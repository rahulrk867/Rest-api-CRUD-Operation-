import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.Date;
import java.util.Locale;
import java.text.SimpleDateFormat;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.framework.ui.ProgramCallable;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Iterator;
import com.matrixone.apps.common.Person;
import  org.apache.poi.hssf.usermodel.HSSFSheet;  
import  org.apache.poi.hssf.usermodel.HSSFWorkbook;  
import  org.apache.poi.hssf.usermodel.HSSFRow;  

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;   
import org.apache.poi.ss.usermodel.Workbook;  
import com.matrixone.apps.framework.ui.UIUtil;
import java.io.*; 
import java.time.LocalDateTime;

public class WMSAOBillDetails_mxJPO extends WMSConstants_mxJPO {

public WMSAOBillDetails_mxJPO(Context context, String[] args) throws Exception {
		super(context, args);
	}

/** Method to get the details for AO User when the bill is pending  (Rahul)**/
public MapList getPendingBillAO(Context context, String[] args) throws Exception {
		MapList mlPendingBill = new MapList();
		try {
			String strFilter = DomainConstants.EMPTY_STRING;
			String strYear = DomainConstants.EMPTY_STRING;
                LocalDateTime now = LocalDateTime.now();
                int year = now.getYear();
                int month = now.getMonthValue();
                
                if(month>3){
                    strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
                }else{
                    strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
                }
                strFilter = strYear;
			//String objectWhere = "current==Review && attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]=='"+strFilter+"'";
			String objectWhere = "current==Review";
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			strListBusSelects.addElement("id");
			strListBusSelects.addElement("physicalid");
			strListBusSelects.addElement("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.name");
			strListBusSelects.addElement("to[WMSWOAbstractMBE].from.attribute[WMSWorkorderTitle].value");
			strListBusSelects.addElement("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.from[WMSProjectCodeHead].to.attribute[Title].value");
			strListBusSelects.addElement("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.from[WMSProjectCodeHead].to.attribute[WMSCodeHeadTitle].value");
			strListBusSelects.addElement("name");
			strListBusSelects.addElement("state[Create].actual");
			strListBusSelects.addElement("state[Approved].actual");
			strListBusSelects.addElement("attribute[BillDiaryNo].value");
			strListBusSelects.addElement("attribute[BillDiaryDate].value");
			strListBusSelects.addElement("attribute[DVNo].value");
			strListBusSelects.addElement("attribute[DVDate].value");
			strListBusSelects.addElement("attribute[WMSCertifiedAmount].value");
			strListBusSelects.addElement("attribute[WMSInvoicedAmount].value");
			strListBusSelects.addElement("attribute[WMSVoucherDate].value");
			strListBusSelects.addElement("attribute[WMSVoucherNumber].value");
			strListBusSelects.addElement("owner");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlPendingBill = DomainObject.findObjects(context, TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					objectWhere, // where clause
					strListBusSelects); // object selects
					
				String BillDairyNumberDetails= "";	
				String DVDetails= "";	
				String strOwnerName= "";
				String strAOAmounts= "";
				String strAODates= "";
				String VoucherDetails= "";
					for (int i = 0; i < mlPendingBill.size(); i++) {
				Map mMap = (Map) mlPendingBill.get(i);
				String BillDairyNumber = (String) mMap.get("attribute[BillDiaryNo].value");
				String BillDairyDate = (String) mMap.get("attribute[BillDiaryDate].value");
				String DVNumber = (String) mMap.get("attribute[DVNo].value");
				String DVDate = (String) mMap.get("attribute[DVDate].value");
				String strAOAmount = (String) mMap.get("attribute[WMSCertifiedAmount].value");
				String strAODate = (String) mMap.get("state[Approved].actual");
				String BillOwner = (String) mMap.get("owner");
				String strVoucherDate = (String) mMap.get("attribute[WMSVoucherDate].value");
				String strVoucherNumber = (String) mMap.get("attribute[WMSVoucherNumber].value");
				if(UIUtil.isNullOrEmpty(BillDairyNumber) && UIUtil.isNullOrEmpty(BillDairyDate))
				{
					BillDairyNumberDetails="Status Pending";
					mMap.put("BillDairyDetails", BillDairyNumberDetails);
				}
				else
				{
					BillDairyNumberDetails= BillDairyNumber + " Dated of " + BillDairyDate;
					mMap.put("BillDairyDetails", BillDairyNumberDetails);
				}
				if(UIUtil.isNullOrEmpty(DVNumber) && UIUtil.isNullOrEmpty(DVDate))
				{
					DVDetails="Status Pending";
					mMap.put("DVDetails", DVDetails);
				}
				else
				{
					DVDetails= DVNumber + " dated of " + DVDate;
					mMap.put("DVDetails", DVDetails);
				}
				String strOwnerID = PersonUtil.getPersonObjectID(context, BillOwner);
			DomainObject dom=DomainObject.newInstance(context,strOwnerID);
			strOwnerName = dom.getInfo(context, "attribute[WMSPersonDesignation].value");
				mMap.put("Unit Name", strOwnerName);
				
				if(UIUtil.isNullOrEmpty(strAODate))
				{
					strAODates="";
					mMap.put("strAODates", strAODates);
				}
				else
				{
					strAODates=strAODate;
					mMap.put("strAODates", strAODates);
				}
				if(UIUtil.isNullOrEmpty(strAOAmount))
				{
					strAOAmounts="";
					mMap.put("strAOAmounts", strAOAmounts);
				}
				else
				{
					strAOAmounts=strAOAmount;
					mMap.put("strAOAmounts", strAOAmounts);
				}
				//Voucher Details
				if(UIUtil.isNullOrEmpty(strVoucherNumber) && UIUtil.isNullOrEmpty(strVoucherDate))
				{
					VoucherDetails="Status Pending";
					mMap.put("VoucherDetails", VoucherDetails);
				}
				else
				{
					VoucherDetails= strVoucherNumber + " Dated of " + strVoucherDate;
					mMap.put("VoucherDetails", VoucherDetails);
				}
				}					
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Get Bill Details " +mlPendingBill);
		return mlPendingBill;
	}
	
	/** Method to get the details for AO User when the bill is Approved for DV Number  (Rahul)**/
public MapList getApprovedBillAO(Context context, String[] args) throws Exception {
		MapList mlPendingBill = new MapList();
		try {
			String strFilter = DomainConstants.EMPTY_STRING;
			String strYear = DomainConstants.EMPTY_STRING;
                LocalDateTime now = LocalDateTime.now();
                int year = now.getYear();
                int month = now.getMonthValue();
                
                if(month>3){
                    strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
                }else{
                    strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
                }
                strFilter = strYear;
			String objectWhere = "revision==last &&  attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]=='"+strFilter+"' && current==Approved";
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			strListBusSelects.addElement("id");
			strListBusSelects.addElement("physicalid");
			strListBusSelects.addElement("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.name");
			strListBusSelects.addElement("to[WMSWOAbstractMBE].from.attribute[WMSWorkorderTitle].value");
			strListBusSelects.addElement("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.from[WMSProjectCodeHead].to.attribute[Title].value");
			strListBusSelects.addElement("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.from[WMSProjectCodeHead].to.attribute[WMSCodeHeadTitle].value");
			strListBusSelects.addElement("name");
			strListBusSelects.addElement("state[Create].actual");
			strListBusSelects.addElement("state[Approved].actual");
			strListBusSelects.addElement("attribute[BillDiaryNo].value");
			strListBusSelects.addElement("attribute[BillDiaryDate].value");
			strListBusSelects.addElement("attribute[DVNo].value");
			strListBusSelects.addElement("attribute[DVDate].value");
			strListBusSelects.addElement("attribute[WMSCertifiedAmount].value");
			strListBusSelects.addElement("attribute[WMSInvoicedAmount].value");
			strListBusSelects.addElement("owner");
			strListBusSelects.addElement("attribute[WMSVoucherDate].value");
			strListBusSelects.addElement("attribute[WMSVoucherNumber].value");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlPendingBill = DomainObject.findObjects(context, TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					objectWhere, // where clause
					strListBusSelects); // object selects
					
				String BillDairyNumberDetails= "";	
				String DVDetails= "";	
				String strOwnerName= "";
				String strAOAmounts= "";
				String strAODates= "";
				String VoucherDetails= "";
					for (int i = 0; i < mlPendingBill.size(); i++) {
				Map mMap = (Map) mlPendingBill.get(i);
				String BillDairyNumber = (String) mMap.get("attribute[BillDiaryNo].value");
				String BillDairyDate = (String) mMap.get("attribute[BillDiaryDate].value");
				String DVNumber = (String) mMap.get("attribute[DVNo].value");
				String DVDate = (String) mMap.get("attribute[DVDate].value");
				String strAOAmount = (String) mMap.get("attribute[WMSCertifiedAmount].value");
				String strAODate = (String) mMap.get("state[Approved].actual");
				String BillOwner = (String) mMap.get("owner");
				String strVocherDate = (String) mMap.get("attribute[WMSVoucherDate].value");
				String strVoucherNumber = (String) mMap.get("attribute[WMSVoucherNumber].value");
				if(UIUtil.isNullOrEmpty(BillDairyNumber) && UIUtil.isNullOrEmpty(BillDairyDate))
				{
					BillDairyNumberDetails="Status Pending";
					mMap.put("BillDairyDetails", BillDairyNumberDetails);
				}
				else
				{
					BillDairyNumberDetails= BillDairyNumber + " Dated of " + BillDairyDate;
					mMap.put("BillDairyDetails", BillDairyNumberDetails);
				}
				if(UIUtil.isNullOrEmpty(DVNumber) && UIUtil.isNullOrEmpty(DVDate))
				{
					DVDetails="Status Pending";
					mMap.put("DVDetails", DVDetails);
				}
				else
				{
					DVDetails= DVNumber + " dated of " + DVDate;
					mMap.put("DVDetails", DVDetails);
				}
				String strOwnerID = PersonUtil.getPersonObjectID(context, BillOwner);
			DomainObject dom=DomainObject.newInstance(context,strOwnerID);
			strOwnerName = dom.getInfo(context, "attribute[WMSPersonDesignation].value");
				mMap.put("Unit Name", strOwnerName);
				
				if(UIUtil.isNullOrEmpty(strAODate))
				{
					strAODates="";
					mMap.put("strAODates", strAODates);
				}
				else
				{
					strAODates=strAODate;
					mMap.put("strAODates", strAODates);
				}
				if(UIUtil.isNullOrEmpty(strAOAmount))
				{
					strAOAmounts="";
					mMap.put("strAOAmounts", strAOAmounts);
				}
				else
				{
					strAOAmounts=strAOAmount;
					mMap.put("strAOAmounts", strAOAmounts);
				}
				//Voucher Details
				if(UIUtil.isNullOrEmpty(strVoucherNumber) && UIUtil.isNullOrEmpty(strVocherDate))
				{
					VoucherDetails="Status Pending";
					mMap.put("VoucherDetails", VoucherDetails);
				}
				else
				{
					VoucherDetails= strVoucherNumber + " Dated of " + strVocherDate;
					mMap.put("VoucherDetails", VoucherDetails);
				}
				}					
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mlPendingBill;
	}
		
	/** Method to get the command visible to AO only (Rahul)**/
	public boolean hasAccessForAODashboard(Context context, String[] args)throws Exception{
		boolean bHasAccess = false;
		try{
			String strPersonId = PersonUtil.getPersonObjectID(context);
			if(UIUtil.isNotNullAndNotEmpty(strPersonId)){
				DomainObject doPerson = new DomainObject(strPersonId);
				String strHostPersonRole = doPerson.getAttributeValue(context, ATTRIBUTE_HOST_ROLE);
				if(UIUtil.isNullOrEmpty(strHostPersonRole) || "AO".equals(strHostPersonRole))
					bHasAccess = true;
			}			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}	
		return bHasAccess;
	}
	
}