
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UICache;
import com.matrixone.apps.framework.ui.UITableIndented;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.Policy;
import matrix.util.StringList;

import com.matrixone.jdom.Element;

import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;

public class WMSActivityLogs_mxJPO extends WMSConstants_mxJPO {
	
	public WMSActivityLogs_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedAcitivityLogs(Context context,String args[]) throws Exception {
		try {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sObjectId = (String) programMap.get("objectId");
			StringList busSelects = new StringList(1);
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add("originated");
			DomainObject doTask = DomainObject.newInstance(context, sObjectId);
			MapList mlActivityLogs = doTask.getRelatedObjects(context, // matrix context
																RELATIONSHIP_WMS_ACTIVITY_LOGS+","+RELATIONSHIP_WMSACTIVITYLOGSCOMMENTS, // relationship pattern
																TYPE_WMS_ACTIVITY_LOGS+","+TYPE_WMSACTIVITYLOGSCOMMENTS, // type pattern
																busSelects, // object selects
																null, // relationship selects
																false, // to direction
																true, // from direction
																(short)2, // recursion level
																null, // object where clause
																null); // relationship where clause
			mlActivityLogs.sortStructure("originated","descending","date");
			return mlActivityLogs;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedTasks(Context context,String args[]) throws Exception {
		try {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sObjectId = (String) programMap.get("objectId");
			StringList busSelects = new StringList(1);
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add("originated");
			busSelects.add("from["+TYPE_WMS_ACTIVITY_LOGS+"]");
			DomainObject doTask = DomainObject.newInstance(context, sObjectId);
			MapList mlActivityLogs = doTask.getRelatedObjects(context, // matrix context
																"Subtask", // relationship pattern
																"Task Management", // type pattern
																busSelects, // object selects
																null, // relationship selects
																false, // to direction
																true, // from direction
																(short) 0, // recursion level
																null, // object where clause
																null); // relationship where clause
			mlActivityLogs.sortStructure("originated","descending","date");
			MapList mlReturnList = new MapList();
			for (int i = 0 ; i < mlActivityLogs.size() ; i++)
			{
				if("TRUE".equals((String)((Map)mlActivityLogs.get(i)).get("from["+TYPE_WMS_ACTIVITY_LOGS+"]")))
				{
					mlReturnList.add((Map)mlActivityLogs.get(i));
				}
			}
			return mlReturnList;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public HashMap createLogEntry(Context context, String [] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Map paramMap = (Map) programMap.get("paramMap");
		String sObjectId=(String)paramMap.get("objectId");

		String sRowId = "" ;
		String strNewObject = "";

		HashMap columnsMap;
		HashMap changedRowMap;
		HashMap doc = new HashMap();
		HashMap retMap;
		DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
		DomainObject doBillItemObject = DomainObject.newInstance(context);

		Element elm = (Element) programMap.get("contextData");        
		MapList mlItems = new MapList();
		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		Map mapAttr = new HashMap();     

		for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
		{
			try
			{   
				retMap = new HashMap();
				changedRowMap = (HashMap) chgRowsMapList.get(i);
				columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");

				String strDesc = (String) columnsMap.get("Description");

				strNewObject = DomainObject.getAutoGeneratedName(context, "type_WMSActivityLogs", DomainConstants.EMPTY_STRING);
				DomainRelationship domRel   = doBillItemObject.createAndConnect(context,
																				TYPE_WMS_ACTIVITY_LOGS,
																				strNewObject,
																				"-",
																				POLICY_WMS_ACTIVITY_LOGS,
																				null,
																				RELATIONSHIP_WMS_ACTIVITY_LOGS,
																				domAmbObject,
																				true);

				if (strDesc != null && !"".equals(strDesc)) {
					doBillItemObject.setDescription(context,strDesc);
				}

				doBillItemObject.setAttributeValues(context,mapAttr);
				retMap = new HashMap();
				retMap.put("oid", doBillItemObject.getObjectId(context));
				retMap.put("relid", domRel.toString());
				retMap.put("pid", "");
				retMap.put("rid", "");
				retMap.put("markup", "new");
				retMap.put("rowId", sRowId);
				columnsMap.putAll(retMap);
				retMap.put("columns", columnsMap);
				mlItems.add(retMap);
				doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
				doc.put("Action", "success"); // Here the action can be "Success" or "refresh"
			}
			catch(Exception Ex)
			{
				Ex.printStackTrace();
				throw Ex;
			}
		}
		return doc;
	}
	@com.matrixone.apps.framework.ui.ProgramCallable
	public String getTotalSum(Context context,String args[]) throws Exception 
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strReturnValue = "";
		String strRICTotalRows = (String)PersonUtil.getPersonProperty(context, "RIC_TotalRows");
		StringList slCellValues = (StringList)programMap.get("columnValues");
		int iRowsSize = Integer.parseInt(strRICTotalRows);
		if(iRowsSize==slCellValues.size())
		{
			strReturnValue = (String)FrameworkUtil.getSum(context,context.getLocale(), slCellValues);
		}
		return strReturnValue;
	}
	public StringList displayNameofCommentBy(Context context,String args[]) throws Exception 
	{
		
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		StringList strReturnValue = new StringList();
		for (int i = 0 ; i < objectList.size(); i++)
		{
			Map mTemp = (Map)objectList.get(i);
			String strId = (String)mTemp.get(DomainObject.SELECT_ID);
			String strOwnerFisrtName = null;
			String strOwnerlastName =null;
			String strOwnerName =null;
			DomainObject domstrId =  DomainObject.newInstance(context,strId);
			String contextECOwner     = domstrId.getInfo(context,DomainConstants.SELECT_OWNER);
			String contextECType     = domstrId.getInfo(context,DomainConstants.SELECT_TYPE);
			String strOwnerID = PersonUtil.getPersonObjectID(context, contextECOwner);
			DomainObject dom=DomainObject.newInstance(context,strOwnerID);
			if(TYPE_WMS_ACTIVITY_LOGS.equals(contextECType)){
			strOwnerFisrtName =dom.getInfo(context, "attribute[First Name].value");
			strOwnerlastName =dom.getInfo(context, "attribute[Last Name].value");
			strOwnerName = strOwnerFisrtName +" "+ strOwnerlastName;
			}
			strReturnValue.add(strOwnerName);
		}
		return strReturnValue;
	}
	
	public boolean displayLoggedOn(Context context, String[] args)throws Exception{
		boolean bReturn = true;
		try{
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId=(String)programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				DomainObject doObj = DomainObject.newInstance(context,sObjectId);
				String strParentType = (String)doObj.getInfo(context,"to[Subtask].from.type");
				if(UIUtil.isNotNullAndNotEmpty(strParentType) && "Project Space".equals(strParentType)){
					bReturn = false;
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return bReturn;
	}
	public StringList displayNameInWorkDairy(Context context,String args[]) throws Exception 
	{
		
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		StringList strReturnValue = new StringList();
		for (int i = 0 ; i < objectList.size(); i++)
		{
			Map mTemp = (Map)objectList.get(i);
			String strId = (String)mTemp.get(DomainObject.SELECT_ID);
			String strOwnerFisrtName = null;
			String strOwnerlastName =null;
			String strOwnerName =null;
			DomainObject domstrId =  DomainObject.newInstance(context,strId);
			String contextECOwner     = domstrId.getInfo(context,DomainConstants.SELECT_OWNER);
			String contextECType     = domstrId.getInfo(context,DomainConstants.SELECT_TYPE);
			String strOwnerID = PersonUtil.getPersonObjectID(context, contextECOwner);
			DomainObject dom=DomainObject.newInstance(context,strOwnerID);
			if(TYPE_WMS_ACTIVITY_LOGS.equals(contextECType)){
			//strOwnerFisrtName =dom.getInfo(context, "attribute[First Name].value");
			//strOwnerlastName =dom.getInfo(context, "attribute[Last Name].value");
			strOwnerName = dom.getInfo(context, "attribute[WMSPersonDesignation].value");
			}
			strReturnValue.add(strOwnerName);
		}
		return strReturnValue;
	}
	
 }
 