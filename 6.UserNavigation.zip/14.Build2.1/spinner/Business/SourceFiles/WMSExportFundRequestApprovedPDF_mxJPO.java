import java.io.File;
import java.util.HashMap;
import java.util.Map;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;

import com.itextpdf.io.image.ImageData; 
import com.itextpdf.io.image.ImageDataFactory; 
import com.itextpdf.kernel.pdf.PdfDocument; 
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Image; 
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Cell; 
import com.itextpdf.layout.element.Table;  
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.Property;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.VerticalAlignment;
import com.itextpdf.layout.property.HorizontalAlignment;

import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;

public class WMSExportFundRequestApprovedPDF_mxJPO extends WMSConstants_mxJPO {

	public WMSExportFundRequestApprovedPDF_mxJPO(Context context,String[] args) {
		super(context,args);
	}
	public HashMap generateFundRequestApprovedPDF(Context context, String[] args) throws Exception 
	{
		try{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strFQId = (String)programMap.get("FQId");
		DomainObject doFQ = DomainObject.newInstance(context, strFQId);
		String strTransPath = context.createWorkspace();
		String strFileName = "FundRequest-"+(String)doFQ.getInfo(context,"name")+".pdf";
		String dest = strTransPath+File.separator+strFileName;

		//get data
		Map hmObjDetails = new HashMap();
		hmObjDetails.put("objectId", strFQId);
		HashMap hmDetails = (HashMap)JPO.invoke(context, "WMSFundDashboard", null, "getFundRequestDataForPDF", JPO.packArgs(hmObjDetails), HashMap.class);
		System.out.println("hmDetails"+hmDetails);

// Creating a PdfDocument
		PdfDocument pdf = new PdfDocument(new PdfWriter(dest));
		// Creating a Document
		Document document = new Document(pdf, PageSize.A4, false);
		//adding DGNP logo
		String imgFile = getImgFile(context);
		ImageData imgdata = ImageDataFactory.create(imgFile);
		Image image = new Image(imgdata);
		image.setTextAlignment(TextAlignment.CENTER);
		document.add(image);
		
		//add space
		//document.add(new Paragraph(""));
	        String FolioNumber = (String)hmDetails.get("FolioNumber");
			String ApprovedDate = (String)hmDetails.get("Fund Approved Date");
			/*Paragraph pHead = new Paragraph(FolioNumber +"\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0"+ ApprovedDate)
									.setTextAlignment(TextAlignment.LEFT)
									.setTextAlignment(TextAlignment.LEFT)
									.setFontSize(10);
				document.add(pHead);*/
			Paragraph p1 = new Paragraph(FolioNumber)
									.setTextAlignment(TextAlignment.LEFT)
									.setFontSize(10);
									document.add(new Paragraph(""));
										document.add(p1);
										
				Paragraph p2 = new Paragraph(ApprovedDate)
									.setTextAlignment(TextAlignment.RIGHT)
									.setFontSize(10);
									document.add(new Paragraph(""));
										document.add(p2);	
										
			Paragraph p3 = new Paragraph("INTER OFFICER NOTE")
									.setTextAlignment(TextAlignment.CENTER)
									.setFontSize(14)
									.setUnderline(0.1f, -2f);
									document.add(new Paragraph(""));
		document.add(p3);
		Paragraph p4 = new Paragraph("E-5(BUDGET)")
									.setTextAlignment(TextAlignment.CENTER)
									.setFontSize(14)
									.setUnderline(0.1f, -2f);
		//Add Space
		document.add(new Paragraph(""));
		document.add(p4);
				Paragraph p5 = new Paragraph("1. Allotment/Withdrawal/ReAppropriation of fund for expenditure during CFY is made as under:-")
									.setTextAlignment(TextAlignment.LEFT)
									.setFontSize(10);
		document.add(p5);
		document.add(new Paragraph(""));
		
		Table table = new Table(UnitValue.createPercentArray(new float[] {1, 6, 6, 3, 3, 3, 2}));
		table.addCell(createCell("Ser", 1, 1, TextAlignment.CENTER).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")).setFontSize(10));
		table.addCell(createCell("Project Name", 1, 1, TextAlignment.CENTER).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")).setFontSize(10));
		table.addCell(createCell("Work Name", 1, 1, TextAlignment.CENTER).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")).setFontSize(10));
		table.addCell(createCell("Existing"+"\n"+ "Allotment", 1, 1, TextAlignment.CENTER).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")).setFontSize(10));
		table.addCell(createCell("Additional"+"\n"+ "Allotment", 1, 1, TextAlignment.CENTER).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")).setFontSize(10));
		table.addCell(createCell("Revised"+ "\n"+ "Allotment", 1, 1, TextAlignment.CENTER).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")).setFontSize(10));
		table.addCell(createCell("Section Name", 1, 1, TextAlignment.CENTER).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")).setFontSize(10));
		
		int iCounter = 1;
		String strProjectName = (String)hmDetails.get("ProjectName");
		String strWorkName = (String)hmDetails.get("WorkName");
		String  strExistingAllot= (String)hmDetails.get("AllotmentAmount");
		String dAdditionalAllot =  (String)hmDetails.get("TotalAmount");
		double dExistingAllot = Double.parseDouble(strExistingAllot);
		double dTotalAllot = Double.parseDouble(dAdditionalAllot);
		double dRevisedAllot = dExistingAllot+dTotalAllot;
		String strRevisedAllot = dRevisedAllot+"";
		String strUnitName=(String)hmDetails.get("designation");
		String strCodeHeadName=(String)hmDetails.get("CodeHead Name");
		String strCodeHeadTitle=(String)hmDetails.get("CodeHead Title");
		
		table.addCell(createCell(iCounter+"", 1, 1, TextAlignment.CENTER).setFontSize(8));
		table.addCell(createCell(strProjectName +"\n"+ "(" +strCodeHeadName+ "-" +strCodeHeadTitle+")" , 1, 1, TextAlignment.CENTER).setFontSize(8));
		table.addCell(createCell(strWorkName, 1, 1, TextAlignment.CENTER).setFontSize(8));
		table.addCell(createCell(strExistingAllot, 1, 1, TextAlignment.CENTER).setFontSize(8));
		table.addCell(createCell(dAdditionalAllot, 1, 1, TextAlignment.CENTER).setFontSize(8));
		table.addCell(createCell(strRevisedAllot, 1, 1, TextAlignment.CENTER).setFontSize(8));
		table.addCell(createCell(strUnitName, 1, 1, TextAlignment.CENTER).setFontSize(8));
		document.add(table);
		
		document.add(new Paragraph(""));
		Paragraph p6 = new Paragraph("2. Please ensure that the funds are utilized in full and the expenditure does not exceed the allotment amount")
									.setTextAlignment(TextAlignment.LEFT)
									.setFontSize(10);
		document.add(p6);
		String strAllotmentDetails=  (String)hmDetails.get("AllocationData");
		Paragraph p7 = new Paragraph("3. Authority : " +strAllotmentDetails)
									.setTextAlignment(TextAlignment.LEFT)
									.setFontSize(10);
		document.add(p7);
		
		String strAllotmentRemarks=  (String)hmDetails.get("AllotmentRemarks");
		Paragraph p8 = new Paragraph("4. Remarks : " +strAllotmentRemarks)
									.setTextAlignment(TextAlignment.LEFT)
									.setFontSize(10);
		document.add(p8);
		String StrDirBudgetName = "(Sukand Sharma)";
		String StrDirBudgetDesignation = "Capt(IN)";
		String StrDirBudgetDesgDGNP = "SO(Budget)";
		String StrDGNP = "for Director General";
		String strDepartment = (String)hmDetails.get("department");
		if(strDepartment == null)
			strDepartment = "";
			
		String strFA = "FA DGNP(V)";
		String strAO = "AO DGNP(V)";
		/*Paragraph pHead1 = new Paragraph(strDepartment+"\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0"+ StrDirBudgetName + "\n" +strUnitName+"\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0"+ StrDirBudgetDesignation + "\n" +"AO DGNP(V)\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0"+ StrDirBudgetDesgDGNP + "\n" + "FA DGNP(V)\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0"+ StrDGNP)
		.setTextAlignment(TextAlignment.LEFT)
									.setTextAlignment(TextAlignment.LEFT)
									.setFontSize(8);
				document.add(pHead1);*/
				
				
		Paragraph pHead1 = new Paragraph("\n \u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0" + StrDirBudgetName  + "\n \u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0" + StrDirBudgetDesignation + "\n\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0" + StrDirBudgetDesgDGNP + "\n\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0" + StrDGNP)
		.setTextAlignment(TextAlignment.LEFT)
		.setFontSize(10);
			document.add(pHead1);
			
				Paragraph phead2 = new Paragraph(strDepartment + "\n" + strUnitName + "\n "  +strFA+ "\n" + strAO)
									.setTextAlignment(TextAlignment.LEFT)
									.setFontSize(10);
		document.add(phead2);

			
		
		//add footer
		float width = pdf.getDefaultPageSize().getWidth();
		float height = pdf.getDefaultPageSize().getHeight();
		int n = pdf.getNumberOfPages();
		PdfCanvas canvas;
		Rectangle pageSize;
		for(int i=1;i<=n;i++)
		{
			PdfPage page = pdf.getPage(i);
			pageSize = page.getPageSize();
			canvas = new PdfCanvas(page);
			canvas.setStrokeColor(ColorConstants.BLACK).setLineWidth(.2f).moveTo(pageSize.getWidth()/2-30,20).lineTo(pageSize.getWidth()/2+30,20).stroke();

			//Draw page number
			canvas.beginText().setFontAndSize(PdfFontFactory.createFont(FontConstants.HELVETICA),7).moveText(pageSize.getWidth()/2-7,10).showText(String.valueOf(i)).showText(" of ").showText(String.valueOf(n)).endText();

			//add border
			canvas.rectangle(20, 20, width - 40, height - 40);
			canvas.stroke();
		}
		document.close();
pdf.close();
		
		//checkin file
		checkinFile(context, strFQId, strTransPath, strFileName);
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
			
		}
		HashMap hmReturnMap = new HashMap();
		hmReturnMap.put("Action","Success");
		return hmReturnMap;
	}
	private static Cell createCell(String content, float borderWidth, int colspan, TextAlignment alignment) {
		Cell cell = new Cell(1, colspan).add(new Paragraph(content));
		cell.setTextAlignment(alignment);
		if(borderWidth==0)
			cell.setBorder(Border.NO_BORDER);
		else
			cell.setBorder(new SolidBorder(borderWidth));
		return cell;
	}
	private static void checkinFile(Context context, String strObjId, String strFilePath, String strFileName) throws Exception
	{
		DomainObject dObject = DomainObject.newInstance(context,strObjId);
		ContextUtil.pushContext(context);
		dObject.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strFilePath);
		ContextUtil.popContext(context);
	}
	private static String getImgFile(Context context) throws Exception
	{
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
		String strLogo = newFile.getCanonicalPath()+strImageFolder+"banner.png";
		strLogo = strLogo.replace("\\", "/");
		return strLogo;
}
}

