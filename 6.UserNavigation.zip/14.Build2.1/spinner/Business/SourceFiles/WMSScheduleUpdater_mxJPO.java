import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.ContextUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class WMSScheduleUpdater_mxJPO extends WMSConstants_mxJPO {
	
/*
Tasks Names are hardcoded based on the templates. If the template is changed/tasks names are changes, the schedule will not be updated automatically.
*/
	public WMSScheduleUpdater_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	public void updateProjectSchedule(Context context, String[] args) throws Exception 
    {
        try {
            MapList mlSOCList = new MapList();
			
			String objectWhere = "revision==last";
			StringList slListBusSelects = new StringList();
			slListBusSelects.add(DomainConstants.SELECT_ID);
			slListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			slListBusSelects.add(DomainConstants.SELECT_CURRENT);
			slListBusSelects.add("to[WMSProjectSOC].from.id");
			slListBusSelects.add("state[RIC].actual");
			slListBusSelects.add("state[ListingOfProjects].actual");
			slListBusSelects.add("state[BoardProceedings].actual");
			slListBusSelects.add("state[AE].actual");
			slListBusSelects.add("state[AdminApproval].actual");
			slListBusSelects.add("state[Delegation].actual");
			slListBusSelects.add("state[UnderExecution].actual");
			
			HashMap mAttaMap = new HashMap();
			
			StringList slTaskSelect = new StringList();
			slTaskSelect.add(DomainObject.SELECT_CURRENT);
			slTaskSelect.add(DomainObject.SELECT_NAME);	
			slTaskSelect.add(DomainObject.SELECT_ID);	

			StringList slMasterSelects = new StringList();
			slMasterSelects.add(DomainObject.SELECT_CURRENT);
			slMasterSelects.add("state[Approved].actual");
			slMasterSelects.add("attribute[Title].value");
			
			StringList slRelSelet = new StringList();
			slRelSelet.add(DomainRelationship.SELECT_ID);
			
			mlSOCList = DomainObject.findObjects(context, TYPE_WMSSOC, // type filter
						DomainConstants.QUERY_WILDCARD, // vault filter
						objectWhere, // where clause
						slListBusSelects); // object selects
		
			Map mTempSOC = null;
			String strSOCId = "";
			String strSOCState = "";
			String strProjectId = "";
			String strProjectTaskId = "";
			String strSOCRICActual = "";
			String strSOCListingOfProjects = "";
			String strSOCBoardProceedings = "";
			String strSOCAEActual = "";
			String strSOCAdminApprovalActual = "";
			String strSOCDelegationActual = "";
			String strSOCUnderExecutionActual = "";
			DomainObject doSOC = DomainObject.newInstance(context);
			DomainObject doProject = DomainObject.newInstance(context);
			com.matrixone.apps.program.Task task = (com.matrixone.apps.program.Task) DomainObject.newInstance(context, DomainConstants.TYPE_TASK, "PROGRAM");
			for(int i=0;i<mlSOCList.size();i++){
				mTempSOC = (Map)mlSOCList.get(i);
				strSOCId = (String)mTempSOC.get(DomainObject.SELECT_ID);
				strSOCState = (String)mTempSOC.get(DomainObject.SELECT_CURRENT);
				strSOCRICActual = (String)mTempSOC.get("state[RIC].actual");
				strSOCListingOfProjects = (String)mTempSOC.get("state[ListingOfProjects].actual");
				strSOCBoardProceedings = (String)mTempSOC.get("state[BoardProceedings].actual");
				strSOCAEActual = (String)mTempSOC.get("state[AE].actual");
				strSOCAdminApprovalActual = (String)mTempSOC.get("state[AdminApproval].actual");
				strSOCDelegationActual = (String)mTempSOC.get("state[Delegation].actual");
				strSOCUnderExecutionActual = (String)mTempSOC.get("state[UnderExecution].actual");
				
				if(UIUtil.isNotNullAndNotEmpty(strSOCState) && "Create".equals(strSOCState)==false && "Submit".equals(strSOCState)==false){
					doSOC.setId(strSOCId);
					strProjectId = (String)mTempSOC.get("to[WMSProjectSOC].from.id");
					if(UIUtil.isNotNullAndNotEmpty(strProjectId)){
						doProject.setId(strProjectId);
						
						MapList mlSubTasks = (MapList)doProject.getRelatedObjects(context, // matrix context
								"Subtask", // relationship pattern
								DomainConstants.QUERY_WILDCARD, // type pattern
								slTaskSelect, // object selects
								slRelSelet, // relationship selects
								false, // to direction
								true, // from direction
								(short) 0, // recursion level
								DomainConstants.EMPTY_STRING, // object where clause
								DomainConstants.EMPTY_STRING, // relationship where clause
								0);
								
						//Updating RIC Tasks-Start
						MapList mlRICMaster = (MapList)doSOC.getRelatedObjects(context, // matrix context
							"WMSSOCRICMaster", // relationship pattern
							DomainConstants.QUERY_WILDCARD, // type pattern
							slMasterSelects, // object selects
							slRelSelet, // relationship selects
							false, // to direction
							true, // from direction
							(short) 1, // recursion level
							DomainConstants.EMPTY_STRING, // object where clause
							DomainConstants.EMPTY_STRING, // relationship where clause
							0);
						Map mRICMap = null;
						String strRICMasterState = "";
						String strRICApprovedDate = "";
						String strRICTitle = "";
						for(int iRIC=0;iRIC<mlRICMaster.size();iRIC++){
							mRICMap = (Map)mlRICMaster.get(iRIC);
							strRICMasterState = (String)mRICMap.get(DomainObject.SELECT_CURRENT);
							strRICTitle = (String)mRICMap.get("attribute[Title].value");
							strRICApprovedDate = (String)mRICMap.get("state[Approved].actual");
							if("Approved".equals(strRICMasterState) && "Works".equals(strRICTitle) && UIUtil.isNotNullAndNotEmpty(strRICApprovedDate)){
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of RIC - Works");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCRICActual);
									mAttaMap.put("Task Actual Finish Date",strRICApprovedDate);
									mAttaMap.put("Percent Complete","100");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
								
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of RIC - Services");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCRICActual);
									mAttaMap.put("Task Actual Finish Date",strRICApprovedDate);
									mAttaMap.put("Percent Complete","100");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
							}else if("RIC".equals(strSOCState)){
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of RIC - Works");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCRICActual);
									mAttaMap.put("Percent Complete","10");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
								
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of RIC - Services");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCRICActual);
									mAttaMap.put("Percent Complete","10");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
								
							}
							if("Approved".equals(strRICMasterState) && "Equipments".equals(strRICTitle) && UIUtil.isNotNullAndNotEmpty(strRICApprovedDate)){
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of RIC - Equipment");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCRICActual);
									mAttaMap.put("Task Actual Finish Date",strRICApprovedDate);
									mAttaMap.put("Percent Complete","100");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
							}else if("RIC".equals(strSOCState)){
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of RIC - Equipment");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCRICActual);
									mAttaMap.put("Percent Complete","10");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
							}								
						}
						if(UIUtil.isNotNullAndNotEmpty(strSOCListingOfProjects)){
							strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Consolidation and Approval of RIC");
							if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
								task.setId(strProjectTaskId);
								task.setState(context,"Active",true);
								mAttaMap = new HashMap();
								mAttaMap.put("Task Actual Start Date",strSOCRICActual);
								mAttaMap.put("Task Actual Finish Date",strSOCListingOfProjects);
								mAttaMap.put("Percent Complete","100");
								task.setAttributeValues(context,mAttaMap);
								task.rollupAndSave(context);
							}
						}
						
						//Updating RIC Tasks-End
						//Updating Post RIC Tasks - Start
						if(UIUtil.isNotNullAndNotEmpty(strSOCListingOfProjects)){
							strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Listing of Project");
							if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
								task.setId(strProjectTaskId);
								task.setState(context,"Active",true);
								mAttaMap = new HashMap();
								mAttaMap.put("Task Actual Start Date",strSOCListingOfProjects);
								if(UIUtil.isNotNullAndNotEmpty(strSOCBoardProceedings)){
									mAttaMap.put("Task Actual Finish Date",strSOCBoardProceedings);
									mAttaMap.put("Percent Complete","100");
								}else{
									mAttaMap.put("Percent Complete","10");
								}								
								task.setAttributeValues(context,mAttaMap);
								task.rollupAndSave(context);
							}
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strSOCBoardProceedings)){
							strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Board Proceedings");
							if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
								task.setId(strProjectTaskId);
								task.setState(context,"Active",true);
								mAttaMap = new HashMap();
								mAttaMap.put("Task Actual Start Date",strSOCBoardProceedings);
								if(UIUtil.isNotNullAndNotEmpty(strSOCAEActual)){
									mAttaMap.put("Task Actual Finish Date",strSOCAEActual);
									mAttaMap.put("Percent Complete","100");
								}else{
									mAttaMap.put("Percent Complete","10");
								}
								mAttaMap.put("Percent Complete","100");
								task.setAttributeValues(context,mAttaMap);
								task.rollupAndSave(context);
							}
						}
						//Updating Post RIC Tasks - End		
						
						//Updating AE Tasks-Start
						MapList mlAEMaster = (MapList)doSOC.getRelatedObjects(context, // matrix context
							"WMSSOCAEMaster", // relationship pattern
							DomainConstants.QUERY_WILDCARD, // type pattern
							slMasterSelects, // object selects
							slRelSelet, // relationship selects
							false, // to direction
							true, // from direction
							(short) 1, // recursion level
							DomainConstants.EMPTY_STRING, // object where clause
							DomainConstants.EMPTY_STRING, // relationship where clause
							0);
						Map mAEMap = null;
						String strAEMasterState = "";
						String strAEApprovedDate = "";
						String strAETitle = "";
						for(int iAE=0;iAE<mlAEMaster.size();iAE++){
							mAEMap = (Map)mlAEMaster.get(iAE);
							strAEMasterState = (String)mAEMap.get(DomainObject.SELECT_CURRENT);
							strAETitle = (String)mAEMap.get("attribute[Title].value");
							strAEApprovedDate = (String)mAEMap.get("state[Approved].actual");
							if("Approved".equals(strAEMasterState) && "Works".equals(strAETitle) && UIUtil.isNotNullAndNotEmpty(strAEApprovedDate)){
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of AE - Works");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCAEActual);
									mAttaMap.put("Task Actual Finish Date",strAEApprovedDate);
									mAttaMap.put("Percent Complete","100");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
								
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of AE - Services");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCAEActual);
									mAttaMap.put("Task Actual Finish Date",strAEApprovedDate);
									mAttaMap.put("Percent Complete","100");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
							}else if("AE".equals(strSOCState)){
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of AE - Works");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCAEActual);
									mAttaMap.put("Percent Complete","10");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of AE - Services");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCAEActual);
									mAttaMap.put("Percent Complete","10");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
								
							}
							if("Approved".equals(strAEMasterState) && "Equipments".equals(strAETitle) && UIUtil.isNotNullAndNotEmpty(strAEApprovedDate)){
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of RIC - Equipment");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCAEActual);
									mAttaMap.put("Task Actual Finish Date",strAEApprovedDate);
									mAttaMap.put("Percent Complete","100");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
							}else if("AE".equals(strSOCState)){
								strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Preparation of RIC - Equipment");
								if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
									task.setId(strProjectTaskId);
									task.setState(context,"Active",true);
									mAttaMap = new HashMap();
									mAttaMap.put("Task Actual Start Date",strSOCAEActual);
									mAttaMap.put("Percent Complete","10");
									task.setAttributeValues(context,mAttaMap);
									task.rollupAndSave(context);
								}
							}								
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strSOCAdminApprovalActual)){
							strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Consolidation and Approval of AE/Admin Approval");
							if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
								task.setId(strProjectTaskId);
								task.setState(context,"Active",true);
								mAttaMap = new HashMap();
								mAttaMap.put("Task Actual Start Date",strSOCAEActual);
								mAttaMap.put("Task Actual Finish Date",strSOCAdminApprovalActual);
								mAttaMap.put("Percent Complete","100");
								task.setAttributeValues(context,mAttaMap);
								task.rollupAndSave(context);
							}
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strSOCAdminApprovalActual)){
							strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Admin Approval");
							String strAdminApprovalDate = (String)doSOC.getInfo(context,"from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
							if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId) && UIUtil.isNotNullAndNotEmpty(strAdminApprovalDate)){
								task.setId(strProjectTaskId);
								task.setState(context,"Active",true);
								mAttaMap = new HashMap();
								mAttaMap.put("Task Actual Start Date",strSOCAdminApprovalActual);
								if(UIUtil.isNotNullAndNotEmpty(strAdminApprovalDate)){
									mAttaMap.put("Task Actual Finish Date",strAdminApprovalDate);
									mAttaMap.put("Percent Complete","100");
								}else{
									mAttaMap.put("Percent Complete","10");
								}
								task.setAttributeValues(context,mAttaMap);
								task.rollupAndSave(context);
							}
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strSOCDelegationActual)){
							strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Delegation");
							String strDelegationApprovalDate = (String)doSOC.getInfo(context,"from[WMSSOCDelegation].to.state[Delegated].actual");
							if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId) && UIUtil.isNotNullAndNotEmpty(strDelegationApprovalDate)){
								task.setId(strProjectTaskId);
								task.setState(context,"Active",true);
								mAttaMap = new HashMap();
								mAttaMap.put("Task Actual Start Date",strSOCDelegationActual);
								if(UIUtil.isNotNullAndNotEmpty(strDelegationApprovalDate)){
									mAttaMap.put("Task Actual Finish Date",strDelegationApprovalDate);
									mAttaMap.put("Percent Complete","100");
								}else{
									mAttaMap.put("Percent Complete","10");
								}								
								task.setAttributeValues(context,mAttaMap);
								task.rollupAndSave(context);
							}
						}
						if(UIUtil.isNotNullAndNotEmpty(strSOCUnderExecutionActual)){
							strProjectTaskId = getTaskIdUsingName(context,mlSubTasks,"Execution");
							if(UIUtil.isNotNullAndNotEmpty(strProjectTaskId)){
								task.setId(strProjectTaskId);
								task.setState(context,"Active",true);
								mAttaMap = new HashMap();
								mAttaMap.put("Task Actual Start Date",strSOCUnderExecutionActual);
								task.setAttributeValues(context,mAttaMap);
								task.rollupAndSave(context);
							}
						}						
					}
				}
			}
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	
	public static String getTaskIdUsingName(Context context, MapList mlSchedule, String strTaskName) throws Exception{
		String strTaskId = "";
		try{
			Map mTemp = null;
			String strName = "";
			String strCurrent = "";
			for(int i=0;i<mlSchedule.size();i++){
				mTemp = (Map)mlSchedule.get(i);
				strName = (String)mTemp.get(DomainObject.SELECT_NAME);
				strCurrent = (String)mTemp.get(DomainObject.SELECT_CURRENT);
				if("Complete".equals(strCurrent)==false){
					strTaskId = (String)mTemp.get(DomainObject.SELECT_ID);
					//break;
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return strTaskId;
	}
 }