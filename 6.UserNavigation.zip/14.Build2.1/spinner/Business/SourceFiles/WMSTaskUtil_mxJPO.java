/** Name of the JPO    : WMSTaskUtil
 ** Developed by    :  
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to use utilities created for code.
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/
import java.util.Map;
import matrix.util.StringList;
import matrix.db.Context;
import matrix.db.JPO;
import java.util.Vector;
import java.util.HashMap;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import com.matrixone.apps.domain.util.PersonUtil;


/**
 * The purpose of this JPO is to use utilities created
 * @author 
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSTaskUtil_mxJPO
{
	 


    /**
     * Constructor.
     * @param context the eMatrix Context object
     * @param strArguments holds the following input arguments[0]-id of the business object
     * @throws Exception if the operation fails    
     * @since 418
     */
    public WMSTaskUtil_mxJPO (Context context, String[] args) throws Exception
    {
         //super(context,args);
    }
    /**
     * Main entry point.
     *
     * @param context
     *            the eMatrix <code>Context</code> object
     * @param args
     *            holds no arguments
     * @return an integer status code (0 = success)
     * @throws Exception
     *             if the operation fails
     * @since 418
     */
    public int mxMain(Context context, String[] args) throws Exception {
        if (!context.isConnected())
            throw new Exception("Not supported on desktop client");
        return 0;
    }


   public Vector getContents(Context context, String[] args) throws Exception 
    {
		System.out.println("getContents----");
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
			Map mTemp = null;
			String strTaskId = DomainConstants.EMPTY_STRING;
			DomainObject doTask = null;
			for(int i=0; i<intSize;i++){
				mTemp = (Map)objectList.get(i);
				strTaskId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
					doTask = new DomainObject(strTaskId);
					
					StringList slContectList = (StringList)doTask.getInfoList(context,"from[Route Task].to.to[Object Route].from.id");
					
					StringBuilder strUrl = new StringBuilder();
					for(int j=0;j<slContectList.size();j++){
						String strContectId = (String)slContectList.get(j);
						doTask = new DomainObject(strContectId);
						String strName = doTask.getInfo(context,DomainObject.SELECT_NAME);						
						String strType = doTask.getInfo(context,DomainObject.SELECT_TYPE);	
						String strFinal= strType.substring(3);
						String strLink = "../common/emxTree.jsp?objectId="+strContectId;
						strUrl.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");            
						strUrl.append(strFinal + " Details");
						strUrl.append("</a>");
						strUrl.append("<br/>");
					}
					vColumnValues.add(strUrl.toString());
				}else{
					vColumnValues.add(DomainConstants.EMPTY_STRING);
				}
					
			}
			
		 return vColumnValues;
		}catch (Exception e) {
            throw e;
        }
           
        }

	public StringList getQuickTaskCompleteLink(Context context, String [] args) throws Exception{
		HashMap programMap        = (HashMap) JPO.unpackArgs(args);
	    MapList relBusObjPageList = (MapList)programMap.get("objectList");
		StringList slLinks = new StringList(relBusObjPageList.size());
		String sTaskLink = "";
	    for (int i=0; i < relBusObjPageList.size(); i++) {
	         Map collMap = (Map)relBusObjPageList.get(i);
	         String sTaskType  = (String)collMap.get(DomainObject.SELECT_TYPE);
	         String sTaskId  = (String)collMap.get(DomainObject.SELECT_ID);
			 
			 System.out.println("sTaskType----"+sTaskType);
			 
			 if(UIUtil.isNotNullAndNotEmpty(sTaskId)){
				 DomainObject doTask = new DomainObject(sTaskId);
				 
				 String strContentType = (String)doTask.getInfo(context,"from[Route Task].to.to[Object Route].from.type");
				 
				 if(UIUtil.isNotNullAndNotEmpty(strContentType)){
					 if(strContentType.startsWith("DMS")){
						String routeTaskAction  = (String)collMap.get("attribute["+ DomainConstants.ATTRIBUTE_ROUTE_ACTION +"]");
						 if(routeTaskAction.equalsIgnoreCase("Approve")){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/dms_emxTaskCompletePreProcess.jsp?action=Approve&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else if((routeTaskAction.equalsIgnoreCase("Comment") || routeTaskAction.equalsIgnoreCase("Notify Only"))){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/dms_emxTaskCompletePreProcess.jsp?action=Complete&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else{
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxUserTasksSummaryLinksProcess.jsp?fromPage=Complete&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;emxTableRowId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }
						 sTaskLink  = "<a href=\"" + sTaskLink + "\">" + "<img src=\"" + "../common/images/buttonDialogDone.gif" + "\" width=\"16px\" height=\"16px\"/>" + "</a>";
						 slLinks.add(sTaskLink); 
					 }else if(strContentType.startsWith("WMS")){
						String routeTaskAction  = (String)collMap.get("attribute["+ DomainConstants.ATTRIBUTE_ROUTE_ACTION +"]");
						 if(routeTaskAction.equalsIgnoreCase("Approve")){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/wms_emxTaskCompletePreProcess.jsp?action=Approve&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else if((routeTaskAction.equalsIgnoreCase("Comment") || routeTaskAction.equalsIgnoreCase("Notify Only"))){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/wms_emxTaskCompletePreProcess.jsp?action=Complete&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else{
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxUserTasksSummaryLinksProcess.jsp?fromPage=Complete&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;emxTableRowId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }
						 sTaskLink  = "<a href=\"" + sTaskLink + "\">" + "<img src=\"" + "../common/images/buttonDialogDone.gif" + "\" width=\"16px\" height=\"16px\"/>" + "</a>";
						 slLinks.add(sTaskLink); 
					 }else{
						 String routeTaskAction  = (String)collMap.get("attribute["+ DomainConstants.ATTRIBUTE_ROUTE_ACTION +"]");
						 if(routeTaskAction.equalsIgnoreCase("Approve")){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxTaskCompletePreProcess.jsp?action=Approve&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else if((routeTaskAction.equalsIgnoreCase("Comment") || routeTaskAction.equalsIgnoreCase("Notify Only"))){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxTaskCompletePreProcess.jsp?action=Complete&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else{
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxUserTasksSummaryLinksProcess.jsp?fromPage=Complete&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;emxTableRowId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }
						 sTaskLink  = "<a href=\"" + sTaskLink + "\">" + "<img src=\"" + "../common/images/buttonDialogDone.gif" + "\" width=\"16px\" height=\"16px\"/>" + "</a>";
						 slLinks.add(sTaskLink); 
						 
					 }
					 
				 }
				 
				 
			 }
			 
	         
	    }
		return slLinks;
	}
	
	public MapList getApprovalHistory(Context context, String[] args) throws Exception
    {
  
       // MapList mlReturnList = new MapList();
	   MapList mlData = new MapList();
	   MapList mlDataFinal = new MapList();
        try
        {
        	
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sObjectId = (String) programMap.get("objectId");
			// Added for Activity Page Changes
			DomainObject domObject = DomainObject.newInstance(context,sObjectId);
			
			
			 Map programMap1 = new HashMap(2);
		if(!domObject.isKindOf(context,"Inbox Task")){// Added for changes in Activity page

        	programMap1.put("objectId", sObjectId);
		}
		else{
				String idOfFundRequest = (String) domObject.getInfo(context,"from[Route Task].to.to[Object Route].from.id");
				programMap1.put("objectId", idOfFundRequest);

		}
		//System.out.println("OBJECT ID INSIDE JPO=========="+sObjectId);
			programMap1.put("languageStr", "en-US");
        	//System.out.println("programMap----------"+programMap);
        	
        	mlData = (MapList)JPO.invoke(context, "emxLifecycle", null, "getAllTaskSignaturesOnObject",JPO.packArgs(programMap1), MapList.class);
        	//System.out.println("The Commenets -------->"+mlData);
        	
        	int iSize = mlData.size();
        	Map mTemp;
        	
        	
        	StringList slPersonDetails = new StringList(4);
        	slPersonDetails.addElement("attribute[First Name]");
        	slPersonDetails.addElement("attribute[Last Name]");
        	slPersonDetails.addElement("attribute[HostPersonRole]");
        	slPersonDetails.addElement("to[Employee].from.name");
        	
        	for (int i = 0 ; i < iSize ; i++)
        	{
        		//JsonObjectBuilder jsonObj = Json.createObjectBuilder();
        		mTemp = (Map)mlData.get(i);
        		
        		if ("emptyRow".equals((String)mTemp.get("infoType")))
        			continue;
        		
        		//completion date
        		if (!"".equals((String)mTemp.get("completionDate")) && (String)mTemp.get("completionDate") != null)
        			mTemp.put("completionDateFormatted", changeDateFormat((String)mTemp.get("completionDate")));
        		else
        			mTemp.put("completionDateFormatted", "");
			DomainObject doPerson = DomainObject.newInstance(context,(String)mTemp.get("assigneeId"));
        		String strUserName = doPerson.getInfo(context,"name");
        		//approval status
//Add code changes for Approval History DG comments changes:-START
			if ("Approve".equals((String)mTemp.get("approvalStatus")) &&  (strUserName.equals("dg") || strUserName.equals("41147R")) || strUserName.equals("so1budget") || strUserName.equals("41493A"))
        			mTemp.put("approvalStatusFormatted", "Approved By");
			else if ("Approve".equals((String)mTemp.get("approvalStatus")) && domObject.isKindOf(context,"WMSDelegation") && (strUserName.equals("51108B") || strUserName.equals("41320H") || strUserName.equals("IC49626F")))
        			mTemp.put("approvalStatusFormatted", "Recommended By");
			else if ("Approve".equals((String)mTemp.get("approvalStatus")) && !domObject.isKindOf(context,"WMSDelegation") && (strUserName.equals("51108B") || strUserName.equals("41320H") || strUserName.equals("IC49626F")))
        			mTemp.put("approvalStatusFormatted", "Approved By");
        		else if ("Approve".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Recommended By");
        		else if ("None".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Pending With");
        		else if ("Reject".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Rejected By");
        		else if ("Abstain".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Abstained By");
        		else if ("Ignore".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Ignored By");
        		else if ("Upcoming".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Upcoming Forwarder");
        		
        		//person details
        		
        		Map hmPersonDetails = (Map) doPerson.getInfo(context, slPersonDetails);
        		mTemp.put("assigneeName", (String)hmPersonDetails.get("attribute[First Name]") + " " + (String)hmPersonDetails.get("attribute[Last Name]"));
        		mTemp.put("assigneeRole", (String)hmPersonDetails.get("attribute[HostPersonRole]"));
        		mTemp.put("assigneeOrg", (String)hmPersonDetails.get("to[Employee].from.name"));
        		 //System.out.println("mTemp ------->"+mTemp);
				 	mlDataFinal.add(mTemp);
        	}
			
		
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return mlDataFinal;
    }
	private String changeDateFormat(String strDate) throws Exception
    {    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat ("MM/dd/yyyy");
    	Date date = dateFormat.parse(strDate);	
    	return new SimpleDateFormat("dd-MMM-yyyy").format(date);
    }
	
	   public Vector getApprovalHistoryComment(Context context, String[] args) throws Exception 
    {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
			Map mTemp = null;
			String strTaskId = DomainConstants.EMPTY_STRING;
			DomainObject doTask = null;
			for(int i=0; i<intSize;i++){
				mTemp = (Map)objectList.get(i);
				strTaskId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
					doTask = new DomainObject(strTaskId);
					
					StringList slContectList = (StringList)doTask.getInfoList(context,"from[Route Task].to.to[Object Route].from.id");
					
					StringBuilder strUrl = new StringBuilder();
					for(int j=0;j<slContectList.size();j++){
						String strContectId = (String)slContectList.get(j);
						doTask = new DomainObject(strContectId);
						String strName = "View";					
						String strLink = "../wms/ApprovalHististory.jsp?objectId="+strContectId;
						strUrl.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");            
						strUrl.append(strName);
						strUrl.append("</a>");
						strUrl.append("<br/>");
					}
					vColumnValues.add(strUrl.toString());
				}else{
					vColumnValues.add(DomainConstants.EMPTY_STRING);
				}
					
			}
			
		 return vColumnValues;
		}catch (Exception e) {
            throw e;
        }
           
        }
		//SGS : addded method to retrive Project details on IPBMS tab : 22/05/2021
	public Vector getProject(Context context, String[] args) throws Exception 
    {
		boolean bIsContentPushed = false;
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
        int intSize = objectList.size();
        Vector vColumnValues = new Vector(intSize);
        try {
			StringList slObj = new StringList(20);
			slObj.add("type");
			slObj.add("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.id");
			slObj.add("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.name");
            slObj.add("to[WMSWOMBE].from.to[WMSProjectWorkOrder].from.id");
            slObj.add("to[WMSWOMBE].from.to[WMSProjectWorkOrder].from.name");
            slObj.add("to[WMSSOCRICMaster].from.to[WMSProjectSOC].from.id");
            slObj.add("to[WMSSOCRICMaster].from.to[WMSProjectSOC].from.name");
            slObj.add("to[WMSWOFundRequest].from.to[WMSProjectWorkOrder].from.id");
            slObj.add("to[WMSWOFundRequest].from.to[WMSProjectWorkOrder].from.name");
            slObj.add("to[WMSSOCAEMaster].from.to[WMSProjectSOC].from.id");
            slObj.add("to[WMSSOCAEMaster].from.to[WMSProjectSOC].from.name");
            slObj.add("to[WMSSOCAdminApproval].from.to[WMSProjectSOC].from.id");
            slObj.add("to[WMSSOCAdminApproval].from.to[WMSProjectSOC].from.name");
            slObj.add("to[WMSSOCDelegation].from.to[WMSProjectSOC].from.id");
            slObj.add("to[WMSSOCDelegation].from.to[WMSProjectSOC].from.name");
            slObj.add("to[WMSSOCDCSMaster].from.to[WMSProjectSOC].from.id");
            slObj.add("to[WMSSOCDCSMaster].from.to[WMSProjectSOC].from.name");
            slObj.add("to[WMSSOCTS].from.to[WMSProjectSOC].from.id");
            slObj.add("to[WMSSOCTS].from.to[WMSProjectSOC].from.name");
	  
			String strId = DomainConstants.EMPTY_STRING;
			String strType = DomainConstants.EMPTY_STRING;
			String strProjName = DomainConstants.EMPTY_STRING;
			String strProjId = DomainConstants.EMPTY_STRING;
			
			
			for(int i=0; i<intSize;i++){
				Map mTemp = (Map)objectList.get(i);
				strId = (String)mTemp.get("from[Route Task].to.to[Object Route].from.id");
				
				if(UIUtil.isNotNullAndNotEmpty(strId)){
					DomainObject doObj = new DomainObject(strId);
					
					ContextUtil.pushContext(context);
					bIsContentPushed = true;
					
					Map mProject = doObj.getInfo(context,slObj);
					strType = (String)mProject.get("type");
					
					if ("WMSAbstractMeasurementBookEntry".equals(strType))
					{
						strProjId = (String)mProject.get("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.id");
						strProjName = (String)mProject.get("to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.name");
					}
					else if ("WMSMeasurementBookEntry".equals(strType))
					{
						strProjId = (String)mProject.get("to[WMSWOMBE].from.to[WMSProjectWorkOrder].from.id");
						strProjName = (String)mProject.get("to[WMSWOMBE].from.to[WMSProjectWorkOrder].from.name");
					}
					else if ("WMSFundRequest".equals(strType))
					{
						strProjId = (String)mProject.get("to[WMSWOFundRequest].from.to[WMSProjectWorkOrder].from.id");
						strProjName = (String)mProject.get("to[WMSWOFundRequest].from.to[WMSProjectWorkOrder].from.name");
					}
					else if ("WMSRICMaster".equals(strType))
					{
						strProjId = (String)mProject.get("to[WMSSOCRICMaster].from.to[WMSProjectSOC].from.id");
						strProjName = (String)mProject.get("to[WMSSOCRICMaster].from.to[WMSProjectSOC].from.name");
					}
					else if ("WMSAEMaster".equals(strType))
					{
						strProjId = (String)mProject.get("to[WMSSOCAEMaster].from.to[WMSProjectSOC].from.id");
						strProjName = (String)mProject.get("to[WMSSOCAEMaster].from.to[WMSProjectSOC].from.name");
					}
					else if ("WMSAdminApproval".equals(strType))
					{
						strProjId = (String)mProject.get("to[WMSSOCAdminApproval].from.to[WMSProjectSOC].from.id");
						strProjName = (String)mProject.get("to[WMSSOCAdminApproval].from.to[WMSProjectSOC].from.name");
					}
					else if ("WMSDelegation".equals(strType))
					{
						strProjId = (String)mProject.get("to[WMSSOCDelegation].from.to[WMSProjectSOC].from.id");
						strProjName = (String)mProject.get("to[WMSSOCDelegation].from.to[WMSProjectSOC].from.name");
					}
					else if ("WMSDCSMaster".equals(strType))
					{
						strProjId = (String)mProject.get("to[WMSSOCDCSMaster].from.to[WMSProjectSOC].from.id");
						strProjName = (String)mProject.get("to[WMSSOCDCSMaster].from.to[WMSProjectSOC].from.name");
					}
					else if ("WMSTechnicalSanction".equals(strType))
					{
						strProjId = (String)mProject.get("to[WMSSOCTS].from.to[WMSProjectSOC].from.id");
						strProjName = (String)mProject.get("to[WMSSOCTS].from.to[WMSProjectSOC].from.name");
					}
					
					StringBuilder strUrl = new StringBuilder();
					if(UIUtil.isNotNullAndNotEmpty(strProjId)){
						String strLink = "../common/emxTree.jsp?objectId="+strProjId;
						strUrl.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");            
						//strUrl.append(strProjName);
						 strUrl.append(strProjName.replace(" & ","&amp;"));
						strUrl.append("</a>");
						vColumnValues.add(strUrl.toString());
					}
					else {
						vColumnValues.add(DomainConstants.EMPTY_STRING);
					}
				}else{
					vColumnValues.add(DomainConstants.EMPTY_STRING);
				}
			}
			
		}catch (Exception e) {
            throw e;
        }
		finally{
			if(bIsContentPushed)
				ContextUtil.popContext(context);
		}
		return vColumnValues;
    }
	
	public Vector getRouteSenderName(Context context, String[] args) throws Exception 
    {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
			Map mTemp = null;
			String strTaskId = DomainConstants.EMPTY_STRING;
			DomainObject doTask = null;
			for(int i=0; i<intSize;i++){
				mTemp = (Map)objectList.get(i);
				strTaskId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
					doTask = new DomainObject(strTaskId);
					
					StringList slContectList = (StringList)doTask.getInfoList(context,"from[Route Task].to.id");
					
					StringBuilder strUrl = new StringBuilder();
					for(int j=0;j<slContectList.size();j++){
						String strContectId = (String)slContectList.get(j);
						doTask = new DomainObject(strContectId);
						String strOwner = doTask.getInfo(context,"owner");	
						String strOwnerID = PersonUtil.getPersonObjectID(context, strOwner);
						DomainObject dom=DomainObject.newInstance(context,strOwnerID);
						String strOwnerFullName =dom.getInfo(context, "attribute[WMSPersonDesignation].value");
						String strLink = "../common/emxTree.jsp?objectId="+strOwnerID;
						strUrl.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");            
						//strUrl.append(strOwnerFullName);
						strUrl.append(strOwnerFullName.replace("&","&amp;"));
						strUrl.append("</a>");
						strUrl.append("<br/>");
					}
					vColumnValues.add(strUrl.toString());
				}else{
					vColumnValues.add(DomainConstants.EMPTY_STRING);
				}
					
			}
			
		 return vColumnValues;
		}catch (Exception e) {
            throw e;
        }
           
        }
        
}

