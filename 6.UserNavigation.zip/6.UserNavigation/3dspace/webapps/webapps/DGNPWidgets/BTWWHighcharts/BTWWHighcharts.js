define("BTWWHighcharts/BTWWHighcharts", ["BTWWLibrairies/highcharts/highcharts"], function() {
    return Highcharts;
});
