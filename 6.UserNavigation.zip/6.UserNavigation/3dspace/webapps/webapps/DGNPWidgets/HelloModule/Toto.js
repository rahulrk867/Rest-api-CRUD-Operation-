define("HelloModule/Toto", [], function () {
    var toto = {
        hello: "Test Module",
        textHello: "Bonjour",
        fctHello: function (name) {
            return "Hello, Dear " + name;
        }
    };
    return toto;
});