/*
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */

function executeWidgetCode() {

    require.config({
        paths: {
            vue: "./BTWWLibrairies/vue/vue", //Need this with "vue" all lower case, else Vuetify can't load correctly
            Vuetify: "./BTWWLibrairies/vuetify/vuetify",
            CSSRoboto: "./BTWWLibrairies/fonts/Roboto", //"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700",
            CSSMaterial: "./BTWWLibrairies/MaterialDesign/material-icons",
            vueloader: "./BTWWLibrairies/requirejs-vue", //"https://unpkg.com/requirejs-vue@1.1.5/requirejs-vue",
            current: "./InfiniteScroll"
        }
    });

    let vueApp; //Declare it here so it can be used in some modules defined here

    require(["vue",
        "Vuetify",
        "css!BTWWLibrairies/vuetify/vuetify.min.css",
        "css!CSSRoboto",
        "css!CSSMaterial",
        "vueloader!current/vue/infinite-scroll",
    ], function(Vue, Vuetify) {

        Vue.use(Vuetify); //To plug vuetify components

        var myWidget = {
            // Widget Events
            onLoadWidget: function() {
                var wdgUrl = widget.getUrl();
                wdgUrl = wdgUrl.substring(0, wdgUrl.lastIndexOf("/"));

                widget.setIcon(wdgUrl + "/../UM5Modules/assets/icons/custom-widget-icon.png");

                var wdgTitlePref = widget.getValue("wdgTitle");
                if (wdgTitlePref) {
                    widget.setTitle(wdgTitlePref);
                }

                widget.setBody(
                    `<div id='appVue'>
                        <v-app style='height:100%;'>
                            <div style='height:3em;'>
                                <v-layout row wrap justify-space-between>
                                    <v-flex shrink>
                                        <v-switch v-model="reverse" color="primary" style="margin-top:0" label="Reverse Mode"></v-switch>
                                    </v-flex>
                                    <v-flex shrink>
                                        <v-btn @click="addAfter">Add Posts After</v-btn>
                                    </v-flex>
                                    <v-flex shrink>
                                        <span>&nbsp;&nbsp;&nbsp;&nbsp;Number of posts : {{posts.length}}</span>
                                    </v-flex>
                                </v-layout>
                            </div>
                            <infinite-scroll :items="posts" :reverse-mode="reverse" style='height:calc(100% - 3em);' @bottom-reached="loadNewPost"></infinite-scroll>
                        </v-app>
                    </div>`
                );

                //Init vue App
                vueApp = new Vue({
                    el: "#appVue",
                    data: {
                        reverse: false,
                        posts: [ //Posts
                            {
                                "id": "123",
                                "title": "Post 123",
                                "textHTML": "This is a post about some stuff<br>We just want to demonstrate the infinite scroll capability of this widget / Vue Component...",
                                "illustration": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Vue.js_Logo_2.svg/1280px-Vue.js_Logo_2.svg.png",
                                "imageSize": (3 * Math.random() + 1) + "em;"
                            },
                            {
                                "id": "456",
                                "title": "Post 456",
                                "textHTML": "This is a post about some stuff<br>We just want to demonstrate the infinite scroll capability of this widget / Vue Component...",
                                "illustration": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Vue.js_Logo_2.svg/1280px-Vue.js_Logo_2.svg.png",
                                "imageSize": (3 * Math.random() + 1) + "em;"
                            },
                            {
                                "id": "789",
                                "title": "Post 789",
                                "textHTML": "This is a post about some stuff<br>We just want to demonstrate the infinite scroll capability of this widget / Vue Component...",
                                "illustration": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Vue.js_Logo_2.svg/1280px-Vue.js_Logo_2.svg.png",
                                "imageSize": (3 * Math.random() + 1) + "em;"
                            },
                            {
                                "id": "147",
                                "title": "Post 147",
                                "textHTML": "This is a post about some stuff<br>We just want to demonstrate the infinite scroll capability of this widget / Vue Component...",
                                "illustration": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Vue.js_Logo_2.svg/1280px-Vue.js_Logo_2.svg.png",
                                "imageSize": (3 * Math.random() + 1) + "em;"
                            },
                            {
                                "id": "258",
                                "title": "Post 258",
                                "textHTML": "This is a post about some stuff<br>We just want to demonstrate the infinite scroll capability of this widget / Vue Component...",
                                "illustration": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Vue.js_Logo_2.svg/1280px-Vue.js_Logo_2.svg.png",
                                "imageSize": (3 * Math.random() + 1) + "em;"
                            },
                            {
                                "id": "369",
                                "title": "Post 369",
                                "textHTML": "This is a post about some stuff<br>We just want to demonstrate the infinite scroll capability of this widget / Vue Component...",
                                "illustration": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Vue.js_Logo_2.svg/1280px-Vue.js_Logo_2.svg.png",
                                "imageSize": (3 * Math.random() + 1) + "em;"
                            }
                        ],
                        loadPending: false
                    },
                    computed: {

                    },
                    methods: {
                        loadNewPost() {
                            if (!this.loadPending) {
                                this.loadPending = true;
                                let time = 1500 * Math.random() + 500;
                                console.log("Will wait " + time);
                                setTimeout(() => {
                                    this.addAfter();
                                    this.loadPending = false;
                                }, time);
                            }
                        },
                        addBefore() {
                            let ts = Date.now();
                            this.posts.splice(0, 0, this.getRandomPost());
                            this.posts.splice(0, 0, this.getRandomPost());
                            console.log("2 new posts Added Before making it " + this.posts.length + " posts- " + ts);
                        },
                        addAfter() {
                            let ts = Date.now();
                            this.posts.push(this.getRandomPost());
                            this.posts.push(this.getRandomPost());
                            console.log("2 new posts loaded making it " + this.posts.length + " posts- " + ts);
                        },
                        getRandomPost() {
                            let rand = parseInt(10000 * Math.random());
                            return {
                                "id": rand + "-1",
                                "title": "Post -" + rand,
                                "textHTML": "This is a post about some stuff<br>We just want to demonstrate the infinite scroll capability of this widget / Vue Component...",
                                "illustration": "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Vue.js_Logo_2.svg/1280px-Vue.js_Logo_2.svg.png",
                                "imageSize": (5 * Math.random() + 0.5) + "em;"
                            };
                        }
                    }
                });
            }
        };

        widget.addEvent("onLoad", myWidget.onLoadWidget);
        //widget.addEvent("onRefresh", myWidget.onLoadWidget);
        //widget.addEvent("onSearch", myWidget.onSearchWidget);
        //widget.addEvent("onResetSearch", myWidget.onResetSearchWidget);

        //widget.addEvent("onConfigChange", myWidget.onConfigChange); //For change of Table Config in list
    });
}