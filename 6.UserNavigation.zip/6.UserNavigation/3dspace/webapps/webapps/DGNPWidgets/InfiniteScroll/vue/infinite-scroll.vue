<template>
    <div class="infiniteScrollView" @wheel.prevent="scrollWheel" @mousemove="moveScroll" @mouseup="movingScroll=false;" @mouseleave="movingScroll=false;">
        <template v-for="(item,i) in itemsDisplayed">
            <div
                v-if="(item.pos+item.height)>=0 && item.pos < height && item.loader"
                :key="'item-'+i"
                :data-index="i"
                class="infScrollItem"
                :style="(reverseMode?'bottom:':'top:')+item.pos+'px;text-align:center;'"
            >
                <v-progress-circular indeterminate color="primary"></v-progress-circular>Loading...
            </div>
            <div
                v-else-if="(item.pos+item.height)>=0 && item.pos < height"
                :key="'item-'+i"
                :data-index="i"
                class="infScrollItem"
                :style="(reverseMode?'bottom:':'top:')+item.pos+'px;'"
            >
                <div class="titleBlock">{{ item.data.title }}</div>
                <div class="imgBlock" :style="'height:'+item.data.imageSize">
                    <img :src="item.data.illustration">
                </div>
                <div v-html="item.data.textHTML"></div>
            </div>
        </template>
        <div class="scrollbar">
            <div
                class="scrollIndex"
                :style="(reverseMode?'bottom:'+scrollIndexInfos.top+'%;height:'+scrollIndexInfos.height+'%;':'top:'+scrollIndexInfos.top+'%;height:'+scrollIndexInfos.height+'%;')"
                @mousedown="activateMoveScroll"
            ></div>
            <div v-if="reverseMode" class="scrollToFirst top" title="Scroll back to First Item" @click="scrollToFirst">
                <v-icon>arrow_downward</v-icon>
            </div>
            <div v-else class="scrollToFirst bottom" title="Scroll back to First Item" @click="scrollToFirst">
                <v-icon>arrow_upward</v-icon>
            </div>
        </div>
    </div>
</template>

<style scoped>
.infiniteScrollView {
    height: 100%;
    overflow: hidden;
    position: relative;
    background-color: #fafafa;
}

.infScrollItem {
    position: absolute;
    background-color: white;
    box-shadow: 0.1em 0.1em 0.5em lightgrey;
    margin: 0 1em;
    width: calc(100% - 2em);
}

.titleBlock {
    font-size: 1.5em;
}

.imgBlock {
    height: 5em;
    text-align: center;
    overflow: hidden;
}

.imgBlock > img {
    max-height: 100%;
    max-width: 100%;
}

.scrollbar {
    position: absolute;
    right: 0px;
    width: 8px;
    height: 100%;
    background: rgba(200, 200, 200, 0.5);
}

.scrollIndex {
    position: absolute;
    min-height: 12px;
    width: 100%;
    border-radius: 4px;
    background-color: grey;
}

.scrollToFirst {
    position: absolute;
    width: 1.5em;
    height: 1.5em;
    right: 10px;
    background: rgba(200, 200, 200, 0.5);
    border-radius: 50%;
    cursor: pointer;
}
.top {
    top: 0px;
}
.bottom {
    bottom: 0px;
}
</style>

<script>
/* global template */
define(["vue"], function(Vue) {
    return Vue.component("infinite-scroll", {
        template: template,
        props: {
            items: { type: Array, required: true },
            reverseMode: { type: Boolean, default: false }
        },
        data: function() {
            return {
                width: 100,
                height: 100,
                offsetSize: 12,
                itemsMargin: 24,
                itemsDisplayed: [],
                movingScroll: false,
                scrollMove: {
                    y: 0
                }
            };
        },
        mounted: function() {
            window.addEventListener("resize", () => {
                this.resize();
            }); //Listen at the frame level for a resize
            this.itemsDisplayed = this.items.map((item, i) => {
                return { data: item, index: i, pos: 1, height: 10 };
            });
            this.itemsDisplayed.push({ loader: true, index: this.itemsDisplayed.length, pos: null, height: 10 });
            this.resize();
        },
        updated: function() {
            this.recalculateBlocksHeights(0);
        },

        computed: {
            mapIdToItem: function() {
                return this.itemsDisplayed.reduce((map, item) => {
                    if (item.data) {
                        map[item.data.id] = item;
                    }
                    return map;
                }, {});
            },
            scrollIndexInfos: function() {
                let mapInfos = this.itemsDisplayed.reduce(
                    (mapInfo, item, i) => {
                        mapInfo.fullHeight += item.height || 10;
                        mapInfo.fullHeight += this.itemsMargin;

                        return mapInfo;
                    },
                    { fullHeight: 0 }
                );

                let heightIndex = (this.height / mapInfos.fullHeight) * 100;
                let topIndex = 0;
                if (this.itemsDisplayed[0]) {
                    topIndex = ((-1 * (this.itemsDisplayed[0].pos - this.itemsMargin)) / mapInfos.fullHeight) * 100;
                }

                return { top: topIndex, height: heightIndex, fullHeight: mapInfos.fullHeight };
            }
        },

        watch: {
            items: {
                deep: true,
                handler() {
                    this.itemsDisplayed = this.items.map((item, i) => {
                        let currentItem = this.mapIdToItem[item.id];
                        return {
                            data: item,
                            index: i,
                            pos: currentItem && currentItem.pos ? currentItem.pos : null,
                            height: (currentItem && currentItem.height) || 10
                        };
                    });
                    this.itemsDisplayed.push({ loader: true, index: this.itemsDisplayed.length, pos: null, height: 10 });
                }
            }
        },

        methods: {
            resize() {
                let elBoundingBox = this.$el.getBoundingClientRect();
                this.width = elBoundingBox.width;
                this.height = elBoundingBox.height;
                this.recalculateBlocksHeights();
            },

            recalculateBlocksHeights() {
                let arrBlocks = this.$el.getElementsByClassName("infScrollItem");
                for (let i = 0; i < arrBlocks.length; i++) {
                    const elementBlock = arrBlocks[i];
                    const elBB = elementBlock.getBoundingClientRect();
                    const dataIndex = elementBlock.getAttribute("data-index");
                    this.itemsDisplayed[dataIndex].height = elBB.height;
                }
                this.repositionBlocks(0);
            },

            repositionBlocks(offset) {
                let refPosition = -1;
                let totalHeight = 0;
                for (let i = 0; i < this.itemsDisplayed.length; i++) {
                    const item = this.itemsDisplayed[i];
                    //Item in view
                    if (refPosition <= -1 && item.pos) {
                        refPosition = item.pos + offset;
                    }
                    item.pos = refPosition;

                    refPosition += item.height;
                    refPosition += this.itemsMargin;
                    totalHeight += item.height;
                }
                if (refPosition - this.itemsMargin < this.height) {
                    //We reached the bottom
                    this.$emit("bottom-reached");
                }
                if (this.itemsDisplayed[0] && this.itemsDisplayed[0].pos > this.itemsMargin) {
                    this.itemsDisplayed[0].pos = this.itemsMargin;
                    this.repositionBlocks(0);
                } else if (totalHeight > this.height) {
                    let lastItem = this.itemsDisplayed[this.itemsDisplayed.length - 1];
                    if (lastItem && lastItem.pos && lastItem.pos !== -1 && lastItem.height && lastItem.pos + lastItem.height + this.itemsMargin < this.height) {
                        let offset = this.height - (lastItem.pos + lastItem.height + this.itemsMargin);
                        this.repositionBlocks(offset);
                    }
                }
            },

            scrollWheel(ev) {
                var scrollY = ev.deltaY;
                if (scrollY > 0) {
                    //Scroll Down
                    this.moveAllBy((this.reverseMode ? 1 : -1) * scrollY);
                } else {
                    //Scroll Up
                    this.moveAllBy((this.reverseMode ? 1 : -1) * scrollY);
                }
            },
            moveAllBy(multiplier) {
                this.repositionBlocks(multiplier * this.offsetSize);
            },

            scrollToFirst() {
                this.itemsDisplayed[0].pos = this.itemsMargin;
                this.repositionBlocks(0);
            },

            activateMoveScroll(ev) {
                this.movingScroll = true;
                this.scrollMove.y = ev.pageY;
            },
            moveScroll(ev) {
                if (this.movingScroll) {
                    ev.stopPropagation();
                    let yNow = ev.pageY;
                    let deltaY = this.scrollMove.y - yNow;
                    if (this.reverseMode) {
                        deltaY *= -1;
                    }

                    let scrollInfos = this.scrollIndexInfos;

                    let scrollMultiplier = scrollInfos.fullHeight / this.height;

                    this.repositionBlocks(scrollMultiplier * deltaY);
                    this.scrollMove.y = yNow;
                }
            }
        }
    });
});
</script>