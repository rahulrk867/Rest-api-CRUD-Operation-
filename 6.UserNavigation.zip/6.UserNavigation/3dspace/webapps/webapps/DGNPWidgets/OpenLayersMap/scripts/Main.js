/*
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */
/* global EXIF */
function executeWidgetCode() {
    require.config({
        paths: {
            vue: "./BTWWLibrairies/vue/vue", //Need this with "vue" all lower case, else Vuetify can't load correctly
            Vuetify: "./BTWWLibrairies/vuetify/vuetify",
            CSSRoboto: "./BTWWLibrairies/fonts/Roboto", //"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700",
            CSSMaterial: "./BTWWLibrairies/MaterialDesign/material-icons",
            vueloader: "./BTWWLibrairies/requirejs-vue", //"https://unpkg.com/requirejs-vue@1.1.5/requirejs-vue",
            current: "./OpenLayersMap",
            OpenLayers: "./BTWWLibrairies/OpenLayers_v5.3.0-dist/ol"
        }
    });

    let vueApp; //Declare it here so it can be used in some modules defined here

    require([
        "vue",
        "Vuetify",
        "OpenLayers", //JS File
        "UM5Modules/Connector3DExp",
        "DS/PlatformAPI/PlatformAPI",
        "css!BTWWLibrairies/vuetify/vuetify.min.css",
        "css!CSSRoboto",
        "css!CSSMaterial",
        "BTWWLibrairies/exifJS/exif",
        "vueloader!current/vue/drop-zone"
    ], function(Vue, Vuetify, ol, Connector3DExp, PlatformAPI) {
        Vue.use(Vuetify); //To plug vuetify components

        var myWidget = {
            // Widget Events
            onLoadWidget: function() {
                var wdgUrl = widget.getUrl();
                wdgUrl = wdgUrl.substring(0, wdgUrl.lastIndexOf("/"));

                widget.setIcon(wdgUrl + "/../UM5Modules/assets/icons/custom-widget-icon.png");

                var wdgTitlePref = widget.getValue("wdgTitle");
                if (wdgTitlePref) {
                    widget.setTitle(wdgTitlePref);
                }

                widget.setBody(
                    `<div id='appVue'>
                        <v-app style='height:100%;'>
                            <drop-zone style='height:100%;position:relative;' @drop-on="dropOnMap">
                                <div id="mapId" :style="'height:100%;width:100%;'"></div>
                                <div id="screenshotTool" style="position:absolute;right:0em;top:0em;z-index:10;">
                                    <v-btn @click="screenshot" icon small dark style="background-color:white;"><v-icon style="color:lightgrey;">camera_alt</v-icon></v-btn>
                                </div>
                                <div id="creditsOSM">© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors - OpenLayers 5.3.0</div>
                            </drop-zone>
                            <div v-if="fullScreenImage!==-1" class="fsOverlay" @click="showImage(-1);">
                                <img :src="images[fullScreenImage].src" :class="'orientation'+images[fullScreenImage].display.orientation">
                            </div>
                        </v-app>
                    </div>`
                );

                //Map Export : https://openlayers.org/en/latest/examples/export-map.html
                //Add Image based on point style function : https://openlayers.org/en/latest/examples/feature-move-animation.html

                //Init vue App
                vueApp = new Vue({
                    el: "#appVue",
                    data: {
                        map: null,

                        images: [],

                        fullScreenImage: -1
                    },
                    mounted: function() {
                        window.addEventListener("resize", this.resize); //Listen at the frame level for a resize
                        this.resize();

                        //https://openlayers.org/en/latest/apidoc/module-ol_Map-Map.html
                        this.map = new ol.Map({
                            target: "mapId",
                            layers: [
                                new ol.layer.Tile({
                                    source: new ol.source.OSM()
                                }),
                                new ol.layer.Vector({
                                    source: new ol.source.Vector({
                                        features: []
                                    })
                                })
                            ],
                            view: new ol.View({
                                center: ol.proj.fromLonLat([2.211087, 48.786443]), //DS HQ Vélizy
                                zoom: 16
                            })
                        });

                        this.map.addEventListener("click", (mapEvent) => {
                            let pixel = mapEvent.pixel;
                            let arrFeatures = this.map.getFeaturesAtPixel(pixel); //See : https://openlayers.org/en/latest/apidoc/module-ol_Map-Map.html
                            if (arrFeatures) {
                                let imageIndex = -1;
                                for (let i = 0; i < arrFeatures.length && imageIndex === -1; i++) {
                                    const feature = arrFeatures[i];
                                    imageIndex = feature.get("imageIndex");
                                }
                                if (imageIndex !== -1) {
                                    this.showImage(imageIndex);
                                }
                            }
                        });
                    },
                    computed: {},
                    watch: {
                        images: {
                            deep: true,
                            handler: function() {
                                if (this.images.length > 0) {
                                    let imageIndex = this.images.length - 1;
                                    let lastImage = this.images[imageIndex];

                                    let gpsPoint = lastImage.gpsPoint;
                                    if (gpsPoint) {
                                        let layers = this.map.getLayers();
                                        let layer = layers.item(1); //Second layer with the points
                                        let source = layer.getSource();
                                        let pointFeature = new ol.Feature({
                                            geometry: new ol.geom.Point(ol.proj.fromLonLat([gpsPoint.longitude, gpsPoint.latitude])),
                                            imageIndex: imageIndex
                                        });
                                        pointFeature.setStyle(
                                            new ol.style.Style({
                                                image: new ol.style.Circle({
                                                    radius: 7,
                                                    fill: new ol.style.Fill({
                                                        color: "red"
                                                    }),
                                                    stroke: new ol.style.Stroke({
                                                        color: "white",
                                                        width: 2
                                                    })
                                                })
                                            })
                                        );
                                        source.addFeature(pointFeature);

                                        //Add the image
                                        let imgWidth = lastImage.display.x,
                                            imgHeight = lastImage.display.y;
                                        let imgScale = 100 / imgWidth;
                                        let imgRotate = 0; //In radians
                                        /*
                                         * EXIF Orientation :
                                         * - 1 : Normal
                                         * 2 : Horizontal Flip
                                         * - 3 : 180° rotate
                                         * 4 : Vertical Flip
                                         * 5 : Vertical Flip + 90° rotate right
                                         * - 6 : 90° rotate right
                                         * 7 : Horizontal Flip + 90° rotate right
                                         * - 8 : 90° rotate left
                                         */
                                        if (lastImage.display.orientation === 3) {
                                            imgRotate = Math.PI;
                                        } else if (lastImage.display.orientation === 5 || lastImage.display.orientation === 6 || lastImage.display.orientation === 7) {
                                            imgRotate = Math.PI / 2;
                                        } else if (lastImage.display.orientation === 8) {
                                            imgRotate = -1 * Math.PI / 2;
                                        }

                                        let imageFeature = new ol.Feature({
                                            geometry: new ol.geom.Point(ol.proj.fromLonLat([gpsPoint.longitude, gpsPoint.latitude])),
                                            imageIndex: imageIndex
                                        });
                                        imageFeature.setStyle(
                                            new ol.style.Style({
                                                image: new ol.style.Icon({
                                                    anchor: [0.5, 1],
                                                    src: lastImage.src,
                                                    size: [imgWidth, imgHeight],
                                                    scale: imgScale,
                                                    rotation: imgRotate
                                                })
                                            })
                                        );
                                        source.addFeature(imageFeature);

                                        let view = this.map.getView();
                                        //view.setCenter(ol.proj.fromLonLat([gpsPoint.longitude, gpsPoint.latitude]));
                                        view.animate({
                                            zoom: 10
                                        }, {
                                            center: ol.proj.fromLonLat([gpsPoint.longitude, gpsPoint.latitude])
                                        }, {
                                            zoom: 16
                                        });
                                    }
                                }
                            }
                        }
                    },
                    methods: {
                        resize() {
                            if (this.map) {
                                this.map.updateSize();
                            }
                        },
                        dropOnMap(ev) {
                            let preTypesOfInfos = ev.dataTransfer.types;
                            //MS Edge bug with DOMStringList instead of Array, so quick cast here
                            let typesOfInfos = [];
                            for (let i = 0; i < preTypesOfInfos.length; i++) {
                                const element = preTypesOfInfos[i];
                                typesOfInfos.push(element);
                            }

                            //console.log("manageDrop typesOfInfos = ", typesOfInfos);

                            if (typesOfInfos.indexOf("Files") !== -1) {
                                //Check if there is some images
                                let fileList = ev.dataTransfer.files;
                                for (let i = 0; i < fileList.length; i++) {
                                    const file = fileList[i];
                                    const fType = file.type;

                                    console.debug("mime type :", fType);

                                    if (fType.indexOf("image/") === 0) {
                                        this.readImageFile(file);
                                    } //Else for the files, ignore them, only manage images
                                }
                            } else if (typesOfInfos.indexOf("text/plain") !== -1) {
                                let dataTxt = ev.dataTransfer.getData("text/plain");
                                //console.log("manageDrop dataTxt = ", dataTxt);
                                //Try to see if it's a Platform object:
                                try {
                                    let dataJson = JSON.parse(dataTxt);
                                    if (dataJson.protocol === "3DXContent") {
                                        //It's a Platform Object !
                                        this.get3DXContent(dataJson);
                                    }
                                } catch (err) {
                                    //Do nothing try the other drop types
                                }
                            }
                            //console.log("manageDrop done !");
                        },

                        get3DXContent: function(dataJson) {
                            let itemsList = dataJson.data.items;
                            for (let i = 0; i < itemsList.length; i++) {
                                const item = itemsList[i];
                                let serviceId = item.serviceId;
                                let envId = item.envId;

                                if (serviceId === "3DDrive") {
                                    //Download the file image
                                    //content.data.displayPreview
                                    this.load3DDriveFile(envId, item);

                                } //Else ignore other types of 3DXContent for the moment (focus on 3DDrive files for the scenario), add them later on...
                            }
                        },

                        load3DDriveFile: function(envId, dataObj) {
                            let that = this;
                            Connector3DExp.get3DDriveFileUrl({
                                envId: envId,
                                fileId: dataObj.objectId,
                                onComplete: (fileURL) => {
                                    //Download the file now and save it in memory for upload to 3DSwym

                                    let req = new XMLHttpRequest();
                                    req.open("GET", fileURL, true);
                                    req.responseType = "blob";

                                    req.onload = function(e) {

                                        if (this.status === 200) {

                                            //We have the file in the response
                                            let fileBlob = new Blob([req.response], {
                                                type: req.getResponseHeader("Content-Type")
                                            });

                                            that.readImageFile(fileBlob);

                                        } else {
                                            console.error("Error will getting the file from 3DDrive", e);
                                        }
                                    };

                                    req.send(); //Send the XHR
                                },
                                onFailure: (errorType, errorMsg) => {
                                    console.error(errorType, errorMsg);
                                }
                            });
                        },

                        readImageFile: function(fileImg) {
                            let objImg = {
                                gpsPoint: {
                                    latitude: 0,
                                    longitude: 0
                                },
                                src: "./notLoaded.png",
                                show: false,
                                display: {
                                    orientation: 1,
                                    x: 100,
                                    y: 100
                                }
                            };
                            //Read the Image for display
                            let fileReader = new FileReader();
                            fileReader.onload = ev => {
                                objImg.src = ev.target.result;

                                EXIF.getData(fileImg, () => {
                                    //console.log("file", fileImg);
                                    let allMetaData = EXIF.getAllTags(fileImg);
                                    //console.log("allMetaData", allMetaData);
                                    let gpsLatArr = allMetaData["GPSLatitude"] || [0, 0, 0];
                                    let gpsLat = gpsLatArr[0] + (gpsLatArr[1] || 0) / 60 + (gpsLatArr[2] || 0) / 3600;
                                    let gpsLatRef = allMetaData["GPSLatitudeRef"] || "N";
                                    if (gpsLatRef === "S") {
                                        gpsLat *= -1;
                                    }
                                    let gpsLongArr = allMetaData["GPSLongitude"] || [0, 0, 0];
                                    let gpsLong = gpsLongArr[0] + (gpsLongArr[1] || 0) / 60 + (gpsLongArr[2] || 0) / 3600;
                                    let gpsLongRef = allMetaData["GPSLongitudeRef"] || "E";
                                    if (gpsLongRef === "W") {
                                        gpsLong *= -1;
                                    }
                                    objImg.gpsPoint = {
                                        latitude: gpsLat,
                                        longitude: gpsLong
                                    };

                                    objImg.display.orientation = allMetaData["Orientation"] || 1;
                                    objImg.display.x = allMetaData["PixelXDimension"] || 100;
                                    objImg.display.y = allMetaData["PixelYDimension"] || 100;

                                    this.images.push(objImg);
                                    /*PlatformAPI.publish("NewTrackedItem", {
                                        type: "PhotoOnMap",
                                        gps: objImg.gpsPoint,
                                        src: objImg.src
                                    });*/
                                });
                            };
                            fileReader.readAsDataURL(fileImg);
                        },

                        showImage(imageIndex) {
                            this.fullScreenImage = imageIndex;
                        },

                        screenshot() {
                            this.map.once("rendercomplete", (event) => {
                                let canvas = event.context.canvas;
                                let imgData = canvas.toDataURL();
                                PlatformAPI.publish("NewTrackedItem", {
                                    type: "PhotoOnMap",
                                    src: imgData
                                });
                            });
                            this.map.renderSync();
                        }
                    }
                });
            }
        };

        widget.addEvent("onLoad", myWidget.onLoadWidget);
        //widget.addEvent("onRefresh", myWidget.onLoadWidget);
        //widget.addEvent("onSearch", myWidget.onSearchWidget);
        //widget.addEvent("onResetSearch", myWidget.onResetSearchWidget);

        //widget.addEvent("onConfigChange", myWidget.onConfigChange); //For change of Table Config in list
    });
}