<template>
    <div></div>
</template>

<style scoped>
</style>

<script>
/* global template */
define(["vue"], function(Vue) {
    return Vue.component("...", {
        template: template,
        props: {},
        data: function() {
            return {};
        },

        computed: {},

        watch: {},

        methods: {}
    });
});
</script>