<template>
    <div
        :class="['dropZone',(dragOver ? 'dragOver' : '')]"
        @dragenter.stop="dragOver=true"
        @dragleave.stop="dragOver=false"
        @dragover.prevent.stop="dragOver=true"
        @drop.prevent.stop="drop($event)"
    >
        <slot>
            <v-icon class="iconDrop">save_alt</v-icon>
            <br>
            {{ displayText }}
        </slot>
    </div>
</template>

<style scoped>
.dropZone {
    box-sizing: border-box;
    text-align: center;
    background-color: #f3f3f3;
}

.dropZone.dragOver {
    opacity: 0.3;
    border: 0.5em solid rgb(0, 153, 255);
}

.v-icon.iconDrop {
    font-size: 5em;
    color: black;
}
</style>

<script>
/* global template */
define(["vue"], function(Vue) {
    return Vue.component("drop-zone", {
        template: template,
        props: {
            displayText: {
                type: String,
                required: false,
                default: "Drop some items here"
            }
        },
        data: function() {
            return {
                dragOver: false
            };
        },
        methods: {
            drop: function(event) {
                this.dragOver = false;
                if (event && event.dataTransfer) {
                    this.$emit("drop-on", event);
                } else {
                    console.warn("Drop not managed, no dataTransfer found");
                }
            }
        }
    });
});
</script>