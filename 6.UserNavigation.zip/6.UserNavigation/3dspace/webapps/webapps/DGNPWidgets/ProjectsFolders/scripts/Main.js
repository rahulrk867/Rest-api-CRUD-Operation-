/*
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */

function executeWidgetCode() {

    require.config({
        paths: {
            vue: "./BTWWLibrairies/vue/vue", //Need this with "vue" all lower case, else Vuetify can't load correctly
            Vuetify: "./BTWWLibrairies/vuetify/vuetify",
            CSSRoboto: "./BTWWLibrairies/fonts/Roboto", //"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700",
            CSSMaterial: "./BTWWLibrairies/MaterialDesign/material-icons",
            vueloader: "./BTWWLibrairies/requirejs-vue", //"https://unpkg.com/requirejs-vue@1.1.5/requirejs-vue",
            current: "./ProjectsFolders"
        }
    });

    let vueApp; //Declare it here so it can be used in some modules defined here

    require(["vue",
        "Vuetify",
        "UM5Modules/ProjectsWS",
        "UM5Modules/DocumentsWSV2",
        "UM5Modules/Connector3DExpV2",
        "css!BTWWLibrairies/vuetify/vuetify.min.css",
        "css!CSSRoboto",
        "css!CSSMaterial",
        "vueloader!current/vue/topbar",
        "vueloader!current/vue/tree-panel",
        "vueloader!current/vue/content-panel",
    ], function(Vue, Vuetify, ProjectsWS, DocumentsWSV2, Connector3DExpV2) {

        Vue.use(Vuetify); //To plug vuetify components

        var myWidget = {
            // Widget Events
            onLoadWidget: function() {
                var wdgUrl = widget.getUrl();
                wdgUrl = wdgUrl.substring(0, wdgUrl.lastIndexOf("/"));

                widget.setIcon(wdgUrl + "/../UM5Modules/assets/icons/custom-widget-icon.png");

                var wdgTitlePref = widget.getValue("wdgTitle");
                if (wdgTitlePref) {
                    widget.setTitle(wdgTitlePref);
                }

                widget.setBody(
                    `<div id='appVue'>
                        <v-app style='height:100%;'>
                            <v-layout column fill-height>
                                <v-flex shrink>
                                    <topbar @toggle-tree="showTree=!showTree"></topbar>
                                </v-flex>
                                <v-flex grow>
                                    <v-layout row fill-height>
                                        <v-flex shrink>
                                            <tree-panel :trees="projectsTrees" :selected-item="selectedItem" :style="'width:'+(showTree ? '200' : '0')+'px;'" @collapse="collapse" @expand="expand"  @select="select"></tree-panel> 
                                        </v-flex>
                                        <v-flex grow>
                                            <content-panel :items="folderContent" @drop-on="dropInContent"></content-panel>
                                        </v-flex>
                                    </v-layout>
                                </v-flex>
                            </v-layout>
                        </v-app>
                    </div>`
                );

                //Init vue App
                vueApp = new Vue({
                    el: "#appVue",
                    data: {
                        projectsTrees: [],
                        folderContent: [],

                        selectedItem: null,

                        showTree: true
                    },
                    computed: {
                        folderPath() {
                            return [];
                        }
                    },
                    methods: {
                        retrieveItemFromPath(path) {
                            let currentItems = this.projectsTrees;
                            let resultItem = null;
                            let currentCandidateItem = null;
                            for (let i = 0; i < path.length && currentItems; i++) {
                                const idInPath = path[i];
                                currentCandidateItem = currentItems.reduce((result, item) => {
                                    if (result) {
                                        return result;
                                    } else if (item.id === idInPath) {
                                        return item;
                                    } else {
                                        return null;
                                    }
                                }, null);
                                if (currentCandidateItem && i >= (path.length - 1)) {
                                    resultItem = currentCandidateItem;
                                } else {
                                    currentItems = currentCandidateItem && currentCandidateItem.childs;
                                }
                            }
                            return resultItem;
                        },
                        collapse(path) {
                            let itemToUpdate = this.retrieveItemFromPath(path);
                            this.$set(itemToUpdate, "expanded", false);
                        },
                        expand(path) {
                            let itemToUpdate = this.retrieveItemFromPath(path);
                            if (itemToUpdate) {
                                myWidget.expandFolder(itemToUpdate.id, (arrDataConverted) => {
                                    itemToUpdate.childs = arrDataConverted;
                                    this.$set(itemToUpdate, "expanded", true);
                                }, (...args) => {
                                    console.error(args);
                                });
                            }
                        },
                        select(path) {
                            let itemToUpdate = this.retrieveItemFromPath(path);
                            this.selectedItem = itemToUpdate;

                            this.refreshContent();
                        },

                        refreshContent() {
                            this.folderContent = [];

                            if (this.selectedItem && this.selectedItem.type === "Workspace Vault") {
                                myWidget.getFolderInfos(this.selectedItem.id, (arrDataConverted) => {
                                    //Take the item 0 as it should be the current folder being expanded
                                    myWidget.expandFolder(this.selectedItem.id, (arrDataConvertedExpand) => {
                                        this.selectedItem.childs = arrDataConvertedExpand;
                                        this.$set(this.selectedItem, "expanded", true);
                                        let fContent = this.selectedItem.childs && this.selectedItem.childs.slice() || [];
                                        fContent.push(...(arrDataConverted[0] && arrDataConverted[0].contentChilds || []));
                                        //let fContent = arrDataConverted[0] && arrDataConverted[0].contentChilds;
                                        this.folderContent = fContent;
                                    }, (...args) => {
                                        console.error(args);
                                    });
                                }, (...args) => {
                                    console.error(args);
                                });
                            }
                        },

                        dropInContent(ev) {
                            let fileList = ev.dataTransfer.files;
                            if (fileList && fileList.length > 0) {
                                //Extract the files to upload them as documents
                                //Do it for 1st file as of now, do code for multiple files later on
                                let parentFolderId = this.selectedItem.id;

                                DocumentsWSV2.uploadFileToNewDoc(null, fileList[0], null, parentFolderId, () => {
                                    //this.docObj = docInfos[0];
                                    this.refreshContent();
                                }, (errorType, errorMsg) => {
                                    console.error("uploadFileToNewDoc error", errorType, errorMsg);
                                });
                            } else {
                                //Try to see if it's a 3DXContent item dropped
                                try {
                                    let txtDrop = ev.dataTransfer.getData("text");
                                    let jsDataDrop = JSON.parse(txtDrop);
                                    if (jsDataDrop.protocol && jsDataDrop.protocol === "3DXContent") {
                                        let items = jsDataDrop.data.items;
                                        let objsDropped = [];
                                        for (let i = 0; i < items.length; i++) {
                                            const item = items[i];
                                            if (item.serviceId && (item.serviceId === "3DSpace" || item.serviceId === "3dspace")) {
                                                objsDropped.push(item);
                                            }
                                        }
                                        if (objsDropped.length > 0) {
                                            //There is some objects to attach
                                            myWidget.attachObjectsToCurrentFolder(this.selectedItem.id, objsDropped.map(item => item.objectId), () => {
                                                this.refreshContent();
                                            }, (...args) => {
                                                console.error(args);
                                            });
                                        }
                                    }
                                } catch (err) {
                                    console.error(err);
                                }
                            }
                        }
                    }
                });

                myWidget.loadProjects();

            },

            loadProjects() {
                ProjectsWS.getUserProjects({}, (arrData) => {
                    //console.log("getUserProjects:", arrData);
                    let arrConverted = myWidget.recurseOn3DSpaceData(arrData);
                    //console.log("arrConverted:", JSON.stringify(arrConverted));
                    vueApp.projectsTrees = arrConverted;
                }, (...args) => {
                    console.error(args);
                });
            },

            expandFolder(projectOrFolderId, onOk, onError) {
                ProjectsWS.getProjectFolders(projectOrFolderId, {}, (arrData) => {
                    let arrConverted = myWidget.recurseOn3DSpaceData(arrData);
                    onOk(arrConverted);
                }, onError);
            },

            getFolderInfos(folderId, onOk, onError) {
                ProjectsWS.getFolderDetails(folderId, {}, (arrData) => {
                    let arrConverted = myWidget.recurseOn3DSpaceData(arrData);
                    onOk(arrConverted);
                }, onError);
            },

            attachObjectsToCurrentFolder(folderId, objsDropped, onOk, onError) {
                ProjectsWS.attachObjectsToFolder(folderId, objsDropped, {}, onOk, onError);
            },

            recurseOn3DSpaceData(arrData) {
                const tenant = Connector3DExpV2.getCurrentTenant();
                const dontCopyKeys = ["dataelements", "relateddata", "children", "columns"];
                let arrResult = arrData.map((dataItem) => {
                    let resultItem = {
                        tenant: tenant
                    };
                    for (const key in dataItem) {
                        if (dataItem.hasOwnProperty(key) && dontCopyKeys.indexOf(key) === -1) {
                            resultItem[key] = dataItem[key];
                        }
                    }
                    if (dataItem.dataelements) {
                        for (const key in dataItem.dataelements) {
                            if (dataItem.dataelements.hasOwnProperty(key) && dontCopyKeys.indexOf(key) === -1) {
                                resultItem[key] = dataItem.dataelements[key];
                            }
                        }
                    }
                    if (dataItem.relateddata) {
                        resultItem.ownerInfo = dataItem.relateddata.ownerInfo;
                        resultItem.originatorInfo = dataItem.relateddata.originatorInfo;
                        resultItem.members = dataItem.relateddata.members;
                        if (dataItem.relateddata.folders) {
                            resultItem.expanded = true;
                            resultItem.childs = myWidget.recurseOn3DSpaceData(dataItem.relateddata.folders);
                        }
                        /*if (dataItem.children) {
                            resultItem.expanded = true;
                            let currentChilds = resultItem.childs || [];
                            currentChilds.push(...myWidget.recurseOn3DSpaceData(dataItem.children));
                            resultItem.childs = currentChilds;
                        }*/
                        if (dataItem.relateddata.content) {
                            resultItem.contentChilds = myWidget.recurseOn3DSpaceData(dataItem.relateddata.content);
                        }
                    }
                    return resultItem;
                });
                return arrResult;
            }
        };

        widget.addEvent("onLoad", myWidget.onLoadWidget);
        //widget.addEvent("onRefresh", myWidget.onLoadWidget);
        //widget.addEvent("onSearch", myWidget.onSearchWidget);
        //widget.addEvent("onResetSearch", myWidget.onResetSearchWidget);

        //widget.addEvent("onConfigChange", myWidget.onConfigChange); //For change of Table Config in list
    });
}