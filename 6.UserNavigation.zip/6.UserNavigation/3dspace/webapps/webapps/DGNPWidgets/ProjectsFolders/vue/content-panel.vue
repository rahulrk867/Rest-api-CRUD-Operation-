<template>
    <div class="contentBlock">
        <drop-zone style="min-height:100%;" @drop-on="dropOn">
            <div v-if="items.length===0">No Content</div>
            <v-layout row wrap>
                <v-flex
                    v-for="(item, i) in items"
                    :key="'item-'+i"
                    shrink
                    class="contentTile"
                    draggable="true"
                    @dragstart.stop="dragItem($event,item)"
                    @dragend.stop
                >
                    <img v-if="item.image || item.typeicon" :src="item.image || item.typeicon">
                    <div>{{ item.title }}</div>
                    <div>{{ item.name }} - {{ item.revision }}</div>
                </v-flex>
            </v-layout>
        </drop-zone>
    </div>
</template>

<style scoped>
.contentBlock {
    overflow: auto;
    height: 100%;
}

.contentTile {
    text-align: center;
    border: 1px solid #f1f1f1;
    box-shadow: 0.15em 0.15em 0.25em lightgrey;
    margin: 0.25em;
    padding: 0.25em;
    min-width: 100px;
}
</style>

<script>
/* global template */
define(["vue", "vueloader!current/vue/drop-zone"], function(Vue) {
    return Vue.component("content-panel", {
        template: template,
        props: {
            items: {
                type: Array,
                required: true
            }
        },
        data: function() {
            return {};
        },

        computed: {},

        watch: {},

        methods: {
            dropOn(ev) {
                this.$emit("drop-on", ev);
            },

            dragItem(event, item) {
                let data3DXContent = {
                    protocol: "3DXContent",
                    version: "1.1",
                    source: "UM5Wdg_Table",
                    widgetId: widget.id,
                    data: {
                        items: [
                            {
                                envId: item.tenant,
                                contextId: "",
                                objectId: item.id,
                                objectType: item.type,
                                displayName: item.name,
                                displayType: item.type,
                                serviceId: "3DSpace"
                            }
                        ]
                    }
                };
                let dataDnD = JSON.stringify(data3DXContent);
                let objNames = [item.name];
                let shortdata = JSON.stringify(objNames);

                //3DExp format
                event.dataTransfer.setData("text/plain", dataDnD);
                event.dataTransfer.setData("text/searchitems", dataDnD);
                event.dataTransfer.setData("shortdata", shortdata);

                //URL if drop in new Web Browser Tab
                //event.dataTransfer.setData("text/uri-list", this.obj.enoUrl);
            }
        }
    });
});
</script>