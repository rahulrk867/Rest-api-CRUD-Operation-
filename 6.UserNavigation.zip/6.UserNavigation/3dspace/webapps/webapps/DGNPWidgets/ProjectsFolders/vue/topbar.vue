<template>
    <div class="topbar">
        <v-layout row justify-space-between>
            <v-flex shrink>
                <v-icon @click="$emit('toggle-tree')">vertical_split</v-icon>
            </v-flex>
            <v-flex grow>
                <div class="pathBlock">
                    <v-icon>arrow_upward</v-icon>
                    <v-icon>refresh</v-icon>Path
                </div>
            </v-flex>
            <v-flex shrink>
                <v-icon>search</v-icon>
            </v-flex>
        </v-layout>
    </div>
</template>

<style scoped>
.topbar {
    border-bottom: 1px solid #f1f1f1;
}
.pathBlock {
    padding-left: 2em;
}
</style>

<script>
/* global template */
define(["vue"], function(Vue) {
    return Vue.component("topbar", {
        template: template,
        props: {},
        data: function() {
            return {};
        },

        computed: {},

        watch: {},

        methods: {}
    });
});
</script>