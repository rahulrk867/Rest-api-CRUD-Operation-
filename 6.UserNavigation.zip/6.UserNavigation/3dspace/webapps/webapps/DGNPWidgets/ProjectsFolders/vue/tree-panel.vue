<template>
    <div class="treeBlock">
        <div
            v-for="(item,i) in flattenTrees"
            :key="'folder-'+i"
            :style="'margin-left:'+item.level*1+'em;'"
            :class="['treeItem',selectedItem && item.id===selectedItem.id?'selected':'']"
        >
            <v-icon v-if="item.expanded" class="clickable" @click="collapse(item)">arrow_drop_down</v-icon>
            <v-icon v-else class="clickable" @click="expand(item)">arrow_right</v-icon>
            <span class="clickable" @click="select(item)">
                <img v-if="item.typeicon" :src="item.typeicon" class="typeicon">
                {{ item.name }}
            </span>
        </div>
    </div>
</template>

<style scoped>
.treeBlock {
    overflow: auto;
    height: 100%;
    border-right: 1px solid #f1f1f1;
}
.typeicon {
    height: 1em;
}
.clickable {
    cursor: pointer;
}
.treeItem.selected {
    border-bottom: 2px solid #005685;
    background-color: #d9edff;
}
</style>

<script>
/* global template */
define(["vue"], function(Vue) {
    return Vue.component("tree-panel", {
        template: template,
        props: {
            trees: {
                type: Array,
                required: true
            },
            selectedItem: {
                type: Object,
                required: false,
                default: null
            }
        },
        data: function() {
            return {};
        },

        computed: {
            flattenTrees() {
                let res = [];
                let exploreRecursive = function(items, parentItem, level) {
                    for (let i = 0; i < items.length; i++) {
                        const item = items[i];
                        item.parent = parentItem;
                        item.level = level;
                        res.push(item);
                        if (item.childs && item.expanded) {
                            exploreRecursive(item.childs, item, level + 1);
                        }
                    }
                };
                exploreRecursive(this.trees, null, 0);
                return res;
            }
        },

        watch: {},

        methods: {
            getItemPath(item) {
                let currItem = item;
                let path = [];
                while (currItem) {
                    path.splice(0, 0, currItem.id); //Push in first position
                    currItem = currItem.parent;
                }
                return path;
            },
            collapse(item) {
                this.$emit("collapse", this.getItemPath(item));
            },
            expand(item) {
                this.$emit("expand", this.getItemPath(item));
            },
            select(item) {
                this.$emit("select", this.getItemPath(item));
            }
        }
    });
});
</script>