/*
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */

function executeWidgetCode() {

    require.config({
        paths: {
            vue: "./BTWWLibrairies/vue/vue", //Need this with "vue" all lower case, else Vuetify can't load correctly
            Vuetify: "./BTWWLibrairies/vuetify/vuetify",
            CSSRoboto: "./BTWWLibrairies/fonts/Roboto", //"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700",
            CSSMaterial: "./BTWWLibrairies/MaterialDesign/material-icons",
            CSS3DSFont: "./BTWWLibrairies/fonts/3ds",
            vueloader: "./BTWWLibrairies/requirejs-vue", //"https://unpkg.com/requirejs-vue@1.1.5/requirejs-vue",
            current: "./QuizzVue"
        }
    });

    let vueApp; //Declare it here so it can be used in some modules defined here

    require(["vue",
        "Vuetify",
        "css!BTWWLibrairies/vuetify/vuetify.min.css",
        "css!CSSRoboto",
        "css!CSSMaterial",
        "css!CSS3DSFont",
        "vueloader!current/vue/question-panel"
    ], function(Vue, Vuetify) {

        Vue.use(Vuetify); //To plug vuetify components

        let prefs = {
            BASE_URL: "wsBaseURL",
            QUIZZ_CONF: "quizzConfName",
            RESULT_AFTER_QUESTION: "showResultAfterQuestion",
            RESULT_AT_END: "showResultsAtTheEnd"
        };

        let myWidget = {
            // Widget Events
            onLoadWidget() {
                let wdgUrl = widget.getUrl();
                wdgUrl = wdgUrl.substring(0, wdgUrl.lastIndexOf("/"));

                widget.setIcon(wdgUrl + "/../UM5Modules/assets/icons/custom-widget-icon.png");

                let wdgTitlePref = widget.getValue("wdgTitle");
                if (wdgTitlePref) {
                    widget.setTitle(wdgTitlePref);
                }

                myWidget.initPrefs();

                widget.setBody(
                    `<div id='appVue'>
                        <v-app style='height:100%;'>
                            <div class="topHeader" v-html="head"></div>
                            <div class="mainPanel">
                                <transition name="fade" mode="out-in">
                                    <div v-if="currentQuestionIndex < 0" @click="currentQuestionIndex = 0" class="startEndPanel">
                                        <v-layout column fill-height align-center justify-center>
                                            <v-flex xs12>
                                                <img :style="startPage.imgCss" :src="startPage.img"/>
                                            </v-flex>
                                            <v-flex xs12>
                                                <div>{{ startPage.text }}</div>
                                            </v-flex>
                                            <v-flex xs12>
                                                <div class="smallFont"> Tap or Click to Start </div>
                                            </v-flex>
                                        </v-layout>
                                    </div>
                                    <div v-else-if="sendingResult" class="startEndPanel">
                                        <v-progress-circular
                                            :size="70"
                                            :width="7"
                                            color="primary"
                                            indeterminate
                                        ></v-progress-circular> 
                                        Sending Result...
                                    </div>
                                    <template v-else-if="questions[currentQuestionIndex]">
                                        <question-panel :question="questions[currentQuestionIndex]" @answer="answer"></question-panel>
                                    </template>
                                    <div v-else @click="currentQuestionIndex = -1" class="startEndPanel">
                                        <v-layout column fill-height align-center justify-center>
                                            <v-flex xs12>
                                                <img :style="endPage.imgCss" :src="endPage.img"/>
                                            </v-flex>
                                            <v-flex xs12>
                                                <div>{{ endPage.text }}</div>
                                            </v-flex>
                                            <v-flex xs12>
                                                <div class="smallFont"> Tap or Click to Restart </div>
                                            </v-flex>
                                        </v-layout>
                                    </div>
                                </transition>
                            </div>
                            <div class="botAlign">
                                <v-progress-linear :color="progress>=100?'success':'primary'" height="10" :value="progress"></v-progress-linear>
                            </div>
                        </v-app>
                    </div>`
                );

                //Init vue App
                vueApp = new Vue({
                    el: "#appVue",
                    data: {
                        currentQuestionIndex: -1,
                        questions: [],
                        head: "Quizz is Loading...",
                        startPage: {},
                        endPage: {},
                        sendResultAfterQuestion: false,

                        sendingResult: false
                    },
                    computed: {
                        progress: function() {
                            if (this.currentQuestionIndex < 0) {
                                return 0;
                            }
                            return 100 * this.currentQuestionIndex / this.questions.length;
                        }
                    },
                    methods: {
                        answer: function(value) {
                            this.questions[this.currentQuestionIndex].value = value;
                            if (this.sendResultAfterQuestion) {
                                // Send the result
                                this.sendingResult = true;
                                this.sendSingleResult(this.currentQuestionIndex, () => {
                                    this.sendingResult = false;
                                    this.currentQuestionIndex++;
                                }, (...args) => {
                                    console.error(args);
                                    //TODO display a message to the user
                                    this.sendingResult = false;
                                });
                            } else if (this.currentQuestionIndex === this.questions.length - 1) {
                                //Last question answered, send all the results at once
                                this.sendResult(() => {
                                    this.sendingResult = false;
                                    this.currentQuestionIndex++;
                                }, (...args) => {
                                    console.error(args);
                                    //TODO display a message to the user
                                    this.sendingResult = false;
                                });
                            } else {
                                this.currentQuestionIndex++;
                            }

                        },

                        sendSingleResult: function(qIndex, onOkResultSent, onError) {
                            let baseUrl = widget.getValue(prefs.BASE_URL);
                            let confName = widget.getValue(prefs.QUIZZ_CONF);
                            let urlToCall = baseUrl + "/UM5QuizzModeler/UM5QuizzWS/" + confName + "/addSingleResult/" + qIndex;

                            let qResult = this.questions[qIndex].value || "";

                            let xhr = new XMLHttpRequest();
                            xhr.open("POST", urlToCall);

                            xhr.setRequestHeader("Content-Type", "text/plain");

                            xhr.onload = function() {
                                if (this.status === 200) {
                                    let data = JSON.parse(this.response);
                                    onOkResultSent(data);
                                } else {
                                    onError("Error will Saving results", this.status, this.response);
                                }
                            };

                            xhr.send(JSON.stringify(qResult));
                        },

                        sendResult: function(onOkResultSent, onError) {
                            let baseUrl = widget.getValue(prefs.BASE_URL);
                            let confName = widget.getValue(prefs.QUIZZ_CONF);
                            let urlToCall = baseUrl + "/UM5QuizzModeler/UM5QuizzWS/" + confName + "/addResults";

                            var arrResults = [];
                            for (var i = 0; i < this.questions.length; i++) {
                                var questRes = this.questions[i];
                                arrResults[i] = (questRes && questRes.value) || "";
                            }

                            let xhr = new XMLHttpRequest();
                            xhr.open("POST", urlToCall);

                            xhr.setRequestHeader("Content-Type", "text/plain");

                            xhr.onload = function() {
                                if (this.status === 200) {
                                    let data = JSON.parse(this.response);
                                    onOkResultSent(data);
                                } else {
                                    onError("Error will Saving results", this.status, this.response);
                                }
                            };

                            xhr.send(JSON.stringify(arrResults));
                        }
                    }
                });

                myWidget.loadConfigFile();
            },

            initPrefs() {
                let addPrefIfNotExisting = function(prefName, prefLabel, prefType, defaultValue) {
                    let prefToCheck = widget.getPreference(prefName);
                    if (typeof prefToCheck === "undefined") {
                        widget.addPreference({
                            name: prefName,
                            type: prefType,
                            label: prefLabel,
                            defaultValue: defaultValue
                        });
                    }
                };

                addPrefIfNotExisting(prefs.BASE_URL, "Base URL for Web Server hosting the Quizz", "text", "https://vdemoproXXXdsy.extranet.3ds.com/3DSpace");
                addPrefIfNotExisting(prefs.QUIZZ_CONF, "Quizz Configuration Name", "text", "QuizzName");
                addPrefIfNotExisting(prefs.RESULT_AFTER_QUESTION, "Show result after each Question", "boolean", "false");
                addPrefIfNotExisting(prefs.RESULT_AT_END, "Show results at the End of the Quizz", "boolean", "false");
            },

            loadConfigFile: function() {
                //var fileUrl = widget.getValue("configSurveyFile");
                let baseUrl = widget.getValue(prefs.BASE_URL);
                let confName = widget.getValue(prefs.QUIZZ_CONF);
                myWidget.confName = confName;

                let xhr = new XMLHttpRequest();
                xhr.open("GET", baseUrl + "/UM5QuizzModeler/UM5QuizzWS/config/" + confName);

                xhr.onload = function() {
                    if (this.status === 200) {
                        let data = JSON.parse(this.response);
                        vueApp.questions = data.questions;
                        vueApp.head = data.head;
                        vueApp.startPage = data.startPage;
                        vueApp.endPage = data.endPage;
                        vueApp.sendResultAfterQuestion = data.sendResultAfterQuestion || false;
                    } else {
                        widget.body.innerHTML = "Error will loading config File :" + this.status + "<br>" + this.response;
                    }
                };

                xhr.send();
            }
        };

        widget.addEvent("onLoad", myWidget.onLoadWidget);
        //widget.addEvent("onRefresh", myWidget.onLoadWidget);
        //widget.addEvent("onSearch", myWidget.onSearchWidget);
        //widget.addEvent("onResetSearch", myWidget.onResetSearchWidget);

        //widget.addEvent("onConfigChange", myWidget.onConfigChange); //For change of Table Config in list
    });
}