<template>
    <div :is="getComponentType()" :question="question" @answer="answer">{{ question.type }}</div>
</template>

<style scoped>
</style>

<script>
/* global template */

let questionTypesMapping = {
    YesNo: "question-type-yesno", //done
    OneChoice: "question-type-onechoice", //done
    MultiChoice: "question-type-multichoice", //done
    MultiLevelChoice: "question-type-multilevelonechoice", //done
    Evaluate: "question-type-evaluate", //done
    FreeText: "question-type-freetext" //done
};

define([
    "vue",
    "vueloader!current/vue/question-type-yesno",
    "vueloader!current/vue/question-type-onechoice",
    "vueloader!current/vue/question-type-multichoice",
    "vueloader!current/vue/question-type-multilevelonechoice",
    "vueloader!current/vue/question-type-evaluate",
    "vueloader!current/vue/question-type-freetext"
], function(Vue) {
    return Vue.component("question-panel", {
        template: template,
        props: {
            question: { type: Object, required: true }
        },
        data: function() {
            return {};
        },
        methods: {
            getComponentType: function() {
                return questionTypesMapping[this.question.type];
            },
            answer: function(value) {
                this.$emit("answer", value);
            }
        }
    });
});
</script>