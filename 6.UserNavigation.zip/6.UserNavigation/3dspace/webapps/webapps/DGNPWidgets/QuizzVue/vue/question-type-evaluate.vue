<template>
    <div>
        <v-layout row wrap justify-space-between>
            <v-flex xs12 class="questionTitle">{{ question.question }}</v-flex>
            <v-flex v-for="(choice,i) in choices" :key="'c-'+i" xs10 offset-xs1>
                <v-btn color="primary" @click="answer(choice.value)">{{ choice.label }}</v-btn>
            </v-flex>
        </v-layout>
    </div>
</template>

<style scoped>
</style>

<script>
/* global template */

define(["vue"], function(Vue) {
    return Vue.component("question-type-evaluate", {
        template: template,
        props: {
            question: { type: Object, required: true }
        },
        data: function() {
            return {};
        },
        computed: {
            choices: function() {
                let arrChoices = [];
                let step = this.question.step || 1;
                for (let i = this.question.min; i <= this.question.max; i += step) {
                    let addedLabel = "";
                    if (i === this.question.min && this.question.labelMin) {
                        addedLabel = " - " + this.question.labelMin;
                    } else if (i === this.question.max && this.question.labelMax) {
                        addedLabel = " - " + this.question.labelMax;
                    }
                    arrChoices.push({
                        label: i + addedLabel,
                        value: i
                    });
                }
                if (this.question["dispN/A"]) {
                    arrChoices.push({
                        label: "N/A",
                        value: "N/A"
                    });
                }
                return arrChoices;
            }
        },
        methods: {
            answer: function(value) {
                this.$emit("answer", value);
            }
        }
    });
});
</script>