<template>
    <div>
        <v-layout row wrap justify-space-between>
            <v-flex xs12 class="questionTitle">{{ question.question }}</v-flex>
            <v-flex xs10 offset-xs1>
                <v-textarea v-model="valueTxt" name="inTextarea" label="Type your Text Here"></v-textarea>
            </v-flex>
            <v-flex xs10 offset-xs1>
                <v-btn color="primary" @click="answer()">Next</v-btn>
            </v-flex>
        </v-layout>
    </div>
</template>

<style scoped>
</style>

<script>
/* global template */

define(["vue"], function(Vue) {
    return Vue.component("question-type-freetext", {
        template: template,
        props: {
            question: { type: Object, required: true }
        },
        data: function() {
            return {
                valueTxt: ""
            };
        },
        methods: {
            answer: function() {
                this.$emit("answer", this.valueTxt);
            }
        }
    });
});
</script>