<template>
    <div>
        <v-layout row wrap justify-space-between>
            <v-flex xs12 class="questionTitle">{{ question.question }}</v-flex>
            <v-flex v-for="(choice,i) in question.choices" :key="'c-'+i" xs10 offset-xs1>
                <v-btn @click="toggleAnswer(choice)">
                    <v-icon v-if="isAnswerSelected(choice)">check</v-icon>
                    {{ choice }}
                </v-btn>
            </v-flex>
            <v-flex xs10 offset-xs1>
                <v-btn :disabled="!validNumberOfAnswers()" color="primary" @click="answer()">Next</v-btn>
            </v-flex>
        </v-layout>
    </div>
</template>

<style scoped>
</style>

<script>
/* global template */

define(["vue"], function(Vue) {
    return Vue.component("question-type-multichoice", {
        template: template,
        props: {
            question: { type: Object, required: true }
        },
        data: function() {
            return {
                values: []
            };
        },
        methods: {
            toggleAnswer: function(value) {
                let iVal = this.values.indexOf(value);
                if (iVal !== -1) {
                    this.values.splice(iVal, 1);
                } else {
                    this.values.push(value);
                }
            },
            isAnswerSelected: function(value) {
                let iVal = this.values.indexOf(value);
                return iVal !== -1;
            },
            answer: function() {
                this.$emit("answer", this.values.join("|"));
            },
            validNumberOfAnswers: function() {
                let nb = this.values.length;
                let min = this.question.min || 0;
                let max = this.question.max || this.question.choices.length;
                return nb >= min && nb <= max;
            }
        }
    });
});
</script>