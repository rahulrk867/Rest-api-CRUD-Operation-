<template>
    <div>
        <v-layout row wrap justify-space-between>
            <v-flex xs12 class="questionTitle">{{ question.question }}</v-flex>
            <v-flex v-for="(choice,i) in currentChoices" :key="'c-'+i" xs10 offset-xs1>
                <v-btn @click="selectChoice(choice)">
                    {{ choice.value }}
                    <span v-if="choice.childs && choice.childs.length>0">&nbsp;
                        <v-icon>chevron_right</v-icon>
                    </span>
                </v-btn>
            </v-flex>
            <v-flex xs10 offset-xs1>
                <v-btn v-if="pathChoice.length>0" color="primary" outline @click="back()">Back</v-btn>
            </v-flex>
        </v-layout>
    </div>
</template>

<style scoped>
</style>

<script>
/* global template */

define(["vue"], function(Vue) {
    return Vue.component("question-type-multilevelonechoice", {
        template: template,
        props: {
            question: { type: Object, required: true }
        },
        data: function() {
            return {
                currentChoices: this.question.choices,
                pathChoice: []
            };
        },
        methods: {
            selectChoice: function(choiceItem) {
                if (choiceItem.childs && choiceItem.childs.length > 0) {
                    this.currentChoices = choiceItem.childs;
                    this.pathChoice.push(choiceItem);
                } else {
                    let values = [];
                    for (let i = 0; i < this.pathChoice.length; i++) {
                        const choiceInPath = this.pathChoice[i];
                        values.push(choiceInPath.value);
                    }
                    values.push(choiceItem.value); //Push also the leaf choice
                    this.$emit("answer", values.join("/"));
                }
            },
            back: function() {
                this.pathChoice.splice(this.pathChoice.length - 1, 1);
                if (this.pathChoice.length >= 1) {
                    this.currentChoices = this.pathChoice[this.pathChoice.length - 1].childs;
                } else {
                    this.currentChoices = this.question.choices;
                }
            }
        }
    });
});
</script>