<template>
    <div>
        <v-layout row wrap justify-space-between align-center>
            <v-flex xs12 class="questionTitle">{{ question.question }}</v-flex>
            <v-flex v-for="(choice,i) in question.choices" :key="'c-'+i" xs10 offset-xs1>
                <v-btn color="primary" @click="answer(choice)">{{ choice }}</v-btn>
            </v-flex>
        </v-layout>
    </div>
</template>

<style scoped>
</style>

<script>
/* global template */

define(["vue"], function(Vue) {
    return Vue.component("question-type-onechoice", {
        template: template,
        props: {
            question: { type: Object, required: true }
        },
        data: function() {
            return {};
        },
        methods: {
            answer: function(value) {
                this.$emit("answer", value);
            }
        }
    });
});
</script>