<template>
    <div>
        <v-layout row wrap justify-space-between>
            <v-flex xs12 class="questionTitle">{{ question.question }}</v-flex>
            <v-flex xs6>
                <v-btn color="primary" @click="answer('yes')">Yes</v-btn>
            </v-flex>
            <v-flex xs6>
                <v-btn color="primary" @click="answer('no')">No</v-btn>
            </v-flex>
        </v-layout>
    </div>
</template>

<style scoped>
</style>

<script>
/* global template */

define(["vue"], function(Vue) {
    return Vue.component("question-type-yesno", {
        template: template,
        props: {
            question: { type: Object, required: true }
        },
        data: function() {
            return {};
        },
        methods: {
            answer: function(value) {
                this.$emit("answer", value);
            }
        }
    });
});
</script>