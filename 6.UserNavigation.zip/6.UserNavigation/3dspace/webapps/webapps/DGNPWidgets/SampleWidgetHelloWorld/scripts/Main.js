function executeWidgetCode() {
    require(["UWA/Drivers/jQuery", "HelloModule/Toto"], function ($, totoModule) {
        var myWidget = {
            onLoadWidget: function () {
                widget.body.innerHTML = "<p>Hello, World !</p>" + totoModule.fctHello(widget.getValue("UserName")) + "<br/>" + "Yeah !";
            },
            toto: "test"
        };

        widget.addEvent("onLoad", myWidget.onLoadWidget);
    });
}