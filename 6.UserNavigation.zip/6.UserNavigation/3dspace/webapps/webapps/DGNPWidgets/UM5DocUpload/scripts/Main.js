/*
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */

function executeWidgetCode() {

    require.config({
        paths: {
            vue: "./BTWWLibrairies/vue/vue", //Need this with "vue" all lower case, else Vuetify can't load correctly
            Vuetify: "./BTWWLibrairies/vuetify/vuetify",
            CSSRoboto: "./BTWWLibrairies/fonts/Roboto", //"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700",
            CSSMaterial: "./BTWWLibrairies/MaterialDesign/material-icons",
            vueloader: "./BTWWLibrairies/requirejs-vue", //"https://unpkg.com/requirejs-vue@1.1.5/requirejs-vue",
            current: "./UM5DocUpload"
        }
    });

    let vueApp; //Declare it here so it can be used in some modules defined here

    require(["vue",
        "Vuetify",
        "UM5Modules/DocumentsWS",
        "css!BTWWLibrairies/vuetify/vuetify.min.css",
        "css!CSSRoboto",
        "css!CSSMaterial",
        "vueloader!current/vue/drop-zone"
    ], function(Vue, Vuetify, DocumentWS) {

        Vue.use(Vuetify); //To plug vuetify components

        var myWidget = {
            // Widget Events
            onLoadWidget: function() {
                var wdgUrl = widget.getUrl();
                wdgUrl = wdgUrl.substring(0, wdgUrl.lastIndexOf("/"));

                widget.setIcon(wdgUrl + "/../UM5Modules/assets/icons/custom-widget-icon.png");

                var wdgTitlePref = widget.getValue("wdgTitle");
                if (wdgTitlePref) {
                    widget.setTitle(wdgTitlePref);
                }

                widget.setBody(
                    `<div id='appVue'>
                        <v-app style='height:100%;'>
                            <drop-zone style='height:100%;' @drop-on="droppedFile">
                                -- File Drop Zone --
                                <div v-if="pendingFile">{{pendingFile.name}}</div>
                                <div v-if="docObj">Doc Id : {{docObj.id}}</div>
                                <div v-if="docObj">Doc Name : {{docObj.dataelements.name}}</div>
                            </drop-zone>
                        </v-app>
                    </div>`
                );

                //Init vue App
                vueApp = new Vue({
                    el: "#appVue",
                    data: {
                        pendingFile: null,
                        docObj: null
                    },
                    computed: {

                    },
                    methods: {
                        droppedFile(ev) {
                            console.log("droppedFile fct");
                            let fileList = ev.dataTransfer.files;
                            console.log("droppedFile fileList:", fileList);
                            if (fileList && fileList.length > 0) {
                                //Extract the files to upload them as documents
                                //Do it for 1st file as of now, do code for multiple files later on
                                DocumentWS.uploadFileToNewDoc(fileList[0], (docInfos) => {
                                    this.docObj = docInfos[0];
                                }, (errorType, errorMsg) => {
                                    console.error("uploadFileToNewDoc error", errorType, errorMsg);
                                });
                            }
                        }
                    }
                });
            }
        };

        widget.addEvent("onLoad", myWidget.onLoadWidget);
        //widget.addEvent("onRefresh", myWidget.onLoadWidget);
        //widget.addEvent("onSearch", myWidget.onSearchWidget);
        //widget.addEvent("onResetSearch", myWidget.onResetSearchWidget);

        //widget.addEvent("onConfigChange", myWidget.onConfigChange); //For change of Table Config in list
    });
}