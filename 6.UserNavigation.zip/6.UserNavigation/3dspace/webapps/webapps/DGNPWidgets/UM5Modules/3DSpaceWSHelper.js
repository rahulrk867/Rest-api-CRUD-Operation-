/**
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */
define(["UM5Modules/Connector3DExpV2"], function(Connector3DExp) {
    "use strict";

    let SpaceWSHelper = {

        //Manage the CSRF Token
        _currentCSRF: null,
        _doCallWithCSRF(options) {
            if (!options.data) {
                options.data = {};
            }
            if ((!SpaceWSHelper._currentCSRF || SpaceWSHelper._currentCSRF === null) && options.method !== "GET") {
                // If it's a GET request CSRF is not needed and we will have a CSRF token available in return
                // In 18x the call to bellow Web Service "/resources/v1/application/CSRF" is KO so you need to first do a GET call to a Web Service that will then give you a CSRF token
                // Due to the if condition above, if it's a GET call then it will do directly do your GET call
                // Once you have a CSRF token stored you can then do any kind of call using this method, the if condition will see that their is a CSRF token stored.

                // Else in 19x you don't need to do a previous GET call, this "/resources/v1/application/CSRF" call should work to Get the CSRF before doing the final targetted call
                SpaceWSHelper._do3DSpaceCall({
                    url: "/resources/v1/application/CSRF", //KO in 18x !
                    tenant: options.tenant,
                    method: "GET",
                    onOk: data => {
                        //We have the CSRF Token here
                        SpaceWSHelper._currentCSRF = data.csrf;
                        //Now do the call
                        SpaceWSHelper._doCallWithCSRF(options);
                    },
                    onError: (errorType, errorMsg) => {
                        options.onError("Impossible to get CSRF Token due to " + errorType, errorMsg);
                    }
                });
            } else {
                //Do the call directly with the last CSRF Token
                options.data.csrf = SpaceWSHelper._currentCSRF;
                if (options.method !== "GET") {
                    options.data = JSON.stringify(options.data);
                    options.contentType = "application/json";
                    options.headers = options.headers || {};
                    options.headers["Content-Type"] = "application/json";
                }

                SpaceWSHelper._do3DSpaceCall(options);
            }
        },

        _do3DSpaceCall(optionsin) {
            let options = optionsin;

            Connector3DExp.call3DSpace({
                url: options.url,
                tenant: options.tenant,
                method: options.method || "POST",
                type: options.type || "json",
                headers: options.headers,
                data: options.data,
                callbackData: options.callbackData,
                contentType: options.contentType,
                responseType: options.responseType,
                onComplete: function(dataResp, headerResp, callbackData) {
                    //Save the CSRF Token if it's there
                    if (dataResp && dataResp.csrf && dataResp.csrf.name === "ENO_CSRF_TOKEN") {
                        SpaceWSHelper._currentCSRF = dataResp.csrf;
                    }
                    if (dataResp.success) {
                        options.onOk(dataResp.data, callbackData);
                    } else {
                        var errorType = "Error in Web Service Response " + options.url;
                        var errorMsg = JSON.stringify(dataResp);
                        options.onError(errorType, errorMsg);
                    }
                },
                onFailure: function(error) {
                    var errorType = "WebService Call Faillure " + options.url;
                    var errorMsg = JSON.stringify(error);
                    options.onError(errorType, errorMsg);
                }
            });
        },

        get3DSpaceURL: function() {
            return Connector3DExp.getCurrentTenantInfo()["3DSpace"];
        }
    };

    return SpaceWSHelper;
});