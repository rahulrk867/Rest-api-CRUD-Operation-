/**
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */

define(["DS/i3DXCompassServices/i3DXCompassServices", "DS/WAFData/WAFData"], function(
    i3DXCompassServices,
    WAFData
) {
    let conn3DExpV2 = widget.conn3DExpV2; //Makes it a singleton on the widget level
    if (typeof conn3DExpV2 === "undefined") {
        conn3DExpV2 = {
            _wdgPrefTenant: "platformTenant", //Name of the widget preference to store the selected Tenant
            _wdgPrefEnoCtx: "enoCtx", //Name of the widget preference to store the currently selected Security context

            _platformTenantsInfos: null,
            _enoCtxForTenants: {},

            areURLsLoaded() {
                return this._platformTenantsInfos !== null;
            },
            getCurrentTenant() {
                return widget.getValue(this._wdgPrefTenant);
            },
            setPreferedTenant(tenant) {
                widget.setValue(this._wdgPrefTenant, tenant);
            },

            getCurrentTenantInfo() {
                console.warn("getCurrentTenantInfo backward compatibility function, please use getURLForTenantAndService instead");
                return this.getInfosOfTenant(this.getCurrentTenant());
            },

            getInfosOfTenant(tenant) {
                let objTenantInfo = null;
                for (let i = 0; i < this._platformTenantsInfos.length && !objTenantInfo; i++) {
                    const tenantInfo = this._platformTenantsInfos[i];
                    if (tenantInfo.platformId === tenant) {
                        objTenantInfo = tenantInfo;
                    }
                }
                return objTenantInfo;
            },

            getURLForTenantAndService(tenant, service) {
                let infoTenant = this.getInfosOfTenant(tenant);
                return infoTenant && infoTenant[service];
            },

            load3DExpURLs(onOk, onError) {
                let whenSuccess = (resultsI3DX) => {
                    if (resultsI3DX) {
                        //Save, update widget preferences and call onOk
                        this._platformTenantsInfos = resultsI3DX;

                        let prefTenants = widget.getPreference(this._wdgPrefTenant);
                        if (typeof prefTenants === "undefined") {
                            //Create it
                            widget.addPreference({
                                name: this._wdgPrefTenant,
                                type: "hidden",
                                label: "3DEXPERIENCE Platform",
                                defaultValue: widget.getValue("x3dPlatformId") || ""
                            });
                        }

                        let lastTenantSelected = widget.getValue(this._wdgPrefTenant);
                        let bLastSelectedTenantExists = false; //To check if it's still in the list for the currently connected user

                        prefTenants = widget.getPreference(this._wdgPrefTenant);
                        prefTenants.type = "list";

                        prefTenants.options = [];

                        let arrInfos = this._platformTenantsInfos;
                        for (let i = 0; i < arrInfos.length; i++) {
                            const platformInfo = arrInfos[i];
                            let platformId = platformInfo.platformId;
                            let platformName = platformInfo.displayName;
                            prefTenants.options.push({
                                value: platformId,
                                label: platformName
                            });
                            if (platformId === lastTenantSelected) {
                                bLastSelectedTenantExists = true;
                            }
                        }

                        if (!bLastSelectedTenantExists) {
                            prefTenants.defaultValue = widget.getValue("x3dPlatformId") || arrInfos[0] && arrInfos[0].platformId || "";
                        } else {
                            prefTenants.defaultValue = lastTenantSelected;
                        }

                        //Add Change Event
                        prefTenants.onchange = "onChangeConnector3DExpTenant";
                        widget.addEvent("onChangeConnector3DExpTenant", this.onChangeConnector3DExpTenant, this); //For change of Table Config in list

                        //Plug or update the Preference
                        widget.addPreference(prefTenants);
                        widget.setValue(this._wdgPrefTenant, prefTenants.defaultValue); //Set the correct selected Value for the tenant (fixed here 13/08/2018)

                        if (typeof onOk === "function") {
                            onOk();
                        } else {
                            console.debug("Platform URL Loaded");
                        }

                    } else {
                        if (typeof onError === "function") {
                            onError("i3DXCompassServices getPlatformServices onComplete but Invalid Response", resultsI3DX);
                        } else {
                            console.error("i3DXCompassServices getPlatformServices onComplete but Invalid Response", resultsI3DX);
                        }
                    }
                };
                let whenFailure = (errMsg, err) => {
                    if (typeof onError === "function") {
                        onError(errMsg, err);
                    } else {
                        console.error(errMsg, err);
                    }
                };

                let callI3DX = () => {
                    let timeOutCall = setTimeout(() => {
                        let errorMessage = "i3DXCompassServices getPlatformServices : Timeout after 10 seconds.";

                        onError(errorMessage);

                    }, 10000);
                    i3DXCompassServices.getPlatformServices({
                        onComplete: function(dataResult) {
                            clearTimeout(timeOutCall);
                            whenSuccess(dataResult);
                        },
                        onFailure: function(error) {
                            clearTimeout(timeOutCall);
                            whenFailure("i3DXCompassServices getPlatformServices onFailure", error);
                        }
                    });
                };
                callI3DX();
            },

            onChangeConnector3DExpTenant(namePref, valPref) {
                if (namePref === this._wdgPrefTenant) {
                    //Load the Security Context Pref
                    if (!this.isEnoCtxOfTenantLoaded(valPref)) {
                        this.loadEnoCtxOfTenant(valPref, () => {
                            //Dispatch onEdit to refresh the preference panel
                            widget.dispatchEvent("onEdit");
                        });
                    } else {
                        this.updateEnoCtxPref();
                    }
                }
            },

            isEnoCtxOfTenantLoaded(tenant) {
                return typeof this._enoCtxForTenants[tenant] !== "undefined";
            },

            _getEnoCtxOfTenant(tenant) {
                return this._enoCtxForTenants[tenant];
            },

            getEnoCtxOfTenant(tenant, onOk, onError) {
                if (!tenant) {
                    tenant = this.getCurrentTenant();
                }
                if (!this.isEnoCtxOfTenantLoaded(tenant)) {
                    this.loadEnoCtxOfTenant(tenant, () => {
                        onOk(this._getEnoCtxOfTenant(tenant));
                    }, onError);
                } else {
                    onOk(this._getEnoCtxOfTenant(tenant));
                }
            },

            updateEnoCtxPref() {
                let tenant = this.getCurrentTenant();
                let enoCtxInfos = this._getEnoCtxOfTenant(tenant);

                let prefCtx = widget.getPreference(this._wdgPrefEnoCtx);
                if (typeof prefCtx === "undefined") {
                    //Create it
                    widget.addPreference({
                        name: this._wdgPrefEnoCtx,
                        type: "hidden",
                        label: "3DSpace Collaborative Space",
                        defaultValue: ""
                    });
                }

                let lastEnoCtxSelected = widget.getValue(this._wdgPrefEnoCtx);
                let bLastEnoCtxExists = false;

                prefCtx = widget.getPreference(this._wdgPrefEnoCtx); //Refresh in case it was just created
                prefCtx.type = "list";

                prefCtx.options = [];

                let arrOfEnoCtx = [];

                let arrOfCS = enoCtxInfos.collabspaces;
                for (let i = 0; i < arrOfCS.length; i++) {
                    const objCollabSpace = arrOfCS[i];
                    let arrCouples = objCollabSpace.couples;
                    for (var j = 0; j < arrCouples.length; j++) {
                        var objCouple = arrCouples[j];

                        var organization = objCouple.organization.name;
                        var roleSC = objCouple.role.name;
                        var roleDisp = objCouple.role.nls || roleSC;

                        var scHere = {
                            label: roleDisp + "." + organization + "." + objCollabSpace.name,
                            value: roleSC + "." + organization + "." + objCollabSpace.name
                        };
                        arrOfEnoCtx.push(scHere);
                        if (lastEnoCtxSelected === scHere.value) {
                            bLastEnoCtxExists = true;
                        }
                    }
                }

                prefCtx.options = arrOfEnoCtx;

                if (!bLastEnoCtxExists) {
                    let preferredEnoCtx = enoCtxInfos.preferredcredentials;
                    prefCtx.defaultValue = preferredEnoCtx.role.name + "." + preferredEnoCtx.organization.name + "." + preferredEnoCtx.collabspace.name;
                } else {
                    prefCtx.defaultValue = lastEnoCtxSelected;
                }

                widget.addPreference(prefCtx);
                widget.setValue(this._wdgPrefEnoCtx, prefCtx.defaultValue);
            },

            loadEnoCtxOfTenant(tenantIn, onOk, onError) {
                if (!this.areURLsLoaded()) {
                    this.load3DExpURLs(() => {
                        this.loadEnoCtxOfTenant(tenantIn, onOk, onError);
                    }, onError);
                } else {
                    let tenant = tenantIn || this.getCurrentTenant();
                    //Do load the Security Context info for the specified tenant
                    let url3DSpace = this.getURLForTenantAndService(tenant, "3DSpace");
                    if (!url3DSpace) {
                        //No 3DSpace available for this tenant
                        //Go to error
                        onError("loadEnoCtxOfTenant - Error : No 3DSpace URL found for tenant", tenant);
                    } else {
                        //Got a 3DSpace URL, we can call the Web Service to get the Security Context available for the user connected
                        let servicePath = `/resources/modeler/pno/person?current=true&select=preferredcredentials&select=collabspaces&select=firstname&select=lastname&tenant=${tenant}`;

                        WAFData.authenticatedRequest(url3DSpace + servicePath, {
                            method: "GET",
                            headers: {
                                "SecurityContext": ""
                            },
                            data: {},
                            type: "json",
                            onComplete: (response) => {
                                this._enoCtxForTenants[tenant] = response;

                                if (!tenant || tenant === this.getCurrentTenant()) {
                                    this.updateEnoCtxPref();
                                }
                                if (typeof onOk === "function") {
                                    onOk();
                                }
                            },
                            onFailure: (error) => {
                                onError("loadEnoCtxOfTenant - Error will calling the Web Service to retrieve the Security Context", error);
                            }
                        });
                    }
                }
            },

            call3DSpace(options) {
                /*
                 * options :
                 * tenant
                 * securityContext
                 * url
                 * method
                 * data
                 * type
                 * contentType
                 * callbackData
                 * onComplete
                 * onFailure
                 */
                let tenant = options.tenant || this.getCurrentTenant();

                let onError = (errMsg, ...errData) => {
                    if (typeof options.onFailure === "function") {
                        options.onFailure(errMsg, errData);
                    } else {
                        console.error(errMsg, errData);
                    }
                };

                if (!this.areURLsLoaded()) {
                    this.load3DExpURLs(() => {
                        this.call3DSpace(options);
                    }, onError);
                } else if (!this.isEnoCtxOfTenantLoaded(tenant)) {
                    this.loadEnoCtxOfTenant(tenant, () => {
                        this.call3DSpace(options);
                    }, onError);
                } else {

                    let url3DSpace = this.getURLForTenantAndService(tenant, "3DSpace");

                    let urlWAF = url3DSpace + options.url;
                    if (urlWAF.indexOf("?") === -1) {
                        urlWAF += "?tenant=";
                    } else {
                        urlWAF += "&tenant=";
                    }
                    urlWAF += tenant;

                    let dataWAF = options.data || {};

                    let strCtx = options.securityContext || "";
                    if (strCtx === "") {
                        if (tenant === this.getCurrentTenant()) {
                            strCtx = widget.getValue(this._wdgPrefEnoCtx);
                        } else {
                            let preferredEnoCtx = this._getEnoCtxOfTenant(tenant).preferredcredentials;
                            strCtx = preferredEnoCtx.role.name + "." + preferredEnoCtx.organization.name + "." + preferredEnoCtx.collabspace.name;
                        }
                    }

                    let headerWAF = options.headers || {};

                    headerWAF["SecurityContext"] = strCtx;

                    let methodWAF = options.method || "GET";
                    let typeWAF = options.type;

                    WAFData.authenticatedRequest(urlWAF, {
                        method: methodWAF,
                        headers: headerWAF,
                        data: dataWAF,
                        type: typeWAF,
                        contentType: options.contentType,
                        responseType: options.responseType,
                        onComplete: function(dataResp, headerResp) {
                            options.onComplete(dataResp, headerResp);
                        },
                        onFailure: function(error, responseDOMString, headerResp) {
                            let errorObj = {
                                url: urlWAF,
                                error: error,
                                responseDOMString: responseDOMString,
                                headerResp: headerResp
                            };

                            onError("call3DSpace - Error", errorObj);
                        }
                    });
                }
            }

            //TODO 3DSwym Code
        };

        conn3DExpV2.load3DExpURLs();
        widget.conn3DExpV2 = conn3DExpV2; //Attach it to the widget object
    }

    return conn3DExpV2;
});