/**
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */

define([],
    function() {
        let tools = {
            csvToJSMatrix(csvAsText, splitChar) {
                let csvDataToLoad = [];

                let arrLines = csvAsText.split("\n");
                for (let i = 0; i < arrLines.length; i++) {
                    let line = arrLines[i];
                    if (line.indexOf("\r") === line.length - 1) {
                        // Remove trailing CR
                        line = line.substring(0, line.length - 1);
                    }
                    let validatedLine = [];
                    let arrCells = line.split(splitChar);
                    for (let j = 0; j < arrCells.length; j++) {
                        const cellVal = arrCells[j];
                        if (cellVal.indexOf('"') === 0) {
                            //Value starting with " check if ending with "
                            if (cellVal.indexOf('"') === cellVal.length - 1) {
                                //value ending with "
                                validatedLine.push(cellVal);
                            } else {
                                //Cell containing the split char
                                let cellValueCompleted = cellVal;
                                let cellEnded = false;
                                for (; j < arrCells.length && !cellEnded; j++) {
                                    const nextCell = arrCells[j];
                                    if (nextCell.indexOf('"') === nextCell.length - 1) {
                                        cellEnded = true;
                                    }
                                    cellValueCompleted += splitChar;
                                    cellValueCompleted += nextCell;
                                }
                                validatedLine.push(cellValueCompleted.substring(1, cellValueCompleted.length - 1)); //Remove the quotes around
                            }
                        } else {
                            //Direct value
                            validatedLine.push(cellVal);
                        }
                    }
                    csvDataToLoad.push(validatedLine);
                }
                return csvDataToLoad;
            },

            jsMatrixToCSV(csvData, splitChar) {
                let contentAsText = "";
                for (let r = 0; r < csvData.length; r++) {
                    const row = csvData[r];
                    if (r > 0) {
                        contentAsText += "\n";
                    }
                    for (let c = 0; c < row.length; c++) {
                        const cell = row[c];
                        if (c > 0) {
                            contentAsText += splitChar;
                        }
                        if (cell.indexOf(splitChar) !== -1) {
                            contentAsText += '"' + cell + '"';
                        } else {
                            contentAsText += cell;
                        }
                    }
                }
                return contentAsText;
            }
        };
        return tools;
    }
);