/**
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */
define(["UM5Modules/3DSpaceWSHelper", "UM5Modules/Connector3DExpV2"], function(SpaceWSHelper, Connector3DExpV2) {
    "use strict";

    let ProjectsWS = {
        getUserProjects(options, onOk, onError) {
            options.url = `/resources/v1/modeler/projects`;
            ProjectsWS._doGetCall(options, onOk, onError);
        },

        getProjectDetails(projectId, options, onOk, onError) {
            options.url = `/resources/v1/modeler/projects/${projectId}`;
            ProjectsWS._doGetCall(options, onOk, onError);
        },

        getProjectFolders(projectId, options, onOk, onError) {
            options.url = `/resources/v1/modeler/projects/${projectId}/folders`;
            ProjectsWS._doGetCall(options, onOk, onError);
        },

        getFolderDetails(folderId, options, onOk, onError) {
            options.url = `/resources/v1/modeler/projects/folderId/${folderId}`;
            ProjectsWS._doGetCall(options, onOk, onError);
        },

        attachObjectsToFolder(folderId, arrObjIds, options, onOk, onError) {
            //19xFD02 Web Service Not documented OOTB, taken from BookmarkEditor through reverse engineering...

            options.url = `/resources/v1/FolderManagement/Folder/${folderId}/content`;

            options.data = JSON.stringify({
                "IDs": arrObjIds.join(",")
            });
            options.contentType = "application/json";
            options.headers = options.headers || {};
            options.headers["Content-Type"] = "application/json";

            Connector3DExpV2.call3DSpace({
                url: options.url,
                tenant: options.tenant,
                method: "POST",
                type: "json",
                headers: options.headers,
                data: options.data,
                callbackData: options.callbackData,
                contentType: options.contentType,
                responseType: options.responseType,
                onComplete: function(dataResp) {
                    if (dataResp.status && dataResp.status === "success") {
                        onOk();
                    } else {
                        var errorType = "Error in Web Service Response " + options.url;
                        var errorMsg = JSON.stringify(dataResp);
                        onError(errorType, errorMsg);
                    }
                },
                onFailure: function(error) {
                    var errorType = "WebService Call Faillure " + options.url;
                    var errorMsg = JSON.stringify(error);
                    onError(errorType, errorMsg);
                }
            });
        },

        _doGetCall(options, onOk, onError) {
            let fields = options.fields || "all";
            let include = options.include || "all";

            options.url += `?$include=${encodeURIComponent(include)}&$fields=${encodeURIComponent(fields)}`;
            options.method = "GET";

            options.onOk = onOk;
            options.onError = onError;

            SpaceWSHelper._doCallWithCSRF(options);
        }
    };

    return ProjectsWS;
});