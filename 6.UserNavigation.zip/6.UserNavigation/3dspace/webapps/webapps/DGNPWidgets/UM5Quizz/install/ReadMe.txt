
In C:\DassaultSystemes\apache-tomee-3DSpace\webapps\3DSpace\WEB-INF\lib
Add UM5Quizz.jar

In C:\DassaultSystemes\apache-tomee-3DSpace\webapps\3DSpace\WEB-INF\web.xml

Add in all <param-value>  of "skipFilterUrlPatterns"
,/UM5QuizzModeler/*,/UM5QuizzWebSocket

Then in your reverse proxy conf file, next to the 3DSpace definition :
<Location /UM5QuizzWebSocket>
    ProxyPass ws://3dexp.18xfd05.ds:9080/3DSpace/UM5QuizzWebSocket
    ProxyPassReverse ws://3dexp.18xfd05.ds:9080/3DSpace/UM5QuizzWebSocket
</Location>

Restart Reverse Proxy and Tomee of 3DSpace