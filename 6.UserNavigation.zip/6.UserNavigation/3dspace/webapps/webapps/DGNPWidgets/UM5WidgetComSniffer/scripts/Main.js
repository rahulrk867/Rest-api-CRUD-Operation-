/*
 * BT WW Competencies Center - Fast Prototypes Team
 * @author UM5
 */

function executeWidgetCode() {

    require.config({
        paths: {
            vue: "./BTWWLibrairies/vue/vue", //Need this with "vue" all lower case, else Vuetify can't load correctly
            Vuetify: "./BTWWLibrairies/vuetify/vuetify",
            CSSRoboto: "./BTWWLibrairies/fonts/Roboto", //"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700",
            CSSMaterial: "./BTWWLibrairies/MaterialDesign/material-icons",
            vueloader: "./BTWWLibrairies/requirejs-vue", //"https://unpkg.com/requirejs-vue@1.1.5/requirejs-vue",
            current: "./UM5WidgetComSniffer"
        }
    });

    let vueApp; //Declare it here so it can be used in some modules defined here

    let getModuleInParent = (function() {
        let mapCache = {};

        function canAccessParent() {
            let access;
            try {
                access = parent && parent.document;
            } catch (err) {
                access = false;
            }
            return access;
        }
        return function(moduleName) {
            if (!mapCache[moduleName] && canAccessParent()) {
                try {
                    mapCache[moduleName] = parent.require(moduleName);
                } catch (err) {
                    //Do nothing
                }
            }
            return mapCache[moduleName];
        };
    })();

    require(["vue",
        "Vuetify",
        "UM5Modules/PrefTools",
        "css!BTWWLibrairies/vuetify/vuetify.min.css",
        "css!CSSRoboto",
        "css!CSSMaterial",
    ], function(Vue, Vuetify, PrefTools) {

        Vue.use(Vuetify); //To plug vuetify components

        var myWidget = {

            prefSubs: "_subsDone",

            // Widget Events
            onLoadWidget: function() {
                var wdgUrl = widget.getUrl();
                wdgUrl = wdgUrl.substring(0, wdgUrl.lastIndexOf("/"));

                widget.setIcon(wdgUrl + "/../UM5Modules/assets/icons/custom-widget-icon.png");

                var wdgTitlePref = widget.getValue("wdgTitle");
                if (wdgTitlePref) {
                    widget.setTitle(wdgTitlePref);
                }

                PrefTools.initPreferences({
                    name: myWidget.prefSubs,
                    default: "[]"
                });

                widget.setBody(
                    `<div id='appVue'>
                        <v-app style='height:100%;'>
                            <v-layout row wrap style='height:100%;'>
                                <v-flex xs6 style='height:100%;overflow:auto;'>
                                    <div class='headerBlock'>Widgets Subscriptions <v-icon color='white' style='float:right;cursor:pointer;' title='Refresh the List' @click='refreshSubsList()'>refresh</v-icon></div>
                                    <div v-for='(channel,nameChannel) in channels' :key="nameChannel">
                                        <div class="channelHead">Channel: {{nameChannel}}</div>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Topic</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr v-for='(topic,j) in channel' :key="j">
                                                    <td>{{topic}}</td>
                                                    <td>
                                                        <v-btn icon small v-if="isChannelTopicListen(nameChannel,topic)" @click="unsub(nameChannel,topic);"><v-icon color="blue" >volume_up</v-icon></v-btn>
                                                        <v-btn icon small v-else @click="sub(nameChannel,topic);"><v-icon color="grey" >volume_off</v-icon></v-btn>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </v-flex>
                                <v-flex xs6 style='height:100%;overflow:auto;'>
                                    <div class='headerBlock'>History <v-icon color='white' style='float:right;cursor:pointer;' title='Clear History' @click='history=[]'>delete_sweep</v-icon></div>
                                    <div v-for="(histObj,i) in history" :key="i" class="histObj">
                                        <div v-if="histObj.type==='subMsg'" class='subMsg'>
                                            <div class='topic'><v-icon color="grey" >message</v-icon> {{histObj.msg.channel}} - {{histObj.msg.topic}}</div>
                                            <div class='data'>{{histObj.msg.data}}</div>
                                            <div class='ts'>{{histObj.ts}}</div>
                                        </div>
                                        <div v-else-if="histObj.type==='newSub'" class='subMsg'>
                                            <div class='topic'><v-icon color="blue" >volume_up</v-icon> Now Listening to {{histObj.msg.channel}} - {{histObj.msg.topic}}</div>
                                            <div class='ts'>{{histObj.ts}}</div>
                                        </div>
                                        <div v-else-if="histObj.type==='unSub'" class='subMsg'>
                                            <div class='topic'><v-icon color="grey" >volume_off</v-icon> Remove Listening of {{histObj.msg.channel}} - {{histObj.msg.topic}}</div>
                                            <div class='ts'>{{histObj.ts}}</div>
                                        </div>
                                    </div>
                                </v-flex>
                            </v-layout>
                        </v-app>
                    </div>`
                );

                //Init vue App
                vueApp = new Vue({
                    el: "#appVue",
                    data: {
                        channels: [],
                        subs: {},
                        history: [],
                        ignorePrefSave: false
                    },
                    computed: {

                    },
                    methods: {
                        sub(channel, topic) {
                            let msgBus = getModuleInParent("DS/MessageBus/MessageBus");
                            let subObj = msgBus.subscribe({
                                channel: channel,
                                topic: topic,
                                callback: this.receiveBusMessage
                            });
                            //this.subs[channel][topic] = subObj;
                            //Needs display re-render
                            this.$set(this.subs, channel + "." + topic, subObj);
                            //Auto save in preferences
                            this.saveSubsInPref();
                            //Display a message
                            this.history.push({
                                type: "newSub",
                                msg: {
                                    channel: channel,
                                    topic: topic
                                },
                                ts: new Date().toLocaleString()
                            });
                        },
                        unsub(channel, topic) {
                            let msgBus = getModuleInParent("DS/MessageBus/MessageBus");
                            msgBus.unsubscribe(this.subs[channel + "." + topic]);
                            //this.subs[channel][topic] = null;
                            //Needs display re-render
                            this.$delete(this.subs, channel + "." + topic);
                            //Auto save in preferences
                            this.saveSubsInPref();
                            //Display a message
                            this.history.push({
                                type: "unSub",
                                msg: {
                                    channel: channel,
                                    topic: topic
                                },
                                ts: new Date().toLocaleString()
                            });
                        },
                        receiveBusMessage(msg, evObj) {
                            this.history.push({
                                type: "subMsg",
                                msg: evObj,
                                ts: new Date().toLocaleString()
                            });
                        },
                        refreshSubsList() {
                            myWidget.retrieveSubscriptions();
                        },
                        isChannelTopicListen(channel, topic) {
                            return this.subs[channel + "." + topic] && this.subs[channel + "." + topic] !== "";
                        },
                        saveSubsInPref() {
                            if (!this.ignorePrefSave) {
                                let arrSubs = [];

                                for (const keySub in this.subs) {
                                    if (this.subs.hasOwnProperty(keySub)) {
                                        const subObj = this.subs[keySub];
                                        if (subObj && typeof subObj.channel === "string" && typeof subObj.topic === "string" && typeof subObj.callback === "function") {
                                            //Quite sure that it's a subscription object there
                                            arrSubs.push({
                                                channel: subObj.channel,
                                                topic: subObj.topic
                                            });
                                        }
                                    }
                                }

                                //Save in pref
                                widget.setValue(myWidget.prefSubs, JSON.stringify(arrSubs));
                            }
                        },

                        loadSubsFromPref() {
                            this.ignorePrefSave = true; //Lock the auto save of subs in pref when a sub is done

                            let arrSubs = PrefTools.getValueAsJSON(myWidget.prefSubs);
                            for (let i = 0; i < arrSubs.length; i++) {
                                const subToDo = arrSubs[i];
                                this.sub(subToDo.channel, subToDo.topic);
                            }

                            this.ignorePrefSave = false; //Unlock auto save
                        }
                    }
                });

                vueApp.loadSubsFromPref();

                setTimeout(myWidget.retrieveSubscriptions, 1000); //Wait 2 sec for other widgets to be loaded
            },

            retrieveSubscriptions: function() {
                let msgBus = getModuleInParent("DS/MessageBus/MessageBus");
                let mapSubs = msgBus && msgBus.subscriptions || {};

                let channels = {};

                for (const channel in mapSubs) {
                    if (mapSubs.hasOwnProperty(channel)) {
                        let arrTopics = channels[channel] || [];
                        const subsInChannel = mapSubs[channel];
                        for (const topic in subsInChannel) {
                            if (subsInChannel.hasOwnProperty(topic)) {
                                arrTopics.push(topic);
                            }
                        }
                        arrTopics.sort(); //Sort by topic name
                        channels[channel] = arrTopics;
                    }
                }

                vueApp.channels = channels;
            }
        };

        widget.addEvent("onLoad", myWidget.onLoadWidget);
        //widget.addEvent("onRefresh", myWidget.onLoadWidget);
        //widget.addEvent("onSearch", myWidget.onSearchWidget);
        //widget.addEvent("onResetSearch", myWidget.onResetSearchWidget);

        //widget.addEvent("onConfigChange", myWidget.onConfigChange); //For change of Table Config in list
    });
}