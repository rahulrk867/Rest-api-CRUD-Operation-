function executeWidgetCode() {
    require(["UWA/Drivers/jQuery", "DS/WAFData/WAFData", "DS/DataDragAndDrop/DataDragAndDrop","DS/i3DXCompassServices/i3DXCompassServices","UWA/Controls/Web"], function($, WAFData, DataDragAndDrop,i3DXCompassServices,UWAControlsWeb) {
        var myWidget = {
            dataFull: [],
			spaceURL:"",

            displayData: function() {
                //Display data in Table
                var tableHTML = "<div id='divTable' style='height:100%;overflow:auto;'>Drop Project here !";
                tableHTML += "</div>";
                widget.body.innerHTML = tableHTML;

                myWidget.setSpaceURL();
				myWidget.setDnD();
            },
			
			setSpaceURL: function()
			{
				i3DXCompassServices.getPlatformServices
				({
					onComplete: function (urlDetails)
					{
						var platform = urlDetails[0];
						myWidget.spaceURL = platform['3DSpace'];
					}
				});
			},

            setDnD: function() {
                var $divTable = $("#divTable");
                if ($divTable.length > 0) {
                    var elemDivTable = $divTable.get(0);
                    DataDragAndDrop.droppable(elemDivTable, {
                        drop: function(data, elem, event) {
							var objDetails = JSON.parse(data);
							var objType = objDetails.data.items[0].objectType;

							if (objType == "Project Space")
							{
								var objectId = objDetails.data.items[0].objectId;
								myWidget.callCostStatusFile(objectId);
							}
							else
							{
								var tableHTML = "<div id='divTable' style='height:100%;overflow:auto;'>Please drop only Project";
								tableHTML += "</div>";
								widget.body.innerHTML = tableHTML;
							}
                        }
                    });
                }
            },

			callCostStatusFile: function(objectId)
			{
				var vURL = myWidget.spaceURL + '/wms/dashboards/wmsProjectCostStatus.jsp?objectId='+objectId;
				var costDashboardURL = new UWA.Controls.Web({
					url: vURL,
					width: '100%',
					height: '1000'
				});
				costDashboardURL.inject(widget.body.empty());
			},


            onLoadWidget: function() {
                myWidget.displayData(myWidget.dataFull);
            }
        };

        widget.addEvent("onLoad", myWidget.onLoadWidget);
        widget.addEvent("onRefresh", myWidget.onLoadWidget);
    });
}
