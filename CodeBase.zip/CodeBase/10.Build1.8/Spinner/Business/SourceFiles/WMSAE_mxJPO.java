/*---------------------------------------------------------------------------------------------------------------
NAME		: ${CLASSNAME}.java

DESCRIPTION	: Purpose of JPO is to Create AE and perform the utility operations on it

CREATED		: August 13 2019

AUTHOR		: Chandrakant M Sangashetty

HISTORY		:

	Chandrakant M Sangashetty	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UICache;
import com.matrixone.apps.framework.ui.UITableIndented;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.Policy;
import matrix.util.StringList;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.matrixone.jdom.Element;

import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;

public class WMSAE_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSAE_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	/**
    * This Method create AE objects.
    **/
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
    public Map createAE(Context context, String[] args)throws Exception {
		Map returnMap = new HashMap();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sParentOID = (String) programMap.get("parentOID");
			HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sObjectId = (String) paramMap.get("objectId");
			String symbolicTypeName = (String) UICache.getSymbolicName(context, TYPE_WMSAE, "type");
			
			Element elm = (Element) programMap.get("contextData");        
			MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
			HashMap objMap;
			String sRowId = DomainConstants.EMPTY_STRING ;
			MapList returnList = new MapList();
			
			for (int i = 0, size = chgRowsMapList.size(); i < size; i++) {
				objMap = new HashMap();
				Map changedRowMap = (HashMap) chgRowsMapList.get(i);
				Map columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");
				String strSequenceNumber = (String) columnsMap.get("SequenceNumber");
				String strTitle = (String) columnsMap.get("Title");
				String strDescription = (String) columnsMap.get("Description");
				
				DomainObject doParentObject = new DomainObject(sParentOID);
				DomainObject doObject = new DomainObject();
				String sType = doParentObject.getInfo(context, DomainConstants.SELECT_TYPE);
				String sRelationship = RELATIONSHIP_WMSAE_AE;
				if (TYPE_WMSAEMASTER.equals(sType) || TYPE_WMS_DEFAULT_MASTERS.equals(sType)) {
					sRelationship = RELATIONSHIP_WMSAEMASTER_AE;
				}
				
				StringList busSelects = new StringList();
				busSelects.add(DomainConstants.SELECT_ID);
				
				String sWhere = "attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value == \""+strTitle+"\"";
				MapList mlObjects = doParentObject.getRelatedObjects(context, // matrix context
															sRelationship, // relationship pattern
															TYPE_WMSAE, // type pattern
															busSelects, // object selects
															null, // relationship selects
															false, // to direction
															true, // from direction
															(short) 1, // recursion level
															sWhere, // object where clause
															null); // relationship where clause
				if (mlObjects.size() > 0) {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.HeadCreate");
					returnMap.put("Action", "ERROR");
					returnMap.put("Message", strMessage);
				} else {
					String sName = DomainObject.getAutoGeneratedName(context, symbolicTypeName, DomainConstants.EMPTY_STRING);
					DomainRelationship doRel = doObject.createAndConnect(context, TYPE_WMSAE, sName, DomainConstants.EMPTY_STRING, POLICY_WMSAE, null, sRelationship, doParentObject, true);
					
					doObject.setDescription(context, strDescription);
					
					HashMap attributeMap = new HashMap();
					attributeMap.put(ATTRIBUTE_WMSITEMSEQUENCE, strSequenceNumber);
					attributeMap.put(DomainConstants.ATTRIBUTE_TITLE, strTitle);
					doObject.setAttributeValues(context, attributeMap);
					
					objMap.put("oid", doObject.getObjectId(context));
					objMap.put("relid", doRel.toString());
					objMap.put("pid", sObjectId);
					objMap.put("rid", "");
					objMap.put("markup", "new");
					objMap.put("rowId", sRowId);                
					returnList.add(objMap);
					returnMap.put("changedRows", returnList);
					returnMap.put("Action", "refresh");
				}
			}
						
		} catch(Exception ex){
			ex.printStackTrace();
			returnMap.put("Action", "ERROR");
			returnMap.put("Message", ex.getMessage());
		}
		return returnMap;
    }
	
	/**
	* Method to get Related AE Master information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedAEMaster(Context context,String args[]) throws Exception {
		MapList mlReturnList = new MapList();
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
			String sCommandName=(String) programMap.get("portalCmdName");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			busSelects.add(DomainObject.SELECT_TYPE);
			busSelects.add("from["+RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE+"].to.id");
			busSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			String sObjState = DomainConstants.EMPTY_STRING;
			String sObjRTId = DomainConstants.EMPTY_STRING;
			String sObjType = DomainConstants.EMPTY_STRING;
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlAEMaster = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_AEMASTER, // relationship pattern
													TYPE_WMSAEMASTER+","+TYPE_WMS_DEFAULT_MASTERS, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			for (int i = 0, size = mlAEMaster.size(); i < size; i++) {
				Map objMap = (Map) mlAEMaster.get(i);
				sObjOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
				sObjState = (String) objMap.get(DomainConstants.SELECT_CURRENT);
				sObjType = (String) objMap.get(DomainObject.SELECT_TYPE);
				sObjRTId = (String) objMap.get("from["+RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE+"].to.id");
				if(("WMSAEPart2".equals(sCommandName) && !sContextUser.equals(sObjOwner)) || !STATE_WMSAEMASTER_CREATE.equals(sObjState)) {
					objMap.put("RowEditable", "readonly");
				}
				
				if ("WMSAEPart1".equals(sCommandName) && (!STATE_WMSAEMASTER_CREATE.equals(sObjState))) {
					objMap.put("disableSelection", "true");
					objMap.put("RowEditable", "readonly");
				}

			}
			mlAEMaster.sort("originated", "ascending", "date");
			if ("WMSAEPart1".equals(sCommandName))
			{
				PersonUtil.setPersonProperty(context, "RIC_TotalRows", ""+mlAEMaster.size());
			}
			return mlAEMaster;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	* Method to get Related AE information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedAE(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
			String sCommandName=(String) programMap.get("portalCmdName");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			String sObjState = DomainConstants.EMPTY_STRING;
			String sObjRTId = DomainConstants.EMPTY_STRING;
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlAE =domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
													TYPE_WMSAE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			for (int i = 0, size = mlAE.size(); i < size; i++) {
				Map objMap = (Map) mlAE.get(i);
				sObjOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
				sObjState = (String) objMap.get(DomainConstants.SELECT_CURRENT);
				if(!sContextUser.equals(sObjOwner) || !STATE_WMSAE_CREATE.equals(sObjState)) {
					objMap.put("RowEditable", "readonly");
				}
				
				objMap.put("disableSelection", "true");
			}
			mlAE.sort("originated", "ascending", "date");
			return mlAE;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
		
	/**
	* Method to get Related AE/AE Item information on AE
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedAEItem(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			
			DomainObject domObject = new DomainObject(sObjectId);
			String sObjState = domObject.getInfo(context, DomainConstants.SELECT_CURRENT);
			MapList mlAEItem =domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE+","+RELATIONSHIP_WMSAE_AEITEM, // relationship pattern
													TYPE_WMSAE+","+TYPE_WMSAEITEM, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			for (int i = 0, size = mlAEItem.size(); i < size; i++) {
				Map objMap = (Map) mlAEItem.get(i);
				sObjOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
				if(!sContextUser.equals(sObjOwner) || (!STATE_WMSAE_CREATE.equals(sObjState))) {
					objMap.put("RowEditable", "readonly");
					objMap.put("disableSelection", "true");
				}
			}
			mlAEItem.sort("originated", "ascending", "date");
			return mlAEItem;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public String getAEAmountField (Context context,String[] args)throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			dAmount = WMSUtil_mxJPO.getHeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
			
			return df.format(dAmount);
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public String getAETotalAmountField (Context context,String[] args)throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			dAmount = WMSUtil_mxJPO.getPart1HeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
			
			return df.format(dAmount);
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public String getAEMasterTotalAmountField (Context context,String[] args)throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			dAmount = WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
			
			return df.format(dAmount);
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method Delete AE and its Childs object.
    */
    public boolean deleteObjectAndChilds(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
			
			StringList slItem = doObj.getInfoList(context, "from["+RELATIONSHIP_WMSAE_AEITEM+"].to.id");
			String[] objIds = new String[slItem.size()];
			objIds = slItem.toArray(objIds);
			DomainObject.deleteObjects(context, objIds);
			StringList slAE = doObj.getInfoList(context, "from["+RELATIONSHIP_WMSAE_AE+"].to.id");
			for (Object ItemObject:slAE) {
				sItemId = (String)ItemObject;
				boolean flag = deleteObjectAndChilds(context, new String[]{sItemId});
				if (!flag) {
					return false;
				}
			}
			doObj.deleteObject(context);
			return true;	
		} catch(Exception ex){
			ex.printStackTrace();
			return false;
		}
    }
	
	/**
    ** This Method connect AE Item object.
    */
	@com.matrixone.apps.framework.ui.PostProcessCallable
    public void connectItem(Context context, String[] args)throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
			HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sParentObjectId = (String) paramMap.get("objectId");
			
			String sfromObjectId = (String) requestMap.get("parentOID");
			String sType = (String) requestMap.get("TypeActual");
			String stoObjectId = (String) paramMap.get("objectId");
			
			DomainRelationship.connect(context, sfromObjectId, RELATIONSHIP_WMSAE_AEITEM, stoObjectId, false);
			
			MapList mlObjects = new MapList();
			Map oMap = new HashMap();
			oMap.put(DomainConstants.SELECT_TYPE, TYPE_WMSAEITEM);
			oMap.put(DomainConstants.SELECT_ID, stoObjectId);
			mlObjects.add(oMap);
			
			oMap = new HashMap();
			oMap.put("ObjectList", mlObjects);
			
			HashMap hmTableData = new HashMap();
			hmTableData.put("tableData", oMap);
			
			JPO.invoke(context, "WMSUtil", null, "updateItemHistory", JPO.packArgs (hmTableData), Map.class);
			
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
			
	/**
	* Method to get Related AE information on AE
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAEAndItem(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
						
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlAE =domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE+","+RELATIONSHIP_WMSAE_AEITEM, // relationship pattern
													TYPE_WMSAE+","+TYPE_WMSAEITEM, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			mlAE.sort("originated", "ascending", "date");
			return mlAE;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	* Method to get Related AE Master information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedApprovedAEMaster(Context context,String args[]) throws Exception {
		MapList mlReturnList = new MapList();
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
			String sCommandName=(String) programMap.get("portalCmdName");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add(DomainConstants.SELECT_TYPE);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			busSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
			busSelects.add("from["+RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE+"].to.id");
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			String sObjState = DomainConstants.EMPTY_STRING;
			String sObjRTId = DomainConstants.EMPTY_STRING;
			String sObjType = DomainConstants.EMPTY_STRING;
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlAEMaster = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_APPROVEDAEMASTER, // relationship pattern
													TYPE_WMSAEMASTER+","+TYPE_WMS_DEFAULT_MASTERS, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			for (int i = 0, size = mlAEMaster.size(); i < size; i++) {
				Map objMap = (Map) mlAEMaster.get(i);
				sObjOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
				sObjState = (String) objMap.get(DomainConstants.SELECT_CURRENT);
				sObjType = (String) objMap.get(DomainConstants.SELECT_TYPE);
				sObjRTId = (String) objMap.get("from["+RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE+"].to.id");
				/*if(("WMSApprovedAEPart2".equals(sCommandName) && !sContextUser.equals(sObjOwner)) || !STATE_WMSAEMASTER_CREATE.equals(sObjState)) {
					objMap.put("RowEditable", "readonly");
				}*/
				
				//if ("WMSApprovedAEPart1".equals(sCommandName) && ((sObjRTId==null || sObjRTId.isEmpty()) || !STATE_WMSAEMASTER_CREATE.equals(sObjState))) {
				if ("WMSApprovedAEPart1".equals(sCommandName) && !STATE_WMSAEMASTER_CREATE.equals(sObjState)) {
					objMap.put("disableSelection", "true");
					objMap.put("RowEditable", "readonly");
				}
				
	
			}
			mlAEMaster.sort("originated", "ascending", "date");
			if ("WMSApprovedAEPart1".equals(sCommandName))
			{
				PersonUtil.setPersonProperty(context, "RIC_TotalRows", ""+mlAEMaster.size());
			}
			return mlAEMaster;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public void reviseAEMaster(Context context, String[] args) throws Exception {
		try {
			ContextUtil.startTransaction(context, true);
			
			String fileName = DomainConstants.EMPTY_STRING;			
			FileOutputStream outputStream = null;
			String strTempFolder = context.createWorkspace();
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strObjId = (String)programMap.get("objectId");
			String strRelationship = (String)programMap.get("relationship");
			
			if(UIUtil.isNotNullAndNotEmpty(strObjId) && UIUtil.isNotNullAndNotEmpty(strRelationship)){
				DomainObject doObject = new DomainObject(strObjId);
				String strSOCTitle = (String)doObject.getAttributeValue(context,DomainConstants.ATTRIBUTE_TITLE);
				StringList slObjectStates = (StringList)doObject.getInfoList(context,"from["+strRelationship+"].to.current");
				
				if(slObjectStates.isEmpty() || slObjectStates.contains(STATE_WMSAEMASTER_CREATE) || slObjectStates.contains(STATE_WMSAEMASTER_REVIEW)){
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Revise.AEFails");
					emxContextUtil_mxJPO.mqlNotice(context, strMessage);
					return;
				}
				
				StringList busSelects = new StringList();
				busSelects.add(DomainConstants.SELECT_ID);
				busSelects.add(DomainConstants.SELECT_DESCRIPTION);
				busSelects.add(DomainConstants.SELECT_OWNER);
				busSelects.add(DomainConstants.SELECT_ORIGINATED);
				busSelects.add("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
				busSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
				busSelects.add("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"].value");
				busSelects.add("attribute["+ATTRIBUTE_RATE+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSGST+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSAUTHORIZED+"].value");
				busSelects.add("attribute["+ATTRIBUTE_REMARKS+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSCONTINGENCY+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSCONSULTANCY+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSUSER+"].value");
				
				MapList mlAE =doObject.getRelatedObjects(context, // matrix context
														strRelationship+","+RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE+","+RELATIONSHIP_WMSAE_AEITEM, // relationship pattern
														TYPE_WMSAEMASTER+","+TYPE_WMSAE+","+TYPE_WMSAEITEM+","+TYPE_WMS_DEFAULT_MASTERS, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														DomainConstants.EMPTY_STRING, // object where clause
														DomainConstants.EMPTY_STRING); // relationship where clause
				//mlAE.sort("originated", "ascending", "date");
				mlAE.addSortKey("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value","ascending","String");
				mlAE.addSortKey(DomainConstants.SELECT_ORIGINATED,"ascending","date");
				mlAE.sort();
				if(mlAE != null && !mlAE.isEmpty()) {
					XSSFWorkbook workbook = new XSSFWorkbook();
					XSSFSheet sheetData = workbook.createSheet("Data");
					//String[] headerData = {"Sl No", "Level", "Sequence Number", "Type", "Title","Description", "Unit of Measure", "Quantity", "Rate", "Amount", "GST(%)", "Contingency(%)", "Consultancy(%)", "Total Amount", "Item Type", "Remarks", "Owner"};
					//String[] headerData = {"Sequence Number", "Level", "Type", "Title","Description", "Unit of Measure", "Quantity", "Rate", "Amount", "GST(%)", "Contingency(%)", "Consultancy(%)", "Total Amount", "Item Type", "Remarks", "Owner"};
					String[] headerData = {"Sequence Number", "Level", "Type", "Title","Description", "Unit of Measure", "Quantity", "Rate", "Amount", "GST(%)", "Total Amount", "Item Type", "Remarks", "Owner"};
					CellStyle styleHeading = workbook.createCellStyle();
					styleHeading.setBorderLeft(CellStyle.ALIGN_CENTER);
					
					XSSFFont font= workbook.createFont();
					font.setFontHeightInPoints((short)10);
					font.setFontName("Arial");
					font.setColor(IndexedColors.WHITE.getIndex());
					font.setBold(true);
					styleHeading.setFont(font);
					//styleHeading.setFillForegroundColor(IndexedColors.DARK_TEAL.getIndex());
					styleHeading.setFillForegroundColor((short)30);
					styleHeading.setFillPattern(CellStyle.SOLID_FOREGROUND); 
					styleHeading.setBorderLeft(CellStyle.BORDER_THIN);
					styleHeading.setBorderRight(CellStyle.BORDER_THIN);
					styleHeading.setBorderTop(CellStyle.BORDER_THIN);
					styleHeading.setBorderBottom(CellStyle.BORDER_THIN);
					
					Row row = sheetData.createRow(0);
					for (int columnCount=0; columnCount < headerData.length; columnCount++) {
						Cell cell = row.createCell(columnCount);
						cell.setCellValue((String) headerData[columnCount]);
						cell.setCellStyle(styleHeading);
					}
					
					String[] cellData = new String[headerData.length];			
					Row rowData = null;
					int iSize = mlAE.size();
					Map mapObjectInfo = null;
					int iCountRow = 1;
					String sObjectId = DomainConstants.EMPTY_STRING;
					String sOwner = DomainConstants.EMPTY_STRING;
					DecimalFormat df = new DecimalFormat("0.00");
					for(int i=0; i<iSize; i++) {
						mapObjectInfo = (Map)mlAE.get(i);
						cellData[0] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
						cellData[1] = (String)mapObjectInfo.get(DomainConstants.SELECT_LEVEL); 
						cellData[3] = (String)mapObjectInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
						cellData[4] = (String)mapObjectInfo.get(DomainConstants.SELECT_DESCRIPTION);
						cellData[5] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
						cellData[6] = (String)mapObjectInfo.get("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"].value");
						cellData[7] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_RATE+"].value");
						cellData[9] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSGST+"].value");
						//cellData[10] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSCONTINGENCY+"].value");
						//cellData[11] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSCONSULTANCY+"].value");
						cellData[11] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSAUTHORIZED+"].value");
						cellData[12] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_REMARKS+"].value");
						
						sObjectId = (String)mapObjectInfo.get(DomainConstants.SELECT_ID);
						DomainObject doAEObject = new DomainObject(sObjectId);
						switch((String) mapObjectInfo.get(DomainConstants.SELECT_TYPE)) {
							case "WMSDefaultMaster" :
										cellData[2] = "Head";
										cellData[8] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value");
										cellData[10] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value");
										ContextUtil.pushContext(context);
										doAEObject.setState(context, STATE_WMSAEMASTER_CREATE, true);
										ContextUtil.popContext(context);
										break;
							case "WMSAEMaster" :
										cellData[2] = "Head";
										cellData[8] = String.valueOf(df.format(WMSUtil_mxJPO.getMasterAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM})));
										cellData[10] = String.valueOf(df.format(WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM})));
										ContextUtil.pushContext(context);
										doAEObject.setState(context, STATE_WMSAEMASTER_CREATE, true);
										ContextUtil.popContext(context);
										break;
							case "WMSAE" :
										cellData[2] = "Head";
										cellData[8] = String.valueOf(df.format(WMSUtil_mxJPO.getHeadAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM})));
										cellData[10] = String.valueOf(df.format(WMSUtil_mxJPO.getPart1HeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM})));
										ContextUtil.pushContext(context);
										doAEObject.setState(context, STATE_WMSAE_CREATE, true);
										ContextUtil.popContext(context);
										break;
							case "WMSAEItem" :
										cellData[2] = "Item";
										cellData[8] = String.valueOf(df.format(WMSUtil_mxJPO.getItemAmount(context, new String[]{sObjectId})));
										cellData[10] = String.valueOf(df.format(WMSUtil_mxJPO.getItemTotalAmount(context, new String[]{sObjectId})));
										ContextUtil.pushContext(context);
										doAEObject.deleteObject(context, true);
										ContextUtil.popContext(context);
										break;
							default :
										cellData[2] = DomainConstants.EMPTY_STRING;
										cellData[8] = "0.00";
										cellData[10] = "0.00";
						}
						
						sOwner = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSUSER+"].value");
						if (("User Agent").equalsIgnoreCase(sOwner)) {
							cellData[13] = sOwner;
						} else {
							//BusinessObject boPerson = new BusinessObject(DomainConstants.TYPE_PERSON, sOwner, "-", VAULT_ESERVICEPRODUCTION);
							//DomainObject doPerson = new DomainObject(boPerson);
							cellData[13] = sOwner;
						}
						
						rowData = sheetData.createRow(iCountRow);
						for (int columnCount=0; columnCount < headerData.length; columnCount++) {
							Cell cell = rowData.createCell(columnCount);
							cell.setCellValue((String) cellData[columnCount]);
						}
						iCountRow++;
						
					}
					fileName = strSOCTitle +"_"+Calendar.getInstance().getTimeInMillis();
					outputStream = new FileOutputStream(new File(strTempFolder+"/"+fileName+ ".xlsx"));
					workbook.write(outputStream);
					
					DomainObject doNewDoc = DomainObject.newInstance(context, DomainConstants.TYPE_DOCUMENT);
					doNewDoc.createObject(context, DomainConstants.TYPE_DOCUMENT, fileName, new Policy(DomainConstants.POLICY_DOCUMENT).getFirstInMinorSequence(context), DomainConstants.POLICY_DOCUMENT, VAULT_ESERVICEPRODUCTION);	
					doNewDoc.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, fileName);
					doNewDoc.checkinFile(context, true, true, "", DomainConstants.FORMAT_GENERIC, fileName+".xlsx", strTempFolder);
					String sDocRelationship = (RELATIONSHIP_WMSSOC_APPROVEDAEMASTER).equalsIgnoreCase(strRelationship) ? RELATIONSHIP_WMSAPPROVEDAE_REVISEREFERENCEDOCUMENT : RELATIONSHIP_WMSAEREVISE_REFERENCEDOCUMENT;
					DomainRelationship.connect(context, doObject, sDocRelationship, doNewDoc);
					
					//revise AA
					if (RELATIONSHIP_WMSSOC_APPROVEDAEMASTER.equals(strRelationship)) {
						busSelects = new StringList();
						busSelects.add(DomainConstants.SELECT_ID);
						busSelects.add(DomainConstants.SELECT_CURRENT);
						busSelects.add(DomainConstants.SELECT_OWNER);
						String sWhere = "revision==last";
						MapList sList = doObject.getRelatedObjects(context, // matrix context
															RELATIONSHIP_WMSSOCADMINAPPROVAL, // relationship pattern
															TYPE_WMSADMINAPPROVAL, // type pattern
															busSelects, // object selects
															null, // relationship selects
															false, // to direction
															true, // from direction
															(short) 1, // recursion level
															sWhere, // object where clause
															null); // relationship where clause
						
						if (sList.size() == 1) {
							Map objMap = (Map) sList.get(0);
							String strAAId = (String) objMap.get(DomainConstants.SELECT_ID);
							String strState = (String) objMap.get(DomainConstants.SELECT_CURRENT);
							String strOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
							if (UIUtil.isNotNullAndNotEmpty(strAAId) && UIUtil.isNotNullAndNotEmpty(strState) && STATE_AAAPPROVED.equals(strState)) {
								DomainObject doAA = new DomainObject(strAAId);
								BusinessObject boDelegation = doAA.reviseObject(context, true);
								doAA = new DomainObject(boDelegation);
								doAA.setOwner(context, strOwner);
							}
						}
						//revise WOO
						ContextUtil.pushContext(context);
						String sWOOState = (String)MqlUtil.mqlCommand(context,"print bus "+strObjId+" select from["+RELATIONSHIP_WMSSOC_WOO+"].to.current dump");
						String strWOOID = (String)MqlUtil.mqlCommand(context,"print bus "+strObjId+" select from["+RELATIONSHIP_WMSSOC_WOO+"].to.id dump");
							if(sWOOState.equals(STATE_WMSWOO_APPROVED)){
								try{
								WMSWOO_mxJPO.generateXLForWOO(context,new String [] {strObjId, strWOOID});	
								DomainObject dWOOObj = new DomainObject(strWOOID);							
								dWOOObj.setState(context,STATE_WMSWOO_CREATE,true);								
								String sStstae = dWOOObj.getInfo(context,"current");
														
								}
								catch(Exception e)
								{
									e.printStackTrace();
								}
							}	
                      					
						ContextUtil.popContext(context);
					}
					
				}
								
			}
			
			ContextUtil.commitTransaction(context);
			
			
		} catch (Exception e) {
			e.printStackTrace();
			ContextUtil.abortTransaction(context);
			emxContextUtil_mxJPO.mqlNotice(context, "Revise Process Failed");
		//	e.printStackTrace();
			throw e;
		}
	}
	
	/**
	* Method to get Related Approved AE Revision History information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getApprovedAERevisionHistory(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList(2);
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			StringList relSelects = new StringList(1);
            relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlRevisionHistory = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSAPPROVEDAE_REVISEREFERENCEDOCUMENT, // relationship pattern
													DomainConstants.QUERY_WILDCARD, // type pattern
													busSelects, // object selects
													relSelects, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			return mlRevisionHistory;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	* Method to get Related AE Revision History information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAERevisionHistory(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList(2);
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			StringList relSelects = new StringList(1);
            relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlRevisionHistory = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSAEREVISE_REFERENCEDOCUMENT, // relationship pattern
													DomainConstants.QUERY_WILDCARD, // type pattern
													busSelects, // object selects
													relSelects, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			return mlRevisionHistory;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public String freezApprovedAE(Context context, String[] args) throws Exception {
		String sResult = DomainConstants.EMPTY_STRING;
		int iResult = 1;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			MapList mlRows = (MapList) programMap.get("RowIds");
			
			ContextUtil.startTransaction(context, true);
			for (int i = 0, size = mlRows.size(); i < size; i++) {
				Map objMap = (Map) mlRows.get(i);
				String strObjId = (String) objMap.get(DomainConstants.SELECT_ID);
				
				StringList busSelects = new StringList();
				busSelects.add(DomainConstants.SELECT_ID);
				busSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
				
				if(UIUtil.isNotNullAndNotEmpty(strObjId)) {
					DomainObject doObject = new DomainObject(strObjId);
					MapList mlAE =doObject.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														DomainConstants.EMPTY_STRING, // object where clause
														DomainConstants.EMPTY_STRING); // relationship where clause
					
					for (int j = 0; j < mlAE.size() ; j++) {
						Map oMap = (Map) mlAE.get(j);
						String strItemId = (String) oMap.get(DomainConstants.SELECT_ID);
						String strItemName = (String) oMap.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
						if(UIUtil.isNotNullAndNotEmpty(strItemId)) {
							iResult = WMSUtil_mxJPO.checkForLeafItem(context, new String [] {strItemId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
							if( iResult == 1) {
								sResult = "Failed to Freeze "+strItemName+" Should have At least one Item to Freeze";
							} else {
								DomainObject doItem = new DomainObject(strItemId);
								ContextUtil.pushContext(context);
								MqlUtil.mqlCommand(context,"trigger off");
								doItem.setState(context, STATE_WMSAE_APPROVED, true);
								MqlUtil.mqlCommand(context,"trigger on");
								ContextUtil.popContext(context);
							}
						}
					}
					if (UIUtil.isNullOrEmpty(sResult)) {
						ContextUtil.pushContext(context);
						MqlUtil.mqlCommand(context,"trigger off");
						doObject.setState(context, STATE_WMSAEMASTER_APPROVED, true);
						MqlUtil.mqlCommand(context,"trigger on");
						ContextUtil.popContext(context);
					}
				}
			}
			
			if (UIUtil.isNullOrEmpty(sResult)) {
				ContextUtil.commitTransaction(context);
			} else {
				ContextUtil.abortTransaction(context);
			}
			
		} catch (Exception e) {
			sResult = e.getMessage();
			ContextUtil.abortTransaction(context);
			e.printStackTrace();
		}
		return sResult;
	}
	
	public int updateAEApprovalHistory(Context context,String[] args) throws Exception
	{
	try {	  
		String strPersonId = PersonUtil.getPersonObjectID(context);
		StringList slPersonSelect = new StringList();
		slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
		slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
		
		DomainObject doPerson = new DomainObject(strPersonId);
		Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
		String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
		String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
		
		if(UIUtil.isNullOrEmpty(strFirstName)){
			strFirstName = DomainConstants.EMPTY_STRING;
		}
		if(UIUtil.isNullOrEmpty(strLastName)){
			strLastName = DomainConstants.EMPTY_STRING;
		}
		
		String strContectUser = strFirstName + " " +strLastName;
		
		String strTaskId = args[0];
		Calendar calendarDate = Calendar.getInstance();
		
		String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
		SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
		String strTime = formatter.format(calendarDate.getTime());
		
		String strRouteId = DomainConstants.EMPTY_STRING;
		String strMBEObjectId = DomainConstants.EMPTY_STRING;
		String strMeasurementObjectId = DomainConstants.EMPTY_STRING;
		String strMeasurementComment = DomainConstants.EMPTY_STRING;
		String strMeasurementApprovalHistory = DomainConstants.EMPTY_STRING;
		String strBOQId = DomainConstants.EMPTY_STRING;
		String strType = DomainConstants.EMPTY_STRING;
		String strIsModified = DomainConstants.EMPTY_STRING;
		String strIsTitle = DomainConstants.EMPTY_STRING;
		MapList mlMeasurementDetails = new MapList();
		MapList mlMeasurementDetailsForNotification = new MapList();

		if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
			String strMqlQuery = "print bus "+strTaskId+" select from["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|from.type=='"+TYPE_WMSAEMASTER+"'].from.id dump";
			strMBEObjectId = MqlUtil.mqlCommand(context,strMqlQuery);
			if(UIUtil.isNotNullAndNotEmpty(strMBEObjectId)){
				DomainObject doMBE = new DomainObject(strMBEObjectId);
				String strState = (String)doMBE.getInfo(context,DomainObject.SELECT_CURRENT);
				HashMap requestMap = new HashMap();
				requestMap.put("objectId", strMBEObjectId);
				StringList busSelects = new StringList();
				busSelects.add(DomainObject.SELECT_ID);
				busSelects.add(DomainObject.SELECT_ORIGINATED);
				busSelects.add(DomainObject.SELECT_TYPE);
				busSelects.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY+"]");
				busSelects.add("attribute[Comments]");
							
				DomainObject domObject = new DomainObject(strMBEObjectId);
				MapList mlRIC = domObject.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE+","+RELATIONSHIP_WMSAE_AEITEM, // relationship pattern
														TYPE_WMSAEMASTER+","+TYPE_WMSAE+","+TYPE_WMSAEITEM, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														null, // object where clause
														null); // relationship where clause
				if(mlRIC != null){
					Map mTemp = null;
					Map mTempMeas = null;
					Map mMeasMap = null;
					Map mMeasMapNotification = null;
					for(int i=0;i<mlRIC.size();i++){
						mTemp = (Map)mlRIC.get(i);
						if(mTemp != null && mTemp.isEmpty()==false){
							strBOQId = (String)mTemp.get(DomainObject.SELECT_ID);
							strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
							if(UIUtil.isNotNullAndNotEmpty(strBOQId) && TYPE_WMSAEITEM.equals(strType)){
								strMeasurementComment = (String)mTemp.get("attribute[Comments]");
								strMeasurementApprovalHistory = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY+"]");

								if(UIUtil.isNotNullAndNotEmpty(strMeasurementComment) && !"Create".equals(strState)){
									mMeasMap = new HashMap();
									mMeasMap.put("id",strBOQId);
									mMeasMap.put("comment",strMeasurementComment);
									mMeasMap.put("history",strMeasurementApprovalHistory);
									mlMeasurementDetails.add(mMeasMap);
								}
							}							
						}						
					}					
				}				
			}			
		}
		
		strMeasurementObjectId = DomainConstants.EMPTY_STRING;
		strMeasurementComment = DomainConstants.EMPTY_STRING;
		strMeasurementApprovalHistory = DomainConstants.EMPTY_STRING;
		String strMeasurementApprovalHistoryOld = DomainConstants.EMPTY_STRING;
		String strMeasurementApprovalHistoryLastEntry = DomainConstants.EMPTY_STRING;
		StringList slHistoryEntryList = new StringList();
		
		DomainObject doMeasurement = null;
		Map mTempMeasMap = null;
		for(int j=0;j<mlMeasurementDetails.size();j++){
			mTempMeasMap = (HashMap)mlMeasurementDetails.get(j);
			strMeasurementObjectId = (String)mTempMeasMap.get("id");
			strMeasurementComment = (String)mTempMeasMap.get("comment");
			strMeasurementApprovalHistoryOld = (String)mTempMeasMap.get("history");
			strMeasurementApprovalHistory = strContectUser +"|"+strTime+"|"+strMeasurementComment;
			slHistoryEntryList = FrameworkUtil.split(strMeasurementApprovalHistoryOld, "\n");
			if(slHistoryEntryList.size()==0){
				strMeasurementApprovalHistoryOld = strMeasurementApprovalHistory;
			}else if(slHistoryEntryList.size()>0){
				strMeasurementApprovalHistoryLastEntry = (String)slHistoryEntryList.get(slHistoryEntryList.size()-1);
				if(strMeasurementApprovalHistoryLastEntry.endsWith(strMeasurementComment) == false){
					strMeasurementApprovalHistoryOld = strMeasurementApprovalHistoryOld +"\n"+strMeasurementApprovalHistory;
				}
			}
			if(UIUtil.isNotNullAndNotEmpty(strMeasurementObjectId)){
				doMeasurement = new DomainObject(strMeasurementObjectId);
				doMeasurement.setAttributeValue(context,ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY,strMeasurementApprovalHistoryOld);
				doMeasurement.setAttributeValue(context,"Comments",DomainConstants.EMPTY_STRING);
			}
		}
		
	}catch(Exception e){
		e.printStackTrace();
	} 
	return 0;
} 
	
 }