/** Name of the JPO    :
 ** Developed by    : DSIS 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to manage all code for Workorder
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/


import com.matrixone.apps.domain.util.PropertyUtil;
import matrix.db.Context;

/**
 * The purpose of this JPO is to handle functionality of SOR
 * @author DSIS
 */
public class WMSConstants_mxJPO	
{
	
	Context context = null;
	
    public WMSConstants_mxJPO(Context context,String[] args) {
		this.context = context;
	}
    
    public static String getSchemaProperty(Context context,String adminType,String adminName){
    	   

        return  PropertyUtil.getSchemaProperty(context, adminType+"_"+adminName);

  }
	
    
  
    
    /*******************************************Relationship constants goes below *******************************************/
    public static final String RELATIONSHIP_WMS_TASK_SOR = PropertyUtil.getSchemaProperty("relationship_WMSTaskSOR");
    public static final String RELATIONSHIP_WMS_REPORTING_MANAGER = PropertyUtil.getSchemaProperty("relationship_WMSReportingManager");
    public static final String RELATIONSHIP_BILL_OF_QUANTITY = PropertyUtil.getSchemaProperty("relationship_WMSMeasurementBookItems");
    public static final String RELATIONSHIP_WMS_PORJECT_WORK_ORDER = PropertyUtil.getSchemaProperty("relationship_WMSProjectWorkOrder");
    public static final String RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderAssignee");
    public static final String RELATIONSHIP_WMS_PROJECT_WORK_ORDER  = PropertyUtil.getSchemaProperty("relationship_WMSProjectWorkOrder");
	public static final String RELATIONSHIP_WMS_PROJECT_OBSERVATIONS = PropertyUtil.getSchemaProperty("relationship_WMSProjectObservations");
	public static final String RELATIONSHIP_REPORTING_MANAGER = PropertyUtil.getSchemaProperty("relationship_WMSReportingManager");
	public static final String RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE= PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderApprovalTemplate");
	public static final String RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR = PropertyUtil.getSchemaProperty("relationship_PRBWorkorderContractor");
	public static final String RELATIONSHIP_WORKORDER_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");
	public static final String RELATIONSHIP_WMS_AMBE_APPROVAL_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSAMBEApprovalTemplate");   
	public static final String RELATIONSHIP_WMS_WORK_ORDER_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOMBE");
	public static final String RELATIONSHIP_WMS_MBE_ACTIVITIES = PropertyUtil.getSchemaProperty("relationship_WMSMBEActivities");
	public static final String RELATIONSHIP_WMS_SEGMENT_MBE = PropertyUtil.getSchemaProperty("relationship_WMSSegmentMBE");
	public static final String RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS = PropertyUtil.getSchemaProperty("relationship_WMSActivityMeasurements");
	public static final String RELATIONSHIP_WMS_MBE_APPROVAL_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSMBEApprovalTemplate");
	public static final String RELATIONSHIP_WMS_PROJECT_SPACE_TRANSMITTAL = PropertyUtil.getSchemaProperty("relationship_WMSProjectSpaceTransmittal");
	public static final String RELATIONSHIP_WMS_PAYMENT_HEAD = PropertyUtil.getSchemaProperty("relationship_WMSPaymentHead");
	public static final String RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBEPaymentItems");
	public static final String RELATIONSHIP_WMS_OBSERVATION_ASSIGNEE = PropertyUtil.getSchemaProperty("relationship_WMSObservationAssignee");
	public static final String RELATIONSHIP_WMS_OBSERVATION_RESPONSE_DOCUMENTS = PropertyUtil.getSchemaProperty("relationship_WMSObservationResponseDocuments");

	
	//ABSMBE
	public static final String RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");  
	public static final String RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION = PropertyUtil.getSchemaProperty("relationship_WMSItemTechnicalDeduction");
	public static final String RELATIONSHIP_WMS_ABSMBE_TECHNICAL_DEDUCTION_RELEASE = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBETechnicalDeductionRelease");
	public static final String RELATIONSHIP_WMS_WO_TECHNICAL_DEDUCTION = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderTechnicalDeduction");
	public static final String RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBEActivities");
	public static final String RELATIONSHIP_WMS_ABSMBE_TECHNICALDEDUCTION = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBETechnicalDeduction");
	
	//Abs Particular
	public static final String RELATIONSHIP_WMS_BILL_REDUCTION_RELEASE = "relationship_WMSBillReductionRelease";
	public static final String RELATIONSHIP_WMS_BILL_REDUCTION = "relationship_WMSBillReduction";
	public static final String RELATIONSHIP_WMS_ADVANCE_RECOVERY = PropertyUtil.getSchemaProperty("relationship_WMSAMBAdvanceRecovery");
	public static final String RELATIONSHIP_WMS_RECOVERY = PropertyUtil.getSchemaProperty("relationship_WMSAMBRecovery");
	public static final String RELATIONSHIP_WMS_WORK_ORDER_ADVANCES = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderAdvances");
	
	//Other head deduction 
	
	 public static final String RELATIONSHIP_WMS_ABSTRACT_MBE_HEAD_DEDUCTION = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBEHeadDeduction");
	 //Material bill
	 public static final String RELATIONSHIP_WMS_MATERIALBILL_STOCK = PropertyUtil.getSchemaProperty("relationship_WMSMaterialBillStock");
	 public static final String RELATIONSHIP_WMS_MATERIAL_TO_SOR = PropertyUtil.getSchemaProperty("relationship_WMSMaterialToSOR");
	 public static final String RELATIONSHIP_WMS_STOCK_MATERIAL = PropertyUtil.getSchemaProperty("relationship_WMSStockMaterial");
	 public static final String RELATIONSHIP_WMS_WORK_ORDER_ADVANCE_RATE = PropertyUtil.getSchemaProperty("relationship_WMSWorkorderAdvanceRate");
	 public static final String RELATIONSHIP_WMS_WO_MATERIAL_BILL = PropertyUtil.getSchemaProperty("relationship_WMSWOMaterialBill");
	 public static final String RELATIONSHIP_WMS_MB_APPROVAL_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSMBApprovalTemplate");	 
	 public static final String RELATIONSHIP_WMS_MAKER_OF = PropertyUtil.getSchemaProperty("relationship_WMSMakerOf");
	 public static final String RELATIONSHIP_WMS_STOCK_ENTRIES_MAKER_OF = PropertyUtil.getSchemaProperty("relationship_WMSStockEntriesMakerOf");	 
	 public static final String RELATIONSHIP_WMS_ABS_STOCK						        = PropertyUtil.getSchemaProperty("relationship_WMSABSStock");	 
	 public static final String RELATIONSHIP_WMS_MATERIAL_CONSUMPTION_TO_AMB             = PropertyUtil.getSchemaProperty("relationship_WMSMaterialConsumptionToAMB");
	 public static final String RELATIONSHIP_WMS_MATERIAL_CONSUMPTION_TO_STOCK    = PropertyUtil.getSchemaProperty("relationship_WMSMaterialConsumptionToStock");	
	 public static final String RELATIONSHIP_WMS_ITEM_MATERIAL_CONSUMPTION               = PropertyUtil.getSchemaProperty("relationship_WMSItemMaterialConsumption");	 
	 public static final String RELATIONSHIP_WMS_MATERIAL_CONSUMPTION_TO_MATERIAL        = PropertyUtil.getSchemaProperty("relationship_WMSMaterialConsumptionToMaterial");
	 public static final String RELATIONSHIP_WMS_MATERIAL_ESCALATION        = PropertyUtil.getSchemaProperty("relationship_WMSMaterialEscalation");
	 
	 //SDP  
	 public static final String RELATIONSHIP_WMS_WORK_ORDER_SDP        = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderSDP");
	 public static final String RELATIONSHIP_WMS_WORK_ORDER_SOR        = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderSOR");
	 
	 
     /*******************************************************Type constants goes below *******************************************/
     public static final String TYPE_WMS_MEASUREMENT_TASK = PropertyUtil.getSchemaProperty("type_WMSMeasurementTask");
     public static final String TYPE_WMS_SEGMENT = PropertyUtil.getSchemaProperty("type_WMSSegment");
     public static final String TYPE_WMS_MEASUREMENT_BOOK = PropertyUtil.getSchemaProperty("type_WMSMeasurementBook"); 
     public static final String TYPE_WMS_WORK_ORDER = PropertyUtil.getSchemaProperty("type_WMSWorkOrder");
     public static final String TYPE_WMS_SOR_CHAPTER = PropertyUtil.getSchemaProperty("type_WMSSORChapter");
     public static final String TYPE_WMSOBSERVATION = PropertyUtil.getSchemaProperty("type_WMSObservation");
public static final String TYPE_WMS_SOR = PropertyUtil.getSchemaProperty("type_WMSSOR");
     public static final String TYPE_WMS_SOR_LIBRARY = PropertyUtil.getSchemaProperty("type_WMSSORLibrary");
     public static final String TYPE_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("type_WMSAbstractMeasurementBookEntry");
     //MBE 
     public static final String TYPE_WMS_MEASUREMENT_BOOK_ENTRY = PropertyUtil.getSchemaProperty("type_WMSMeasurementBookEntry");
     public static final String TYPE_WMS_PAYMENT_ITEM = PropertyUtil.getSchemaProperty("type_WMSPaymentItem");//remove
     public static final String TYPE_WMS_MEASUREMENTS = PropertyUtil.getSchemaProperty("type_WMSMeasurements");
     public static final String RELATIONSHIP_WMS_PAYMENT_ITEM = PropertyUtil.getSchemaProperty("relationship_WMSPaymentItem");
    
    
     //ABSMBE
     public static final String TYPE_WMS_BILL_REDUCTION_ITEM = "type_WMSBillReductionItem";
     public static final String TYPE_WMS_TECHNICAL_DEDUCTION = PropertyUtil.getSchemaProperty("type_WMSTechnicalDeduction");

    //ABS Particular
    public static final String TYPE_WMS_ADVANCE_RECOVERY_ITEM = PropertyUtil.getSchemaProperty("type_WMSAdvanceRecoveryItem");
    public static final String TYPE_WMS_PAYMENT_SCHEDULE = PropertyUtil.getSchemaProperty("type_WMSPaymentSchedule");
    //othe deduction
    
    public static final String TYPE_WMS_OTER_HEAD_DEDUCTION = PropertyUtil.getSchemaProperty("type_WMSOtherHeadDeduction");
    public static final String POLICY_WMS_OTER_HEAD_DEDUCTION = PropertyUtil.getSchemaProperty("policy_WMSOtherHeadDeduction");
    
    //Material library
    public static final String TYPE_WMS_MATERIAL = PropertyUtil.getSchemaProperty("type_WMSMaterialCategory");
    public static final String TYPE_WMS_MATERIAL_BILL = PropertyUtil.getSchemaProperty("type_WMSMaterialBill");
	public static final String TYPE_WMS_STOCK_ENTRIES = PropertyUtil.getSchemaProperty("type_WMSStockEntries");
	
	public static final String TYPE_WMS_MATERIAL_MAKER = PropertyUtil.getSchemaProperty("type_WMSMaterialMaker");
	 public static final String TYPE_WMS_MATERIAL_CONSUMPTION           = PropertyUtil.getSchemaProperty("type_WMSMaterialConsumption");
    
    /*************************************************Attribute constants goes below **************************************/
    public static final String ATTRIBUTE_WMS_ITEM_RATE_ESCALATION = PropertyUtil.getSchemaProperty("attribute_WMSItemRateEscalation");
	public static final String ATTRIBUTE_WMS_WORK_ORDER_ROLE = PropertyUtil.getSchemaProperty("attribute_WMSWorkOrderRole");
	public static final String ATTRIBUTE_WMS_DEFAULT_ROLE = PropertyUtil.getSchemaProperty("attribute_WMSDefaultRole");
	public static final String ATTRIBUTE_WMS_MBE_ITEM_TYPE = PropertyUtil.getSchemaProperty("attribute_WMSMBEItemType");
	public static final String ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE= PropertyUtil.getSchemaProperty("attribute_WMSApprovalTemplatePurpose");
	public static final String ATTRIBUTE_WMS_COMPLETION_DUE_DATE = PropertyUtil.getSchemaProperty("attribute_WMSCompletionDueDate");
	public static final String ATTRIBUTE_WMS_VALUE_OF_CONTRACT = PropertyUtil.getSchemaProperty("attribute_WMSValueOfContract");
	public static final String ATTRIBUTE_WMS_SOR_RATE = PropertyUtil.getSchemaProperty("attribute_WMSSORRate");
	public static final String ATTRIBUTE_WMS_SOR_ITEM_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSSORItemNumber");
	public static final String ATTRIBUTE_WMS_SOR_ITEM_CODE = PropertyUtil.getSchemaProperty("attribute_WMSSORItemCode");
	public static final String ATTRIBUTE_WMS_WORK_ORDER_TITLE = PropertyUtil.getSchemaProperty("attribute_WMSWorkorderTitle");
	
	//MEB attribute 
	public static final String ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSMBEActivityQuantity");
	public static final String ATTRIBUTE_WMS_BOQ_SERIAL_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSBOQSequenceNumber");
	public static final String ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE =  PropertyUtil.getSchemaProperty("attribute_WMSQtyPaidTillDate");
    public static final String ATTRIBUTE_WMS_REDUCED_SOR_RATE =  PropertyUtil.getSchemaProperty("attribute_WMSReducedSORRate"); 
    public static final String ATTRIBUTE_WMS_MBE_COST =  PropertyUtil.getSchemaProperty("attribute_WMSMBECost");
    public static final String ATTRIBUTE_WMS_MBE_QUANTITY =  PropertyUtil.getSchemaProperty("attribute_WMSMBEQuantity");
    public static final String ATTRIBUTE_WMS_TOTAL_QUANTITY =  PropertyUtil.getSchemaProperty("attribute_WMSTotalQuantity");
    public static final String ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE =  PropertyUtil.getSchemaProperty("attribute_WMSPercentageCompleteTillDate");
    public static final String ATTRIBUTE_WMS_PAYMENT_SCHEDULE_SEQUENCE =  PropertyUtil.getSchemaProperty("attribute_WMSPaymentScheduleSequence");

    
 
    public static final String ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE =  PropertyUtil.getSchemaProperty("attribute_WMSPercentageOfWeightage"); //remove
   
    public static final String ATTRIBUTE_WMS_IS_DEDUCTION = PropertyUtil.getSchemaProperty("attribute_WMSIsDeduction");
    public static final String ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR = PropertyUtil.getSchemaProperty("attribute_WMSItemCoEfficientFactor");
    public static final String ATTRIBUTE_WMS_QTY_SUBMITTED_TILL_DATE = PropertyUtil.getSchemaProperty("attribute_WMSQtySubmitedTillDate");
    public static final String ATTRIBUTE_WMS_MEASUREMENT_LOCATION = PropertyUtil.getSchemaProperty("attribute_WMSMeasurementLocation");
    public static final String ATTRIBUTE_WMS_MEASUREMENT_ADDRESS = PropertyUtil.getSchemaProperty("attribute_WMSMeasurementAddress");
    public static final String ATTRIBUTE_WMS_DATE_OF_MEASUREMENT = PropertyUtil.getSchemaProperty("attribute_WMSMBEDateOfMeasurementDate");
    
    public static final String ATTRIBUTE_WMS_MBE_FREQUENCY = PropertyUtil.getSchemaProperty("attribute_WMSMBEFrequency");
    public static final String ATTRIBUTE_WMS_MBE_DEPTH = PropertyUtil.getSchemaProperty("attribute_WMSMBEDepth");
    public static final String ATTRIBUTE_WMS_MBE_LENGTH = PropertyUtil.getSchemaProperty("attribute_WMSMBELength");
    public static final String ATTRIBUTE_WMS_MBE_RADIUS = PropertyUtil.getSchemaProperty("attribute_WMSMBERadius");
    public static final String ATTRIBUTE_WMS_MBE_BREADTH = PropertyUtil.getSchemaProperty("attribute_WMSMBEBreadth");
    public static final String ATTRIBUTE_WMS_PO_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSPONumber");
     public static final String ATTRIBUTE_WMS_UNIT_OF_MEASURE = PropertyUtil.getSchemaProperty("attribute_WMSUnitOfMeasure");
	 public static final String ATTRIBUTE_WMS_UWD = PropertyUtil.getSchemaProperty("attribute_WMSUWD");
	 public static final String ATTRIBUTE_WMS_MEASUREMENT_HISTORY = PropertyUtil.getSchemaProperty("attribute_WMSMeasurementHistory");
        
    
	//public static final String ATTRIBUTE_ABSMBE_ITEM_RATE = PropertyUtil.getSchemaProperty("attribute_WMSDeductionRate");
	//public static final String ATTRIBUTE_ITEM_TOTAL_DEDUCTION = PropertyUtil.getSchemaProperty("attribute_WMSTotalDeduction");
	public static final String ATTRIBUTE_WMS_ABSMBE_ITEM_TOTAL_COST = PropertyUtil.getSchemaProperty("attribute_WMSAMBItemTotalCost");
	public static final String ATTRIBUTE_WMS_TOTAL_COST = PropertyUtil.getSchemaProperty("attribute_WMSTotalCost");
	public static final String ATTRIBUTE_WMS_ABS_MBE_ITEM_COST = PropertyUtil.getSchemaProperty("attribute_WMSAbsMBEItemCost");
	public static final String ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSMBEActivityQuantity");
	public static final String ATTRIBUTE_WMS_PAYABLE_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEItemPayableQuantity");
	public static final String ATTRIBUTE_WMS_WITHHELD_CAUSE = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEItemWithheldCause");
	public static final String ATTRIBUTE_WMS_ITEMWITHHELD_RELEASED_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSItemWithHeldReleasedQuantity");
	
	
	
	   //ABSMBE
    public static final String TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY = PropertyUtil.getSchemaProperty("type_WMSAbstractMeasurementBookEntry");
 	public static final String ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RELEASE_AMOUNT= PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionReleaseAmount");
	public static final String ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionAmount");
	public static final String ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_TYPE= PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionType");
	public static final String ATTRIBUTE_WMS_CURRENT_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT= PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionReleaseCurrentBill");
	public static final String ATTRIBUTE_WMS_PREVIOUS_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT= PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionReleasePreviousBill");
	public static final String ATTRIBUTE_WMS_ABS_MBE_OID = PropertyUtil.getSchemaProperty("attribute_WMSAbsMBEOID");
	public static final String ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionQuanity");
	public static final String ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RATE= PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionRate");
	public static final String ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_BILL_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionBillQuanity");

	public static final String ATTRIBUTE_WMS_WORK_ORDER_DATE= PropertyUtil.getSchemaProperty("attribute_WMSWorkOrderDate");
	
	/** Advance particular
	 * 
	 * 
	 */
	
	public static final String ATTRIBUTE_WMS_BILL_REDUCTION_RELEASE_AMOUNT_TILL_DATE = PropertyUtil.getSchemaProperty("attribute_WMSBillReductionReleaseAmountTillDate");
	public static final String ATTRIBUTE_WMS_REDUCTION_RELEASE_AMOUNT_TILL_PREVIOUS = PropertyUtil.getSchemaProperty("attribute_WMSReductionReleaseAmountTillPrevious");
	public static final String ATTRIBUTE_WMS_BILL_REDUCTION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSBillReductionAmount");
	public static final String ATTRIBUTE_WMS_ABSTRACT_MBE_WITHHELD_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEWithHeldAmount");
	public static final String ATTRIBUTE_WMS_ABSTRACT_MBE_WITHHELD_RELEASED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEWithHeldReleasedAmount");
	
	public static final String ATTRIBUTE_WMS_ADVANCE_PARTICULARS = PropertyUtil.getSchemaProperty("attribute_WMSAdvanceParticulars");
	public static final String ATTRIBUTE_WMS_ADVANCE_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSAdvanceAmount");
	public static final String ATTRIBUTE_WMS_TYPE_OF_ADVANCE = PropertyUtil.getSchemaProperty("attribute_WMSTypeofAdvance");
	public static final String ATTRIBUTE_WMS_ADVANCE_REMARKS = PropertyUtil.getSchemaProperty("attribute_WMSAdvanceRemarks");
	public static final String ATTRIBUTE_WMS_RECOVERY_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSRecoveryAmount");
	public static final String ATTRIBUTE_WMS_RECOVERY_AMOUNT_TILL_PREVIOUS = PropertyUtil.getSchemaProperty("attribute_WMSRecoveryAmountTillPrevious");
	public static final String ATTRIBUTE_WMS_RECOVERY_REMARKS = PropertyUtil.getSchemaProperty("attribute_WMSRecoveryRemarks");
	public static final String ATTRIBUTE_WMS_ADVANCE_AMOUNT_RECOVER_TILL_DATE = PropertyUtil.getSchemaProperty("attribute_WMSAdvanceAmountRecoveredTillDate");
	public static final String ATTRIBUTE_WMS_ABSTRACT_MBE_PLANT_MACHINARY_ADVANCE_RECOVERED = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEPlantAndMachinaryAdvanceRecovered");
	public static final String ATTRIBUTE_WMS_ABSTRACT_MBE_MOBILISATION_ADVANCE_RECOVERED = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEMobilistionAdvanceRecovered");
	public static final String ATTRIBUTE_WMS_ABSTRACT_MBE_SECURED_ADVANCE_RECOVERED = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBESecuredAdvanceRecovered");
	public static final String ATTRIBUTE_WMS_ABSTRACT_MBE_PLANT_MACHINARY_ADVANCE_PAID = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEPlantAndMachinaryAdvancePaid");
	public static final String ATTRIBUTE_WMS_ABSTRACT_MBE_MOBILISATION_ADVANCE_PAID = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEMobilistionAdvancePaid");
	public static final String ATTRIBUTE_WMS_MBE_SECURED_ADVANCE_PAID = PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBESecuredAdvancePaid");
	
	public static final String ATTRIBUTE_WMS_MATERIAL_UOM = PropertyUtil.getSchemaProperty("attribute_WMSMaterialUOM");
	public static final String ATTRIBUTE_WMS_ADVANCE_RATE = PropertyUtil.getSchemaProperty("attribute_WMSAdvanceRate");
	public static final String ATTRIBUTE_WMS_BILL_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSBillNumber");
    public static final String ATTRIBUTE_WMS_MATERIAL_BILL_SUPPLIER = PropertyUtil.getSchemaProperty("attribute_WMSMaterialBillSupplier");
    public static final String ATTRIBUTE_WMS_BILL_DATE = PropertyUtil.getSchemaProperty("attribute_WMSBillDate");
    
    public static final String ATTRIBUTE_WMS_STOCK_ENTRIES_PHYSICAL_STOCK = PropertyUtil.getSchemaProperty("attribute_WMSStockEntriesPhysicalStock");
	public static final String ATTRIBUTE_WMS_STOCK_ENTRIES_PARTICULARS = PropertyUtil.getSchemaProperty("attribute_WMSStockEntriesParticulars");  
    public static final String ATTRIBUTE_WMS_STOCK_ENTRIES_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSStockEntriesQuantity");       
    public static final String ATTRIBUTE_WMS_STOCK_AVAILABLE_QTY = PropertyUtil.getSchemaProperty("attribute_WMSStockAvailableQty");
	public static final String ATTRIBUTE_WMS_STOCK_PENDING_QTY = PropertyUtil.getSchemaProperty("attribute_WMSStockPendingQty");
	public static final String ATTRIBUTE_WMS_STOCK_ENTRIES_RATE_PER_UNIT = PropertyUtil.getSchemaProperty("attribute_WMSStockEntriesRatePerUnit");
	public static final String ATTRIBUTE_WMS_STOCK_SGST = PropertyUtil.getSchemaProperty("attribute_WMSStockSGST");
	public static final String ATTRIBUTE_WMS_STOCK_CGST = PropertyUtil.getSchemaProperty("attribute_WMSStockCGST");
	public static final String ATTRIBUTE_WMS_STOCK_ENTRIES_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSStockEntriesAmount");
	public static final String ATTRIBUTE_WMS_CONVERSION_RATE = PropertyUtil.getSchemaProperty("attribute_WMSConversionRate");
	public static final String ATTRIBUTE_WMS_TRANSPORTATION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTransportationBillAmount");
	public static final String ATTRIBUTE_WMS_TRANSPORTATION_BILL_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSTransportationBillNumber");
	public static final String ATTRIBUTE_WMS_LOAD_UNLOAD_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSLoadUnloadAmount");
	public static final String ATTRIBUTE_WMS_STOCK_ENTRIES_TOTAL_COST = PropertyUtil.getSchemaProperty("attribute_WMSStockEntriesTotalCost");
	public static final String ATTRIBUTE_WMS_REDUCED_RATE_FOR_ADVANCE        = PropertyUtil.getSchemaProperty("attribute_WMSReducedRateforAdvance");
	public static final String ATTRIBUTE_WMS_MATERIAL_CONSUMPTION_QUANTITY   = PropertyUtil.getSchemaProperty("attribute_WMSMaterialConsumptionQuantity");
	    // public static final String ATTRIBUTE_WMS_STOCK_RECOVERY_AMOUNT           = PropertyUtil.getSchemaProperty("attribute_WMSStockRecoveryAmount");
	 public static final String ATTRIBUTE_WMS_SECURED_ADVANCE_TEMP            = PropertyUtil.getSchemaProperty("attribute_WMSSecuredAdvanceTemp");
	 public static final String ATTRIBUTE_WMS_STOCK_APPROVE_FOR_ADVANCE       = PropertyUtil.getSchemaProperty("attribute_WMSStockApproveforAdvance");
	public static final String ATTR_WMS_STOCK_ENTRIES_AMOUNT       = PropertyUtil.getSchemaProperty("attribute_WMSStockEntriesAmount"); 
	 public static final String ATTRIBUTE_WMS_REASON_FOR_NO_ADVANCE       = PropertyUtil.getSchemaProperty("attribute_WMSReasonforNoAdvance");
	
	//other head deduction
	
	  public static final String ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DEFAULT_VALUE = PropertyUtil.getSchemaProperty("attribute_WMSHeadDeductionDefaultValue");
	  public static final String ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DESCRIPTION = PropertyUtil.getSchemaProperty("attribute_WMSHeadDeductionDescription");
	  public static final String ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSHeadDeductionAmount");
	  public static final String ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_PER_STATUS = PropertyUtil.getSchemaProperty("attribute_WMSHeadDeductionCalculationUsingPercentStatus");
	  public static final String ATTRIBUTE_WMS_CONVERSION_FACTOR = PropertyUtil.getSchemaProperty("attribute_WMSConversionFactor");
 	  public static final String ATTRIBUTE_WMS_BASE_RATE = PropertyUtil.getSchemaProperty("attribute_WMSBaseRate");
 	  
 	  //SDP
 	  public static final String ATTRIBUTE_WMS_VALID_UNTIL_DATE = PropertyUtil.getSchemaProperty("attribute_WMSValidUntilDate");
 	  public static final String ATTRIBUTE_WMS_SUBMITED_BY = PropertyUtil.getSchemaProperty("attribute_WMSSubmittedBy");
 	  public static final String ATTRIBUTE_WMS_IS_MANDATORY_DELIVERABLES = PropertyUtil.getSchemaProperty("attribute_WMSIsMandatoryDeliverables");
 	  public static final String ATTRIBUTE_WMS_PERCENTAGE_CONTRACT_VALUE = PropertyUtil.getSchemaProperty("attribute_WMSPercentageOfContractValue");
 	  public static final String  ATTRIBUTE_WMS_CALCULATED_DOCUMENT_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSCalculatedDocumentAmount");
 	 public static final String  ATTRIBUTE_WMS_REVIEWED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSReviewedAmmount");
 	  
 	 
 	  
 	 
 	 
 	  
	/***********************************POlicy constants goes below**************************************************/
	public static final String POLICY_WMS_MEASUREMENT_ITEM= PropertyUtil.getSchemaProperty("policy_WMSMeasurementItem");
	public static final String POLICY_WMS_MEASUREMENT_BOOK_ENTRY= PropertyUtil.getSchemaProperty("policy_WMSMeasurementBookEntry");
	public static final String POLICY_WMS_ABSTRACT_MEASUREMENT_BOOKENTRY= PropertyUtil.getSchemaProperty("policy_WMSAbstractMeasurementBookEntry");
	public static final String POLICY_WMS_ABSTRACT_MEASUREMENT_BOOKENTRY_CANCELLED= PropertyUtil.getSchemaProperty("policy_WMSAbstractMeasurementBookEntryCancelled");
	
	public static final String POLICY_WMS_ADVANCE_RECOVERY_ITEM = PropertyUtil.getSchemaProperty("policy_WMSAdvanceRecoveryItem");
	
	//Material 
	public static final String POLICY_WMS_MATERIAL = PropertyUtil.getSchemaProperty("policy_WMSMaterialCategory");
	public static final String POLICY_WMS_STOCK_ENTRIES = PropertyUtil.getSchemaProperty("policy_WMSStockEntries");
	public static final String POLICY_WMS_MATERIAL_BILL = PropertyUtil.getSchemaProperty("policy_WMSMaterialBill");
	public static final String POLICY_WMS_MATERIAL_CONSUMPTION = PropertyUtil.getSchemaProperty("policy_WMSMaterialConsumption");
    public static final String STATE_PLAN = PropertyUtil.getSchemaProperty("policy",POLICY_WMS_ABSTRACT_MEASUREMENT_BOOKENTRY, "state_Paid");
    public static final String STATE_APPROVED = PropertyUtil.getSchemaProperty("policy",POLICY_WMS_ABSTRACT_MEASUREMENT_BOOKENTRY, "state_Approved");
    public static final String STATE_CANCELLED = PropertyUtil.getSchemaProperty("policy",POLICY_WMS_ABSTRACT_MEASUREMENT_BOOKENTRY, "state_Cancelled");
    public static final String STATE_MATERIAL_BILL_APPROVE = PropertyUtil.getSchemaProperty("policy",POLICY_WMS_MATERIAL_BILL, "state_Approved");
    public static final String STATE_MATERIAL_ACTIVE = PropertyUtil.getSchemaProperty("policy",POLICY_WMS_MATERIAL, "state_Active");
     
    public static final String STATE_STOCK_ENTRIES_STOCKED         = PropertyUtil.getSchemaProperty("policy",POLICY_WMS_STOCK_ENTRIES, "state_Stocked");
    public static final String STATE_STOCK_ENTRIES_CONSUMED        = PropertyUtil.getSchemaProperty("policy",POLICY_WMS_STOCK_ENTRIES, "state_Consumed");
	
    public static final  String TYPE_DELIVERABLE1 = PropertyUtil.getSchemaProperty("type_Deliverable1");
    public static final  String ATTRIBUTE_SUBMITTED_DATE = PropertyUtil.getSchemaProperty("attribute_SubmittedDate");
	
	public static final String ATTRIBUTE_ROUTE_COMPLETION_ACTION = PropertyUtil.getSchemaProperty("attribute_RouteCompletionAction");
	
	public static final String ATTRIBUTE_WMSECVIBM_VALUE = PropertyUtil.getSchemaProperty("attribute_WMSECVIBM");
	

	public static final String TYPE_WMSRETENTION_RECOVERYITEM = PropertyUtil.getSchemaProperty("type_WMSRetentionRecoveryItem");
	public static final String POLICY_WMSRETENTION_RECOVERYITEM = PropertyUtil.getSchemaProperty("policy_WMSRetentionRecoveryItem");
	public static final String RELATIONSHIP_WMSAMBRETENTION_RECOVERY = PropertyUtil.getSchemaProperty("relationship_WMSAMBRetentionRecovery");
	public static final String ATTRIBUTE_WMSRETENTION_PERCENTAGE = PropertyUtil.getSchemaProperty("attribute_WMSRetentionPercentage");
	public static final String ATTRIBUTE_WMSPAYMENTITEM_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSPaymentItemAmount");
	public static final String RELATIONSHIP_WMSWORKORDER_RETUNTIONRECOVERY = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderRetentionRecovery");
	public static final String ATTRIBUTE_WMS_SHAPE_IMAGE = PropertyUtil.getSchemaProperty("attribute_WMSShapeImage");
	public static final String ATTRIBUTE_WMS_DIMENSION_1 = PropertyUtil.getSchemaProperty("attribute_WMSDimension1");
	public static final String ATTRIBUTE_WMS_DIMENSION_2 = PropertyUtil.getSchemaProperty("attribute_WMSDimension2");
	public static final String ATTRIBUTE_WMS_DIMENSION_3 = PropertyUtil.getSchemaProperty("attribute_WMSDimension3");
	public static final String ATTRIBUTE_WMS_DIMENSION_4 = PropertyUtil.getSchemaProperty("attribute_WMSDimension4");
	public static final String ATTRIBUTE_WMS_IS_MANUALQUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSIsManualQuanity");	
	public static final String ATTRIBUTE_WMS_MBE_FINALIZED = PropertyUtil.getSchemaProperty("attribute_WMSMBEFinalized");
	public static final String ATTRIBUTE_WMS_MBE_TYPE = PropertyUtil.getSchemaProperty("attribute_WMSMBEType");
	public static final String ATTRIBUTE_WMS_TYPE_OF_CONTRACT = PropertyUtil.getSchemaProperty("attribute_WMSTypeOfContract");
	public static final String ATTRIBUTE_WMS_SHAPE_NAME = PropertyUtil.getSchemaProperty("attribute_WMSShapeName");

	public static final String  RELATIONSHIP_WMS_AMBPAYMENTS = PropertyUtil.getSchemaProperty("relationship_WMSAMBPayments");
	public static final String  ATTRIBUTE_TITLE = PropertyUtil.getSchemaProperty("attribute_Title");
	public static final String  ATTRIBUTE_WMS_CONTRACTOR_REVIEW = PropertyUtil.getSchemaProperty("attribute_WMSContrectorReview");
	public static final String  ATTRIBUTE_WMS_CONTRACTOR_APPROVELSENTDATE = PropertyUtil.getSchemaProperty("attribute_WMSContractorApprovalSentDate");

	public static final String  RELATIONSHIP_WMS_RELATED_MBE = PropertyUtil.getSchemaProperty("relationship_WMSRelatedMBE");
	public static final String  ATTRIBUTE_WMS_SE_VALIDATED = PropertyUtil.getSchemaProperty("attribute_WMSSEValidated");
	public static final String  ATTRIBUTE_WMS_EE_VALIDATED = PropertyUtil.getSchemaProperty("attribute_WMSEEValidated");
	
	public static final String  RELATIONSHIP_WMS_WORKORDER_PMC_CONSULTANT = PropertyUtil.getSchemaProperty("relationship_PRBWorkOrderPMCConsultant");
	
	public static final String  ATTRIBUTE_WMS_ABS_START_DATE = PropertyUtil.getSchemaProperty("attribute_WMSAbsBillStartDate");
	public static final String  ATTRIBUTE_WMS_ABS_END_DATE = PropertyUtil.getSchemaProperty("attribute_WMSAbsBillEndDate");
	public static final String  ATTRIBUTE_WMS_IS_MODIFIED = PropertyUtil.getSchemaProperty("attribute_WMSIsModified");
	public static final String  ATTRIBUTE_WMS_IS_SHAPE = PropertyUtil.getSchemaProperty("attribute_WMSIsShape");
	public static final String  ATTRIBUTE_WMS_CONTRACTOR_COMMENT = PropertyUtil.getSchemaProperty("attribute_WMSContrectorReviewComment");
	public static final String  ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY = PropertyUtil.getSchemaProperty("attribute_WMSMeasurementApprovalHistory");
	public static final String  ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE = PropertyUtil.getSchemaProperty("attribute_WMSMeasurementTaskType");
	public static final String  ATTRIBUTE_WMS_MEASUREMENT_SCOPE = PropertyUtil.getSchemaProperty("attribute_WMSMeasurementScope");
	public static final String RELATIONSHIP_WMS_WORKORDER_ROYALTY_CHARGES = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderRoyaltyCharges");
	public static final String RELATIONSHIP_WMS_ROYALTY_CHARGES = PropertyUtil.getSchemaProperty("relationship_WMSRoyaltyCharges");
	public static final String TYPE_WMS_ROYALTY_CHARGES = PropertyUtil.getSchemaProperty("type_WMSRoyaltyCharges");
	public static final String POLICY_WMS_ROYALTY_CHARGES = PropertyUtil.getSchemaProperty("policy_WMSRoyaltyChargesPolicy"); 
	public static final String  ATTRIBUTE_WMS_SOR_UOM = PropertyUtil.getSchemaProperty("attribute_WMSSORUnitOfMeasure");
	public static final String  ATTRIBUTE_WMS_TOTAL_PAYABLE_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTotalPayableAmount");
	
	//added for eSign
	public static final String ATTRIBUTE_WMS_FILE_HASH_CODE = PropertyUtil.getSchemaProperty("attribute_WMSFileHashCode");
	public static final String ATTRIBUTE_WMS_E_VEFIRY = PropertyUtil.getSchemaProperty("attribute_WMSEVerify");
	public static final String ATTRIBUTE_WMS_RESPONSE_HASHCODE = PropertyUtil.getSchemaProperty("attribute_WMSResponseHashCode");
	

	public static final String  ATTRIBUTE_HOST_ROLE = PropertyUtil.getSchemaProperty("attribute_HostPersonRole");
	public static final String  ATTRIBUTE_WMS_TYPE_OF_COMPANY = PropertyUtil.getSchemaProperty("attribute_PRBTypeOfCompany");
	public static final String  ATTRIBUTE_WMS_RETENTION_RECOVERED = PropertyUtil.getSchemaProperty("attribute_WMSRetentionRecovered");
	public static final String  ATTRIBUTE_WMS_WORK_ORDER_ACCESS = PropertyUtil.getSchemaProperty("attribute_WMSWorkOrderAccess");
	public static final String  ATTRIBUTE_WMS_RETENTION_REMARK = PropertyUtil.getSchemaProperty("attribute_WMSRetentionRemarks");
	public static final String  ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSRecoveryEntryAmount");
	public static final String  ATTRIBUTE_ASSESSMENT_COMMENTS = PropertyUtil.getSchemaProperty("attribute_AssessmentComments");
	public static final String  ATTRIBUTE_WMS_OTHER_DEDUCTION_PERCENTAGE = PropertyUtil.getSchemaProperty("attribute_WMSHeadDeductionPercentage");
	
	public static final String  RELATIONSHIP_WMS_BILL_QUALITY_CERTIFICATES = PropertyUtil.getSchemaProperty("relationship_WMSBillQualityCertificate");
	public static final String TYPE_WMS_QUALITY_CERTIFICATE = PropertyUtil.getSchemaProperty("type_WMSQualityCertificate");
	public static final String  RELATIONSHIP_WMS_BILL_RATE_ESCALATION = PropertyUtil.getSchemaProperty("relationship_WMSAbsMBERateEscalation");
	public static final String  RELATIONSHIP_WMS_WORKORDER_RATE_ESCALATION = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderRateEscalation");
	public static final String TYPE_WMS_RATE_ESCALATION = PropertyUtil.getSchemaProperty("type_WMSRateEscalation");
	public static final String POLICY_WMS_RATE_ESCALATION = PropertyUtil.getSchemaProperty("policy_WMSRateEscalationPolicy"); 
	public static final String  ATTRIBUTE_WMS_CHANGE_ORDER_VALUE = PropertyUtil.getSchemaProperty("attribute_WMSChangeOrderValue");
	public static final String  ATTRIBUTE_WMS_REMARK = PropertyUtil.getSchemaProperty("attribute_WMSRemarks");
	public static final String  ATTRIBUTE_WMS_HEAD_DEDUCTION_REMARKS = PropertyUtil.getSchemaProperty("attribute_WMSHeadDeductionRemarks");
	public static final String  ATTRIBUTE_WMS_BILL_REDUCTION_REMARK = PropertyUtil.getSchemaProperty("attribute_WMSBillReductionRemarks");
	public static final String  ATTRIBUTE_WMS_BILL_REDUCTION_RELEASE_REMARK = PropertyUtil.getSchemaProperty("attribute_WMSReductionReleaseRemarks");
	public static final String  ATTRIBUTE_WMS_RETENSION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSRetensionAmount");
	public static final String  ATTRIBUTE_WMS_VALIDATE_ROLE = PropertyUtil.getSchemaProperty("attribute_WMSValidateRole");
	public static final String TYPE_WMS_MBE_VALIDATE = PropertyUtil.getSchemaProperty("type_WMSMBEValidate");	
	public static final String  RELATIONSHIP_WMS_MBE_VALIDATE = PropertyUtil.getSchemaProperty("relationship_WMSMBEValidate");
	public static final String POLICY_WMS_MBE_VALIDATE = PropertyUtil.getSchemaProperty("policy_WMSMBEValidate"); 
	
	public static final String  ATTRIBUTE_WMS_CERTIFIED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSCertifiedAmount");
	public static final String  ATTRIBUTE_WMS_INVOICED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSInvoicedAmount");
	public static final String  ATTRIBUTE_WMS_IS_LD_ITEM = PropertyUtil.getSchemaProperty("attribute_WMSIsLDItem");
	public static final String  ATTRIBUTE_WMS_IS_COMMENTED = PropertyUtil.getSchemaProperty("attribute_WMSIsCommented");
	
	public static final String sTypeInboxTask = PropertyUtil.getSchemaProperty("type_InboxTask");
	
	public static final String TYPE_WMS_SUPPLIMENTARY_AGREEMENT = PropertyUtil.getSchemaProperty("type_WMSSupplimentaryAgreement");	
	public static final String  RELATIONSHIP_WMS_WORKORDER_SUPPLIMENTARY_AGREEMENT = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderSupplimentaryAgreement");
	public static final String  RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ = PropertyUtil.getSchemaProperty("relationship_WMSSupplimentaryAgreementBOQ");
	public static final String POLICY_WMS_SUPPLIMENTARY_AGREEMENT = PropertyUtil.getSchemaProperty("policy_WMSSupplimentaryAgreement"); 
	public static final String  ATTRIBUTE_WMS_CHANGE_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSChangeQuantity");
	public static final String  ATTRIBUTE_WMS_PREV_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSPrevQuantity");

	public static final String  ATTRIBUTE_WMS_SUPP_AGREEMENT_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSSupAgreementNumber");
	public static final String  ATTRIBUTE_WMS_SUPP_AGREEMENT_DATE = PropertyUtil.getSchemaProperty("attribute_WMSSupAgreementDate");
	
	public static final String POLICY_WMS_MEASUREMENT_BOOK_ENTRY_NONEPC = PropertyUtil.getSchemaProperty("policy_WMSMeasurementBookEntryNonEPC"); 
	public static final String  RELATIONSHIP_WMS_MBE_FORMAL_APPROVAL_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSMBEFormalApprovalTemplate");
	public static final String  RELATIONSHIP_WMS_BOQ_SUB_ITEMS = PropertyUtil.getSchemaProperty("relationship_WMSBOQSubItems");
	
	public static final String  ATTRIBUTE_WMS_PROJECT_CODE = PropertyUtil.getSchemaProperty("attribute_PRBProjectCode");
	public static final String  ATTRIBUTE_WMS_RETENSION_AMOUNT_PAID_TILL_DATE = PropertyUtil.getSchemaProperty("attribute_WMSRetensionAmountPaidTillDate");
	public static final String  ATTRIBUTE_WMS_GST_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSGSTNumber");
	public static final String  ATTRIBUTE_WMS_PAN_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSPANNumber");
	public static final String  ATTRIBUTE_WMS_RECOVERY_INTEREST = PropertyUtil.getSchemaProperty("attribute_WMSRecoveryInterest");
	public static final String  ATTRIBUTE_WMS_TIME_ALLOWED = PropertyUtil.getSchemaProperty("attribute_WMSTimeAllowed");
	public static final String  ATTRIBUTE_WMS_DEVIATION_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSDeviationQuantity");
	public static final String  ATTRIBUTE_WMS_FORMALIZED = PropertyUtil.getSchemaProperty("attribute_WMSFormalized");
	public static final String ATTRIBUTE_REDUCTION_RELEASE_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSReductionReleaseAmount");
	public static final String ATTRIBUTE_WMS_RC_APPLICABLE = PropertyUtil.getSchemaProperty("attribute_WMSRCApplicable");
	public static final String ATTRIBUTE_WMS_WO_AGREEMENT_DATE = PropertyUtil.getSchemaProperty("attribute_WMSWOAgreementDate");
	public static final String ATTRIBUTE_WMS_E_TOKEN_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSeTokenNumber");
	public static final String ATTRIBUTE_WMS_SIGNED_FILE_HASH = PropertyUtil.getSchemaProperty("attribute_WMSSignedFileHash");
	public static final String ATTRIBUTE_WMS_TOKEN_FILE_HASH = PropertyUtil.getSchemaProperty("attribute_WMSeTokenFileHash");
	public static final String ATTRIBUTE_WMS_TOKEN_SIGNED_FILE_HASH = PropertyUtil.getSchemaProperty("attribute_WMSeTokenSignedFileHash");
	public static final String ATTRIBUTE_WMS_TOKEN_RESPONCE_HASH = PropertyUtil.getSchemaProperty("attribute_WMSeTokenResponceHash");
	
	public static final String  RELATIONSHIP_WMS_REFERENCE_DOCUMENTS = PropertyUtil.getSchemaProperty("relationship_WMSReferenceDocuments");
	
	
	public static final String POLICY_WMS_BILL_CERTIFICATES = PropertyUtil.getSchemaProperty("policy_WMSBillCertificates"); 
	public static final String TYPE_WMS_BILL_CERTIFICATES = PropertyUtil.getSchemaProperty("type_WMSBillCertificates"); 
	public static final String RELATIONSHIP_WMS_BILL_CERTIFICATES = PropertyUtil.getSchemaProperty("relationship_WMSBillCertificate"); 
	
	public static final String POLICY_WMS_BILL_OTHER_ADDITION = PropertyUtil.getSchemaProperty("policy_WMSBillOtherAddition"); 
	public static final String TYPE_WMS_BILL_OTHER_ADDITION = PropertyUtil.getSchemaProperty("type_WMSBillOtherAddition"); 
	public static final String RELATIONSHIP_WMS_BILL_OTHER_ADDITION = PropertyUtil.getSchemaProperty("relationship_WMSBillOtherAddition"); 
	
	public static final String POLICY_WMS_BG = PropertyUtil.getSchemaProperty("policy_WMSBankGuarantees"); 
	public static final String TYPE_WMS_BG = PropertyUtil.getSchemaProperty("type_WMSBankGuarantees"); 
	public static final String RELATIONSHIP_WMS_BG = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderBG"); 
	
	public static final String POLICY_WMS_CHECKLIST = PropertyUtil.getSchemaProperty("policy_WMSCheckList"); 
	public static final String TYPE_WMS_CHECKLIST = PropertyUtil.getSchemaProperty("type_WMSCheckList"); 
	public static final String RELATIONSHIP_WMS_CHECKLIST = PropertyUtil.getSchemaProperty("relationship_WMSCheckList"); 
	
	public static final String ATTRIBUTE_WMS_IS_LIBRARY = PropertyUtil.getSchemaProperty("attribute_WMSIsLibrary");
	public static final String ATTRIBUTE_WMS_RECURRENCE = PropertyUtil.getSchemaProperty("attribute_WMSRecurrence");
	public static final String ATTRIBUTE_WMS_CHECKED = PropertyUtil.getSchemaProperty("attribute_WMSChecked");
	public static final String ATTRIBUTE_WMS_REFERENCE_TO = PropertyUtil.getSchemaProperty("attribute_WMSReferenceTo");
	public static final String ATTRIBUTE_WMS_ABS_MBE_TYPE = PropertyUtil.getSchemaProperty("attribute_WMSAbsMBEType");
	
	public static final String RELATIONSHIP_WMS_CERTIFICATE_CLASSIFICATION_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSCertificateClassificationToTemplate"); 
	public static final String RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderToCertificateTemplate"); 
	public static final String RELATIONSHIP_WMS_AMB_CERTIFICATE_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBEToCertificateTemplate"); 
	public static final String TYPE_WMS_CERTIFICATE_TEMPLATE = PropertyUtil.getSchemaProperty("type_WMSCertificateTemplate");
	public static final String TYPE_WMS_CERTIFICATE_CLASSIFICATION = PropertyUtil.getSchemaProperty("type_WMSCertificateClassification");
	public static final String ATTRIBUTE_WMS_RESPONSIBLE_ROLE = PropertyUtil.getSchemaProperty("attribute_WMSResponsibleRole");
	public static final String ATTRIBUTE_WMS_ADDED_BY = PropertyUtil.getSchemaProperty("attribute_WMSAddedBy");
	public static final String ATTRIBUTE_WMS_ADDED_ON = PropertyUtil.getSchemaProperty("attribute_WMSAddedOn");	
	public static final String ATTRIBUTE_WMS_IS_MANDATORY = PropertyUtil.getSchemaProperty("attribute_WMSIsManditary");	
	public static final String ATTRIBUTE_WMS_ENABLE_ESIGN = PropertyUtil.getSchemaProperty("attribute_WMSEnableESign");	
	public static final String ATTRIBUTE_WMSCODE_HEAD_NAME = PropertyUtil.getSchemaProperty("attribute_WMSCodeHeadName");	

	//SOC
	public static final String TYPE_WMSSOC = PropertyUtil.getSchemaProperty("type_WMSSOC");
	public static final String POLICY_WMSSOC = PropertyUtil.getSchemaProperty("policy_WMSSOC");
	public static final String ATTRIBUTE_WMSSOC_ROUGH_INDICATIVE_COST = PropertyUtil.getSchemaProperty("attribute_WMSSOCRoughIndicativeCost");
	public static final String ATTRIBUTE_WMSSOC_FINANCIAL_YEAR = PropertyUtil.getSchemaProperty("attribute_WMSSOCFinancialYear");
	public static final String ATTRIBUTE_WMSSOC_PROJECT_TYPE = PropertyUtil.getSchemaProperty("attribute_WMSSOCProjectType");
	public static final String ATTRIBUTE_WMSSOC_COMMENTS = PropertyUtil.getSchemaProperty("attribute_WMSSOCComments");
	public static final String ATTRIBUTE_WMSSOC_EQUIPMENTS_INCLUDED = PropertyUtil.getSchemaProperty("attribute_WMSSOCEquipementsIncluded");
	public static final String ATTRIBUTE_WMSSOC_WORKS_INCLUDED = PropertyUtil.getSchemaProperty("attribute_WMSSOCWorksIncluded");
	public static final String ATTRIBUTE_WMSSOC_SERVICES_INCLUDED = PropertyUtil.getSchemaProperty("attribute_WMSSOCServicesIncluded");
	public static final String RELATIONSHIP_WMSPROJECTSOC = PropertyUtil.getSchemaProperty("relationship_WMSProjectSOC");
	public static final String RELATIONSHIP_WMS_BUDGETORY_QUOTES = PropertyUtil.getSchemaProperty("relationship_WMSBudgetoryQuotes");
	public static final String RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE= PropertyUtil.getSchemaProperty("relationship_WMSSOCApprovalTemplate");
	public static final String RELATIONSHIP_WMSSOC_SYSTEMREFERENCEDOCUMENT = PropertyUtil.getSchemaProperty("relationship_WMSSOCSystemReferenceDocument");
	public static final String ATTRIBUTE_WMSSOC_SUBMITTED = PropertyUtil.getSchemaProperty("attribute_WMSSOCSubmitted");
	
	// RIC
	public static final String TYPE_WMSRICMASTER = PropertyUtil.getSchemaProperty("type_WMSRICMaster");
	public static final String TYPE_WMSRIC = PropertyUtil.getSchemaProperty("type_WMSRIC");
	public static final String TYPE_WMSRICITEM = PropertyUtil.getSchemaProperty("type_WMSRICItem");
	public static final String POLICY_WMSRICMASTER = PropertyUtil.getSchemaProperty("policy_WMSRICMaster");
	public static final String POLICY_WMSRIC = PropertyUtil.getSchemaProperty("policy_WMSRIC");
	public static final String POLICY_WMSRICITEM = PropertyUtil.getSchemaProperty("policy_WMSRICItem");
	public static final String STATE_WMSRICMASTER_CREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSRICMASTER, "state_Create");
	public static final String STATE_WMSRICMASTER_REVIEW = PropertyUtil.getSchemaProperty("policy",POLICY_WMSRICMASTER, "state_Review");
	public static final String STATE_WMSRICMASTER_APPROVED = PropertyUtil.getSchemaProperty("policy",POLICY_WMSRICMASTER, "state_Approved");
	public static final String STATE_WMSRIC_CREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSRIC, "state_Create");
	public static final String STATE_WMSRIC_REVIEW = PropertyUtil.getSchemaProperty("policy",POLICY_WMSRIC, "state_Review");
	public static final String STATE_WMSRIC_APPROVED = PropertyUtil.getSchemaProperty("policy",POLICY_WMSRIC, "state_Approved");
	public static final String RELATIONSHIP_WMSSOC_RICMASTER = PropertyUtil.getSchemaProperty("relationship_WMSSOCRICMaster");
	public static final String RELATIONSHIP_WMSRICMASTER_RIC = PropertyUtil.getSchemaProperty("relationship_WMSRICMasterRIC");
	public static final String RELATIONSHIP_WMSRIC_RIC = PropertyUtil.getSchemaProperty("relationship_WMSRICRIC");
	public static final String RELATIONSHIP_WMSRIC_RICITEM = PropertyUtil.getSchemaProperty("relationship_WMSRICRICItem");
	public static final String RELATIONSHIP_WMSRICMASTER_APPROVAL_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSRICMasterApprovalTemplate");
		
	// AE
	public static final String TYPE_WMSAEMASTER = PropertyUtil.getSchemaProperty("type_WMSAEMaster");
	public static final String TYPE_WMSAE = PropertyUtil.getSchemaProperty("type_WMSAE");
	public static final String TYPE_WMSAEITEM = PropertyUtil.getSchemaProperty("type_WMSAEItem");
	public static final String POLICY_WMSAEMASTER = PropertyUtil.getSchemaProperty("policy_WMSAEMaster");
	public static final String POLICY_WMSAE = PropertyUtil.getSchemaProperty("policy_WMSAE");
	public static final String POLICY_WMSAEITEM = PropertyUtil.getSchemaProperty("policy_WMSAEItem");
	public static final String STATE_WMSAEMASTER_CREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSAEMASTER, "state_Create");
	public static final String STATE_WMSAEMASTER_REVIEW = PropertyUtil.getSchemaProperty("policy",POLICY_WMSAEMASTER, "state_Review");
	public static final String STATE_WMSAEMASTER_APPROVED = PropertyUtil.getSchemaProperty("policy",POLICY_WMSAEMASTER, "state_Approved");
	public static final String STATE_WMSAE_CREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSAE, "state_Create");
	public static final String STATE_WMSAE_REVIEW = PropertyUtil.getSchemaProperty("policy",POLICY_WMSAE, "state_Review");
	public static final String STATE_WMSAE_APPROVED = PropertyUtil.getSchemaProperty("policy",POLICY_WMSAE, "state_Approved");
	public static final String RELATIONSHIP_WMSSOC_AEMASTER = PropertyUtil.getSchemaProperty("relationship_WMSSOCAEMaster");
	public static final String RELATIONSHIP_WMSAEMASTER_AE = PropertyUtil.getSchemaProperty("relationship_WMSAEMasterAE");
	public static final String RELATIONSHIP_WMSAE_AE = PropertyUtil.getSchemaProperty("relationship_WMSAEAE");
	public static final String RELATIONSHIP_WMSAE_AEITEM = PropertyUtil.getSchemaProperty("relationship_WMSAEAEItem");
	public static final String RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSAEMasterApprovalTemplate");
	public static final String RELATIONSHIP_WMSSOC_APPROVEDAEMASTER = PropertyUtil.getSchemaProperty("relationship_WMSSOCApprovedAEMaster");
	public static final String RELATIONSHIP_WMSAEREVISE_REFERENCEDOCUMENT = PropertyUtil.getSchemaProperty("relationship_WMSAEReviseReferenceDocument");
	public static final String RELATIONSHIP_WMSAPPROVEDAE_REVISEREFERENCEDOCUMENT = PropertyUtil.getSchemaProperty("relationship_WMSApprovedAEReviseReferenceDocument");

	//DCS
	public static final String TYPE_WMSDCSMASTER = PropertyUtil.getSchemaProperty("type_WMSDCSMaster");
	public static final String TYPE_WMSDCS = PropertyUtil.getSchemaProperty("type_WMSDCS");
	public static final String TYPE_WMSDCSITEM = PropertyUtil.getSchemaProperty("type_WMSDCSItem");
	public static final String POLICY_WMSDCSMASTER = PropertyUtil.getSchemaProperty("policy_WMSDCSMaster");
	public static final String POLICY_WMSDCS = PropertyUtil.getSchemaProperty("policy_WMSDCS");
	public static final String POLICY_WMSDCSITEM = PropertyUtil.getSchemaProperty("policy_WMSDCSItem");
	public static final String STATE_WMSDCSMASTER_CREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSDCSMASTER, "state_Create");
	public static final String STATE_WMSDCSMASTER_REVIEW = PropertyUtil.getSchemaProperty("policy",POLICY_WMSDCSMASTER, "state_Review");
	public static final String STATE_WMSDCSMASTER_APPROVED = PropertyUtil.getSchemaProperty("policy",POLICY_WMSDCSMASTER, "state_Approved");	
	public static final String RELATIONSHIP_WMSSOC_DCSMASTER = PropertyUtil.getSchemaProperty("relationship_WMSSOCDCSMaster");
	public static final String RELATIONSHIP_WMSDCSMASTER_DCS = PropertyUtil.getSchemaProperty("relationship_WMSDCSMasterDCS");
	public static final String RELATIONSHIP_WMSDCS_DCS = PropertyUtil.getSchemaProperty("relationship_WMSDCSDCS");
	public static final String RELATIONSHIP_WMSDCS_DCSITEM = PropertyUtil.getSchemaProperty("relationship_WMSDCSDCSItem");
	public static final String RELATIONSHIP_WMSDCSMASTER_APPROVAL_TEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSDCSMasterApprovalTemplate");
	public static final String RELATIONSHIP_WMSDCS_AE = PropertyUtil.getSchemaProperty("relationship_WMSDCSAE");
	public static final String RELATIONSHIP_WMSDCSMASTERREVISE_REFERENCEDOCUMENT = PropertyUtil.getSchemaProperty("relationship_WMSDCSMasterReviseReferenceDocument");
		
	public static final String ATTRIBUTE_RATE = PropertyUtil.getSchemaProperty("attribute_Rate");
	public static final String ATTRIBUTE_WMSGST = PropertyUtil.getSchemaProperty("attribute_WMSGST");
	public static final String ATTRIBUTE_WMSCONTINGENCY = PropertyUtil.getSchemaProperty("attribute_WMSContingency");
	public static final String ATTRIBUTE_WMSCONSULTANCY = PropertyUtil.getSchemaProperty("attribute_WMSConsultancy");
	public static final String ATTRIBUTE_WMSDCSMASTERID = PropertyUtil.getSchemaProperty("attribute_WMSDCSMasterId");
	public static final String ATTRIBUTE_WMSITEMSEQUENCE = PropertyUtil.getSchemaProperty("attribute_WMSItemSequence");
	public static final String ATTRIBUTE_WMSTOTALAMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTotalAmount");
	public static final String ATTRIBUTE_WMSAUTHORIZED = PropertyUtil.getSchemaProperty("attribute_WMSAuthorized");
	public static final String ATTRIBUTE_WMSUSER = PropertyUtil.getSchemaProperty("attribute_WMSUser");
	public static final String ATTRIBUTE_WMSSTATION = PropertyUtil.getSchemaProperty("attribute_WMSStation");
	
   //Admin Approvals
	public static final String ATTRIBUTE_WMSADMINAPPROVALAMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSAdminApprovalAmount");
	public static final String ATTRIBUTE_WMSADMINAPPROVALDATE = PropertyUtil.getSchemaProperty("attribute_WMSAdminApprovalDate");
	public static final String ATTRIBUTE_WMSADMINAPPROVALDURATION = PropertyUtil.getSchemaProperty("attribute_WMSApprovedDuration");
	public static final String TYPE_WMSADMINAPPROVAL = PropertyUtil.getSchemaProperty("type_WMSAdminApproval");
	public static final String POLICY_WMSADMINAPPROVAL = PropertyUtil.getSchemaProperty("policy_WMSAdminApproval");
	public static final String RELATIONSHIP_WMSSOCADMINAPPROVAL = PropertyUtil.getSchemaProperty("relationship_WMSSOCAdminApproval");
	public static final String STATE_AAAPPROVED = PropertyUtil.getSchemaProperty("policy",POLICY_WMSADMINAPPROVAL, "state_Approved");
	public static final String STATE_AACREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSADMINAPPROVAL, "state_Create");
	public static final String STATE_AAREVIEW = PropertyUtil.getSchemaProperty("policy",POLICY_WMSADMINAPPROVAL, "state_Review");
	
	//Delegation
	public static final String ATTRIBUTE_WMSAPPROVEDEQUIPMENT = PropertyUtil.getSchemaProperty("attribute_WMSApprovedAmountEquipment");
	public static final String ATTRIBUTE_WMSAPPROVEDWORK = PropertyUtil.getSchemaProperty("attribute_WMSApprovedAmountWork");
	public static final String ATTRIBUTE_WMSAPPROVEDWORKCONTIGENCY = PropertyUtil.getSchemaProperty("attribute_WMSWorksContingency");
	public static final String ATTRIBUTE_WMSAPPROVEDPLANNING = PropertyUtil.getSchemaProperty("attribute_WMSApprovedAmountPlanning");
	public static final String ATTRIBUTE_WMSAPPROVEDEQUIPMENTREMARKS = PropertyUtil.getSchemaProperty("attribute_WMSApprovedEquipmentRemarks");
	public static final String ATTRIBUTE_WMSAPPROVEDWORKREMARKS = PropertyUtil.getSchemaProperty("attribute_WMSApprovedWorkRemarks");
	public static final String ATTRIBUTE_WMSAPPROVEDPLANNINGREMARKS = PropertyUtil.getSchemaProperty("attribute_WMSApprovedPlanningRemarks");	
	public static final String TYPE_WMSDELEGATION = PropertyUtil.getSchemaProperty("type_WMSDelegation");
	public static final String POLICY_WMSDELEGATION = PropertyUtil.getSchemaProperty("policy_WMSDelegation");
	public static final String RELATIONSHIP_WMSSOCDELEGATION = PropertyUtil.getSchemaProperty("relationship_WMSSOCDelegation");
    public static final String STATE_DELEGATECREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSDELEGATION, "state_Create");
	public static final String STATE_DELEGATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSDELEGATION, "state_Delegate");
	public static final String RELATIONSHIP_WMSAUTHORIZED = PropertyUtil.getSchemaProperty("relationship_WMSWOOAuthorized");
	public static final String ATTRIBUTE_REMARKS = PropertyUtil.getSchemaProperty("attribute_Remarks");
	
	//Technical Sanction
	public static final String TYPE_WMSTECHNICALSANCTION = PropertyUtil.getSchemaProperty("type_WMSTechnicalSanction");
	public static final String POLICY_WMSTECHNICALSANCTION = PropertyUtil.getSchemaProperty("policy_WMSTechnicalSanction");
	public static final String STATE_WMSTECHNICALSANCTION_CREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSTECHNICALSANCTION, "state_Create");
	public static final String STATE_WMSTECHNICALSANCTION_REVIEW = PropertyUtil.getSchemaProperty("policy",POLICY_WMSTECHNICALSANCTION, "state_Review");
	public static final String STATE_WMSTECHNICALSANCTION_APPROVED = PropertyUtil.getSchemaProperty("policy",POLICY_WMSTECHNICALSANCTION, "state_Approved");
	public static final String STATE_WMSTECHNICALSANCTION_OBSOLETE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSTECHNICALSANCTION, "state_Obsolete");
	public static final String RELATIONSHIP_WMSDCSTS = PropertyUtil.getSchemaProperty("relationship_WMSDCSTS");
	public static final String RELATIONSHIP_WMSSOCTS = PropertyUtil.getSchemaProperty("relationship_WMSSOCTS");
	public static final String ATTRIBUTE_WMSTSAMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTSAmount");
	
	public static final String RELATIONSHIP_WMSTSAPPROVALTEMPLATE = PropertyUtil.getSchemaProperty("relationship_WMSTSApprovalTemplate");
	//WOO
	public static final String TYPE_WMSWOO = PropertyUtil.getSchemaProperty("type_WMSWOO");
	public static final String POLICY_WMSWOO = PropertyUtil.getSchemaProperty("policy_WMSWOO");
	public static final String STATE_WMSWOO_CREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSWOO, "state_Create");
	public static final String STATE_WMSWOO_REVIEW = PropertyUtil.getSchemaProperty("policy",POLICY_WMSWOO, "state_Review");
	public static final String STATE_WMSWOO_APPROVED = PropertyUtil.getSchemaProperty("policy",POLICY_WMSWOO, "state_Approved");
	public static final String RELATIONSHIP_WMSSOC_WOO = PropertyUtil.getSchemaProperty("relationship_WMSSOCWOO");
	public static final String RELATIONSHIP_WMSWOO_REVISE_REFERENCEDOCUMENT = PropertyUtil.getSchemaProperty("relationship_WMSWOOReviseReferenceDocument");
	
	public static final String ATTRIBUTE_WMSDEPARTMENT = PropertyUtil.getSchemaProperty("attribute_WMSDepartment");
	
	public static final String TYPE_WMS_BILL_ITEM = PropertyUtil.getSchemaProperty("type_WMSBillItem");
	public static final String POLICY_WMS_BILL_ITEM = PropertyUtil.getSchemaProperty("policy_WMSBillItem");
	public static final String RELATIONSHIP_WMS_BILL_ITEM = PropertyUtil.getSchemaProperty("relationship_WMSBillItem");
	
	public static final String VAULT_ESERVICEPRODUCTION = PropertyUtil.getSchemaProperty("vault_eServiceProduction");
	
	public static final String STATE_WMSSOC_CREATE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSSOC, "state_Create");
	public static final String STATE_WMSSOC_SUBMIT = PropertyUtil.getSchemaProperty("policy",POLICY_WMSSOC, "state_Submit");
	public static final String STATE_WMSSOC_RIC = PropertyUtil.getSchemaProperty("policy",POLICY_WMSSOC, "state_RIC");
	public static final String STATE_WMSSOC_AE = PropertyUtil.getSchemaProperty("policy",POLICY_WMSSOC, "state_AE");
	public static final String STATE_WMSSOC_LISTINGOFPROJECTS = PropertyUtil.getSchemaProperty("policy",POLICY_WMSSOC, "state_ListingOfProjects");
	public static final String STATE_WMSSOC_ADMINAPPROVAL = PropertyUtil.getSchemaProperty("policy",POLICY_WMSSOC, "state_AdminApproval");
	public static final String STATE_WMSSOC_DELEGATION = PropertyUtil.getSchemaProperty("policy",POLICY_WMSSOC, "state_Delegation");
	public static final String STATE_WMSSOC_UNDEREXECUTION = PropertyUtil.getSchemaProperty("policy",POLICY_WMSSOC, "state_UnderExecution");
	public static final String STATE_WMSSOC_REJECTED = PropertyUtil.getSchemaProperty("policy",POLICY_WMSSOC, "state_Rejected");
	
	public static final String ATTRIBUTE_WMSITEMHISTORY = PropertyUtil.getSchemaProperty("attribute_WMSItemHistory");
	public static final String ATTRIBUTE_ROUTE_BASE_STATE = PropertyUtil.getSchemaProperty("attribute_RouteBaseState");
	public static final String RELATIONSHIP_ROUTE_TASK = PropertyUtil.getSchemaProperty("relationship_RouteTask");
		
	public static final String TYPE_WMS_CODE_HEAD = PropertyUtil.getSchemaProperty("type_WMSCodeHead");
	public static final String POLICY_WMS_CODE_HEAD = PropertyUtil.getSchemaProperty("policy_WMSCodeHead");
	public static final String RELATIONSHIP_WMS_PROJECT_CODE_HEAD = PropertyUtil.getSchemaProperty("relationship_WMSProjectCodeHead");
	public static final String RELATIONSHIP_WMS_WO_FUND_REQUEST = PropertyUtil.getSchemaProperty("relationship_WMSWOFundRequest");
	public static final String RELATIONSHIP_WMS_WO_FUND_RELEASE = PropertyUtil.getSchemaProperty("relationship_WMSWOFundRelease");
	public static final String TYPE_WMS_FUND_REQUEST = PropertyUtil.getSchemaProperty("type_WMSFundRequest");
	public static final String TYPE_WMS_FUND_RELEASE = PropertyUtil.getSchemaProperty("type_WMSFundRelease");
	
	public static final String POLICY_WMS_FUND_REQUEST = PropertyUtil.getSchemaProperty("policy_WMSFundRequest");
	public static final String POLICY_WMS_FUND_RELEASE = PropertyUtil.getSchemaProperty("policy_WMSFundRelease");
	
	
	public static final String RELATIONSHIP_WMS_CODE_HEAD_YEAR = PropertyUtil.getSchemaProperty("relationship_WMSCodeHeadYear");
	public static final String RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION = PropertyUtil.getSchemaProperty("relationship_WMSCodeHeadYearAllocation");
	public static final String TYPE_WMS_CODE_HEAD_YEAR = PropertyUtil.getSchemaProperty("type_WMSCodeHeadYear");
	public static final String TYPE_WMS_CODE_HEAD_YEAR_ALLOCATION = PropertyUtil.getSchemaProperty("type_WMSCodeHeadYearAllocation");
	
	public static final String POLICY_WMS_CODE_HEAD_YEAR = PropertyUtil.getSchemaProperty("policy_WMSCodeHeadYear");
	public static final String POLICY_WMS_CODE_HEAD_YEAR_ALLOCATION = PropertyUtil.getSchemaProperty("policy_WMSCodeHeadYearAllocation");
	
	public static final String ATTRIBUTE_WMS_FINANCIAL_YEAR = PropertyUtil.getSchemaProperty("attribute_WMSFinancialYear");
	public static final String ATTRIBUTE_WMS_MONTH = PropertyUtil.getSchemaProperty("attribute_WMSMonth");
	
	public static final String RELATIONSHIP_WMS_BUDGET_PLANNING = PropertyUtil.getSchemaProperty("relationship_WMSBudgetPlanning");
	public static final String TYPE_WMS_BUDGET_PLANNING = PropertyUtil.getSchemaProperty("type_WMSBudgetPlanning");
	public static final String POLICY_WMS_BUDGET_PLANNING = PropertyUtil.getSchemaProperty("policy_WMSBudgetPlanning");
	
	
	public static final String ATTRIBUTE_WMS_JAN = PropertyUtil.getSchemaProperty("attribute_WMSJan");
	public static final String ATTRIBUTE_WMS_FEB = PropertyUtil.getSchemaProperty("attribute_WMSFeb");
	public static final String ATTRIBUTE_WMS_MAR = PropertyUtil.getSchemaProperty("attribute_WMSMar");
	public static final String ATTRIBUTE_WMS_APR = PropertyUtil.getSchemaProperty("attribute_WMSApr");
	public static final String ATTRIBUTE_WMS_MAY = PropertyUtil.getSchemaProperty("attribute_WMSMay");
	public static final String ATTRIBUTE_WMS_JUN = PropertyUtil.getSchemaProperty("attribute_WMSJun");
	public static final String ATTRIBUTE_WMS_JUL = PropertyUtil.getSchemaProperty("attribute_WMSJul");
	public static final String ATTRIBUTE_WMS_AUG = PropertyUtil.getSchemaProperty("attribute_WMSAug");
	public static final String ATTRIBUTE_WMS_SEP = PropertyUtil.getSchemaProperty("attribute_WMSSep");
	public static final String ATTRIBUTE_WMS_OCT = PropertyUtil.getSchemaProperty("attribute_WMSOct");
	public static final String ATTRIBUTE_WMS_NOV = PropertyUtil.getSchemaProperty("attribute_WMSNov");
	public static final String ATTRIBUTE_WMS_DEC = PropertyUtil.getSchemaProperty("attribute_WMSDec");
	public static final String ATTRIBUTE_WMS_PLANNING_YEAR = PropertyUtil.getSchemaProperty("attribute_WMSPlanningYear");
	public static final String ATTRIBUTE_WMS_TYPE_OF_PLANNING = PropertyUtil.getSchemaProperty("attribute_WMSTypeOfPlanning");
	public static final String TYPE_WMS_MER = PropertyUtil.getSchemaProperty("type_WMSMER");
	public static final String POLICY_WMS_MER = PropertyUtil.getSchemaProperty("policy_WMSMER");
	public static final String ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE= PropertyUtil.getSchemaProperty("attribute_WMSAmountPaidTillDate");
	public static final String ATTRIBUTE_WMS_PERCENT_AMOUNT_PAYABLE= PropertyUtil.getSchemaProperty("attribute_WMSPercentAmountPayable");
	public static final String REL_ABS_STOCK = PropertyUtil.getSchemaProperty("relationship_WMSABSStock");
	public static final String ATTR_SECURED_ADVANCE_TEMP            = PropertyUtil.getSchemaProperty("attribute_WMSSecuredAdvanceTemp");
	public static final String ATTR_STOCK_RECOVERY_AMOUNT           = PropertyUtil.getSchemaProperty("attribute_WMSStockRecoveryAmount");
	public static final String ATTR_REDUCED_RATE_FOR_ADVANCE        = PropertyUtil.getSchemaProperty("attribute_WMSReducedRateforAdvance");
	public static final String ATTR_RECOVERY_AMOUNT                 = PropertyUtil.getSchemaProperty("attribute_WMSRecoveryAmount");
	public static final String TYPE_MATERIAL_CONSUMPTION           = PropertyUtil.getSchemaProperty("type_WMSMaterialConsumption");
	public static final String TYPE_STOCK_ENTRIES					= PropertyUtil.getSchemaProperty("type_WMSStockEntries");
	public static final String REL_MATERIAL_CONSUMPTION_TO_AMB             = PropertyUtil.getSchemaProperty("relationship_WMSMaterialConsumptionToAMB");
	public static final String REL_MATERIALCONSUMPTION_TO_STOCK    = PropertyUtil.getSchemaProperty("relationship_WMSMaterialConsumptionToStock");
	public static final String ATTR_STOCK_AVAILABLE_QTY             = PropertyUtil.getSchemaProperty("attribute_WMSStockAvailableQty");
	
	public static final String RELATIONSHIP_WMS_PERSON = PropertyUtil.getSchemaProperty("relationship_WMSPerson");
	public static final String TYPE_WMS_PERSON = PropertyUtil.getSchemaProperty("type_WMSPerson");
	public static final String POLICY_WMS_PERSON = PropertyUtil.getSchemaProperty("policy_WMSPerson");
		
	public static final String ATTRIBUTE_WMS_SOC_REJECT_STATE = PropertyUtil.getSchemaProperty("attribute_WMSSOCRejectState");
	public static final String ATTRIBUTE_WMS_LETTER_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSLetterNumber");
	public static final String ATTRIBUTE_WMSDELEGATIONLETTERNUMBER = PropertyUtil.getSchemaProperty("attribute_WMSDelegationLetterNumber");
	public static final String ATTRIBUTE_WMS_WORKS_CONTINGENCY = PropertyUtil.getSchemaProperty("attribute_WMSWorksContingency");
	public static final String ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY = PropertyUtil.getSchemaProperty("attribute_WMSEquipmentsContingency");
	public static final String ATTRIBUTE_WMS_PLANNING_CONTINGENCY = PropertyUtil.getSchemaProperty("attribute_WMSPlanningContingency");
	public static final String ATTRIBUTE_WMS_MAJOR_HEAD = PropertyUtil.getSchemaProperty("attribute_WMSMajorHead");
	public static final String ATTRIBUTE_WMS_MINOR_HEAD = PropertyUtil.getSchemaProperty("attribute_WMSMinorHead");
	
	public static final String TYPE_WMS_DEFAULT_MASTERS = PropertyUtil.getSchemaProperty("type_WMSDefaultMaster");
	public static final String POLICY_WMS_DEFAULT_MASTERS = PropertyUtil.getSchemaProperty("policy_WMSDefaultMaster");

	public static final String RELATIONSHIP_WMS_ACTIVITY_LOGS = PropertyUtil.getSchemaProperty("relationship_WMSActivityLogs");
	public static final String TYPE_WMS_ACTIVITY_LOGS = PropertyUtil.getSchemaProperty("type_WMSActivityLogs");
	public static final String POLICY_WMS_ACTIVITY_LOGS = PropertyUtil.getSchemaProperty("policy_WMSActivityLogs");
	
	public static final String ATTRIBUTE_WMS_VENDOR_RATING_DELIVERY = PropertyUtil.getSchemaProperty("attribute_WMSVendorRatingDelivery");
	public static final String ATTRIBUTE_WMS_VENDOR_RATING_ENV_FRIENDLY = PropertyUtil.getSchemaProperty("attribute_WMSVendorRatingEnvironmentFriendly");
	public static final String ATTRIBUTE_WMS_VENDOR_RATING_PERFORMANCE = PropertyUtil.getSchemaProperty("attribute_WMSVendorRatingPerformance");
	public static final String ATTRIBUTE_WMS_VENDOR_RATING_QC_COMPLIANCE = PropertyUtil.getSchemaProperty("attribute_WMSVendorRatingQCCompliance");
	public static final String ATTRIBUTE_WMS_VENDOR_RATING_QUALITY = PropertyUtil.getSchemaProperty("attribute_WMSVendorRatingQuality");
	public static final String ATTRIBUTE_WMS_VENDOR_RATING_SAFETY = PropertyUtil.getSchemaProperty("attribute_WMSVendorRatingSafety");
	public static final String ATTRIBUTE_WMS_VENDOR_RATING_SECURITY = PropertyUtil.getSchemaProperty("attribute_WMSVendorRatingSecurity");
	
	public static final String ATTRIBUTE_WMS_BILL_FORM_GENERATED = PropertyUtil.getSchemaProperty("attribute_WMSBillFormGenerated");

	public static final String RELATIONSHIP_WMS_BP_AE = PropertyUtil.getSchemaProperty("relationship_WMSBPAE");
	public static final String RELATIONSHIP_WMS_WORK_ORDER_TS = PropertyUtil.getSchemaProperty("relationship_WMSWorkOrderTS");
	public static final String ATTRIBUTE_WMS_CODE_HEAD_NAME = PropertyUtil.getSchemaProperty("attribute_WMSCodeHeadName");
	public static final String TYPE_PROJECTSPACE = PropertyUtil.getSchemaProperty("type_ProjectSpace");

	public static final String RELATIONSHIP_WMS_OTHER_ITEMS = PropertyUtil.getSchemaProperty("relationship_WMSDelegationOtherItems");
	public static final String RELATIONSHIP_WMSACTIVITYLOGSCOMMENTS = PropertyUtil.getSchemaProperty("relationship_WMSActivityLogsComments");
	public static final String RELATIONSHIP_WMSISSUECOMMENT = PropertyUtil.getSchemaProperty("relationship_WMSISSUECOMMENT");
	public static final String ATTRIBUTE_SUBJECT = PropertyUtil.getSchemaProperty("attribute_Subject");
	public static final String ATTRIBUTE_FUND_REQUEST_FOLIO_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSFundRequestFolioNumber");
	public static final String ATTRIBUTE_FUND_REQUEST_APPROVER_COMMENT = PropertyUtil.getSchemaProperty("attribute_WMSFundRequestApproverComment");
	public static final String TYPE_WMSACTIVITYLOGSCOMMENTS = PropertyUtil.getSchemaProperty("type_WMSActivityLogsComments");
	
	public static final String ATTRIBUTE_WMS_TS_LETTER_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSTSLetterNumber");
	public static final String ATTRIBUTE_WMS_PROJECT_PHYSICAL_PROGRESS = PropertyUtil.getSchemaProperty("attribute_WMSProjectPhysicalProgress");
	
	
	public static final String ATTRIBUTE_WMS_BUDGET_FE_START = PropertyUtil.getSchemaProperty("attribute_WMSBudgetFEStart");
	public static final String ATTRIBUTE_WMS_BUDGET_FE_END = PropertyUtil.getSchemaProperty("attribute_WMSBudgetFEEnd");	
	public static final String ATTRIBUTE_WMS_BUDGET_PRE_START = PropertyUtil.getSchemaProperty("attribute_WMSBudgetPREStart");
	public static final String ATTRIBUTE_WMS_BUDGET_PRE_END = PropertyUtil.getSchemaProperty("attribute_WMSBudgetPREEnd");	
	public static final String ATTRIBUTE_WMS_BUDGET_BE_START = PropertyUtil.getSchemaProperty("attribute_WMSBudgetBEStart");
	public static final String ATTRIBUTE_WMS_BUDGET_BE_END = PropertyUtil.getSchemaProperty("attribute_WMSBudgetBEEnd");	
	public static final String ATTRIBUTE_WMS_BUDGET_RE_START = PropertyUtil.getSchemaProperty("attribute_WMSBudgetREStart");
	public static final String ATTRIBUTE_WMS_BUDGET_RE_END = PropertyUtil.getSchemaProperty("attribute_WMSBudgetREEnd");	
	public static final String ATTRIBUTE_WMS_BUDGET_MAR_START = PropertyUtil.getSchemaProperty("attribute_WMSBudgetMARStart");
	public static final String ATTRIBUTE_WMS_BUDGET_MAR_END = PropertyUtil.getSchemaProperty("attribute_WMSBudgetMAREnd");
	public static final String ATTRIBUTE_WMS_FRQ_LETTER_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSFRQLetterNumber");
	public static final String ATTRIBUTE_ALLOCATION_FUND_REQUEST_REMARKS = PropertyUtil.getSchemaProperty("attribute_WMSAllocationFundRequestRemarks");
	public static final String ATTRIBUTE_ALLOCATION_WMS_FUND_REQUEST_INITIAL_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSFundRequestInitialAmount");
	
	
	
	
	
}
