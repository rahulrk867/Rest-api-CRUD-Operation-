Udpate fromPersonName  and toPersonName in ReassignPerson.bat.

Or execute below command from MQL by updating the from and to user names.

exec program WMSPerson -method reassignPerson fromPersonName toPersonName;

Note: fromPersonName --> UserID of the person who is moving out from the organization.
toPersonName --> UserID of the person who is replacing fromPersonName in the organization.