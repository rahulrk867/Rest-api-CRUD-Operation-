import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MailUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UINavigatorUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

import java.text.SimpleDateFormat;
import java.util.Date;
import com.matrixone.apps.framework.ui.UIUtil;

public class WMSAbstractBillHistory_mxJPO extends WMSConstants_mxJPO {

	public WMSAbstractBillHistory_mxJPO(Context context, String[] args) {

		super(context, args);
	}

	public void triggerGetModifiedHistoryForUser(Context context, String[] args) throws Exception {
		try {

			 String strInboxTaskId = args[0];
			 String strType = args[1];
			 String strCurrentState = args[2];
			if (strType.equalsIgnoreCase(DomainConstants.TYPE_INBOX_TASK)
					&& strCurrentState.equalsIgnoreCase("Complete")) {
			 	DomainObject domObject = DomainObject.newInstance(context, strInboxTaskId);
				StringList slSelect = new StringList(2);
				slSelect.add("attribute[" + DomainConstants.ATTRIBUTE_COMMENTS + "]");
				slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.id");
				slSelect.add("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_ROUTE_STATUS+"]");
				slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.to["
						+ DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.type");
				slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.to["
						+ DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.name");
				slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.to["
						+ DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.id");
				slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.id");
				slSelect.add("from[" + DomainConstants.RELATIONSHIP_PROJECT_TASK + "].to.name");
				Map mInboxData = domObject.getInfo(context, slSelect);
				String strConnectedType = (String) mInboxData.get("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK
						+ "].to.to[" + DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.type");
				String strRouteStatus= (String) mInboxData.get("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_ROUTE_STATUS+"]");
 			   if (strConnectedType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY) && !strRouteStatus.equalsIgnoreCase("STOPPED")) {

					String strBillId = (String) mInboxData.get("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK
							+ "].to.to[" + DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.id"); 
					DomainObject domBill = DomainObject.newInstance(context, strBillId);
					String strWOId = domBill.getInfo(context, "to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
					 
					Map m=new HashMap();
					m.put("objectId", strWOId);
					String strRelAttr=DomainConstants.EMPTY_STRING;
					String strToPersonNames=DomainConstants.EMPTY_STRING;
					StringList lstToPersonNames=new StringList();
					WMSMeasurementBookItem_mxJPO mxBookItem=new WMSMeasurementBookItem_mxJPO(context,args);
						MapList mlAssignees =  mxBookItem.getWorkOrderAssignees(context,JPO.packArgs(m));
						for(int i=0;i<mlAssignees.size();i++) {
							Map mData=(Map)mlAssignees.get(i);
						    strRelAttr = (String) mData.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"]");
		                    if(!strRelAttr.equalsIgnoreCase(DomainConstants.ROLE_SUPPLIER_REPRESENTATIVE)) {
		                    	strToPersonNames=(String)mData.get(DomainConstants.SELECT_NAME);
		                    	lstToPersonNames.add(strToPersonNames);
		                    }
						}
					String strUser = DomainConstants.EMPTY_STRING;
					String strAction = DomainConstants.EMPTY_STRING;
					String strDescription = DomainConstants.EMPTY_STRING;
			 		StringList objectSelects = new StringList();
					objectSelects.add(DomainConstants.SELECT_ID);
					objectSelects.add(DomainConstants.SELECT_TYPE);
					objectSelects.add(DomainConstants.SELECT_NAME);
					objectSelects.add("attribute.value");
					StringList relSelects = new StringList();
					relSelects.add(DomainRelationship.SELECT_NAME);
					relSelects.add(DomainRelationship.SELECT_ID);
					// relSelects.add(arg0)
					String strRels = "WMSAbstractMBEHeadDeduction,WMSAbstractMBEPaymentItems,WMSAbstractMBETechnicalDeduction,WMSAbstractMBETechnicalDeductionRelease,"
							+ "WMSAMBAdvanceRecovery,WMSAMBRecovery,WMSAMBRetentionRecovery,,WMSBillReduction,WMSBillReductionRelease";

					MapList objectList = domBill.getRelatedObjects(context, strRels, "*", objectSelects, relSelects,
							false, true, (short) 0, DomainConstants.EMPTY_STRING, null, 0);
					StringList timeArray = null;
					StringList userArray = null;
					StringList actionArray = null;
					StringList stateArray = null;
					StringList descriptionArray = null;
					String modifiedName = DomainConstants.EMPTY_STRING;
					Map mTypeDisplayName = new HashMap();
					mTypeDisplayName.put("WMSAMBAdvanceRecovery", "Advance Recovery");
				 	mTypeDisplayName.put("WMSAdvanceRecoveryItem", "Advance Recovery Item");
					mTypeDisplayName.put("WMSTechnicalDeduction", "Technical Deduction");
					
					Map mRelToTypeMapped = new HashMap();
					mRelToTypeMapped.put("WMSAMBRecovery", "Recovery");
					mRelToTypeMapped.put("WMSAMBAdvanceRecovery", "Advances");
					mRelToTypeMapped.put("WMSBillReduction", "Withheld");
					mRelToTypeMapped.put("WMSBillReductionRelease", "Withheld Release");
			 		String strObjectId = DomainConstants.EMPTY_STRING;
					Map mIdData = new HashMap();
					List<String> lstIds = new ArrayList();
					String strDirection = "from";
					StringBuilder sbGlobalHistory = new StringBuilder();

					boolean bDeleted = false;
					boolean bNewAdd = false;
					int iMaxCount = 0;
				 	String strRelName=DomainConstants.EMPTY_STRING;
					for (int i = 0; i < objectList.size(); i++) {
						bDeleted = false;
						bNewAdd = false;
						StringBuilder sbHistory = new StringBuilder();
						StringBuilder sbModHistory = new StringBuilder();
						Map<String, String> mStore = new HashMap<String, String>();
						String strName = DomainConstants.EMPTY_STRING;
						m = (Map) objectList.get(i);
						strType = (String) m.get(DomainConstants.SELECT_TYPE);
						strRelName=(String) m.get(DomainRelationship.SELECT_NAME);
				 		strObjectId = (String) m.get(DomainConstants.SELECT_ID);
						lstIds.add(strObjectId);
						HashMap hmaplist = UINavigatorUtil.getHistoryData(context, strObjectId);
						timeArray = (StringList) hmaplist.get("time");
						userArray = (StringList) hmaplist.get("user");
						actionArray = (StringList) hmaplist.get("action");
						stateArray = (StringList) hmaplist.get("state");
						descriptionArray = (StringList) hmaplist.get("description");
						modifiedName = (String) hmaplist.get("modifiedName");
						String strContextUser = context.getUser();
				 		iMaxCount = userArray.size();
					 	for (int n = 0; n < iMaxCount; n++) {
							strUser = (String) userArray.get(n);
							if (strUser.equalsIgnoreCase("user: "+strContextUser)) {
								strAction = (String) actionArray.get(n);
								strDescription = (String) descriptionArray.get(n);
							 	if (strAction.equalsIgnoreCase("connect")) {
									sbHistory.append(mRelToTypeMapped.get(strRelName)).append(" is added \n");
									bNewAdd = true;
								} else if (strAction.equalsIgnoreCase("disconnect")) {
									bDeleted = true;
									break;

								} else if (strAction.equalsIgnoreCase("modify")) {
									strDescription=strDescription.replaceAll("WMS", "");
  				                   sbModHistory.append(" ").append(strDescription).append("\n");

								}
					 		}
				       }
						if (sbModHistory.length() > 0) {
							if (!bNewAdd)
								sbHistory.append(mRelToTypeMapped.get(strRelName))
										.append(" is modified with below changes \n");
							sbHistory.append(sbModHistory.toString());
						}

						if (!bDeleted) {
							sbGlobalHistory.append(sbHistory.toString());
						}
					}
				 
					//send mail
					if(sbGlobalHistory.length()>0) {
						 String strBillName =  (String) mInboxData.get("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK
								+ "].to.to[" + DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.name"); 
				             StringList slObjectIdList=new StringList();
				             slObjectIdList.add(strBillId);
						 	 String[] subjectKeys = {};
				             String[] subjectValues = {};

				             String[] messageKeys = {};
				             String[] messageValues = {};
				             StringBuilder sbSubject=new StringBuilder();
				             sbSubject.append("Bill data for bill :").append(strBillName).append(" is modified by").append(context.getUser());
								MailUtil.sendNotification(context,
				               	                        lstToPersonNames,
				                                         null,
				                                         null,
				                                         sbSubject.toString(),
				                                         subjectKeys,
				                                         subjectValues,
				                                         sbGlobalHistory.toString(),
				                                         messageKeys,
				                                         messageValues,
				                                         slObjectIdList,
				                                         null);
								  
						
						
					}

				 }
			 }

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static MapList getRARContingentBillsByDate(Context context, String args[]) throws Exception
	{
		MapList mlReturn = new MapList();
		StringList slBillSels = new StringList();
		slBillSels.add(DomainConstants.SELECT_NAME);
		slBillSels.add("originated");
		slBillSels.add(DomainConstants.SELECT_DESCRIPTION);
		slBillSels.add("attribute[WMSInvoicedAmount]");
		slBillSels.add("attribute[WMSCertifiedAmount]");
		slBillSels.add("state[Approved].actual");
		slBillSels.add("from[WMSAbstractMBEHeadDeduction|to.description==CGST].attribute[WMSHeadDeductionAmount]");
		slBillSels.add("from[WMSAbstractMBEHeadDeduction|to.description==SGST].attribute[WMSHeadDeductionAmount]");
		
		String sDate = args[0]; 
		StringList slDateChunks = FrameworkUtil.split(sDate,"-");
		if(slDateChunks != null && !slDateChunks.isEmpty())
		{
			String sYear=slDateChunks.get(0);
			String sMonth = slDateChunks.get(1);
			String sDay = slDateChunks.get(2);
			sDate = sMonth+"/"+sDay+"/"+sYear;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		if(UIUtil.isNotNullAndNotEmpty(sDate) && sDate.contains("/"))
		{
			Date dSelected = sdf.parse(sDate);	
			String sDateStartRange = "\'"+sdf.format(dSelected)+" 12:00:00 AM\'";
			String sDateEndRange = "\'"+sdf.format(dSelected)+" 11:59:59 PM\'";
			String sWhere = "originated >= "+sDateStartRange+" && originated <= "+sDateEndRange+"";
			mlReturn = DomainObject.findObjects(context, 
												"WMSAbstractMeasurementBookEntry", 
												"*", 
												"*", 
												null,
												null, 
												sWhere, 
												true, 
												slBillSels);
		}
		return mlReturn;
	}

}
