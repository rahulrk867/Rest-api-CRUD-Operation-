import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;

import com.itextpdf.io.image.ImageData; 
import com.itextpdf.io.image.ImageDataFactory; 
import com.itextpdf.kernel.pdf.PdfDocument; 
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Image; 
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Cell; 
import com.itextpdf.layout.element.Table;  
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.Property;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.VerticalAlignment;
import com.itextpdf.layout.property.HorizontalAlignment;

import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;

import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.program.ProgramCentralConstants;

public class WMSBillSummary_mxJPO extends WMSConstants_mxJPO {

	public WMSBillSummary_mxJPO(Context context,String[] args) {
		super(context,args);
	}
	public HashMap generateBillSummary(Context context, String[] args) throws Exception 
	{
		boolean bIsContentPushed = false;
		try{
		ContextUtil.pushContext(context);
		bIsContentPushed = true;
		//String strTSId = args[1];
		Map mInputMap = (Map) JPO.unpackArgs(args);
		String strProjectId = (String)mInputMap.get("objectId");
		
		DomainObject doProject = DomainObject.newInstance(context, strProjectId);
		
		StringList slProjectSelect = new StringList();
		slProjectSelect.add(DomainObject.SELECT_NAME);
		
		Map mProjectInfo = (Map)doProject.getInfo(context,slProjectSelect);
		
		String strProjectName = (String)mProjectInfo.get(DomainObject.SELECT_NAME);
		
		StringList slContactors = (StringList)doProject.getInfoList(context,"from[WMSProjectWorkOrder].to.to[PRBWorkorderContractor].from.name");
		
		StringList slContractValues = (StringList)doProject.getInfoList(context,"from[WMSProjectWorkOrder].to.attribute[WMSValueOfContract].value");
		
		String strContractorName = "";
		StringList slTempContractList = new StringList();
		for(int i=0;i<slContactors.size();i++){
			
			if(i==0){
				strContractorName = (String)slContactors.get(i);
				slTempContractList.add(strContractorName);
			}
			if(slTempContractList.contains((String)slContactors.get(i))==false){
				strContractorName = strContractorName+", "+(String)slContactors.get(i);
			}			
		}
		
		String strValueOfCotract = "";
		double dTotalValueOfContract = 0.0;
		
		for(int i=0;i<slContractValues.size();i++){
			dTotalValueOfContract = dTotalValueOfContract + Double.parseDouble((String)slContractValues.get(i));
		}
		
		strValueOfCotract = WMSUtil_mxJPO.converToIndianCurrency(context,dTotalValueOfContract);
		
		String strTransPath = context.createWorkspace();
		String strFileName = "Bill_Summary_Sheet.pdf";
		String dest = strTransPath+File.separator+strFileName;

		// Creating a PdfDocument
		PdfDocument pdf = new PdfDocument(new PdfWriter(dest));
		// Creating a Document
		Document document = new Document(pdf, PageSize.A4, false);

		//adding DGNP logo
		String imgFile = getImgFile(context);
		ImageData imgdata = ImageDataFactory.create(imgFile);
		Image image = new Image(imgdata);
		image.setTextAlignment(TextAlignment.CENTER);
		document.add(image);
		
		//add space
		document.add(new Paragraph(""));
		
		PdfFont  fontBold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD); 		
		
		//add headers
		Paragraph p = new Paragraph("SUMMARY SHEET FOR MIXED CONTRACT")
									.setTextAlignment(TextAlignment.CENTER)
									.setFontSize(13)
									.setUnderline(0.1f, -2f).setFont(fontBold);
		document.add(p);
				
		//add space
		document.add(new Paragraph(""));	

		Table details = new Table(UnitValue.createPercentArray(new float[] {3, 6}));
		details.addCell(createCell("Project Name:-", 0, 1, TextAlignment.LEFT,true));
		details.addCell(createCell(strProjectName,0, 1, TextAlignment.LEFT,false));
		details.addCell(createCell("Contractor:-", 0, 1, TextAlignment.LEFT,true));
		details.addCell(createCell(strContractorName, 0, 1, TextAlignment.LEFT,false));
		details.addCell(createCell("Amount of Contract:-", 0, 1, TextAlignment.LEFT,true));
		details.addCell(createCell(strValueOfCotract+" (Including all the work order)", 0, 1, TextAlignment.LEFT,false));
		details.addCell(createCell("Date:-", 0, 1, TextAlignment.LEFT,true));	
		details.addCell(createCell("", 0, 1, TextAlignment.LEFT,false));
		details.addCell(createCell("", 0, 1, TextAlignment.LEFT,false));
		details.addCell(createCell("", 0, 1, TextAlignment.LEFT,false));		
		details.addCell(createCell("Bill Summary", 0, 1, TextAlignment.LEFT,true));	
		
		document.add(details);
		
		document.add(new Paragraph(""));	
		
		//adding items table
		Table table = new Table(UnitValue.createPercentArray(new float[] {1, 4, 4, 3}));
		table.addCell(createCell("Section", 1, 1, TextAlignment.CENTER,true).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Type of Contract", 1, 1, TextAlignment.CENTER,true).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Payment History", 1, 1, TextAlignment.CENTER,true).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Total", 1, 1, TextAlignment.CENTER,true).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		
		
		String strFundRequest = MqlUtil.mqlCommand(context,"print bus "+strProjectId+" select from[WMSProjectWorkOrder].to.from[WMSWOFundRequest|to.current==Approved].to.attribute[WMSTotalAmount].value dump");
		
		StringList slFundRequests = new StringList();
		if(UIUtil.isNotNullAndNotEmpty(strFundRequest)){
			slFundRequests = FrameworkUtil.split(strFundRequest,",");
		}
		
		double dTotalFundRequest = 0.0;
		String strValue = "";
		for(int i=0;i<slFundRequests.size();i++){
			strValue = (String)slFundRequests.get(i);
			if(UIUtil.isNullOrEmpty(strValue)){
				strValue = "0";
			}
			dTotalFundRequest = dTotalFundRequest + Double.parseDouble(strValue);
		}
		
		String strBRWorkOrders = MqlUtil.mqlCommand(context,"print bus "+strProjectId+" select from[WMSProjectWorkOrder|to.attribute[WMSTypeOfWork]=='B/R'].to.id dump");
		
		StringList slBRWorkOrderIds = new StringList();
		if(UIUtil.isNotNullAndNotEmpty(strBRWorkOrders)){
			slBRWorkOrderIds = FrameworkUtil.split(strBRWorkOrders,",");
		}		
		
		String strEMWorkOrders = MqlUtil.mqlCommand(context,"print bus "+strProjectId+" select from[WMSProjectWorkOrder|to.attribute[WMSTypeOfWork]=='E/M'].to.id dump");
		
		StringList slEMWorkOrderIds = new StringList();
		if(UIUtil.isNotNullAndNotEmpty(strEMWorkOrders)){
			slEMWorkOrderIds = FrameworkUtil.split(strEMWorkOrders,",");
		}
		
		
		String strBRWorkOrdersBillAmount = MqlUtil.mqlCommand(context,"print bus "+strProjectId+" select from[WMSProjectWorkOrder|to.attribute[WMSTypeOfWork]=='B/R'].to.from[WMSWOAbstractMBE|(to.current==Approved || to.current==Paid)].to.attribute[WMSCertifiedAmount].value dump");
		
		double dBRTotal = 0.0;
		double dEMTotal = 0.0;
		strValue = "";
		StringList slBRAmount = FrameworkUtil.split(strBRWorkOrdersBillAmount,",");
		for(int i=0;i<slBRAmount.size();i++){
			strValue = (String)slBRAmount.get(i);
			if(UIUtil.isNullOrEmpty(strValue)){
				strValue = "0";
			}
			dBRTotal = dBRTotal + Double.parseDouble(strValue);
		}
		
		String strEMWorkOrdersBillAmount = MqlUtil.mqlCommand(context,"print bus "+strProjectId+" select from[WMSProjectWorkOrder|to.attribute[WMSTypeOfWork]=='E/M'].to.from[WMSWOAbstractMBE|(to.current==Approved || to.current==Paid)].to.attribute[WMSCertifiedAmount].value dump");

		StringList slEMAmount = FrameworkUtil.split(strEMWorkOrdersBillAmount,",");
		for(int i=0;i<slEMAmount.size();i++){
			strValue = (String)slEMAmount.get(i);
			if(UIUtil.isNullOrEmpty(strValue)){
				strValue = "0";
			}
			dEMTotal = dEMTotal + Double.parseDouble(strValue);
		}
		
		Map mTemp = null;
		String strWorkOrder = "";
		StringList slBillSelect = new StringList();
		slBillSelect.add(DomainObject.SELECT_ID);
		slBillSelect.add("attribute[Sequence Order].value");
		slBillSelect.add("attribute[WMSCertifiedAmount].value");		
		
		DomainObject doWO = DomainObject.newInstance(context);
		
		for(int i=0;i<slBRWorkOrderIds.size();i++){
			strWorkOrder = (String)slBRWorkOrderIds.get(i);
			doWO.setId(strWorkOrder);
			
			MapList mlWOBills = doWO.getRelatedObjects(context,
                                                "WMSWOAbstractMBE",
                                                TYPE_ABSTRACT_MBE,
                                                slBillSelect,
                                                null,       // relationshipSelects
                                                false,      // getTo
                                                true,       // getFrom
                                                (short) 1,  // recurseToLevel
                                                "(current==Approved || current==Paid)",// objectWhere
                                                null);

			mlWOBills.sort("attribute[Sequence Order].value", ProgramCentralConstants.ASCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
			
			if(i==0){
				table.addCell(createCell("B/R", 1, 1, TextAlignment.CENTER,false));
				table.addCell(createCell("EPC or Items Rates", 1, 1, TextAlignment.CENTER,false));
				table.addCell(createCell("", 1, 1, TextAlignment.CENTER,false));
				table.addCell(createCell("", 1, 1, TextAlignment.CENTER,false));
			}
			
			Map mBillMap = null;
			String strBillAmount = "";
			for(int j=0;j<mlWOBills.size();j++){
				mBillMap = (Map)mlWOBills.get(j);
				strBillAmount = (String)mBillMap.get("attribute[WMSCertifiedAmount].value");
				if(UIUtil.isNullOrEmpty(strBillAmount))
					strBillAmount = "0";
				if(j==0){
					table.addCell(createCell("", 1, 1, TextAlignment.LEFT,false));
					table.addCell(createCell("", 1, 1, TextAlignment.LEFT,false));
					table.addCell(createCell(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strBillAmount)), 1, 1, TextAlignment.RIGHT,false));
					table.addCell(createCell(WMSUtil_mxJPO.converToIndianCurrency(context,dBRTotal), 1, 1, TextAlignment.RIGHT,false));
				}else{
					table.addCell(createCell("", 1, 1, TextAlignment.LEFT,false));
					table.addCell(createCell("", 1, 1, TextAlignment.LEFT,false));
					table.addCell(createCell(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strBillAmount)), 1, 1, TextAlignment.RIGHT,false));
					table.addCell(createCell("", 1, 1, TextAlignment.RIGHT,false));
				}
			}
			
		}
		
		for(int i=0;i<slEMWorkOrderIds.size();i++){
			strWorkOrder = (String)slEMWorkOrderIds.get(i);
			doWO.setId(strWorkOrder);
			
			MapList mlWOBills = doWO.getRelatedObjects(context,
                                                "WMSWOAbstractMBE",
                                                TYPE_ABSTRACT_MBE,
                                                slBillSelect,
                                                null,       // relationshipSelects
                                                false,      // getTo
                                                true,       // getFrom
                                                (short) 1,  // recurseToLevel
                                                "(current==Approved || current==Paid)",// objectWhere
                                                null);

			mlWOBills.sort("attribute[Sequence Order].value", ProgramCentralConstants.ASCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
			
			if(i==0){
				table.addCell(createCell("E/M", 1, 1, TextAlignment.CENTER,false));
				table.addCell(createCell("EPC or Items Rates", 1, 1, TextAlignment.CENTER,false));
				table.addCell(createCell("", 1, 1, TextAlignment.CENTER,false));
				table.addCell(createCell("", 1, 1, TextAlignment.CENTER,false));
			}
			
			Map mBillMap = null;
			String strBillAmount = "";
			for(int j=0;j<mlWOBills.size();j++){
				mBillMap = (Map)mlWOBills.get(j);
				strBillAmount = (String)mBillMap.get("attribute[WMSCertifiedAmount].value");
				if(UIUtil.isNullOrEmpty(strBillAmount))
					strBillAmount = "0";
				if(j==0){
					table.addCell(createCell("", 1, 1, TextAlignment.LEFT,false));
					table.addCell(createCell("", 1, 1, TextAlignment.LEFT,false));
					table.addCell(createCell(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strBillAmount)), 1, 1, TextAlignment.RIGHT,false));
					table.addCell(createCell(WMSUtil_mxJPO.converToIndianCurrency(context,dEMTotal), 1, 1, TextAlignment.RIGHT,false));
				}else{
					table.addCell(createCell("", 1, 1, TextAlignment.LEFT,false));
					table.addCell(createCell("", 1, 1, TextAlignment.LEFT,false));
					table.addCell(createCell(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strBillAmount)), 1, 1, TextAlignment.RIGHT,false));
					table.addCell(createCell("", 1, 1, TextAlignment.RIGHT,false));
				}
			}
			
		}
		
		
		document.add(table);
		document.add(new Paragraph(""));	
		document.add(new Paragraph(""));	
		document.add(new Paragraph(""));	
		document.add(new Paragraph(""));	
		
		document.add(new Paragraph("Current Fund Demand Amount including B/R and E/M "+WMSUtil_mxJPO.converToIndianCurrency(context,dTotalFundRequest)+" ("+WMSUtil_mxJPO.getValueInWords(String.valueOf(dTotalFundRequest))+")"));	
		
		document.add(new Paragraph(""));	
		document.add(new Paragraph(""));	
		document.add(new Paragraph(""));	
		document.add(new Paragraph(""));

		Table aquittance = new Table(UnitValue.createPercentArray(new float[] {5,5,5,5}));
		aquittance.addCell(createCell("ACQUITTANCE", 1, 4, TextAlignment.CENTER,true));
		aquittance.addCell(createCell("Received(Rs.\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0)Rupees", 1, 4, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("as an intermediate / Final payment in connection with the contract referred to above", 1, 4, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("Dated:\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0\u00a0 Amount in Indian Language", 1, 4, TextAlignment.LEFT,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("Witness:", 1, 2, TextAlignment.LEFT,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("Full Signature of Contractor", 1, 4, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("Dated:", 1, 2, TextAlignment.LEFT,false));
		aquittance.addCell(createCell("Paid by me by Cash", 1, 2, TextAlignment.LEFT,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("Check No.", 1, 2, TextAlignment.LEFT,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("\u00a0", 1, 2, TextAlignment.CENTER,false));
		aquittance.addCell(createCell("Dated initials of person actually making the payment.", 1, 4, TextAlignment.CENTER,false));
		document.add(aquittance);
		//aquittance.addCell(createCell("EPC or Items Rates", 1, 1, TextAlignment.CENTER,false));
		//aquittance.addCell(createCell("", 1, 1, TextAlignment.CENTER,false));
		//aquittance.addCell(createCell("", 1, 1, TextAlignment.CENTER,false));
		
		document.close();
		pdf.close();
		
		//checkin file
		checkinFile(context, strProjectId, strTransPath, strFileName);
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
			
		}finally{
			if(bIsContentPushed)
				ContextUtil.popContext(context);
		}
		HashMap hmReturnMap = new HashMap();
		hmReturnMap.put("Action","Success");
		return hmReturnMap;
	}
	private static Cell createCell(String content, float borderWidth, int colspan, TextAlignment alignment, boolean bBold) throws Exception {
		
		PdfFont  fontBold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD); 
		Cell cell = new Cell(1, colspan).add(new Paragraph(content));
		if(bBold)
			cell.setTextAlignment(alignment).setFont(fontBold); 
		else
			cell.setTextAlignment(alignment);
		if(borderWidth==0)
			cell.setBorder(Border.NO_BORDER);
		else
			cell.setBorder(new SolidBorder(borderWidth));
		return cell;
	}
	private static void checkinFile(Context context, String strObjId, String strFilePath, String strFileName) throws Exception
	{
		DomainObject dObject = DomainObject.newInstance(context,strObjId);
		ContextUtil.pushContext(context);
		dObject.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strFilePath);
		ContextUtil.popContext(context);
	}
	private static String getImgFile(Context context) throws Exception
	{
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
		String strLogo = newFile.getCanonicalPath()+strImageFolder+"banner.png";
		strLogo = strLogo.replace("\\", "/");
		return strLogo;
	}
}
