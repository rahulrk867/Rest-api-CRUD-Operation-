/*---------------------------------------------------------------------------------------------------------------
NAME		: WMSDelegation.java

DESCRIPTION	: Purpose of JPO is to Create Delegation/Admin Approvals update and perform the utility operations on it

CREATED		: August 13 2019

AUTHOR		: Divyashree B K

HISTORY		:

	Divyashree B K	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;
import java.math.BigDecimal;

import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectConcept;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.ContextUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import matrix.db.Policy;

import matrix.util.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Calendar;
import matrix.db.MQLCommand;
import java.io.*;

import java.util.Collections;

import java.lang.Integer;

public class WMSDelegation_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSDelegation_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	/**
	* Method to get Realated RICChapters information on ProjectSpace
	*
	* @param context - the eMatrix <code>Context</code> object
	* @param args - args contains a Map with the following entries
	*                      objectId - Object Id of the Context object
	* @return - Maplist
	* @throws Exception if the operation fails
	**/
		
	
	
	       
		public String getEquipmentlAmount(Context context,String args[]) throws Exception{
			String sEquipment = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
			String strMode = (String)requestMap.get("mode");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
				MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);				
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sEquipment = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDEQUIPMENT);
				if(UIUtil.isNotNullAndNotEmpty(strMode) && "view".equalsIgnoreCase(strMode))
					sEquipment = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(sEquipment));
				ContextUtil.popContext(context);
			}
			return sEquipment;
		}
		public String getEquipmentContingency(Context context,String args[]) throws Exception{
			//System.out.println("getEquipmentContingency-------------------");
			String sEquipment = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			//System.out.println("projectConceptId-------------------"+projectConceptId);
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
				MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);				
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				StringList slOtherItemsRels = (StringList)objDelegate.getInfoList(context,"from[WMSDelegationOtherItems].id");
				String strOtherItemRelId = "";
				String sOtherItem = "";
				
				HashMap mAmountMap = new HashMap();
				StringList slItemDetails = new StringList();
				for(int i=0;i<slOtherItemsRels.size();i++){
					strOtherItemRelId = (String)slOtherItemsRels.get(i);
					String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSEquipmentDelegationAmount].value dump |");
					slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
					mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
				}
				Set keySet = mAmountMap.keySet();
				Iterator keys = keySet.iterator();
				int ctr=0;
				while(keys.hasNext())
				{
					String itemName = (String)keys.next();
					String strValue = (String)mAmountMap.get(itemName);
					if(ctr==0)
						sEquipment = itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					else
						sEquipment = sEquipment +"<br>"+ itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					ctr++;
				}
				//sEquipment = objDelegate.getAttributeValue(context,ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY);
				ContextUtil.popContext(context);
			}
			return sEquipment;
		}
		public String  getEquipmentRemarks(Context context,String args[]) throws Exception{
			String sEquipmentRemarks = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sEquipmentRemarks = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDEQUIPMENTREMARKS);
				ContextUtil.popContext(context);
			}
			return sEquipmentRemarks;
		}
		public String getWorkAmount(Context context,String args[]) throws Exception{
			String sWork = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
			
            HashMap requestMap = (HashMap) programMap.get("requestMap");
			String strMode = (String)requestMap.get("mode");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sWork = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDWORK);
				if(UIUtil.isNotNullAndNotEmpty(strMode) && "view".equalsIgnoreCase(strMode))
					sWork = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(sWork));
				ContextUtil.popContext(context);
			}
			return sWork;
		}
		public String getWorkContingency(Context context,String args[]) throws Exception{
			String sWork = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				//sWork = objDelegate.getAttributeValue(context,ATTRIBUTE_WMS_WORKS_CONTINGENCY);
				StringList slOtherItemsRels = (StringList)objDelegate.getInfoList(context,"from[WMSDelegationOtherItems].id");
				String strOtherItemRelId = "";
				String sOtherItem = "";
				
				HashMap mAmountMap = new HashMap();
				StringList slItemDetails = new StringList();
				for(int i=0;i<slOtherItemsRels.size();i++){
					strOtherItemRelId = (String)slOtherItemsRels.get(i);
					String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSWorksDelegationAmount].value dump |");
					slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
					mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
				}
				Set keySet = mAmountMap.keySet();
				Iterator keys = keySet.iterator();
				int ctr=0;
				while(keys.hasNext())
				{
					String itemName = (String)keys.next();
					String strValue = (String)mAmountMap.get(itemName);
					if(ctr==0)
						sWork = itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					else
						sWork = sWork +"<br>"+ itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					ctr++;
				}
				ContextUtil.popContext(context);
			}
			return sWork;
		}
		public String getWorkRemarks(Context context,String args[]) throws Exception{
			String sWorkRemarks = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sWorkRemarks = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDWORKREMARKS);
				ContextUtil.popContext(context);
				
			}
			return sWorkRemarks;
		}
		public String getLetterNumber(Context context,String args[]) throws Exception{
			String sLetterNumber = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sLetterNumber = objDelegate.getAttributeValue(context,"WMSDelegationLetterNumber");
				ContextUtil.popContext(context);
				
			}
			return sLetterNumber;
		}
		public void updateLetterNumber(Context context,String args[]) throws Exception{
			 HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strLetterNo =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strLetterNo, "WMSDelegationLetterNumber"};
			updateDeligationAttribute(context, args1);
		}
		public String getPlanningAmount(Context context,String args[]) throws Exception{
			String sPlanning = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
			String strMode = (String)requestMap.get("mode");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sPlanning = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDPLANNING);
				if(UIUtil.isNotNullAndNotEmpty(strMode) && "view".equalsIgnoreCase(strMode))
					sPlanning = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(sPlanning));
				ContextUtil.popContext(context);
			}
			return sPlanning;
		}
		public String getPlanningContingency(Context context,String args[]) throws Exception{
			String sPlanning = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				//sPlanning = objDelegate.getAttributeValue(context,ATTRIBUTE_WMS_PLANNING_CONTINGENCY);
				StringList slOtherItemsRels = (StringList)objDelegate.getInfoList(context,"from[WMSDelegationOtherItems].id");
				String strOtherItemRelId = "";
				String sOtherItem = "";
				
				HashMap mAmountMap = new HashMap();
				StringList slItemDetails = new StringList();
				for(int i=0;i<slOtherItemsRels.size();i++){
					strOtherItemRelId = (String)slOtherItemsRels.get(i);
					String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSPlanningDelegationAmount].value dump |");
					slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
					mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
				}
				Set keySet = mAmountMap.keySet();
				Iterator keys = keySet.iterator();
				int ctr=0;
				while(keys.hasNext())
				{
					String itemName = (String)keys.next();
					String strValue = (String)mAmountMap.get(itemName);
					if(ctr==0)
						sPlanning = itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					else
						sPlanning = sPlanning +"<br>"+ itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					ctr++;
				}
				ContextUtil.popContext(context);
			}
			return sPlanning;
		}
		public String getPlanningRemarks(Context context,String args[]) throws Exception{
			String sPlanningRemarks = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sPlanningRemarks = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDPLANNINGREMARKS);
				ContextUtil.popContext(context);
			}
			return sPlanningRemarks;
		}
		
		public void updateDeligationAttribute (Context context,String args[]) throws Exception{
			try {
			String projectConceptId = args[0];
			String strPlanningRemarks = args[1];
			//System.out.println("checking seq attr value :: "+strPlanningRemarks);
			String sAttributeName = args[2];
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				objDelegate.setAttributeValue(context, sAttributeName, strPlanningRemarks);
				//System.out.println("update method executed.. ");
			}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		public void updateEquipmentlAmount(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDEQUIPMENT};			
			updateDeligationAttribute(context, args1);
		}
		public void updateEquipmentContingency(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY};			
			updateDeligationAttribute(context, args1);
		}
		public void updateWorkAmount(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDWORK};			
			updateDeligationAttribute(context, args1);
		}
		public void updateWorksContingency(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMS_WORKS_CONTINGENCY};			
			updateDeligationAttribute(context, args1);
		}
		public void updatePlanningAmount(Context context,String args[]) throws Exception{
             HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDPLANNING};
			updateDeligationAttribute(context, args1);
		}
		public void updatePlanningContingency(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMS_PLANNING_CONTINGENCY};			
			updateDeligationAttribute(context, args1);
		}
		public void updateEquipmentRemarks(Context context,String args[]) throws Exception{
			 HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDEQUIPMENTREMARKS};
			updateDeligationAttribute(context, args1);
		}
		public void updateWorkRemarks(Context context,String args[]) throws Exception{
			 HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDWORKREMARKS};
			updateDeligationAttribute(context, args1);
		}
		public void updatePlanningRemarks(Context context,String args[]) throws Exception{
			 HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDPLANNINGREMARKS};
			updateDeligationAttribute(context, args1);
		}
		
		public int createDelegation(Context context, String[] args)throws Exception 
		{			
			String sObjectId = args[0];			
			DomainObject socObj = new DomainObject(sObjectId);
			String revision = "";
			revision = new Policy(POLICY_WMSDELEGATION).getFirstInMinorSequence(context);		
            StringList relSelects = new StringList();
            relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				DomainObject domDelegation=DomainObject.newInstance(context);
				MapList mMap = socObj.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", null, relSelects, false, true, (short)0, null, null,0,null,null,null);				
				if(mMap.size()==0){
				String strDelegationName = DomainObject.getAutoGeneratedName(context, "type_WMSDelegation", "");			
				domDelegation.createObject(context, TYPE_WMSDELEGATION, strDelegationName,revision,POLICY_WMSDELEGATION, "eService Production");
				DomainRelationship domRel = DomainRelationship.connect(context, socObj, RELATIONSHIP_WMSSOCDELEGATION, domDelegation);
				}
				
			}
			return 0;
		}
		
	public boolean getDelegateOption(Context context, String[] args) throws Exception
    {
    	boolean showDelegation = false;  
    	try 
    	{
			Map programMap  = JPO.unpackArgs(args);
			String objectId = (String)programMap.get("objectId");		
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(2);
    		selects.add(DomainConstants.SELECT_ID);
			selects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(objectId))
            {
				domProject = DomainObject.newInstance(context, objectId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
				if (socList.size() == 1) {
					Map mSoc = (Map)socList.get(0);
					String sSocId =(String)mSoc.get("id");
					String sSOCState =(String)mSoc.get(DomainConstants.SELECT_CURRENT);
					if (UIUtil.isNullOrEmpty(sSOCState) || (!sSOCState.equalsIgnoreCase(STATE_WMSSOC_DELEGATION) && !sSOCState.equalsIgnoreCase(STATE_WMSSOC_UNDEREXECUTION))){
						return showDelegation;
					}
					DomainObject domSOC = DomainObject.newInstance(context, sSocId);
					MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
					if (delegationList.size() == 1) {
						Map mDelegate = (Map)delegationList.get(0);
						String sStste =(String)mDelegate.get(DomainConstants.SELECT_CURRENT);
						if(sStste.equalsIgnoreCase(STATE_DELEGATECREATE)) {
							showDelegation = true;
						}
					}
				}
			    
			
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		return showDelegation;
    }
	
	public boolean getReDelegateOption(Context context, String[] args) throws Exception
    {
    	boolean showDelegation = false;  
    	try 
    	{
			Map programMap  = JPO.unpackArgs(args);
			String objectId = (String)programMap.get("objectId");			
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(2);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(objectId))
            {
				domProject = DomainObject.newInstance(context, objectId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
				if (socList.size() == 1) {
					Map mSoc = (Map)socList.get(0);
					String sSocId =(String)mSoc.get("id");
					String sSOCState = (String)mSoc.get(DomainConstants.SELECT_CURRENT);
					if (UIUtil.isNullOrEmpty(sSOCState) || (!sSOCState.equalsIgnoreCase(STATE_WMSSOC_DELEGATION) && !sSOCState.equalsIgnoreCase(STATE_WMSSOC_UNDEREXECUTION))){
						return showDelegation;
					}
					DomainObject domSOC = DomainObject.newInstance(context, sSocId);
					MapList mlAdminApprovalList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCADMINAPPROVAL, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
					if (mlAdminApprovalList.size() == 1) {
						Map mAdminApproval = (Map)mlAdminApprovalList.get(0);
						String sStste =(String)mAdminApproval.get(DomainConstants.SELECT_CURRENT);
						if("Approved".equalsIgnoreCase(sStste)) {
							showDelegation = true;
						}
					}
					
					MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
					if (delegationList.size() == 1) {
						Map mDelegate = (Map)delegationList.get(0);
						String sStste =(String)mDelegate.get(DomainConstants.SELECT_CURRENT);
						if(sStste.equalsIgnoreCase("Delegate")) {
							showDelegation = true;
						}else{
							showDelegation = false;
						}
					}
				}				 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		return showDelegation;
    }
	public int checkdelegationdetails(Context context, String[] args) throws Exception
	{
		    String sObjectId = args[0];	
			Double Sum ;
			StringList objectSelects = new StringList();
			objectSelects.add("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
			objectSelects.add("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
			objectSelects.add("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");		
			if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				DomainObject domDelegation=DomainObject.newInstance(context,sObjectId);
				Map mAmp = domDelegation.getInfo(context,objectSelects);
				String sEquipAmount =(String)mAmp.get("attribute[WMSApprovedAmountEquipment]");
				String sPlanAmount = (String)mAmp.get("attribute[WMSApprovedAmountPlanning]");
				String sWorkAmount = (String)mAmp.get("attribute[WMSApprovedAmountWork]");
				Sum =Double.parseDouble(sEquipAmount) + Double.parseDouble(sPlanAmount) + Double.parseDouble(sWorkAmount);							
				if(Sum <= 0)		
			     {					
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "Please enter delegation Details");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
					
				}
				String sRouteCheckNotice = "";
				MapList mlRoute = domDelegation.getRelatedObjects(context,"Object Route", "Route", false, true, 0, new StringList(DomainConstants.SELECT_ID),null, "", "", 0, "", "", null);
				if(mlRoute.size()==0){
					sRouteCheckNotice = "Please add Route and then proceed";
					emxContextUtil_mxJPO.mqlNotice(context,sRouteCheckNotice);
					return 1;				
				}	
				
			}
		return 0;
    }
	public static int createApprovalRoute(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doDelObj = null;
			DomainObject dSOCObj = null;
			String strTemplateId ="";
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				doDelObj = new DomainObject(sObjectId);
				MapList socList = doDelObj.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, false, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				
				
				StringList slDomSels = new StringList();
				slDomSels.add("policy");
				slDomSels.add("current");

				Map mDomValues = (Map)doDelObj.getInfo(context, slDomSels);
				System.out.println("mDomValues = "+mDomValues);

				Map relMap = new HashMap();
				relMap.put("Route Base Policy", "policy_"+(String)mDomValues.get("policy"));
				relMap.put("Route Base State", "state_"+(String)mDomValues.get("current"));
				relMap.put("Route Base Purpose", "Review");				
				
				
				dSOCObj = new DomainObject(sSocId);
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\" || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doDelObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);					
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						
						String RelIDRoute = (String)mRoute.get(DomainRelationship.SELECT_ID);
						DomainRelationship drelObjectRoute = new DomainRelationship(RelIDRoute);						
						drelObjectRoute.setAttributeValues(context, relMap);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
				} 
				/*else {
					
					String strPolicy = (String)doDelObj.getInfo(context,DomainConstants.SELECT_POLICY);
					String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"Delegation\"";
					MapList routeMapList= dSOCObj.getRelatedObjects(context, RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
					if(routeMapList != null && !routeMapList.isEmpty()){
						Map mRouteTemplateMap = (Map)routeMapList.get(0);
						strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
						String sRouteDescription = (String)doDelObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
						String sState = (String)doDelObj.getInfo(context, DomainConstants.SELECT_CURRENT);
						String strContectUser =  context.getUser();
						Map mRouteAttrib= new HashMap();
						mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
					   
						Map objectRouteAttributeMap=new HashMap();
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy,false ));
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Review");
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,"Review");
						Map reviewerInfo= new HashMap();
					   
						Route.createAndStartRouteFromTemplateAndReviewers(context,
										strTemplateId,
										sRouteDescription,
										strContectUser ,
										sObjectId,
										strPolicy,
										sState,
										mRouteAttrib,
										objectRouteAttributeMap,
										reviewerInfo,
										true);
						/*String strStatus = route.getAttributeValue(context, DomainConstants.ATTRIBUTE_ROUTE_STATUS);
						if(strStatus.equalsIgnoreCase("Not Started")) {
							route.promote(context);
						}
					}*/
					
					}
				
					return 0;
			}
  catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}	
	   public String showApprovalWorkflow(Context context,String [] args) throws Exception {
			StringBuilder sb=new StringBuilder();
			Map mInputMap = (Map) JPO.unpackArgs(args);
			Map requestMap = (Map) mInputMap.get("requestMap");
			String sProjectId = (String)requestMap.get("objectId");
			DomainObject domObject=new DomainObject(sProjectId);
			String sWhere = "revision == last";
			StringList selects = new StringList(1);
			selects.add(DomainConstants.SELECT_ID);
			
			String sSOCObjId = domObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)){
				DomainObject domSOC = DomainObject.newInstance(context, sSOCObjId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
				if(delegationList.size()>0){			
					Map mDelegate = (Map)delegationList.get(0);
					String sDelegated =(String)mDelegate.get("id");
					String shref = "../wms/wmsActiveTaskGraphicalForAdminApproval.jsp";
					sb.append("<a href=\"javascript:showModalDialog('"+shref+"?objectId="+sDelegated+"','600','400','false');\" >");            
					//sb.append("<img border='0' title='Approval Workflow' src='../common/images/iconActionApprovalMass.png' height='15px' name='Approval Workflow' id='Approval Workflow'/>");
					sb.append("View");
					sb.append("</a>");
				}
			}
			return sb.toString();
		}
		
		public String showOthersEditIcon(Context context,String [] args) throws Exception {
			StringBuilder sb=new StringBuilder();
			Map mInputMap = (Map) JPO.unpackArgs(args);
			Map requestMap = (Map) mInputMap.get("requestMap");
			String sProjectId = (String)requestMap.get("objectId");
			DomainObject domObject=new DomainObject(sProjectId);
			String sWhere = "revision == last";
			StringList selects = new StringList(1);
			selects.add(DomainConstants.SELECT_ID);
			
			String sSOCObjId = domObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)){
				DomainObject domSOC = DomainObject.newInstance(context, sSOCObjId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
				if(delegationList.size()>0){			
					Map mDelegate = (Map)delegationList.get(0);
					String sDelegated =(String)mDelegate.get("id");
					String shref = "emxIndentedTable.jsp?program=WMSDelegation:getAssociatedOtherItems&selection=multiple&toolbar=WMSDelegationOtherItemsToolbar&table=WMSAssociatedOtherItems&objectId="+sDelegated;
					sb.append("<a href=\"javascript:showModalDialog('"+shref+"','600','400','false');\" >");            
					sb.append("<img border='0' title='Add Contingency Consultancy Others' src='../common/images/iconActionApprovalMass.png' height='15px' name='Add Contingency Consultancy Others' id='Add Contingency Consultancy Others'/>");
					sb.append("</a>");
				}
			}
			return sb.toString();
		}
		
		
		@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAssociatedOtherItems(Context context, String[] args) throws Exception
	{
		MapList mlReturnMapList = new MapList();
		Map mInputMap = (Map) JPO.unpackArgs(args);
		String sDelegationId = (String)mInputMap.get("objectId");
		DomainObject doDelegation = DomainObject.newInstance(context, sDelegationId);
		StringList slObjSels = new StringList();
		slObjSels.addElement("id");
		StringList slRelSels = new StringList();
		slRelSels.addElement("id[connection]");
		mlReturnMapList = (MapList)doDelegation.getRelatedObjects(context, "WMSDelegationOtherItems", "*", slObjSels, slRelSels, false, true, (short)1, null, null,0,null,null,null);
		return mlReturnMapList;
	}
	
	public void updateOtherItemsAttributeValueWorks (Context context, String[] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strRelId = (String) paramMap.get("relId");
		String newValue = (String) paramMap.get("New Value");
		DomainRelationship domRel = DomainRelationship.newInstance(context, strRelId);
		domRel.setAttributeValue(context, "WMSWorksDelegationAmount", newValue);
	}
	public Vector getOtherItemsAttributeValueWorks (Context context, String[] args) throws Exception
	{
		Vector vReturnVector = new Vector();
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		
		for (int i = 0 ; i < objectList.size(); i++)
		{
			Map mTemp = (Map)objectList.get(i);
			DomainRelationship domRel = DomainRelationship.newInstance(context, (String)mTemp.get("id[connection]"));
			vReturnVector.add(domRel.getAttributeValue(context, "WMSWorksDelegationAmount"));
		}
		return vReturnVector;
	}
	public void updateOtherItemsAttributeValueEquipments (Context context, String[] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strRelId = (String) paramMap.get("relId");
		String newValue = (String) paramMap.get("New Value");
		DomainRelationship domRel = DomainRelationship.newInstance(context, strRelId);
		domRel.setAttributeValue(context, "WMSEquipmentDelegationAmount", newValue);
	}
	public Vector getOtherItemsAttributeValueEquipments (Context context, String[] args) throws Exception
	{
		Vector vReturnVector = new Vector();
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		
		for (int i = 0 ; i < objectList.size(); i++)
		{
			Map mTemp = (Map)objectList.get(i);
			DomainRelationship domRel = DomainRelationship.newInstance(context, (String)mTemp.get("id[connection]"));
			vReturnVector.add(domRel.getAttributeValue(context, "WMSEquipmentDelegationAmount"));
		}
		return vReturnVector;
	}
	public void updateOtherItemsAttributeValuePlanning (Context context, String[] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strRelId = (String) paramMap.get("relId");
		String newValue = (String) paramMap.get("New Value");
		DomainRelationship domRel = DomainRelationship.newInstance(context, strRelId);
		domRel.setAttributeValue(context, "WMSPlanningDelegationAmount", newValue);
	}
	public Vector getOtherItemsAttributeValuePlanning (Context context, String[] args) throws Exception
	{
		Vector vReturnVector = new Vector();
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		
		for (int i = 0 ; i < objectList.size(); i++)
		{
			Map mTemp = (Map)objectList.get(i);
			DomainRelationship domRel = DomainRelationship.newInstance(context, (String)mTemp.get("id[connection]"));
			vReturnVector.add(domRel.getAttributeValue(context, "WMSPlanningDelegationAmount"));
		}
		return vReturnVector;
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getApprovedAEOtherItems(Context context, String[] args) throws Exception
	{
		MapList mlReturnMapList = new MapList();
		Map mInputMap = (Map) JPO.unpackArgs(args);
		//System.out.println("mInputMap getApprovedAEOtherItems : " + mInputMap);
		String sProjectId = (String)mInputMap.get("objectId");
		DomainObject doProject = DomainObject.newInstance(context, sProjectId);
		String strSOCId = doProject.getInfo(context, "to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.id");
		//System.out.println("strSOCId getApprovedAEOtherItems : " + strSOCId);
		DomainObject doSOC = DomainObject.newInstance(context, strSOCId);
		
		StringList busSelects = new StringList();
		busSelects.add(DomainConstants.SELECT_ID);
		busSelects.add(DomainConstants.SELECT_OWNER);
		busSelects.add(DomainConstants.SELECT_CURRENT);
		busSelects.add(DomainConstants.SELECT_TYPE);
		busSelects.add(DomainConstants.SELECT_ORIGINATED);
		busSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
		
		MapList mlAEMaster = doSOC.getRelatedObjects(context, // matrix context
												RELATIONSHIP_WMSSOC_APPROVEDAEMASTER, // relationship pattern
												TYPE_WMS_DEFAULT_MASTERS, // type pattern
												busSelects, // object selects
												null, // relationship selects
												false, // to direction
												true, // from direction
												(short) 1, // recursion level
												null, // object where clause
												null); // relationship where clause
		for(int i = 0 ; i < mlAEMaster.size() ; i++)
		{
			Map mTemp = (Map)mlAEMaster.get(i);
			mTemp.put("disableSelection", "true");
		}
		
		return mlAEMaster;
	}
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedAE(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
			String sCommandName=(String) programMap.get("portalCmdName");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			String sObjState = DomainConstants.EMPTY_STRING;
			String sObjRTId = DomainConstants.EMPTY_STRING;
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlAE = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
													TYPE_WMSAE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			mlAE.sort("originated", "ascending", "date");
			return mlAE;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
		
	public String getDelegationRevisionHistory(Context context,String [] args) throws Exception {
		StringBuilder sb = new StringBuilder();
		Map mInputMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) mInputMap.get("requestMap");
		String sProjectId = (String)requestMap.get("objectId");
			
		if(UIUtil.isNotNullAndNotEmpty(sProjectId)){
			String shref = "../common/emxIndentedTable.jsp?table=WMSDelegationRevisions&program=WMSDelegation:getDelegationRevisions&header=Revisions of Delegation";
			sb.append("<a href=\"javascript:showModalDialog('"+shref+"&objectId="+sProjectId+"','600','400','false');\" >");            
			//sb.append("<img border='0' title='Revision History' src='../common/images/iconActionHistory.png' height='15px' name='Revision History' id='Approval Workflow'/>");
			sb.append("View");
			sb.append("</a>");
		}
			return sb.toString();
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getDelegationRevisions(Context context, String[] args) throws Exception{
		try{
			MapList mlRevisionList = new MapList();
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strObjectId = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				DomainObject doProject = new DomainObject(strObjectId);
				String strSOCId = (String)doProject.getInfo(context,"from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
				StringList relSelects = new StringList();
				relSelects.add(DomainRelationship.SELECT_ID);
				StringList objSelects = new StringList();
				objSelects.add(DomainObject.SELECT_ID);			
				objSelects.add(DomainObject.SELECT_REVISION);						
			
				if(UIUtil.isNotNullAndNotEmpty(strSOCId)){
					DomainObject doSOC = new DomainObject(strSOCId);
					mlRevisionList = (MapList)doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", objSelects, relSelects, false, true, (short)0, null, null,0,null,null,null);					
				}		
				if(mlRevisionList.size()>0){
					mlRevisionList.sort(DomainObject.SELECT_REVISION, ProgramCentralConstants.ASCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
				}
			}
			return mlRevisionList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public boolean getDelegationEditOption(Context context, String[] args) throws Exception {
    	boolean showDelegation = false;  
    	try 
    	{
			Map programMap  = JPO.unpackArgs(args);
			String objectId = (String)programMap.get("objectId");			
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(2);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(objectId))
            {
				domProject = DomainObject.newInstance(context, objectId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
				if (socList.size() == 1) {
					Map mSoc = (Map)socList.get(0);
					String sSocId =(String)mSoc.get(DomainConstants.SELECT_ID);
					String sSOCState =(String)mSoc.get(DomainConstants.SELECT_CURRENT);
					if (UIUtil.isNotNullAndNotEmpty(sSOCState) && (sSOCState.equalsIgnoreCase(STATE_WMSSOC_DELEGATION) || sSOCState.equalsIgnoreCase(STATE_WMSSOC_UNDEREXECUTION))) {
						DomainObject domSOC = DomainObject.newInstance(context, sSocId);
						MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
						if (delegationList.size() == 1) {
							Map mDelegate = (Map)delegationList.get(0);
							String sStste =(String)mDelegate.get(DomainConstants.SELECT_CURRENT);
							if(sStste.equalsIgnoreCase(STATE_DELEGATECREATE)) {
								showDelegation = true;
							}
						}
					}
				}				 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		return showDelegation;
    }
	public String getAssociatedProject(Context context,String args[]) throws Exception{
			String sTitle = "";
			try{
			
			Map programMap = (Map) JPO.unpackArgs(args);
			Map requestMap = (Map) programMap.get("requestMap");
				// Get object id
			String strObjectId = (String)requestMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject doAA = new DomainObject(strObjectId);
				String sSOCId = (String)doAA.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.id");
				if(UIUtil.isNotNullAndNotEmpty(sSOCId))
				{
				DomainObject doSOC = new DomainObject(sSOCId);
				sTitle = (String)doSOC.getInfo(context,"to["+RELATIONSHIP_WMSPROJECTSOC+"].from.name");
				}
			}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return sTitle;
		}
		public String getCurrentState(Context context,String args[]) throws Exception{
		String sState = "";
		try{
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
				String sSOCObjId = domProject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");	
				if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)){
					DomainObject domSOC = DomainObject.newInstance(context, sSOCObjId);
					MapList AAList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
					if(AAList.size()>0)
					{
						Map mAA = (Map)AAList.get(0);
						String sAA =(String)mAA.get("id");					
						sState = (String)mAA.get(DomainConstants.SELECT_CURRENT);
					}
				}
				
			}
		}
        catch(Exception e)
		{
			e.printStackTrace();
		}
	return sState;
	}
	public String showApprovalHistory(Context context,String [] args) throws Exception {
		StringBuilder sb = new StringBuilder();
		Map mInputMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) mInputMap.get("requestMap");
		String sProjectId = (String)requestMap.get("objectId");
			
		if(UIUtil.isNotNullAndNotEmpty(sProjectId)){
			String shref = "../common/emxIndentedTable.jsp?table=WMSApprovalHistory&program=WMSDelegation:getAllApprovedTask&header=Approval History of Admin Approval";
			sb.append("<a href=\"javascript:showModalDialog('"+shref+"&objectId="+sProjectId+"','600','400','false');\" >");            
			sb.append("<img border='0' title='Revision History' src='../common/images/iconActionHistory.png' height='15px' name='Approval History' id='Approval History'/>");
			sb.append("</a>");
		}
			return sb.toString();
	}	
	 @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getAllApprovedTask(Context context, String[] args) throws Exception {
		MapList mlInboxTask = new MapList();
		MapList returnList = new MapList();
        try {

			Pattern includeType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
			MapList mlDelegationList = new MapList();
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
           
			String sWhere = "revision == last";
			String strObjectId = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
			DomainObject doProject = new DomainObject(strObjectId);
			String strSOCId = (String)doProject.getInfo(context,"from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			StringList objSelects = new StringList();
			objSelects.add(DomainObject.SELECT_ID);	
			if(UIUtil.isNotNullAndNotEmpty(strSOCId)){
				DomainObject doSOC = new DomainObject(strSOCId);
				mlDelegationList = (MapList)doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", objSelects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mAA = (Map)mlDelegationList.get(0);
			String strID = (String) mAA.get(DomainObject.SELECT_ID);
			
			StringList objectList = new StringList();
			objectList.addElement(DomainConstants.SELECT_ID);
			objectList.addElement(DomainConstants.SELECT_TYPE);
			objectList.addElement(DomainConstants.SELECT_CURRENT);
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_FIRST_NAME+"]");
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.id");
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_LAST_NAME+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ROUTE_TASK_USER+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_APPROVAL_STATUS+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
			objectList.addElement("format.file.name");
			objectList.addElement("format.file.format");
			objectList.addElement("format.file.fileid");
			objectList.addElement("from["+RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].attribute["+ATTRIBUTE_ROUTE_BASE_STATE+"].value");
			
			
			StringList relList = new StringList();
			relList.addElement(DomainRelationship.SELECT_ID);
			relList.addElement("attribute[Route Base State].value");

			DomainObject dObject = DomainObject.newInstance(context,strID);

			MapList mlRoutes = dObject.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_OBJECT_ROUTE,  //String relPattern
					DomainConstants.TYPE_ROUTE, //String typePattern
					objectList,            //StringList objectSelects,
					relList,    		   //StringList relationshipSelects,
					false,                  //boolean getTo,
					true,                  //boolean getFrom,
					(short)1,              //short recurseToLevel,
					"",   				   //String objectWhere,
					//"attribute[Route Base State].value == state_Review",             //String relationshipWhere,
					"",             //String relationshipWhere,
					0);        
			Map mTemp = null;
			String strRouteId = DomainConstants.EMPTY_STRING;
			DomainObject doRoute = null;
			for(int i=0;i<mlRoutes.size();i++){
				mTemp = (Map)mlRoutes.get(i);
				strRouteId = (String)mTemp.get(DomainObject.SELECT_ID);
				doRoute = new DomainObject(strRouteId);
				MapList mlRouteTasks = doRoute.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_ROUTE_TASK,  //String relPattern
					DomainConstants.TYPE_INBOX_TASK, //String typePattern
					objectList,            //StringList objectSelects,
					relList,    		   //StringList relationshipSelects,
					true,                  //boolean getTo,
					false,                  //boolean getFrom,
					(short)1,              //short recurseToLevel,
					"",   				   //String objectWhere,
					"",             //String relationshipWhere,
					0); 
				mlInboxTask.addAll(mlRouteTasks);
			}
			
		Iterator itr = mlInboxTask.iterator();
		while(itr.hasNext()){
			Map returnMap = (Map)itr.next();
			String strState = (String)returnMap.get(DomainConstants.SELECT_CURRENT);
			if(strState != null && !"".equals(strState) && strState.equals("Complete")){
				returnList.add(returnMap);
			}
		  }			
		 }
			}
	     }
		 catch (Exception e){
		
		 }
		 returnList.sort("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]","ascending","date");
		
		  return returnList;
	
	}
	
	public boolean getDownloadDelegationOption(Context context, String[] args) throws Exception
    {
    	boolean showDelegation = false;  
    	try 
    	{
			Map programMap  = JPO.unpackArgs(args);
			String objectId = (String)programMap.get("objectId");			
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(2);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(objectId))
            {
				domProject = DomainObject.newInstance(context, objectId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
				if (socList.size() == 1) {
					Map mSoc = (Map)socList.get(0);
					String sSocId =(String)mSoc.get("id");
					String sSOCState = (String)mSoc.get(DomainConstants.SELECT_CURRENT);
					if (UIUtil.isNullOrEmpty(sSOCState) || (!sSOCState.equalsIgnoreCase(STATE_WMSSOC_DELEGATION) && !sSOCState.equalsIgnoreCase(STATE_WMSSOC_UNDEREXECUTION))){
						return showDelegation;
					}
					DomainObject domSOC = DomainObject.newInstance(context, sSocId);
					MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
					if (delegationList.size() == 1) {
						showDelegation = true;
					}
				}				 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		return showDelegation;
    }
	
	
	public void generateDelegationPDF(Context context, String[] args)throws Exception{
		try{
			HashMap params      = new HashMap();
			String strObjId = (String)args[0];
			DomainObject doDelegation = new DomainObject(strObjId);
			String strSOCId = (String)doDelegation.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.id");
			params.put("objectId", strSOCId);
			String strDelegationId = downloadDelegation(context,JPO.packArgs(params));
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;			
		}
	}
	
	public String downloadDelegation(Context context , String [] args) throws Exception
	{
		String strDelegationId = DomainConstants.EMPTY_STRING;
		
	try {
			HashMap programMap      = (HashMap)JPO.unpackArgs(args);
			String strObjID         = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjID)){
				StringList slWorksItems = new StringList();
				StringList slEquipmentsItems = new StringList();
				StringList slServicesItems = new StringList();
				DomainObject doSOC = new DomainObject(strObjID);
				StringList slObjSelect = new StringList();
				slObjSelect.add(DomainObject.SELECT_ID);
				slObjSelect.add(DomainObject.SELECT_TYPE);
				slObjSelect.add("attribute[Title]");
				slObjSelect.add("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
				slObjSelect.add("from["+TYPE_WMSAE+"]");
				
				StringList slSOCSelect = new StringList();
				slSOCSelect.add("attribute["+ATTRIBUTE_WMSSOC_EQUIPMENTS_INCLUDED+"]");
				slSOCSelect.add("attribute["+ATTRIBUTE_WMSSOC_WORKS_INCLUDED+"]");
				slSOCSelect.add("attribute["+ATTRIBUTE_WMSSOC_SERVICES_INCLUDED+"]");
				slSOCSelect.add("attribute[Title]");
				slSOCSelect.add("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
				
				Map mSOCInfo = doSOC.getInfo(context,slSOCSelect);
				String strEquipSelected = (String)mSOCInfo.get("attribute["+ATTRIBUTE_WMSSOC_EQUIPMENTS_INCLUDED+"]");
				String strWorksSelected = (String)mSOCInfo.get("attribute["+ATTRIBUTE_WMSSOC_WORKS_INCLUDED+"]");
				String strServicesSelected = (String)mSOCInfo.get("attribute["+ATTRIBUTE_WMSSOC_SERVICES_INCLUDED+"]");
				String strProjectTitle = (String)mSOCInfo.get("attribute[Title]");
				String strCodeHead = (String)mSOCInfo.get("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
				
				MapList mlApprivedAEList =  doSOC.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSSOC_APPROVEDAEMASTER, // relationship pattern
														TYPE_WMSAEMASTER, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														null, // object where clause
														null); // relationship where clause
														
					
				//Map mTemp = null;
				double dEquipmentAmount = 0.0;
				double dWorksAmount = 0.0;
				double dPlanningAmount = 0.0;
				
				double dEquipmentContAmount = 0.0;
				double dWorksContAmount = 0.0;
				double dPlanningContAmount = 0.0;
				
				double dEquipmentAmountprevious = 0.0;
				double dWorksAmountprevious = 0.0;
				double dPlanningAmountprevious = 0.0;
				
				double dEquipmentContAmountprevious = 0.0;
				double dWorksContAmountprevious = 0.0;
				double dPlanningContAmountprevious = 0.0;
				
				String strTitle = DomainConstants.EMPTY_STRING;
				String strId = DomainConstants.EMPTY_STRING;
				String strEquipmentSeq = DomainConstants.EMPTY_STRING;
				String strWorksSeq = DomainConstants.EMPTY_STRING;
				String strServicesSeq = DomainConstants.EMPTY_STRING;
				
				String strAAAmount = DomainConstants.EMPTY_STRING;
				String strAADuration = DomainConstants.EMPTY_STRING;
				String strAALetterNo = DomainConstants.EMPTY_STRING;
				String strAADate = DomainConstants.EMPTY_STRING;		
				String strDelName = DomainConstants.EMPTY_STRING;
				String strDelRev = DomainConstants.EMPTY_STRING;
				String strDelDate = DomainConstants.EMPTY_STRING;
				String strDelState = DomainConstants.EMPTY_STRING;
				String strDGName = DomainConstants.EMPTY_STRING;
				String strDGDesignation = DomainConstants.EMPTY_STRING;
				
				String strCodeHeadName = DomainConstants.EMPTY_STRING;
				String strMajorHead = DomainConstants.EMPTY_STRING;
				String strMinorHead = DomainConstants.EMPTY_STRING;
				String strDelDateprevious = DomainConstants.EMPTY_STRING;
				String strDelNameprevious = DomainConstants.EMPTY_STRING;
				String strDelRevprevious = DomainConstants.EMPTY_STRING;
				String strDelegationIdprevious = DomainConstants.EMPTY_STRING;
				String strDelStateprevious = DomainConstants.EMPTY_STRING;
						
				
				if(UIUtil.isNotNullAndNotEmpty(strCodeHead)){
					DomainObject doCodeHead = new DomainObject(strCodeHead);
					StringList slCodeHeadSelect = new StringList();
					slCodeHeadSelect.add("attribute[Title]");
					slCodeHeadSelect.add("attribute["+ATTRIBUTE_WMS_MAJOR_HEAD+"]");
					slCodeHeadSelect.add("attribute["+ATTRIBUTE_WMS_MINOR_HEAD+"]");
					Map mCodeHeadInfo = doCodeHead.getInfo(context,slCodeHeadSelect);
					
					if(mCodeHeadInfo!=null){
						strCodeHeadName = (String)mCodeHeadInfo.get("attribute[Title]");
						strMajorHead = (String)mCodeHeadInfo.get("attribute["+ATTRIBUTE_WMS_MAJOR_HEAD+"]");
						strMinorHead = (String)mCodeHeadInfo.get("attribute["+ATTRIBUTE_WMS_MINOR_HEAD+"]");
					}
				}
				
				
				Map mTempAE = null;
				MapList mlTemp = new MapList();
				String strSeq = DomainConstants.EMPTY_STRING;
				String strHasChild = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlApprivedAEList.size();i++){
					Map mTemp = null;
					mTemp = (Map)mlApprivedAEList.get(i);
					strTitle = (String)mTemp.get("attribute[Title]");
					strId = (String)mTemp.get(DomainObject.SELECT_ID);				
					
					if("Services".equals(strTitle)){
						DomainObject doAEMastet = new DomainObject(strId);
						MapList mlAEList =  doAEMastet.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														null, // object where clause
														null); // relationship where clause
														mlAEList.sort("attribute[WMSItemSequence]", "ascending", "real");
														
						for(int j=0;j<mlAEList.size();j++){
							mTempAE = (Map)mlAEList.get(j);
							strHasChild = (String)mTempAE.get("from["+TYPE_WMSAE+"]");
							
							slServicesItems.add((String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]"));
							//alSortServiceItems.add((String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]"));
							/*if(UIUtil.isNullOrEmpty(strServicesSeq)){
								strServicesSeq = (String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
							}else{
								strServicesSeq = strServicesSeq+","+(String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
							}*/
						}
						
					}
					
					//Collections.sort(slServicesItems);
					
					if("Equipments".equals(strTitle)){					
						DomainObject doAEMastet = new DomainObject(strId);
						MapList mlAEList =  doAEMastet.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														null, // object where clause
														null); // relationship where clause
														mlAEList.sort("attribute[WMSItemSequence]", "ascending", "real");
														
														
						MapList mlTemp2 = new MapList();
						for(int k = 0 ; k < mlAEList.size(); k++)
						{
							Map hmTemp = (Map)mlAEList.get(k);
							if(!"1".equals((String)hmTemp.get("level")))
								mlTemp2.add(hmTemp);
						}
						mlTemp2.sort("attribute[WMSItemSequence]", "ascending", "real");
						
						for(int j=0;j<mlTemp2.size();j++){
							mTempAE = (Map)mlTemp2.get(j);
							strHasChild = (String)mTempAE.get("from["+TYPE_WMSAE+"]");
							slEquipmentsItems.add((String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]"));
							/*if(UIUtil.isNullOrEmpty(strEquipmentSeq)){
								strEquipmentSeq = (String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
							}else{
								strEquipmentSeq = strEquipmentSeq+", "+(String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
							}*/
						}
					}
					
					if("Works".equals(strTitle)){
						DomainObject doAEMastet = new DomainObject(strId);
						 MapList mlAEList =  doAEMastet.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 2, // recursion level
														null, // object where clause
														null); // relationship where clause
														//mlAEList.sort("attribute[WMSItemSequence]", "ascending", "real");
														
						MapList mlTemp2 = new MapList();
						mlTemp2 = mlAEList;
						/*
						for(int k = 0 ; k < mlAEList.size(); k++)
						{
							Map hmTemp = (Map)mlAEList.get(k);
							if(!"1".equals((String)hmTemp.get("level")))
								mlTemp2.add(hmTemp);
						}*/
						mlTemp2.sort("attribute[WMSItemSequence]", "ascending", "real");
						
						for(int j=0;j<mlTemp2.size();j++){
							mTempAE = (Map)mlTemp2.get(j);
							strHasChild = (String)mTempAE.get("from["+TYPE_WMSAE+"]");
							if(UIUtil.isNotNullAndNotEmpty(strHasChild) && "false".equalsIgnoreCase(strHasChild)){
								//alSortWorkItems.add((String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]"));
								slWorksItems.add((String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]"));
								/*if(UIUtil.isNullOrEmpty(strWorksSeq)){
									strWorksSeq = (String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
								}else{
									strWorksSeq = strWorksSeq+", "+(String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
								}*/
							}

						}
					}
				}
				Collections.sort(slWorksItems);
				Collections.sort(slServicesItems);
				Collections.sort(slEquipmentsItems);
				
				for(int ctrItems=0;ctrItems<slWorksItems.size();ctrItems++){
					if(UIUtil.isNullOrEmpty(strWorksSeq)){
						strWorksSeq = (String)slWorksItems.get(ctrItems);
					}else{
						strWorksSeq = strWorksSeq+", "+(String)slWorksItems.get(ctrItems);
					}
				}
				
				for(int ctrItems=0;ctrItems<slEquipmentsItems.size();ctrItems++){
					if(UIUtil.isNullOrEmpty(strEquipmentSeq)){
						strEquipmentSeq = (String)slEquipmentsItems.get(ctrItems);
					}else{
						strEquipmentSeq = strEquipmentSeq+", "+(String)slEquipmentsItems.get(ctrItems);
					}
				}
				
				for(int ctrItems=0;ctrItems<slServicesItems.size();ctrItems++){
					if(UIUtil.isNullOrEmpty(strServicesSeq)){
						strServicesSeq = (String)slServicesItems.get(ctrItems);
					}else{
						strServicesSeq = strServicesSeq+", "+(String)slServicesItems.get(ctrItems);
					}
				}
				
				/**/
				
				
				if(UIUtil.isNotNullAndNotEmpty(strWorksSelected) && "true".equalsIgnoreCase(strWorksSelected)){
					strWorksSelected = strWorksSelected +","+ strServicesSeq;
					
				}else if(UIUtil.isNotNullAndNotEmpty(strEquipSelected) && "true".equalsIgnoreCase(strEquipSelected)){
					strEquipSelected = strEquipSelected +","+ strServicesSeq;
				}else{
					if(UIUtil.isNullOrEmpty(strWorksSelected))
						strWorksSelected = strServicesSeq;
					else
						strWorksSelected = strWorksSelected +", "+ strServicesSeq;
				}
								
				String sWhere = "revision == last";
				StringList slDelSelect = new StringList();
				slDelSelect.add(DomainObject.SELECT_ID);
				slDelSelect.add(DomainObject.SELECT_NAME);
				slDelSelect.add(DomainObject.SELECT_ORIGINATED);
				slDelSelect.add(DomainObject.SELECT_REVISION);
				slDelSelect.add(DomainObject.SELECT_CURRENT);
				slDelSelect.add("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
				MapList delegationList = doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", slDelSelect, null, true, true, (short)0, sWhere, null,0,null,null,null);
				
				MapList mlOtherItems = new MapList();
				MapList mlOtherItemsWorks = new MapList();
				MapList mlOtherItemsEquip = new MapList();
				MapList mlOtherItemsPlanning = new MapList();
				
				if(delegationList.size()>0){
					Map mDelegate = (Map)delegationList.get(0);
					if(mDelegate != null){
						String strWorksAmount = (String)mDelegate.get("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
						String strEquipAmount = (String)mDelegate.get("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
						String strPlanAmount = (String)mDelegate.get("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
						String strWorksCont = (String)mDelegate.get("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
						String strEquipCont = (String)mDelegate.get("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
						String strPlanCont = (String)mDelegate.get("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
						strDelName = (String)mDelegate.get(DomainObject.SELECT_NAME);
						strDelRev = (String)mDelegate.get(DomainObject.SELECT_REVISION);
						strDelDate = (String)mDelegate.get(DomainObject.SELECT_ORIGINATED);
						strDelegationId = (String)mDelegate.get(DomainObject.SELECT_ID);
						strDelState = (String)mDelegate.get(DomainObject.SELECT_CURRENT);
						
						if(UIUtil.isNotNullAndNotEmpty(strDelState) && "Delegate".equals(strDelState)){
							strDelDate = MqlUtil.mqlCommand(context,"print bus "+strDelegationId+" select state[Delegate].actual dump");
						}else{
							
						}
						if(UIUtil.isNullOrEmpty(strWorksAmount))
							strWorksAmount = "0";
						if(UIUtil.isNullOrEmpty(strEquipAmount))
							strEquipAmount = "0";
						if(UIUtil.isNullOrEmpty(strPlanAmount))
							strPlanAmount = "0";
						if(UIUtil.isNullOrEmpty(strWorksCont))
							strWorksCont = "0";
						if(UIUtil.isNullOrEmpty(strEquipCont))
							strEquipCont = "0";
						if(UIUtil.isNullOrEmpty(strPlanCont))
							strPlanCont = "0";
						
						dEquipmentAmount = Double.valueOf(strEquipAmount);
						dWorksAmount = Double.valueOf(strWorksAmount);
						dPlanningAmount = Double.valueOf(strPlanAmount);
						dEquipmentContAmount = Double.valueOf(strEquipCont);
						dWorksContAmount = Double.valueOf(strWorksCont);
						dPlanningContAmount = Double.valueOf(strPlanCont);
						
						DomainObject doDelegation = DomainObject.newInstance(context, strDelegationId);
						StringList slRelSels = new StringList();
						slRelSels.addElement("attribute[WMSWorksDelegationAmount].value");
						slRelSels.addElement("attribute[WMSEquipmentDelegationAmount].value");
						slRelSels.addElement("attribute[WMSPlanningDelegationAmount].value");
						StringList slObjSels = new StringList();
						slObjSels.addElement("id");
						slObjSels.addElement("attribute[Title].value");
						slObjSels.addElement("attribute[WMSItemSequence].value");
						mlOtherItems = doDelegation.getRelatedObjects(context, // matrix context
																			"WMSDelegationOtherItems", // relationship pattern
																			"*", // type pattern
																			slObjSels, // object selects
																			slRelSels, // relationship selects
																			false, // to direction
																			true, // from direction
																			(short) 1, // recursion level
																			null, // object where clause
																			null);
						for (int k = 0 ; k < mlOtherItems.size() ;k++)
						{
							/*
							MapList mlOtherItemsWorks = new MapList();
							MapList mlOtherItemsEquip = new MapList();
							MapList mlOtherItemsPlanning = new MapList();
							*/
							HashMap hmTempWorks = new HashMap();
							HashMap hmTempEquip = new HashMap();
							HashMap hmTempPlan = new HashMap();
							
							hmTempWorks.put("text", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempWorks.put("value", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSWorksDelegationAmount].value"));
							dWorksContAmount += Double.valueOf((String)((Map)mlOtherItems.get(k)).get("attribute[WMSWorksDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempWorks.get("value")))
								mlOtherItemsWorks.add(hmTempWorks);
							
							hmTempEquip.put("text", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempEquip.put("value", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSEquipmentDelegationAmount].value"));
							dEquipmentContAmount += Double.valueOf((String)((Map)mlOtherItems.get(k)).get("attribute[WMSEquipmentDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempEquip.get("value")))
								mlOtherItemsEquip.add(hmTempEquip);
							
							hmTempPlan.put("text", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempPlan.put("value", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSPlanningDelegationAmount].value"));
							dPlanningContAmount += Double.valueOf((String)((Map)mlOtherItems.get(k)).get("attribute[WMSPlanningDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempPlan.get("value")))
								mlOtherItemsPlanning.add(hmTempPlan);
						}
					}
				}
				String sWhereprevious = "revision == last.previous";
				StringList slDelSelectList = new StringList();
				slDelSelectList.add(DomainObject.SELECT_ID);
				slDelSelectList.add(DomainObject.SELECT_NAME);
				slDelSelectList.add(DomainObject.SELECT_ORIGINATED);
				slDelSelectList.add(DomainObject.SELECT_REVISION);
				slDelSelectList.add(DomainObject.SELECT_CURRENT);
				slDelSelectList.add("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
				MapList delegationListprevious = doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", slDelSelectList, null, true, true, (short)0, sWhereprevious, null,0,null,null,null);
				
				MapList mlOtherItemsprevious = new MapList();
				MapList mlOtherItemsWorksprevious = new MapList();
				MapList mlOtherItemsEquipprevious = new MapList();
				MapList mlOtherItemsPlanningprevious = new MapList();
				
				if(delegationListprevious.size()>0){
					Map mDelegateprevious = (Map)delegationListprevious.get(0);
					if(mDelegateprevious != null){
						String strWorksAmountprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
						String strEquipAmountprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
						String strPlanAmountprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
						String strWorksContprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
						String strEquipContprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
						String strPlanContprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
						strDelNameprevious = (String)mDelegateprevious.get(DomainObject.SELECT_NAME);
						strDelRevprevious = (String)mDelegateprevious.get(DomainObject.SELECT_REVISION);
						strDelDateprevious = (String)mDelegateprevious.get(DomainObject.SELECT_ORIGINATED);
						strDelegationIdprevious = (String)mDelegateprevious.get(DomainObject.SELECT_ID);
						strDelStateprevious = (String)mDelegateprevious.get(DomainObject.SELECT_CURRENT);
					
						if(UIUtil.isNotNullAndNotEmpty(strDelStateprevious) && "Delegate".equals(strDelStateprevious)){
							strDelDateprevious = MqlUtil.mqlCommand(context,"print bus "+strDelegationIdprevious+" select state[Delegate].actual dump");
						}else{
							
						}
						if(UIUtil.isNullOrEmpty(strWorksAmountprevious))
							strWorksAmountprevious = "0";
						if(UIUtil.isNullOrEmpty(strEquipAmountprevious))
							strEquipAmountprevious = "0";
						if(UIUtil.isNullOrEmpty(strPlanAmountprevious))
							strPlanAmountprevious = "0";
						if(UIUtil.isNullOrEmpty(strWorksContprevious))
							strWorksContprevious = "0";
						if(UIUtil.isNullOrEmpty(strEquipContprevious))
							strEquipContprevious = "0";
						if(UIUtil.isNullOrEmpty(strPlanContprevious))
							strPlanContprevious = "0";
						
						dEquipmentAmountprevious = Double.valueOf(strEquipAmountprevious);
						dWorksAmountprevious = Double.valueOf(strWorksAmountprevious);
						dPlanningAmountprevious = Double.valueOf(strPlanAmountprevious);
						dEquipmentContAmountprevious = Double.valueOf(strEquipContprevious);
						dWorksContAmountprevious = Double.valueOf(strWorksContprevious);
						dPlanningContAmountprevious = Double.valueOf(strPlanContprevious);
						
						DomainObject doDelegationprevious = DomainObject.newInstance(context, strDelegationIdprevious);
						StringList slRelSels = new StringList();
						slRelSels.addElement("attribute[WMSWorksDelegationAmount].value");
						slRelSels.addElement("attribute[WMSEquipmentDelegationAmount].value");
						slRelSels.addElement("attribute[WMSPlanningDelegationAmount].value");
						StringList slObjSels = new StringList();
						slObjSels.addElement("id");
						slObjSels.addElement("attribute[Title].value");
						slObjSels.addElement("attribute[WMSItemSequence].value");
						mlOtherItemsprevious = doDelegationprevious.getRelatedObjects(context, // matrix context
																			"WMSDelegationOtherItems", // relationship pattern
																			"*", // type pattern
																			slObjSels, // object selects
																			slRelSels, // relationship selects
																			false, // to direction
																			true, // from direction
																			(short) 1, // recursion level
																			null, // object where clause
																			null);
						for (int k = 0 ; k < mlOtherItemsprevious.size() ;k++)
						{
							/*
							MapList mlOtherItemsWorks = new MapList();
							MapList mlOtherItemsEquip = new MapList();
							MapList mlOtherItemsPlanning = new MapList();
							*/
							HashMap hmTempWorks = new HashMap();
							HashMap hmTempEquip = new HashMap();
							HashMap hmTempPlan = new HashMap();
							
							hmTempWorks.put("text", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempWorks.put("value", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSWorksDelegationAmount].value"));
							dWorksContAmountprevious += Double.valueOf((String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSWorksDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempWorks.get("value")))
								mlOtherItemsWorksprevious.add(hmTempWorks);
							
							hmTempEquip.put("text", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempEquip.put("value", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSEquipmentDelegationAmount].value"));
							dEquipmentContAmountprevious += Double.valueOf((String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSEquipmentDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempEquip.get("value")))
								mlOtherItemsEquipprevious.add(hmTempEquip);
							
							hmTempPlan.put("text", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempPlan.put("value", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSPlanningDelegationAmount].value"));
							dPlanningContAmountprevious += Double.valueOf((String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSPlanningDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempPlan.get("value")))
								mlOtherItemsPlanningprevious.add(hmTempPlan);
						}
					}
				}
				
				double dWorksTotal = 0.0;
				double dEquipmentTotal = 0.0;
				double dPlanningTotal = 0.0;
				
				double dWorksTotalprevious = 0.0;
				double dEquipmentTotalprevious = 0.0;
				double dPlanningTotalprevious = 0.0;
				
				dWorksTotal = dWorksAmount+dWorksContAmount;
				dEquipmentTotal = dEquipmentAmount+dEquipmentContAmount;
				dPlanningTotal=dPlanningContAmount;
				String strWorksTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksTotal);
				String strEquipmentTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentTotal);
				String strplanningTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dPlanningTotal);
				strWorksTotal = "Rs. "+strWorksTotal;
				strEquipmentTotal = "Rs. "+strEquipmentTotal;
				strplanningTotal = "Rs. "+strplanningTotal; 
				
				dWorksTotalprevious = dWorksAmountprevious+dWorksContAmountprevious;
				dEquipmentTotalprevious = dEquipmentAmountprevious+dEquipmentContAmountprevious;
				dPlanningTotalprevious=dPlanningContAmountprevious;
				String strWorksTotalprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksTotalprevious);
				String strEquipmentTotalprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentTotalprevious);
				String strplanningTotalprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dPlanningTotalprevious);
				strWorksTotalprevious = "Rs. "+strWorksTotalprevious;
				strEquipmentTotalprevious = "Rs. "+strEquipmentTotalprevious;
				strplanningTotalprevious = "Rs. "+strplanningTotalprevious;
							
				StringList selects = new StringList();
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALDATE+"]");
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALDURATION+"]");
				selects.add("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
				MapList AAList = doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCADMINAPPROVAL, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
				if(AAList.size()>0){
					Map mAA = (Map)AAList.get(0);
					if(mAA != null){
						strAAAmount = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
						strAADuration = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALDURATION+"]");
						strAALetterNo = (String)mAA.get("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
						strAADate = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALDATE+"]");
					}
				}

				DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
				Date date1 = eMatrixDateFormat.getJavaDate(strAADate);
				strAADate = dateFormat.format(date1);
				
				if(UIUtil.isNotNullAndNotEmpty(strDelState) && "Delegate".equals(strDelState)){
					Date date2 = eMatrixDateFormat.getJavaDate(strDelDate);
					strDelDate = dateFormat.format(date2);
				}else{
					SimpleDateFormat simpleformat = new SimpleDateFormat("MMM");
					String strMonth= simpleformat.format(new Date());
					simpleformat = new SimpleDateFormat("yyyy");
					String strYear= simpleformat.format(new Date());
					strDelDate = "  -"+strMonth+"-"+strYear;
				}				
								
				String strDelegationNumber = "DG/_____/_____/_____/_____/_____/Plg";
				String strHeader = strDelName+" Rev. "+strDelRev;
				String strHeaderprevious = strDelNameprevious+" Rev. "+strDelRevprevious;
				
				String strAAInWords = WMSUtil_mxJPO.getValueInWords(strAAAmount);
				strAAAmount = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strAAAmount));
				
				strAAAmount = "Rs. "+strAAAmount+" ("+strAAInWords+" ).";
				strDGName = EnoviaResourceBundle.getProperty(context,"WMS.DGNP.DGName");
				StringList slDG = FrameworkUtil.split(strDGName,"|");
				if(slDG.size()==2){
					strDGName = (String)slDG.get(0);
					strDGDesignation = (String)slDG.get(1);
				}
				//xml write stared
				
				//PDF Customization :: START


								
				//PDF Customization :: END
				
				String strTransPath = context.createWorkspace();
				String xmlSourceFileName = "DelegationFormSource.xml";
				String xmlFilePath = strTransPath + File.separator+xmlSourceFileName;
				//System.out.println("xmlFilePath = "+xmlFilePath);
				DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
				Document document = documentBuilder.newDocument();
				Element root = document.createElement("page");
				document.appendChild(root);
				String strpath = System.getProperty("user.dir");
			    File newFile = new File(strpath+"/..");
				
				String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
				String strLogo = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Logo1");
				String strWatermark = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Watermark");
				strWatermark = strWatermark.replace("\\", "/");
				strLogo = strLogo.replace("\\", "/");
				Element embLogo = document.createElement("logo1");
				embLogo.appendChild(document.createTextNode("file:"+strLogo));
				
				Element embHeader = document.createElement("header-footer");
				Element embHeaderprevious = document.createElement("header-footer");
				Element embWatermark = document.createElement("watermark");
				embWatermark.appendChild(document.createTextNode("file:"+strWatermark));
				if("1".equals(strDelRev)){
				embHeader.appendChild(document.createTextNode(strHeader));
				root.appendChild(embHeader);
				}
				else {
				embHeaderprevious.appendChild(document.createTextNode(strHeaderprevious));
				root.appendChild(embHeaderprevious);
				}
								
				root.appendChild(embHeaderprevious);
				root.appendChild(embWatermark);
				root.appendChild(embLogo);
								
				Element eleLetterNo =  document.createElement("letter-index-no");
				eleLetterNo.appendChild(document.createTextNode(strDelegationNumber));
				root.appendChild(eleLetterNo);
				
				Element elesDate =  document.createElement("letter-date");
				elesDate.appendChild(document.createTextNode(strDelDate));
				root.appendChild(elesDate);
				
				Element elesletterno =  document.createElement("letter-no");
				elesletterno.appendChild(document.createTextNode(strAALetterNo));
				root.appendChild(elesletterno);
				
				Element elesConstructionName =  document.createElement("construction-name");
				elesConstructionName.appendChild(document.createTextNode(strProjectTitle));
				root.appendChild(elesConstructionName);
				
				Element elesamount =  document.createElement("amount");
				elesamount.appendChild(document.createTextNode(strAAAmount));
				root.appendChild(elesamount);
				
				Element elesAADate =  document.createElement("date");
				elesAADate.appendChild(document.createTextNode(strAADate));
				root.appendChild(elesAADate);
					

//my part start
				DomainObject doDel = new DomainObject(strDelegationId);
				StringList slSequenceSelects = new StringList();
				slSequenceSelects.add("attribute[WMSWorksDelegateSequence]");
				slSequenceSelects.add("attribute[WMSEquipmentDelegateSequence]");
				slSequenceSelects.add("attribute[WMSPlanningDelegateSequence]");
				
				StringList slRouteList = (StringList)doDel.getInfoList(context,"from[Object Route].to.id");
				if(slRouteList.size()>0){
					String strDelRoute = (String)slRouteList.get(0);
					if(UIUtil.isNotNullAndNotEmpty(strDelRoute)){
						DomainObject doRoute = DomainObject.newInstance(context,strDelRoute);
						StringList slRouteSelect = new StringList();
						slRouteSelect.add(DomainObject.SELECT_ID);
						slRouteSelect.add(DomainObject.SELECT_NAME);
						slRouteSelect.add("attribute[First Name]");
						slRouteSelect.add("attribute[Last Name]");
						slRouteSelect.add("attribute[HostPersonRole]");
						
						StringList slRouteNodeRelSelect = new StringList();
						slRouteNodeRelSelect.add("attribute[Route Sequence].value");
						slRouteNodeRelSelect.add(DomainRelationship.SELECT_ID);
						
						MapList mlRouteMapList = doRoute.getRelatedObjects(context, "Route Node", "*", slRouteSelect, slRouteNodeRelSelect, false, true, (short)0, "", null,0,null,null,null);
						mlRouteMapList.sort("attribute[Route Sequence].value", "descending", ProgramCentralConstants.SORTTYPE_INTEGER);
						Map mRouteMap = null;
						if(mlRouteMapList.size()>0){
							mRouteMap = (Map)mlRouteMapList.get(0);
							strDGName = (String)mRouteMap.get("attribute[First Name]") +" " +(String)mRouteMap.get("attribute[Last Name]");
							strDGDesignation = (String)mRouteMap.get("attribute[HostPersonRole]");		
						}
					}
				}
								
				Map SequenceCallMap = new HashMap();
								
				Map mSequence = doDel.getInfo(context, slSequenceSelects);
				String sWorkSequenceNo = (String)mSequence.get("attribute[WMSWorksDelegateSequence]");
				String sEquipmentsSequenceNo = (String)mSequence.get("attribute[WMSEquipmentDelegateSequence]");
				String sPlanningSequenceNo = (String)mSequence.get("attribute[WMSPlanningDelegateSequence]");
				

				Map mPDFData = new HashMap();
				
				Map mWorks = new HashMap();
				Map mEquipments = new HashMap();
				Map mPlanning = new HashMap();
				//System.out.println("strWorksTotal = "+strWorksTotal);
				//System.out.println("strWorksTotalprevious = "+strWorksTotalprevious);
				//System.out.println("strEquipmentTotal = "+strEquipmentTotal);
				//System.out.println("strEquipmentTotalprevious = "+strEquipmentTotalprevious);
				//System.out.println("strplanningTotal = "+strplanningTotal);
				
				mWorks.put("ddg-seq"+sWorkSequenceNo+"-total-value", strWorksTotal);
				mWorks.put("ddg-seq"+sWorkSequenceNo+"-total-previous-value", strWorksTotalprevious);
		
				mEquipments.put("ddg-seq"+sEquipmentsSequenceNo+"-total-value", strEquipmentTotal);
				mEquipments.put("ddg-seq"+sEquipmentsSequenceNo+"-total-previous-value", strEquipmentTotalprevious);
				
				mPlanning.put("ddg-seq"+sPlanningSequenceNo+"-total-value", strplanningTotal);
				mPlanning.put("ddg-seq"+sPlanningSequenceNo+"-total-previous-value", strplanningTotal);
				
				Iterator SequenceItr = mSequence.keySet().iterator();
				String sSequenceNo = "";
				while(SequenceItr.hasNext())
				{
					sSequenceNo = (String)mSequence.get(SequenceItr.next());
					if(sSequenceNo.equals(sWorkSequenceNo))
					{
						mPDFData.put(sSequenceNo, mWorks);
					}
					if(sSequenceNo.equals(sEquipmentsSequenceNo))
					{
						mPDFData.put(sSequenceNo, mEquipments);
					}
					if(sSequenceNo.equals(sPlanningSequenceNo))
					{
						mPDFData.put(sSequenceNo, mPlanning);
					}					
				}
				
				//System.out.println("mPDFData = "+mPDFData);

								
				if(mPDFData != null && mPDFData.size() > 0)
				{
					String PDFSequenceNo = "";
					Iterator PDFDataItr = mPDFData.keySet().iterator();
					Map PDFElementMap = new HashMap();
					String PDFElementKey = "";
					while(PDFDataItr.hasNext())
					{
						PDFSequenceNo = (String)PDFDataItr.next();
						PDFElementMap = (Map)mPDFData.get(PDFSequenceNo);
						Iterator PDFElementItr = PDFElementMap.keySet().iterator();
						while(PDFElementItr.hasNext())
						{
							PDFElementKey = (String)PDFElementItr.next();
							Element element =  document.createElement(PDFElementKey);
							element.appendChild(document.createTextNode((String)PDFElementMap.get(PDFElementKey)));
							root.appendChild(element);
						}
						//Element elesTotal =  document.createElement("ddg-seq"+PDFSequenceNo+"-total-value");
						//elesTotal.appendChild(document.createTextNode(strWorksTotal ));
					}					
				}


				Map mWorks2 = new HashMap();
				mWorks2.put("sequence-"+sWorkSequenceNo, WMSUtil_mxJPO.conertToRoman(1));
				mWorks2.put("item-ddg-seq"+sWorkSequenceNo, "Item No. " + strWorksSeq + " of AE Part-I");
				mWorks2.put("item-ddg-seq"+sWorkSequenceNo+"-value", "Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dWorksAmount)));
				mWorks2.put("item-ddg-seq"+sWorkSequenceNo+"-value-previous", "Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dWorksAmountprevious)));
				
				Map mEquipments2 = new HashMap();
				//mWorks2.put("core-element", "delegation-ddg-seq"+sWorkSequenceNo);
	
				mEquipments2.put("sequence-"+sEquipmentsSequenceNo, WMSUtil_mxJPO.conertToRoman(1));
				mEquipments2.put("item-ddg-seq"+sEquipmentsSequenceNo, "Item No. " + strEquipmentSeq + " of AE Part-I");
				mEquipments2.put("item-ddg-seq"+sEquipmentsSequenceNo+"-value", "Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dEquipmentAmount)));
				mEquipments2.put("item-ddg-seq"+sEquipmentsSequenceNo+"-value-previous", "Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dEquipmentAmountprevious)));

				Iterator SequenceCallItr = mSequence.keySet().iterator();
				String SequenceKey = "";
				String SequenceNo = "";
				Map mMethods = new HashMap();
				while(SequenceCallItr.hasNext())
				{
					SequenceKey = (String)SequenceCallItr.next();
					SequenceNo = (String)mSequence.get(SequenceKey);
					if("1".equals(SequenceNo))
					{
						if(SequenceKey.contains("Works"))
							mMethods.put("1","callWorks");
						if(SequenceKey.contains("Equipment"))
							mMethods.put("1","callEquipments");
						if(SequenceKey.contains("Planning"))
							mMethods.put("1", "callPlanning");
					}
					if("2".equals(SequenceNo))
					{
						if(SequenceKey.contains("Works"))
							mMethods.put("2","callWorks");
						if(SequenceKey.contains("Equipment"))
							mMethods.put("2","callEquipments");
						if(SequenceKey.contains("Planning"))
							mMethods.put("2", "callPlanning");
					}
					if("3".equals(SequenceNo))
					{
						if(SequenceKey.contains("Works"))
							mMethods.put("3","callWorks");
						if(SequenceKey.contains("Equipment"))
							mMethods.put("3","callEquipments");
						if(SequenceKey.contains("Planning"))
							mMethods.put("3", "callPlanning");
					}					
				}
				
				//System.out.println("mMethods = "+mMethods);
				
				Iterator itrMethodCall = mMethods.keySet().iterator();
				String sMethodCallKey = "";
				String sMethodCallValue = "";
				while(itrMethodCall.hasNext())
				{
					sMethodCallKey = (String)itrMethodCall.next();
					sMethodCallValue = (String)mMethods.get(sMethodCallKey);
					if("1".equals(sMethodCallKey))
					{
						if(sMethodCallValue.contains("Works"))
						{
							setWork(context, args, mWorks2, root,document,  sWorkSequenceNo, mlOtherItemsWorks, mlOtherItemsWorksprevious);
							break;
						}
							
						if(sMethodCallValue.contains("Equipments"))
						{
							setEquipment(context, args, mEquipments2, root,document, sEquipmentsSequenceNo, mlOtherItemsEquip, mlOtherItemsEquipprevious);
							break;
						}
							
						if(sMethodCallValue.contains("Planning"))
						{
							setPlanning(context, args, root,document, sPlanningSequenceNo, mlOtherItemsPlanning, dPlanningContAmount, dPlanningContAmountprevious);
							break;
						}							
					}
				}


				itrMethodCall = mMethods.keySet().iterator();
				while(itrMethodCall.hasNext())
				{
					sMethodCallKey = (String)itrMethodCall.next();
					sMethodCallValue = (String)mMethods.get(sMethodCallKey);
					if("2".equals(sMethodCallKey))
					{
						if(sMethodCallValue.contains("Works"))
						{
							setWork(context, args, mWorks2, root,document, sWorkSequenceNo, mlOtherItemsWorks, mlOtherItemsWorksprevious);
							break;
						}
							
						if(sMethodCallValue.contains("Equipments"))
						{
							setEquipment(context, args, mEquipments2, root,document, sEquipmentsSequenceNo, mlOtherItemsEquip, mlOtherItemsEquipprevious);
							break;
						}
							
						if(sMethodCallValue.contains("Planning"))
						{
							setPlanning(context, args, root,document, sPlanningSequenceNo, mlOtherItemsPlanning, dPlanningContAmount, dPlanningContAmountprevious);
							break;
						}							
					}
				}

				itrMethodCall = mMethods.keySet().iterator();
				while(itrMethodCall.hasNext())
				{
					sMethodCallKey = (String)itrMethodCall.next();
					sMethodCallValue = (String)mMethods.get(sMethodCallKey);
					if("3".equals(sMethodCallKey))
					{
						if(sMethodCallValue.contains("Works"))
						{
							setWork(context, args, mWorks2, root,document, sWorkSequenceNo, mlOtherItemsWorks, mlOtherItemsWorksprevious);
							break;
						}
							
						if(sMethodCallValue.contains("Equipments"))
						{
							setEquipment(context, args, mEquipments2, root,document, sEquipmentsSequenceNo, mlOtherItemsEquip, mlOtherItemsEquipprevious);
							break;
						}
							
						if(sMethodCallValue.contains("Planning"))
						{
							setPlanning(context, args, root,document, sPlanningSequenceNo, mlOtherItemsPlanning, dPlanningContAmount, dPlanningContAmountprevious);
							break;
						}							
					}
				}				
				
				/*setWork(context, args, mWorks2, root, document, sWorkSequenceNo, mlOtherItemsWorks, mlOtherItemsWorksprevious);
				setEquipment(context, args, mEquipments2, root, document, sEquipmentsSequenceNo, mlOtherItemsEquip, mlOtherItemsEquipprevious);
				setPlanning(context, args, root, document, sPlanningSequenceNo, mlOtherItemsPlanning, dPlanningContAmount, dPlanningContAmountprevious);*/
					
				//---------------------
				//majo header
				Element elemMajorHead = document.createElement("major-head");
				elemMajorHead.appendChild(document.createTextNode(strMajorHead));
				Element elemMinorHead = document.createElement("minor-head");
				elemMinorHead.appendChild(document.createTextNode(strMinorHead));
				Element elemCodeHead = document.createElement("code-head");
				elemCodeHead.appendChild(document.createTextNode(strCodeHeadName));
				root.appendChild(elemMajorHead);
				root.appendChild(elemMinorHead);
				root.appendChild(elemCodeHead);
				
				
				//signature
				 Element elemDGName = document.createElement("dg-name");
                elemDGName.appendChild(document.createTextNode("("+strDGName+")"));
               
                Element elemDGRank = document.createElement("dg-rank");
                elemDGRank.appendChild(document.createTextNode(strDGDesignation));
               
                root.appendChild(elemDGName);
                root.appendChild(elemDGRank);
				
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource domSource = new DOMSource(document);
				StreamResult streamResult = new StreamResult(new File(xmlFilePath));
				transformer.transform(domSource, streamResult);
				File xmlFile = new File(xmlFilePath);
				
				//Write XML - End
				
				//Write XSL - Start
				String strXSLFile ="";
				if("1".equals(strDelRev)){
				strXSLFile= "WMSDelegation.xsl";
				}
				else {
				strXSLFile= "WMSDelegation_Revision.xsl";
				}
				
				
				File newTextFile = new File(strTransPath + File.separator+strXSLFile);

				MQLCommand mql = new MQLCommand();
				mql.open(context);
				mql.executeCommand(context, "print program "+strXSLFile+" select code dump");
				mql.close(context);
				FileWriter fw = new FileWriter(newTextFile);
				fw.write(mql.getResult());
				fw.close();		
				
				File xsltFile = new File(strTransPath + File.separator+strXSLFile);
				StreamSource xmlSource = new StreamSource(new File(xmlFilePath));
				String strName = "Delegation";
				String strFileName = strName+".pdf";
				OutputStream out;
				String strDocumentId = DomainConstants.EMPTY_STRING;
				out = new java.io.FileOutputStream(strTransPath+File.separator+strFileName);
				try {
					FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());		
					FOUserAgent foUserAgent = fopFactory.newFOUserAgent();			
					Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);
					TransformerFactory factory = TransformerFactory.newInstance();
					Transformer transformer1 = factory.newTransformer(new StreamSource(xsltFile));
					Result res = new SAXResult(fop.getDefaultHandler());
					transformer1.transform(xmlSource, res);
					//DomainObject doDel = new DomainObject(strDelegationId);
					ContextUtil.pushContext(context);
					doDel.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strTransPath);
					ContextUtil.popContext(context);
				  } 	
				  catch(Exception exception)
				  {
						exception.printStackTrace();
				  }	
				
				
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return strDelegationId;
	}
	
	public String showDownloadIcon(Context context,String[] args) throws Exception{
		StringBuilder sb=new StringBuilder();
		 try { 
			Map mInputMap = (Map) JPO.unpackArgs(args);
		   Map requestMap = (Map) mInputMap.get("requestMap");
		   String strObjectId = (String) requestMap.get("objectId");
		   String downloadURL = "../components/emxCommonDocumentPreCheckout.jsp?objectAction=download&objectId="+strObjectId; 
		   String strDownLoadTip="Download Bill Form";
		 
			 sb.append("<a href=\"" + downloadURL + "\"  target=\"formViewHidden\"   >");
			 sb.append("<img border=\"0\" src=\"../common/images/iconActionDownload.gif\" alt=\""
			+ strDownLoadTip + "\" title=\"" + strDownLoadTip + "\"></img></a>&#160;");
		
		 }catch(Exception e) {
			 e.printStackTrace();
		 } 
		return  sb.toString();
	 }
	 
	 public StringList getEquipmentDelegations(Context context, String[] args) throws Exception
	{
		StringList slReturnList = new StringList();
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		String strDelId = "";
		String strOtherItemRelId = "";
		StringList slOtherItemsRels = new StringList();
		DomainObject doDelegation = DomainObject.newInstance(context);
		String sEquipment = "";
		for (int i = 0 ; i < objectList.size(); i++)
		{
			sEquipment = "";
			Map mTemp = (Map)objectList.get(i);
			strDelId = (String)mTemp.get(DomainObject.SELECT_ID);
			if(UIUtil.isNotNullAndNotEmpty(strDelId)){
				doDelegation.setId(strDelId);
				slOtherItemsRels = doDelegation.getInfoList(context,"from[WMSDelegationOtherItems].id");
				
				HashMap mAmountMap = new HashMap();
				StringList slItemDetails = new StringList();
				for(int k=0;k<slOtherItemsRels.size();k++){
					strOtherItemRelId = (String)slOtherItemsRels.get(k);
					String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSEquipmentDelegationAmount].value dump |");
					slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
					mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
				}
				Set keySet = mAmountMap.keySet();
				Iterator keys = keySet.iterator();
				int ctr=0;
				while(keys.hasNext())
				{
					String itemName = (String)keys.next();
					String strValue = (String)mAmountMap.get(itemName);
					if(ctr==0)
						sEquipment = itemName + "=" + strValue;
					else
						sEquipment = sEquipment +"<br/>"+ itemName + "=" + strValue;
					ctr++;
				}
			}
			
			slReturnList.add(sEquipment);
		}
		return slReturnList;
	}
	
	public StringList getWorksDelegations(Context context, String[] args) throws Exception
	{
		StringList slReturnList = new StringList();
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		String strDelId = "";
		String strOtherItemRelId = "";
		StringList slOtherItemsRels = new StringList();
		DomainObject doDelegation = DomainObject.newInstance(context);
		String sWorks = "";
		for (int i = 0 ; i < objectList.size(); i++)
		{
			sWorks = "";
			Map mTemp = (Map)objectList.get(i);
			strDelId = (String)mTemp.get(DomainObject.SELECT_ID);
			if(UIUtil.isNotNullAndNotEmpty(strDelId)){
				doDelegation.setId(strDelId);
				slOtherItemsRels = doDelegation.getInfoList(context,"from[WMSDelegationOtherItems].id");
				
				HashMap mAmountMap = new HashMap();
				StringList slItemDetails = new StringList();
				for(int k=0;k<slOtherItemsRels.size();k++){
					strOtherItemRelId = (String)slOtherItemsRels.get(k);
					String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSWorksDelegationAmount].value dump |");
					slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
					mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
				}
				Set keySet = mAmountMap.keySet();
				Iterator keys = keySet.iterator();
				int ctr=0;
				while(keys.hasNext())
				{
					String itemName = (String)keys.next();
					String strValue = (String)mAmountMap.get(itemName);
					if(ctr==0)
						sWorks = itemName + "=" + strValue;
					else
						sWorks = sWorks +"<br/>"+ itemName + "=" + strValue;
					ctr++;
				}
			}
			
			slReturnList.add(sWorks);
		}
		return slReturnList;
	}
	
	public StringList getPlanningDelegations(Context context, String[] args) throws Exception
	{
		StringList slReturnList = new StringList();
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		String strDelId = "";
		String strOtherItemRelId = "";
		StringList slOtherItemsRels = new StringList();
		DomainObject doDelegation = DomainObject.newInstance(context);
		String sPlanning = "";
		for (int i = 0 ; i < objectList.size(); i++)
		{
			sPlanning = "";
			Map mTemp = (Map)objectList.get(i);
			strDelId = (String)mTemp.get(DomainObject.SELECT_ID);
			if(UIUtil.isNotNullAndNotEmpty(strDelId)){
				doDelegation.setId(strDelId);
				slOtherItemsRels = doDelegation.getInfoList(context,"from[WMSDelegationOtherItems].id");
				
				HashMap mAmountMap = new HashMap();
				StringList slItemDetails = new StringList();
				for(int k=0;k<slOtherItemsRels.size();k++){
					strOtherItemRelId = (String)slOtherItemsRels.get(k);
					String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSPlanningDelegationAmount].value dump |");
					slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
					mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
				}
				Set keySet = mAmountMap.keySet();
				Iterator keys = keySet.iterator();
				int ctr=0;
				while(keys.hasNext())
				{
					String itemName = (String)keys.next();
					String strValue = (String)mAmountMap.get(itemName);
					if(ctr==0)
						sPlanning = itemName + "=" + strValue;
					else
						sPlanning = sPlanning +"<br/>"+ itemName + "=" + strValue;
					ctr++;
				}
			}
			
			slReturnList.add(sPlanning);
		}
		return slReturnList;
	}
	
	public StringList getDelegationApprovalHistory(Context context, String[] args) throws Exception
	{
		StringList slReturnList = new StringList();
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		String strDelId = "";
		Map mTemp = null;
		for (int i = 0 ; i < objectList.size(); i++)
		{
			mTemp = (Map)objectList.get(i);
			strDelId = (String)mTemp.get(DomainObject.SELECT_ID);
			StringBuilder sb=new StringBuilder();
			String shref = "../common/emxIndentedTable.jsp?program=WMSApprovalHistory:getAllApprovedTask&amp;table=WMSApprovalHistory&amp;header=Approval History&amp;HelpMarker=emxhelplifecycleapprovaltab&amp;selection=none&amp;freezePane=SNo,ApprovedUser";
			sb.append("<a href=\"javascript:showModalDialog('"+shref+"&amp;objectId="+strDelId+"','600','400','false');\" >");            
			sb.append("View");
			sb.append("</a>");
			
			slReturnList.add(sb.toString());
		}
		return slReturnList;
	}
	public String getEquipmentTotal(Context context,String args[]) throws Exception{
		String sEquipment = "";
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap requestMap = (HashMap) programMap.get("requestMap");
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String projectConceptId = (String) paramMap.get("objectId");
		String sWhere = "revision == last";
		DomainObject domProject=DomainObject.newInstance(context);
		StringList selects = new StringList(1);
		selects.add(DomainConstants.SELECT_ID);
		double dTotal = 0.0;
		if(ProgramCentralUtil.isNotNullString(projectConceptId))
		{
			domProject = DomainObject.newInstance(context, projectConceptId);
			ContextUtil.pushContext(context);
			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			Map mSoc = (Map)socList.get(0);				
			String sSocId =(String)mSoc.get("id");
			DomainObject domSOC = DomainObject.newInstance(context, sSocId);
			MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
			Map mDelegate = (Map)delegationList.get(0);
			String sDelegated =(String)mDelegate.get("id");
			DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
			String strEquipDelegatedAmout = (String)objDelegate.getAttributeValue(context,"WMSApprovedAmountEquipment");
			if(UIUtil.isNullOrEmpty(strEquipDelegatedAmout))
				strEquipDelegatedAmout = "0";
			
			dTotal = Double.parseDouble(strEquipDelegatedAmout);
			StringList slOtherItemsRels = (StringList)objDelegate.getInfoList(context,"from[WMSDelegationOtherItems].id");
			String strOtherItemRelId = "";
			String sOtherItem = "";
			
			HashMap mAmountMap = new HashMap();
			StringList slItemDetails = new StringList();
			for(int i=0;i<slOtherItemsRels.size();i++){
				strOtherItemRelId = (String)slOtherItemsRels.get(i);
				String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSEquipmentDelegationAmount].value dump |");
				slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
				mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
			}
			Set keySet = mAmountMap.keySet();
			Iterator keys = keySet.iterator();
			int ctr=0;
			while(keys.hasNext())
			{
				String itemName = (String)keys.next();
				String strValue = (String)mAmountMap.get(itemName);
				if(UIUtil.isNullOrEmpty(strValue)){
					strValue = "0.0";
				}
				dTotal += Double.parseDouble(strValue);
			}			
			sEquipment = WMSUtil_mxJPO.converToIndianCurrency(context,dTotal);
			//sEquipment = new BigDecimal(dTotal).setScale(2, BigDecimal.ROUND_UP).toPlainString();
			
			ContextUtil.popContext(context);
		}
		return sEquipment;
	}


public String getWorksTotal(Context context,String args[]) throws Exception{
		String sWorks = "";
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap requestMap = (HashMap) programMap.get("requestMap");
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String projectConceptId = (String) paramMap.get("objectId");
		String sWhere = "revision == last";
		DomainObject domProject=DomainObject.newInstance(context);
		StringList selects = new StringList(1);
		selects.add(DomainConstants.SELECT_ID);
		double dTotal = 0.0;
		if(ProgramCentralUtil.isNotNullString(projectConceptId))
		{
			domProject = DomainObject.newInstance(context, projectConceptId);
			ContextUtil.pushContext(context);
			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			Map mSoc = (Map)socList.get(0);				
			String sSocId =(String)mSoc.get("id");
			DomainObject domSOC = DomainObject.newInstance(context, sSocId);
			MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
			Map mDelegate = (Map)delegationList.get(0);
			String sDelegated =(String)mDelegate.get("id");
			DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
			String strWorksDelegatedAmout = (String)objDelegate.getAttributeValue(context,"WMSApprovedAmountWork");
			if(UIUtil.isNullOrEmpty(strWorksDelegatedAmout))
				strWorksDelegatedAmout = "0";
			
			dTotal = Double.parseDouble(strWorksDelegatedAmout);
			StringList slOtherItemsRels = (StringList)objDelegate.getInfoList(context,"from[WMSDelegationOtherItems].id");
			String strOtherItemRelId = "";
			String sOtherItem = "";
			
			HashMap mAmountMap = new HashMap();
			StringList slItemDetails = new StringList();
			for(int i=0;i<slOtherItemsRels.size();i++){
				strOtherItemRelId = (String)slOtherItemsRels.get(i);
				String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSWorksDelegationAmount].value dump |");
				slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
				mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
			}
			Set keySet = mAmountMap.keySet();
			Iterator keys = keySet.iterator();
			int ctr=0;
			while(keys.hasNext())
			{
				String itemName = (String)keys.next();
				String strValue = (String)mAmountMap.get(itemName);
				if(UIUtil.isNullOrEmpty(strValue)){
					strValue = "0.0";
				}
				dTotal += Double.parseDouble(strValue);
			}
			sWorks = WMSUtil_mxJPO.converToIndianCurrency(context,dTotal);
			//sWorks = new BigDecimal(dTotal).setScale(2, BigDecimal.ROUND_UP).toPlainString();
			ContextUtil.popContext(context);
		}
		return sWorks;
	}
	
	public String getPlanningTotal(Context context,String args[]) throws Exception{
		String sPlanning = "";
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap requestMap = (HashMap) programMap.get("requestMap");
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String projectConceptId = (String) paramMap.get("objectId");
		String sWhere = "revision == last";
		DomainObject domProject=DomainObject.newInstance(context);
		StringList selects = new StringList(1);
		selects.add(DomainConstants.SELECT_ID);
		double dTotal = 0.0;
		if(ProgramCentralUtil.isNotNullString(projectConceptId))
		{
			domProject = DomainObject.newInstance(context, projectConceptId);
			ContextUtil.pushContext(context);
			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			Map mSoc = (Map)socList.get(0);				
			String sSocId =(String)mSoc.get("id");
			DomainObject domSOC = DomainObject.newInstance(context, sSocId);
			MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
			Map mDelegate = (Map)delegationList.get(0);
			String sDelegated =(String)mDelegate.get("id");
			DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
			String strPlanningDelegatedAmout = (String)objDelegate.getAttributeValue(context,"WMSApprovedAmountPlanning");
			if(UIUtil.isNullOrEmpty(strPlanningDelegatedAmout))
				strPlanningDelegatedAmout = "0";
			
			dTotal = Double.parseDouble(strPlanningDelegatedAmout);
			StringList slOtherItemsRels = (StringList)objDelegate.getInfoList(context,"from[WMSDelegationOtherItems].id");
			String strOtherItemRelId = "";
			String sOtherItem = "";
			
			HashMap mAmountMap = new HashMap();
			StringList slItemDetails = new StringList();
			for(int i=0;i<slOtherItemsRels.size();i++){
				strOtherItemRelId = (String)slOtherItemsRels.get(i);
				String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSPlanningDelegationAmount].value dump |");
				slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
				mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
			}
			Set keySet = mAmountMap.keySet();
			Iterator keys = keySet.iterator();
			int ctr=0;
			while(keys.hasNext())
			{
				String itemName = (String)keys.next();
				String strValue = (String)mAmountMap.get(itemName);
				if(UIUtil.isNullOrEmpty(strValue)){
					strValue = "0.0";
				}
				dTotal += Double.parseDouble(strValue);
			}
			sPlanning = WMSUtil_mxJPO.converToIndianCurrency(context,dTotal);
			//sPlanning = new BigDecimal(dTotal).setScale(2, BigDecimal.ROUND_UP).toPlainString();
			ContextUtil.popContext(context);
		}
		return sPlanning;
	}
	
	
	public String getEquipmentlAmountEdit(Context context,String args[]) throws Exception{
			String sEquipment = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
				MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);				
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sEquipment = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDEQUIPMENT);
				//sEquipment = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(sEquipment));
				ContextUtil.popContext(context);
			}
			return sEquipment;
		}
		
		public String getWorkAmountEdit(Context context,String args[]) throws Exception{
			String sWork = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sWork = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDWORK);
				//sWork = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(sWork));
				ContextUtil.popContext(context);
			}
			return sWork;
		}
		
		public String getPlanningAmountEdit(Context context,String args[]) throws Exception{
			String sPlanning = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sPlanning = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDPLANNING);
				//sPlanning = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(sPlanning));
				ContextUtil.popContext(context);
			}
			return sPlanning;
		}
public static Map getDeligationStatsicDetails(Context context,String[] args)throws Exception
	{
		Map mDeligationMap = new HashMap();
		String sID = args[0];
		String strDelegationId = DomainConstants.EMPTY_STRING;
			try{		
			if(UIUtil.isNotNullAndNotEmpty(sID)){
				StringList slWorksItems = new StringList();
				StringList slEquipmentsItems = new StringList();
				StringList slServicesItems = new StringList();
				DomainObject doPro = new DomainObject(sID);
				String sProjecrId = doPro.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.id");
				String sProjecrName = doPro.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.to["+RELATIONSHIP_WMSPROJECTSOC+"].from.name");
				String sProjecrObjectId = doPro.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
				mDeligationMap.put("socID",sProjecrId);
				mDeligationMap.put("ProjecrName",sProjecrName);
				mDeligationMap.put("ProjecrObjectId",sProjecrObjectId);
				DomainObject doSOC = new DomainObject(sProjecrId);
				StringList slObjSelect = new StringList();
				slObjSelect.add(DomainObject.SELECT_ID);
				slObjSelect.add(DomainObject.SELECT_TYPE);
				slObjSelect.add("attribute[Title]");
				slObjSelect.add("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
				slObjSelect.add("from["+TYPE_WMSAE+"]");
				
				StringList slSOCSelect = new StringList();
				slSOCSelect.add("attribute["+ATTRIBUTE_WMSSOC_EQUIPMENTS_INCLUDED+"]");
				slSOCSelect.add("attribute["+ATTRIBUTE_WMSSOC_WORKS_INCLUDED+"]");
				slSOCSelect.add("attribute["+ATTRIBUTE_WMSSOC_SERVICES_INCLUDED+"]");
				slSOCSelect.add("attribute[Title]");
				slSOCSelect.add("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
				
				Map mSOCInfo = doSOC.getInfo(context,slSOCSelect);
				String strEquipSelected = (String)mSOCInfo.get("attribute["+ATTRIBUTE_WMSSOC_EQUIPMENTS_INCLUDED+"]");
				String strWorksSelected = (String)mSOCInfo.get("attribute["+ATTRIBUTE_WMSSOC_WORKS_INCLUDED+"]");
				String strServicesSelected = (String)mSOCInfo.get("attribute["+ATTRIBUTE_WMSSOC_SERVICES_INCLUDED+"]");
				String strProjectTitle = (String)mSOCInfo.get("attribute[Title]");
				String strCodeHead = (String)mSOCInfo.get("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
				
				MapList mlApprivedAEList =  doSOC.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSSOC_APPROVEDAEMASTER, // relationship pattern
														TYPE_WMSAEMASTER, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														null, // object where clause
														null); // relationship where clause
														
					
				//Map mTemp = null;
				double dEquipmentAmount = 0.0;
				double dWorksAmount = 0.0;
				double dPlanningAmount = 0.0;
				
				double dEquipmentContAmount = 0.0;
				double dWorksContAmount = 0.0;
				double dPlanningContAmount = 0.0;
				
				double dEquipmentAmountprevious = 0.0;
				double dWorksAmountprevious = 0.0;
				double dPlanningAmountprevious = 0.0;
				
				double dEquipmentContAmountprevious = 0.0;
				double dWorksContAmountprevious = 0.0;
				double dPlanningContAmountprevious = 0.0;
				
				String strTitle = DomainConstants.EMPTY_STRING;
				String strId = DomainConstants.EMPTY_STRING;
				String strEquipmentSeq = DomainConstants.EMPTY_STRING;
				String strWorksSeq = DomainConstants.EMPTY_STRING;
				String strServicesSeq = DomainConstants.EMPTY_STRING;
				
				String strAAAmount = DomainConstants.EMPTY_STRING;
				String strAADuration = DomainConstants.EMPTY_STRING;
				String strAALetterNo = DomainConstants.EMPTY_STRING;
				String strAADate = DomainConstants.EMPTY_STRING;		
				String strDelName = DomainConstants.EMPTY_STRING;
				String strDelRev = DomainConstants.EMPTY_STRING;
				String strDelDate = DomainConstants.EMPTY_STRING;
				String strDelState = DomainConstants.EMPTY_STRING;
				String strDGName = DomainConstants.EMPTY_STRING;
				String strDGDesignation = DomainConstants.EMPTY_STRING;
				
				String strCodeHeadName = DomainConstants.EMPTY_STRING;
				String strMajorHead = DomainConstants.EMPTY_STRING;
				String strMinorHead = DomainConstants.EMPTY_STRING;
				String strHeader = DomainConstants.EMPTY_STRING;
				String strDelDateprevious = DomainConstants.EMPTY_STRING;
				String strDelNameprevious = DomainConstants.EMPTY_STRING;
				String strDelRevprevious = DomainConstants.EMPTY_STRING;
				String strDelegationIdprevious = DomainConstants.EMPTY_STRING;
				String strDelStateprevious = DomainConstants.EMPTY_STRING;
				
				if(UIUtil.isNotNullAndNotEmpty(strCodeHead)){
					DomainObject doCodeHead = new DomainObject(strCodeHead);
					StringList slCodeHeadSelect = new StringList();
					slCodeHeadSelect.add("attribute[Title]");
					slCodeHeadSelect.add("attribute["+ATTRIBUTE_WMS_MAJOR_HEAD+"]");
					slCodeHeadSelect.add("attribute["+ATTRIBUTE_WMS_MINOR_HEAD+"]");
					Map mCodeHeadInfo = doCodeHead.getInfo(context,slCodeHeadSelect);
					
					if(mCodeHeadInfo!=null){
						strCodeHeadName = (String)mCodeHeadInfo.get("attribute[Title]");
						strMajorHead = (String)mCodeHeadInfo.get("attribute["+ATTRIBUTE_WMS_MAJOR_HEAD+"]");
						strMinorHead = (String)mCodeHeadInfo.get("attribute["+ATTRIBUTE_WMS_MINOR_HEAD+"]");
						mDeligationMap.put("CodeHeadName",strCodeHeadName);
						mDeligationMap.put("MajorHead",strMajorHead);
						mDeligationMap.put("MinorHead",strMinorHead);
					}
				}
				
				
				Map mTempAE = null;
				MapList mlTemp = new MapList();
				String strSeq = DomainConstants.EMPTY_STRING;
				String strHasChild = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlApprivedAEList.size();i++){
					Map mTemp = null;
					mTemp = (Map)mlApprivedAEList.get(i);
					strTitle = (String)mTemp.get("attribute[Title]");
					strId = (String)mTemp.get(DomainObject.SELECT_ID);
							mDeligationMap.put("Title",strTitle);
							mDeligationMap.put("TitleID",strId);
					
					if("Services".equals(strTitle)){
						DomainObject doAEMastet = new DomainObject(strId);
						MapList mlAEList =  doAEMastet.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														null, // object where clause
														null); // relationship where clause
														mlAEList.sort("attribute[WMSItemSequence]", "ascending", "real");
														
						for(int j=0;j<mlAEList.size();j++){
							mTempAE = (Map)mlAEList.get(j);
							strHasChild = (String)mTempAE.get("from["+TYPE_WMSAE+"]");
							mDeligationMap.put("SerHasChild",strHasChild);
							
							slServicesItems.add((String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]"));
							
						}
						
					}
					if("Equipments".equals(strTitle)){					
						DomainObject doAEMastet = new DomainObject(strId);
						MapList mlAEList =  doAEMastet.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														null, // object where clause
														null); // relationship where clause
														mlAEList.sort("attribute[WMSItemSequence]", "ascending", "real");
														
														
						MapList mlTemp2 = new MapList();
						for(int k = 0 ; k < mlAEList.size(); k++)
						{
							Map hmTemp = (Map)mlAEList.get(k);
							if(!"1".equals((String)hmTemp.get("level")))
								mlTemp2.add(hmTemp);
						}
						mlTemp2.sort("attribute[WMSItemSequence]", "ascending", "real");
						for(int j=0;j<mlTemp2.size();j++){
							mTempAE = (Map)mlTemp2.get(j);
							strHasChild = (String)mTempAE.get("from["+TYPE_WMSAE+"]");
							
							mDeligationMap.put("EquHasChild",strHasChild);
							slEquipmentsItems.add((String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]"));
						
						}
					}
					if("Works".equals(strTitle)){
						DomainObject doAEMastet = new DomainObject(strId);
						 MapList mlAEList =  doAEMastet.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 2, // recursion level
														null, // object where clause
														null); // relationship where clause
														//mlAEList.sort("attribute[WMSItemSequence]", "ascending", "real");
														//System.out.println("mlAEList"+mlAEList);
						MapList mlTemp2 = new MapList();
						for(int k = 0 ; k < mlAEList.size(); k++)
						{
							Map hmTemp = (Map)mlAEList.get(k);
							if(!"1".equals((String)hmTemp.get("level")))
								mlTemp2.add(hmTemp);
						}
						mlTemp2.sort("attribute[WMSItemSequence]", "ascending", "real");
						for(int j=0;j<mlTemp2.size();j++){
							mTempAE = (Map)mlTemp2.get(j);
							strHasChild = (String)mTempAE.get("from["+TYPE_WMSAE+"]");
							mDeligationMap.put("WorksHasChild",strHasChild);
							if(UIUtil.isNotNullAndNotEmpty(strHasChild) && "false".equalsIgnoreCase(strHasChild)){
								slWorksItems.add((String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]"));
								
							}
						}
					}
				}
				slWorksItems.sort();
				slServicesItems.sort();
				slEquipmentsItems.sort();
				
				for(int ctrItems=0;ctrItems<slWorksItems.size();ctrItems++){
					if(UIUtil.isNullOrEmpty(strWorksSeq)){
						strWorksSeq = (String)slWorksItems.get(ctrItems);
					}else{
						strWorksSeq = strWorksSeq+", "+(String)slWorksItems.get(ctrItems);
					}
				}
				
				for(int ctrItems=0;ctrItems<slEquipmentsItems.size();ctrItems++){
					if(UIUtil.isNullOrEmpty(strEquipmentSeq)){
						strEquipmentSeq = (String)slEquipmentsItems.get(ctrItems);
					}else{
						strEquipmentSeq = strEquipmentSeq+", "+(String)slEquipmentsItems.get(ctrItems);
					}
				}
				
				for(int ctrItems=0;ctrItems<slServicesItems.size();ctrItems++){
					if(UIUtil.isNullOrEmpty(strServicesSeq)){
						strServicesSeq = (String)slServicesItems.get(ctrItems);
					}else{
						strServicesSeq = strServicesSeq+", "+(String)slServicesItems.get(ctrItems);
					}
				}
				
				if(UIUtil.isNotNullAndNotEmpty(strWorksSelected) && "true".equalsIgnoreCase(strWorksSelected)){
					strWorksSelected = strWorksSelected +","+ strServicesSeq;
					
				}else if(UIUtil.isNotNullAndNotEmpty(strEquipSelected) && "true".equalsIgnoreCase(strEquipSelected)){
					strEquipSelected = strEquipSelected +","+ strServicesSeq;
				}else{
					if(UIUtil.isNullOrEmpty(strWorksSelected))
						strWorksSelected = strServicesSeq;
					else
						strWorksSelected = strWorksSelected +", "+ strServicesSeq;
				}
								
				String sWhere = "revision == last";
				StringList slDelSelect = new StringList();
				slDelSelect.add(DomainObject.SELECT_ID);
				slDelSelect.add(DomainObject.SELECT_NAME);
				slDelSelect.add(DomainObject.SELECT_ORIGINATED);
				slDelSelect.add(DomainObject.SELECT_REVISION);
				slDelSelect.add(DomainObject.SELECT_CURRENT);
				slDelSelect.add("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
				MapList delegationList = doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", slDelSelect, null, true, true, (short)0, sWhere, null,0,null,null,null);
				
				MapList mlOtherItems = new MapList();
				MapList mlOtherItemsWorks = new MapList();
				MapList mlOtherItemsEquip = new MapList();
				MapList mlOtherItemsPlanning = new MapList();
				
				if(delegationList.size()>0){
					Map mDelegate = (Map)delegationList.get(0);
					if(mDelegate != null){
						String strWorksAmount = (String)mDelegate.get("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
						String strEquipAmount = (String)mDelegate.get("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
						String strPlanAmount = (String)mDelegate.get("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
						String strWorksCont = (String)mDelegate.get("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
						String strEquipCont = (String)mDelegate.get("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
						String strPlanCont = (String)mDelegate.get("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
						strDelName = (String)mDelegate.get(DomainObject.SELECT_NAME);
						strDelRev = (String)mDelegate.get(DomainObject.SELECT_REVISION);
						strDelDate = (String)mDelegate.get(DomainObject.SELECT_ORIGINATED);
						strDelegationId = (String)mDelegate.get(DomainObject.SELECT_ID);
						strDelState = (String)mDelegate.get(DomainObject.SELECT_CURRENT);
						mDeligationMap.put("DelName",strDelName);
						mDeligationMap.put("DelRev",strDelRev);
						mDeligationMap.put("DelDate",strDelDate);
						mDeligationMap.put("DelegationId",strDelegationId);
						mDeligationMap.put("DelState",strDelState);
						
						if(UIUtil.isNotNullAndNotEmpty(strDelState) && "Delegate".equals(strDelState)){
							strDelDate = MqlUtil.mqlCommand(context,"print bus "+strDelegationId+" select state[Delegate].actual dump");
						}else{
							
						}
						if(UIUtil.isNullOrEmpty(strWorksAmount))
							strWorksAmount = "0";
						if(UIUtil.isNullOrEmpty(strEquipAmount))
							strEquipAmount = "0";
						if(UIUtil.isNullOrEmpty(strPlanAmount))
							strPlanAmount = "0";
						if(UIUtil.isNullOrEmpty(strWorksCont))
							strWorksCont = "0";
						if(UIUtil.isNullOrEmpty(strEquipCont))
							strEquipCont = "0";
						if(UIUtil.isNullOrEmpty(strPlanCont))
							strPlanCont = "0";
						
						dEquipmentAmount = Double.valueOf(strEquipAmount);
						dWorksAmount = Double.valueOf(strWorksAmount);
						dPlanningAmount = Double.valueOf(strPlanAmount);
						dEquipmentContAmount = Double.valueOf(strEquipCont);
						dWorksContAmount = Double.valueOf(strWorksCont);
						dPlanningContAmount = Double.valueOf(strPlanCont);
						DomainObject doDelegation = DomainObject.newInstance(context, strDelegationId);
						StringList slRelSels = new StringList();
						slRelSels.addElement("attribute[WMSWorksDelegationAmount].value");
						slRelSels.addElement("attribute[WMSEquipmentDelegationAmount].value");
						slRelSels.addElement("attribute[WMSPlanningDelegationAmount].value");
						StringList slObjSels = new StringList();
						slObjSels.addElement("id");
						slObjSels.addElement("attribute[Title].value");
						slObjSels.addElement("attribute[WMSItemSequence].value");
						mlOtherItems = doDelegation.getRelatedObjects(context, // matrix context
																			"WMSDelegationOtherItems", // relationship pattern
																			"*", // type pattern
																			slObjSels, // object selects
																			slRelSels, // relationship selects
																			false, // to direction
																			true, // from direction
																			(short) 1, // recursion level
																			null, // object where clause
																			null);
						for (int k = 0 ; k < mlOtherItems.size() ;k++)
						{

							HashMap hmTempWorks = new HashMap();
							HashMap hmTempEquip = new HashMap();
							HashMap hmTempPlan = new HashMap();
							String sSeqenceWorks =(String)((Map)mlOtherItems.get(k)).get("attribute[WMSItemSequence].value");
							mDeligationMap.put("SeqenceWorks",sSeqenceWorks);
							hmTempWorks.put("text", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempWorks.put("value", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSWorksDelegationAmount].value"));
							dWorksContAmount += Double.valueOf((String)((Map)mlOtherItems.get(k)).get("attribute[WMSWorksDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempWorks.get("value")))
								mlOtherItemsWorks.add(hmTempWorks);
							String sSeqenceEqu =(String)((Map)mlOtherItems.get(k)).get("attribute[WMSItemSequence].value");
							mDeligationMap.put("SeqenceEqu",sSeqenceEqu);
							hmTempEquip.put("text", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempEquip.put("value", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSEquipmentDelegationAmount].value"));
							dEquipmentContAmount += Double.valueOf((String)((Map)mlOtherItems.get(k)).get("attribute[WMSEquipmentDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempEquip.get("value")))
								mlOtherItemsEquip.add(hmTempEquip);
							String sSeqencePlanning =(String)((Map)mlOtherItems.get(k)).get("attribute[WMSItemSequence].value");
							mDeligationMap.put("SeqencePlanning",sSeqencePlanning);
							hmTempPlan.put("text", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempPlan.put("value", (String)((Map)mlOtherItems.get(k)).get("attribute[WMSPlanningDelegationAmount].value"));
							dPlanningContAmount += Double.valueOf((String)((Map)mlOtherItems.get(k)).get("attribute[WMSPlanningDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempPlan.get("value")))
								mlOtherItemsPlanning.add(hmTempPlan);
						}
					}
				}
				String sWhereprevious = "revision == last.previous";
				StringList slDelSelectList = new StringList();
				slDelSelectList.add(DomainObject.SELECT_ID);
				slDelSelectList.add(DomainObject.SELECT_NAME);
				slDelSelectList.add(DomainObject.SELECT_ORIGINATED);
				slDelSelectList.add(DomainObject.SELECT_REVISION);
				slDelSelectList.add(DomainObject.SELECT_CURRENT);
				slDelSelectList.add("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
				slDelSelectList.add("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
				MapList delegationListprevious = doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", slDelSelectList, null, true, true, (short)0, sWhereprevious, null,0,null,null,null);
				
				MapList mlOtherItemsprevious = new MapList();
				MapList mlOtherItemsWorksprevious = new MapList();
				MapList mlOtherItemsEquipprevious = new MapList();
				MapList mlOtherItemsPlanningprevious = new MapList();
				
				if(delegationListprevious.size()>0){
					Map mDelegateprevious = (Map)delegationListprevious.get(0);
					if(mDelegateprevious != null){
						String strWorksAmountprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
						String strEquipAmountprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
						String strPlanAmountprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
						String strWorksContprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
						String strEquipContprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
						String strPlanContprevious = (String)mDelegateprevious.get("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
						strDelNameprevious = (String)mDelegateprevious.get(DomainObject.SELECT_NAME);
						strDelRevprevious = (String)mDelegateprevious.get(DomainObject.SELECT_REVISION);
						strDelDateprevious = (String)mDelegateprevious.get(DomainObject.SELECT_ORIGINATED);
						strDelegationIdprevious = (String)mDelegateprevious.get(DomainObject.SELECT_ID);
						strDelStateprevious = (String)mDelegateprevious.get(DomainObject.SELECT_CURRENT);
						mDeligationMap.put("DelNameprevious",strDelNameprevious);
						mDeligationMap.put("DelRevprevious",strDelRevprevious);
						mDeligationMap.put("DelDateprevious",strDelDateprevious);
						mDeligationMap.put("DelegationIdprevious",strDelegationIdprevious);
						mDeligationMap.put("DelStateprevious",strDelStateprevious);
					
						if(UIUtil.isNotNullAndNotEmpty(strDelStateprevious) && "Delegate".equals(strDelStateprevious)){
							strDelDateprevious = MqlUtil.mqlCommand(context,"print bus "+strDelegationIdprevious+" select state[Delegate].actual dump");
						}else{
							
						}
						if(UIUtil.isNullOrEmpty(strWorksAmountprevious))
							strWorksAmountprevious = "0";
						if(UIUtil.isNullOrEmpty(strEquipAmountprevious))
							strEquipAmountprevious = "0";
						if(UIUtil.isNullOrEmpty(strPlanAmountprevious))
							strPlanAmountprevious = "0";
						if(UIUtil.isNullOrEmpty(strWorksContprevious))
							strWorksContprevious = "0";
						if(UIUtil.isNullOrEmpty(strEquipContprevious))
							strEquipContprevious = "0";
						if(UIUtil.isNullOrEmpty(strPlanContprevious))
							strPlanContprevious = "0";
						
						dEquipmentAmountprevious = Double.valueOf(strEquipAmountprevious);
						dWorksAmountprevious = Double.valueOf(strWorksAmountprevious);
						dPlanningAmountprevious = Double.valueOf(strPlanAmountprevious);
						dEquipmentContAmountprevious = Double.valueOf(strEquipContprevious);
						dWorksContAmountprevious = Double.valueOf(strWorksContprevious);
						dPlanningContAmountprevious = Double.valueOf(strPlanContprevious);
						
						DomainObject doDelegationprevious = DomainObject.newInstance(context, strDelegationIdprevious);
						StringList slRelSels = new StringList();
						slRelSels.addElement("attribute[WMSWorksDelegationAmount].value");
						slRelSels.addElement("attribute[WMSEquipmentDelegationAmount].value");
						slRelSels.addElement("attribute[WMSPlanningDelegationAmount].value");
						StringList slObjSels = new StringList();
						slObjSels.addElement("id");
						slObjSels.addElement("attribute[Title].value");
						slObjSels.addElement("attribute[WMSItemSequence].value");
						mlOtherItemsprevious = doDelegationprevious.getRelatedObjects(context, // matrix context
																			"WMSDelegationOtherItems", // relationship pattern
																			"*", // type pattern
																			slObjSels, // object selects
																			slRelSels, // relationship selects
																			false, // to direction
																			true, // from direction
																			(short) 1, // recursion level
																			null, // object where clause
																			null);
						for (int k = 0 ; k < mlOtherItemsprevious.size() ;k++)
						{
							/*
							MapList mlOtherItemsWorks = new MapList();
							MapList mlOtherItemsEquip = new MapList();
							MapList mlOtherItemsPlanning = new MapList();
							*/
							HashMap hmTempWorks = new HashMap();
							HashMap hmTempEquip = new HashMap();
							HashMap hmTempPlan = new HashMap();
							String sSeqenceWorksPrevious =(String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSItemSequence].value");
							mDeligationMap.put("SeqenceWorksprevious",sSeqenceWorksPrevious);
							hmTempWorks.put("text", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempWorks.put("value", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSWorksDelegationAmount].value"));
							dWorksContAmountprevious += Double.valueOf((String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSWorksDelegationAmount].value"));
							//System.out.println("dWorksContAmountprevious--------------"+dWorksContAmountprevious);
							if(!"0.0".equals((String)hmTempWorks.get("value")))
								mlOtherItemsWorksprevious.add(hmTempWorks);
							String sSeqenceEquprevious =(String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSItemSequence].value");
							mDeligationMap.put("SeqenceEquprevious",sSeqenceEquprevious);
							hmTempEquip.put("text", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempEquip.put("value", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSEquipmentDelegationAmount].value"));
							dEquipmentContAmountprevious += Double.valueOf((String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSEquipmentDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempEquip.get("value")))
								mlOtherItemsEquipprevious.add(hmTempEquip);
							String sSeqencePlanningprevious =(String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSItemSequence].value");
							mDeligationMap.put("SeqencePlanningprevious",sSeqencePlanningprevious);
							hmTempPlan.put("text", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSItemSequence].value"));
							hmTempPlan.put("value", (String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSPlanningDelegationAmount].value"));
							dPlanningContAmountprevious += Double.valueOf((String)((Map)mlOtherItemsprevious.get(k)).get("attribute[WMSPlanningDelegationAmount].value"));
							if(!"0.0".equals((String)hmTempPlan.get("value")))
								mlOtherItemsPlanningprevious.add(hmTempPlan);
						}
					}
				}
				
				double dWorksTotal = 0.0;
				double dEquipmentTotal = 0.0;
				double dPlanningTotal = 0.0;
				
				double dWorksTotalprevious = 0.0;
				double dEquipmentTotalprevious = 0.0;
				double dPlanningTotalprevious = 0.0;
				
				dWorksTotal = dWorksAmount+dWorksContAmount;
				dEquipmentTotal = dEquipmentAmount+dEquipmentContAmount;
				dPlanningTotal=dPlanningContAmount;
				String strWorksTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksTotal);
				String strWorksContAmount = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksContAmount);
				String strEquipmentTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentTotal);
				String strplanningTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dPlanningTotal);
				String strEquipmentContAmount = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentContAmount);
				String strWorksAmount = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksAmount);
				String strEquipmentAmount = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentAmount);
				String strPlanningContAmount = WMSUtil_mxJPO.converToIndianCurrency(context,dPlanningContAmount);
				strWorksTotal = "Rs. "+strWorksTotal;
				strWorksContAmount = "Rs. "+strWorksContAmount;
				strEquipmentTotal = "Rs. "+strEquipmentTotal;
				strplanningTotal = "Rs. "+strplanningTotal; 
				strEquipmentContAmount = "Rs. "+strEquipmentContAmount; 
				strWorksAmount = "Rs. "+strWorksAmount; 
				strEquipmentAmount = "Rs. "+strEquipmentAmount; 
				strPlanningContAmount = "Rs. "+strPlanningContAmount; 
				mDeligationMap.put("EquipmentTotal",strEquipmentTotal);
				mDeligationMap.put("WorksTotal",strWorksTotal);
				mDeligationMap.put("planningTotal",strplanningTotal);
				mDeligationMap.put("WorksContAmount",strWorksContAmount);
				mDeligationMap.put("EquipmentContAmount",strEquipmentContAmount);
				mDeligationMap.put("WorksAmount",strWorksAmount);
				mDeligationMap.put("EquipmentAmount",strEquipmentAmount);
				mDeligationMap.put("PlanningContAmount",strPlanningContAmount);
				
				dWorksTotalprevious = dWorksAmountprevious+dWorksContAmountprevious;
				dEquipmentTotalprevious = dEquipmentAmountprevious+dEquipmentContAmountprevious;
				dPlanningTotalprevious=dPlanningContAmountprevious;
				String strWorksTotalprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksTotalprevious);
				String strWorksContAmountprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksContAmountprevious);
				String strEquipmentTotalprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentTotalprevious);
				String strplanningTotalprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dPlanningTotalprevious);
				String strEquipmentContAmountprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentContAmountprevious);
				String strWorksAmountprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksAmountprevious);
				String strEquipmentAmountprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentAmountprevious);
				String strPlanningContAmountprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dPlanningContAmountprevious);
				strWorksTotalprevious = "Rs. "+strWorksTotalprevious;
				strWorksContAmountprevious = "Rs. "+strWorksContAmountprevious;
				strEquipmentTotalprevious = "Rs. "+strEquipmentTotalprevious;
				strplanningTotalprevious = "Rs. "+strplanningTotalprevious; 
				strEquipmentContAmountprevious = "Rs. "+strEquipmentContAmountprevious; 
				strWorksAmountprevious = "Rs. "+strWorksAmountprevious; 
				strEquipmentAmountprevious = "Rs. "+strEquipmentAmountprevious; 
				strPlanningContAmountprevious = "Rs. "+strPlanningContAmountprevious; 
				mDeligationMap.put("EquipmentTotalprevious",strEquipmentTotalprevious);
				mDeligationMap.put("WorksTotalprevious",strWorksTotalprevious);
				mDeligationMap.put("planningTotalprevious",strplanningTotalprevious);
				mDeligationMap.put("WorksContAmountprevious",strWorksContAmountprevious);
				mDeligationMap.put("EquipmentContAmountprevious",strEquipmentContAmountprevious);
				mDeligationMap.put("WorksAmountprevious",strWorksAmountprevious);
				mDeligationMap.put("EquipmentAmountprevious",strEquipmentAmountprevious);
				mDeligationMap.put("PlanningContAmountprevious",strPlanningContAmountprevious);
				
				
				
				
				
				
				
				StringList selects = new StringList();
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALDATE+"]");
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALDURATION+"]");
				selects.add("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
				MapList AAList = doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCADMINAPPROVAL, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
				if(AAList.size()>0){
					Map mAA = (Map)AAList.get(0);
					if(mAA != null){
						strAAAmount = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
						strAADuration = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALDURATION+"]");
						strAALetterNo = (String)mAA.get("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
						strAADate = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALDATE+"]");
						mDeligationMap.put("AAAmount",strAAAmount);
						mDeligationMap.put("AADuration",strAADuration);
						mDeligationMap.put("AALetterNo",strAALetterNo);
						mDeligationMap.put("AADate",strAADate);
					}
				}

				DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
				Date date1 = eMatrixDateFormat.getJavaDate(strAADate);
				strAADate = dateFormat.format(date1);
				
				if(UIUtil.isNotNullAndNotEmpty(strDelState) && "Delegate".equals(strDelState)){
					Date date2 = eMatrixDateFormat.getJavaDate(strDelDate);
					strDelDate = dateFormat.format(date2);
				}else{
					SimpleDateFormat simpleformat = new SimpleDateFormat("MMM");
					String strMonth= simpleformat.format(new Date());
					simpleformat = new SimpleDateFormat("yyyy");
					String strYear= simpleformat.format(new Date());
					strDelDate = "  -"+strMonth+"-"+strYear;
					mDeligationMap.put("DelDate",strDelDate);
				}				
								
				String strDelegationNumber = "DG/_____/_____/_____/_____/_____/Plg";
				strHeader = strDelName+" Rev. "+strDelRev;
				mDeligationMap.put("Header",strHeader);
				String strAAInWords = WMSUtil_mxJPO.getValueInWords(strAAAmount);
				strAAAmount = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strAAAmount));
				
				strAAAmount = "Rs. "+strAAAmount+" ("+strAAInWords+" ).";
				mDeligationMap.put("AAAmount",strAAAmount);
				strDGName = EnoviaResourceBundle.getProperty(context,"WMS.DGNP.DGName");
				mDeligationMap.put("DGName",strDGName);
				StringList slDG = FrameworkUtil.split(strDGName,"|");
				if(slDG.size()==2){
					strDGName = (String)slDG.get(0);
					strDGDesignation = (String)slDG.get(1);
					
					mDeligationMap.put("DGName",strDGName);
					mDeligationMap.put("DGDesignation",strDGDesignation);
				}
			}
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		//System.out.println("-----mDeligationMap--->JPO CALL->>>>>>>>>"+mDeligationMap);
		return mDeligationMap;
	}
	public String getEquipmentContingencyPropeties(Context context,String args[]) throws Exception{
			String sEquipment = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String DelegationId = (String) paramMap.get("objectId");
			DomainObject domDelegation =DomainObject.newInstance(context ,DelegationId);
			String projectConceptId = domDelegation.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
				MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);				
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				StringList slOtherItemsRels = (StringList)objDelegate.getInfoList(context,"from[WMSDelegationOtherItems].id");
				String strOtherItemRelId = "";
				String sOtherItem = "";
				
				HashMap mAmountMap = new HashMap();
				StringList slItemDetails = new StringList();
				for(int i=0;i<slOtherItemsRels.size();i++){
					strOtherItemRelId = (String)slOtherItemsRels.get(i);
					String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSEquipmentDelegationAmount].value dump |");
					slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
					mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
				}
				Set keySet = mAmountMap.keySet();
				Iterator keys = keySet.iterator();
				int ctr=0;
				while(keys.hasNext())
				{
					String itemName = (String)keys.next();
					String strValue = (String)mAmountMap.get(itemName);
					if(ctr==0)
						sEquipment = itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					else
						sEquipment = sEquipment +"<br>"+ itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					ctr++;
				}
				//sEquipment = objDelegate.getAttributeValue(context,ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY);
				ContextUtil.popContext(context);
			}
			return sEquipment;
		}
		public String getWorkContingencyPropeties(Context context,String args[]) throws Exception{
			String sWork = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String DelegationId = (String) paramMap.get("objectId");
			DomainObject domDelegation =DomainObject.newInstance(context ,DelegationId);
			String projectConceptId = domDelegation.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				//sWork = objDelegate.getAttributeValue(context,ATTRIBUTE_WMS_WORKS_CONTINGENCY);
				StringList slOtherItemsRels = (StringList)objDelegate.getInfoList(context,"from[WMSDelegationOtherItems].id");
				String strOtherItemRelId = "";
				String sOtherItem = "";
				
				HashMap mAmountMap = new HashMap();
				StringList slItemDetails = new StringList();
				for(int i=0;i<slOtherItemsRels.size();i++){
					strOtherItemRelId = (String)slOtherItemsRels.get(i);
					String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSWorksDelegationAmount].value dump |");
					slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
					mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
				}
				Set keySet = mAmountMap.keySet();
				Iterator keys = keySet.iterator();
				int ctr=0;
				while(keys.hasNext())
				{
					String itemName = (String)keys.next();
					String strValue = (String)mAmountMap.get(itemName);
					if(ctr==0)
						sWork = itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					else
						sWork = sWork +"<br>"+ itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					ctr++;
				}
				ContextUtil.popContext(context);
			}
			return sWork;
		}
		public String getPlanningContingencyProperties(Context context,String args[]) throws Exception{
			String sPlanning = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String DelegationId = (String) paramMap.get("objectId");
			DomainObject domDelegation =DomainObject.newInstance(context ,DelegationId);
			String projectConceptId = domDelegation.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				//sPlanning = objDelegate.getAttributeValue(context,ATTRIBUTE_WMS_PLANNING_CONTINGENCY);
				StringList slOtherItemsRels = (StringList)objDelegate.getInfoList(context,"from[WMSDelegationOtherItems].id");
				String strOtherItemRelId = "";
				String sOtherItem = "";
				
				HashMap mAmountMap = new HashMap();
				StringList slItemDetails = new StringList();
				for(int i=0;i<slOtherItemsRels.size();i++){
					strOtherItemRelId = (String)slOtherItemsRels.get(i);
					String strResult = MqlUtil.mqlCommand(context,"print connection "+strOtherItemRelId+" select to.to[WMSAEMasterAE].from.attribute[Title].value attribute[WMSPlanningDelegationAmount].value dump |");
					slItemDetails = (StringList)FrameworkUtil.split(strResult,"|");
					mAmountMap.put((String)slItemDetails.get(0),(String)slItemDetails.get(1));
				}
				Set keySet = mAmountMap.keySet();
				Iterator keys = keySet.iterator();
				int ctr=0;
				while(keys.hasNext())
				{
					String itemName = (String)keys.next();
					String strValue = (String)mAmountMap.get(itemName);
					if(ctr==0)
						sPlanning = itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					else
						sPlanning = sPlanning +"<br>"+ itemName + "=" + WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValue));
					ctr++;
				}
				ContextUtil.popContext(context);
			}
			return sPlanning;
		}
		
		/*
		Get Range Values for Sequence Fields in Edit Delegation Form
		*/
    public Object getDelegationSequenceFieldRangeValues(Context context, String[] args) throws Exception {
        HashMap tempMap = new HashMap();
        StringList fieldRangeValues = new StringList();
        StringList fieldDisplayRangeValues = new StringList();

		String sQueryResult = MqlUtil.mqlCommand(context,"print attribute $1 select range dump $2","WMSWorksDelegateSequence","|");
		//System.out.println("sQueryResult = "+sQueryResult);
		if(UIUtil.isNotNullAndNotEmpty(sQueryResult))
		{
			StringList slRangeValues = (StringList)FrameworkUtil.split(sQueryResult,"|");
			String sRangeValue = "";
			if(slRangeValues.size() > 0)
			{
				for(int i = 0; i < slRangeValues.size(); i++)
				{
					fieldRangeValues.addElement((slRangeValues.get(i)).replaceAll("= ",""));
					fieldDisplayRangeValues.addElement((slRangeValues.get(i)).replaceAll("= ",""));
				}
			}
		}
		tempMap.put("field_choices",fieldRangeValues);
		tempMap.put("field_display_choices", fieldDisplayRangeValues);
		//System.out.println("return = "+tempMap);
        return tempMap;
    }
	
	public void updateWorkSequence(Context context,String args[]) throws Exception
	{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sProjectId = (String) paramMap.get("objectId");			
			String sWorkSequence =(String)paramMap.get("New Value");
			String[] args1 = new String[] {sProjectId, sWorkSequence, "WMSWorksDelegateSequence"};			
			updateDeligationAttribute(context, args1);
	}
	
	public void updateEquipmentSequence(Context context,String args[]) throws Exception
	{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sProjectId = (String) paramMap.get("objectId");			
			String sEquipmentSequence =(String)paramMap.get("New Value");
			String[] args1 = new String[] {sProjectId, sEquipmentSequence, "WMSEquipmentDelegateSequence"};			
			updateDeligationAttribute(context, args1);
	}
	
	public void updatePlanningSequence(Context context,String args[]) throws Exception
	{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sProjectId = (String) paramMap.get("objectId");			
			String sPlanningSequence =(String)paramMap.get("New Value");
			String[] args1 = new String[] {sProjectId, sPlanningSequence, "WMSPlanningDelegateSequence"};			
			updateDeligationAttribute(context, args1);
	}

		/*public void updateDeligationIntegerAttribute (Context context,String args[]) throws Exception{
			String projectConceptId = args[0];
			String sAttrValue = args[1];
			String sAttributeName = args[2];
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				objDelegate.setAttributeValue(context, sAttributeName, Integer.parseInt(sAttrValue));		
			}
		}*/	
		
		public String getWorkSequence(Context context,String args[]) throws Exception{
			String sWork = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sWork = objDelegate.getAttributeValue(context,"WMSWorksDelegateSequence");
				//System.out.println("work seq = "+sWork);
				//sWork = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(sWork));
				ContextUtil.popContext(context);
			}
			return sWork;
		}
		
		public String getEquipmentSequence(Context context,String args[]) throws Exception{
			String sWork = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sWork = objDelegate.getAttributeValue(context,"WMSEquipmentDelegateSequence");
				//System.out.println("equipment seq = "+sWork);
				//sWork = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(sWork));
				ContextUtil.popContext(context);
			}
			return sWork;
		}
		
		public String getPlanningSequence(Context context,String args[]) throws Exception{
			String sWork = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sWork = objDelegate.getAttributeValue(context,"WMSPlanningDelegateSequence");
				//System.out.println("planning seq = "+sWork);
				//sWork = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(sWork));
				ContextUtil.popContext(context);
			}
			return sWork;
		}

public Element setWork(Context context, String args[], Map mWorks2, Element root, Document document, String sWorkSequenceNo, MapList mlOtherItemsWorks, MapList mlOtherItemsWorksprevious)	 throws Exception
{
				//Document document = documentBuilder.newDocument();;
				Element eleDelDDGCE =  document.createElement("delegation-ddg-seq"+sWorkSequenceNo);
				Element eleDelDDGCEHeader = document.createElement("delegation-ddg-seq"+sWorkSequenceNo+"-header");
				Element eleHeading = document.createElement("H1");
				eleHeading.appendChild(document.createTextNode("DDG and CE"));
				eleDelDDGCEHeader.appendChild(eleHeading);
				root.appendChild(eleDelDDGCEHeader);
				//root.appendChild(eleDelDDGCEHeader);
				Iterator mWorks2Itr = mWorks2.keySet().iterator();
				String Works2Key = "";
				while(mWorks2Itr.hasNext())
				{
					Works2Key = (String)mWorks2Itr.next();
					Element element =  document.createElement(Works2Key);
					element.appendChild(document.createTextNode((String)mWorks2.get(Works2Key)));
					eleDelDDGCE.appendChild(element);
					
				}
				root.appendChild(eleDelDDGCE);
				
				for(int j = 0 ; j < mlOtherItemsWorks.size() ; j++)
				{
					Element eleDelDDGCE1 =  document.createElement("delegation-ddg-seq"+sWorkSequenceNo);
					
					Element eleSequence1 = document.createElement("sequence-"+sWorkSequenceNo);
					eleSequence1.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(j+2)));
					
					Element elemItem1 = document.createElement("item-ddg-seq"+sWorkSequenceNo);
					
					elemItem1.appendChild(document.createTextNode("Item No. " + (String)((Map)mlOtherItemsWorks.get(j)).get("text") + " of AE Part-I"));
					
					Element elemItemValue1 = document.createElement("item-ddg-seq"+sWorkSequenceNo+"-value");
					elemItemValue1.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf((String)((Map)mlOtherItemsWorks.get(j)).get("value")))));
					Element elemItemValue1previous = document.createElement("item-ddg-seq"+sWorkSequenceNo+"-value-previous");
					if(mlOtherItemsWorksprevious.size()>0){
						elemItemValue1previous.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf((String)((Map)mlOtherItemsWorksprevious.get(j)).get("value")))));
					}
					
					eleDelDDGCE1.appendChild(eleSequence1);
					eleDelDDGCE1.appendChild(elemItem1);
					eleDelDDGCE1.appendChild(elemItemValue1);
					eleDelDDGCE1.appendChild(elemItemValue1previous);
					root.appendChild(eleDelDDGCE1);
				}
return root;				
}


public Element setEquipment(Context context, String args[], Map mEquipments2, Element root,Document document, String sEquipmentsSequenceNo, MapList mlOtherItemsEquip, MapList mlOtherItemsEquipprevious) throws Exception
{
				Element eleDelDDGE =  document.createElement("delegation-ddg-seq"+sEquipmentsSequenceNo);								
				Element eleDelDDGEHeader = document.createElement("delegation-ddg-seq"+sEquipmentsSequenceNo+"-header");
				Element eleHeading = document.createElement("H1");
				eleHeading.appendChild(document.createTextNode("DDG (E)"));
				eleDelDDGEHeader.appendChild(eleHeading);
				root.appendChild(eleDelDDGEHeader);
				//root.appendChild(eleDelDDGEHeader);
				Iterator mEquipments2Itr = mEquipments2.keySet().iterator();
				String Equipments2Key = "";
				while(mEquipments2Itr.hasNext())
				{
					Equipments2Key = (String)mEquipments2Itr.next();
					Element element =  document.createElement(Equipments2Key);
					element.appendChild(document.createTextNode((String)mEquipments2.get(Equipments2Key)));
					eleDelDDGE.appendChild(element);
					
				}
				root.appendChild(eleDelDDGE);

				for(int j = 0 ; j < mlOtherItemsEquip.size() ; j++)
				{
					Element eleDelDDGE1 =  document.createElement("delegation-ddg-seq"+sEquipmentsSequenceNo);
					
					Element eleSequence1 = document.createElement("sequence-"+sEquipmentsSequenceNo);
					eleSequence1.appendChild(document.createTextNode((String)WMSUtil_mxJPO.conertToRoman(j+2)));
					
					Element elemItem1 = document.createElement("item-ddg-seq"+sEquipmentsSequenceNo);
					
					elemItem1.appendChild(document.createTextNode("Item No. " + (String)((Map)mlOtherItemsEquip.get(j)).get("text") + " of AE Part-I"));
					
					Element elemItemValue1 = document.createElement("item-ddg-seq"+sEquipmentsSequenceNo+"-value");
					elemItemValue1.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf((String)((Map)mlOtherItemsEquip.get(j)).get("value")))));
					Element elemItemValue1previous = document.createElement("item-ddg-seq"+sEquipmentsSequenceNo+"-value-previous");
					if(mlOtherItemsEquipprevious.size()>0){
						elemItemValue1previous.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf((String)((Map)mlOtherItemsEquipprevious.get(j)).get("value")))));
					}
					
					eleDelDDGE1.appendChild(eleSequence1);
					eleDelDDGE1.appendChild(elemItem1);
					eleDelDDGE1.appendChild(elemItemValue1);
					eleDelDDGE1.appendChild(elemItemValue1previous);
					root.appendChild(eleDelDDGE1);
				}
return root;				
}

public Element setPlanning(Context context, String args[], Element root,Document document, String sPlanningSequenceNo, MapList mlOtherItemsPlanning, Double dPlanningContAmount, Double dPlanningContAmountprevious) throws Exception 
{

				//Document document = documentBuilder.newDocument();;
				Element eleDelDDGP1 =  document.createElement("delegation-ddg-seq"+sPlanningSequenceNo);
				Element eleDelDDGPHeader = document.createElement("delegation-ddg-seq"+sPlanningSequenceNo+"-header");
				Element eleHeading = document.createElement("H1");
				//eleHeading.;
				eleHeading.appendChild(document.createTextNode("DDG (P)"));
				eleDelDDGPHeader.appendChild(eleHeading);
				root.appendChild(eleDelDDGPHeader);					
				Element eleSequenceP1 = document.createElement("sequence-"+sPlanningSequenceNo);
				eleSequenceP1.appendChild(document.createTextNode(""));
					
				Element elemItemP1 = document.createElement("item-ddg-seq"+sPlanningSequenceNo);
				elemItemP1.appendChild(document.createTextNode(""));
				String strPlanningContValue = "";
				String strPlanningContValueprevious = "";
				if(dPlanningContAmount==0 )
					strPlanningContValue = "0.00";
				else
					strPlanningContValue = WMSUtil_mxJPO.converToIndianCurrency(context,dPlanningContAmount);
				//Element elemItemValueP1 = document.createElement("item-ddg-seq"+sPlanningSequenceNo+"-value");
				//elemItemValueP1.appendChild(document.createTextNode(strPlanningContValue));	
				if(dPlanningContAmountprevious==0)
					strPlanningContValueprevious = "0.00";
				else
					strPlanningContValueprevious = WMSUtil_mxJPO.converToIndianCurrency(context,dPlanningContAmountprevious);
				Element elemItemValueP1previous = document.createElement("item-ddg-seq"+sPlanningSequenceNo+"-value-previous");
				elemItemValueP1previous.appendChild(document.createTextNode(strPlanningContValueprevious));
				
				eleDelDDGP1.appendChild(eleSequenceP1);
				eleDelDDGP1.appendChild(elemItemP1);
				//eleDelDDGP1.appendChild(elemItemValueP1);
				eleDelDDGP1.appendChild(elemItemValueP1previous);
				
				root.appendChild(eleDelDDGP1);
				
				//System.out.println("mlOtherItemsWorks = "+mlOtherItemsWorks);
				for(int j = 0 ; j < mlOtherItemsPlanning.size() ; j++)
				{
					Element eleDelDDGE2 =  document.createElement("delegation-ddg-seq"+sPlanningSequenceNo);
						
					Element eleSequenceE2 = document.createElement("sequence-"+sPlanningSequenceNo);
					eleSequenceE2.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(j+1)));
						
					Element elemItemE2 = document.createElement("item-ddg-seq"+sPlanningSequenceNo);
					elemItemE2.appendChild(document.createTextNode("Item No. " + (String)((Map)mlOtherItemsPlanning.get(j)).get("text") + " of AE Part-I"));
					
					Element elemItemValueE2 = document.createElement("item-ddg-seq"+sPlanningSequenceNo+"-value");
					if(mlOtherItemsPlanning.size()>0){
						elemItemValueE2.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf((String)((Map)mlOtherItemsPlanning.get(j)).get("value")))));
					}
					
					eleDelDDGE2.appendChild(eleSequenceE2);
					eleDelDDGE2.appendChild(elemItemE2);
					eleDelDDGE2.appendChild(elemItemValueE2);
					
					root.appendChild(eleDelDDGE2);
				}
return root;				
}


public String getDelegationRouteField(Context context,String[] args) throws Exception {
		StringBuilder sb= null;
		try {
			
			String sObjectId = "";
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sBusWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
				String sSOCObjId = domProject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");	
				if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)){
					DomainObject domSOC = DomainObject.newInstance(context, sSOCObjId);
					MapList AAList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sBusWhere, null,0,null,null,null);
					if(AAList.size()>0)
					{
						Map mAA = (Map)AAList.get(0);
	
						sObjectId = (String)mAA.get(DomainConstants.SELECT_ID);
					}
				}
				
			}
			
            //String sObjectId = (String) requestMap.get("objectId");
			
			String strCurrent = DomainConstants.EMPTY_STRING;
			String strObjId = DomainConstants.EMPTY_STRING;
			String strObjName = DomainConstants.EMPTY_STRING;
			MapList mlExtRoutes = null;
			String sWhere = DomainConstants.EMPTY_STRING;
			Map oMap = null;
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			DomainObject doObject = new DomainObject(sObjectId);
			strCurrent = doObject.getInfo(context, DomainConstants.SELECT_CURRENT);
			
			if ("Create".equals(strCurrent)) {
				sWhere = "current != Complete";
				mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
													DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
													DomainConstants.TYPE_ROUTE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
				sb = new StringBuilder();
				if (mlExtRoutes.size() == 1) {
					String strURL="../common/emxTree.jsp";
					oMap = (Map) mlExtRoutes.get(0);
					strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
					strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
					sb.append(strObjName);
					sb.append("</a>");
				} else if (mlExtRoutes.size() == 0) {
					String strURL="../wms/wmsRouteCreationDialogFS.jsp?wmsSearch=all";
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"%26objectId="+sObjectId+"','600','400','false');\" >");            
					//sb.append("<img border='0' title='Route' src='../common/images/iconSmallRoute.png' height='15px' name='Route' id='Route' alt='Route'/>");
					sb.append("Create Route");
					sb.append("</a>");
				}
			} else {
				mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
													DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
													DomainConstants.TYPE_ROUTE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
				mlExtRoutes.sort("originated", "descending", "date");
				sb = new StringBuilder();
				if (mlExtRoutes.size() > 0) {
					String strURL="../common/emxTree.jsp";
					oMap = (Map) mlExtRoutes.get(0);
					strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
					strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
					sb.append(strObjName);
					sb.append("</a>");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

	/*public int startRouteForDelegation(Context context, String[] args) throws Exception
	{
		try {
			//HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId = args[0];
			DomainObject doSOCObj = null;
			String strTemplateId ="";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doSOCObj = new DomainObject(sObjectId);
				StringList slDomSels = new StringList();
				slDomSels.add("policy");
				slDomSels.add("current");

				Map mDomValues = (Map)doSOCObj.getInfo(context, slDomSels);
				System.out.println("mDomValues = "+mDomValues);

				Map relMap = new HashMap();
				relMap.put("Route Base Policy", "policy_"+(String)mDomValues.get("policy"));
				relMap.put("Route Base State", "state_"+(String)mDomValues.get("current"));
				relMap.put("Route Base Purpose", "Review");
				
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\" || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);
					ContextUtil.pushContext(context);
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						String RelIDRoute = (String)mRoute.get(DomainRelationship.SELECT_ID);
						DomainRelationship drelObjectRoute = new DomainRelationship(RelIDRoute);
						
						drelObjectRoute.setAttributeValues(context, relMap);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
						//checking rel data mlRoutes[{owner=navaldockyard, attribute[Route Status]=Stopped, type=Route, current=In Process, relationship=Object Route, level=1, id=34288.53217.49852.8710}]
						
						//34288.53217.26128.20423
						//checking rel data mlRoutes[{owner=navaldockyard, id[connection]=34288.53217.49852.8710, attribute[Route Status]=Stopped, type=Route, current=In Process, relationship=Object Route, level=1, id=34288.53217.26128.20423}]
					}
					ContextUtil.popContext(context);
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
		return 0;
	}*/
}  

 
