/*---------------------------------------------------------------------------------------------------------------
NAME        : ${CLASSNAME}.java

DESCRIPTION    : Purpose of JPO is to get Data for Fund Status Report

CREATED        : June 26, 2020

AUTHOR        : Dassault

HISTORY        :

    Dassault    26-06-2020        Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Locale;
import java.math.RoundingMode;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectConcept;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import matrix.db.Policy;
import com.matrixone.jdom.Element;
import matrix.util.Pattern;
import java.math.MathContext; 

public class WMSFundStatusReport_mxJPO extends WMSConstants_mxJPO {
    
    /**
    * Constructor.
    *
    * @param context the eMatrix <code>Context</code> object.
    * @param args holds no arguments.
    * @throws Exception if the operation fails.
    * @since EC 9.5.JCI.0.
    **/
    public WMSFundStatusReport_mxJPO (Context context, String[] args) throws Exception {
      super(context, args);
    }
    
    
    public static final String ATTRIBUTE_WMS_CODE_HEAD_NAME = PropertyUtil.getSchemaProperty("attribute_WMSCodeHeadName");
    public static final String ATTRIBUTE_WMS_ALLOCATION_DATE = PropertyUtil.getSchemaProperty("attribute_WMSAllocationDate");
    public static final String ATTRIBUTE_WMS_LETTER_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSAllocationLetterNumber");
    public static final String RELATIONSHIP_WMS_PROJECT_WORKORDER = PropertyUtil.getSchemaProperty("relationship_WMSProjectWorkOrder");
    public static final String SELECT_FUND_REQUEST_CURRENT = "from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].to.current";
    public static final String SELECT_FUND_RELEASE_CURRENT = "from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].to.current";
    public static final String SELECT_FUND_REQUEST_CURRENT_ACTUAL = "from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].to.current.actual";
    public static final String SELECT_FUND_RELEASE_CURRENT_ACTUAL = "from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].to.current.actual";
    public static final String SELECT_FUND_REQUEST_REVIEW_ACTUAL = "from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].to.state[Review].actual";
    public static final String SELECT_FUND_RELEASE_REVIEW_ACTUAL = "from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].to.state[Review].actual";
    public static final String SELECT_FUND_REQUEST_FY = "from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]";
    public static final String SELECT_FUND_REQUEST_AMOUNT = "from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]";
    public static final String SELECT_FUND_RELEASE_FY = "from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]";
    public static final String SELECT_FUND_RELEASE_AMOUNT = "from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]";
    
    //selectable for AMB.
    public static final String SELECT_AMB_CURRENT = "from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.current";
    public static final String SELECT_AMB_APPROVED_ACTUAL = "from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.state[Approved].actual";
    public static final String SELECT_AMB_REVIEW_ACTUAL = "from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.state[Review].actual";
    public static final String SELECT_AMB_FY = "from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]";
    public static final String SELECT_AMB_AMOUNT = "from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"]";
    public static final String SELECT_AMB_INVOICE_COST = "from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.attribute["+ATTRIBUTE_WMS_INVOICED_AMOUNT+"]";
    public static final String SELECT_AMB_NAME = "from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.name";
    
    public MapList getFundReportData(Context context, String[] args) throws Exception 
    {
        MapList mlResults = new MapList();
        try{
            Map programMap = (Map) JPO.unpackArgs(args);
            String strFY = (String)programMap.get("strFinancialYear");
            //Get the data for SubAllocation:
            Map mWOFinancialData = getWorkorderFinancialDataForPerson(context, strFY);
            //Get the Code Head Year Objects related to FY selected from Dropdown filter.
            String strWhere = "attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]=='"+strFY+"'";
            StringList strObjSelects = new StringList(5);
            strObjSelects.add(DomainObject.SELECT_ID);
            strObjSelects.add("to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.id");
            strObjSelects.add("to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            strObjSelects.add("to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
            strObjSelects.add("to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.description");
            MapList mlCodeHeadYears = DomainObject.findObjects(context,
                                                                TYPE_WMS_CODE_HEAD_YEAR,
                                                                context.getVault().getName(),
                                                                strWhere,               // where expression
                                                                strObjSelects);
            
            //Get all the allocations for Code Head Year Objects which have state ----.actual within the selected FY.
            Map mTemp = null;
            Map mFinalMap = null;
            String strCodeHeadId = "";
            String strCodeHeadYearId = "";
            String strCodeHeadTitle = "";
            String strCodeHeadName = "";
            String strCodeHeadDescription = "";
            String strAllocation = "";
            mlCodeHeadYears.sortStructure("to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]", "ascending", "string");
            BigDecimal bgZero = new BigDecimal(0);
            BigDecimal bgHundered = new BigDecimal(100);
            for(int i = 0; i < mlCodeHeadYears.size(); i++){
                mTemp = (Map)mlCodeHeadYears.get(i);
                mFinalMap = new HashMap();
                strCodeHeadYearId = (String)mTemp.get(DomainObject.SELECT_ID);
                strCodeHeadId = (String)mTemp.get("to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.id");
                if(UIUtil.isNotNullAndNotEmpty(strCodeHeadId)){
                    mFinalMap.put("CodeHeadID", strCodeHeadId);
                    mFinalMap.put("CodeHeadYearID", strCodeHeadYearId);
                    //get the total allocation amount for a CodeHeadYearObject
                    BigDecimal bgAllocationAmount = getTotalAllocationForCHY(context, strCodeHeadYearId);
                    Double dblValue = Double.parseDouble(bgAllocationAmount.toString());
                    String strAmount = String.format("%.2f", dblValue);
                    mFinalMap.put("CodeHeadName", (String)mTemp.get("to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]"));
                    mFinalMap.put("CodeHead", (String)mTemp.get("to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]"));
                    mFinalMap.put("Description", (String)mTemp.get("to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.description"));
                    mFinalMap.put("TotalAllocation", strAmount);
                    
                    //get the Sub Allocation Amount for CodeHeadId
                    String strCHSAAmount = strCodeHeadId + "SAAmount";
                    if (mWOFinancialData.containsKey(strCHSAAmount)) {
                        BigDecimal bgSubAllocationAmount = (BigDecimal)mWOFinancialData.get(strCHSAAmount);
                        Double dblSAValue = Double.parseDouble(bgSubAllocationAmount.toString());
                        String strSAAmount = String.format("%.2f", dblSAValue);
                        mFinalMap.put("TotalSAAllocation", strSAAmount);
                    } else {
                        mFinalMap.put("TotalSAAllocation", "0.00");
                    }
                    //Add the Bill Pending and Bills Clear amount in Map
                    String strCHBillClear = strCodeHeadId + "BillClear";
                    BigDecimal bgBillClearAmount = new BigDecimal(0);
                    if (mWOFinancialData.containsKey(strCHBillClear)) {
                        bgBillClearAmount = (BigDecimal)mWOFinancialData.get(strCHBillClear);
                        Double dblBCValue = Double.parseDouble(bgBillClearAmount.toString());
                        String strBCAmount = String.format("%.2f", dblBCValue);
                        mFinalMap.put("TotalBillCleared", strBCAmount);
                    } else {
                        mFinalMap.put("TotalBillCleared", "0.00");
                    }
                    String strCHBillPending = strCodeHeadId + "BillPending";
                    if (mWOFinancialData.containsKey(strCHBillPending)) {
                        BigDecimal bgBillPendingAmount = (BigDecimal)mWOFinancialData.get(strCHBillPending);
                        Double dblBPValue = Double.parseDouble(bgBillPendingAmount.toString());
                        String strBPAmount = String.format("%.2f", dblBPValue);
                        mFinalMap.put("TotalBillPending", strBPAmount);
                    } else {
                        mFinalMap.put("TotalBillPending", "0.00");
                    }
                    //Calculate the %Exp and %Balance
                    //%Expense is (Bill Cleared / Total Allocation) X 100
                    BigDecimal bgPercentExpense = new BigDecimal(0);
                    if (bgAllocationAmount.compareTo(bgZero) != 0){
                        BigDecimal bgExpenseRatio = bgBillClearAmount.divide(bgAllocationAmount, MathContext.DECIMAL128);
                        bgPercentExpense = bgExpenseRatio.multiply(bgHundered);
                    }
                    Double dblPerExpValue = Double.parseDouble(bgPercentExpense.toString());
                    String strPerExpAmount = String.format("%.2f", dblPerExpValue);
                    mFinalMap.put("PercentExpense", strPerExpAmount);
                    //%Balance is 100-%Expense
                    BigDecimal bgPerBalance = bgHundered.subtract(bgPercentExpense);
                    Double dblPerBalValue = Double.parseDouble(bgPerBalance.toString());
                    String strPerBalAmount = String.format("%.2f", dblPerBalValue);
                    mFinalMap.put("PercentBalance", strPerBalAmount);
                    mlResults.add(mFinalMap);
                }
                
            }
            
            //Sum up all the Allocation Amounts
        }catch(Exception ex){
            System.out.println("error in getFundReportData method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return mlResults;
    }
    
    public BigDecimal getTotalAllocationForCHY(Context context, String strCodeHeadYearId) throws Exception 
    {
        BigDecimal bgReturn = new BigDecimal(0);
        try{
            StringList slObjectSelects = new StringList(1);
            slObjectSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
            MapList mlAllocations = getCHYAllocations(context, strCodeHeadYearId, slObjectSelects);
            
            Map mTemp = null;
            String strAllocationAmount = "";
            
            for(int i = 0; i < mlAllocations.size(); i++){
                mTemp = (Map)mlAllocations.get(i);
                strAllocationAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
                if(UIUtil.isNotNullAndNotEmpty(strAllocationAmount)){
                    BigDecimal bgTemp = new BigDecimal(strAllocationAmount);
                    bgReturn = bgReturn.add(bgTemp);
                }
            }
            bgReturn = bgReturn.stripTrailingZeros();
        }catch(Exception ex){
            System.out.println("error in getTotalAllocationForCHY method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return bgReturn;
    }
    
    public Map getWorkorderFinancialDataForPerson(Context context, String strFY) throws Exception 
    {
        Map mFinalMap = new HashMap();
        try{
            MapList mlWOData = getWorkOrderData(context, true, false, false, true, null);
            Map mTemp = null;
            String strAllocationAmount = "";
            String strCodeHeadId = "";
            
            for(int i = 0; i < mlWOData.size(); i++){
                mTemp = (Map)mlWOData.get(i);
                strCodeHeadId = (String)mTemp.get("to["+RELATIONSHIP_WMS_PROJECT_WORKORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
                if(UIUtil.isNotNullAndNotEmpty(strCodeHeadId)){
                    //Code for getting Sub Allocation Amount
                    //get the Request Objects
                    StringList slRequestState = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_REQUEST_CURRENT));
                    StringList slRequestFY = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_REQUEST_FY));
                    StringList slRequestAmount = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_REQUEST_AMOUNT));
                    String strRequestState = "";
                    String strRequestFY = "";
                    String strRequestAmount = "";
                    for(int j=0;j<slRequestState.size();j++){
                        strRequestState = (String)slRequestState.get(j);
                        strRequestFY = (String)slRequestFY.get(j);
                        //if Request if approved and for same FY as passed to the method then add it to total. 
                        if (UIUtil.isNotNullAndNotEmpty(strRequestState) && strRequestState.equals("Approved") && UIUtil.isNotNullAndNotEmpty(strRequestFY) && strRequestFY.equals(strFY)) {
                            strRequestAmount = (String)slRequestAmount.get(j);
                            if (UIUtil.isNotNullAndNotEmpty(strRequestAmount)) {
                                BigDecimal bgTemp = new BigDecimal(strRequestAmount);
                                //add this amount to the map if its there else add both key and value
                                String strReqKeyName = strCodeHeadId + "SAAmount";
                                if (mFinalMap.containsKey(strReqKeyName)) {
                                    BigDecimal bgCodeHeadAmount = (BigDecimal)mFinalMap.get(strReqKeyName);
                                    bgCodeHeadAmount = bgCodeHeadAmount.add(bgTemp);
                                    bgCodeHeadAmount.stripTrailingZeros();
                                    mFinalMap.put(strReqKeyName, bgCodeHeadAmount);
                                } else {
                                    bgTemp.stripTrailingZeros();
                                    mFinalMap.put(strReqKeyName, bgTemp);
                                }
                            }
                        }
                    }
                    StringList slReleaseState = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_RELEASE_CURRENT));
                    StringList slReleaseFY = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_RELEASE_FY));
                    StringList slReleaseAmount = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_RELEASE_AMOUNT));
                    String strReleaseState = "";
                    String strReleaseFY = "";
                    String strReleaseAmount = "";
                    for(int k=0;k<slReleaseState.size();k++){
                        strReleaseState = (String)slReleaseState.get(k);
                        strReleaseFY = (String)slReleaseFY.get(k);
                        //if Request if approved and for same FY as passed to the method then add it to total. 
                        if (UIUtil.isNotNullAndNotEmpty(strReleaseState) && strReleaseState.equals("Approved") && UIUtil.isNotNullAndNotEmpty(strReleaseFY) && strReleaseFY.equals(strFY)) {
                            strReleaseAmount = (String)slReleaseAmount.get(k);
                            if (UIUtil.isNotNullAndNotEmpty(strReleaseAmount)) {
                                BigDecimal bgTemp = new BigDecimal(strReleaseAmount);
                                //subtract this amount to the map if its there else add both key and value
                                String strReqKeyName = strCodeHeadId + "SAAmount";
                                if (mFinalMap.containsKey(strReqKeyName)) {
                                    BigDecimal bgCodeHeadAmount = (BigDecimal)mFinalMap.get(strReqKeyName);
                                    bgCodeHeadAmount = bgCodeHeadAmount.subtract(bgTemp);
                                    bgCodeHeadAmount.stripTrailingZeros();
                                    mFinalMap.put(strReqKeyName, bgCodeHeadAmount);
                                } else {
                                    bgTemp.stripTrailingZeros();
                                    mFinalMap.put(strReqKeyName, bgTemp.negate());
                                }
                            }
                        }
                    }
                    
                    //code for finding Bills Pending and Bills Cleared amount
                    StringList slAMBState = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_CURRENT));
                    StringList slAMBFY = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_FY));
                    StringList slAMBAmount = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_AMOUNT));
                    StringList slInvoiceAmount = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_INVOICE_COST));
                    String strAMBState = "";
                    String strAMBFY = "";
                    String strAMBAmount = "";
                    for(int m = 0; m < slAMBState.size(); m++){
                        strAMBState = (String)slAMBState.get(m);
                        strAMBFY = (String)slAMBFY.get(m);
                        //if AMB is approved/paid then its Cleared. It should be for same FY as passed to the method. 
                        if (UIUtil.isNotNullAndNotEmpty(strAMBState) && (strAMBState.equals(STATE_APPROVED) || strAMBState.equals(STATE_PLAN))&& UIUtil.isNotNullAndNotEmpty(strAMBFY) && strAMBFY.equals(strFY)) {
                            strAMBAmount = (String)slAMBAmount.get(m);
                            if (UIUtil.isNotNullAndNotEmpty(strAMBAmount)) {
                                BigDecimal bgTemp = new BigDecimal(strAMBAmount);
                                //add this amount to the map if its there else add both key and value
                                String strAMBClearKeyName = strCodeHeadId + "BillClear";
                                if (mFinalMap.containsKey(strAMBClearKeyName)) {
                                    BigDecimal bgCodeHeadAmount = (BigDecimal)mFinalMap.get(strAMBClearKeyName);
                                    bgCodeHeadAmount = bgCodeHeadAmount.add(bgTemp);
                                    bgCodeHeadAmount.stripTrailingZeros();
                                    mFinalMap.put(strAMBClearKeyName, bgCodeHeadAmount);
                                } else {
                                    bgTemp.stripTrailingZeros();
                                    mFinalMap.put(strAMBClearKeyName, bgTemp);
                                }
                            }
                        } else if (UIUtil.isNotNullAndNotEmpty(strAMBState) && strAMBState.equals("Review") && UIUtil.isNotNullAndNotEmpty(strAMBFY) && strAMBFY.equals(strFY)) {
                            //If AMB is review then its Bill Pending
                            strAMBAmount = (String)slInvoiceAmount.get(m);
                            if (UIUtil.isNotNullAndNotEmpty(strAMBAmount)) {
                                BigDecimal bgTemp = new BigDecimal(strAMBAmount);
                                //add this amount to the map if its there else add both key and value
                                String strAMBPendingKeyName = strCodeHeadId + "BillPending";
                                if (mFinalMap.containsKey(strAMBPendingKeyName)) {
                                    BigDecimal bgCodeHeadAmount = (BigDecimal)mFinalMap.get(strAMBPendingKeyName);
                                    bgCodeHeadAmount = bgCodeHeadAmount.add(bgTemp);
                                    bgCodeHeadAmount.stripTrailingZeros();
                                    mFinalMap.put(strAMBPendingKeyName, bgCodeHeadAmount);
                                } else {
                                    bgTemp.stripTrailingZeros();
                                    mFinalMap.put(strAMBPendingKeyName, bgTemp);
                                }
                            }
                        }
                    }
                }
            }
        }catch(Exception ex){
            System.out.println("error in getSubAllocationForCHY method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return mFinalMap;
    }
    
    public StringList getFYs(Context context, String[] args) throws Exception 
    {
        StringList slFYs = new StringList();
        try{
            //Get the all Code Head Year Objects to get list of FYs
            StringList strObjSelects = new StringList(1);
            strObjSelects.add("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
            
            MapList mlCodeHeadYears = DomainObject.findObjects(context,
                                                                TYPE_WMS_CODE_HEAD_YEAR,
                                                                context.getVault().getName(),
                                                                null,               // where expression
                                                                strObjSelects);
            
            //Get all the allocations for Code Head Year Objects which have state ----.actual within the selected FY.
            Map mTemp = null;
            String strFY = "";
             
            for(int i = 0; i < mlCodeHeadYears.size(); i++){
                mTemp = (Map)mlCodeHeadYears.get(i);
                strFY = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
                if(UIUtil.isNotNullAndNotEmpty(strFY) && !(slFYs.contains(strFY))){
                    slFYs.add(strFY);
                }
            }
            
            //Sum up all the Allocation Amounts
        }catch(Exception ex){
            System.out.println("error in getFYs method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return slFYs;
    }
    
    public MapList getTotalAllocationDrillDown(Context context, String[] args) throws Exception 
    {
        MapList mlFinalList = new MapList();
        try{
            Map programMap = (Map) JPO.unpackArgs(args);
            String strFY = (String)programMap.get("strFinancialYear");
            String strCodeHeadYearId = (String)programMap.get("strCodeHeadYearId");
            //Get the allocation objects for the CodeHeadYear Object
            StringList slObjectSelects = new StringList(2);
            slObjectSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_ALLOCATION_DATE+"]");
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
            
            MapList mlAllocations = getCHYAllocations(context, strCodeHeadYearId, slObjectSelects);
            mlAllocations.sortStructure("attribute["+ATTRIBUTE_WMS_ALLOCATION_DATE+"]", "ascending", "date");
            Map mTemp = null;
            String strAllocationAmount = "";
            String strDate = "";
            String strLetterNumber = "";
            Map mFinalMap = new HashMap();
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
            for(int i = 0; i < mlAllocations.size(); i++){
                mTemp = (Map)mlAllocations.get(i);
                mFinalMap = new HashMap();
                strAllocationAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
                Double dblValue = Double.parseDouble(strAllocationAmount);
                String strAmount = String.format("%.2f", dblValue);
                strDate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_ALLOCATION_DATE+"]");
                strLetterNumber = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
                if(UIUtil.isNotNullAndNotEmpty(strAllocationAmount)){
                    BigDecimal bgTemp = new BigDecimal(strAllocationAmount);
                    if (bgTemp.compareTo(new BigDecimal(0)) < 0) {
                        mFinalMap.put("Type", "Withdrawl");
                        mFinalMap.put("WithdrawlAmount", strAmount);
                        mFinalMap.put("ReceiptAmount", "0.00");
                    } else {
                        mFinalMap.put("Type", "Allotment");
                        mFinalMap.put("ReceiptAmount", strAmount);
                        mFinalMap.put("WithdrawlAmount", "0.00");
                    }
                }
                Date dLetterDate = eMatrixDateFormat.getJavaDate(strDate);
                mFinalMap.put("LetterDate", "dated " + sdf.format(dLetterDate));
                mFinalMap.put("LetterNo", strLetterNumber);
                mlFinalList.add(mFinalMap);
            }
        } catch(Exception ex){
            System.out.println("error in getTotalAllocationDrillDown method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return mlFinalList;
    }
    
    public MapList getCHYAllocations(Context context, String strCodeHeadYearId, StringList slObjectSelects) throws Exception 
    {
        MapList mlAllocations = new MapList();
        try{
            
            DomainObject domParentObj = DomainObject.newInstance(context, strCodeHeadYearId);
            String strWhere = "current=='Frozen'";
            mlAllocations = domParentObj.getRelatedObjects(context,
                                                            RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION,
                                                            TYPE_WMS_CODE_HEAD_YEAR_ALLOCATION,
                                                            slObjectSelects,
                                                            null,       // relationshipSelects
                                                            false,      // getTo
                                                            true,       // getFrom
                                                            (short) 1,  // recurseToLevel
                                                            strWhere,// objectWhere
                                                            null);
        } catch(Exception ex){
            System.out.println("error in getCHYAllocations method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return mlAllocations;
    } 
    
    public MapList getWorkOrderData(Context context, boolean bSelectBillData, boolean bGetCurrentActual, boolean bSelectReviewDate, boolean bFundData, StringList slNewSelects) throws Exception 
    {
        MapList mlWOData = new MapList();
        try{
            
            //Get the Workorders connected with Context user.
            DomainObject doContextPerson = PersonUtil.getPersonObject(context);
            StringList slObjectSelects = new StringList();
            slObjectSelects.add("to["+RELATIONSHIP_WMS_PROJECT_WORKORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
            if (bFundData) {
                slObjectSelects.add(SELECT_FUND_REQUEST_CURRENT);
                slObjectSelects.add(SELECT_FUND_RELEASE_CURRENT);
                slObjectSelects.add(SELECT_FUND_REQUEST_FY);
                slObjectSelects.add(SELECT_FUND_RELEASE_FY);
                slObjectSelects.add(SELECT_FUND_REQUEST_AMOUNT);
                slObjectSelects.add(SELECT_FUND_RELEASE_AMOUNT);
            }
            if (bGetCurrentActual) {
                slObjectSelects.add(SELECT_FUND_REQUEST_CURRENT_ACTUAL);
                slObjectSelects.add(SELECT_FUND_RELEASE_CURRENT_ACTUAL);
            }
            if (bSelectReviewDate) {
                slObjectSelects.add(SELECT_FUND_REQUEST_REVIEW_ACTUAL);
                slObjectSelects.add(SELECT_FUND_RELEASE_REVIEW_ACTUAL);
            }
            if (bSelectBillData) {
                slObjectSelects.add(SELECT_AMB_CURRENT);
                slObjectSelects.add(SELECT_AMB_FY);
                slObjectSelects.add(SELECT_AMB_AMOUNT);
                slObjectSelects.add(SELECT_AMB_INVOICE_COST);
            }
            if(null != slNewSelects) {
                slObjectSelects.addAll(slNewSelects);
            }
            
            mlWOData = doContextPerson.getRelatedObjects(context,
                                                        RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE,
                                                        TYPE_WMS_WORK_ORDER,
                                                        slObjectSelects,
                                                        null,       // relationshipSelects
                                                        false,      // getTo
                                                        true,       // getFrom
                                                        (short) 1,  // recurseToLevel
                                                        null,// objectWhere
                                                        null);
            
        } catch(Exception ex){
            System.out.println("error in getWorkOrderData method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return mlWOData;
    }
    
    public MapList getSubAllocationDrillDown(Context context, String[] args) throws Exception 
    {
        MapList mlFinalList = new MapList();
        try{
            Map programMap = (Map) JPO.unpackArgs(args);
            String strFY = (String)programMap.get("strFinancialYear");
            String strCodeHeadIdFromTable = (String)programMap.get("strCodeHeadId");
            StringList slAdditionalSelects = new StringList();
            slAdditionalSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slAdditionalSelects.add(DomainConstants.SELECT_OWNER);
            slAdditionalSelects.add("to["+RELATIONSHIP_WMS_PROJECT_WORKORDER+"].from.name");
            
            MapList mlWOData = getWorkOrderData(context, false, true, true, true, slAdditionalSelects);
            
            Map mTemp = null;
            String strAllocationAmount = "";
            String strCodeHeadId = "";
            String strWOTitle = "";
            String strProjectName = "";
            String strWOOwner = "";
            String strWOOwnerFullName = "";
            Map mFinalMap = new HashMap();
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
            for(int i = 0; i < mlWOData.size(); i++){
                mTemp = (Map)mlWOData.get(i);
                strCodeHeadId = (String)mTemp.get("to["+RELATIONSHIP_WMS_PROJECT_WORKORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
                strWOTitle = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
                strProjectName = (String)mTemp.get("to["+RELATIONSHIP_WMS_PROJECT_WORKORDER+"].from.name");
                strWOOwner = (String)mTemp.get(DomainConstants.SELECT_OWNER);
                strWOOwnerFullName = PersonUtil.getFullName(context, strWOOwner);
                if(UIUtil.isNotNullAndNotEmpty(strCodeHeadId) && strCodeHeadIdFromTable.equals(strCodeHeadId)){
                    //get the Request Objects
                    StringList slRequestState = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_REQUEST_CURRENT));
                    StringList slRequestFY = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_REQUEST_FY));
                    StringList slRequestAmount = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_REQUEST_AMOUNT));
                    StringList slRequestApprovedDate = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_REQUEST_CURRENT_ACTUAL));
                    StringList slRequestReviewDate = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_REQUEST_REVIEW_ACTUAL));
                    
                    String strRequestState = "";
                    String strRequestFY = "";
                    String strRequestAmount = "";
                    for(int j=0;j<slRequestState.size();j++){
                        mFinalMap = new HashMap();
                        strRequestState = (String)slRequestState.get(j);
                        strRequestFY = (String)slRequestFY.get(j);
                        //if Request if approved and for same FY as passed to the method then add it to total. 
                        if (UIUtil.isNotNullAndNotEmpty(strRequestState) && strRequestState.equals("Approved") && UIUtil.isNotNullAndNotEmpty(strRequestFY) && strRequestFY.equals(strFY)) {
                            strRequestAmount = (String)slRequestAmount.get(j);
                            Double dblValue = Double.parseDouble(strRequestAmount);
                            String strAmount = String.format("%.2f", dblValue);
                            String strApprovedDate = slRequestApprovedDate.get(j);
                            Date dApprovedDate = eMatrixDateFormat.getJavaDate(strApprovedDate);
                            String strReviewDate = slRequestReviewDate.get(j);
                            Date dReviewDate = eMatrixDateFormat.getJavaDate(strReviewDate);
                            mFinalMap.put("Amount", strAmount);
                            mFinalMap.put("ApprovedDate", sdf.format(dApprovedDate));
                            mFinalMap.put("ReviewDate", sdf.format(dReviewDate));
                            mFinalMap.put("WOTitle", strWOTitle);
                            mFinalMap.put("ProjectName", strProjectName);
                            mFinalMap.put("WOOwner", strWOOwnerFullName);
                            mlFinalList.add(mFinalMap);
                        }
                    }
                    StringList slReleaseState = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_RELEASE_CURRENT));
                    StringList slReleaseFY = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_RELEASE_FY));
                    StringList slReleaseAmount = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_RELEASE_AMOUNT));
                    StringList slReleaseApprovedDate = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_RELEASE_CURRENT_ACTUAL));
                    StringList slReleaseReviewDate = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_FUND_RELEASE_REVIEW_ACTUAL));
                    String strReleaseState = "";
                    String strReleaseFY = "";
                    String strReleaseAmount = "";
                    for(int k=0;k<slReleaseState.size();k++){
                        mFinalMap = new HashMap();
                        strReleaseState = (String)slReleaseState.get(k);
                        strReleaseFY = (String)slReleaseFY.get(k);
                        //if Request if approved and for same FY as passed to the method then add it to total. 
                        if (UIUtil.isNotNullAndNotEmpty(strReleaseState) && strReleaseState.equals("Approved") && UIUtil.isNotNullAndNotEmpty(strReleaseFY) && strReleaseFY.equals(strFY)) {
                            strReleaseAmount = (String)slReleaseAmount.get(k);
                            if (UIUtil.isNotNullAndNotEmpty(strReleaseAmount)) {
                                BigDecimal bgTemp = new BigDecimal(strReleaseAmount);
                                bgTemp = bgTemp.negate();
                                Double dblValue = Double.parseDouble(bgTemp.toString());
                                String strAmount = String.format("%.2f", dblValue);
                                String strApprovedDate = slReleaseApprovedDate.get(k);
                                Date dApprovedDate = eMatrixDateFormat.getJavaDate(strApprovedDate);
                                String strReviewDate = slReleaseReviewDate.get(k);
                                Date dReviewDate = eMatrixDateFormat.getJavaDate(strReviewDate);
                                mFinalMap.put("Amount", strAmount);
                                mFinalMap.put("ApprovedDate", sdf.format(dApprovedDate));
                                mFinalMap.put("ReviewDate", sdf.format(dReviewDate));
                                mFinalMap.put("WOTitle", strWOTitle);
                                mFinalMap.put("ProjectName", strProjectName);
                                mFinalMap.put("WOOwner", strWOOwnerFullName);
                                mlFinalList.add(mFinalMap);
                            }
                        }
                    }
                }
            }
        } catch(Exception ex){
            System.out.println("error in getSubAllocationDrillDown method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        mlFinalList.sortStructure("WOTitle", "ascending", "string");
        return mlFinalList;
    }
    
    public MapList getBillDrillDown(Context context, String[] args) throws Exception 
    {
        MapList mlFinalList = new MapList();
        try{
            Map programMap = (Map) JPO.unpackArgs(args);
            String strFY = (String)programMap.get("strFinancialYear");
            String strCodeHeadIdFromTable = (String)programMap.get("strCodeHeadId");
            StringList slAdditionalSelects = new StringList();
            slAdditionalSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slAdditionalSelects.add(DomainConstants.SELECT_OWNER);
            slAdditionalSelects.add("to["+RELATIONSHIP_WMS_PROJECT_WORKORDER+"].from.name");
            slAdditionalSelects.add(SELECT_AMB_APPROVED_ACTUAL);
            slAdditionalSelects.add(SELECT_AMB_REVIEW_ACTUAL);
            slAdditionalSelects.add(SELECT_AMB_NAME);
            
            MapList mlWOData = getWorkOrderData(context, true, false, false, false, slAdditionalSelects);
            
            Map mTemp = null;
            String strAllocationAmount = "";
            String strCodeHeadId = "";
            String strWOTitle = "";
            String strProjectName = "";
            String strWOOwner = "";
            String strWOOwnerFullName = "";
            Map mFinalMap = new HashMap();
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy");
            for(int i = 0; i < mlWOData.size(); i++){
                mTemp = (Map)mlWOData.get(i);
                strCodeHeadId = (String)mTemp.get("to["+RELATIONSHIP_WMS_PROJECT_WORKORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
                strWOTitle = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
                strProjectName = (String)mTemp.get("to["+RELATIONSHIP_WMS_PROJECT_WORKORDER+"].from.name");
                strWOOwner = (String)mTemp.get(DomainConstants.SELECT_OWNER);
                strWOOwnerFullName = PersonUtil.getFullName(context, strWOOwner);
                if(UIUtil.isNotNullAndNotEmpty(strCodeHeadId) && strCodeHeadIdFromTable.equals(strCodeHeadId)){
                    //get the AMB Objects
                    StringList slAMBState = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_CURRENT));
                    StringList slAMBFY = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_FY));
                    StringList slAMBInvoiceAmount = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_INVOICE_COST));
                    StringList slAMBReviewDate = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_REVIEW_ACTUAL));
                    StringList slAMBName = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_NAME));
                    
                    String strAMBState = "";
                    String strAMBFY = "";
                    String strBillAmount = "";
                    String strAMBName = "";
                    String strReviewDate = "";
                    String strBillClearDate = "";
                    String strBillClearAmount = "";
                    boolean bInclude = false;
                    for(int j = 0; j < slAMBState.size(); j++){
                        bInclude = false;
                        mFinalMap = new HashMap();
                        strAMBState = (String)slAMBState.get(j);
                        strAMBFY = (String)slAMBFY.get(j);
                        strAMBName = (String)slAMBName.get(j);
                        strBillAmount = (String)slAMBInvoiceAmount.get(j);
                        Double dblValue = Double.parseDouble(strBillAmount);
                        strBillAmount = String.format("%.2f", dblValue);
                        strReviewDate = slAMBReviewDate.get(j);
                        Date dReviewDate = eMatrixDateFormat.getJavaDate(strReviewDate);
                        strReviewDate = sdf.format(dReviewDate);
                        //if AMB is in review state and for same FY as passed to the method then add it to total Bill Pending. 
                        if (UIUtil.isNotNullAndNotEmpty(strAMBState) && strAMBState.equals("Review") && UIUtil.isNotNullAndNotEmpty(strAMBFY) && strAMBFY.equals(strFY)) {
                            strBillClearDate = "NA";
                            strBillClearAmount = "NA";
                            bInclude = true;
                        } else if (UIUtil.isNotNullAndNotEmpty(strAMBState) && (strAMBState.equals(STATE_APPROVED) || strAMBState.equals(STATE_PLAN))&& UIUtil.isNotNullAndNotEmpty(strAMBFY) && strAMBFY.equals(strFY)) {
                            StringList slAMBApprovedDate = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_APPROVED_ACTUAL));
                            strBillClearDate = slAMBApprovedDate.get(j);
                            Date dApprovedDate = eMatrixDateFormat.getJavaDate(strBillClearDate);
                            strBillClearDate = sdf.format(dApprovedDate);
                            StringList slAMBAmount = ProgramCentralUtil.getAsStringList(mTemp.get(SELECT_AMB_AMOUNT));
                            strBillClearAmount = (String)slAMBAmount.get(j);
                            Double dblCAValue = Double.parseDouble(strBillClearAmount);
                            strBillClearAmount = String.format("%.2f", dblCAValue);
                            bInclude = true;
                        }
                        if (bInclude) {
                            mFinalMap.put("BillNo", strAMBName);
                            mFinalMap.put("BillAmount", strBillAmount);
                            mFinalMap.put("BillClearAmount", strBillClearAmount);
                            mFinalMap.put("BillDate", strReviewDate);
                            mFinalMap.put("BillClearDate", strBillClearDate);
                            mFinalMap.put("WOTitle", strWOTitle);
                            mFinalMap.put("ProjectName", strProjectName);
                            mFinalMap.put("WOOwner", strWOOwnerFullName);
                            mlFinalList.add(mFinalMap);
                        }
                    }
                }
            }
        } catch(Exception ex){
            System.out.println("error in getSubAllocationDrillDown method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        mlFinalList.sortStructure("WOTitle", "ascending", "string");
        return mlFinalList;
    }
}
