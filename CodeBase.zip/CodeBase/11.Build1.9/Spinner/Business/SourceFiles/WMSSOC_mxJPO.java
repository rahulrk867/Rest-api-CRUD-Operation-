
/** Name of the JPO    : WMSSOC
 ** Developed by    : Matrixone 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to create SOC and perform the utility operations for SOC
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/

import com.matrixone.apps.framework.ui.ProgramCallable;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.DomainObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;

import java.util.Map;
import java.util.Iterator;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.common.Person;
import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.PersonUtil;

/**
 * The purpose of this JPO is to handle functionality of SOR
 * 
 * @author WMS
 * @version R419 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSSOC_mxJPO extends WMSConstants_mxJPO {
	/**
	 * Constructor.
	 * 
	 * @param context - the eMatrix <code>Context</code> object
	 * @param args    - holds no arguments
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 419
	 */

	public WMSSOC_mxJPO(Context context, String[] args) throws Exception {
		super(context, args);
	}

	/**
	 * Method will create SOR object and assign the attributes to it.
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args    
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 419
	 */
	@com.matrixone.apps.framework.ui.CreateProcessCallable
	public Map<String,String> performCreateSOCAddProcess(Context context, String[] args) throws Exception {
		Map<String,String> mapReturnMap = new HashMap();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strDescription = (String) programMap.get("Description");
			String Title = (String) programMap.get("Title");
			String strFinancialYear = (String) programMap.get("FinancialYear");
			String strProjectType = (String) programMap.get("ProjectType");
			String strSOCEquipmentsIncluded = (String) programMap.get("attribute_WMSSOCEquipementsIncluded");
			String strSOCWorksIncluded = (String) programMap.get("attribute_WMSSOCWorksIncluded");
			String strSOCServicesIncluded = (String) programMap.get("attribute_WMSSOCServicesIncluded");
			strSOCEquipmentsIncluded = changeValueBasedOnInput(strSOCEquipmentsIncluded);
			strSOCWorksIncluded = changeValueBasedOnInput(strSOCWorksIncluded);
			strSOCServicesIncluded = changeValueBasedOnInput(strSOCServicesIncluded);
			mapReturnMap = validateInputValues(strSOCEquipmentsIncluded,strSOCServicesIncluded,strSOCWorksIncluded);
			if(mapReturnMap.size()!=0)
				return mapReturnMap;
			if (UIUtil.isNotNullAndNotEmpty(Title)) {
				Map<String,String> mAttrMap = new HashMap<String,String>();
				mAttrMap.put(ATTRIBUTE_WMSSOC_FINANCIAL_YEAR, strFinancialYear);
				mAttrMap.put(ATTRIBUTE_WMSSOC_PROJECT_TYPE, strProjectType);
				mAttrMap.put(ATTRIBUTE_WMSSOC_EQUIPMENTS_INCLUDED,strSOCEquipmentsIncluded);
				mAttrMap.put(ATTRIBUTE_WMSSOC_WORKS_INCLUDED,strSOCWorksIncluded);
				mAttrMap.put(ATTRIBUTE_WMSSOC_SERVICES_INCLUDED,strSOCServicesIncluded);
				mAttrMap.put(DomainConstants.ATTRIBUTE_TITLE, Title);
				DomainObject domSOC = DomainObject.newInstance(context);
				String strSOCName = FrameworkUtil.autoName(context, "type_WMSSOC", "", "", "", "", true, false);
				domSOC.createObject(context, TYPE_WMSSOC, strSOCName, "1", POLICY_WMSSOC, "eService Production");
				domSOC.setAttributeValues(context, mAttrMap);
				domSOC.setDescription(context, strDescription);
				mapReturnMap.put("id", domSOC.getObjectId(context));
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			mapReturnMap.put("Action", "Stop");
			mapReturnMap.put("Message", exception.getMessage());
		}
		return mapReturnMap;

	}
	/**
	 * Validate the values of the input
	 * @param strSOCEquipmentsIncluded
	 * @param strSOCServicesIncluded
	 * @param strSOCWorksIncluded
	 * @return
	 */
	private Map validateInputValues(String strSOCEquipmentsIncluded, String strSOCServicesIncluded,
			String strSOCWorksIncluded) {
		Map<String,String> mapReturnMap = new HashMap();
		
		if (strSOCEquipmentsIncluded.equals("false") && 
			strSOCServicesIncluded.equals("false") &&
			strSOCWorksIncluded.equals("false")) 
		{
			mapReturnMap.put("ErrorMessage", EnoviaResourceBundle.
					getProperty(context, "wmsStringResource", context.getLocale(),
							"WMS.SOC.Create.EquipmentsServicesWorksAllFalse"));
	    	return mapReturnMap;
		}
		return mapReturnMap;
		
	}

	/**
	 * If the checkbox is enabled we get on in the input which is converted to boolean value.
	 * @param strSOCEquipmentsIncluded
	 * @return
	 */
	private String changeValueBasedOnInput(String strSOCEquipmentsIncluded) {
		String strSOCIncludes="";
		if("on".equals(strSOCEquipmentsIncluded))
			strSOCEquipmentsIncluded = "Yes";
			
		else
			strSOCEquipmentsIncluded = "No";
		//System.out.println("strSOCEquipmentsIncluded---"+strSOCEquipmentsIncluded);
		return strSOCEquipmentsIncluded;
	}
	/**
	 * Validats the rough indicative cost
	 * @param strRoughIndicativeCost
	 * @return
	 */
	private boolean validateRoughIndicativeCost(String strRoughIndicativeCost) {
		boolean isValidated = true;
		String regExp = "[0-9]+([,.][0-9]{1,2})?";
		Pattern pattern = Pattern.compile(regExp);
		Matcher matcher = pattern.matcher(strRoughIndicativeCost); 
		isValidated = matcher.matches();
		
		return isValidated;
		
	}

	/**
	 * Range function to bring To List of financial year on create page
	 * 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public Map<String,StringList> getFinancialYearList(Context context, String[] args) throws Exception {
		Map<String,StringList> mRange = new HashMap();
		try {
			String strRangeOfYear = EnoviaResourceBundle.getProperty(context, "WMS.SOC.FinancialYear");
			String[] rangeFromPropertiesFile = strRangeOfYear.split("-");
			StringList slRange = new StringList();
			String sRange = "";
			for (int i = Integer.parseInt(rangeFromPropertiesFile[0]); i < Integer
					.parseInt(rangeFromPropertiesFile[1]); i++) {
				int firstInt = i;
				int secondInt = firstInt + 1;
				sRange = i + "-" + secondInt;
				slRange.add(sRange);
			}
			mRange.put("field_choices", slRange);
			mRange.put("field_display_choices", slRange);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mRange;
	}

	/**
	 * method get the basic bus info for the general class
	 *
	 * @return selListBusSelects SelectList containing the bus selects : type name
	 *         revision policy vault
	 * @author WMS
	 * @since 419
	 */
	public static SelectList getSubClassBusSelect() {
		SelectList selListBusSelects = new SelectList(6);
		selListBusSelects.add(DomainConstants.SELECT_ID);
		selListBusSelects.add(DomainConstants.SELECT_POLICY);
		selListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
		selListBusSelects.add(DomainConstants.SELECT_VAULT);
		selListBusSelects.add(DomainConstants.SELECT_TYPE);
		selListBusSelects.add(DomainConstants.SELECT_NAME);
		return selListBusSelects;
	}

	/**
	 * Method to Generate the Serial Numbers after the
	 * Object Creation
	 */
	public Vector getSNOColumn(Context context, String[] args) throws Exception {
		try {
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			Iterator iterator = objectList.iterator();
			for (int i = 1; i < intSize + 1; i++) {
				vecResponse.add(String.valueOf(i));
			}

			return vecResponse;
		} catch (Exception exception) {
			exception.printStackTrace();
			throw exception;
		}
	}
	/**
	 * Returns the list of the project type
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public Map<String,StringList> getProjectTypeList(Context context, String[] args) throws Exception {
		Map<String,StringList> mRange = new HashMap();
		try {
			String strProjectType = EnoviaResourceBundle.getProperty(context, "WMS.SOC.ProjectType");
			String[] rangeFromPropertiesFile = strProjectType.split(",");
			StringList slRange = new StringList();
			String sRange = "";
			for (int i = 0; i < rangeFromPropertiesFile.length; i++) {
				sRange = rangeFromPropertiesFile[i];
				slRange.add(sRange);
			}
			mRange.put("field_choices", slRange);
			mRange.put("field_display_choices", slRange);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mRange;
	}
	
	
	/**
	 * Show comments on properties page
	 *   
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public String showReviewComments(Context context,String [] args) throws Exception {
		StringBuilder sbTable=new StringBuilder();
		Map mInputMap = (Map) JPO.unpackArgs(args);
		Map fieldMap = (Map) mInputMap.get("fieldMap");
		Map requestMap = (Map) mInputMap.get("requestMap");
		Map settings =  (Map) fieldMap.get("settings");
		String strFieldKey = (String) settings.get("FieldKey");
		String strAttribute= "WMSSOCComments";
		if(strFieldKey!=null & strFieldKey.equalsIgnoreCase("Contractor"))
			strAttribute="WMSSOCComments";
		String strObjectId = (String) requestMap.get("objectId");
		DomainObject domDoc = DomainObject.newInstance(context,strObjectId);
		strAttribute = domDoc.getAttributeValue(context, strAttribute);
		StringList slVal = FrameworkUtil.split(strAttribute, "~"); 
		if(slVal.size()>0) {
			sbTable.append("<table style=\"width:100%;border: 1px solid black;padding:3px;\"><tr style=\"border: 1px solid black;background-color:lightblue;padding:10px;\"><th style=\"border: 1px solid black;text-align:center;width:5%\"><b>Sr No</b></th><th style=\"border: 1px solid black;text-align:center;\"><b>Person</b></th><th style=\"border: 1px solid black;text-align:center;\"><b>Comments</b></th><th style=\"border: 1px solid black;text-align:center;\"><b>Date</b></th><th style=\"border: 1px solid black;text-align:center;\"><b>State</b></th></tr>");
			for(int i=0;i<slVal.size();i++) {
				StringList slData = FrameworkUtil.split((String)slVal.get(i), "|");
				String strState = DomainConstants.EMPTY_STRING;
				if(slData.size()>3)
					strState = slData.get(3);
				sbTable.append("<tr style=\"border: 1px solid black;text-align:center;\">")
				.append("<td style=\"border: 1px solid black;padding:2px;\">").append(i+1).append("</td>")
				.append("<td style=\"border: 1px solid black;\">").append(slData.get(2)).append("</td>")
				.append("<td style=\"border: 1px solid black;text-align:left;\">").append(slData.get(0)).append("</td>")
				.append("<td style=\"border: 1px solid black;\">").append(slData.get(1)).append("</td>")
				.append("<td style=\"border: 1px solid black;\">").append(strState).append("</td>")
				.append("</tr>");
			}
			sbTable.append("</table>");
		}	
		return sbTable.toString();

	}
	
	
	/**
	 * Performs the post process
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@com.matrixone.apps.framework.ui.PostProcessCallable	
	public void performPostRespond(Context context,String[] args) throws Exception
	{
		String strNewRevId = DomainConstants.EMPTY_STRING;
		boolean isContextPushed = false;
		try {
			LocalDate lToday = LocalDate.now();
			String strToday = lToday.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy"));
			Map mInputMap = (Map) JPO.unpackArgs(args);
			String strUser = MqlUtil.mqlCommand(context,"print person '"+context.getUser()+"' select fullname dump");
			Map requestMap = (Map) mInputMap.get("requestMap");
			String strObjectId = (String) requestMap.get("objectId");
			String strTargetState = (String) requestMap.get("TargetState");
			String stateInfo = getCommentsBasedOnState(strTargetState);
			DomainObject domSOC = DomainObject.newInstance(context, strObjectId);
			StringList slSelect = new StringList(2);
			slSelect.add(DomainConstants.SELECT_NAME);
			slSelect.add(DomainConstants.SELECT_OWNER);
			slSelect.add(DomainConstants.SELECT_CURRENT);
			slSelect.add("attribute["+ DomainConstants.ATTRIBUTE_TITLE + "].value");
			slSelect.add("attribute["+ATTRIBUTE_WMSSOC_COMMENTS+"].value");
			slSelect.add("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
			Map mSOCInfo = domSOC.getInfo(context, slSelect);
			String strProjectId = (String)mSOCInfo.get("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
			String strSOCTitle = (String)mSOCInfo.get("attribute["+ DomainConstants.ATTRIBUTE_TITLE + "].value");
			String strComments = (String) requestMap.get("Comments");
			String strUIComments = strComments;
			String strCurrent = (String)mSOCInfo.get(DomainObject.SELECT_CURRENT);
			String strSOCOwner = (String)mSOCInfo.get(DomainObject.SELECT_OWNER);
			
			if("Create".equals(strTargetState)) {
				String strMessageHeading = EnoviaResourceBundle.getProperty(context,
						"wmsStringResource", context.getLocale(), "WMS.SOC.Message.SOC.MoreInfo.Heading");
				String strMessageBody = EnoviaResourceBundle.getProperty(context,
						"wmsStringResource", context.getLocale(), "WMS.SOC.Message.SOC.MoreInfo.Body");
				String strMessage = strUser + " " + strMessageBody + " " + strSOCTitle + "\n" + strUIComments;
				String strHeading = strUser + " " + strMessageHeading + strSOCTitle;
				StringList slTOList = new StringList();
				slTOList.add((String)mSOCInfo.get(DomainConstants.SELECT_OWNER));
				sendNotification(context,strObjectId,strUser,strHeading,strMessage,slTOList);
			}
			
			
			ContextUtil.pushContext(context);	
			isContextPushed = true;			
			String strDBPMCComments=DomainConstants.EMPTY_STRING;
			Map mInfo = domSOC.getInfo(context, slSelect);
				strDBPMCComments=(String) mInfo.get("attribute["+ATTRIBUTE_WMSSOC_COMMENTS+"].value");
				strComments = strComments+"|"+strToday + "|"+strUser+ "|" + stateInfo ;
				if(UIUtil.isNotNullAndNotEmpty(strDBPMCComments)) {
					strComments= strDBPMCComments +"~" + strComments;
				}
			MqlUtil.mqlCommand(context,"trigger off");
			if("Rejected".equals(strTargetState)){
				strCurrent = EnoviaResourceBundle.getProperty(context,
						"emxFrameworkStringResource", context.getLocale(), "emxFramework.State.WMSSOC."+strCurrent);
				domSOC.setAttributeValue(context, ATTRIBUTE_WMS_SOC_REJECT_STATE, strCurrent);
			}
			
			if("Create".equals(strTargetState)){
				strTargetState = "Rejected";
				DomainObject doNewSOC = new DomainObject(domSOC
                                        .reviseObject(context, true));
				doNewSOC.setAttributeValue(context, ATTRIBUTE_WMSSOC_COMMENTS, strComments);
				doNewSOC.setOwner(context, strSOCOwner);
				strNewRevId = (String)doNewSOC.getInfo(context,DomainObject.SELECT_ID);
			}
			domSOC.setState(context, strTargetState);
			domSOC.setAttributeValue(context, ATTRIBUTE_WMSSOC_COMMENTS, strComments);
			MqlUtil.mqlCommand(context,"trigger on");
			if("Submit".equals(strTargetState)){
				String strMessage = strUser + ": need information about following things \n" + strUIComments;
				String strHeading = strUser + " need more information for SOC ref: " + strSOCTitle;
				StringList slTOList = new StringList();
				slTOList.addAll(getSO1Planning(context));
				if(UIUtil.isNotNullAndNotEmpty(strProjectId)) {
					StringList allMembers = (StringList)extractRouteAndProjectMembers(context,strObjectId,strProjectId);
					if(allMembers.size()>0)
						slTOList.addAll(allMembers);						
				}
				if(UIUtil.isNotNullAndNotEmpty(strNewRevId)){
					sendNotification(context,strNewRevId,strUser,strHeading,strMessage,slTOList);
				}else{
					sendNotification(context,strObjectId,strUser,strHeading,strMessage,slTOList);
				}
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally{
			if(isContextPushed)
				ContextUtil.popContext(context);
		}
	}
	/**
	 * Returns the comments to display in the table.
	 * @param strTargetState
	 * @return
	 */
	private String getCommentsBasedOnState(String strTargetState) {
		String stateInfo = DomainConstants.EMPTY_STRING;
		if("Create".equals(strTargetState))
			stateInfo = "Request information";
		else if("Submit".equals(strTargetState))
			stateInfo = "Need information for RIC";
		else
			stateInfo = "Reject";
		return stateInfo;
	}
	
	/**
	 * Method query all the SOC in db
	 *
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@ProgramCallable
	public MapList getWMSSOCs(Context context, String[] args) throws Exception {
		MapList mlSOC = new MapList();
		try {
			String objectWhere = "revision==last";
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlSOC = DomainObject.findObjects(context, TYPE_WMSSOC, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					objectWhere, // where clause
					strListBusSelects); // object selects
			
			String strCurrent = DomainConstants.EMPTY_STRING;
			for (int i = 0; i < mlSOC.size(); i++) {
				Map mMap = (Map) mlSOC.get(i);
				strCurrent = (String) mMap.get(DomainConstants.SELECT_CURRENT);
				if (!strCurrent.equalsIgnoreCase("Create")) {
					mMap.put("disableSelection", "true");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		mlSOC.sort("originated", "descending", "date");
		return mlSOC;
	}
	
	/**
	 * Method query all the SOC in db
	 *
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@ProgramCallable
	public MapList getWMSSOCsNotUnderExecution(Context context, String[] args) throws Exception {
		MapList mlSOC = new MapList();
		try {
			String objectWhere = "revision==last && current!=UnderExecution";
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlSOC = DomainObject.findObjects(context, TYPE_WMSSOC, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					objectWhere, // where clause
					strListBusSelects); // object selects
			//System.out.println("The object id ---------"+mlSOC);
			
			String strCurrent = DomainConstants.EMPTY_STRING;
			for (int i = 0; i < mlSOC.size(); i++) {
				Map mMap = (Map) mlSOC.get(i);
				strCurrent = (String) mMap.get(DomainConstants.SELECT_CURRENT);
				if (!strCurrent.equalsIgnoreCase("Create")) {
					mMap.put("disableSelection", "true");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		mlSOC.sort("originated", "descending", "date");
		return mlSOC;
	}
	
	/**
	 * Method query all the SOC in db
	 *
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@ProgramCallable
	public MapList getWMSSOCsUnderAE(Context context, String[] args) throws Exception {
		MapList mlSOC = new MapList();
		try {
			String objectWhere = "revision==last && current==AE";
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlSOC = DomainObject.findObjects(context, TYPE_WMSSOC, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					objectWhere, // where clause
					strListBusSelects); // object selects
			
			String strCurrent = DomainConstants.EMPTY_STRING;
			for (int i = 0; i < mlSOC.size(); i++) {
				Map mMap = (Map) mlSOC.get(i);
				strCurrent = (String) mMap.get(DomainConstants.SELECT_CURRENT);
				if (!strCurrent.equalsIgnoreCase("Create")) {
					mMap.put("disableSelection", "true");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		mlSOC.sort("originated", "descending", "date");
		return mlSOC;
	}
	
	
	/** exclude the connected SOC in search field
	 *  
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@com.matrixone.apps.framework.ui.ExcludeOIDProgramCallable
	public StringList excludeConnectedSOC(Context context,String[] args) throws Exception{
		StringList slExclude =new StringList();
		StringList strListBusSelects = new StringList();
		strListBusSelects.add(DomainConstants.SELECT_ID);
		MapList mlSOCwithRelationship = DomainObject.findObjects(context, TYPE_WMSSOC, // type filter
				DomainConstants.QUERY_WILDCARD, // vault filter
				"relationship["+ RELATIONSHIP_WMSPROJECTSOC + "]", // where clause
				strListBusSelects); // object selects
		for (int i = 0; i < mlSOCwithRelationship.size(); i++)
		{
			Map map = (Map) mlSOCwithRelationship.get(i);
			String id = (String)map.get(DomainConstants.SELECT_ID);
			slExclude.add(id);
		}
		return slExclude;
	}
	/**
	 * Display the checkbox.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public String displayCopyParameterCheckBox(Context context, String[] args) throws Exception{
		Map requestMap = (Map) JPO.unpackArgs(args);
		Map fieldMap = (Map)requestMap.get("fieldMap");
		//System.out.println("fieldMap----->"+fieldMap);
		Map settings = (Map)fieldMap.get("settings");
		//System.out.println("settings----->"+settings);
		String adminType = (String)settings.get("Admin Type");
		//System.out.println("adminType----->"+adminType);
		//System.out.println("<input type=\"checkbox\" checked=\"checked\" name=\"" + adminType + "\"/>");
		return  "<input type=\"checkbox\" checked=\"checked\" name=\"" + adminType + "\"/>";
    }
	
/**
 * Checks if the Budgetory quotes are attached to the WMSSOC before promotion
 * @param context
 * @param args
 * @return
 * @throws Exception
 */
	public int checkBudgetoryQuotes(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId);
			StringList slRefDocs = doObj.getInfoList(context, "from["+DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT+"].to.id");
			if ((slRefDocs.size() == 0)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.SOC.NoRefDoc");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			String strEquipmentsIncluded = doObj.getAttributeValue(context, ATTRIBUTE_WMSSOC_EQUIPMENTS_INCLUDED);
			if("TRUE".contentEquals(strEquipmentsIncluded)) {
				StringList slBudgetoryQuotes = doObj.getInfoList(context, "from["+RELATIONSHIP_WMS_BUDGETORY_QUOTES+"].to.id");
				if ((slBudgetoryQuotes.size() == 0)) {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.SOC.NoBudgetoryQuotes");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
			}
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	 * This Load Apprval Template table content.
	 * @param context
	 * @param args
	 * @return 
	 * @throws Exception
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getApprovalTemplate(Context context, String[] args) throws Exception {
		MapList mlApprovalTemplate=new MapList();
		try {
			StringList strListBusSelects     = new StringList(1);
            strListBusSelects.add(DomainConstants.SELECT_ID);
            strListBusSelects.add(DomainConstants.SELECT_NAME);
           
            StringList strListRelSelects     = new StringList(1);
            strListRelSelects.add(DomainRelationship.SELECT_ID);
            strListRelSelects.add("attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"]");
			Map mInputMap = (Map) JPO.unpackArgs(args);
			String strObjId = (String)mInputMap.get("objectId");
			DomainObject domObjSOC = DomainObject.newInstance(context, strObjId);
			ContextUtil.pushContext(context);
			mlApprovalTemplate=domObjSOC.getRelatedObjects(context, // matrix context
					RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, // relationship pattern
                     DomainConstants.TYPE_ROUTE_TEMPLATE, // type pattern
                    strListBusSelects, // object selects
                    strListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 1, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
			ContextUtil.popContext(context);
		}catch (Exception ex) {
			throw ex;// TODO: handle exception
		}
		return mlApprovalTemplate;
	}
	/**
	 * Returns  range of the template purpose
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@com.matrixone.apps.framework.ui.CellRangeJPOCallable
	public Map getSOCTemplatePurposeRange(Context context, String[] args) throws Exception{
		Map mRange =new HashMap();
		 try {
	 		  String strMappingKey = EnoviaResourceBundle.getProperty(context, "WMS.SOC.RouteTemplate.Purpose");
			  StringList slKeys = FrameworkUtil.split(strMappingKey, ",");
			  mRange.put("field_choices", slKeys);
			  mRange.put("field_display_choices", slKeys);
		    }catch(Exception e) {
			 e.printStackTrace();
		 }
		return mRange;
	}

	

	/**
	 * Checks if all the RICs are approved
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int checkAllconnectedRICApproved(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doSOCObj = new DomainObject(sObjectId);
			StringList slRICItemState = doSOCObj.getInfoList(context, "from["+RELATIONSHIP_WMSSOC_RICMASTER+"].to.current");
			if(slRICItemState.size()==0) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.RIC.NORICConnected");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			if(slRICItemState.contains("Create")||slRICItemState.contains("Review")) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.RIC.RICNotInApprovedState");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			String sProjectId = doSOCObj.getInfo(context, "to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
			if(!UIUtil.isNotNullAndNotEmpty(sProjectId)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.RIC.NoProject");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			
			
			String strBusWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\" || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
			MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strBusWhere);
			
			if(mlExtRoutes.size()==0){
				
				String strRouteExist = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from[Object Route|attribute[Route Base State]==state_RIC].to.current dump");
				if("Complete".equals(strRouteExist)){
					return 0;
				}else{				
					String strMessage = "Please add Route and then proceed";
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
			}
			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public int checkForRoute(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doSOCObj = new DomainObject(sObjectId);
						
			String strBusWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\" || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
			MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strBusWhere);
			
			if(mlExtRoutes.size()==0){
				
				String strRouteExist = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from[Object Route|attribute[Route Base State]==state_ListingOfProjects].to.current dump");
				if("Complete".equals(strRouteExist)){
					return 0;
				}else{				
					String strMessage = "Please add Route and then proceed";
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
			}			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	 * Creates the route between the Listing of Project to AE state.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int createRouteOnPromoteOfListingOfProjectsToAE(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doSOCObj = null;
			String strTemplateId ="";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doSOCObj = new DomainObject(sObjectId);
				
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);
					ContextUtil.pushContext(context);
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
					ContextUtil.popContext(context);
				} else {
					
					String strPolicy = (String)doSOCObj.getInfo(context,DomainConstants.SELECT_POLICY);
					String strProjectOwner = doSOCObj.getInfo(context, "to["+RELATIONSHIP_WMSPROJECTSOC+"].from.owner");
					
					String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"Listing Of Projects\"";
					MapList routeMapList= doSOCObj.getRelatedObjects(context, RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
					if(routeMapList != null && routeMapList.isEmpty() == false){
						Map mRouteTemplateMap = (Map)routeMapList.get(0);
						strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
						String sRouteDescription = (String)doSOCObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
						String sState = (String)doSOCObj.getInfo(context, DomainConstants.SELECT_CURRENT);
						String sApprovalTemplateId = strTemplateId;
						String strContectUser =  context.getUser();
						Map mRouteAttrib= new HashMap();
						mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
						
						Map objectRouteAttributeMap=new HashMap(); 
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy,false ));
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_ListingOfProjects");
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,"Review");
						Map reviewerInfo= new HashMap();
						ContextUtil.pushContext(context);
						Route route = Route.createAndStartRouteFromTemplateAndReviewers(context,
										sApprovalTemplateId,
										sRouteDescription,
										strProjectOwner , 
										sObjectId,
										POLICY_WMSSOC,
										"BoardProceedings", 
										mRouteAttrib,
										objectRouteAttributeMap, 
										reviewerInfo,
										true);
						route.promote(context);
						ContextUtil.popContext(context);
					}
				}
			}
			return 0;
		
		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}
	
	
	/**
	 * Checks if all the RICs are approved
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int checkApprovedTemplate(Context context, String[] args)throws Exception {
		
    	String STR_ERROR_MSG_EMPTY="Purpose is empty for Approval Template ";
    	String STR_ERROR_MSG="Please add Approval Template for value";
    	try{
    	
		StringList strListBusSelects = new StringList(DomainConstants.SELECT_ID);
    	strListBusSelects.add(DomainConstants.SELECT_NAME);
    	StringList strListRelSelects = new StringList(DomainRelationship.SELECT_ID);
    	strListRelSelects.add("attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"]");
    	DomainObject domSOC = DomainObject.newInstance(context,args[0]);
		
		StringList slApprovalReasons = new StringList();
		String strApprovapPurposeListEPC = EnoviaResourceBundle.getProperty(context,"WMS.SOC.RouteTemplate.Purpose");
		
		StringList slKeys = FrameworkUtil.split(strApprovapPurposeListEPC, ",");
		  StringList slRange=new StringList();
		  String sToken=DomainConstants.EMPTY_STRING;
		  for(int i=0;i<slKeys.size();i++) {
			  sToken=(String)slKeys.get(i);
			  String[] sSpilts=  sToken.split("~");
			  sToken=sSpilts[1];
			  if(!slApprovalReasons.contains(sToken)){
				  slApprovalReasons.add(sToken);
			  }
		  }
		Map<String,Integer> mCounter=new HashMap<String,Integer>();
    	Iterator itr = slApprovalReasons.iterator();
    	String strRange=DomainConstants.EMPTY_STRING;
			while(itr.hasNext()){
			strRange=(String)itr.next();
				if(!strRange.isEmpty()){
					mCounter.put(strRange, 0);
				}
			}
    		//now get all approval template with
		
    	MapList mlApprovalTemplates= domSOC.getRelatedObjects(context, // matrix context
			    	RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, // relationship pattern
			    	DomainConstants.TYPE_ROUTE_TEMPLATE, // type pattern // Approval Template type
			    	strListBusSelects, // object selects
			    	strListRelSelects, // relationship selects
			    	false, // to direction
			    	true, // from direction
			    	(short) 1, // recursion level
			    	DomainConstants.EMPTY_STRING, // object where clause
			    	DomainConstants.EMPTY_STRING, // relationship where clause
			    	0);
			if(mlApprovalTemplates.size()==0) {
				String strMessage = DomainConstants.EMPTY_STRING;
				for(int i=0;i<slApprovalReasons.size();i++){
					strMessage = strMessage + "\n" +String.valueOf(i+1)+" "+(String)slApprovalReasons.get(i);
					
				}
        	   emxContextUtil_mxJPO.mqlNotice(context, "No Approval Templates are added,Please add approval Templates for below purpose"+strMessage );
        	   return 1;
			}else {	
		    	Iterator<Map> itrApprovalTemplate = mlApprovalTemplates.iterator();
		    	String strPurpose=DomainConstants.EMPTY_STRING;
		    	String strName=DomainConstants.EMPTY_STRING;
		    	while(itrApprovalTemplate.hasNext()){
			    	Map m=itrApprovalTemplate.next();
			    	strPurpose = (String)m.get("attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"]");
			    	strName = (String)m.get(DomainConstants.SELECT_NAME);
			    	if(strPurpose.isEmpty()){
						emxContextUtil_mxJPO.mqlNotice(context, STR_ERROR_MSG_EMPTY+" "+strName);
						return 1; 
			    	}
			    	// Start counting...
			    	int iCount = mCounter.get(strPurpose);
			    	mCounter.put(strPurpose, iCount+1);
			    	
		    	}
		    	java.util.Set keys = mCounter.keySet();
		    	Iterator itrKeys = keys.iterator();
		    	while(itrKeys.hasNext()){
				    	strName=(String)itrKeys.next();
				    	int i =mCounter.get(strName);
				    	if(i==0){
				    	     emxContextUtil_mxJPO.mqlNotice(context, "Approval Template with Purpose "+strName+" is not added");
				    	return 1; 
				    	}
		       	}
     }
    	}catch(Exception e){
    		throw e;
    	}
    	return 0;
    }
	@ProgramCallable
		  public String SocServicesAttribute(Context context, String[] args) throws Exception
	  {	
		HashMap programMap = (HashMap) JPO.unpackArgs(args);  
		 String objectId    = (String)programMap.get("objectId");
		DomainObject doObj = new DomainObject(objectId);
          	String SocServices = doObj.getInfo(context,"attribute[WMSSOCServicesIncluded");
		  if(SocServices.equals("TRUE"))
		  {
			return "Yes";
			}
			return "No";
}
@ProgramCallable
		  public String SocWorksAttribute(Context context, String[] args) throws Exception
	  {
HashMap programMap = (HashMap) JPO.unpackArgs(args); 	
 String objectId    = (String)programMap.get("objectId");
		DomainObject doObj = new DomainObject(objectId);
          	String SocWorks = doObj.getInfo(context,"attribute[WMSSOCWorksIncluded");
		  if(SocWorks.equals("TRUE"))
		  {
			return "Yes";
			}
			return "No"; 
		}
		  
@ProgramCallable
		  public String SocEquipmentsAttribute(Context context, String[] args) throws Exception
	  {	
HashMap programMap = (HashMap) JPO.unpackArgs(args); 
		 String objectId    = (String)programMap.get("objectId");
		DomainObject doObj = new DomainObject(objectId);
		//System.out.println("The object id" +objectId);
          	String SocEquipments = doObj.getInfo(context,"attribute[WMSSOCEquipmentsIncluded");
	//System.out.println("The attribute ---"+SocEquipments);
		  if(SocEquipments.equals("TRUE"))
		  {
			return "Yes";
		}
			return "No"; 
}
		

	
	

	/**
	 * Checks if all the AEs are approved
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int checkAllconnectedAEApproved(Context context, String[] args)throws Exception {

		try {
			String sObjectId = args[0];
			DomainObject doSOCObj = new DomainObject(sObjectId);
			StringList slAEItemState = doSOCObj.getInfoList(context, "from["+RELATIONSHIP_WMSSOC_AEMASTER+"].to.current");
			if(slAEItemState.size()==0) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.AE.NOAEConnected");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			if(slAEItemState.contains("Create")||slAEItemState.contains("Review")) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.AE.NotInApprovedState");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			
			String strBusWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\" || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
			MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strBusWhere);
			
			if(mlExtRoutes.size()==0){
				
				String strRouteExist = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from[Object Route|attribute[Route Base State]==state_AE].to.current dump");
				if("Complete".equals(strRouteExist)){
					return 0;
				}else{				
					String strMessage = "Please add Route and then proceed";
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
			}
			//String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"Admin Approval\"";
			//MapList routeMapList= doSOCObj.getRelatedObjects(context, RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 0, "", "", null);
			//if(routeMapList.size()==0){
			//	String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.AdminApproval.TemplateNotConnected");
			//	
			//	emxContextUtil_mxJPO.mqlNotice(context,strMessage);
			//	return 1;
			//}
			//if(routeMapList.size()>1){
			//
			//	String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.AdminApproval.TemplateNotConnected");
			//	emxContextUtil_mxJPO.mqlNotice(context,strMessage);
			//	return 1;
			//}
			return 0;
			
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}

	/**
	 * Creates the route between the AE to AdminApproval state.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int createRouteOnPromoteOfAEToAdminApproval(Context context, String[] args)throws Exception {

		try {
			String sObjectId = args[0];
			DomainObject doSOCObj = null;
			String strTemplateId ="";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				doSOCObj = new DomainObject(sObjectId);
				
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);
					ContextUtil.pushContext(context);
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
					ContextUtil.popContext(context);
				} else {
					
					String strPolicy = (String)doSOCObj.getInfo(context,DomainConstants.SELECT_POLICY);
					String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"AE Approval\"";
					MapList routeMapList= doSOCObj.getRelatedObjects(context, RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
					if(routeMapList != null && routeMapList.isEmpty() == false){
						Map mRouteTemplateMap = (Map)routeMapList.get(0);
						strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
						String sRouteDescription = (String)doSOCObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
						String sState = (String)doSOCObj.getInfo(context, DomainConstants.SELECT_CURRENT);
						String sApprovalTemplateId = strTemplateId;
						String strContectUser =  context.getUser();
						Map mRouteAttrib= new HashMap();
						mRouteAttrib.put("Route Completion Action", "Promote Connected Object");

						Map objectRouteAttributeMap=new HashMap(); 
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy,false ));
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_AE");
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,"Review");
						Map reviewerInfo= new HashMap();
						ContextUtil.pushContext(context);
						Route route = Route.createAndStartRouteFromTemplateAndReviewers(context,
								sApprovalTemplateId,
								sRouteDescription,
								strContectUser , 
								sObjectId,
								POLICY_WMSSOC,
								"AdminApproval", 
								mRouteAttrib,
								objectRouteAttributeMap, 
								reviewerInfo,
								true);
						String strStatus = route.getAttributeValue(context, DomainConstants.ATTRIBUTE_ROUTE_STATUS);
						if(strStatus.equalsIgnoreCase("Not Started")) {
							route.promote(context);
						}
						ContextUtil.popContext(context);
					}
				}
			}
			return 0;

		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}
	
	
	/**
	 * Creates the route between the AE to AdminApproval state.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int checkAdminApprovalValues (Context context, String[] args)throws Exception {

		try {
			String sObjectId = args[0];
			DomainObject doSOCObj = null;
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doSOCObj = new DomainObject(sObjectId);
				
				StringList slAEItemState = doSOCObj.getInfoList(context, "from["+RELATIONSHIP_WMSSOC_APPROVEDAEMASTER+"].to.current");
				if(slAEItemState.size()==0) {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.AE.NOAEConnected");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
				if(slAEItemState.contains("Create")||slAEItemState.contains("Review")) {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.ApprovedAE.NotInApprovedState");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
				String strAtributeValue = (String)doSOCObj.getInfo(context,"from["+RELATIONSHIP_WMSSOCADMINAPPROVAL+"].to.attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"].value");
				if(UIUtil.isNullOrEmpty(strAtributeValue)) {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.AdminApprovalAmountNotEntered");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
			}
			//check for approval template
			//String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"Delegation\"";
			//MapList routeMapList= doSOCObj.getRelatedObjects(context, RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 0, "", "", null);
			//if(routeMapList.size()==0){
			//	String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Delegation.NoTemplate");
			//	emxContextUtil_mxJPO.mqlNotice(context,strMessage);
			//	return 1;
			//}
			//if(routeMapList.size()>1){
			//	String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Delegation.MultiTemplate");
			//	emxContextUtil_mxJPO.mqlNotice(context,strMessage);
			//	return 1;
			//}
			
			//checking for approved adminApproval
			String sWhere = "revision == last";
			StringList selects = new StringList(1);
            selects.add(DomainConstants.SELECT_ID);
            selects.add(DomainConstants.SELECT_CURRENT);
            MapList AAList = doSOCObj.getRelatedObjects(context,RELATIONSHIP_WMSSOCADMINAPPROVAL, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
            if(AAList.isEmpty()) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.AdminApproval.NotConnected");
                emxContextUtil_mxJPO.mqlNotice(context,strMessage);               
            } else if(AAList.size()>0) {
                Map mAA = (Map)AAList.get(0);
                String strCurrentState = (String) mAA.get(DomainConstants.SELECT_CURRENT);
                if(!"Approved".equals(strCurrentState)) {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.AdminApproval.NotApproved");
                    emxContextUtil_mxJPO.mqlNotice(context,strMessage);
                    return 1;
                }
                   
            }
            return 0;
		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}

	/**
	 * checks the demote access.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int checkDemoteAccess (Context context, String[] args)throws Exception {

		try {
			String sObjectId = args[0];
			DomainObject doSOCObj = null;
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doSOCObj = new DomainObject(sObjectId);
				String strOwner = (String)doSOCObj.getInfo(context,DomainConstants.SELECT_OWNER);
				if(strOwner.equals(context.getUser())) {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.SOC.NoDemoteAccess");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
			}
			return 0;

		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}
	
	/**
	 * Returns documents
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public Object getDocuments(Context context, String[] args)
			throws Exception
	{
		try
		{
			HashMap programMap        = (HashMap) JPO.unpackArgs(args);
			String  parentId          = (String) programMap.get("objectId");
			String  parentRel         = (String) programMap.get("parentRelName");
			if(UIUtil.isNullOrEmpty(parentRel))
				parentRel = PropertyUtil.getSchemaProperty(context, CommonDocument.SYMBOLIC_relationship_ReferenceDocument);
			DomainObject masterObject = new DomainObject(parentId);
			StringList relSelects = new StringList(1);
			relSelects.add(CommonDocument.SELECT_RELATIONSHIP_ID);
			StringList slObjectSelect = new StringList();
			slObjectSelect.add(DomainObject.SELECT_ID);
			slObjectSelect.add(DomainObject.SELECT_NAME);
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			MapList mlDocList = masterObject.getRelatedObjects(context, // matrix context
					parentRel, // relationship pattern
					"*", // type pattern
					slObjectSelect, // object selects
					slRelSelect, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					"", // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
			return mlDocList;
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	 * Access to Project members only
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public boolean CheckForProjectMember(Context context ,String[] args) throws Exception{
		try {
			String strContextId = args[0];
			String strType      = args[1];
			String strProjectId = DomainConstants.EMPTY_STRING;
			MapList routeMembersOFSOC = new MapList();
			
			StringList strSO1PlanningUser= getSO1Planning(context);
			if((strSO1PlanningUser).contains(context.getUser()))
				return true;
			
			if(strType.equalsIgnoreCase(TYPE_WMSSOC)){
				String strRel = RELATIONSHIP_WMSPROJECTSOC;
				DomainObject dom=DomainObject.newInstance(context, strContextId);
				routeMembersOFSOC = getRouteMembersConnectedToSOC(context, strContextId);
				String sOwner = (String) dom.getInfo(context, DomainConstants.SELECT_OWNER);
				if(sOwner.equalsIgnoreCase(context.getUser())) {
					return true;
				}
				strProjectId = dom.getInfo(context, "to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
				
			}
			//Finding Project Members.
			ProjectSpace project = new ProjectSpace(strProjectId);
			
			MapList mlExternalMembers = project.getProjectTaskAssignees(context, strProjectId);
			
			MapList mlMemberList = getProjectMembers(context, strProjectId);
			if(mlExternalMembers.size()>0)
				mlMemberList.addAll(mlExternalMembers);
			if(routeMembersOFSOC.size()>0)
				mlMemberList.addAll(routeMembersOFSOC);
			StringList slUsers = getUniqueUsersFromMapList(mlMemberList);
			if(slUsers.contains(context.getUser()))
				return true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;

	}
	/**
	 * Returns the uniques users from MapList
	 * @param mlMemberList
	 * @return
	 */
	private static StringList getUniqueUsersFromMapList(MapList mlMemberList) {
		StringList slUsers = new StringList();
		String strUserName = DomainConstants.EMPTY_STRING;
		Map mTemp = null;
		for(int i=0;i<mlMemberList.size();i++){
			mTemp = (Map)mlMemberList.get(i);
			strUserName = (String)mTemp.get(DomainObject.SELECT_NAME);
			if(slUsers.contains(strUserName) == false){
				slUsers.add(strUserName);
			}
		}
		return slUsers;
	}
	/**
	 * Returns Project members
	 * @param context
	 * @param strProjectId
	 * @return
	 * @throws FrameworkException
	 */
	private static MapList getProjectMembers(Context context, String strProjectId) throws FrameworkException {
		DomainObject projectDomainObject = DomainObject.newInstance(context,strProjectId); 
		StringList slObjSelect = new StringList();
		slObjSelect.add(DomainObject.SELECT_ID);
		slObjSelect.add(DomainObject.SELECT_NAME);
		StringList slRelSelect = new StringList();
		slRelSelect.add(DomainRelationship.SELECT_ID);
		MapList mlMemberList = 	projectDomainObject.getRelatedObjects(context, // matrix context
				"Member", // relationship pattern
				DomainConstants.TYPE_PERSON, // type pattern
				slObjSelect, // object selects
				slRelSelect, // relationship selects
				true, // to direction
				true, // from direction
				(short) 1, // recursion level
				"", // object where clause
				DomainConstants.EMPTY_STRING, // relationship where clause
				0);
		return mlMemberList;
	}
	
	/**
	 * Method for returning the members of the connected Routes.
	 * @param context
	 * @param strContextId
	 * @return
	 * @throws FrameworkException
	 */
	private static MapList getRouteMembersConnectedToSOC(Context context, String strContextId) throws FrameworkException {
		MapList allRouteMebers= new MapList();
		DomainObject socObject = DomainObject.newInstance(context, strContextId);
		StringList slRouteTemplates = socObject.getInfoList(context, "from[WMSSOCApprovalTemplate].to.id");
		SelectList selectables = new SelectList(10);
		selectables.addElement(DomainConstants.SELECT_ID);
		selectables.addElement(DomainConstants.SELECT_NAME);

		for( String strRouteId:slRouteTemplates){
			Route routeBO = (Route)DomainObject.newInstance(context,DomainConstants.TYPE_ROUTE);
			routeBO.setId(strRouteId);
			String typePattern = DomainConstants.TYPE_PERSON + "," + DomainConstants.TYPE_ROUTE_TASK_USER;
			SelectList selectPersonRelStmts = new SelectList(2);
			selectPersonRelStmts.addElement(routeBO.SELECT_RELATIONSHIP_ID);
			selectPersonRelStmts.addElement(routeBO.SELECT_ROUTE_TASK_USER);
			MapList memberList = routeBO.getRelatedObjects(context, 
					DomainConstants.RELATIONSHIP_ROUTE_NODE, typePattern,
					selectables, selectPersonRelStmts,
					false, true, (short)1, 
					DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING,
					0);
			allRouteMebers.addAll(memberList);
		}
		return allRouteMebers;
	}
	
	/**
	 * Finds SO1 planning
	 * @param context
	 * @return
	 * @throws FrameworkException
	 */
	public static StringList getSO1Planning(Context context) throws FrameworkException{
		StringList SO1PlanningPersonList = new StringList();
		String SO1PlanningPerson = "";
		String whereExpression = "attribute["+ATTRIBUTE_HOST_ROLE+"] == \"SO1 Planning\" && current==Active";
		StringList objectSelects =  new StringList();
		objectSelects.add(DomainConstants.SELECT_NAME);
		objectSelects.add(DomainConstants.SELECT_ID);
		Map m = new HashMap();
		MapList personMList = DomainObject.findObjects(context,DomainConstants.TYPE_PERSON,"*",whereExpression,objectSelects);
		if(personMList != null && personMList.size() >0)
		{
			for( int i= 0 ; i< personMList.size(); i++){
			Map m1 = (Map) personMList.get(i);
			SO1PlanningPerson = (String)m1.get(DomainConstants.SELECT_NAME);
			if(UIUtil.isNotNullAndNotEmpty(SO1PlanningPerson))
				SO1PlanningPersonList.add(SO1PlanningPerson);
			}
		}
		return SO1PlanningPersonList;
	}
	
	
	
	
	/**
	 * Sends email to the members
	 * @param context
	 * @param objectId
	 * @param strUser
	 * @param strHeading
	 * @param strMessage
	 * @throws Exception
	 */
	
	public static void sendNotification(Context context, String objectId, String strUser, String strHeading, String strMessage,StringList slTOList) throws Exception {
		try {
			StringBuilder sbMessage = new StringBuilder();
			sbMessage.append(strHeading);
			StringBuilder sbBody = new StringBuilder();
			sbBody.append("Hi,");
			sbBody.append("\n \n ");
			sbBody.append(strMessage);
			sbBody.append("\n");
			sbBody.append("\n \n Regards, \n ").append(strUser);
			sbBody.append("\n \n Note: This is system generate mail. Please do not reply to the same.");
			String notifyType = "IconMail";
			StringList objectIdLists = new StringList(1);
			objectIdLists.add(objectId);
			emxNotificationUtilBase_mxJPO.sendJavaMail(context, slTOList, null, null, sbMessage.toString(),
					sbBody.toString(), sbBody.toString(), strUser, null, objectIdLists, notifyType);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	/**
	 * Creates the route between the RIC to Listing of Project state.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public String createRouteBetRICToListingOfProject(Context context, String[] args)throws Exception {
		try {
			
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId = (String)programMap.get("objectId");
			DomainObject doSOCObj = null;
			String strTemplateId ="";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doSOCObj = new DomainObject(sObjectId);
				
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);
					ContextUtil.pushContext(context);
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						//
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
					ContextUtil.popContext(context);
				} else {
				
				String strPolicy = (String)doSOCObj.getInfo(context,DomainConstants.SELECT_POLICY);
				String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"RIC Approval\"";
				MapList routeMapList= doSOCObj.getRelatedObjects(context, RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
					
				if(routeMapList != null && routeMapList.isEmpty() == false){
					Map mRouteTemplateMap = (Map)routeMapList.get(0);
					strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
					String sRouteDescription = (String)doSOCObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
					String sState = (String)doSOCObj.getInfo(context, DomainConstants.SELECT_CURRENT);
					String sApprovalTemplateId = strTemplateId;
					String strContectUser =  context.getUser();
					Map mRouteAttrib= new HashMap();
					mRouteAttrib.put("Route Completion Action", "Promote Connected Object");

					Map objectRouteAttributeMap=new HashMap(); 
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy,false ));
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_RIC");
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,"Review");
					Map reviewerInfo= new HashMap();
					ContextUtil.pushContext(context);
					Route route = Route.createAndStartRouteFromTemplateAndReviewers(context,
							sApprovalTemplateId,
							sRouteDescription,
							strContectUser , 
							sObjectId,
							POLICY_WMSSOC,
							"ListingOfProjects", 
							mRouteAttrib,
							objectRouteAttributeMap, 
							reviewerInfo,
							true);
					String strStatus = route.getAttributeValue(context, DomainConstants.ATTRIBUTE_ROUTE_STATUS);
					if(strStatus.equalsIgnoreCase("Not Started")) {
						route.promote(context);
					} 
					ContextUtil.popContext(context);
				}	
				}
			}
			return "0";

		}
		catch (Exception e) {
			e.printStackTrace();
			return "1";
		}
	}	
	/**
	 * Access function for the SO1 Planning user.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public static Boolean isNotSO1Planning (Context context, String[] args) throws Exception {
		boolean returnVal = true;
		StringList SO1PlanningUser = getSO1Planning(context);
		if(SO1PlanningUser.contains(context.getUser()))
				returnVal = false;
		return returnVal;
	}
	/**
	 * Disable command once route is started
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public static Boolean disableIfActiveRouteFound(Context context, String[] args) throws Exception {
		boolean returnVal = true;
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String sObjectId = (String)programMap.get("objectId");
		if(UIUtil.isNotNullAndNotEmpty(sObjectId))
		{
			DomainObject doObject = new DomainObject(sObjectId);
			String mqlQuery = "print bus "+sObjectId+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
			String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
			if(UIUtil.isNotNullAndNotEmpty(strRouteId)) {
				returnVal = false;
			}
		}
		return returnVal;
	}
	
	/**
	* Method to get Related Import History information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getSystemReferenceDocuments(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList(2);
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			StringList relSelects = new StringList(1);
            relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlSystemDocuments = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_SYSTEMREFERENCEDOCUMENT, // relationship pattern
													DomainConstants.QUERY_WILDCARD, // type pattern
													busSelects, // object selects
													relSelects, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
													
			mlSystemDocuments.sort(DomainConstants.SELECT_ORIGINATED, "descending", "date");
			return mlSystemDocuments;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
	/**
	 * Access to SO1 planning in create state when the SOC is submitted
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public static Boolean CheckForSOCSubmittedAttribute(Context context ,String[] args) throws Exception{
		try {
			StringList SO1PlanningUser = getSO1Planning(context);
			if(SO1PlanningUser.contains(context.getUser())){
				String strContextId = args[0];
				DomainObject dom = DomainObject.newInstance(context, strContextId);
				String isSOCSubmitted = dom.getInfo(context, "attribute["+ATTRIBUTE_WMSSOC_SUBMITTED+"].value");
				if("Yes".equals(isSOCSubmitted))
					return true;
			}
		}catch (Exception exception) {
		}
		return false;
	}
	
	/**
	 * Set the value of the attribute the SOC is submitted and send the notification email
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	
	public int setSOCAttribute(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId);
			String strUser = context.getUser();
			String strMessageHeading = EnoviaResourceBundle.getProperty(context,
					"wmsStringResource", context.getLocale(), "WMS.SOC.Message.SubmitSOC.Heading");
			String strMessageBody = EnoviaResourceBundle.getProperty(context,
					"wmsStringResource", context.getLocale(), "WMS.SOC.Message.SubmitSOC.Body");
			String strTitle = doObj.getAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE);
			String strMessage = strUser +" "+ strMessageBody + " " + strTitle;
			String strHeading = strUser + " "+ strMessageHeading + " " + strTitle;
			StringList slTOList = new StringList();
			slTOList.addAll(getSO1Planning(context));
			sendNotification(context,sObjectId,strUser,strHeading,strMessage,slTOList);
			ContextUtil.pushContext(context);			
			doObj.setAttributeValue(context,ATTRIBUTE_WMSSOC_SUBMITTED,"Yes");
			ContextUtil.popContext(context);
		}catch(Exception exception) {
			throw exception;
		}
		return 0;
	}
	
	/**
	 *  Trigger to check the delegation objects
	 * @param context
	 * @param args includes id
	 * @return meassge in case there is any issue. 
	 * @throws Exception
	 */
	public static int checkSOCForDelegation(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doObject = new DomainObject(sObjectId);
			StringList selects = new StringList(1);
			selects.add(DomainConstants.SELECT_ID);
			selects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision == last";
			MapList delegationList = doObject.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
			String strMessage = DomainConstants.EMPTY_STRING;
			if(getSO1Planning(context).contains(context.getUser())==false) {
				strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.SOC.OnlySO1PlanningCanMoveObjectInNextState");
				emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				return 1;
			}else if(delegationList.isEmpty()) {
				strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.SOC.NoDelgationObjectAttachedToSOC");
				emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				return 1;
			} else if(delegationList.size()>0) {
				Map mDelegate = (Map)delegationList.get(0);
				String strCurrentState = (String) mDelegate.get(DomainConstants.SELECT_CURRENT);
				if(!"Delegate".equals(strCurrentState)) {
					strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.SOC.LatestDelegationNotApproved");
					emxContextUtil_mxJPO.mqlNotice(context, strMessage);
					return 1;
				}
					
			}
			return 0;
		} catch(Exception ex) {
			ex.printStackTrace();
			return 1;
		}
	}
	/**
	 * Notification email to all the project member and task owners
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public static int notifyAllProjectMembersTaskAssignes(Context context, String[] args)throws Exception {
		int iResult = 0;
		try {
			String sObjectId = args[0];
			String sFromState = args[1];
			String sToState = args[2];
			DomainObject doObject = new DomainObject(sObjectId);
			String sProjectId = doObject.getInfo(context, "to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
			String strTitle = doObject.getAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE);
			
			String strMessageHeading = EnoviaResourceBundle.getProperty(context,
					"wmsStringResource", context.getLocale(), "WMS.SOC.Message.SOC.promoted.Heading");
			String strMessageBody = EnoviaResourceBundle.getProperty(context,
					"wmsStringResource", context.getLocale(), "WMS.SOC.Message.SOC.promoted.Body");
			String sOwner = (String) doObject.getInfo(context, DomainConstants.SELECT_OWNER);
			
			StringList slTOList = extractRouteAndProjectMembers(context, sObjectId, sProjectId);
			slTOList.add(sOwner);
			slTOList.addAll(getSO1Planning(context));
			String strMessage = strTitle+ ": " + strMessageBody +  " " +sFromState + " To " + sToState;
			String strHeading = strTitle+ ": " + strMessageHeading + " " +sFromState + " To " + sToState;
			sendNotification(context,sObjectId,context.getUser(),strHeading,strMessage,slTOList);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return iResult;
	}
	/**
	 * Wrapper for the jsp
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception 
	 * @throws MatrixException 
	 * @throws FrameworkException 
	 */
	public static StringList extractRouteAndProjectMembers(Context context, String[] args) throws FrameworkException, MatrixException, Exception {
		Map programMap =  JPO.unpackArgs(args);
		String sObjectId = (String)programMap.get("sObjectId");
		String sProjectId = (String)programMap.get("sProjectId");
		return extractRouteAndProjectMembers(context,sObjectId,sProjectId);
	}
	
	/**
	 * @param context
	 * @param sObjectId SOC id
	 * @param sProjectId project Id to which SOC is attached.
	 * @return
	 * @throws FrameworkException
	 * @throws Exception
	 * @throws MatrixException
	 */
	public static StringList extractRouteAndProjectMembers(Context context, String sObjectId, String sProjectId)
			throws FrameworkException, Exception, MatrixException {
		MapList routeMembersOFSOC = getRouteMembersConnectedToSOC(context, sObjectId);
		ProjectSpace project = new ProjectSpace(sProjectId);
		MapList mlExternalMembers = project.getProjectTaskAssignees(context, sProjectId);
		MapList mlMemberList = getProjectMembers(context, sProjectId);
		if(mlExternalMembers.size()>0)
			mlMemberList.addAll(mlExternalMembers);
		if(routeMembersOFSOC.size()>0)
			mlMemberList.addAll(routeMembersOFSOC);
		
		StringList slTOList = getUniqueUsersFromMapList(mlMemberList);
		return slTOList;
	}
	/**
	 * extract parameters sent from jsp and calls the util method.
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@com.matrixone.apps.framework.ui.PostProcessCallable	
	public void sendNotificationFromJSP(Context context,String[] args) throws Exception
	{
		try {
			Map mInputMap = (Map) JPO.unpackArgs(args);
			String sObjectId = (String)mInputMap.get("sObjectId");
			String strHeading = (String)mInputMap.get("strHeading");
			String strMessage = (String)mInputMap.get("strMessage");
			StringList slTOList = (StringList)mInputMap.get("slTOList");
			sendNotification(context,sObjectId,context.getUser(),strHeading,strMessage,slTOList);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Send the notification email for the discussion
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	
	public int sendDiscussionNotification(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			String strUser = context.getUser();
			DomainObject doMessageObject = new DomainObject(sObjectId);
			String messageSubject = doMessageObject.getInfo(context,"attribute[" + DomainConstants.ATTRIBUTE_SUBJECT + "].value");
			boolean isReply = false;
			String strMessage = DomainConstants.EMPTY_STRING;
			String strHeading= DomainConstants.EMPTY_STRING;
			String sThreadId = doMessageObject.getInfo(context, "to["+DomainConstants.RELATIONSHIP_MESSAGE+"].from.id");
			if(UIUtil.isNullOrEmpty(sThreadId)) {
				String sReplyToMessageId = doMessageObject.getInfo(context, "to["+DomainConstants.RELATIONSHIP_REPLY+"].from.id");
				if(UIUtil.isNotNullAndNotEmpty(sReplyToMessageId)) {
					isReply = true;
					DomainObject doMainMessageObject = new DomainObject(sReplyToMessageId);
					sThreadId = doMainMessageObject.getInfo(context, "to["+DomainConstants.RELATIONSHIP_MESSAGE+"].from.id");
				}
			}
			if(UIUtil.isNotNullAndNotEmpty(sThreadId)) {
				DomainObject doThreadObject = new DomainObject(sThreadId);
				StringList threadInfoList = new StringList(); 
				threadInfoList.add("to["+DomainConstants.RELATIONSHIP_THREAD+"].from.id");
				threadInfoList.add("to["+DomainConstants.RELATIONSHIP_THREAD+"].from.type");
				threadInfoList.add("to["+DomainConstants.RELATIONSHIP_THREAD+"].from.current");
				threadInfoList.add("to["+DomainConstants.RELATIONSHIP_THREAD+"].from.owner");
				Map threadInfoMap = doThreadObject.getInfo(context, threadInfoList);
				if(threadInfoMap.size()>0) {
					String masterType = (String)threadInfoMap.get("to["+DomainConstants.RELATIONSHIP_THREAD+"].from.type");
					if("WMSSOC".equals(masterType)) {
						Map mpMessage = getMessage(context, strUser,isReply);
						strMessage = messageSubject + " " + (String) mpMessage.get("Message");
						strHeading = messageSubject + " " + (String) mpMessage.get("Heading");
						String strObjectId = (String)threadInfoMap.get("to["+DomainConstants.RELATIONSHIP_THREAD+"].from.id");
						StringList slTOList = new StringList();
						String masterObjState = (String)threadInfoMap.get("to["+DomainConstants.RELATIONSHIP_THREAD+"].from.current");
						if("RIC".equals(masterObjState) || "ListingOfProjects".equals(masterObjState) || "AE".equals(masterObjState) || 
								"AdminApproval".equals(masterObjState) || "Delegation".equals(masterObjState) || "UnderExecution".equals(masterObjState)) {
							DomainObject doSOCObject = new DomainObject(strObjectId);
							String strProjectId = doSOCObject.getInfo(context, "to["+RELATIONSHIP_WMSPROJECTSOC+"].from.id");
							slTOList = (StringList)extractRouteAndProjectMembers(context,strObjectId,strProjectId);
							sendNotification(context,strObjectId,strUser,strHeading,strMessage,slTOList);
						}else if(masterObjState=="Submit") {
							slTOList.addAll(getSO1Planning(context));
							String masterObjOwner = (String)threadInfoMap.get("to["+DomainConstants.RELATIONSHIP_THREAD+"].from.owner");
							slTOList.add(masterObjOwner);
							sendNotification(context,strObjectId,strUser,strHeading,strMessage,slTOList);
						} else {
							String masterObjOwner = (String)threadInfoMap.get("to["+DomainConstants.RELATIONSHIP_THREAD+"].from.owner");
							slTOList.add(masterObjOwner);
							sendNotification(context,strObjectId,strUser,strHeading,strMessage,slTOList);
						}
					}
				}
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	/**
	 * Returns proper message to the user for reply and the discussion
	 * @param context
	 * @param strUser
	 * @param isReply
	 * @return
	 */
	private Map getMessage(Context context, String strUser,boolean isReply) {
		Map returnMap = new HashMap();
		String strMessage = DomainConstants.EMPTY_STRING;
		String strHeading = DomainConstants.EMPTY_STRING;
		if(isReply) {
			strHeading = EnoviaResourceBundle.getProperty(context,
					"wmsStringResource", context.getLocale(), "WMS.SOC.Message.Heading.ReplyCreation") + " " + strUser; 
			strMessage =  EnoviaResourceBundle.getProperty(context,
					"wmsStringResource", context.getLocale(), "WMS.SOC.Message.Message.ReplyCreation") + " " + strUser; 

		}else {
			strHeading = EnoviaResourceBundle.getProperty(context,
					"wmsStringResource", context.getLocale(), "WMS.SOC.Message.Heading.DiscussionsCreation") + " " + strUser; 
			strMessage =  EnoviaResourceBundle.getProperty(context,
					"wmsStringResource", context.getLocale(), "WMS.SOC.Message.Message.DiscussionsCreation") + " " + strUser;
		}
		returnMap.put("Heading",strHeading);
		returnMap.put("Message",strMessage);
		return returnMap;
	}
	/**
	 * Access to commands for SO1 planning in submit state when the SOC is sent for more info by 
	 * people of works
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public static Boolean showOnlyToSO1Planning(Context context ,String[] args) throws Exception{
		boolean returnVal = false;
		StringList SO1PlanningUser = getSO1Planning(context);
		if(SO1PlanningUser.contains(context.getUser()))
				returnVal = true;
		return returnVal;			
	}
	public int createRouteBetCreateToSubmit(Context context, String[] args)throws Exception {

		try {
				HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId = (String)programMap.get("objectId");
			DomainObject doSOCObj = null;
			String strTemplateId ="";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doSOCObj = new DomainObject(sObjectId);
				
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
				//System.out.println("strRelWhereExist"+strRelWhereExist);
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strRelWhereExist);
				//System.out.println("mlExtRoutes"+mlExtRoutes);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);
					ContextUtil.pushContext(context);
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
					ContextUtil.popContext(context);
				} else {
					
					String strPolicy = (String)doSOCObj.getInfo(context,DomainConstants.SELECT_POLICY);
					//System.out.println("strPolicy"+strPolicy);
					String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"Submit SOC\"";
					//System.out.println("strRelWhere"+strRelWhere);
					MapList routeMapList= doSOCObj.getRelatedObjects(context, RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
					//System.out.println("routeMapList"+routeMapList);
					if(routeMapList != null && routeMapList.isEmpty() == false){
						Map mRouteTemplateMap = (Map)routeMapList.get(0);
						strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
						String sRouteDescription = (String)doSOCObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
						String sState = (String)doSOCObj.getInfo(context, DomainConstants.SELECT_CURRENT);
						String sApprovalTemplateId = strTemplateId;
						String strContectUser =  context.getUser();
						Map mRouteAttrib= new HashMap();
						mRouteAttrib.put("Route Completion Action", "Promote Connected Object");

						Map objectRouteAttributeMap=new HashMap(); 
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy,false ));
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Create");
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,"Review");
						Map reviewerInfo= new HashMap();
						ContextUtil.pushContext(context);
						Route route = Route.createAndStartRouteFromTemplateAndReviewers(context,
								sApprovalTemplateId,
								sRouteDescription,
								strContectUser , 
								sObjectId,
								POLICY_WMSSOC,
								"Submit", 
								mRouteAttrib,
								objectRouteAttributeMap, 
								reviewerInfo,
								true);
						String strStatus = route.getAttributeValue(context, DomainConstants.ATTRIBUTE_ROUTE_STATUS);
						if(strStatus.equalsIgnoreCase("Not Started")) {
							route.promote(context);
						}
						ContextUtil.popContext(context);
					}
				}
			}
			return 0;

		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}
	
	public int startRouteBetCreatetoSubmit(Context context, String[] args) throws Exception
	{
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId = (String)programMap.get("objectId");
			DomainObject doSOCObj = null;
			String strTemplateId ="";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doSOCObj = new DomainObject(sObjectId);
				StringList slDomSels = new StringList();
				slDomSels.add("policy");
				slDomSels.add("current");

				Map mDomValues = (Map)doSOCObj.getInfo(context, slDomSels);

				Map relMap = new HashMap();
				relMap.put("Route Base Policy", "policy_"+(String)mDomValues.get("policy"));
				relMap.put("Route Base State", "state_"+(String)mDomValues.get("current"));
				relMap.put("Route Base Purpose", "Review");
				
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"  || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);
					ContextUtil.pushContext(context);
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						String RelIDRoute = (String)mRoute.get(DomainRelationship.SELECT_ID);
						DomainRelationship drelObjectRoute = new DomainRelationship(RelIDRoute);
						
						drelObjectRoute.setAttributeValues(context, relMap);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
					ContextUtil.popContext(context);
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
		return 0;
	}


	public int startRouteBetRICtoListingOfProjects(Context context, String[] args) throws Exception
	{
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId = (String)programMap.get("objectId");
			DomainObject doSOCObj = null;
			String strTemplateId ="";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doSOCObj = new DomainObject(sObjectId);
				StringList slDomSels = new StringList();
				slDomSels.add("policy");
				slDomSels.add("current");

				Map mDomValues = (Map)doSOCObj.getInfo(context, slDomSels);

				Map relMap = new HashMap();
				relMap.put("Route Base Policy", "policy_"+(String)mDomValues.get("policy"));
				relMap.put("Route Base State", "state_"+(String)mDomValues.get("current"));
				relMap.put("Route Base Purpose", "Review");
				
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\" || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);
					ContextUtil.pushContext(context);
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						String RelIDRoute = (String)mRoute.get(DomainRelationship.SELECT_ID);
						DomainRelationship drelObjectRoute = new DomainRelationship(RelIDRoute);
						
						drelObjectRoute.setAttributeValues(context, relMap);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
					ContextUtil.popContext(context);
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
		return 0;
	}

	public int startRouteBetListingOfProjectsToBP(Context context, String[] args) throws Exception
	{
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId = (String)programMap.get("objectId");
			DomainObject doSOCObj = null;
			String strTemplateId ="";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doSOCObj = new DomainObject(sObjectId);
				StringList slDomSels = new StringList();
				slDomSels.add("policy");
				slDomSels.add("current");

				Map mDomValues = (Map)doSOCObj.getInfo(context, slDomSels);

				Map relMap = new HashMap();
				relMap.put("Route Base Policy", "policy_"+(String)mDomValues.get("policy"));
				relMap.put("Route Base State", "state_"+(String)mDomValues.get("current"));
				relMap.put("Route Base Purpose", "Review");
				
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\" || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSOCObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);
					ContextUtil.pushContext(context);
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						String RelIDRoute = (String)mRoute.get(DomainRelationship.SELECT_ID);
						DomainRelationship drelObjectRoute = new DomainRelationship(RelIDRoute);
						
						drelObjectRoute.setAttributeValues(context, relMap);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
					ContextUtil.popContext(context);
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
		return 0;
	}
	
	public String displayAssociatedSOC(Context context,String [] args) throws Exception {
		StringBuilder sb=new StringBuilder();
		Map mInputMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) mInputMap.get("requestMap");
		String sProjectId = (String)requestMap.get("objectId");
		DomainObject domObject=new DomainObject(sProjectId);
		String sWhere = "revision == last";
		StringList selects = new StringList(1);
		selects.add(DomainConstants.SELECT_ID);
		
		String sSOCObjId = domObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
		String sSOCTitle = domObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.attribute[Title].value");
		if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)){
				String shref = "../common/emxTree.jsp";
				sb.append("<a href=\"javascript:showModalDialog('"+shref+"?objectId="+sSOCObjId+"','600','400','false');\" >");            
				sb.append(sSOCTitle);
				sb.append("</a>");
		}
		return sb.toString();
	}


	public String getMasterGE(Context context,String [] args) throws Exception {
		Map mInputMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) mInputMap.get("requestMap");
		String sProjectId = (String)requestMap.get("objectId");
		String strFullName = "";
		if(UIUtil.isNotNullAndNotEmpty(sProjectId)){
			
			DomainObject doProject = DomainObject.newInstance(context,sProjectId);
			
			StringList slBusSelect = new StringList();
			slBusSelect.add(DomainObject.SELECT_ID);
			slBusSelect.add(DomainObject.SELECT_NAME);
			slBusSelect.add("attribute[First Name]");
			slBusSelect.add("attribute[Last Name]");
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			slRelSelect.add("attribute[Project Role]");
			
			String strRelWhere = "attribute[Project Role]=='Master GE'";
			
			
			MapList mlMemberList = (MapList)doProject.getRelatedObjects(context, // matrix context
					"Member", // relationship pattern
                     "Person", // type pattern
                    slBusSelect, // object selects
                    slRelSelect, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 1, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    strRelWhere, // relationship where clause
                    0);
			Map mPersonMap = null;
			String strFirstName = "";
			String strLastName = "";
			
			if(mlMemberList.size()>0){
				mPersonMap = (Map)mlMemberList.get(0);
				if(mPersonMap !=null){
					strFirstName = (String)mPersonMap.get("attribute[First Name]");
					strLastName = (String)mPersonMap.get("attribute[Last Name]");
				}
				
				if(UIUtil.isNullOrEmpty(strFirstName)){
					strFirstName = "";
				}
				if(UIUtil.isNullOrEmpty(strLastName)){
					strLastName = "";
				}		
				
				strFullName = strFirstName + " "+ strLastName;
			}
				
		}
		return strFullName;
	}
	/**
	 * Notification email to all the project member and task owners
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int getCommentNotification(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			String NewValue = args[1];
			String AttributeName = args[2];
			DomainObject doObj = new DomainObject(sObjectId);
			String strPersonId = PersonUtil.getPersonObjectID(context,context.getUser());
			DomainObject doPerson = new DomainObject(strPersonId);
			StringList slSelect = new StringList();
				slSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
				slSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			Map mPersonInfo = doPerson.getInfo(context,slSelect);
				String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
				String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			StringList slOwner = doObj.getInfoList(context, DomainConstants.SELECT_OWNER);
			StringList slDes = doObj.getInfoList(context, DomainConstants.SELECT_DESCRIPTION);
			String sllog = (String)doObj.getInfo(context, "to[WMSActivityLogsComments].from.name");
			String strMessage = strLastName + " "+ NewValue + " " + slOwner;
			StringBuilder sbSubject = new StringBuilder();
			sbSubject.append(strFirstName).append(strLastName).append(" Has Created an Comment Please visit and Reply by clicking on below link");
			StringList slObjectIdList = new StringList(1);
			slObjectIdList.addElement(sObjectId);
				HashMap arg = new HashMap();
					arg.put("toList", new StringList(slOwner));
					arg.put("ccList", DomainConstants.EMPTY_STRINGLIST);
					arg.put("bccList", DomainConstants.EMPTY_STRINGLIST);
					arg.put("subject",sbSubject.toString());
					arg.put("messages",strMessage);
					arg.put("objectIdList",slObjectIdList);
					JPO.invoke(context, "emxMailUtil",null,"sendMessage",JPO.packArgs(arg),null);  
			
		}catch(Exception exception) {
			throw exception;
		}
		return 0;
	}
	
	 public void SendNotificationByTypecreate(Context context, String[] args) throws Exception 
     {
         try {
			String strObjectTYPE = (String)args[0];
			String strObjectId = (String)args[1];
			String strFromobjectid = (String)args[2];
			String strRelid = (String)args[3];
			String relWmsissuecomment = (String)args[4];
			StringList slMembers = new StringList();
			String slSubject =null;
			DomainObject doObj = new DomainObject(strObjectId);
			slMembers = doObj.getInfoList(context, "from[RELATIONSHIP_WMSISSUECOMMENT].to.name");
			slSubject = doObj.getInfo(context, "attribute[ATTRIBUTE_SUBJECT].value");
			
			
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 public String getSOCRouteField(Context context,String[] args) throws Exception {
		StringBuilder sb= null;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			String strCurrent = DomainConstants.EMPTY_STRING;
			String strObjId = DomainConstants.EMPTY_STRING;
			String strObjName = DomainConstants.EMPTY_STRING;
			MapList mlExtRoutes = null;
			String sWhere = DomainConstants.EMPTY_STRING;
			Map oMap = null;
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			DomainObject doObject = new DomainObject(sObjectId);
			strCurrent = doObject.getInfo(context, DomainConstants.SELECT_CURRENT);
			
			if ("Create".equals(strCurrent) || "RIC".equals(strCurrent) || "ListingOfProjects".equals(strCurrent) || "AE".equals(strCurrent)){
				sWhere = "current != Complete";
				mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
													DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
													DomainConstants.TYPE_ROUTE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
				sb = new StringBuilder();
				if (mlExtRoutes.size() == 1) {
					String strURL="../common/emxTree.jsp";
					oMap = (Map) mlExtRoutes.get(0);
					strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
					strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
					sb.append(strObjName);
					sb.append("</a>");
				} else if (mlExtRoutes.size() == 0) {
					String strURL="../wms/wmsRouteCreationDialogFS.jsp?wmsSearch=all";
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"%26objectId="+sObjectId+"','600','400','false');\" >");            
					//sb.append("<img border='0' title='Route' src='../common/images/iconSmallRoute.png' height='15px' name='Route' id='Route' alt='Route'/>");
					sb.append("Create Route");
					sb.append("</a>");
				}
			} else {
				mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
													DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
													DomainConstants.TYPE_ROUTE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
				mlExtRoutes.sort("originated", "descending", "date");
				sb = new StringBuilder();
				if (mlExtRoutes.size() > 0) {
					String strURL="../common/emxTree.jsp";
					oMap = (Map) mlExtRoutes.get(0);
					strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
					strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
					sb.append(strObjName);
					sb.append("</a>");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
}
