/** Name of the JPO     : WMSSupplimentaryAgreement
 ** Developed by        : AurionPro Team 
 ** Client              : WMS
 ** Description         : The purpose of this JPO is to create a Measurement Book Entry
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------
 ** AurionPro                  28-Jul-2017                  Original Version
 ** -----------------------------------------------------------------
 **/

import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.common.Route;
import com.matrixone.jdom.Element;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.math.BigDecimal;
import java.util.Vector;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import matrix.util.Pattern;

import matrix.db.JPO;
import matrix.db.Context;
import matrix.util.StringList;
import java.text.DecimalFormat;

/**
 * The purpose of this JPO is to create a Measurement Book Entry.
 * @author WMS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSSupplimentaryAgreement_mxJPO extends WMSConstants_mxJPO
{
	

	 
	/**
	 * Create a new ${CLASS:AdvanceRecovery} object from a given id.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds no arguments.
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since R418
	 */

	public WMSSupplimentaryAgreement_mxJPO(Context context, String[] args)
			throws Exception
	{
          super(context,args);
	}

	/**
	 * PENDING header and annotation
	 * Method called on the Portal to display the Advances 
	 * 
	 * to get the Advances
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getSupplimentaryAgreements(Context context,String[]args) throws Exception
	{
		MapList mapListAMBAdvances = new MapList();
		try
		{
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				StringList strListBusSelects     = new StringList(3);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_TYPE);
				strListBusSelects.add(DomainConstants.SELECT_CURRENT);
				strListBusSelects.add("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
				DomainObject domObjTask= DomainObject.newInstance(context, strObjectId);
				mapListAMBAdvances = domObjTask.getRelatedObjects(context, // matrix context
						RELATIONSHIP_WMS_WORKORDER_SUPPLIMENTARY_AGREEMENT, // relationship pattern
						TYPE_WMS_SUPPLIMENTARY_AGREEMENT, // type pattern
						strListBusSelects, // object selects
						null, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
						
				String strCurrent = DomainConstants.EMPTY_STRING;	
				 for(int i=0;i<mapListAMBAdvances.size();i++) {
                	Map m = (Map) mapListAMBAdvances.get(i);
                	strCurrent=(String)m.get(DomainConstants.SELECT_CURRENT);
					if(!strCurrent.equalsIgnoreCase("Create")) {
						m.put("RowEditable", "readonly");
						if(!strCurrent.equalsIgnoreCase("Create"))
							m.put("disableSelection", "true");
					}
				}
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in getSupplimentaryAgreements method of JPO WMSSupplimentaryAgreement");
			exception.printStackTrace();
			throw exception;
		}
		return mapListAMBAdvances;
	}
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getSupplimentaryAgreementsBOQs(Context context,String[]args) throws Exception
	{
		boolean bHasAccessToModify = false;
		MapList mapListAMBAdvances = new MapList();
		try
		{
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strObjectId = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{

				DomainObject domObj= DomainObject.newInstance(context, strObjectId);
				
				String mqlQuery = "print bus "+strObjectId+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
				String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
				String strContextUser = context.getUser();
				if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
					mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name dump";
					String strUser = MqlUtil.mqlCommand(context, mqlQuery);
					if(UIUtil.isNotNullAndNotEmpty(strUser) && strUser.contains(strContextUser)){
						bHasAccessToModify = true;
					}
				}
				
				
				StringList strListBusSelects = new StringList();
				strListBusSelects.add(DomainObject.SELECT_ID);
				strListBusSelects.add(DomainObject.SELECT_CURRENT);
				strListBusSelects.add(DomainObject.SELECT_TYPE);
				strListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
				strListBusSelects.add("attribute[WMSMBEQuantity]");
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				StringList strListRelSelects = new StringList();
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				strListRelSelects.add("attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"]");
				
				MapList mlSegmentList = domObj.getRelatedObjects(context, // matrix context
                		                                    RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+","+RELATIONSHIP_BILL_OF_QUANTITY, // relationship pattern
															TYPE_WMS_SEGMENT+","+TYPE_WMS_MEASUREMENT_TASK,    
															strListBusSelects, // object selects
															strListRelSelects, // relationship selects
															false, // to direction
															true, // from direction
															(short) 0, // recursion level
															DomainConstants.EMPTY_STRING, // object where clause
															DomainConstants.EMPTY_STRING, // relationship where clause
															0);
				
				StringList strListOBJ = WMSUtil_mxJPO.convertToStringList(mlSegmentList, DomainRelationship.SELECT_ID);
				
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_CURRENT);
				slSelect.add(DomainObject.SELECT_TYPE);
				slSelect.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
				slSelect.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
				slSelect.add("attribute[WMSMBEQuantity].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
				String [] objIds = new String[1];	
				objIds[0] = strObjectId;
				StringList slDeviationList = domObj.getInfoList(context,"from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id");
				
				String strTempId = DomainConstants.EMPTY_STRING;
				for(int k=0;k<strListOBJ.size();k++){
					strTempId = (String)strListOBJ.get(k);
					if(slDeviationList.contains(strTempId)){
						slDeviationList.remove(strTempId);
					}
				}
				
				String strCurrent = domObj.getInfo(context,DomainObject.SELECT_CURRENT);
				String strState = DomainConstants.EMPTY_STRING;
				String strType = DomainConstants.EMPTY_STRING;
				String strSOR = DomainConstants.EMPTY_STRING;
				String strQty = DomainConstants.EMPTY_STRING;
				String strTitle = DomainConstants.EMPTY_STRING;
				String strTotalQty = DomainConstants.EMPTY_STRING;
				String strMBEQty = DomainConstants.EMPTY_STRING;
				DomainObject doDev = null;
				 for(int i=0;i<slDeviationList.size();i++) {
                	String strDevRel = (String) slDeviationList.get(i);
					
					String strDevObjId = MqlUtil.mqlCommand(context, "print connection "+strDevRel+" select torel.to.id dump");
					strQty = MqlUtil.mqlCommand(context, "print connection "+strDevRel+" select attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"].value dump");
					doDev = new DomainObject(strDevObjId);
					
					Map m = (Map)doDev.getInfo(context,slSelect);

					strState = (String)m.get(DomainObject.SELECT_CURRENT);
					strType = (String)m.get(DomainObject.SELECT_TYPE);
					strSOR = (String)m.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
					strTitle = (String)m.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
					strMBEQty = (String)m.get("attribute[WMSMBEQuantity].value");
					strTotalQty = (String)m.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
					
					Map mTemp = new HashMap();
					mTemp.put(DomainObject.SELECT_ID,strDevObjId);
					mTemp.put(DomainObject.SELECT_TYPE,strType);
					mTemp.put(DomainRelationship.SELECT_ID,strDevRel);
					mTemp.put("attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"]",strQty);
					mTemp.put("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]",strSOR);
					mTemp.put("from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id",strDevRel);
					mTemp.put("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]",strTitle);
					mTemp.put(DomainObject.SELECT_CURRENT,strState);
					mTemp.put("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]",strTotalQty);
					mTemp.put("attribute[WMSMBEQuantity]",strMBEQty);
					
					if(strCurrent.equalsIgnoreCase("Approved") || (strCurrent.equalsIgnoreCase("Review") && !bHasAccessToModify)) {
						mTemp.put("RowEditable", "readonly");
						if(!strCurrent.equalsIgnoreCase("Create"))
							mTemp.put("disableSelection", "true");
					}
					
					mapListAMBAdvances.add(mTemp);
				}
				
				for(int j=0;j<mlSegmentList.size();j++){
					Map mTempMap = (Map)mlSegmentList.get(j);
					if(strCurrent.equalsIgnoreCase("Approved") || (strCurrent.equalsIgnoreCase("Review") && !bHasAccessToModify)) {
						mTempMap.put("RowEditable", "readonly");
						if(!strCurrent.equalsIgnoreCase("Create"))
							mTempMap.put("disableSelection", "true");
					}
					mapListAMBAdvances.add(mTempMap);
				}
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in getSupplimentaryAgreementsBOQs method of JPO WMSSupplimentaryAgreement");
			exception.printStackTrace();
			throw exception;
		}
		return mapListAMBAdvances;
	}
	
		
	@com.matrixone.apps.framework.ui.CreateProcessCallable
    public Map createSupplimentaryAgreeent(Context context, String[] args) throws Exception {
        HashMap requestMap  = (HashMap) JPO.unpackArgs(args);
		
        Map returnMap       = new HashMap();
        try {
				DomainObject doSupAgreement = DomainObject.newInstance(context);
                String strTitle       = (String) requestMap.get("Title");  
                String strDesc        = (String) requestMap.get("Description");  
                String strAgreementNo          = (String) requestMap.get("AgreementNo");
                String strAgreementDate              = (String) requestMap.get("AgreementDate"); 
                String strWOId              = (String) requestMap.get("objectId"); 

				DomainObject doWO = new DomainObject(strWOId);
				
				StringList slAgreementStateList = (StringList)doWO.getInfoList(context,"from["+RELATIONSHIP_WMS_WORKORDER_SUPPLIMENTARY_AGREEMENT+"].to.current");
				
				if(slAgreementStateList.contains("Create") || slAgreementStateList.contains("Review")){
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.Agreements.Pending");
					returnMap.put("Action","Stop");
					returnMap.put("ErrorMessage",strMessage);
					return returnMap;
				}
				
                Map mapAttributeMap = new HashMap();
                mapAttributeMap.put(DomainObject.ATTRIBUTE_TITLE, strTitle);
                mapAttributeMap.put(ATTRIBUTE_WMS_SUPP_AGREEMENT_NUMBER, strAgreementNo);
                mapAttributeMap.put(ATTRIBUTE_WMS_SUPP_AGREEMENT_DATE, strAgreementDate);

									   
				String symbolicTypeName = PropertyUtil.getAliasForAdmin(context, "Type", TYPE_WMS_SUPPLIMENTARY_AGREEMENT, true);
  				String symbolicPolicyName = PropertyUtil.getAliasForAdmin(context, "Policy", POLICY_WMS_SUPPLIMENTARY_AGREEMENT, true);
				
				String strNewObject = FrameworkUtil.autoName(context,
                        symbolicTypeName,
                        null,
                        symbolicPolicyName,
                        null,
                        null,
                        true,
                        true);
				DomainRelationship domRel   = doSupAgreement.createAndConnect(context,
						TYPE_WMS_SUPPLIMENTARY_AGREEMENT,
						strNewObject,
						"-",
						POLICY_WMS_SUPPLIMENTARY_AGREEMENT,
						null,
						RELATIONSHIP_WMS_WORKORDER_SUPPLIMENTARY_AGREEMENT,
						doWO,
						true);

                String strNewObjectId     = doSupAgreement.getId();
                doSupAgreement.setAttributeValues(context, mapAttributeMap);
                doSupAgreement.setDescription(context, strDesc);
                returnMap.put("id", strNewObjectId);
        } catch (Exception e) {
            throw new FrameworkException(e);
        }
        return returnMap;
    }
	
	public StringList getItemType(Context context, String[] args)throws Exception{
	StringList slReturnList = new StringList();
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		MapList objectList = (MapList) programMap.get("objectList");
		Iterator<Map<String, String>> iteratorMap = objectList.iterator();
		Map<String, String> mapObjectData = new HashMap<String, String>();
		String strRelId = DomainConstants.EMPTY_STRING;
		String strType = DomainConstants.EMPTY_STRING;
		while (iteratorMap.hasNext()) {
			mapObjectData = iteratorMap.next();
			strType = (String)mapObjectData.get(DomainObject.SELECT_TYPE);
			if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
				strRelId = (String)mapObjectData.get("from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id");				
				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
					slReturnList.add("Deviation");
				}else{
					slReturnList.add("Supplemental");
				}
			}else{
				slReturnList.add(DomainConstants.EMPTY_STRING);
			}			
		}
		
	} catch (Exception exception) {
		System.out.println("Exception in getUpToDateAmount method of JPO WMSAbsParticulars");
		exception.printStackTrace();
		throw exception;
	}

	return slReturnList;
}

public StringList getState(Context context, String[] args)throws Exception{
	StringList slReturnList = new StringList();
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		MapList objectList = (MapList) programMap.get("objectList");
		DecimalFormat decFor = new DecimalFormat("#.###");
		Iterator<Map<String, String>> iteratorMap = objectList.iterator();
		Map<String, String> mapObjectData = new HashMap<String, String>();
		String strRelId = DomainConstants.EMPTY_STRING;
		String strType = DomainConstants.EMPTY_STRING;
		String strCurrent = DomainConstants.EMPTY_STRING;
		while (iteratorMap.hasNext()) {
			mapObjectData = iteratorMap.next();
			strType = (String)mapObjectData.get(DomainObject.SELECT_TYPE);
			strCurrent = (String)mapObjectData.get(DomainObject.SELECT_CURRENT);
			if(UIUtil.isNotNullAndNotEmpty(strType) && (TYPE_WMS_MEASUREMENT_TASK.equals(strType) || TYPE_WMS_SEGMENT.equals(strType))){
				slReturnList.add(DomainConstants.EMPTY_STRING);
			}else{
				slReturnList.add(strCurrent);
			}			
		}
		
	} catch (Exception exception) {
		System.out.println("Exception in getUpToDateAmount method of JPO WMSAbsParticulars");
		exception.printStackTrace();
		throw exception;
	}

	return slReturnList;
}


public StringList getQuantity(Context context, String[] args)throws Exception{
	StringList slReturnList = new StringList();
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		MapList objectList = (MapList) programMap.get("objectList");
		DecimalFormat decFor = new DecimalFormat("#.###");
		Iterator<Map<String, String>> iteratorMap = objectList.iterator();
		Map<String, String> mapObjectData = new HashMap<String, String>();
		String strType = DomainConstants.EMPTY_STRING;
		String strRelId = DomainConstants.EMPTY_STRING;
		String strQty = DomainConstants.EMPTY_STRING;
		while (iteratorMap.hasNext()) {
			mapObjectData = iteratorMap.next();
			strType = (String)mapObjectData.get(DomainObject.SELECT_TYPE);
			strRelId = (String)mapObjectData.get("from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id");		
			if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
					strQty = (String)mapObjectData.get("attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"]");
				}else{
					strQty = (String)mapObjectData.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
				}
				
				if(UIUtil.isNotNullAndNotEmpty(strQty)){
					Double dQty = Double.valueOf(strQty);
					slReturnList.add(new BigDecimal(dQty).setScale(3, BigDecimal.ROUND_UP).toPlainString());
				}else{
					slReturnList.add("0.000");
				}
				
			}else{
				slReturnList.add(DomainConstants.EMPTY_STRING);
			}			
		}
		
	} catch (Exception exception) {
		System.out.println("Exception in getUpToDateAmount method of JPO WMSAbsParticulars");
		exception.printStackTrace();
		throw exception;
	}

	return slReturnList;
}
	
	
	public StringList checkForMeasurementType(Context context,String args[]) throws Exception
    {
        StringList strListAccess = new StringList();;
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();

            while (objectListIterator.hasNext()) {

                Map<String,String> mapData = objectListIterator.next();
                String strType = mapData.get(DomainConstants.SELECT_TYPE);
                if(TYPE_WMS_MEASUREMENT_TASK.equals(strType))
                    strListAccess.add(String.valueOf(true));
                else
                    strListAccess.add(String.valueOf(false));
            }

        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListAccess;

    }
	
	
	public void updateQuantity(Context context, String[] args) throws Exception 
     {
		 boolean isContextPushed = false;
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sBOQId = (String)paramMap.get("objectId");
             String sRelId = (String)paramMap.get("relId");
             String strNewValue = (String)paramMap.get("New Value");
			 
			 ContextUtil.pushContext(context);
			 isContextPushed = true;
			 String strRelName = MqlUtil.mqlCommand(context,"print connection "+sRelId+" select name dump");
			 if(RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ.equals(strRelName)){
				 DomainRelationship doRel = new DomainRelationship(sRelId);
				 doRel.setAttributeValue(context,ATTRIBUTE_WMS_CHANGE_QUANTITY,strNewValue);
			 }else{
				 DomainObject doBus = new DomainObject(sBOQId);
				 doBus.setAttributeValue(context,ATTRIBUTE_WMS_TOTAL_QUANTITY,strNewValue);
			 }
         }
         catch (Exception e) {
             throw e;
         }finally{
			 if(isContextPushed)
				 ContextUtil.popContext(context);
		 }
     }

 
public void triggerAutoCreateApprovalRoute(Context context, String[] args) throws Exception{
	boolean isContextPushed = false;
	try {
		String sObjectId = args[0];
		DomainObject doObj = null;
		if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
			doObj = new DomainObject(sObjectId);
			 String strRouteRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"  || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
			MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doObj, strRouteRelWhere);
		   if(mlExtRoutes.size()>0) {
			   WMSUtil_mxJPO.restartExistingRoute(context,mlExtRoutes);
		   }else{
			
				StringList slObjSelect = new StringList();
				slObjSelect.add(DomainConstants.SELECT_POLICY);
				slObjSelect.add("to["+RELATIONSHIP_WMS_WORKORDER_SUPPLIMENTARY_AGREEMENT+"].from.id");
				
				Map ObjInfo = (Map)doObj.getInfo(context,slObjSelect);
				String strPolicy = (String)ObjInfo.get(DomainConstants.SELECT_POLICY);
				String strWOId = (String)ObjInfo.get("to["+RELATIONSHIP_WMS_WORKORDER_SUPPLIMENTARY_AGREEMENT+"].from.id");
				
				if(UIUtil.isNotNullAndNotEmpty(strWOId)){
					DomainObject doObjWO = new DomainObject(strWOId);
					String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == 'Agreement Approval'";
					MapList routeMapList= doObjWO.getRelatedObjects(context, RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
					if(routeMapList != null && routeMapList.isEmpty() == false){
						Map mRouteTemplateMap = (Map)routeMapList.get(0);
						String strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
						WMSUtil_mxJPO.createRouteFromTemplate(context, sObjectId, strTemplateId, strPolicy, "Approved", "state_Review");
					}
				}

		   }
			/*StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainObject.SELECT_ID);
			strListBusSelects.add(DomainObject.SELECT_CURRENT);
			strListBusSelects.add(DomainObject.SELECT_TYPE);
			strListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			
			MapList mlSegmentList = doObj.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ, // relationship pattern
														TYPE_WMS_SEGMENT,    
														strListBusSelects, // object selects
														strListRelSelects, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														DomainConstants.EMPTY_STRING, // object where clause
														DomainConstants.EMPTY_STRING, // relationship where clause
														0);
			
			StringList strListOBJ = ${CLASS:WMSUtil}.convertToStringList(mlSegmentList, DomainRelationship.SELECT_ID);				

			StringList slDeviationList = doObj.getInfoList(context,"from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id");
			
			String strTempId = DomainConstants.EMPTY_STRING;
			for(int k=0;k<strListOBJ.size();k++){
				strTempId = (String)strListOBJ.get(k);
				if(slDeviationList.contains(strTempId)){
					slDeviationList.remove(strTempId);
				}
			}
				
				
			String strDevRelId = DomainConstants.EMPTY_STRING;
			String strMqlResult = DomainConstants.EMPTY_STRING;
			String strChangeQty = DomainConstants.EMPTY_STRING;
			String strBOQId = DomainConstants.EMPTY_STRING;
			String strTotalQty = DomainConstants.EMPTY_STRING;
			String strDeviation = DomainConstants.EMPTY_STRING;
			
			DomainObject doBOQ = null;
			double dChangeQty = 0;
			double dTotalQty = 0;
			double dDeviationQty = 0;
			StringList slValueList = new StringList();
			ContextUtil.pushContext(context);
			isContextPushed = true;
			HashMap mapAttr = new HashMap();
			for(int i=0;i<slDeviationList.size();i++){
				strDevRelId = (String)slDeviationList.get(i);
				strMqlResult = MqlUtil.mqlCommand(context,"print connection "+strDevRelId+" select attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"].value torel.to.id torel.to.attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value attribute["+ATTRIBUTE_WMS_DEVIATION_QUANTITY+"].value dump |");
				
				if(UIUtil.isNotNullAndNotEmpty(strMqlResult)){
					slValueList = FrameworkUtil.split(strMqlResult,"|");
					strChangeQty = (String)slValueList.get(0);
					strBOQId = (String)slValueList.get(1);
					strTotalQty = (String)slValueList.get(2);
					strDeviation = (String)slValueList.get(3);
					
					if(UIUtil.isNullOrEmpty(strDeviation)){
						strDeviation = "0";
					}
					
					doBOQ = new DomainObject(strBOQId);
					dChangeQty = Double.valueOf(strChangeQty);
					dTotalQty = Double.valueOf(strTotalQty);
					dDeviationQty = Double.valueOf(strDeviation);
					
					mapAttr = new HashMap();
					mapAttr.put(ATTRIBUTE_WMS_TOTAL_QUANTITY, String.valueOf(dChangeQty+dTotalQty));
					mapAttr.put(ATTRIBUTE_WMS_DEVIATION_QUANTITY, String.valueOf(dChangeQty+dDeviationQty));
					//mapAttr.put(ATTRIBUTE_WMS_PREV_QUANTITY, strTotalQty);
					mapAttr.put(ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE, "Deviation");
					doBOQ.setAttributeValues(context,mapAttr);							
				}
			}
				
			if(UIUtil.isNotNullAndNotEmpty(strWOId)){
				DomainObject doObjWO = new DomainObject(strWOId);
				String strMBId = (String)doObjWO.getInfo(context,"from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");
				
				
				MapList mlWOSegmentList = doObjWO.getRelatedObjects(context, // matrix context
														RELATIONSHIP_BILL_OF_QUANTITY, // relationship pattern
														TYPE_WMS_SEGMENT+","+TYPE_WMS_MEASUREMENT_BOOK,    
														strListBusSelects, // object selects
														strListRelSelects, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														DomainConstants.EMPTY_STRING, // object where clause
														DomainConstants.EMPTY_STRING, // relationship where clause
														0);
							
				String strType = DomainConstants.EMPTY_STRING;
				String strSegId = DomainConstants.EMPTY_STRING;
				String strWOSegId = DomainConstants.EMPTY_STRING;
				String strTitle = DomainConstants.EMPTY_STRING;
				String strWOSegTitle = DomainConstants.EMPTY_STRING;
				Map mTempSegMap = null;							
				Map mTempWOSegMap = null;	
				DomainObject doBOQNew = null;		
				boolean isSegmentAvailable = false;
				for(int k=0;k<mlSegmentList.size();k++){					
					isSegmentAvailable = false;
					mTempSegMap = (Map)mlSegmentList.get(k);
					strTitle = (String)mTempSegMap.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
					strSegId = (String)mTempSegMap.get(DomainObject.SELECT_ID);
					DomainObject doSeg = new DomainObject(strSegId);
					for(int j=0;j<mlWOSegmentList.size();j++){
						mTempWOSegMap = (Map)mlWOSegmentList.get(j);
						strType = (String)mTempWOSegMap.get(DomainObject.SELECT_TYPE);
						if(TYPE_WMS_SEGMENT.equals(strType)){
							strWOSegTitle = (String)mTempWOSegMap.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
							strWOSegId = (String)mTempWOSegMap.get(DomainObject.SELECT_ID);
							if(strWOSegTitle.equals(strTitle)){
								isSegmentAvailable = true;								
								DomainObject doWOSeg = new DomainObject(strWOSegId);
								StringList slSegBOQList = doSeg.getInfoList(context,"from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");								
								for(int x=0;x<slSegBOQList.size();x++){
									doBOQNew = new DomainObject((String)slSegBOQList.get(x));
									DomainRelationship.connect(context, doWOSeg, RELATIONSHIP_BILL_OF_QUANTITY, doBOQNew);
									doBOQNew.setAttributeValue(context,ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE,"Non-Tender Items");
									doBOQNew.setState(context, "Active");
								}
								break;
							}						
						}						
					}
					
					if(isSegmentAvailable == false){
						DomainRelationship.connect(context, new DomainObject(strMBId), RELATIONSHIP_BILL_OF_QUANTITY, doSeg);
						doSeg.setState(context, "Active");
						StringList slSegBOQList = doSeg.getInfoList(context,"from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");
						for(int x=0;x<slSegBOQList.size();x++){
							doBOQNew = new DomainObject((String)slSegBOQList.get(x));
							doBOQNew.setAttributeValue(context,ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE,"Non-Tender Items");
							doBOQNew.setState(context, "Active");
						}						
					}
				}				
				
			}		*/
		}			
	}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}finally{
		if(isContextPushed)
			ContextUtil.popContext(context);
	}
}


public void updateBOQOnAgreementApproval(Context context, String[] args) throws Exception{
	boolean isContextPushed = false;
	try {
		String sObjectId = args[0];
		DomainObject doObj = null;
		if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
			doObj = new DomainObject(sObjectId);
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainConstants.SELECT_POLICY);
			slObjSelect.add("to["+RELATIONSHIP_WMS_WORKORDER_SUPPLIMENTARY_AGREEMENT+"].from.id");
			
			Map ObjInfo = (Map)doObj.getInfo(context,slObjSelect);
			String strPolicy = (String)ObjInfo.get(DomainConstants.SELECT_POLICY);
			String strWOId = (String)ObjInfo.get("to["+RELATIONSHIP_WMS_WORKORDER_SUPPLIMENTARY_AGREEMENT+"].from.id");
			
			/*if(UIUtil.isNotNullAndNotEmpty(strWOId)){
				DomainObject doObjWO = new DomainObject(strWOId);
				String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == 'Agreement Approval'";
				MapList routeMapList= doObjWO.getRelatedObjects(context, RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
				if(routeMapList != null && routeMapList.isEmpty() == false){
					Map mRouteTemplateMap = (Map)routeMapList.get(0);
					String strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
					${CLASS:WMSUtil}.createRouteFromTemplate(context, sObjectId, strTemplateId, strPolicy, "Approved", "state_Review");
				}
			}*/

				
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainObject.SELECT_ID);
			strListBusSelects.add(DomainObject.SELECT_CURRENT);
			strListBusSelects.add(DomainObject.SELECT_TYPE);
			strListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			
			MapList mlSegmentList = doObj.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ, // relationship pattern
														TYPE_WMS_SEGMENT,    
														strListBusSelects, // object selects
														strListRelSelects, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														DomainConstants.EMPTY_STRING, // object where clause
														DomainConstants.EMPTY_STRING, // relationship where clause
														0);
			
			StringList strListOBJ = WMSUtil_mxJPO.convertToStringList(mlSegmentList, DomainRelationship.SELECT_ID);				

			StringList slDeviationList = doObj.getInfoList(context,"from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id");
			
			String strTempId = DomainConstants.EMPTY_STRING;
			for(int k=0;k<strListOBJ.size();k++){
				strTempId = (String)strListOBJ.get(k);
				if(slDeviationList.contains(strTempId)){
					slDeviationList.remove(strTempId);
				}
			}
				
				
			String strDevRelId = DomainConstants.EMPTY_STRING;
			String strMqlResult = DomainConstants.EMPTY_STRING;
			String strChangeQty = DomainConstants.EMPTY_STRING;
			String strBOQId = DomainConstants.EMPTY_STRING;
			String strTotalQty = DomainConstants.EMPTY_STRING;
			String strDeviation = DomainConstants.EMPTY_STRING;
			
			DomainObject doBOQ = null;
			double dChangeQty = 0;
			double dTotalQty = 0;
			double dDeviationQty = 0;
			StringList slValueList = new StringList();
			ContextUtil.pushContext(context);
			isContextPushed = true;
			HashMap mapAttr = new HashMap();
			for(int i=0;i<slDeviationList.size();i++){
				strDevRelId = (String)slDeviationList.get(i);
				strMqlResult = MqlUtil.mqlCommand(context,"print connection "+strDevRelId+" select attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"].value torel.to.id torel.to.attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value attribute["+ATTRIBUTE_WMS_DEVIATION_QUANTITY+"].value dump |");
				
				if(UIUtil.isNotNullAndNotEmpty(strMqlResult)){
					slValueList = FrameworkUtil.split(strMqlResult,"|");
					strChangeQty = (String)slValueList.get(0);
					strBOQId = (String)slValueList.get(1);
					strTotalQty = (String)slValueList.get(2);
					strDeviation = (String)slValueList.get(3);
					
					if(UIUtil.isNullOrEmpty(strDeviation)){
						strDeviation = "0";
					}
					
					doBOQ = new DomainObject(strBOQId);
					dChangeQty = Double.valueOf(strChangeQty);
					dTotalQty = Double.valueOf(strTotalQty);
					dDeviationQty = Double.valueOf(strDeviation);
					
					mapAttr = new HashMap();
					mapAttr.put(ATTRIBUTE_WMS_TOTAL_QUANTITY, String.valueOf(dChangeQty+dTotalQty));
					mapAttr.put(ATTRIBUTE_WMS_DEVIATION_QUANTITY, String.valueOf(dChangeQty+dDeviationQty));
					//mapAttr.put(ATTRIBUTE_WMS_PREV_QUANTITY, strTotalQty);
					mapAttr.put(ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE, "Deviation");
					doBOQ.setAttributeValues(context,mapAttr);							
				}
			}
				
			if(UIUtil.isNotNullAndNotEmpty(strWOId)){
				DomainObject doObjWO = new DomainObject(strWOId);
				String strMBId = (String)doObjWO.getInfo(context,"from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");
				
				
				MapList mlWOSegmentList = doObjWO.getRelatedObjects(context, // matrix context
														RELATIONSHIP_BILL_OF_QUANTITY, // relationship pattern
														TYPE_WMS_SEGMENT+","+TYPE_WMS_MEASUREMENT_BOOK,    
														strListBusSelects, // object selects
														strListRelSelects, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														DomainConstants.EMPTY_STRING, // object where clause
														DomainConstants.EMPTY_STRING, // relationship where clause
														0);
							
				String strType = DomainConstants.EMPTY_STRING;
				String strSegId = DomainConstants.EMPTY_STRING;
				String strWOSegId = DomainConstants.EMPTY_STRING;
				String strTitle = DomainConstants.EMPTY_STRING;
				String strWOSegTitle = DomainConstants.EMPTY_STRING;
				Map mTempSegMap = null;							
				Map mTempWOSegMap = null;	
				DomainObject doBOQNew = null;		
				boolean isSegmentAvailable = false;
				for(int k=0;k<mlSegmentList.size();k++){					
					isSegmentAvailable = false;
					mTempSegMap = (Map)mlSegmentList.get(k);
					strTitle = (String)mTempSegMap.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
					strSegId = (String)mTempSegMap.get(DomainObject.SELECT_ID);
					DomainObject doSeg = new DomainObject(strSegId);
					for(int j=0;j<mlWOSegmentList.size();j++){
						mTempWOSegMap = (Map)mlWOSegmentList.get(j);
						strType = (String)mTempWOSegMap.get(DomainObject.SELECT_TYPE);
						if(TYPE_WMS_SEGMENT.equals(strType)){
							strWOSegTitle = (String)mTempWOSegMap.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
							strWOSegId = (String)mTempWOSegMap.get(DomainObject.SELECT_ID);
							if(strWOSegTitle.equals(strTitle)){
								isSegmentAvailable = true;								
								DomainObject doWOSeg = new DomainObject(strWOSegId);
								StringList slSegBOQList = doSeg.getInfoList(context,"from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");								
								for(int x=0;x<slSegBOQList.size();x++){
									doBOQNew = new DomainObject((String)slSegBOQList.get(x));
									DomainRelationship.connect(context, doWOSeg, RELATIONSHIP_BILL_OF_QUANTITY, doBOQNew);
									doBOQNew.setAttributeValue(context,ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE,"Non-Tender Items");
									doBOQNew.setState(context, "Active");
								}
								break;
							}						
						}						
					}
					
					if(isSegmentAvailable == false){
						DomainRelationship.connect(context, new DomainObject(strMBId), RELATIONSHIP_BILL_OF_QUANTITY, doSeg);
						doSeg.setState(context, "Active");
						StringList slSegBOQList = doSeg.getInfoList(context,"from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");
						for(int x=0;x<slSegBOQList.size();x++){
							doBOQNew = new DomainObject((String)slSegBOQList.get(x));
							doBOQNew.setAttributeValue(context,ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE,"Non-Tender Items");
							doBOQNew.setState(context, "Active");
						}						
					}
				}				
				
			}		
		}			
	}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}finally{
		if(isContextPushed)
			ContextUtil.popContext(context);
	}
}
	 
	 public int checkQuantityAndRateUpdated(Context context, String[] args) throws Exception
		{
			try {
				String sObjectId = args[0];
				DomainObject doObj = null;
				if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
					DomainObject doSupAggr = DomainObject.newInstance(context,sObjectId);
					StringList slBOQList = new StringList();
					StringList slReducedQtyBOQList = new StringList();
					Map mArgs=new HashMap();
					mArgs.put("objectId", sObjectId);
					MapList mlBOQItems = getSupplimentaryAgreementsBOQs(context,JPO.packArgs(mArgs));
					
					Map mTemp = null;
					String strType = DomainConstants.EMPTY_STRING;
					String strQty = DomainConstants.EMPTY_STRING;
					String strRate = DomainConstants.EMPTY_STRING;
					String strTitle = DomainConstants.EMPTY_STRING;
					String strRelId = DomainConstants.EMPTY_STRING;
					String strChangeQty = DomainConstants.EMPTY_STRING;
					String strTotalQty = DomainConstants.EMPTY_STRING;
					String strMBEQty = DomainConstants.EMPTY_STRING;
					double dRate = 0;
					double dQty = 0;
					double dChangeQty = 0;
					double dTotalQty = 0;
					double dMBEQty = 0;
					double dFinalQty = 0;
					
					for(int i=0;i<mlBOQItems.size();i++){
						mTemp = (Map)mlBOQItems.get(i);
						strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
						strTitle = (String)mTemp.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
						if(TYPE_WMS_MEASUREMENT_TASK.equals(strType)){							
							strRelId = (String)(String)mTemp.get("from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id");
							if(UIUtil.isNotNullAndNotEmpty(strRelId)){
								strQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"]");
								strTotalQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
								strChangeQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"]");
								strMBEQty = (String)mTemp.get("attribute[WMSMBEQuantity]");
								dTotalQty = Double.valueOf(strTotalQty);
								dChangeQty = Double.valueOf(strChangeQty);
								dMBEQty = Double.valueOf(strMBEQty);
								dFinalQty = dTotalQty+dChangeQty;
								if(dFinalQty<dMBEQty){
									slReducedQtyBOQList.add(strTitle);
								}
								
							}else{
								strQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
							}
							strRate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
							
							if(UIUtil.isNullOrEmpty(strRate)){
								strRate = "0";
							}
							
							if(UIUtil.isNullOrEmpty(strQty)){
								strQty = "0";
							}
							dRate = Double.valueOf(strRate);
							dQty = Double.valueOf(strQty);
							
							if(dRate == 0 || dQty == 0){
								if(slBOQList.contains(strTitle)==false)
									slBOQList.add(strTitle);
							}
						}
						
					}
					if(slBOQList.size()>0){
						StringBuilder sbMessage = new StringBuilder();
						String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.BOQ.Update.RateQuantiry");
						
						for(int i=0;i<slBOQList.size();i++){
							if(i==0){
								sbMessage.append((String)slBOQList.get(i));
							}else{
								sbMessage.append(",");
								sbMessage.append((String)slBOQList.get(i));
							}							
						}
						emxContextUtil_mxJPO.mqlNotice(context,strMessage+"\n"+sbMessage.toString());
						return 1;
					}
					
					if(slReducedQtyBOQList.size()>0){
						StringBuilder sbMessage = new StringBuilder();
												
						for(int i=0;i<slReducedQtyBOQList.size();i++){
							if(i==0){
								sbMessage.append((String)slReducedQtyBOQList.get(i));
							}else{
								sbMessage.append(",");
								sbMessage.append((String)slReducedQtyBOQList.get(i));
							}							
						}
						emxContextUtil_mxJPO.mqlNotice(context,"Measured quantity is more than the actual quantity after agreement for following BOQs."+"\n"+sbMessage.toString());
						return 1;
					}
					
					String strBusWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\" || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
					MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doSupAggr, strBusWhere);
					if(mlExtRoutes.size()==0){
						emxContextUtil_mxJPO.mqlNotice(context,"Please add Route and then proceed");
						return 1;						
					}
					
				}			
			}
			catch (Exception e) {
				throw e;
			}
			return 0;
		}
		
		 public String checkQuantityAndRateUpdatedOnApproval(Context context, String[] args) throws Exception
		{
			try {
				 HashMap programMap = (HashMap)JPO.unpackArgs(args);
				String sObjectId = (String)programMap.get("objectId");
				DomainObject doObj = null;
				if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
					StringList slBOQList = new StringList();
					StringList slReducedQtyBOQList = new StringList();
					Map mArgs=new HashMap();
					mArgs.put("objectId", sObjectId);
					MapList mlBOQItems = getSupplimentaryAgreementsBOQs(context,JPO.packArgs(mArgs));
					
					Map mTemp = null;
					String strType = DomainConstants.EMPTY_STRING;
					String strQty = DomainConstants.EMPTY_STRING;
					String strRate = DomainConstants.EMPTY_STRING;
					String strTitle = DomainConstants.EMPTY_STRING;
					String strRelId = DomainConstants.EMPTY_STRING;
					String strChangeQty = DomainConstants.EMPTY_STRING;
					String strTotalQty = DomainConstants.EMPTY_STRING;
					String strMBEQty = DomainConstants.EMPTY_STRING;
					double dRate = 0;
					double dQty = 0;
					double dChangeQty = 0;
					double dTotalQty = 0;
					double dMBEQty = 0;
					double dFinalQty = 0;
					
					for(int i=0;i<mlBOQItems.size();i++){
						mTemp = (Map)mlBOQItems.get(i);
						strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
						strTitle = (String)mTemp.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
						if(TYPE_WMS_MEASUREMENT_TASK.equals(strType)){							
							strRelId = (String)(String)mTemp.get("from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id");
							if(UIUtil.isNotNullAndNotEmpty(strRelId)){
								strQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"]");
								strTotalQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
								strChangeQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"]");
								strMBEQty = (String)mTemp.get("attribute[WMSMBEQuantity]");
								dTotalQty = Double.valueOf(strTotalQty);
								dChangeQty = Double.valueOf(strChangeQty);
								dMBEQty = Double.valueOf(strMBEQty);
								dFinalQty = dTotalQty+dChangeQty;
								if(dFinalQty<dMBEQty){
									slReducedQtyBOQList.add(strTitle);
								}
							}else{
								strQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
							}
							strRate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
							
							if(UIUtil.isNullOrEmpty(strRate)){
								strRate = "0";
							}
							
							if(UIUtil.isNullOrEmpty(strQty)){
								strQty = "0";
							}
							dRate = Double.valueOf(strRate);
							dQty = Double.valueOf(strQty);
							
							if(dRate == 0 || dQty == 0){
								if(slBOQList.contains(strTitle)==false)
									slBOQList.add(strTitle);
							}
						}
						
					}
					if(slBOQList.size()>0){
						StringBuilder sbMessage = new StringBuilder();
						String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.BOQ.Update.RateQuantiry");
						
						for(int i=0;i<slBOQList.size();i++){
							if(i==0){
								sbMessage.append((String)slBOQList.get(i));
							}else{
								sbMessage.append(",");
								sbMessage.append((String)slBOQList.get(i));
							}							
						}
						
						return strMessage+". "+sbMessage.toString();
					}
					
					if(slReducedQtyBOQList.size()>0){
						StringBuilder sbMessage = new StringBuilder();
												
						for(int i=0;i<slReducedQtyBOQList.size();i++){
							if(i==0){
								sbMessage.append((String)slReducedQtyBOQList.get(i));
							}else{
								sbMessage.append(",");
								sbMessage.append((String)slReducedQtyBOQList.get(i));
							}							
						}
						return "Measured quantity is more than the actual quantity after agreement for following BOQs."+"\n"+sbMessage.toString();
					}
				}			
			}
			catch (Exception e) {
				throw e;
			}
			return DomainConstants.EMPTY_STRING;
		}
	 
	 
	 public Vector getTitle(Context context,String args[]) throws Exception
    {
        Vector vTitle = new Vector();
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();

			String strType = DomainConstants.EMPTY_STRING;
			String strId = DomainConstants.EMPTY_STRING;
			String strTitle = DomainConstants.EMPTY_STRING;
			StringBuilder sbMessage = new StringBuilder();
            while (objectListIterator.hasNext()) {
                Map<String,String> mapData = objectListIterator.next();
                strType = mapData.get(DomainConstants.SELECT_TYPE);
                strId = mapData.get(DomainConstants.SELECT_ID);
                strTitle = mapData.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
                if(TYPE_WMS_MEASUREMENT_TASK.equals(strType) || TYPE_WMS_SEGMENT.equals(strType)){
                    vTitle.add(strTitle);
                }else{
					sbMessage = new StringBuilder();
					String strLink = "../common/emxTree.jsp?objectId="+strId;
					sbMessage.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");            
					sbMessage.append(strTitle);
					sbMessage.append("</a>");
                    vTitle.add(sbMessage.toString());
				}
            }

        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return vTitle;

    }
	
	
	public void updateTitle(Context context, String[] args) throws Exception 
     {
		 boolean isContextPushed = false;
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sBOQId = (String)paramMap.get("objectId");
             String strNewValue = (String)paramMap.get("New Value");
			 
			 ContextUtil.pushContext(context);
			 isContextPushed = true;
			 DomainObject doBus = new DomainObject(sBOQId);
			 doBus.setAttributeValue(context,DomainObject.ATTRIBUTE_TITLE,strNewValue);
         }
         catch (Exception e) {
             throw e;
         }finally{
			 if(isContextPushed)
				 ContextUtil.popContext(context);
		 }
     }
	 
	 
	 public void updateQuantityOnBOQ(Context context, String[] args) throws Exception
		{
			boolean isContextPushed = false;
			try {
				String sObjectId = args[0];
				DomainObject doObj = null;
				if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
					StringList slBOQList = new StringList();
					Map mArgs=new HashMap();
					mArgs.put("objectId", sObjectId);
					MapList mlBOQItems = getSupplimentaryAgreementsBOQs(context,JPO.packArgs(mArgs));
					
					Map mTemp = null;
					String strType = DomainConstants.EMPTY_STRING;
					String strQty = DomainConstants.EMPTY_STRING;
					String strObjId = DomainConstants.EMPTY_STRING;
					DomainObject doBOQ = null;
					ContextUtil.pushContext(context);
					isContextPushed = true;
					for(int i=0;i<mlBOQItems.size();i++){
						mTemp = (Map)mlBOQItems.get(i);
						strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
						if(TYPE_WMS_MEASUREMENT_TASK.equals(strType)){							
							strObjId = (String)(String)mTemp.get(DomainObject.SELECT_ID);
							doBOQ = new DomainObject(strObjId);
							strQty = (String)doBOQ.getAttributeValue(context,ATTRIBUTE_WMS_TOTAL_QUANTITY);
							doBOQ.setAttributeValue(context,ATTRIBUTE_WMS_PREV_QUANTITY,strQty);
						}						
					}					
				}			
			}
			catch (Exception e) {
				throw e;
			}finally{
				if(isContextPushed)
					ContextUtil.popContext(context);
			}
		
		}
	 
	 
	 public int checkSupplimentaryAgreementApproved(Context context, String[] args) throws Exception
		{
			try {
				String sObjectId = args[0];
				DomainObject doObj = null;
				StringList slBOQList = new StringList();
				if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
					doObj = new DomainObject(sObjectId);
					StringList strListBusSelects = new StringList();
					strListBusSelects.add(DomainObject.SELECT_ID);
					strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
					strListBusSelects.add("attribute["+ATTRIBUTE_WMS_PREV_QUANTITY+"]");
					strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
					strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]");
					strListBusSelects.add("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
					strListBusSelects.add("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].tomid["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].from.id");
					strListBusSelects.add("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.to["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].from.current");
					
					StringList strListRelSelects = new StringList();
					strListRelSelects.add(DomainRelationship.SELECT_ID);
					
					MapList mlBOQList = doObj.getRelatedObjects(context, // matrix context
						RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS, // relationship pattern
						TYPE_WMS_MEASUREMENT_TASK, // type pattern
						strListBusSelects, // object selects
						strListRelSelects, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
						
						
					Map mTemp = null;
					String strMeasurementType = DomainConstants.EMPTY_STRING;
					String strPrevQty = DomainConstants.EMPTY_STRING;
					String strTotalQty = DomainConstants.EMPTY_STRING;
					String strMBEQty = DomainConstants.EMPTY_STRING;
					String strTitle = DomainConstants.EMPTY_STRING;
					
					Object oSuplAgreement = null;
					
					double dPrevQty = 0;
					double dTotalQty = 0;
					double dMBEQty = 0;
					for(int i=0;i<mlBOQList.size();i++){
						mTemp = (Map)mlBOQList.get(i);
						strMeasurementType = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]");
						strPrevQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_PREV_QUANTITY+"]");
						strTotalQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
						strMBEQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
						strTitle = (String)mTemp.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
						
						dPrevQty = Double.valueOf(strPrevQty);
						dTotalQty = Double.valueOf(strTotalQty);
						dMBEQty = Double.valueOf(strMBEQty);
						if("Non-Tender Items".equalsIgnoreCase(strMeasurementType)){
							StringList slStates = mTemp.get("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.to["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].from.current") instanceof StringList ? (StringList) mTemp.get("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.to["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].from.current") : new StringList((String)mTemp.get("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.to["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].from.current"));

							if(slStates.contains("Create") || slStates.contains("Review")){
								if(dMBEQty > dPrevQty){
									slBOQList.add(strTitle);
								}
							}							
						}
						if("Deviation".equalsIgnoreCase(strMeasurementType)){
							/*System.out.println("strTitle---"+strTitle);
							System.out.println("dMBEQty---"+dMBEQty);
							System.out.println("dPrevQty---"+dPrevQty);*/
							if(dPrevQty != 0 && dMBEQty > dPrevQty){
								slBOQList.add(strTitle);
							}
						}
					}					
				}		
				if(slBOQList.size()>0){
					StringBuilder sbMessage = new StringBuilder();
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.SupplementaryNotApproved");
					
					for(int i=0;i<slBOQList.size();i++){
						if(i==0){
							sbMessage.append((String)slBOQList.get(i));
						}else{
							sbMessage.append(",");
							sbMessage.append((String)slBOQList.get(i));
						}							
					}
					emxContextUtil_mxJPO.mqlNotice(context,strMessage+"\n"+sbMessage.toString());
					return 1;
					
				}
				
			}
			catch (Exception e) {
				throw e;
			}
			return 0;
		}
	 
	 
	 
	  @com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedActivitiesForMBE (Context context, String[] args) throws Exception 
     {
		 HashMap programMap = (HashMap) JPO.unpackArgs(args);
		 
		 String strObjectId = (String)programMap.get("objectId");
		 MapList mlFinalList = new MapList();
		 if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
			 DomainObject doAgreement = new DomainObject(strObjectId);
			 
			 String strSelectedType = doAgreement.getInfo(context,DomainObject.SELECT_TYPE);
			 
			 if(UIUtil.isNotNullAndNotEmpty(strSelectedType) && TYPE_WMS_SUPPLIMENTARY_AGREEMENT.equals(strSelectedType) == false){
				 emxContextUtil_mxJPO.mqlNotice(context,"Please select Agreement");
				 return mlFinalList;
			 }
			 
			 StringList slConnectedBOQs = doAgreement.getInfoList(context,"from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].to.id");
			 
			 String strWOId = doAgreement.getInfo(context,"to["+RELATIONSHIP_WMS_WORKORDER_SUPPLIMENTARY_AGREEMENT+"].from.id");
			 
			 DomainObject doWorkOder = new DomainObject(strWOId);
			 StringList strListBusSelects     = new StringList(3);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_TYPE);
			strListBusSelects.add("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
			strListBusSelects.add("attribute["+"WMSItemRateEscalation"+"].value");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");

			Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
			patternType.addPattern(TYPE_WMS_SEGMENT);
			patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK);
			 
			 MapList mapListObjects = doWorkOder.getRelatedObjects(context,
            	                     	                    RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
															patternType.getPattern(),                                    // object pattern
															false,                                                        // to direction
															true,                                                       // from direction
															(short)2,                                                      // recursion level
															strListBusSelects,                                                 // object selects
															null,                                                         // relationship selects
															DomainConstants.EMPTY_STRING,                                // object where clause
															DomainConstants.EMPTY_STRING,                                // relationship where clause
															(short)0,                                                      // No expand limit
															DomainConstants.EMPTY_STRING,                                // postRelPattern
															TYPE_WMS_MEASUREMENT_TASK+","+TYPE_WMS_SEGMENT, // postTypePattern
															null); 
			 
			 
			 
		Map mTemp = null;
		String strId = DomainConstants.EMPTY_STRING;
		String strMeasType = DomainConstants.EMPTY_STRING;
		for(int i=0;i<mapListObjects.size();i++){
			mTemp = (Map)mapListObjects.get(i);
			strId = (String)mTemp.get(DomainObject.SELECT_ID);
			strMeasType = (String)mTemp.get(DomainObject.SELECT_TYPE);
			if(slConnectedBOQs.contains(strId) == false){				
				if(TYPE_WMS_SEGMENT.equals(strMeasType)){
            		mTemp.put("disableSelection", "true");
				}
				mlFinalList.add(mTemp);
			}
		}
		 }
		 return mlFinalList;
     }
	 
	  @com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getExpandViewForChapter (Context context, String[] args) throws Exception 
     {
		 HashMap programMap = (HashMap) JPO.unpackArgs(args);
		 String strObjectId = (String)programMap.get("objectId");
		 String strParentId = (String)programMap.get("parentId");
		 MapList mlFinalList = new MapList();
		 if(UIUtil.isNotNullAndNotEmpty(strObjectId) && UIUtil.isNotNullAndNotEmpty(strParentId)){
			 DomainObject doAgreement = new DomainObject(strParentId);
			 StringList slConnectedBOQs = doAgreement.getInfoList(context,"from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].torel.to.id");
			 
			 DomainObject doWorkOder = new DomainObject(strObjectId);
			 StringList strListBusSelects     = new StringList(3);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_TYPE);
			strListBusSelects.add("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
			strListBusSelects.add("attribute["+"WMSItemRateEscalation"+"].value");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");

			Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
			patternType.addPattern(TYPE_WMS_SEGMENT);
			patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK);
			 
			 MapList mapListObjects = doWorkOder.getRelatedObjects(context,
            	                     	                    RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
															patternType.getPattern(),                                    // object pattern
															false,                                                        // to direction
															true,                                                       // from direction
															(short)2,                                                      // recursion level
															strListBusSelects,                                                 // object selects
															null,                                                         // relationship selects
															DomainConstants.EMPTY_STRING,                                // object where clause
															DomainConstants.EMPTY_STRING,                                // relationship where clause
															(short)0,                                                      // No expand limit
															DomainConstants.EMPTY_STRING,                                // postRelPattern
															TYPE_WMS_MEASUREMENT_TASK+","+TYPE_WMS_SEGMENT, // postTypePattern
															null); 
			 
			 
			 
		Map mTemp = null;
		String strId = DomainConstants.EMPTY_STRING;
		String strMeasType = DomainConstants.EMPTY_STRING;
		for(int i=0;i<mapListObjects.size();i++){
			mTemp = (Map)mapListObjects.get(i);
			strId = (String)mTemp.get(DomainObject.SELECT_ID);
			strMeasType = (String)mTemp.get(DomainObject.SELECT_TYPE);
			if(slConnectedBOQs.contains(strId) == false){				
				if(TYPE_WMS_SEGMENT.equals(strMeasType)){
            		mTemp.put("disableSelection", "true");
				}
				mlFinalList.add(mTemp);
			}
		}
		

     }
	  return mlFinalList;
	 
	}
	
	public StringList isRateEditable(Context context, String[] args)throws Exception{
	StringList slReturnList = new StringList();
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		MapList objectList = (MapList) programMap.get("objectList");
		Iterator<Map<String, String>> iteratorMap = objectList.iterator();
		Map<String, String> mapObjectData = new HashMap<String, String>();
		String strRelId = DomainConstants.EMPTY_STRING;
		String strType = DomainConstants.EMPTY_STRING;
		while (iteratorMap.hasNext()) {
			mapObjectData = iteratorMap.next();
			strType = (String)mapObjectData.get(DomainObject.SELECT_TYPE);
			if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
				strRelId = (String)mapObjectData.get("from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id");				
				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
					slReturnList.add("false");
				}else{
					slReturnList.add("true");
				}
			}else{
				slReturnList.add("false");
			}			
		}
		
	} catch (Exception exception) {
		System.out.println("Exception in isRateEditable method of JPO");
		exception.printStackTrace();
		throw exception;
	}

	return slReturnList;
}
	
	public boolean checkAccessForSupplementaryAgreement(Context context,String[] args)throws Exception{
		boolean bHasAccess = false;
		try{
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strObjectId = (String)programMap.get("objectId");
			
			String strContextUser = context.getUser();
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				String strSuppAgreementAccess = EnoviaResourceBundle.getProperty(context,"WMS.SupplementaryAgreement.CreateAccess");
				String strAccess = MqlUtil.mqlCommand(context,"print bus "+strObjectId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+strContextUser+"'].attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"].value dump");
				
				if(UIUtil.isNotNullAndNotEmpty(strAccess) && UIUtil.isNotNullAndNotEmpty(strSuppAgreementAccess) && strAccess.contains(strSuppAgreementAccess)){
					bHasAccess = true;
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return bHasAccess;
	}
	
	public void updateTitleForChapter(Context context,String[] args)throws Exception{
		boolean isContextPushed = false;
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sBOQId = (String)paramMap.get("objectId");
             String strNewValue = (String)paramMap.get("New Value");
			 ContextUtil.pushContext(context);
			
			 DomainObject doBus = new DomainObject(sBOQId);
			 String strType  = doBus.getInfo(context,DomainObject.SELECT_TYPE);
			 if(TYPE_WMS_SEGMENT.equals(strType)){ 
				isContextPushed = true;
				doBus.setAttributeValue(context,DomainObject.ATTRIBUTE_TITLE,strNewValue);
			 }
         }
         catch (Exception e) {
             throw e;
         }finally{
			 if(isContextPushed)
				 ContextUtil.popContext(context);
		 }
	}
	
	
	public Vector getItemHistory(Context context,String[] args) throws Exception
     {
    	Vector colVector = new Vector();
	     try { 
	     	 
	    	 String strURL="../wms/wmsSupplementaryHistory.jsp";
	    	 HashMap programMap         = (HashMap) JPO.unpackArgs(args);
			 HashMap paramList = (HashMap) programMap.get("paramList");
	    	 MapList objectList  = (MapList) programMap.get("objectList");
	    	 StringBuilder sb= null;
	    	 Iterator<Map> itr = objectList.iterator();
			 String strType = DomainConstants.EMPTY_STRING;
			 String strId = DomainConstants.EMPTY_STRING;
	    	 while(itr.hasNext()) {
	    		 Map m = itr.next();
				 strType = (String)m.get(DomainObject.SELECT_TYPE);
				 strId = (String)m.get(DomainObject.SELECT_ID);
				 sb=new StringBuilder();
				 if(strType.equals(TYPE_WMS_MEASUREMENT_TASK)){
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strId+"','600','400','false');\" >");            
					sb.append("<img border='0' title='History' src='../common/images/iconNewWindow.gif' height='15px' name='History' id='History' alt='History' onmouseover='openHistory()'/>");
					sb.append("</a>");
					sb.append("<script>");
					sb.append("function openHistory(){");
					sb.append("javascript:showModalDialog('"+strURL+"?objectId="+strId+"','600','400','false');");
					sb.append("}");
					sb.append("</script>");
				 }				
	    		 colVector.add(sb.toString());
	    	 }
	    	 
	    }catch(Exception e) {
	    	e.printStackTrace();
	    } 
	  return colVector;
     }
	
	
	
	@com.matrixone.apps.framework.ui.PostProcessCallable
    public Map updateSupplementalHistory(Context context, String[] args) throws Exception {
        HashMap mapReturnMap = new HashMap();
        try {
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
            HashMap hmTableData 			= (HashMap) programMap.get("tableData");
            HashMap hmRequestMap 			= (HashMap) programMap.get("requestMap");
			String strObjectid = (String)hmRequestMap.get("objectId");
			String strCurrentState = DomainConstants.EMPTY_STRING;
			
			MapList mlMeasList = new MapList();
			Map mMeasInfoMap = null;
			
            MapList mlObjectList 			= (MapList) hmTableData.get("ObjectList");
			
			String strPersonId = PersonUtil.getPersonObjectID(context);
			StringList slPersonSelect = new StringList();
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			
			DomainObject doPerson = new DomainObject(strPersonId);
			Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
			String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			
			if(UIUtil.isNullOrEmpty(strFirstName)){
				strFirstName = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strLastName)){
				strLastName = DomainConstants.EMPTY_STRING;
			}
			
			String strUser = strFirstName + " " +strLastName;
			
			if(mlObjectList != null){				
				String strTime  =  DomainConstants.EMPTY_STRING;
				String strRate = DomainConstants.EMPTY_STRING;
				String strQty = DomainConstants.EMPTY_STRING;
				String strUnit = DomainConstants.EMPTY_STRING;
				String strHistoryOld = DomainConstants.EMPTY_STRING;
				String strHistoryNew = DomainConstants.EMPTY_STRING;
				String strLastValue = DomainConstants.EMPTY_STRING;
				String strLastEntry = DomainConstants.EMPTY_STRING;
				String strType = DomainConstants.EMPTY_STRING;
				String strMeasId = DomainConstants.EMPTY_STRING;
				String strState = DomainConstants.EMPTY_STRING;
				
				Calendar calendarDate = Calendar.getInstance();
				String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
				SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
				strTime = formatter.format(calendarDate.getTime());
			
				Map mTemp = null;
				Map mObjInfo = null;
				
				int iOldHistoryEntrySize = 0;
				
				DomainObject doMeas = null;
				StringList slHistoryEntryList = new StringList();
			
				StringList slSelect = new StringList();
				slSelect.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY+"].value");
				
				for(int i=0;i<mlObjectList.size();i++){
					iOldHistoryEntrySize = 0;
					strQty = DomainConstants.EMPTY_STRING;
					strRate = DomainConstants.EMPTY_STRING;
					strUnit = DomainConstants.EMPTY_STRING;
					strLastEntry = DomainConstants.EMPTY_STRING;
					
					
					mTemp = (Map)mlObjectList.get(i);
					strType = (String)mTemp.get(DomainConstants.SELECT_TYPE);
					strState = (String)mTemp.get(DomainConstants.SELECT_CURRENT);
					
					if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENT_TASK.equals(strType) && "Active".equals(strState) == false){
						strMeasId = (String)mTemp.get(DomainConstants.SELECT_ID);	
						
						if(UIUtil.isNotNullAndNotEmpty(strMeasId)){
							doMeas = new DomainObject(strMeasId);
							mObjInfo = (Map)doMeas.getInfo(context,slSelect);
							if(mObjInfo != null && mObjInfo.isEmpty() == false){
								strQty = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
								strRate = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
								strUnit = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
								strHistoryOld = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY+"].value");
							}

							strHistoryNew = strUser+"|"+strTime+"|"+strUnit+"|"+strRate+"|"+strQty;
							strLastValue = strUnit+"|"+strRate+"|"+strQty;

							
							if(UIUtil.isNotNullAndNotEmpty(strHistoryNew)){
								if(UIUtil.isNullOrEmpty(strHistoryOld)){
									strHistoryOld = strHistoryNew;
								}else{
									slHistoryEntryList = FrameworkUtil.split(strHistoryOld, "\n");
									iOldHistoryEntrySize = slHistoryEntryList.size();
									strLastEntry = (String)slHistoryEntryList.get(iOldHistoryEntrySize-1);
									if(strLastEntry.startsWith(strUser)){
										slHistoryEntryList.remove(strLastEntry);
										slHistoryEntryList.add(iOldHistoryEntrySize-1,strHistoryNew);
										for(int k=0;k<slHistoryEntryList.size();k++){
											if(k==0){
												strHistoryOld = (String)slHistoryEntryList.get(k);
											}else{
												strHistoryOld = strHistoryOld +"\n"+(String)slHistoryEntryList.get(k);
											}
										}
									}else{
										if(strHistoryOld.endsWith(strLastValue)==false){
											strHistoryOld = strHistoryOld + "\n"+ strHistoryNew;
										}
									}
								}
								doMeas.setAttributeValue(context, ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY, strHistoryOld);
							}
						}
					}

				}
			}	
			
            mapReturnMap.put("Action","success");
        } catch (Exception exception) {
         exception.printStackTrace();
            mapReturnMap.put("Action","Stop");
            mapReturnMap.put("Message",exception.getMessage());
        }
        return mapReturnMap;
    }
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getSupplimentaryAgreementItems(Context context,String[]args) throws Exception
	{
		boolean bHasAccessToModify = false;
		MapList mapListAMBAdvances = new MapList();
		try
		{
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strObjectId = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{

				DomainObject domObj= DomainObject.newInstance(context, strObjectId);
				
				String mqlQuery = "print bus "+strObjectId+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
				String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
				String strContextUser = context.getUser();
				if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
					mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name dump";
					String strUser = MqlUtil.mqlCommand(context, mqlQuery);
					if(UIUtil.isNotNullAndNotEmpty(strUser) && strUser.contains(strContextUser)){
						bHasAccessToModify = true;
					}
				}
				
				
				StringList strListBusSelects = new StringList();
				strListBusSelects.add(DomainObject.SELECT_ID);
				strListBusSelects.add(DomainObject.SELECT_CURRENT);
				strListBusSelects.add(DomainObject.SELECT_TYPE);
				strListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				StringList strListRelSelects = new StringList();
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				
				MapList mlSegmentList = domObj.getRelatedObjects(context, // matrix context
                		                                    RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+","+RELATIONSHIP_BILL_OF_QUANTITY, // relationship pattern
															TYPE_WMS_SEGMENT+","+TYPE_WMS_MEASUREMENT_TASK,    
															strListBusSelects, // object selects
															strListRelSelects, // relationship selects
															false, // to direction
															true, // from direction
															(short) 1, // recursion level
															DomainConstants.EMPTY_STRING, // object where clause
															DomainConstants.EMPTY_STRING, // relationship where clause
															0);
				
				StringList strListOBJ = WMSUtil_mxJPO.convertToStringList(mlSegmentList, DomainRelationship.SELECT_ID);
				
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_CURRENT);
				slSelect.add(DomainObject.SELECT_TYPE);
				slSelect.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
				slSelect.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
				String [] objIds = new String[1];	
				objIds[0] = strObjectId;
				StringList slDeviationList = domObj.getInfoList(context,"from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id");
				
				String strTempId = DomainConstants.EMPTY_STRING;
				for(int k=0;k<strListOBJ.size();k++){
					strTempId = (String)strListOBJ.get(k);
					if(slDeviationList.contains(strTempId)){
						slDeviationList.remove(strTempId);
					}
				}
				
				String strCurrent = domObj.getInfo(context,DomainObject.SELECT_CURRENT);
				String strState = DomainConstants.EMPTY_STRING;
				String strType = DomainConstants.EMPTY_STRING;
				String strSOR = DomainConstants.EMPTY_STRING;
				String strQty = DomainConstants.EMPTY_STRING;
				String strTitle = DomainConstants.EMPTY_STRING;
				DomainObject doDev = null;
				 for(int i=0;i<slDeviationList.size();i++) {
                	String strDevRel = (String) slDeviationList.get(i);
					
					String strDevObjId = MqlUtil.mqlCommand(context, "print connection "+strDevRel+" select torel.to.id dump");
					strQty = MqlUtil.mqlCommand(context, "print connection "+strDevRel+" select attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"].value dump");
					doDev = new DomainObject(strDevObjId);
					
					Map m = (Map)doDev.getInfo(context,slSelect);

					strState = (String)m.get(DomainObject.SELECT_CURRENT);
					strType = (String)m.get(DomainObject.SELECT_TYPE);
					strSOR = (String)m.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
					strTitle = (String)m.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
					
					Map mTemp = new HashMap();
					mTemp.put(DomainObject.SELECT_ID,strDevObjId);
					mTemp.put(DomainObject.SELECT_TYPE,strType);
					mTemp.put(DomainRelationship.SELECT_ID,strDevRel);
					mTemp.put("attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"]",strQty);
					mTemp.put("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]",strSOR);
					mTemp.put("from["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].id",strDevRel);
					mTemp.put("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]",strTitle);
					mTemp.put(DomainObject.SELECT_CURRENT,strState);
					
					if(strCurrent.equalsIgnoreCase("Approved") || (strCurrent.equalsIgnoreCase("Review") && !bHasAccessToModify)) {
						mTemp.put("RowEditable", "readonly");
						if(!strCurrent.equalsIgnoreCase("Create"))
							mTemp.put("disableSelection", "true");
					}
					
					mapListAMBAdvances.add(mTemp);
				}
				
				for(int j=0;j<mlSegmentList.size();j++){
					Map mTempMap = (Map)mlSegmentList.get(j);
					if(strCurrent.equalsIgnoreCase("Approved") || (strCurrent.equalsIgnoreCase("Review") && !bHasAccessToModify)) {
						mTempMap.put("RowEditable", "readonly");
						if(!strCurrent.equalsIgnoreCase("Create"))
							mTempMap.put("disableSelection", "true");
					}
					mapListAMBAdvances.add(mTempMap);
				}
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in getSupplimentaryAgreementItems method of JPO WMSSupplimentaryAgreement");
			exception.printStackTrace();
			throw exception;
		}
		return mapListAMBAdvances;
	}
	
	
	public Vector getRouteDetails(Context context,String[] args) throws Exception {
		Vector colVector = new Vector();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramList = (HashMap) programMap.get("paramList");
			MapList objectList  = (MapList) programMap.get("objectList");
			StringBuilder sb= null;
			Iterator<Map> itr = objectList.iterator();
			String strId = DomainConstants.EMPTY_STRING;
			String strType = DomainConstants.EMPTY_STRING;
			String strCurrent = DomainConstants.EMPTY_STRING;
			String strObjId = DomainConstants.EMPTY_STRING;
			String strObjName = DomainConstants.EMPTY_STRING;
			DomainObject doObject = null;
			MapList mlExtRoutes = null;
			String sWhere = DomainConstants.EMPTY_STRING;
			Map oMap = null;
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			while(itr.hasNext()) {
				Map m = itr.next();
				strId = (String)m.get(DomainObject.SELECT_ID);
				strCurrent = (String)m.get(DomainObject.SELECT_CURRENT);
				strType = (String)m.get(DomainObject.SELECT_TYPE);
				doObject = new DomainObject(strId);
				
				if("WMSSupplimentaryAgreement".equals(strType)){
					if ("Create".equals(strCurrent)) {
						sWhere = "current != Complete";
						mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
															DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
															DomainConstants.TYPE_ROUTE, // type pattern
															busSelects, // object selects
															null, // relationship selects
															false, // to direction
															true, // from direction
															(short) 1, // recursion level
															sWhere, // object where clause
															null); // relationship where clause
						sb=new StringBuilder();
						if (mlExtRoutes.size() == 1) {
							String strURL="../common/emxTree.jsp";
							oMap = (Map) mlExtRoutes.get(0);
							strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
							strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
							sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
							sb.append(strObjName);
							sb.append("</a>");
						} else if (mlExtRoutes.size() == 0) {
							String strURL="../wms/wmsRouteCreationDialogFS.jsp?";
							
							if(TYPE_WMSTECHNICALSANCTION.equals(strType) || TYPE_WMSAEMASTER.equals(strType) || TYPE_WMSRICMASTER.equals(strType) || "WMSFundRelease".equals(strType) ||"WMSFundRequest".equals(strType) || "WMSSupplimentaryAgreement".equals(strType) ) {
								strURL = strURL+"wmsSearch=all";
							} else {
								strURL = strURL+"wmsSearch=organization";
							}
							//String strURL="../wms/wmsRouteCreationDialogFS.jsp?WMSSearch=all";
							sb.append("<a href=\"javascript:showModalDialog('"+strURL+"%26objectId="+strId+"','600','400','false');\" >");            
							//sb.append("<img border='0' title='Route' src='../common/images/iconSmallRoute.png' height='15px' name='Route' id='Route' alt='Route'/>");
							sb.append("Create Route");
							sb.append("</a>");
						}
					} else {
						mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
															DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
															DomainConstants.TYPE_ROUTE, // type pattern
															busSelects, // object selects
															null, // relationship selects
															false, // to direction
															true, // from direction
															(short) 1, // recursion level
															null, // object where clause
															null); // relationship where clause
						mlExtRoutes.sort("originated", "descending", "date");
						sb=new StringBuilder();
						if (mlExtRoutes.size() > 0) {
							String strURL="../common/emxTree.jsp";
							oMap = (Map) mlExtRoutes.get(0);
							strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
							strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
							sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
							sb.append(strObjName);
							sb.append("</a>");
						}
					}
				}else{
					sb=new StringBuilder();
				}
				colVector.add(sb.toString());
			}
			 
		} catch(Exception e) {
			e.printStackTrace();
		}
		return colVector;
	}
	
	 }