
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UICache;
import com.matrixone.apps.framework.ui.UITableIndented;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.Policy;
import matrix.util.StringList;

import com.matrixone.jdom.Element;

import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;

public class WMSVendorManagement_mxJPO extends WMSConstants_mxJPO {
	
	public WMSVendorManagement_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getVendorRatings(Context context,String args[]) throws Exception 
	{
		try {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sObjectId = (String) programMap.get("objectId");
			StringList busSelects = new StringList(1);
			busSelects.add(DomainConstants.SELECT_ID);
			DomainObject doVendor = DomainObject.newInstance(context, sObjectId);
			MapList mlVendorRatings = doVendor.getRelatedObjects(context, // matrix context
																RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR, // relationship pattern
																TYPE_WMS_WORK_ORDER, // type pattern
																busSelects, // object selects
																null, // relationship selects
																false, // to direction
																true, // from direction
																(short) 1, // recursion level
																null, // object where clause
																null); // relationship where clause
			return mlVendorRatings;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public Vector getVendorRating(Context context, String[] args) throws Exception
	{
		Vector vReturn = new Vector();
		HashMap programMap  = (HashMap) JPO.unpackArgs(args);
		HashMap columnMap   = (HashMap) programMap.get("columnMap");
		HashMap settings    = (HashMap) columnMap.get("settings"); 
		MapList mlObjects   = (MapList) programMap.get("objectList");
		
		String strAttributeName = (String)settings.get("Attribute Name");
		Integer iRedIf = Integer.parseInt((String)settings.get("redif"));
		
		int iSize = mlObjects.size();
		DomainObject doWorkOrder = DomainObject.newInstance(context);
		Integer iAttributeValue = 0;
		
		for (int i = 0 ; i < iSize ; i++)
		{
			String strHTMLString = new String();
			doWorkOrder.setId((String)((Map)mlObjects.get(i)).get("id"));
			iAttributeValue = Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+strAttributeName+"]"));
			if (iAttributeValue < iRedIf)
			{
				strHTMLString = "<font color=\"red\"><h2>"+iAttributeValue+"</h2></font>";
			}
			else
			{
				strHTMLString = "<font color=\"green\"><h2>"+iAttributeValue+"</h2></font>";
			}
			vReturn.add(strHTMLString);
		}
		return vReturn;
	}
	public Vector getTotalVendorRating(Context context, String[] args) throws Exception
	{
		Vector vReturn = new Vector();
		HashMap programMap  = (HashMap) JPO.unpackArgs(args);
		MapList mlObjects   = (MapList) programMap.get("objectList");

		int iSize = mlObjects.size();
		DomainObject doWorkOrder = DomainObject.newInstance(context);
		Integer iTotalValue = 0;

		for (int i = 0 ; i < iSize ; i++)
		{
			String strHTMLString = new String();
			doWorkOrder.setId((String)((Map)mlObjects.get(i)).get("id"));

			iTotalValue = Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_DELIVERY+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_ENV_FRIENDLY+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_PERFORMANCE+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_QC_COMPLIANCE+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_QUALITY+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_SAFETY+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_SECURITY+"]"));

			if (iTotalValue < 50)
			{
				strHTMLString = "<font color=\"red\"><h2>"+iTotalValue+" (Unsatisfactory)</h2></font>";
			}
			else if (iTotalValue >50 && iTotalValue <64)
			{
				strHTMLString = "<font color=\"blue\"><h2>"+iTotalValue+" (Average)</h2></font>";
			}
			else if (iTotalValue >64 && iTotalValue <79)
			{
				strHTMLString = "<font color=\"yellow\"><h2>"+iTotalValue+" (Good)</h2></font>";
			}
			else
			{
				strHTMLString = "<font color=\"green\"><h2>"+iTotalValue+" (Very Good)</h2></font>";
			}
			vReturn.add(strHTMLString);
		}
		return vReturn;
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public String getTotalRatingValue(Context context,String args[]) throws Exception 
	{
		try {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sObjectId = (String) paramMap.get("objectId");
			
			DomainObject doWorkOrder = DomainObject.newInstance(context, sObjectId);
			
			Integer iTotal = Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_DELIVERY+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_ENV_FRIENDLY+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_PERFORMANCE+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_QC_COMPLIANCE+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_QUALITY+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_SAFETY+"]")) + Integer.parseInt((String)doWorkOrder.getInfo(context, "attribute["+ATTRIBUTE_WMS_VENDOR_RATING_SECURITY+"]"));
			
			return String.valueOf(iTotal);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public static MapList getCompaniesByDate(Context context, String args[]) throws Exception
	{
		String sDate = args[0];
		StringList slDateChunks = FrameworkUtil.split(sDate,"-");
		if(slDateChunks != null && !slDateChunks.isEmpty())
		{
			String sYear=slDateChunks.get(0);
			String sMonth = slDateChunks.get(1);
			String sDay = slDateChunks.get(2);
			sDate = sMonth+"/"+sDay+"/"+sYear;
		}
		StringList slCompanySels = new StringList();
		slCompanySels.add(DomainConstants.SELECT_NAME);
		slCompanySels.add("attribute[WMSVenderTransactioncode]");
		slCompanySels.add("attribute[Primary Key]");
		slCompanySels.add("attribute[Address]");
		slCompanySels.add("attribute[WMSCity]");
		slCompanySels.add("attribute[WMSState]");
		slCompanySels.add("attribute[Postal Code]");
		slCompanySels.add("attribute[WMSCountryCode]");
		slCompanySels.add("attribute[WMSPanNumber]");
		slCompanySels.add("attribute[WMSGSNNumber]");
		slCompanySels.add("attribute[WMSDateOfInroduction]");
		slCompanySels.add("attribute[WMSRegistrationValidUpto]");
		slCompanySels.add("attribute[WMSIFSCCode]");
		slCompanySels.add("attribute[WMSBankAccountNumber]");
		slCompanySels.add("attribute[WMSAccountHolder]");
		slCompanySels.add("attribute[WMSBankName]");
		slCompanySels.add("attribute[WMSCurrency]");
		String sWhere = "";
		MapList mlCompanies = new MapList();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		if(UIUtil.isNotNullAndNotEmpty(sDate) && sDate.contains("/"))
		{
			Date dSelected = sdf.parse(sDate);
			String sDateStartRange = "\'"+sdf.format(dSelected)+" 12:00:00 AM\'";
			String sDateEndRange = "\'"+sdf.format(dSelected)+" 11:59:59 PM\'";			
			sWhere = "attribute[WMSDateOfInroduction] >= "+sDateStartRange+" && attribute[WMSDateOfInroduction] <= "+sDateEndRange+"";
			mlCompanies = DomainObject.findObjects(context,
													"Company",
													"*",
													"*",
													"*",
													"*",
													sWhere,//where
													"",
													true,
													slCompanySels,
													(short)0);			
		}
		return mlCompanies;
	}
}