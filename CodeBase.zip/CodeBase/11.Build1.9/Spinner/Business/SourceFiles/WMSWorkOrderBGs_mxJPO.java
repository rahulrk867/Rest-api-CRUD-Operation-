/**
 *  ${CLASSNAME}.java
 *
 * (c) Dassault Systemes, 1993 - 2017. All rights reserved.
 * This program contains proprietary and trade secret information of
 * ENOVIA MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
 import java.util.HashMap;
 import java.util.Map;
 import java.text.SimpleDateFormat;
 import java.util.Vector;
 import java.util.Iterator;
 import java.text.DecimalFormat;
 import java.util.Date;
 import java.util.Locale;
 
 import matrix.db.Context;
 import matrix.db.JPO;
 import matrix.util.StringList;
 import java.math.BigDecimal;

 
 import com.matrixone.jdom.Element;
 import com.matrixone.apps.domain.util.MapList;
 import com.matrixone.apps.domain.DomainRelationship;
 import com.matrixone.apps.domain.DomainConstants;
 import com.matrixone.apps.domain.DomainObject;
 import com.matrixone.apps.framework.ui.UITableIndented;
 import com.matrixone.apps.domain.util.eMatrixDateFormat;
 import com.matrixone.apps.domain.util.FrameworkUtil;
 import com.matrixone.apps.framework.ui.UIUtil;
 import com.matrixone.apps.domain.util.EnoviaResourceBundle;
 import com.matrixone.apps.domain.util.ContextUtil;
 import com.matrixone.apps.domain.util.PersonUtil;
 
 /**
 * This JPO includes the code related to the Approval History Functionality
 */
public class WMSWorkOrderBGs_mxJPO extends WMSConstants_mxJPO
{

 /**
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments
     * @throws Exception if the operation fails
     * @grade 0
     */
    public WMSWorkOrderBGs_mxJPO (Context context, String[] args) throws Exception
    {
		super(context,args);
    }
  /**
     * Method is used to populate the data for Royalty Charges page
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args The packed argument for JPO, containing the program map.
     *             This program map will have request parameter information, objectId and information about the UI table object.
     * @return MapList of data
     * @throws Exception
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getAllBGsConnectedToWO(Context context, String[] args) throws Exception {
		MapList mlBGs = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");
			String strContextUser = context.getUser();
            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add("attribute[Title]");
				slObjectSelects.add("attribute[Rate]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_WO_AGREEMENT_DATE+"]");
				slObjectSelects.add(DomainObject.SELECT_OWNER);
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_SUPP_AGREEMENT_DATE+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_REMARK+"]");
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
                MapList otherAdditions = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_BG,
															TYPE_WMS_BG,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
															
				Map mTemp = null;
				String strOwner = DomainConstants.EMPTY_STRING;
				String strValidity = DomainConstants.EMPTY_STRING;
				
				Date dToday = new Date();
				SimpleDateFormat simpleDateFormatMatrix  = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(),context.getLocale());
				for(int i=0;i<otherAdditions.size();i++){
					mTemp = (Map)otherAdditions.get(i);
					strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
					strValidity = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_WO_AGREEMENT_DATE+"]");
					if(strContextUser.equals(strOwner) == false){
						mTemp.put("RowEditable", "readonly");
               			mTemp.put("disableSelection", "true");
					}	
					if(UIUtil.isNotNullAndNotEmpty(strValidity)){
						Date dValidty=simpleDateFormatMatrix.parse(strValidity);	
						if(dToday.after(dValidty)){
							mTemp.put("styleRows", "ResourcePlanningRedBackGroundColor");
						}
					}
					
					mlBGs.add(mTemp);
				}
				
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlBGs;
	}
	
 /**
     * To create a SOR Library
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds the following input arguments
     *      0 - requestMap
     * @return Map contains created objectId
     * @throws Exception
     */
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public HashMap createBG(Context context, String [] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Map paramMap = (Map) programMap.get("paramMap");
		String sObjectId=(String)paramMap.get("objectId");

		String sRowId = "" ;
		String strNewObject = "";

		HashMap columnsMap;
		HashMap changedRowMap;
		HashMap doc = new HashMap();
		HashMap retMap;
		DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
		DomainObject doAdvancObject = DomainObject.newInstance(context);

		Element elm = (Element) programMap.get("contextData");        
		MapList mlItems = new MapList();
		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		Map mapAttr = new HashMap();     

		for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
		{
			try
			{   
				retMap = new HashMap();
				changedRowMap = (HashMap) chgRowsMapList.get(i);
				columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");

				String strTitle = (String) columnsMap.get("Title");
				String strDesc = (String) columnsMap.get("Description");
				String strValue = (String) columnsMap.get("Value");
				String strValidity = (String) columnsMap.get("Validity");
				String strBGDate = (String) columnsMap.get("BGDate");
				String strTypeOfBG = (String) columnsMap.get("TypeOfBG");
				
				Date dCompletionDate = new Date(strValidity);
				long lCompletionTime = dCompletionDate.getTime();
		   
				Date dBGDate = new Date(strBGDate);
				long lBGTime = dBGDate.getTime();
			
				//use MatrixDateFormat's pattern
				SimpleDateFormat mxDateFrmt = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
				String strFormattedCompletionDate = mxDateFrmt.format(lCompletionTime);
				String strBGFormattedDate = mxDateFrmt.format(lBGTime);
			
				strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
						"type_WMSBankGuarantees",
						"",
						"policy_WMSBankGuarantees",
						context.getVault().getName(),
						"-"
						);
				
				DomainRelationship domRel   = doAdvancObject.createAndConnect(context,
						TYPE_WMS_BG,
						strNewObject,
						"-",
					    POLICY_WMS_BG,
						null,
						RELATIONSHIP_WMS_BG,
						domAmbObject,
						true);

				mapAttr = new HashMap();
				if (strValue != null && !"".equals(strValue)) {
					mapAttr.put("Rate", strValue);
				}
				if (strTitle != null && !"".equals(strTitle)) {
					mapAttr.put("Title", strTitle);
				}
				if (strFormattedCompletionDate != null && !"".equals(strFormattedCompletionDate)) {
					mapAttr.put(ATTRIBUTE_WMS_WO_AGREEMENT_DATE, strFormattedCompletionDate);
				}
				if (strBGFormattedDate != null && !"".equals(strBGFormattedDate)) {
					mapAttr.put(ATTRIBUTE_WMS_SUPP_AGREEMENT_DATE, strBGFormattedDate);
				}
				if (strTypeOfBG != null && !"".equals(strTypeOfBG)) {
					mapAttr.put(ATTRIBUTE_WMS_REMARK, strTypeOfBG);
				}
				if (strDesc != null && !"".equals(strDesc)) {
					doAdvancObject.setDescription(context,strDesc);
				}
				doAdvancObject.setAttributeValues(context,mapAttr);
				retMap = new HashMap();
				retMap.put("oid", doAdvancObject.getObjectId(context));
				retMap.put("relid", domRel.toString());
				retMap.put("pid", "");
				retMap.put("rid", "");
				retMap.put("markup", "new");
				retMap.put("rowId", sRowId);
				columnsMap.putAll(retMap);
				retMap.put("columns", columnsMap);
				mlItems.add(retMap);
				doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
				doc.put("Action", "success"); // Here the action can be "Success" or "refresh"
			}
			catch(Exception Ex)
			{
				Ex.printStackTrace();
				throw Ex;
			}
		}
		return doc;
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAllBGsForContract(Context context, String[] args)throws Exception{
		MapList mlBGs = new MapList();
		boolean bIsContextPushed = false;
		try{
			ContextUtil.pushContext(context);
			bIsContextPushed = true;
			
			StringList slObjectSelect = new StringList();
			slObjectSelect.add(DomainObject.SELECT_ID);
			slObjectSelect.add(DomainObject.SELECT_DESCRIPTION);
			slObjectSelect.add("attribute["+ATTRIBUTE_WMS_SUPP_AGREEMENT_DATE+"]");
			slObjectSelect.add("attribute["+ATTRIBUTE_WMS_WO_AGREEMENT_DATE+"]");
			slObjectSelect.add("attribute["+ATTRIBUTE_WMS_REMARK+"]");
			slObjectSelect.add("attribute[Title]");
			slObjectSelect.add("attribute[Rate]");
			slObjectSelect.add("to[WMSWorkOrderBG].from.id");
			slObjectSelect.add("to[WMSWorkOrderBG].from.attribute[WMSDepartment].value");
			slObjectSelect.add("to[WMSWorkOrderBG].from.attribute[WMSWorkorderTitle].value");
			
			String strWhere = "to[WMSWorkOrderBG]==TRUE";
			
			MapList mlBankGuaranteeList = DomainObject.findObjects(context, TYPE_WMS_BG, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					strWhere, // where clause
					slObjectSelect);
					
			Date today = new Date();
			String strExpiryReminder = EnoviaResourceBundle.getProperty(context,"WMS.BG.ExpiryReminder.Duration");
			int iDuration = Integer.parseInt(strExpiryReminder);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			
			Map mTemp = null;
			
			for(int i=0;i<mlBankGuaranteeList.size();i++){
				mTemp = (Map)mlBankGuaranteeList.get(i);
				Date dBGExpdate = sdf.parse((String)mTemp.get("attribute["+ATTRIBUTE_WMS_WO_AGREEMENT_DATE+"]"));
				int diffInDays = (int) ((dBGExpdate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
				if(diffInDays >=0 && diffInDays < iDuration){
					mTemp.put("Expiry","Soon");
				}else if(diffInDays < 0){
					mTemp.put("Expiry","Expired");
				}else{
					mTemp.put("Expiry","NA");
				}
				mlBGs.add(mTemp);
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(bIsContextPushed)
				ContextUtil.popContext(context);
		}
		
		return mlBGs;
		
	}
	
	public boolean getAccessForBGReport(Context context, String[] args)throws Exception{
		boolean bHasAccess = false;
		try{
			String strPersonId = PersonUtil.getPersonObjectID(context);
			DomainObject doPerson = DomainObject.newInstance(context,strPersonId);
			String strHostRole = (String)doPerson.getAttributeValue(context,"HostPersonRole");
			
			String strBGReportRole = EnoviaResourceBundle.getProperty(context,"WMS.BG.Report.AccessRole");
			StringList slBGRoles = FrameworkUtil.split(strBGReportRole,",");
			
			if(UIUtil.isNotNullAndNotEmpty(strHostRole) && slBGRoles.contains(strHostRole)){
				bHasAccess = true;
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return bHasAccess;
	}
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getBGFilterWise(Context context, String[] args)throws Exception{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String strWhere = (String)programMap.get("Bgwhere");
		MapList mlBGs = new MapList();
		boolean bIsContextPushed = false;
		try{
			ContextUtil.pushContext(context);
			bIsContextPushed = true;
			
			StringList slObjectSelect = new StringList();
			slObjectSelect.add(DomainObject.SELECT_ID);
			slObjectSelect.add(DomainObject.SELECT_DESCRIPTION);
			slObjectSelect.add("attribute["+ATTRIBUTE_WMS_SUPP_AGREEMENT_DATE+"]");
			slObjectSelect.add("attribute["+ATTRIBUTE_WMS_WO_AGREEMENT_DATE+"]");
			slObjectSelect.add("attribute["+ATTRIBUTE_WMS_REMARK+"]");
			slObjectSelect.add("attribute[Title]");
			slObjectSelect.add("attribute[Rate]");
			slObjectSelect.add("to[WMSWorkOrderBG].from.id");
			slObjectSelect.add("to[WMSWorkOrderBG].from.attribute[WMSDepartment].value");
			slObjectSelect.add("to[WMSWorkOrderBG].from.attribute[WMSWorkorderTitle].value");
			
			String strWhere1 = "to[WMSWorkOrderBG]==TRUE";
			String strWhereFinal = strWhere + "&&" + strWhere1;
			
			MapList mlBankGuaranteeList = DomainObject.findObjects(context, TYPE_WMS_BG, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					strWhereFinal, // where clause
					slObjectSelect);
					
			Date today = new Date();
			String strExpiryReminder = EnoviaResourceBundle.getProperty(context,"WMS.BG.ExpiryReminder.Duration");
			int iDuration = Integer.parseInt(strExpiryReminder);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			
			Map mTemp = null;
			
			for(int i=0;i<mlBankGuaranteeList.size();i++){
				mTemp = (Map)mlBankGuaranteeList.get(i);
				Date dBGExpdate = sdf.parse((String)mTemp.get("attribute["+ATTRIBUTE_WMS_WO_AGREEMENT_DATE+"]"));
				int diffInDays = (int) ((dBGExpdate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
				if(diffInDays >=0 && diffInDays < iDuration){
					mTemp.put("Expiry","Soon");
				}else if(diffInDays < 0){
					mTemp.put("Expiry","Expired");
				}else{
					mTemp.put("Expiry","NA");
				}
				mlBGs.add(mTemp);
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(bIsContextPushed)
				ContextUtil.popContext(context);
		}
		
		return mlBGs;
		
	}
	
}