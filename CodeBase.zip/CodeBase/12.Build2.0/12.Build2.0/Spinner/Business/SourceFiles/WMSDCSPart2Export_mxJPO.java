import com.matrixone.apps.domain.util.MailUtil;
import org.joda.time.LocalDate;
import org.joda.time.Days;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Calendar;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import java.text.DateFormat;

import matrix.util.Pattern;
import matrix.util.StringList;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.Page;
import java.util.Vector;
import java.text.DecimalFormat;
import java.lang.Math;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.PersonUtil;

public class WMSDCSPart2Export_mxJPO extends WMSConstants_mxJPO
{
    /**
     * Constructor.
     * @param context - the eMatrix <code>Context</code> object
     * @param args - holds no arguments
     * @throws Exception if the operation fails
     * @author DSIS
     */

    public WMSDCSPart2Export_mxJPO(Context context, String[] args) throws Exception
    {
       super(context,args);
    }
    @com.matrixone.apps.framework.ui.ProgramCallable
    public HashMap getDCSPart2Details (Context context, String[] args) throws Exception
    {
		 HashMap hmReturnMap = new HashMap();
		try{
	  HashMap programMap = (HashMap) JPO.unpackArgs(args);
	  String strTSId = (String)programMap.get("objectId");
	  
      //get TS Details
      DomainObject doTS = DomainObject.newInstance(context, strTSId);
      StringList slTSSels = new StringList(2);
      slTSSels.addElement("to[WMSDCSTS].from.id"); // dcs master id
      slTSSels.addElement("to[WMSSOCTS].from.id"); //soc id
      slTSSels.addElement("to[WMSDCSTS].from.owner"); // dcs master owner
      slTSSels.addElement("to[WMSSOCTS].from.to[WMSProjectSOC].from.name"); //name of project
      slTSSels.addElement("to[WMSDCSTS].from.attribute[Title].value"); // name of sub project
      Map mDetails = doTS.getInfo(context, slTSSels);

      //get Admin Approval Details
      String strAAId = MqlUtil.mqlCommand(context, "print bus " +  (String)mDetails.get("to[WMSSOCTS].from.id") + " select from[WMSSOCAdminApproval|to.revision==to.last && to.current==Approved].to.id dump");
      String strAAString = getAdminApprovalDetails(context, strAAId);

      //get Delegation Details
      String strDelegationId = MqlUtil.mqlCommand(context, "print bus " +  (String)mDetails.get("to[WMSSOCTS].from.id") + " select from[WMSSOCDelegation|to.revision==to.last && to.current==Delegate].to.id dump");

      String strDelegationString = getDelegationDetails(context, strDelegationId, (String)mDetails.get("to[WMSDCSTS].from.owner"));

      //get Item Details
      DomainObject doDCSMaster = DomainObject.newInstance(context,  (String)mDetails.get("to[WMSDCSTS].from.id"));
      StringList slDCSSels = new StringList();
      slDCSSels.addElement("attribute[Quantity].value");
      slDCSSels.addElement("attribute[WMSGST].value");
      slDCSSels.addElement("attribute[Rate].value");
      slDCSSels.addElement("attribute[WMSUnitOfMeasure].value");
	  slDCSSels.addElement("attribute[WMSItemSequence].value");
	  slDCSSels.addElement("description");

      MapList mlDCSPart2Details = doDCSMaster.getRelatedObjects(context,
    																													 "WMSDCSMasterDCS,WMSDCSDCSItem",
    																													 "WMSDCS,WMSDCSItem",
    																													 slDCSSels,
    																													 null,
    																													 false,
    																													 true,
    																													 (short)0,
    																													 null,
    																													 null);

     
      hmReturnMap.put("projectname", (String)mDetails.get("to[WMSSOCTS].from.to[WMSProjectSOC].from.name"));
      hmReturnMap.put("subprojectname", (String)mDetails.get("to[WMSDCSTS].from.attribute[Title].value"));
      hmReturnMap.put("aadetails", strAAString);
      hmReturnMap.put("deldetails", strDelegationString);
      hmReturnMap.put("itemdetails", mlDCSPart2Details);
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
      return hmReturnMap;
    }
    public String getAdminApprovalDetails(Context context, String strAAId) throws Exception
    {
      DomainObject doAA = DomainObject.newInstance(context, strAAId);
      StringList slAADetailsSels = new StringList();
      slAADetailsSels.addElement("attribute[WMSLetterNumber].value");
      slAADetailsSels.addElement("attribute[WMSAdminApprovalAmount].value");
      slAADetailsSels.addElement("attribute[WMSAdminApprovalDate].value");
      Map mAADetails = doAA.getInfo(context, slAADetailsSels);

      SimpleDateFormat sdfFrom = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
  		Date dAdminApprovalDate = sdfFrom.parse((String)mAADetails.get("attribute[WMSAdminApprovalDate].value"));
      SimpleDateFormat sdfTo = new SimpleDateFormat("dd/MM/yyyy");
  		String strAAFormatedDate = sdfTo.format(dAdminApprovalDate);

      String strReturnString = (String)mAADetails.get("attribute[WMSLetterNumber].value") +","+strAAFormatedDate+","+WMSUtil_mxJPO.converToIndianCurrency(context, Double.valueOf((String)mAADetails.get("attribute[WMSAdminApprovalAmount].value")));
      return strReturnString;
    }
    static public String getDelegationDetails(Context context, String strDelegationId, String strDCSOwner) throws Exception
    {
      DomainObject doDelegation = DomainObject.newInstance(context, strDelegationId);

      String strWorksOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Works");
			String strEqupmentsOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Equipments");
			String strPlanningOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Planning");
      String defaultOrg = PersonUtil.getDefaultOrganization(context, strDCSOwner);

      StringList slDelSels = new StringList();
      slDelSels.addElement("attribute[WMSApprovedAmountWork].value");
      slDelSels.addElement("attribute[WMSWorksContingency].value");
      slDelSels.addElement("attribute[WMSApprovedAmountEquipment].value");
      slDelSels.addElement("attribute[WMSEquipmentsContingency].value");
      slDelSels.addElement("attribute[WMSDelegationLetterNumber].value"); //delegation letter number
      slDelSels.addElement("state[Delegate].actual");
      Map mDelDetails = doDelegation.getInfo(context, slDelSels);

      //get delegation date
      SimpleDateFormat sdfFrom = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
		Date dDelegationApprovalDate = sdfFrom.parse((String)mDelDetails.get("state[Delegate].actual"));
      SimpleDateFormat sdfTo = new SimpleDateFormat("dd/MM/yyyy");
  		String strDelegationFormatedApprovalDate = sdfTo.format(dDelegationApprovalDate);

      //get other item details
      StringList slOtherSels = new StringList();
      slOtherSels.addElement("attribute[WMSWorksDelegationAmount].value");
      slOtherSels.addElement("attribute[WMSEquipmentDelegationAmount].value");
      slOtherSels.addElement("attribute[WMSPlanningDelegationAmount].value");
      MapList mlOthers = doDelegation.getRelatedObjects(context,
														 "WMSDelegationOtherItems",
														 "WMSAE",
														 null,
														 slOtherSels,
														 false,
														 true,
														 (short)1,
														 null,
														 null);
      double dDelegationAmount = 0.0;
      if(strWorksOrgName.equals(defaultOrg))
      {
        dDelegationAmount += Double.valueOf((String)mDelDetails.get("attribute[WMSApprovedAmountWork].value")) + Double.valueOf((String)mDelDetails.get("attribute[WMSWorksContingency].value"));
      }
      else if (strEqupmentsOrgName.equals(defaultOrg))
      {
        dDelegationAmount += Double.valueOf((String)mDelDetails.get("attribute[WMSApprovedAmountEquipment].value")) + Double.valueOf((String)mDelDetails.get("attribute[WMSEquipmentsContingency].value"));
      }
      int iSize = mlOthers.size();
      for(int i = 0 ; i < iSize ; i++)
      {
        if(strWorksOrgName.equals(defaultOrg))
        {
          dDelegationAmount += Double.valueOf((String)((Map)mlOthers.get(i)).get("attribute[WMSWorksDelegationAmount].value"));
        }
        else if (strEqupmentsOrgName.equals(defaultOrg))
        {
          dDelegationAmount += Double.valueOf((String)((Map)mlOthers.get(i)).get("attribute[WMSEquipmentDelegationAmount].value"));
        }
		  else if (strPlanningOrgName.equals(defaultOrg))
        {
          dDelegationAmount += Double.valueOf((String)((Map)mlOthers.get(i)).get("attribute[WMSPlanningDelegationAmount].value"));
        }
      }
      String strReturnString = (String)mDelDetails.get("attribute[WMSDelegationLetterNumber].value") + "," + strDelegationFormatedApprovalDate + "," + WMSUtil_mxJPO.converToIndianCurrency(context, dDelegationAmount);
      return strReturnString;
    }
}
