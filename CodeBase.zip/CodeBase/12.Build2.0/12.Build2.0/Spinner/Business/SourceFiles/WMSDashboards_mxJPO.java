/** Name of the JPO    : WMSDashboards
 ** Developed by    :  
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to update/get data for dashboards.
 ** Revision Log:
 ** ---------------------------------------------------------------------------------------------------------------
 ** Author						Modified Date				History
 ** azr2						24th March, 19				add method to get cost details of work order
 ** ---------------------------------------------------------------------------------------------------------------
 ** ---------------------------------------------------------------------------------------------------------------
 **/

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.Date;
import java.util.Locale;
import java.text.SimpleDateFormat;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import java.text.DateFormat;
import java.util.Calendar;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

/**
 * The purpose of this JPO is to update/get data for dashboards.
 * @author azr2
 */
public class WMSDashboards_mxJPO
{
	/**
	* Main entry point.
	*
	* @param context
	*		the eMatrix <code>Context</code> object
	* @param args
	*		holds no arguments
	* @return an integer status code (0 = success)
	* @throws Exception
	*		if the operation fails
	* @since 418
	*/
	public int mxMain(Context context, String[] args) throws Exception {
		if (!context.isConnected())
			throw new Exception("Not supported on desktop client");
		return 0;
	}

	/**
	*
	* @param context
	*		the eMatrix <code>Context</code> object
	* @param args
	*		holds 1 argument - obj id of work order
	* @return HashMap
	* @throws Exception
	*		if the operation fails
	*/
	public HashMap getWorkOrderCostDetails(Context context,String[] args) throws Exception
	{
		//get work order object id
		String strWorkOrderId = args[0];
		HashMap hmReturnMap = new HashMap();

		//prepare object selectables
		StringList slObj = new StringList();
		slObj.addElement("id");
		slObj.addElement("name");
		slObj.addElement("type");
		slObj.addElement("description");
		slObj.addElement("attribute[WMSPONumber]");
		slObj.addElement("attribute[WMSValueOfContract]");

		//get details of work order
		DomainObject doWorkOrder = DomainObject.newInstance(context, strWorkOrderId);
		Map mWorkOrderDetails = (Map)doWorkOrder.getInfo(context, slObj);

		//add work order details to return list
		hmReturnMap.put("objectid", (String)mWorkOrderDetails.get("id"));
		String strValueOfContract = (String)mWorkOrderDetails.get("attribute[WMSValueOfContract]");
		hmReturnMap.put("valueofcontract", WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strValueOfContract)));

		//get details of related objects
		slObj = new StringList();
		slObj.addElement("current");
		//bill selects
		slObj.addElement("attribute[WMSCertifiedAmount]");
		//advance recovery selects
		slObj.addElement("attribute[WMSAdvanceAmount]");
		slObj.addElement("attribute[WMSRecoveryAmount]");
		//retention release selects
		slObj.addElement("attribute[WMSRetensionAmount]");
		slObj.addElement("attribute[WMSRetentionRecoveryAmount]");
		//withheld release selects 
		slObj.addElement("attribute[WMSBillReductionAmount]");
		slObj.addElement("attribute[WMSBillReductionReleaseAmountTillDate]");

		MapList mlRelatedItemsDetails = doWorkOrder.getRelatedObjects(context,
																		"WMSWOAbstractMBE,WMSWorkOrderAdvances,WMSWorkOrderRetentionRecovery,WMSWorkOrderReduction",  //String relPattern
																		"WMSAbstractMeasurementBookEntry,WMSAdvanceRecoveryItem,WMSRetentionRecoveryItem,WMSBillReductionItem", //String typePattern
																		slObj,
																		null,
																		false,
																		true,
																		(short)1,
																		DomainConstants.EMPTY_STRING,
																		DomainConstants.EMPTY_STRING,
																		null,
																		null,
																		null);

			//add details of related items
			int iSize = mlRelatedItemsDetails.size();

			double dTotalAdvances = 0.0;
			double dTotalRecoveries = 0.0;
			double dTotalRetentions = 0.0;
			double dTotalRetentionReleases = 0.0;
			double dTotalWithheld = 0.0;
			double dTotalWithheldReleases = 0.0;
			double dTotalAmountPaid = 0.0;
			double dTotalAmountInReview = 0.0;

			String strType = DomainConstants.EMPTY_STRING;
			for (int i = 0 ; i < iSize ; i++)
			{
				strType = (String)((Map)mlRelatedItemsDetails.get(i)).get("type");
				//get details from Bill
				if("WMSAbstractMeasurementBookEntry".equals(strType))
				{
					if ("Review".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
					{
						dTotalAmountInReview += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
					}
					else if ("Approved".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
					{
						dTotalAmountPaid += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
					}
				}
				//get details of advances and recoveries
				else if ("WMSAdvanceRecoveryItem".equals(strType))
				{
					dTotalAdvances += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdvanceAmount]"));
					dTotalRecoveries += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRecoveryAmount]"));
				}
				//get details of retentions and recoveries
				else if ("WMSRetentionRecoveryItem".equals(strType))
				{
					dTotalRetentions += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetensionAmount]"));
					dTotalRetentionReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetentionRecoveryAmount]"));
				}
				//get details of withheld releases
				else if ("WMSBillReductionItem".equals(strType))
				{
					dTotalWithheld += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionAmount]"));
					dTotalWithheldReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionReleaseAmountTillDate]"));
				}
			}

			//add details to return map & maplist
			hmReturnMap.put("dTotalAdvances", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAdvances));
			hmReturnMap.put("dTotalRecoveries", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalRecoveries));
			hmReturnMap.put("dTotalRetentions", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalRetentions));
			hmReturnMap.put("dTotalRetentionReleases", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalRetentionReleases));
			hmReturnMap.put("dTotalWithheld", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalWithheld));
			hmReturnMap.put("dTotalWithheldReleases", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalWithheldReleases));
			hmReturnMap.put("dTotalAmountPaid", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAmountPaid));
			hmReturnMap.put("dTotalAmountInReview", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAmountInReview));
			hmReturnMap.put("financialprogress", Math.round((dTotalAmountPaid/Double.parseDouble(strValueOfContract))*100));

			return hmReturnMap;
	}
	
	/**
	*
	* @param context
	*		the eMatrix <code>Context</code> object
	* @param args
	*		holds 1 argument - obj id of work order
	* @return HashMap
	* @throws Exception
	*		if the operation fails
	*/
	public HashMap getProjectCostDetails(Context context,String[] args) throws Exception
	{
		//get project object id
		String strProjectId = args[0];
		HashMap hmReturnMap = new HashMap();

		//prepare object selectables
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("type");
		slObjSelects.addElement("description");
		slObjSelects.addElement("organization");
		slObjSelects.addElement("attribute[WMSAdminApprovalAmount]");
		slObjSelects.addElement("attribute[WMSApprovedAmountWork]");
		slObjSelects.addElement("attribute[WMSWorksContingency]");
		slObjSelects.addElement("attribute[WMSApprovedAmountEquipment]");
		slObjSelects.addElement("attribute[WMSEquipmentsContingency]");
		slObjSelects.addElement("attribute[WMSPlanningContingency]");
		slObjSelects.addElement("attribute[WMSCertifiedAmount]");
		
		//get details of related objects
		DomainObject doProject = DomainObject.newInstance(context, strProjectId);
		MapList mlRelatedItemsDetails = doProject.getRelatedObjects(context, 
																		"WMSProjectSOC,WMSSOCAdminApproval,WMSSOCDelegation,WMSProjectWorkOrder,WMSWOAbstractMBE",  //String relPattern
																		"WMSSOC,WMSAdminApproval,WMSDelegation,WMSWorkOrder,WMSAbstractMeasurementBookEntry", //String typePattern
																		slObjSelects,
																		null,
																		false,
																		true,
																		(short)0,
																		"revision==last",
																		DomainConstants.EMPTY_STRING,
																		null,
																		null,
																		null);
			//add details of related items
			int iSize = mlRelatedItemsDetails.size();

			String strAdminApproval = DomainConstants.EMPTY_STRING;
			String strTotalWorks = DomainConstants.EMPTY_STRING;
			String strTotalEquipment = DomainConstants.EMPTY_STRING;
			String strTotalPlanning = DomainConstants.EMPTY_STRING;
			double dTotalConsumedWorks=0.0;
			double dTotalConsumedEquipment=0.0;

			String strType = DomainConstants.EMPTY_STRING;
			String organzationType=DomainConstants.EMPTY_STRING;

			for (int i = 0 ; i < iSize ; i++)
			{
				strType = (String)((Map)mlRelatedItemsDetails.get(i)).get("type");
				organzationType =(String)((Map)mlRelatedItemsDetails.get(i)).get("organization");
				//get details of admin approval
				if("WMSAdminApproval".equals(strType))
				{
					strAdminApproval = WMSUtil_mxJPO.converToIndianCurrency(context, Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdminApprovalAmount]")));
				}
				//get details of delegation
				else if ("WMSDelegation".equals(strType))
				{
					strTotalWorks = WMSUtil_mxJPO.converToIndianCurrency(context, Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSApprovedAmountWork]")) + Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSWorksContingency]")));
					
					strTotalEquipment = WMSUtil_mxJPO.converToIndianCurrency(context, Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSApprovedAmountEquipment]")) + Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSEquipmentsContingency]")));
					
					strTotalPlanning = WMSUtil_mxJPO.converToIndianCurrency(context, Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSPlanningContingency]")));
				}
				//get details of the consumed amount Works
				else if("WMSAbstractMeasurementBookEntry".equals(strType) && "Works_V".equals(organzationType))
				{	
					dTotalConsumedWorks += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
			   	}
				//get  details of the consumed amount Equipments
				else if("WMSAbstractMeasurementBookEntry".equals(strType) && "Equipments_V".equals(organzationType))
				{
					dTotalConsumedEquipment += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));

			    	}
			}
			String strTotalConsumedWorks = WMSUtil_mxJPO.converToIndianCurrency(context, dTotalConsumedWorks);
			String strTotalConsumedEquipment = WMSUtil_mxJPO.converToIndianCurrency(context, dTotalConsumedEquipment);

			//add details to return map & maplist
			hmReturnMap.put("dAdminApproval", strAdminApproval);
			hmReturnMap.put("dTotalWorks", strTotalWorks);
			hmReturnMap.put("dTotalEquipment", strTotalEquipment);
			hmReturnMap.put("dTotalPlanning", strTotalPlanning);
			hmReturnMap.put("dTotalConsumedWork", strTotalConsumedWorks);
			hmReturnMap.put("dTotalConsumedEquipment", strTotalConsumedEquipment);

			return hmReturnMap;
	}
	public MapList getProjectDetails(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String strWhereCondition = "from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation ";

		DomainObject doPerson = PersonUtil.getPersonObject(context);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		String StrDateFormat = " ";
		String StrDateFormat1 = " ";
		String ProjectEndDate = " ";
		for (int i = 0 ; i < iSize ; i++)
		{
			int count=i+1;
			Map mTemp = new HashMap();
		
			mTemp = (Map)mlRelatedProjectDetails.get(i);
			mTemp.put("DgnpCount", count+"");
			
			StrDateFormat = (String) mTemp.get("attribute[Task Estimated Finish Date]");
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date = dt.parse(StrDateFormat);
			//System.out.println("date"+date);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("DateFormat", (dt1.format(date))+"");
			//System.out.println (dt1.format(date));
			
			StrDateFormat1 = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mTemp.put("ProjectStartDate", (dt21.format(date1))+"");
			//System.out.println ("Admin Approval Start date "+dt21.format(date1));
			
			//ProjectEndDate = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value");
			Double TotalWeek= Double.parseDouble((String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			//System.out.println ("TotalWeek "+TotalWeek);
			int TotalIntWeek = (int) Math.round(TotalWeek);
			//System.out.println("TotalIntWeek" + TotalIntWeek);
			int TotalDays = TotalIntWeek*7;
			//System.out.println("TotalDays" + TotalDays);
			
			//DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			//System.out.println("Project Complete Date " +dt.format(projectCompleteDate));
			//mTemp.put("ProjectCompletedDate", (dt.format(projectCompleteDate))+"");
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			
			
			/*SimpleDateFormat dt123 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date123 = dt123.parse(ProjectCompletedate);
			SimpleDateFormat dt213 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectstrCompleteDateDate= (dt213.format(date123));
			System.out.println("ProjectstrCompleteDateDate"+ProjectstrCompleteDateDate);
			mTemp.put("ProjectCompleteDate", (dt213.format(date123))+"");*/

				
			
			
			
			//calculate no. of weeks
			String strAADate = (String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			if(strAADate!=null && !"".equals(strAADate))
			{
				Date dAADate = dt.parse(strAADate);
				mTemp.put("AADate", (dt1.format(dAADate))+"");
			}
			else
			{
				mTemp.put("AADate", "");
			}
			//delayed by no. of weeks
			Date dToday = new Date();
			if(dToday.after(Cdate))
			{
				long diff = dToday.getTime() - Cdate.getTime();
				//System.out.println("----diff----"+diff);
				long diffDays = diff / (24*60*60*1000);
				//System.out.println("----diffDays----"+diffDays);
				long diffWeeks = diffDays/7;
				//System.out.println("----diffWeeks----"+diffWeeks);
				mTemp.put("DiffWeeks", diffWeeks+"");
			}
			else
			{
				mTemp.put("WeeksDelayed", "");
			}
			
			
			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
				//System.out.println("dEstimatedFinishDate---------"+dEstimatedFinishDate);
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		//System.out.println("mlRelatedProjectDetails"+mlRelatedProjectDetails);
		return mlRelatedProjectDetails;
	}
	
	/**
	*
	* @param context
	*		the eMatrix <code>Context</code> object
	* @param args
	*		holds 1 argument - obj id of work order
	* @return HashMap
	* @throws Exception
	*		if the operation fails
	*/
	public HashMap getProjectWorkOrderCostDetails(Context context,String[] args) throws Exception
	{
		//get work order object id
		String strProjectId = args[0];
		HashMap hmReturnMap = new HashMap();
		HashMap hmTotalReturnMap = new HashMap();
		HashMap hmWorksReturnMap = new HashMap();
		HashMap hmEquipmentReturnMap = new HashMap();

		//prepare object selectables
		DomainObject doProject = DomainObject.newInstance(context,strProjectId);
		StringList slWorkOrderIds = new StringList();
		
		slWorkOrderIds = (StringList)doProject.getInfoList(context,"from[WMSProjectWorkOrder].to.id");
		//get details of work order
		
		double dTotalAdvances = 0.0;
		double dTotalRecoveries = 0.0;
		double dTotalRetentions = 0.0;
		double dTotalRetentionReleases = 0.0;
		double dTotalWithheld = 0.0;
		double dTotalWithheldReleases = 0.0;
		double dTotalAmountPaid = 0.0;
		double dTotalAmountInReview = 0.0;
		double dTotalValueOfContract = 0.0;
		
		
		double dWorksAdvances = 0.0;
		double dWorksRecoveries = 0.0;
		double dWorksRetentions = 0.0;
		double dWorksRetentionReleases = 0.0;
		double dWorksWithheld = 0.0;
		double dWorksWithheldReleases = 0.0;
		double dWorksAmountPaid = 0.0;
		double dWorksAmountInReview = 0.0;
		double dWorksValueOfContract = 0.0;
		
		double dEquipmentsAdvances = 0.0;
		double dEquipmentsRecoveries = 0.0;
		double dEquipmentsRetentions = 0.0;
		double dEquipmentsRetentionReleases = 0.0;
		double dEquipmentsWithheld = 0.0;
		double dEquipmentsWithheldReleases = 0.0;
		double dEquipmentsAmountPaid = 0.0;
		double dEquipmentsAmountInReview = 0.0;
		double dEquipmentsValueOfContract = 0.0;
		
		String strWorkOrderId = "";
		DomainObject doWorkOrder = DomainObject.newInstance(context);
		for(int k=0;k<slWorkOrderIds.size();k++){
			StringList slObj = new StringList();
			slObj.addElement("id");
			slObj.addElement("name");
			slObj.addElement("type");
			slObj.addElement("description");
			slObj.addElement("attribute[WMSPONumber]");
			slObj.addElement("attribute[WMSValueOfContract]");
			slObj.addElement("attribute[WMSDepartmentUI]");
			strWorkOrderId = (String)slWorkOrderIds.get(k);
			doWorkOrder.setId(strWorkOrderId);
			Map mWorkOrderDetails = (Map)doWorkOrder.getInfo(context, slObj);
			//add work order details to return list
			hmTotalReturnMap.put("objectid", (String)mWorkOrderDetails.get("id"));
			String strValueOfContract = (String)mWorkOrderDetails.get("attribute[WMSValueOfContract]");
			String strDepartment = (String)mWorkOrderDetails.get("attribute[WMSDepartmentUI]");
			
			if(UIUtil.isNullOrEmpty(strValueOfContract)){
				strValueOfContract = "0";
			}
			dTotalValueOfContract	+= Double.parseDouble((String)strValueOfContract);
			
			
			if(UIUtil.isNotNullAndNotEmpty(strDepartment) && "Works".equals(strDepartment)){
				dWorksValueOfContract	+= Double.parseDouble((String)strValueOfContract);
			}
			
			if(UIUtil.isNotNullAndNotEmpty(strDepartment) && "Equipments".equals(strDepartment)){
				dEquipmentsValueOfContract	+= Double.parseDouble((String)strValueOfContract);
			}

			//get details of related objects
			slObj = new StringList();
			slObj.addElement("current");
			//bill selects
			slObj.addElement("attribute[WMSCertifiedAmount]");
			//advance recovery selects
			slObj.addElement("attribute[WMSAdvanceAmount]");
			slObj.addElement("attribute[WMSRecoveryAmount]");
			//retention release selects
			slObj.addElement("attribute[WMSRetensionAmount]");
			slObj.addElement("attribute[WMSRetentionRecoveryAmount]");
			//withheld release selects 
			slObj.addElement("attribute[WMSBillReductionAmount]");
			slObj.addElement("attribute[WMSBillReductionReleaseAmountTillDate]");

			MapList mlRelatedItemsDetails = doWorkOrder.getRelatedObjects(context,
																			"WMSWOAbstractMBE,WMSWorkOrderAdvances,WMSWorkOrderRetentionRecovery,WMSWorkOrderReduction",  //String relPattern
																			"WMSAbstractMeasurementBookEntry,WMSAdvanceRecoveryItem,WMSRetentionRecoveryItem,WMSBillReductionItem", //String typePattern
																			slObj,
																			null,
																			false,
																			true,
																			(short)1,
																			DomainConstants.EMPTY_STRING,
																			DomainConstants.EMPTY_STRING,
																			null,
																			null,
																			null);

				//add details of related items
				int iSize = mlRelatedItemsDetails.size();
				String strType = DomainConstants.EMPTY_STRING;
				for (int i = 0 ; i < iSize ; i++)
				{
					strType = (String)((Map)mlRelatedItemsDetails.get(i)).get("type");
					//get details from Bill
					if("WMSAbstractMeasurementBookEntry".equals(strType))
					{
						if ("Review".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
						{
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]")))
								dTotalAmountInReview += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
						}
						else if ("Approved".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
						{
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]")))
								dTotalAmountPaid += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
						}
					}
					//get details of advances and recoveries
					else if ("WMSAdvanceRecoveryItem".equals(strType))
					{
						if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdvanceAmount]")))
							dTotalAdvances += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdvanceAmount]"));
						if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRecoveryAmount]")))
							dTotalRecoveries += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRecoveryAmount]"));
					}
					//get details of retentions and recoveries
					else if ("WMSRetentionRecoveryItem".equals(strType))
					{
						if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetensionAmount]")))
							dTotalRetentions += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetensionAmount]"));
						if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetentionRecoveryAmount]")))
							dTotalRetentionReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetentionRecoveryAmount]"));
					}
					//get details of withheld releases
					else if ("WMSBillReductionItem".equals(strType))
					{
						if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionAmount]")))
							dTotalWithheld += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionAmount]"));
						if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionReleaseAmountTillDate]")))
							dTotalWithheldReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionReleaseAmountTillDate]"));
					}
				}
				
				if(UIUtil.isNotNullAndNotEmpty(strDepartment) && "Works".equals(strDepartment)){
					//add details of related items
					for (int i = 0 ; i < iSize ; i++)
					{
						strType = (String)((Map)mlRelatedItemsDetails.get(i)).get("type");
						//get details from Bill
						if("WMSAbstractMeasurementBookEntry".equals(strType))
						{
							if ("Review".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
							{
								if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]")))
									dWorksAmountInReview += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
							}
							else if ("Approved".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
							{
								if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]")))
									dWorksAmountPaid += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
							}
						}
						//get details of advances and recoveries
						else if ("WMSAdvanceRecoveryItem".equals(strType))
						{
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdvanceAmount]")))
								dWorksAdvances += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdvanceAmount]"));
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRecoveryAmount]")))
								dWorksRecoveries += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRecoveryAmount]"));
						}
						//get details of retentions and recoveries
						else if ("WMSRetentionRecoveryItem".equals(strType))
						{
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetensionAmount]")))
								dWorksRetentions += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetensionAmount]"));
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetentionRecoveryAmount]")))
								dWorksRetentionReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetentionRecoveryAmount]"));
						}
						//get details of withheld releases
						else if ("WMSBillReductionItem".equals(strType))
						{
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionAmount]")))
								dWorksWithheld += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionAmount]"));
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionReleaseAmountTillDate]")))
								dWorksWithheldReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionReleaseAmountTillDate]"));
						}
					}
				}
				
				if(UIUtil.isNotNullAndNotEmpty(strDepartment) && "Equipments".equals(strDepartment)){
					//add details of related items
					for (int i = 0 ; i < iSize ; i++)
					{
						strType = (String)((Map)mlRelatedItemsDetails.get(i)).get("type");
						//get details from Bill
						if("WMSAbstractMeasurementBookEntry".equals(strType))
						{
							if ("Review".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
							{
								if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]")))
									dEquipmentsAmountInReview += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
							}
							else if ("Approved".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
							{
								if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]")))
									dEquipmentsAmountPaid += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
							}
						}
						//get details of advances and recoveries
						else if ("WMSAdvanceRecoveryItem".equals(strType))
						{
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdvanceAmount]")))
								dEquipmentsAdvances += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdvanceAmount]"));
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRecoveryAmount]")))
								dEquipmentsRecoveries += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRecoveryAmount]"));
						}
						//get details of retentions and recoveries
						else if ("WMSRetentionRecoveryItem".equals(strType))
						{
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetensionAmount]")))
								dEquipmentsRetentions += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetensionAmount]"));
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetentionRecoveryAmount]")))
								dEquipmentsRetentionReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetentionRecoveryAmount]"));
						}
						//get details of withheld releases
						else if ("WMSBillReductionItem".equals(strType))
						{
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionAmount]")))
								dEquipmentsWithheld += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionAmount]"));
							if(UIUtil.isNotNullAndNotEmpty((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionReleaseAmountTillDate]")))
								dEquipmentsWithheldReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionReleaseAmountTillDate]"));
						}
					}
				}
			
		}		
		
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("type");
		slObjSelects.addElement("description");
		slObjSelects.addElement("organization");
		slObjSelects.addElement("attribute[WMSAdminApprovalAmount]");
		slObjSelects.addElement("attribute[WMSApprovedAmountWork]");
		slObjSelects.addElement("attribute[WMSWorksContingency]");
		slObjSelects.addElement("attribute[WMSApprovedAmountEquipment]");
		slObjSelects.addElement("attribute[WMSEquipmentsContingency]");
		slObjSelects.addElement("attribute[WMSPlanningContingency]");
		slObjSelects.addElement("attribute[WMSCertifiedAmount]");
		
		//get details of related objects
		MapList mlProjectRelatedItemsDetails = doProject.getRelatedObjects(context, 
																		"WMSProjectSOC,WMSSOCAdminApproval,WMSSOCDelegation,WMSProjectWorkOrder",  //String relPattern
																		"WMSSOC,WMSAdminApproval,WMSDelegation", //String typePattern
																		slObjSelects,
																		null,
																		false,
																		true,
																		(short)0,
																		"revision==last",
																		DomainConstants.EMPTY_STRING,
																		null,
																		null,
																		null);
																		
		//add details of related items
			int iItemSize = mlProjectRelatedItemsDetails.size();

			String strAdminApproval = DomainConstants.EMPTY_STRING;
			String strTotalWorks = DomainConstants.EMPTY_STRING;
			String strTotalEquipment = DomainConstants.EMPTY_STRING;
			String strTotalPlanning = DomainConstants.EMPTY_STRING;
			double dTotalConsumedWorks=0.0;
			double dTotalConsumedEquipment=0.0;
			double dAdminApprovalAmount = 0.0;
			double dWorksDelegatedAmount = 0.0;
			double dEquipmentDelegatedAmount = 0.0;
			double dPlanningDelegatedAmount = 0.0;

			String sType = DomainConstants.EMPTY_STRING;

			for (int i = 0 ; i < iItemSize ; i++)
			{
				sType = (String)((Map)mlProjectRelatedItemsDetails.get(i)).get("type");
				//get details of admin approval
				if("WMSAdminApproval".equals(sType))
				{
					dAdminApprovalAmount = Double.parseDouble((String)((Map)mlProjectRelatedItemsDetails.get(i)).get("attribute[WMSAdminApprovalAmount]"));
				}
				//get details of delegation
				else if ("WMSDelegation".equals(sType))
				{
					dWorksDelegatedAmount = Double.parseDouble((String)((Map)mlProjectRelatedItemsDetails.get(i)).get("attribute[WMSApprovedAmountWork]")) + Double.parseDouble((String)((Map)mlProjectRelatedItemsDetails.get(i)).get("attribute[WMSWorksContingency]"));
					
					dEquipmentDelegatedAmount = Double.parseDouble((String)((Map)mlProjectRelatedItemsDetails.get(i)).get("attribute[WMSApprovedAmountEquipment]")) + Double.parseDouble((String)((Map)mlProjectRelatedItemsDetails.get(i)).get("attribute[WMSEquipmentsContingency]"));
					
					dPlanningDelegatedAmount = Double.parseDouble((String)((Map)mlProjectRelatedItemsDetails.get(i)).get("attribute[WMSPlanningContingency]"));
				}
				
			}
		hmReturnMap.put("WorksDelegated",WMSUtil_mxJPO.converToIndianCurrency(context,dWorksDelegatedAmount));
		hmReturnMap.put("EquipmentDelegated",WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentDelegatedAmount));
		hmReturnMap.put("PlanningDelegated",WMSUtil_mxJPO.converToIndianCurrency(context,dPlanningDelegatedAmount));
			
			
			//add details to return map & maplist
		hmTotalReturnMap.put("valueofcontract", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalValueOfContract));
		hmTotalReturnMap.put("dTotalAdvances", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAdvances));
		hmTotalReturnMap.put("dTotalRecoveries", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalRecoveries));
		hmTotalReturnMap.put("dTotalRetentions", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalRetentions));
		hmTotalReturnMap.put("dTotalRetentionReleases", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalRetentionReleases));
		hmTotalReturnMap.put("dTotalWithheld", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalWithheld));
		hmTotalReturnMap.put("dTotalWithheldReleases", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalWithheldReleases));
		hmTotalReturnMap.put("dTotalAmountPaid", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAmountPaid));
		hmTotalReturnMap.put("dTotalAmountInReview", WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAmountInReview));
		if(dTotalAmountPaid==0 || dTotalValueOfContract==0){
			hmTotalReturnMap.put("financialprogress", Math.round(0.0));
		}else{
			hmTotalReturnMap.put("financialprogress", Math.round((dTotalAmountPaid/(dWorksDelegatedAmount+dEquipmentDelegatedAmount+dPlanningDelegatedAmount))*100));
		}
		
		
		//add details to return map & maplist
		hmWorksReturnMap.put("valueofcontract", WMSUtil_mxJPO.converToIndianCurrency(context,dWorksValueOfContract));
		hmWorksReturnMap.put("dTotalAdvances", WMSUtil_mxJPO.converToIndianCurrency(context,dWorksAdvances));
		hmWorksReturnMap.put("dTotalRecoveries", WMSUtil_mxJPO.converToIndianCurrency(context,dWorksRecoveries));
		hmWorksReturnMap.put("dTotalRetentions", WMSUtil_mxJPO.converToIndianCurrency(context,dWorksRetentions));
		hmWorksReturnMap.put("dTotalRetentionReleases", WMSUtil_mxJPO.converToIndianCurrency(context,dWorksRetentionReleases));
		hmWorksReturnMap.put("dTotalWithheld", WMSUtil_mxJPO.converToIndianCurrency(context,dWorksWithheld));
		hmWorksReturnMap.put("dTotalWithheldReleases", WMSUtil_mxJPO.converToIndianCurrency(context,dWorksWithheldReleases));
		hmWorksReturnMap.put("dTotalAmountPaid", WMSUtil_mxJPO.converToIndianCurrency(context,dWorksAmountPaid));
		hmWorksReturnMap.put("dTotalAmountInReview", WMSUtil_mxJPO.converToIndianCurrency(context,dWorksAmountInReview));
		if(dWorksAmountPaid==0 || dWorksValueOfContract==0){
			hmWorksReturnMap.put("financialprogress", Math.round(0.0));
		}else{
			hmWorksReturnMap.put("financialprogress", Math.round((dWorksAmountPaid/dWorksDelegatedAmount)*100));
		}
		
		
		//add details to return map & maplist
		hmEquipmentReturnMap.put("valueofcontract", WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentsValueOfContract));
		hmEquipmentReturnMap.put("dTotalAdvances", WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentsAdvances));
		hmEquipmentReturnMap.put("dTotalRecoveries", WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentsRecoveries));
		hmEquipmentReturnMap.put("dTotalRetentions", WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentsRetentions));
		hmEquipmentReturnMap.put("dTotalRetentionReleases", WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentsRetentionReleases));
		hmEquipmentReturnMap.put("dTotalWithheld", WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentsWithheld));
		hmEquipmentReturnMap.put("dTotalWithheldReleases", WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentsWithheldReleases));
		hmEquipmentReturnMap.put("dTotalAmountPaid", WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentsAmountPaid));
		hmEquipmentReturnMap.put("dTotalAmountInReview", WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentsAmountInReview));
		if(dEquipmentsAmountPaid==0 || dEquipmentsValueOfContract==0){
			hmEquipmentReturnMap.put("financialprogress", Math.round(0.0));
		}else{
			hmEquipmentReturnMap.put("financialprogress", Math.round((dEquipmentsAmountPaid/dEquipmentDelegatedAmount)*100));
		}
		
		hmReturnMap.put("Total",hmTotalReturnMap);
		hmReturnMap.put("Works",hmWorksReturnMap);
		hmReturnMap.put("Equipments",hmEquipmentReturnMap);
		
		return hmReturnMap;
	}
	public MapList getProjectDetailsAOB(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition = "(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType]==AOB";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		String StrDateFormat = " ";
		String StrDateFormat1 = " ";
		String ProjectEndDate = " ";
		for (int i = 0 ; i < iSize ; i++)
		{
			int count=i+1;
			Map mTemp = new HashMap();
		
			mTemp = (Map)mlRelatedProjectDetails.get(i);
			mTemp.put("DgnpCount", count+"");
			
			StrDateFormat = (String) mTemp.get("attribute[Task Estimated Finish Date]");
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date = dt.parse(StrDateFormat);
			//System.out.println("date"+date);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("DateFormat", (dt1.format(date))+"");
			//System.out.println (dt1.format(date));
			
			StrDateFormat1 = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mTemp.put("ProjectStartDate", (dt21.format(date1))+"");
			//System.out.println ("Admin Approval Start date "+dt21.format(date1));
			
			//ProjectEndDate = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value");
			Double TotalWeek= Double.parseDouble((String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			//System.out.println ("TotalWeek "+TotalWeek);
			int TotalIntWeek = (int) Math.round(TotalWeek);
			//System.out.println("TotalIntWeek" + TotalIntWeek);
			int TotalDays = TotalIntWeek*7;
			//System.out.println("TotalDays" + TotalDays);
			
			//DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			//System.out.println("Project Complete Date " +dt.format(projectCompleteDate));
			//mTemp.put("ProjectCompletedDate", (dt.format(projectCompleteDate))+"");
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			
			
			/*SimpleDateFormat dt123 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date123 = dt123.parse(ProjectCompletedate);
			SimpleDateFormat dt213 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectstrCompleteDateDate= (dt213.format(date123));
			System.out.println("ProjectstrCompleteDateDate"+ProjectstrCompleteDateDate);
			mTemp.put("ProjectCompleteDate", (dt213.format(date123))+"");*/

				
			
			
			
			//calculate no. of weeks
			String strAADate = (String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			if(strAADate!=null && !"".equals(strAADate))
			{
				Date dAADate = dt.parse(strAADate);
				mTemp.put("AADate", (dt1.format(dAADate))+"");
			}
			else
			{
				mTemp.put("AADate", "");
			}
			//delayed by no. of weeks
			Date dToday = new Date();
			if(dToday.after(Cdate))
			{
				long diff = dToday.getTime() - Cdate.getTime();
				//System.out.println("----diff----"+diff);
				long diffDays = diff / (24*60*60*1000);
				//System.out.println("----diffDays----"+diffDays);
				long diffWeeks = diffDays/7;
				//System.out.println("----diffWeeks----"+diffWeeks);
				mTemp.put("DiffWeeks", diffWeeks+"");
			}
			else
			{
				mTemp.put("WeeksDelayed", "");
			}
			
			
			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
				//System.out.println("dEstimatedFinishDate---------"+dEstimatedFinishDate);
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		//System.out.println("mlRelatedProjectDetails"+mlRelatedProjectDetails);
		return mlRelatedProjectDetails;
	}
	public MapList getProjectDetailsSFC(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition = "(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType]==SFC";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		String StrDateFormat = " ";
		String StrDateFormat1 = " ";
		String ProjectEndDate = " ";
		for (int i = 0 ; i < iSize ; i++)
		{
			int count=i+1;
			Map mTemp = new HashMap();
		
			mTemp = (Map)mlRelatedProjectDetails.get(i);
			mTemp.put("DgnpCount", count+"");
			
			StrDateFormat = (String) mTemp.get("attribute[Task Estimated Finish Date]");
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date = dt.parse(StrDateFormat);
			//System.out.println("date"+date);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("DateFormat", (dt1.format(date))+"");
			//System.out.println (dt1.format(date));
			
			StrDateFormat1 = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mTemp.put("ProjectStartDate", (dt21.format(date1))+"");
			//System.out.println ("Admin Approval Start date "+dt21.format(date1));
			
			//ProjectEndDate = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value");
			Double TotalWeek= Double.parseDouble((String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			//System.out.println ("TotalWeek "+TotalWeek);
			int TotalIntWeek = (int) Math.round(TotalWeek);
			//System.out.println("TotalIntWeek" + TotalIntWeek);
			int TotalDays = TotalIntWeek*7;
			//System.out.println("TotalDays" + TotalDays);
			
			//DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			//System.out.println("Project Complete Date " +dt.format(projectCompleteDate));
			//mTemp.put("ProjectCompletedDate", (dt.format(projectCompleteDate))+"");
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			
			
			/*SimpleDateFormat dt123 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date123 = dt123.parse(ProjectCompletedate);
			SimpleDateFormat dt213 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectstrCompleteDateDate= (dt213.format(date123));
			System.out.println("ProjectstrCompleteDateDate"+ProjectstrCompleteDateDate);
			mTemp.put("ProjectCompleteDate", (dt213.format(date123))+"");*/

				
			
			
			
			//calculate no. of weeks
			String strAADate = (String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			if(strAADate!=null && !"".equals(strAADate))
			{
				Date dAADate = dt.parse(strAADate);
				mTemp.put("AADate", (dt1.format(dAADate))+"");
			}
			else
			{
				mTemp.put("AADate", "");
			}
			//delayed by no. of weeks
			Date dToday = new Date();
			if(dToday.after(Cdate))
			{
				long diff = dToday.getTime() - Cdate.getTime();
				//System.out.println("----diff----"+diff);
				long diffDays = diff / (24*60*60*1000);
				//System.out.println("----diffDays----"+diffDays);
				long diffWeeks = diffDays/7;
				//System.out.println("----diffWeeks----"+diffWeeks);
				mTemp.put("DiffWeeks", diffWeeks+"");
			}
			else
			{
				mTemp.put("WeeksDelayed", "");
			}
			
			
			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
				//System.out.println("dEstimatedFinishDate---------"+dEstimatedFinishDate);
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		//System.out.println("mlRelatedProjectDetails"+mlRelatedProjectDetails);
		return mlRelatedProjectDetails;
	}
	public MapList getProjectDetailsATVP(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition = "(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType]==ATVP";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		String StrDateFormat = " ";
		String StrDateFormat1 = " ";
		String ProjectEndDate = " ";
		for (int i = 0 ; i < iSize ; i++)
		{
			int count=i+1;
			Map mTemp = new HashMap();
		
			mTemp = (Map)mlRelatedProjectDetails.get(i);
			mTemp.put("DgnpCount", count+"");
			
			StrDateFormat = (String) mTemp.get("attribute[Task Estimated Finish Date]");
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date = dt.parse(StrDateFormat);
			//System.out.println("date"+date);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("DateFormat", (dt1.format(date))+"");
			//System.out.println (dt1.format(date));
			
			StrDateFormat1 = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mTemp.put("ProjectStartDate", (dt21.format(date1))+"");
			//System.out.println ("Admin Approval Start date "+dt21.format(date1));
			
			//ProjectEndDate = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value");
			Double TotalWeek= Double.parseDouble((String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			//System.out.println ("TotalWeek "+TotalWeek);
			int TotalIntWeek = (int) Math.round(TotalWeek);
			//System.out.println("TotalIntWeek" + TotalIntWeek);
			int TotalDays = TotalIntWeek*7;
			//System.out.println("TotalDays" + TotalDays);
			
			//DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			//System.out.println("Project Complete Date " +dt.format(projectCompleteDate));
			//mTemp.put("ProjectCompletedDate", (dt.format(projectCompleteDate))+"");
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			
			
			/*SimpleDateFormat dt123 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date123 = dt123.parse(ProjectCompletedate);
			SimpleDateFormat dt213 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectstrCompleteDateDate= (dt213.format(date123));
			System.out.println("ProjectstrCompleteDateDate"+ProjectstrCompleteDateDate);
			mTemp.put("ProjectCompleteDate", (dt213.format(date123))+"");*/

				
			
			
			
			//calculate no. of weeks
			String strAADate = (String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			if(strAADate!=null && !"".equals(strAADate))
			{
				Date dAADate = dt.parse(strAADate);
				mTemp.put("AADate", (dt1.format(dAADate))+"");
			}
			else
			{
				mTemp.put("AADate", "");
			}
			//delayed by no. of weeks
			Date dToday = new Date();
			if(dToday.after(Cdate))
			{
				long diff = dToday.getTime() - Cdate.getTime();
				//System.out.println("----diff----"+diff);
				long diffDays = diff / (24*60*60*1000);
				//System.out.println("----diffDays----"+diffDays);
				long diffWeeks = diffDays/7;
				//System.out.println("----diffWeeks----"+diffWeeks);
				mTemp.put("DiffWeeks", diffWeeks+"");
			}
			else
			{
				mTemp.put("WeeksDelayed", "");
			}
			
			
			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
				//System.out.println("dEstimatedFinishDate---------"+dEstimatedFinishDate);
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		//System.out.println("mlRelatedProjectDetails"+mlRelatedProjectDetails);
		return mlRelatedProjectDetails;
	}
		public MapList getProjectDetailsATWP(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition = "(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType]==ATWP";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		String StrDateFormat = " ";
		String StrDateFormat1 = " ";
		String ProjectEndDate = " ";
		for (int i = 0 ; i < iSize ; i++)
		{
			int count=i+1;
			Map mTemp = new HashMap();
		
			mTemp = (Map)mlRelatedProjectDetails.get(i);
			mTemp.put("DgnpCount", count+"");
			
			StrDateFormat = (String) mTemp.get("attribute[Task Estimated Finish Date]");
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date = dt.parse(StrDateFormat);
			//System.out.println("date"+date);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("DateFormat", (dt1.format(date))+"");
			//System.out.println (dt1.format(date));
			
			StrDateFormat1 = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mTemp.put("ProjectStartDate", (dt21.format(date1))+"");
			//System.out.println ("Admin Approval Start date "+dt21.format(date1));
			
			//ProjectEndDate = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value");
			Double TotalWeek= Double.parseDouble((String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			//System.out.println ("TotalWeek "+TotalWeek);
			int TotalIntWeek = (int) Math.round(TotalWeek);
			//System.out.println("TotalIntWeek" + TotalIntWeek);
			int TotalDays = TotalIntWeek*7;
			//System.out.println("TotalDays" + TotalDays);
			
			//DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			//System.out.println("Project Complete Date " +dt.format(projectCompleteDate));
			//mTemp.put("ProjectCompletedDate", (dt.format(projectCompleteDate))+"");
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			
			
			/*SimpleDateFormat dt123 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date123 = dt123.parse(ProjectCompletedate);
			SimpleDateFormat dt213 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectstrCompleteDateDate= (dt213.format(date123));
			System.out.println("ProjectstrCompleteDateDate"+ProjectstrCompleteDateDate);
			mTemp.put("ProjectCompleteDate", (dt213.format(date123))+"");*/

				
			
			
			
			//calculate no. of weeks
			String strAADate = (String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			if(strAADate!=null && !"".equals(strAADate))
			{
				Date dAADate = dt.parse(strAADate);
				mTemp.put("AADate", (dt1.format(dAADate))+"");
			}
			else
			{
				mTemp.put("AADate", "");
			}
			//delayed by no. of weeks
			Date dToday = new Date();
			if(dToday.after(Cdate))
			{
				long diff = dToday.getTime() - Cdate.getTime();
				//System.out.println("----diff----"+diff);
				long diffDays = diff / (24*60*60*1000);
				//System.out.println("----diffDays----"+diffDays);
				long diffWeeks = diffDays/7;
				//System.out.println("----diffWeeks----"+diffWeeks);
				mTemp.put("DiffWeeks", diffWeeks+"");
			}
			else
			{
				mTemp.put("WeeksDelayed", "");
			}
			
			
			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
				//System.out.println("dEstimatedFinishDate---------"+dEstimatedFinishDate);
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		//System.out.println("mlRelatedProjectDetails"+mlRelatedProjectDetails);
		return mlRelatedProjectDetails;
	}
	public MapList getProjectDetailsDNSPI(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition = "(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType]==DNSPI";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		String StrDateFormat = " ";
		String StrDateFormat1 = " ";
		String ProjectEndDate = " ";
		for (int i = 0 ; i < iSize ; i++)
		{
			int count=i+1;
			Map mTemp = new HashMap();
		
			mTemp = (Map)mlRelatedProjectDetails.get(i);
			mTemp.put("DgnpCount", count+"");
			
			StrDateFormat = (String) mTemp.get("attribute[Task Estimated Finish Date]");
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date = dt.parse(StrDateFormat);
			//System.out.println("date"+date);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("DateFormat", (dt1.format(date))+"");
			//System.out.println (dt1.format(date));
			
			StrDateFormat1 = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mTemp.put("ProjectStartDate", (dt21.format(date1))+"");
			//System.out.println ("Admin Approval Start date "+dt21.format(date1));
			
			//ProjectEndDate = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value");
			Double TotalWeek= Double.parseDouble((String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			//System.out.println ("TotalWeek "+TotalWeek);
			int TotalIntWeek = (int) Math.round(TotalWeek);
			//System.out.println("TotalIntWeek" + TotalIntWeek);
			int TotalDays = TotalIntWeek*7;
			//System.out.println("TotalDays" + TotalDays);
			
			//DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			//System.out.println("Project Complete Date " +dt.format(projectCompleteDate));
			//mTemp.put("ProjectCompletedDate", (dt.format(projectCompleteDate))+"");
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			
			
			/*SimpleDateFormat dt123 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date123 = dt123.parse(ProjectCompletedate);
			SimpleDateFormat dt213 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectstrCompleteDateDate= (dt213.format(date123));
			System.out.println("ProjectstrCompleteDateDate"+ProjectstrCompleteDateDate);
			mTemp.put("ProjectCompleteDate", (dt213.format(date123))+"");*/

				
			
			
			
			//calculate no. of weeks
			String strAADate = (String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			if(strAADate!=null && !"".equals(strAADate))
			{
				Date dAADate = dt.parse(strAADate);
				mTemp.put("AADate", (dt1.format(dAADate))+"");
			}
			else
			{
				mTemp.put("AADate", "");
			}
			//delayed by no. of weeks
			Date dToday = new Date();
			if(dToday.after(Cdate))
			{
				long diff = dToday.getTime() - Cdate.getTime();
				//System.out.println("----diff----"+diff);
				long diffDays = diff / (24*60*60*1000);
				//System.out.println("----diffDays----"+diffDays);
				long diffWeeks = diffDays/7;
				mTemp.put("DiffWeeks", diffWeeks+"");
			}
			else
			{
				mTemp.put("WeeksDelayed", "");
			}
			
			
			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
				//System.out.println("dEstimatedFinishDate---------"+dEstimatedFinishDate);
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		return mlRelatedProjectDetails;
	}
	public MapList getProjectDetailsCONSULTANCY(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition = "(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType]==CONSULTANCY";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		String StrDateFormat = " ";
		String StrDateFormat1 = " ";
		String ProjectEndDate = " ";
		for (int i = 0 ; i < iSize ; i++)
		{
			int count=i+1;
			Map mTemp = new HashMap();
		
			mTemp = (Map)mlRelatedProjectDetails.get(i);
			mTemp.put("DgnpCount", count+"");
			
			StrDateFormat = (String) mTemp.get("attribute[Task Estimated Finish Date]");
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date = dt.parse(StrDateFormat);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("DateFormat", (dt1.format(date))+"");
			
			StrDateFormat1 = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mTemp.put("ProjectStartDate", (dt21.format(date1))+"");
			Double TotalWeek= Double.parseDouble((String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			int TotalIntWeek = (int) Math.round(TotalWeek);
			int TotalDays = TotalIntWeek*7;
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			String strAADate = (String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			if(strAADate!=null && !"".equals(strAADate))
			{
				Date dAADate = dt.parse(strAADate);
				mTemp.put("AADate", (dt1.format(dAADate))+"");
			}
			else
			{
				mTemp.put("AADate", "");
			}
			Date dToday = new Date();
			if(dToday.after(Cdate))
			{
				long diff = dToday.getTime() - Cdate.getTime();
				long diffDays = diff / (24*60*60*1000);
				long diffWeeks = diffDays/7;
				mTemp.put("DiffWeeks", diffWeeks+"");
			}
			else
			{
				mTemp.put("WeeksDelayed", "");
			}
			
			
			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		return mlRelatedProjectDetails;
	}
	public MapList getProjectDetailsHQENC(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition = "(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType]==HQENC";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		String StrDateFormat = " ";
		String StrDateFormat1 = " ";
		String ProjectEndDate = " ";
		for (int i = 0 ; i < iSize ; i++)
		{
			int count=i+1;
			Map mTemp = new HashMap();
		
			mTemp = (Map)mlRelatedProjectDetails.get(i);
			mTemp.put("DgnpCount", count+"");
			
			StrDateFormat = (String) mTemp.get("attribute[Task Estimated Finish Date]");
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date = dt.parse(StrDateFormat);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("DateFormat", (dt1.format(date))+"");
			
			StrDateFormat1 = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mTemp.put("ProjectStartDate", (dt21.format(date1))+"");
			Double TotalWeek= Double.parseDouble((String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			int TotalIntWeek = (int) Math.round(TotalWeek);
			int TotalDays = TotalIntWeek*7;
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			String strAADate = (String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			if(strAADate!=null && !"".equals(strAADate))
			{
				Date dAADate = dt.parse(strAADate);
				mTemp.put("AADate", (dt1.format(dAADate))+"");
			}
			else
			{
				mTemp.put("AADate", "");
			}
			Date dToday = new Date();
			if(dToday.after(Cdate))
			{
				long diff = dToday.getTime() - Cdate.getTime();
				long diffDays = diff / (24*60*60*1000);
				long diffWeeks = diffDays/7;
				mTemp.put("DiffWeeks", diffWeeks+"");
			}
			else
			{
				mTemp.put("WeeksDelayed", "");
			}
			
			
			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		return mlRelatedProjectDetails;
	}
	public MapList getProjectDetailsAMWP(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition = "(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType]==AMWP";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		String StrDateFormat = " ";
		String StrDateFormat1 = " ";
		String ProjectEndDate = " ";
		for (int i = 0 ; i < iSize ; i++)
		{
			int count=i+1;
			Map mTemp = new HashMap();
		
			mTemp = (Map)mlRelatedProjectDetails.get(i);
			mTemp.put("DgnpCount", count+"");
			
			StrDateFormat = (String) mTemp.get("attribute[Task Estimated Finish Date]");
			SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date = dt.parse(StrDateFormat);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("DateFormat", (dt1.format(date))+"");
			
			StrDateFormat1 = (String) mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mTemp.put("ProjectStartDate", (dt21.format(date1))+"");
			Double TotalWeek= Double.parseDouble((String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			int TotalIntWeek = (int) Math.round(TotalWeek);
			int TotalDays = TotalIntWeek*7;
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mTemp.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			String strAADate = (String)mTemp.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			if(strAADate!=null && !"".equals(strAADate))
			{
				Date dAADate = dt.parse(strAADate);
				mTemp.put("AADate", (dt1.format(dAADate))+"");
			}
			else
			{
				mTemp.put("AADate", "");
			}
			Date dToday = new Date();
			if(dToday.after(Cdate))
			{
				long diff = dToday.getTime() - Cdate.getTime();
				long diffDays = diff / (24*60*60*1000);
				long diffWeeks = diffDays/7;
				mTemp.put("DiffWeeks", diffWeeks+"");
			}
			else
			{
				mTemp.put("WeeksDelayed", "");
			}
			
			
			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		return mlRelatedProjectDetails;
	}
	
}
