import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.MqlUtil;

import com.itextpdf.io.image.ImageData; 
import com.itextpdf.io.image.ImageDataFactory; 
import com.itextpdf.kernel.pdf.PdfDocument; 
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Image; 
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Cell; 
import com.itextpdf.layout.element.Table;  
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.Property;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.VerticalAlignment;
import com.itextpdf.layout.property.HorizontalAlignment;

import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;

public class WMSExportRouteTask_mxJPO extends WMSConstants_mxJPO {

	public WMSExportRouteTask_mxJPO(Context context,String[] args) {
		super(context,args);
	}
	public HashMap generateApprovalCommentReport(Context context, String[] args) throws Exception 
	{
		try{
		//String strTSId = args[1];
		Map mInputMap = (Map) JPO.unpackArgs(args);
		String sRouteId = (String)mInputMap.get("objectId");
		
		DomainObject doBus = DomainObject.newInstance(context,sRouteId);
		String strBusType = (String)doBus.getInfo(context,DomainObject.SELECT_TYPE);

		if("Inbox Task".equals(strBusType)){
			sRouteId  = MqlUtil.mqlCommand(context,"print bus "+sRouteId+"  select from[Route Task].to.id dump");
		} 
		
		DomainObject doRoute = DomainObject.newInstance(context, sRouteId);
		
		StringList slRouteSelect = new StringList();
		slRouteSelect.add(DomainObject.SELECT_NAME);
		slRouteSelect.add("to[Object Route].from.name");
		slRouteSelect.add("to[Object Route].from.attribute[Title]");
		slRouteSelect.add("to[Object Route].from.type");
		slRouteSelect.add("to[Object Route].from.description");
		slRouteSelect.add("to[Object Route].from.revision");
		
		Map mRouteInfo = (Map)doRoute.getInfo(context,slRouteSelect);
		
		
		
		String strTransPath = context.createWorkspace();
		String strFileName = "Route-"+(String)mRouteInfo.get(DomainObject.SELECT_NAME)+".pdf";
		String dest = strTransPath+File.separator+strFileName;

		// Creating a PdfDocument
		PdfDocument pdf = new PdfDocument(new PdfWriter(dest));
		// Creating a Document
		Document document = new Document(pdf, PageSize.A4, false);

		//adding DGNP logo
		String imgFile = getImgFile(context);
		ImageData imgdata = ImageDataFactory.create(imgFile);
		Image image = new Image(imgdata);
		image.setTextAlignment(TextAlignment.CENTER);
		document.add(image);
		
		//add space
		document.add(new Paragraph(""));
		
		//add headers
		Paragraph p = new Paragraph("Route Approval Comments")
									.setTextAlignment(TextAlignment.CENTER)
									.setFontSize(14)
									.setUnderline(0.1f, -2f);
		document.add(p);
				
		//add space
		document.add(new Paragraph(""));
		
		//adding project details table
		Table details = new Table(UnitValue.createPercentArray(new float[] {3, 6}));
		details.addCell(createCell("1. Route Number", 0, 1, TextAlignment.LEFT));
		details.addCell(createCell(": "+(String)mRouteInfo.get(DomainObject.SELECT_NAME),0, 1, TextAlignment.LEFT));
		details.addCell(createCell("2. Name of Activitiy", 0, 1, TextAlignment.LEFT));
		details.addCell(createCell(": "+(String)mRouteInfo.get("to[Object Route].from.name")+" (Title: "+(String)mRouteInfo.get("to[Object Route].from.attribute[Title]")+")", 0, 1, TextAlignment.LEFT));
		details.addCell(createCell("3. Revision", 0, 1, TextAlignment.LEFT));
		details.addCell(createCell(": "+(String)mRouteInfo.get("to[Object Route].from.revision"), 0, 1, TextAlignment.LEFT));
		details.addCell(createCell("4. Purpose", 0, 1, TextAlignment.LEFT));
		
		String strType= (String)mRouteInfo.get("to[Object Route].from.type");
		
		strType = EnoviaResourceBundle.getProperty(context,
						"emxFrameworkStringResource", context.getLocale(), "emxFramework.Type."+strType);
		details.addCell(createCell(": "+strType,0, 1, TextAlignment.LEFT));
		document.add(details);
		document.add(new Paragraph(""));
		
		StringList relList = new StringList();
		StringList objectList = new StringList();
		objectList.addElement(DomainConstants.SELECT_ID);
		objectList.addElement(DomainConstants.SELECT_NAME);
		objectList.addElement(DomainConstants.SELECT_TYPE);
		objectList.addElement(DomainConstants.SELECT_CURRENT);
		objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_FIRST_NAME+"]");
		objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.id");
		objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_LAST_NAME+"]");
		objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ROUTE_TASK_USER+"]");
		objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_APPROVAL_STATUS+"]");
		objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]");
		objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
		objectList.addElement("attribute[WMSInboxTaskFromUser]");
		objectList.addElement("attribute[Route Instructions]");
		
		
		
		MapList mlRouteTasks = doRoute.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_ROUTE_TASK,  //String relPattern
					DomainConstants.TYPE_INBOX_TASK, //String typePattern
					objectList,            //StringList objectSelects,
					relList,    		   //StringList relationshipSelects,
					true,                  //boolean getTo,
					false,                  //boolean getFrom,
					(short)1,              //short recurseToLevel,
					"",   				   //String objectWhere,
					"",             //String relationshipWhere,
					0); 
					
					
		mlRouteTasks.sort("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]","ascending","date");
		
		document.add(new Paragraph(""));
		document.add(new Paragraph(""));
		
		//adding items table
		Table table = new Table(UnitValue.createPercentArray(new float[] {1, 2, 4, 3, 2, 3}));
		table.addCell(createCell("Sl No", 1, 1, TextAlignment.CENTER).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Task Name", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Approver", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Comments", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Purpose", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Completion Date", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		
		int iCounter = 1;
		String atrTaskName = "";
		String strApproverName = "";
		String strComment = "";
		String strStatus = "";
		String strDate = "";
		String strDelegateduser = "";
		String strOnBehalf= "";
		
		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
		Map mTemp = null;
		for (int i = 0 ; i < mlRouteTasks.size() ; i++)
		{
			mTemp = (Map)mlRouteTasks.get(i);
			atrTaskName = (String)mTemp.get(DomainConstants.SELECT_NAME);
			strApproverName = (String)mTemp.get("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_FIRST_NAME+"]") +" "+(String)mTemp.get("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_LAST_NAME+"]");
			strDelegateduser = (String)mTemp.get("attribute[WMSInboxTaskFromUser]");
			if(UIUtil.isNotNullAndNotEmpty(strDelegateduser)){	
			strOnBehalf = strApproverName + "\n" + "(Offg  " + strDelegateduser + ")";
			}else
			strOnBehalf = strApproverName;
			strComment = (String)mTemp.get("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
			strStatus = (String)mTemp.get("attribute[Route Instructions]");
			strDate = (String)mTemp.get("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]");
			
			if(UIUtil.isNotNullAndNotEmpty(strDate)){
				Date date1 = eMatrixDateFormat.getJavaDate(strDate);
				strDate = df.format(date1);	
			}
				
			table.addCell(createCell(iCounter+"", 1, 1, TextAlignment.LEFT));
			table.addCell(createCell(atrTaskName, 1, 1, TextAlignment.CENTER));
			table.addCell(createCell(strOnBehalf, 1, 1, TextAlignment.LEFT));
			table.addCell(createCell(strComment, 1, 1, TextAlignment.LEFT));
			table.addCell(createCell(strStatus, 1, 1, TextAlignment.LEFT));
			table.addCell(createCell(strDate, 1, 1, TextAlignment.LEFT));
			
			iCounter++;
		}
		
		document.add(table);
		
		//add footer
		float width = pdf.getDefaultPageSize().getWidth();
		float height = pdf.getDefaultPageSize().getHeight();
		int n = pdf.getNumberOfPages();
		PdfCanvas canvas;
		Rectangle pageSize;
		for(int i=1;i<=n;i++)
		{
			PdfPage page = pdf.getPage(i);
			pageSize = page.getPageSize();
			canvas = new PdfCanvas(page);
			canvas.setStrokeColor(ColorConstants.BLACK).setLineWidth(.2f).moveTo(pageSize.getWidth()/2-30,20).lineTo(pageSize.getWidth()/2+30,20).stroke();

			//Draw page number
			canvas.beginText().setFontAndSize(PdfFontFactory.createFont(FontConstants.HELVETICA),7).moveText(pageSize.getWidth()/2-7,10).showText(String.valueOf(i)).showText(" of ").showText(String.valueOf(n)).endText();

			//add border
			canvas.rectangle(20, 20, width - 40, height - 40);
			canvas.stroke();
		}
		document.close();
		//pdf.close();
		
		//checkin file
		checkinFile(context, sRouteId, strTransPath, strFileName);
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
			
		}
		HashMap hmReturnMap = new HashMap();
		hmReturnMap.put("Action","Success");
		return hmReturnMap;
	}
	private static Cell createCell(String content, float borderWidth, int colspan, TextAlignment alignment) {
		Cell cell = new Cell(1, colspan).add(new Paragraph(content));
		cell.setTextAlignment(alignment);
		if(borderWidth==0)
			cell.setBorder(Border.NO_BORDER);
		else
			cell.setBorder(new SolidBorder(borderWidth));
		return cell;
	}
	private static void checkinFile(Context context, String strObjId, String strFilePath, String strFileName) throws Exception
	{
		DomainObject dObject = DomainObject.newInstance(context,strObjId);
		ContextUtil.pushContext(context);
		dObject.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strFilePath);
		ContextUtil.popContext(context);
	}
	private static String getImgFile(Context context) throws Exception
	{
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
		String strLogo = newFile.getCanonicalPath()+strImageFolder+"banner.png";
		strLogo = strLogo.replace("\\", "/");
		return strLogo;
	}
}
