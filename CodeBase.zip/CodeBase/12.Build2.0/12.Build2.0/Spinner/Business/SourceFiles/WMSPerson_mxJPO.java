/**
 *  ${CLASSNAME}.java
 *
 * (c) Dassault Systemes, 1993 - 2017. All rights reserved.
 * This program contains proprietary and trade secret information of
 * ENOVIA MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
 import java.util.HashMap;
 import java.util.Map;
 import java.text.SimpleDateFormat;
 import java.util.Vector;
 import java.util.Iterator;
 import java.text.DecimalFormat;
 import java.io.FileWriter;   
 import java.io.IOException;
 import java.io.File;
 import com.wms.batch.RunBatch;
 import java.lang.Long;
 
 import matrix.db.Context;
 import matrix.db.JPO;
 import matrix.util.StringList;
 import java.math.BigDecimal;
 import java.util.Date;
 import java.util.Locale;
 
 import com.matrixone.jdom.Element;
 import com.matrixone.apps.domain.util.MapList;
 import com.matrixone.apps.domain.DomainRelationship;
 import com.matrixone.apps.domain.DomainConstants;
 import com.matrixone.apps.domain.DomainObject;
 import com.matrixone.apps.framework.ui.UITableIndented;
 import com.matrixone.apps.domain.util.eMatrixDateFormat;
 import com.matrixone.apps.domain.util.FrameworkUtil;
 import com.matrixone.apps.domain.util.ContextUtil;
 import com.matrixone.apps.framework.ui.UIUtil;
 import com.matrixone.apps.domain.util.MqlUtil;
 import com.matrixone.apps.domain.util.EnoviaResourceBundle;
 import com.matrixone.apps.domain.util.PersonUtil;
 import com.matrixone.apps.common.InboxTask;
 /**
 * This JPO includes the code related to the Approval History Functionality
 */
public class WMSPerson_mxJPO extends WMSConstants_mxJPO
{

 /**
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments
     * @throws Exception if the operation fails
     * @grade 0
     */
    public WMSPerson_mxJPO (Context context, String[] args) throws Exception
    {
		super(context,args);
    }
  /**
     * Method is used to populate the data for Royalty Charges page
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args The packed argument for JPO, containing the program map.
     *             This program map will have request parameter information, objectId and information about the UI table object.
     * @return MapList of data
     * @throws Exception
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getPersonEntries(Context context, String[] args) throws Exception {
		MapList mlPersonNames = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");

            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add("attribute[Start Date]");
				slObjectSelects.add("attribute[End Date]");
				slObjectSelects.add("attribute[Title]");
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
                mlPersonNames = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_PERSON,
															TYPE_WMS_PERSON,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
				
				String strEndDate = DomainConstants.EMPTY_STRING;
				for (int i = 0; i < mlPersonNames.size(); i++) {
					Map mMap = (Map) mlPersonNames.get(i);
					strEndDate = (String) mMap.get("attribute[End Date]");
					if (UIUtil.isNotNullAndNotEmpty(strEndDate)) {
						mMap.put("disableSelection", "true");
						mMap.put("RowEditable", "readonly");
					}
				}				
															
				mlPersonNames.sort("attribute[Start Date]", "ascending", "date");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlPersonNames;
	}
	
 /**
     * To create a SOR Library
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds the following input arguments
     *      0 - requestMap
     * @return Map contains created objectId
     * @throws Exception
     */
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public HashMap createPersonEntry(Context context, String [] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Map paramMap = (Map) programMap.get("paramMap");
		String sObjectId=(String)paramMap.get("objectId");

		String sRowId = "" ;
		String strNewObject = "";

		HashMap columnsMap;
		HashMap changedRowMap;
		HashMap doc = new HashMap();
		HashMap retMap;
		DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
		DomainObject doBillItemObject = DomainObject.newInstance(context);

		Element elm = (Element) programMap.get("contextData");        
		MapList mlItems = new MapList();
		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		Map mapAttr = new HashMap();     

		for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
		{
			try
			{   
				retMap = new HashMap();
				changedRowMap = (HashMap) chgRowsMapList.get(i);
				columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");

				String strName = (String) columnsMap.get("Title");
				String strStartDate = (String) columnsMap.get("StartDate");
				String strEndDate = (String) columnsMap.get("EndDate");

				strNewObject = DomainObject.getAutoGeneratedName(context, "type_WMSPerson", DomainConstants.EMPTY_STRING);
				
				DomainRelationship domRel   = doBillItemObject.createAndConnect(context,
						TYPE_WMS_PERSON,
						strNewObject,
						"-",
					    POLICY_WMS_PERSON,
						null,
						RELATIONSHIP_WMS_PERSON,
						domAmbObject,
						true);

				mapAttr = new HashMap();
				if (strName != null && !"".equals(strName)) {
					mapAttr.put("Title", strName);
				}
				if (strStartDate != null && !"".equals(strStartDate)) {
					mapAttr.put("Start Date", strStartDate);
				}
				if (strEndDate != null && !"".equals(strEndDate)) {
					mapAttr.put("End Date", strEndDate);
				}
				doBillItemObject.setAttributeValues(context,mapAttr);
				retMap = new HashMap();
				retMap.put("oid", doBillItemObject.getObjectId(context));
				retMap.put("relid", domRel.toString());
				retMap.put("pid", "");
				retMap.put("rid", "");
				retMap.put("markup", "new");
				retMap.put("rowId", sRowId);
				columnsMap.putAll(retMap);
				retMap.put("columns", columnsMap);
				mlItems.add(retMap);
				doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
				doc.put("Action", "success"); // Here the action can be "Success" or "refresh"
			}
			catch(Exception Ex)
			{
				Ex.printStackTrace();
				throw Ex;
			}
		}
		return doc;
	}

public HashMap reassignPerson(Context context, String[] args)throws Exception{
	HashMap mReturnMap = new HashMap();
	boolean bContextPushed = false;
	try{
		
		String strPerson1 = (String)args[0];
		String strPerson2 = (String)args[1];
		
		if(UIUtil.isNotNullAndNotEmpty(strPerson1) && UIUtil.isNotNullAndNotEmpty(strPerson2)){
			ContextUtil.pushContext(context);
			bContextPushed = true;
			//MqlUtil.mqlCommand(context,"trig off");
			
			DomainObject doPerson1 = DomainObject.newInstance(context,strPerson1);
			DomainObject doPerson2 = DomainObject.newInstance(context,strPerson2);
			
			String strPerson1Name = (String)doPerson1.getInfo(context,DomainObject.SELECT_NAME);
			String strPerson2Name = (String)doPerson2.getInfo(context,DomainObject.SELECT_NAME);
			
			//Updating Projects - Start
			String strProjects = (String)MqlUtil.mqlCommand(context,"print bus "+strPerson1+" select to[Member|from.type=='Project Space'].id dump |");
			StringList slProjectMemberList = FrameworkUtil.split(strProjects,"|");
			
			String strProjectMemberRelId = "";
			String strProjectOwner = "";
			String strProjectId = "";
			String strProjectNameId = "";
			StringList slProjectNameId = new StringList();
			for(int i=0;i<slProjectMemberList.size();i++){
				strProjectMemberRelId = (String)slProjectMemberList.get(i);
				strProjectNameId = (String)MqlUtil.mqlCommand(context,"print connection "+strProjectMemberRelId+" select from.owner from.id dump |");
				slProjectNameId = FrameworkUtil.split(strProjectNameId,"|");
				strProjectOwner = (String)slProjectNameId.get(0);
				strProjectId = (String)slProjectNameId.get(1);
				//if(strProjectOwner.equals(strPerson1Name)){
				//	MqlUtil.mqlCommand(context,"mod bus "+strProjectId+" owner '"+strPerson2Name+"'");
				//}
				try{
					DomainRelationship.setToObject(context, strProjectMemberRelId, doPerson2);
				}catch(Exception ex){
					continue;
				}
			}
			
			//Updating WorkOrders - End
			
			//Updating Projects - Start
			String strWorkOrders = (String)MqlUtil.mqlCommand(context,"print bus "+strPerson1+" select from[WMSWorkOrderAssignee|to.type=='WMSWorkOrder'].id dump |");
			StringList slWorkOrderMemberList = FrameworkUtil.split(strWorkOrders,"|");
			
			String strWOMemberRelId = "";
			String strWOOwner = "";
			String strWOId = "";
			String strWONameId = "";
			
			StringList slWONameId = new StringList();
			for(int i=0;i<slWorkOrderMemberList.size();i++){
				strWOMemberRelId = (String)slWorkOrderMemberList.get(i);
				strWONameId = (String)MqlUtil.mqlCommand(context,"print connection "+strWOMemberRelId+" select to.owner to.id dump |");
				slWONameId = FrameworkUtil.split(strWONameId,"|");
				strWOOwner = (String)slWONameId.get(0);
				strWOId = (String)slWONameId.get(1);
				//if(strWOOwner.equals(strPerson1Name)){
				//	MqlUtil.mqlCommand(context,"mod bus "+strWOId+" owner '"+strPerson2Name+"'");
				//}
				try{
					DomainRelationship.setFromObject(context, strWOMemberRelId, doPerson2);
				}catch(Exception ex){
					continue;
				}
			}
			
			//Updating WorkOrders - End
			
			//Updating WBS Tasks - Start
			String strWBSTasks = (String)MqlUtil.mqlCommand(context,"print bus "+strPerson1+" select from[Assigned Tasks].id dump |");
			StringList slWBSTaskList = FrameworkUtil.split(strWBSTasks,"|");
		
			String strWBSMemberRelId = "";
			String strWBSOwner = "";
			String strWBSId = "";
			String strWBSNameId = "";
			
			StringList slWBSNameId = new StringList();
			for(int i=0;i<slWBSTaskList.size();i++){
				strWBSMemberRelId = (String)slWBSTaskList.get(i);
				strWBSNameId = (String)MqlUtil.mqlCommand(context,"print connection "+strWBSMemberRelId+" select to.owner to.id dump |");
				slWBSNameId = FrameworkUtil.split(strWBSNameId,"|");
				strWBSOwner = (String)slWBSNameId.get(0);
				strWBSId = (String)slWBSNameId.get(1);
				//if(strWBSOwner.equals(strPerson1Name)){
				//	MqlUtil.mqlCommand(context,"mod bus "+strWBSId+" owner '"+strPerson2Name+"'");
				//}
				try{
					DomainRelationship.setFromObject(context, strWBSMemberRelId, doPerson2);
				}catch(Exception ex){
					continue;
				}
			}
			//Updating WBS Tasks - End	

			//Updating Observations - Start
			String strObservations = (String)MqlUtil.mqlCommand(context,"print bus "+strPerson1+" select from[WMSObservationAssignee|to.type=='WMSObservation'].id dump |");
			StringList slObservationList = FrameworkUtil.split(strObservations,"|");
			
			String strObservationMemberRelId = "";
			String strObservationOwner = "";
			String strObservationId = "";
			String strObservationNameId = "";
			StringList slObservationNameId = new StringList();
			for(int i=0;i<slObservationList.size();i++){
				strObservationMemberRelId = (String)slObservationList.get(i);
				strObservationNameId = (String)MqlUtil.mqlCommand(context,"print connection "+strObservationMemberRelId+" select from.owner from.id dump |");
				slObservationNameId = FrameworkUtil.split(strObservationNameId,"|");
				strObservationOwner = (String)slObservationNameId.get(0);
				strObservationId = (String)slObservationNameId.get(1);

				try{
					DomainRelationship.setFromObject(context, strObservationMemberRelId, doPerson2);
				}catch(Exception ex){
					continue;
				}
			}
			
			//Updating Observations - End
			
			//Updating Inbox Tasks - Start
			String strInboxTasks = (String)MqlUtil.mqlCommand(context,"print bus "+strPerson1+" select to[Project Task|from.current!=Complete].from.id dump |");
			StringList slInboxTasks = FrameworkUtil.split(strInboxTasks,"|");
			
			InboxTask inboxTaskObj = (InboxTask)DomainObject.newInstance(context,DomainConstants.TYPE_INBOX_TASK);
			String strInboxTaskId = "";
			for(int i=0;i<slInboxTasks.size();i++){
				strInboxTaskId = (String)slInboxTasks.get(i);
				inboxTaskObj.setId(strInboxTaskId);
				inboxTaskObj.delegateTask(context, (String)strPerson2,true);
			}
			
			//Updating Inbox Tasks - End
		}
		
		mReturnMap.put("Action","success");

		return mReturnMap;
	}catch(Exception ex){
		ex.printStackTrace();
		throw ex;
	}finally{
		if(bContextPushed)
			ContextUtil.popContext(context);
		//MqlUtil.mqlCommand(context,"trig on");
	}
	
}
@com.matrixone.apps.framework.ui.PostProcessCallable
public HashMap reassignPersonFromUI(Context context, String[] args)throws Exception{
	HashMap mReturnMap = new HashMap();
	boolean bContextPushed = false;
	try{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		HashMap requestMap = (HashMap)programMap.get("requestMap");
		String strPerson1 = (String)requestMap.get("Person1OID");
		String strPerson2 = (String)requestMap.get("Person2OID");
		if(UIUtil.isNotNullAndNotEmpty(strPerson1) && UIUtil.isNotNullAndNotEmpty(strPerson2)){
			String strMQLPath = EnoviaResourceBundle.getProperty(context,"WMS.Environment.MQLPath");
			String strTempFolder = context.createWorkspace();
			FileWriter myWriter = new FileWriter(strTempFolder+File.separator+"Reassignment.bat");
			myWriter.write("echo off\n"+strMQLPath+File.separator+"mql.exe -c -remain \"set context user creator; trigger on; verbose; exec program WMSPerson -method reassignPerson "+strPerson1+" "+strPerson2+";\"");
			myWriter.close();
			
			RunBatch rubBatch = new RunBatch();
			rubBatch.execBatch(strTempFolder+File.separator, strTempFolder+File.separator+"Reassignment.bat");
			
		}
		
		mReturnMap.put("Action","success");

		return mReturnMap;
	}catch(Exception ex){
		ex.printStackTrace();
		throw ex;
	}finally{
		if(bContextPushed)
			ContextUtil.popContext(context);
		}	
	}
	
	/**
	 * PENDING header and annotation
	 * Method to Generate the Serial Numbers after the Object Creation
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public static Vector getPersonRole(Context context, String[] args) throws Exception {
		try{
			Map programMap =   (Map)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			
			Map mTemp = null;
			String strUserName = "";
			String strPersonId = "";
			String strAttrValue = "";
			DomainObject doPerson = DomainObject.newInstance(context);
			
			for(int i=0; i < objectList.size(); i++) {
				mTemp = (Map)objectList.get(i);
				strUserName = (String)mTemp.get("username");
				if(UIUtil.isNotNullAndNotEmpty(strUserName)){
					strPersonId = PersonUtil.getPersonObjectID(context,strUserName);
					doPerson.setId(strPersonId);
					strAttrValue = (String)doPerson.getAttributeValue(context,"HostPersonRole");
					vecResponse.add(strAttrValue);
				}else{
					vecResponse.add("");
				}
			}           

			return vecResponse;
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public static Vector getPersonDesignation(Context context, String[] args) throws Exception {
		try{
			Map programMap =   (Map)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			
			Map mTemp = null;
			String strUserName = "";
			String strPersonId = "";
			String strAttrValue = "";
			DomainObject doPerson = DomainObject.newInstance(context);
			
			for(int i=0; i < objectList.size(); i++) {
				mTemp = (Map)objectList.get(i);
				strUserName = (String)mTemp.get("username");
				if(UIUtil.isNotNullAndNotEmpty(strUserName)){
					strPersonId = PersonUtil.getPersonObjectID(context,strUserName);
					doPerson.setId(strPersonId);
					strAttrValue = (String)doPerson.getAttributeValue(context,"WMSPersonDesignation");
					vecResponse.add(strAttrValue);
				}else{
					vecResponse.add("");
				}
			}           

			return vecResponse;
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	 public String transferSelectedTasks(Context context, String[] args) throws Exception {
		String strReturn = "<input type='checkbox' id='transferTasks' name='transferTasks' value='yes'>";
		return strReturn;
	}
	
	@com.matrixone.apps.framework.ui.PostProcessCallable
	public void tranferTasks(Context context, String[] args)throws Exception{
		try{
			Map programMap =   (Map)JPO.unpackArgs(args);
			Map requestMap = (Map)programMap.get("requestMap");
			String strStartDate = (String)requestMap.get("LeaveStart_msvalue");
			String strEndDate = (String)requestMap.get("LeaveEnd_msvalue");
			String strComments = (String)requestMap.get("Comments");
			String strToPersonId = (String)requestMap.get("TransferToOID");
			String strToPerson = (String)requestMap.get("TransferTo");
			String strTransferTasks = (String)requestMap.get("transferTasks");
			
			String strPersonId = PersonUtil.getPersonObjectID(context,context.getUser());
			
			long lStartTime = Long.parseLong(strStartDate);
			long lEndTime = Long.parseLong(strEndDate);
			Date dStart = new Date(lStartTime);
			Date dEnd = new Date(lEndTime);
			
			SimpleDateFormat sdf = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), context.getLocale());
			strStartDate = sdf.format(dStart);
			strEndDate = sdf.format(dEnd);
			
			HashMap mAttrMap = new HashMap();
			mAttrMap.put("Absence Start Date",strStartDate);
			mAttrMap.put("Absence End Date",strEndDate);
			mAttrMap.put("Absence Delegate",strToPerson);
			
			if(UIUtil.isNotNullAndNotEmpty(strPersonId)){
				DomainObject doPerson = DomainObject.newInstance(context,strPersonId);
				doPerson.setAttributeValues(context,mAttrMap);
			}
			
			if(UIUtil.isNotNullAndNotEmpty(strTransferTasks) && "Yes".equalsIgnoreCase(strTransferTasks)){
				DomainObject doToPerson = DomainObject.newInstance(context,strToPersonId);
				MapList mlInboxTasks = JPO.invoke(context, "emxDashboardRoutes",args,"getRouteTasksAssignedPending",args,MapList.class); 
				
				MapList mlProjectTasks = JPO.invoke(context, "emxProgramUI",args,"getAssignedTasksPending",args,MapList.class); 
				
				Map mInboxTask = null;
				String strInboxTaskId = "";
				String strProjectTask = "";
				String strDelegatedUser = "";
				
				InboxTask inboxTaskObj = (InboxTask)DomainObject.newInstance(context,DomainConstants.TYPE_INBOX_TASK);
				for(int i=0;i<mlInboxTasks.size();i++){
					mInboxTask = (Map)mlInboxTasks.get(i);
					strInboxTaskId = (String)mInboxTask.get(DomainObject.SELECT_ID);
					inboxTaskObj.setId(strInboxTaskId);
					strDelegatedUser = (String)inboxTaskObj.getAttributeValue(context,"WMSInboxTaskFromUser");
					String strUser = context.getUser();
					String strOwnerID = PersonUtil.getPersonObjectID(context, strUser);
					DomainObject dom=DomainObject.newInstance(context,strOwnerID);
					String strOwnerFullName =dom.getInfo(context, "attribute[WMSPersonDesignation].value");
					if(UIUtil.isNotNullAndNotEmpty(strDelegatedUser) && strToPerson.equals(strDelegatedUser)){
						inboxTaskObj.setAttributeValue(context,"WMSInboxTaskFromUser","");
					}else{
						inboxTaskObj.setAttributeValue(context,"WMSInboxTaskFromUser",strOwnerFullName);
					}					
					inboxTaskObj.delegateTask(context, (String)strToPersonId,true);
					
				}
				
				DomainObject doProjectTask = DomainObject.newInstance(context);
				Map mProjectTask = null;
				for(int i=0;i<mlProjectTasks.size();i++){
					mProjectTask = (Map)mlProjectTasks.get(i);
					strProjectTask = (String)mProjectTask.get(DomainObject.SELECT_ID);
					doProjectTask.setId(strProjectTask);
					String strRelExist = MqlUtil.mqlCommand(context,"print bus "+strProjectTask+" select to[Assigned Tasks|from.name=='"+strToPerson+"'].id dump");
					if(UIUtil.isNullOrEmpty(strRelExist)){
						ContextUtil.pushContext(context);
						DomainRelationship.connect(context,doToPerson,"Assigned Tasks",doProjectTask);
						ContextUtil.popContext(context);
					}
				}
				
				if(mlProjectTasks.size()>0 || mlInboxTasks.size()>0){
					String sMessageBody = "Tasks are delegated to you by "+context.getUser()+" as per following comment: "+strComments;
					emxNotificationUtil_mxJPO.sendJavaMail(context,new StringList(strToPerson), null, null, "Tasks Delegated by "+context.getUser(), sMessageBody, sMessageBody, context.getUser(), null,null, "both");
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}		
	}
	
}