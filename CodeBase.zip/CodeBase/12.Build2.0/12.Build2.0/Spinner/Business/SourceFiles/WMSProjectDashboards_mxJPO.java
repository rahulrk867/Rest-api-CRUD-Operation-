import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.Date;
import java.util.Locale;
import java.text.SimpleDateFormat;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.framework.ui.ProgramCallable;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Iterator;
import com.matrixone.apps.common.Person;
import  org.apache.poi.hssf.usermodel.HSSFSheet;  
import  org.apache.poi.hssf.usermodel.HSSFWorkbook;  
import  org.apache.poi.hssf.usermodel.HSSFRow;  

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;   
import org.apache.poi.ss.usermodel.Workbook;  
import java.io.*; 

public class WMSProjectDashboards_mxJPO extends WMSConstants_mxJPO {

public WMSProjectDashboards_mxJPO(Context context, String[] args) throws Exception {
		super(context, args);
	}

@ProgramCallable
public MapList getProjectUnderExecution(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String strWhereCondition ="from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation ";

		DomainObject doPerson = PersonUtil.getPersonObject(context);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalAmount].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
		String strCurrent = " ";
		String StrDateFormat= " ";
		String SAdminCost= " ";
		String Sname= " ";
		String StrDateFormat1 =" ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
			
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				 Sname=(String) mMap.get("description");
				
				
			StrDateFormat1 = (String) mMap.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mMap.put("ProjectStartDate", (dt21.format(date1))+"");
				
			Double TotalWeek= Double.parseDouble((String)mMap.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			
			int TotalIntWeek = (int) Math.round(TotalWeek);
			
			int TotalDays = TotalIntWeek*7;
			
			
			//DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
		
			
			
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mMap.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojects(Context context, String[] args) throws Exception {
		MapList mlSOC = new MapList();
		try {
			DomainObject doPerson = PersonUtil.getPersonObject(context);
			String objectWhere = "revision==last && current!=Create && current!=Submit && current!=Rejected && current!=UnderExecution && current!=Delegation";
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			//strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			//slObjSelects.addElement("id");
			strListBusSelects.addElement("id");
			strListBusSelects.addElement("physicalid");
			strListBusSelects.addElement("type");
			strListBusSelects.addElement("current");
			strListBusSelects.addElement("policy");
			strListBusSelects.addElement("name");
			strListBusSelects.addElement("description");
			strListBusSelects.addElement("attribute[WMSSOCProjectType]");
			strListBusSelects.addElement("attribute[WMSSOCFinancialYear]");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlSOC = doPerson.findObjects(context, TYPE_WMSSOC, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					objectWhere, // where clause
					strListBusSelects); // object selects
			
			String strCurrent = DomainConstants.EMPTY_STRING;
			for (int i = 0; i < mlSOC.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlSOC.get(i);
				mMap.put("DgnpCount", count+"");
				strCurrent = (String) mMap.get(DomainConstants.SELECT_CURRENT);
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return mlSOC;
	}
public String getSOCAttributeValue(Context context,String args[]) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		HashMap fieldMap = (HashMap) programMap.get("fieldMap");
		HashMap settings = (HashMap) fieldMap.get("settings");

		String strSOCId = (String) paramMap.get("objectId");
		String strAttributeName = (String) settings.get("attribute");

		DomainObject doSOC = DomainObject.newInstance(context, strSOCId);
		String strAttributeValue = doSOC.getInfo(context, "attribute["+strAttributeName+"].value");

		if("TRUE".equals(strAttributeValue))
		{
			strAttributeValue = "Yes";
		}
		if("FALSE".equals(strAttributeValue))
		{
			strAttributeValue = "No";
		}

		return strAttributeValue;
	}
	@ProgramCallable
	public MapList getProjectUnderExecutionAOB(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition ="(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==AOB";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																	
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojectsAOB(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
	
		String strWhereCondition ="(from[WMSProjectSOC].to.current==RIC || from[WMSProjectSOC].to.current==ListingOfProjects || from[WMSProjectSOC].to.current==BoardProceedings || from[WMSProjectSOC].to.current==AE || from[WMSProjectSOC].to.current==AdminApproval) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==AOB";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
			}
			
		return mlRelatedProjectDetails;
	}
	@ProgramCallable
	public MapList getProjectUnderExecutionSFC(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition ="(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==SFC";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																	System.out.println("-------562----"+mlRelatedProjectDetails);
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojectsSFC(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
	
		String strWhereCondition ="(from[WMSProjectSOC].to.current==RIC || from[WMSProjectSOC].to.current==ListingOfProjects || from[WMSProjectSOC].to.current==BoardProceedings || from[WMSProjectSOC].to.current==AE || from[WMSProjectSOC].to.current==AdminApproval) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==SFC";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
			}
			
		return mlRelatedProjectDetails;
	}
	@ProgramCallable
	public MapList getProjectUnderExecutionATVP(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition ="(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==ATVP";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																	System.out.println("-------562----"+mlRelatedProjectDetails);
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojectsATVP(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
	
		String strWhereCondition ="(from[WMSProjectSOC].to.current==RIC || from[WMSProjectSOC].to.current==ListingOfProjects || from[WMSProjectSOC].to.current==BoardProceedings || from[WMSProjectSOC].to.current==AE || from[WMSProjectSOC].to.current==AdminApproval) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==ATVP";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
			}
			
		return mlRelatedProjectDetails;
	}
		@ProgramCallable
	public MapList getProjectUnderExecutionATWP(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition ="(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==ATWP";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																	
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
			
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojectsATWP(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
	
		String strWhereCondition ="(from[WMSProjectSOC].to.current==RIC || from[WMSProjectSOC].to.current==ListingOfProjects || from[WMSProjectSOC].to.current==BoardProceedings || from[WMSProjectSOC].to.current==AE || from[WMSProjectSOC].to.current==AdminApproval) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==ATWP";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
			}
			
		return mlRelatedProjectDetails;
		
	}
	/*public MapList getPreAAprojectsATWP(Context context, String[] args) throws Exception {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sPersonID = (String) programMap.get("objectId");
				System.out.println("------PersonidatwpAAA-----"+sPersonID);
		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		//DomainObject doPerson = PersonUtil.getPersonObject(context);
		MapList mlSOC = new MapList();
			System.out.println("-------------------------------------------------------------------------------Check-----"+doPerson);
			String objectWhere = "revision==last && current!=Create && current!=Submit && current!=Rejected && current!=UnderExecution && current!=Delegation && attribute[WMSSOCProjectType].value==ATWP";
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			//strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			//slObjSelects.addElement("id");
			strListBusSelects.addElement("id");
			strListBusSelects.addElement("physicalid");
			strListBusSelects.addElement("type");
			strListBusSelects.addElement("current");
			strListBusSelects.addElement("policy");
			strListBusSelects.addElement("name");
			strListBusSelects.addElement("description");
			strListBusSelects.addElement("attribute[WMSSOCProjectType]");
			strListBusSelects.addElement("attribute[WMSSOCFinancialYear]");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlSOC = doPerson.findObjects(context, TYPE_WMSSOC, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					objectWhere, // where clause
					strListBusSelects); // object selects
															
			String strCurrent = DomainConstants.EMPTY_STRING;
			for (int i = 0; i < mlSOC.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlSOC.get(i);
				mMap.put("DgnpCount", count+"");
				strCurrent = (String) mMap.get(DomainConstants.SELECT_CURRENT);
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
			}
		System.out.println("------mlSOC"+mlSOC);
		return mlSOC;
	}*/
	
	public MapList getProjectUnderExecutionDNSPI(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition ="(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==DNSPI";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																	
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojectsDNSPI(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
	
		String strWhereCondition ="(from[WMSProjectSOC].to.current==RIC || from[WMSProjectSOC].to.current==ListingOfProjects || from[WMSProjectSOC].to.current==BoardProceedings || from[WMSProjectSOC].to.current==AE || from[WMSProjectSOC].to.current==AdminApproval) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==DNSPI";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
													
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
			}
			
		return mlRelatedProjectDetails;
	}
	public MapList getProjectUnderExecutionCONSULTANCY(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition ="(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==CONSULTANCY";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																	System.out.println("-------562----"+mlRelatedProjectDetails);
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojectsCONSULTANCY(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition ="(from[WMSProjectSOC].to.current==RIC || from[WMSProjectSOC].to.current==ListingOfProjects || from[WMSProjectSOC].to.current==BoardProceedings || from[WMSProjectSOC].to.current==AE || from[WMSProjectSOC].to.current==AdminApproval) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==CONSULTANCY";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																	
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
			}
			
		return mlRelatedProjectDetails;
	}
	public MapList getProjectUnderExecutionHQENC(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition ="(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==HQENC";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
																	System.out.println("-------562----"+mlRelatedProjectDetails);
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojectsHQENC(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
	
		String strWhereCondition ="(from[WMSProjectSOC].to.current==RIC || from[WMSProjectSOC].to.current==ListingOfProjects || from[WMSProjectSOC].to.current==BoardProceedings || from[WMSProjectSOC].to.current==AE || from[WMSProjectSOC].to.current==AdminApproval) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==HQENC";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
													
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
			}
			
		return mlRelatedProjectDetails;
	}
	public MapList getProjectUnderExecutionAMWP(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
		String strWhereCondition ="(from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==AMWP";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojectsAMWP(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String sPersonID = (String) programMap.get("objectId");
	
		String strWhereCondition ="(from[WMSProjectSOC].to.current==RIC || from[WMSProjectSOC].to.current==ListingOfProjects || from[WMSProjectSOC].to.current==BoardProceedings || from[WMSProjectSOC].to.current==AE || from[WMSProjectSOC].to.current==AdminApproval) && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value==AMWP";

		DomainObject doPerson = DomainObject.newInstance(context, sPersonID);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]"); 
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
													
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
			}
			
		return mlRelatedProjectDetails;
	}
	public void getOverAllDashboardDetails (Context context, String args[])throws Exception{
		String strWhere = "current == Active";
		
		
		/*if(args.length>0){
			String strArgsPersonName = (String)args[0];
			strWhere = strWhere + " && name == '"+strArgsPersonName+"'";
		}*/
		StringList selectStmts = new StringList(2);
		selectStmts.add(DomainConstants.SELECT_ID);
		selectStmts.add(DomainConstants.SELECT_NAME);
		
		MapList mlPersonList = (MapList)DomainObject.findObjects(context,
																 DomainConstants.TYPE_PERSON,
																 DomainConstants.QUERY_WILDCARD,
																 strWhere,
																 selectStmts);
		Iterator itrPerson = mlPersonList.iterator();
		Person person = new Person();
		while (itrPerson.hasNext())
		{
			Map mpPerson = (Map) itrPerson.next();
			String strPersonId = (String)mpPerson.get(DomainConstants.SELECT_ID); 
			String strPersonName = (String)mpPerson.get(DomainConstants.SELECT_NAME);
			// For ATWP
			Map mProjectDetails = new HashMap();
			mProjectDetails.put("objectId",strPersonId);
			mProjectDetails.put("whereCondition","current!=Create || current!=Archive");
			MapList mlProjectDetails =  (MapList)JPO.invoke(context, "WMSDashboards", null, "getProjectDetailsATWP", JPO.packArgs (mProjectDetails), MapList.class);
			int iTotal = 0;
			int iOnTime = 0;
			int iDelayed = 0;
			int iCompleted = 0;
			int iSize = mlProjectDetails.size();
			String strStatus = "";
			for (int i = 0 ; i < iSize ; i++)
			{
				strStatus = (String)((Map)mlProjectDetails.get(i)).get("status");
				if ("completed".equals(strStatus))
					iCompleted++;
				else if("ontime".equals(strStatus))
					iOnTime++;
				else if("delayed".equals(strStatus))
					iDelayed++;
			}
			iTotal = iSize;
			Map mProjectDetails1 = new HashMap();
					mProjectDetails1.put("objectId",strPersonId);
					MapList mlProjectDetails1 =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getPreAAprojectsATWP", JPO.packArgs (mProjectDetails1), MapList.class);
					int iTotal1=0;
					int iRic=0;
					int iAE=0;
					int iAA=0;


					int iSize1 = mlProjectDetails1.size();
					String strStatus1 = "";
					for (int j= 0 ; j < iSize1 ; j++)
					{
						strStatus1 = (String)((Map)mlProjectDetails1.get(j)).get("status");
						if (("RIC".equals(strStatus1)) || ("ListingOfProjects".equals(strStatus1)) || ("BoardProceedings".equals(strStatus1)))				
							iRic++;
						else if ("AE".equals(strStatus1))
							iAE++;
						else if ("AdminApproval".equals(strStatus1))
							iAA++;
					}
					iTotal1=iSize1;
					Map mProjectDetails2 = new HashMap();
					mProjectDetails2.put("objectId",strPersonId);
					MapList mlProjectDetails2 =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getProjectUnderExecutionATWP", JPO.packArgs (mProjectDetails2), MapList.class);
					int iUnderExecution=0;
					int iSize2 = mlProjectDetails2.size();
					String strStatus2 = "";
					for (int k= 0 ; k < iSize2 ; k++)
					{
						strStatus2 = (String)((Map)mlProjectDetails2.get(k)).get("status");
						if (("Delegation".equals(strStatus2)) || ("UnderExecution".equals(strStatus2)));
							iUnderExecution++;
					}
					
					Map mProjectDetailsAOB = new HashMap();
							mProjectDetailsAOB.put("objectId",strPersonId);
							mProjectDetailsAOB.put("whereCondition","current!=Create || current!=Archive");
							MapList mlProjectDetailsAOB =  (MapList)JPO.invoke(context, "WMSDashboards", null, "getProjectDetailsAOB", JPO.packArgs (mProjectDetailsAOB), MapList.class);
							int iTotalAOB = 0;
							int iOnTimeAOB = 0;
							int iDelayedAOB = 0;
							int iCompletedAOB = 0;

							int iSizeAOB = mlProjectDetailsAOB.size();
							String strStatusAOB = "";
							for (int i = 0 ; i < iSizeAOB ; i++)
							{
								strStatusAOB = (String)((Map)mlProjectDetailsAOB.get(i)).get("status");
								if ("completed".equals(strStatusAOB))
									iCompletedAOB++;
								else if("ontime".equals(strStatusAOB))
									iOnTimeAOB++;
								else if("delayed".equals(strStatusAOB))
									iDelayedAOB++;
							}
							iTotalAOB = iSizeAOB;
							Map mProjectDetailsPreAOB = new HashMap();
						mProjectDetailsPreAOB.put("objectId",strPersonId);
						MapList mlProjectDetails1preAOB =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getPreAAprojectsAOB", JPO.packArgs (mProjectDetailsPreAOB), MapList.class);
						int iTotal1AOB=0;
						int iRicAOB=0;
						int iAEAOB=0;
						int iAAAOB=0;


						int iSize1AOB = mlProjectDetails1preAOB.size();
						String strStatus1AOB = "";
						for (int j= 0 ; j < iSize1AOB ; j++)
						{
							strStatus1AOB = (String)((Map)mlProjectDetails1preAOB.get(j)).get("status");
							if (("RIC".equals(strStatus1AOB)) || ("ListingOfProjects".equals(strStatus1AOB)) || ("BoardProceedings".equals(strStatus1AOB))) 
								iRicAOB++;
							else if ("AE".equals(strStatus1AOB))
								iAEAOB++;
							else if ("AdminApproval".equals(strStatus1AOB))
								iAAAOB++;
						}
						iTotal1AOB=iSize1AOB;
						Map mProjectDetails2PostAOB = new HashMap();
				mProjectDetails2PostAOB.put("objectId",strPersonId);
				MapList mlProjectDetails2PostAob =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getProjectUnderExecutionAOB", JPO.packArgs (mProjectDetails2PostAOB), MapList.class);
				int iUnderExecutionAOB=0;
				int iSize2AOB = mlProjectDetails2PostAob.size();
				String strStatus2AOB = "";
				for (int k= 0 ; k < iSize2AOB ; k++)
				{
					strStatus2AOB = (String)((Map)mlProjectDetails2PostAob.get(k)).get("status");
					if (("Delegation".equals(strStatus2AOB)) || ("UnderExecution".equals(strStatus2AOB)));
						iUnderExecutionAOB++;
				}
				// SFC
				Map mProjectDetailsSFC = new HashMap();
				mProjectDetailsSFC.put("objectId",strPersonId);
				mProjectDetailsSFC.put("whereCondition","current!=Create || current!=Archive");
				MapList mlProjectDetailsSFC =  (MapList)JPO.invoke(context, "WMSDashboards", null, "getProjectDetailsSFC", JPO.packArgs (mProjectDetailsAOB), MapList.class);
				int iTotalSFC = 0;
				int iOnTimeSFC = 0;
				int iDelayedSFC = 0;
				int iCompletedSFC = 0;

				int iSizeSFC = mlProjectDetailsSFC.size();
				String strStatusSFC = "";
				for (int i = 0 ; i < iSizeSFC ; i++)
				{
					strStatusSFC = (String)((Map)mlProjectDetailsSFC.get(i)).get("status");
					if ("completed".equals(strStatusSFC))
						iCompletedSFC++;
					else if("ontime".equals(strStatusSFC))
						iOnTimeSFC++;
					else if("delayed".equals(strStatusSFC))
						iDelayedSFC++;
				}
				iTotalSFC = iSizeSFC;
				Map mProjectDetailsPreSFC = new HashMap();
				mProjectDetailsPreSFC.put("objectId",strPersonId);
				MapList mlProjectDetails1preSFC =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getPreAAprojectsSFC", JPO.packArgs (mProjectDetailsPreSFC), MapList.class);
				int iTotal1SFC=0;
				int iRicSFC=0;
				int iAESFC=0;
				int iAASFC=0;


				int iSize1SFC = mlProjectDetails1preSFC.size();
				String strStatus1SFC = "";
				for (int j= 0 ; j < iSize1SFC ; j++)
				{
					strStatus1SFC = (String)((Map)mlProjectDetails1preSFC.get(j)).get("status");
					if (("RIC".equals(strStatus1SFC)) || ("ListingOfProjects".equals(strStatus1SFC)) || ("BoardProceedings".equals(strStatus1SFC))) 
						iRicSFC++;
					else if ("AE".equals(strStatus1SFC))
						iAESFC++;
					else if ("AdminApproval".equals(strStatus1SFC))
						iAASFC++;
				}
				iTotal1SFC=iSize1SFC;
				Map mProjectDetails2PostSFC= new HashMap();
				mProjectDetails2PostSFC.put("objectId",strPersonId);
				MapList mlProjectDetails2PostSFC =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getProjectUnderExecutionSFC", JPO.packArgs (mProjectDetails2PostSFC), MapList.class);
				int iUnderExecutionSFC=0;
				int iSize2SFC = mlProjectDetails2PostSFC.size();
				String strStatus2SFC = "";
				for (int k= 0 ; k < iSize2SFC ; k++)
				{
					strStatus2SFC = (String)((Map)mlProjectDetails2PostSFC.get(k)).get("status");
					if (("Delegation".equals(strStatus2SFC)) || ("UnderExecution".equals(strStatus2SFC)));
						iUnderExecutionSFC++;
				}
				// ATVP
				Map mProjectDetailsATVP = new HashMap();
				mProjectDetailsATVP.put("objectId",strPersonId);
				mProjectDetailsATVP.put("whereCondition","current!=Create || current!=Archive");
				MapList mlProjectDetailsATVP =  (MapList)JPO.invoke(context, "WMSDashboards", null, "getProjectDetailsATVP", JPO.packArgs (mProjectDetailsATVP), MapList.class);
				int iTotalATVP = 0;
				int iOnTimeATVP = 0;
				int iDelayedATVP= 0;
				int iCompletedATVP = 0;

				int iSizeATVP = mlProjectDetailsATVP.size();
				String strStatusATVP = "";
				for (int i = 0 ; i < iSizeATVP ; i++)
				{
					strStatusATVP = (String)((Map)mlProjectDetailsATVP.get(i)).get("status");
					if ("completed".equals(strStatusATVP))
						iCompletedATVP++;
					else if("ontime".equals(strStatusATVP))
						iOnTimeATVP++;
					else if("delayed".equals(strStatusATVP))
						iDelayedATVP++;
				}
				iTotalATVP = iSizeATVP;
				Map mProjectDetailsPreATVP = new HashMap();
				mProjectDetailsPreATVP.put("objectId",strPersonId);
				MapList mlProjectDetails1preATVP =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getPreAAprojectsATVP", JPO.packArgs (mProjectDetailsPreATVP), MapList.class);
				int iTotal1ATVP=0;
				int iRicATVP=0;
				int iAEATVP=0;
				int iAAATVP=0;


				int iSize1ATVP = mlProjectDetails1preATVP.size();
				String strStatus1ATVP = "";
				for (int j= 0 ; j < iSize1ATVP ; j++)
				{
					strStatus1ATVP = (String)((Map)mlProjectDetails1preATVP.get(j)).get("status");
					if (("RIC".equals(strStatus1ATVP)) || ("ListingOfProjects".equals(strStatus1ATVP)) || ("BoardProceedings".equals(strStatus1ATVP))) 
						iRicATVP++;
					else if ("AE".equals(strStatus1ATVP))
						iAEAOB++;
					else if ("AdminApproval".equals(strStatus1ATVP))
						iAAATVP++;
				}
				iTotal1ATVP=iSize1ATVP;
				Map mProjectDetails2PostATVP= new HashMap();
				mProjectDetails2PostATVP.put("objectId",strPersonId);
				MapList mlProjectDetails2PostATVP =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getProjectUnderExecutionATVP", JPO.packArgs (mProjectDetails2PostATVP), MapList.class);
				int iUnderExecutionATVP=0;
				int iSize2ATVP = mlProjectDetails2PostATVP.size();
				String strStatus2ATVP = "";
				for (int k= 0 ; k < iSize2ATVP ; k++)
				{
					strStatus2ATVP = (String)((Map)mlProjectDetails2PostATVP.get(k)).get("status");
					if (("Delegation".equals(strStatus2ATVP)) || ("UnderExecution".equals(strStatus2ATVP)));
						iUnderExecutionATVP++;
				}
				 // DNSPI-->
				Map mProjectDetailsDNSPI = new HashMap();
				mProjectDetailsDNSPI.put("objectId",strPersonId);
				mProjectDetailsDNSPI.put("whereCondition","current!=Create || current!=Archive");
				MapList mlProjectDetailsDNSPI =  (MapList)JPO.invoke(context, "WMSDashboards", null, "getProjectDetailsDNSPI", JPO.packArgs (mProjectDetailsDNSPI), MapList.class);
				int iTotalDNSPI = 0;
				int iOnTimeDNSPI = 0;
				int iDelayedDNSPI= 0;
				int iCompletedDNSPI = 0;

				int iSizeDNSPI = mlProjectDetailsDNSPI.size();
				String strStatusDNSPI = "";
				for (int i = 0 ; i < iSizeDNSPI ; i++)
				{
					strStatusDNSPI = (String)((Map)mlProjectDetailsDNSPI.get(i)).get("status");
					if ("completed".equals(strStatusDNSPI))
						iCompletedDNSPI++;
					else if("ontime".equals(strStatusDNSPI))
						iOnTimeDNSPI++;
					else if("delayed".equals(strStatusDNSPI))
						iDelayedDNSPI++;
				}
				iTotalDNSPI = iSizeDNSPI;
				Map mProjectDetailsPreDNSPI = new HashMap();
				mProjectDetailsPreDNSPI.put("objectId",strPersonId);
				MapList mlProjectDetails1preDNSPI =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getPreAAprojectsDNSPI", JPO.packArgs (mProjectDetailsPreDNSPI), MapList.class);
				int iTotal1DNSPI=0;
				int iRicDNSPI=0;
				int iAEDNSPI=0;
				int iAADNSPI=0;


				int iSize1DNSPI = mlProjectDetails1preDNSPI.size();
				String strStatus1DNSPI = "";
				for (int j= 0 ; j < iSize1DNSPI ; j++)
				{
					strStatus1DNSPI = (String)((Map)mlProjectDetails1preDNSPI.get(j)).get("status");
					if (("RIC".equals(strStatus1DNSPI)) || ("ListingOfProjects".equals(strStatus1DNSPI)) || ("BoardProceedings".equals(strStatus1DNSPI))) 
						iRicDNSPI++;
					else if ("AE".equals(strStatus1DNSPI))
						iAEAOB++;
					else if ("AdminApproval".equals(strStatus1DNSPI))
						iAADNSPI++;
				}
				iTotal1DNSPI=iSize1DNSPI;
				Map mProjectDetails2PostDNSPI= new HashMap();
				mProjectDetails2PostDNSPI.put("objectId",strPersonId);
				MapList mlProjectDetails2PostDNSPI =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getProjectUnderExecutionDNSPI", JPO.packArgs (mProjectDetails2PostDNSPI), MapList.class);
				int iUnderExecutionDNSPI=0;
				int iSize2DNSPI = mlProjectDetails2PostDNSPI.size();
				String strStatus2DNSPI = "";
				for (int k= 0 ; k < iSize2DNSPI ; k++)
				{
					strStatus2DNSPI = (String)((Map)mlProjectDetails2PostDNSPI.get(k)).get("status");
					if (("Delegation".equals(strStatus2DNSPI)) || ("UnderExecution".equals(strStatus2DNSPI)));
						iUnderExecutionDNSPI++;
				}
				// CONSULTANCY-->
				Map mProjectDetailsCONSULTANCY = new HashMap();
				mProjectDetailsCONSULTANCY.put("objectId",strPersonId);
				mProjectDetailsCONSULTANCY.put("whereCondition","current!=Create || current!=Archive");
				MapList mlProjectDetailsCONSULTANCY =  (MapList)JPO.invoke(context, "WMSDashboards", null, "getProjectDetailsCONSULTANCY", JPO.packArgs (mProjectDetailsCONSULTANCY), MapList.class);
				int iTotalCONSULTANCY = 0;
				int iOnTimeCONSULTANCY = 0;
				int iDelayedCONSULTANCY= 0;
				int iCompletedCONSULTANCY = 0;

				int iSizeCONSULTANCY = mlProjectDetailsCONSULTANCY.size();
				String strStatusCONSULTANCY = "";
				for (int i = 0 ; i < iSizeCONSULTANCY ; i++)
				{
					strStatusCONSULTANCY = (String)((Map)mlProjectDetailsCONSULTANCY.get(i)).get("status");
					if ("completed".equals(strStatusCONSULTANCY))
						iCompletedCONSULTANCY++;
					else if("ontime".equals(strStatusCONSULTANCY))
						iOnTimeCONSULTANCY++;
					else if("delayed".equals(strStatusCONSULTANCY))
						iDelayedCONSULTANCY++;
				}
				iTotalCONSULTANCY = iSizeCONSULTANCY;
				Map mProjectDetailsPreCONSULTANCY = new HashMap();
				mProjectDetailsPreCONSULTANCY.put("objectId",strPersonId);
				MapList mlProjectDetails1preCONSULTANCY =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getPreAAprojectsCONSULTANCY", JPO.packArgs (mProjectDetailsPreCONSULTANCY), MapList.class);
				int iTotal1CONSULTANCY=0;
				int iRicCONSULTANCY=0;
				int iAECONSULTANCY=0;
				int iAACONSULTANCY=0;


				int iSize1CONSULTANCY = mlProjectDetails1preCONSULTANCY.size();
				String strStatus1CONSULTANCY = "";
				for (int j= 0 ; j < iSize1CONSULTANCY ; j++)
				{
					strStatus1CONSULTANCY = (String)((Map)mlProjectDetails1preCONSULTANCY.get(j)).get("status");
					if (("RIC".equals(strStatus1CONSULTANCY)) || ("ListingOfProjects".equals(strStatus1CONSULTANCY)) || ("BoardProceedings".equals(strStatus1CONSULTANCY))) 
						iRicCONSULTANCY++;
					else if ("AE".equals(strStatus1CONSULTANCY))
						iAEAOB++;
					else if ("AdminApproval".equals(strStatus1CONSULTANCY))
						iAACONSULTANCY++;
				}
				iTotal1CONSULTANCY=iSize1CONSULTANCY;
				Map mProjectDetails2PostCONSULTANCY= new HashMap();
				mProjectDetails2PostCONSULTANCY.put("objectId",strPersonId);
				MapList mlProjectDetails2PostCONSULTANCY =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getProjectUnderExecutionCONSULTANCY", JPO.packArgs (mProjectDetails2PostCONSULTANCY), MapList.class);
				int iUnderExecutionCONSULTANCY=0;
				int iSize2CONSULTANCY = mlProjectDetails2PostCONSULTANCY.size();
				String strStatus2CONSULTANCY = "";
				for (int k= 0 ; k < iSize2CONSULTANCY ; k++)
				{
					strStatus2CONSULTANCY = (String)((Map)mlProjectDetails2PostCONSULTANCY.get(k)).get("status");
					if (("Delegation".equals(strStatus2CONSULTANCY)) || ("UnderExecution".equals(strStatus2CONSULTANCY)));
						iUnderExecutionCONSULTANCY++;
				}
				// HQENC-->
				Map mProjectDetailsHQENC = new HashMap();
				mProjectDetailsHQENC.put("objectId",strPersonId);
				mProjectDetailsHQENC.put("whereCondition","current!=Create || current!=Archive");
				MapList mlProjectDetailsHQENC =  (MapList)JPO.invoke(context, "WMSDashboards", null, "getProjectDetailsHQENC", JPO.packArgs (mProjectDetailsHQENC), MapList.class);
				int iTotalHQENC = 0;
				int iOnTimeHQENC = 0;
				int iDelayedHQENC= 0;
				int iCompletedHQENC = 0;

				int iSizeHQENC = mlProjectDetailsHQENC.size();
				String strStatusHQENC = "";
				for (int i = 0 ; i < iSizeHQENC ; i++)
				{
					strStatusHQENC = (String)((Map)mlProjectDetailsHQENC.get(i)).get("status");
					if ("completed".equals(strStatusHQENC))
						iCompletedHQENC++;
					else if("ontime".equals(strStatusHQENC))
						iOnTimeHQENC++;
					else if("delayed".equals(strStatusHQENC))
						iDelayedHQENC++;
				}
				iTotalHQENC = iSizeHQENC;
				Map mProjectDetailsPreHQENC = new HashMap();
				mProjectDetailsPreHQENC.put("objectId",strPersonId);
				MapList mlProjectDetails1preHQENC =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getPreAAprojectsHQENC", JPO.packArgs (mProjectDetailsPreHQENC), MapList.class);
				int iTotal1HQENC=0;
				int iRicHQENC=0;
				int iAEHQENC=0;
				int iAAHQENC=0;


				int iSize1HQENC = mlProjectDetails1preHQENC.size();
				String strStatus1HQENC = "";
				for (int j= 0 ; j < iSize1HQENC ; j++)
				{
					strStatus1HQENC = (String)((Map)mlProjectDetails1preHQENC.get(j)).get("status");
					if (("RIC".equals(strStatus1HQENC)) || ("ListingOfProjects".equals(strStatus1HQENC)) || ("BoardProceedings".equals(strStatus1HQENC))) 
						iRicHQENC++;
					else if ("AE".equals(strStatus1HQENC))
						iAEAOB++;
					else if ("AdminApproval".equals(strStatus1HQENC))
						iAAHQENC++;
				}
				iTotal1HQENC=iSize1HQENC;
				Map mProjectDetails2PostHQENC= new HashMap();
				mProjectDetails2PostHQENC.put("objectId",strPersonId);
				MapList mlProjectDetails2PostHQENC =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getProjectUnderExecutionHQENC", JPO.packArgs (mProjectDetails2PostHQENC), MapList.class);
				int iUnderExecutionHQENC=0;
				int iSize2HQENC = mlProjectDetails2PostHQENC.size();
				String strStatus2HQENC = "";
				for (int k= 0 ; k < iSize2HQENC ; k++)
				{
					strStatus2HQENC = (String)((Map)mlProjectDetails2PostHQENC.get(k)).get("status");
					if (("Delegation".equals(strStatus2HQENC)) || ("UnderExecution".equals(strStatus2HQENC)));
						iUnderExecutionHQENC++;
				}
				// AMWP-->
				Map mProjectDetailsAMWP = new HashMap();
				mProjectDetailsAMWP.put("objectId",strPersonId);
				mProjectDetailsAMWP.put("whereCondition","current!=Create || current!=Archive");
				MapList mlProjectDetailsAMWP =  (MapList)JPO.invoke(context, "WMSDashboards", null, "getProjectDetailsAMWP", JPO.packArgs (mProjectDetailsAMWP), MapList.class);
				int iTotalAMWP = 0;
				int iOnTimeAMWP = 0;
				int iDelayedAMWP= 0;
				int iCompletedAMWP = 0;

				int iSizeAMWP = mlProjectDetailsAMWP.size();
				String strStatusAMWP = "";
				for (int i = 0 ; i < iSizeAMWP ; i++)
				{
					strStatusAMWP = (String)((Map)mlProjectDetailsAMWP.get(i)).get("status");
					if ("completed".equals(strStatusAMWP))
						iCompletedAMWP++;
					else if("ontime".equals(strStatusAMWP))
						iOnTimeAMWP++;
					else if("delayed".equals(strStatusAMWP))
						iDelayedAMWP++;
				}
				iTotalAMWP = iSizeAMWP;
				Map mProjectDetailsPreAMWP = new HashMap();
				mProjectDetailsPreAMWP.put("objectId",strPersonId);
				MapList mlProjectDetails1preAMWP =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getPreAAprojectsAMWP", JPO.packArgs (mProjectDetailsPreAMWP), MapList.class);
				int iTotal1AMWP=0;
				int iRicAMWP=0;
				int iAEAMWP=0;
				int iAAAMWP=0;


				int iSize1AMWP = mlProjectDetails1preAMWP.size();
				String strStatus1AMWP = "";
				for (int j= 0 ; j < iSize1AMWP ; j++)
				{
					strStatus1AMWP = (String)((Map)mlProjectDetails1preAMWP.get(j)).get("status");
					if (("RIC".equals(strStatus1AMWP)) || ("ListingOfProjects".equals(strStatus1AMWP)) || ("BoardProceedings".equals(strStatus1AMWP))) 
						iRicAMWP++;
					else if ("AE".equals(strStatus1AMWP))
						iAEAOB++;
					else if ("AdminApproval".equals(strStatus1AMWP))
						iAAAMWP++;
				}
				iTotal1AMWP=iSize1AMWP;
				Map mProjectDetails2PostAMWP= new HashMap();
				mProjectDetails2PostAMWP.put("objectId",strPersonId);
				MapList mlProjectDetails2PostAMWP =  (MapList)JPO.invoke(context, "WMSProjectDashboards", null, "getProjectUnderExecutionAMWP", JPO.packArgs (mProjectDetails2PostAMWP), MapList.class);
				int iUnderExecutionAMWP=0;
				int iSize2AMWP = mlProjectDetails2PostAMWP.size();
				String strStatus2AMWP = "";
				for (int k= 0 ; k < iSize2AMWP ; k++)
				{
					strStatus2AMWP = (String)((Map)mlProjectDetails2PostAMWP.get(k)).get("status");
					if (("Delegation".equals(strStatus2AMWP)) || ("UnderExecution".equals(strStatus2AMWP)));
						iUnderExecutionAMWP++;
				}
				int totalpreTotal=iTotal1+iTotal1AOB+iTotal1SFC+iTotal1ATVP+iTotal1DNSPI+iTotal1CONSULTANCY+iTotal1HQENC+iTotal1AMWP;
				int totalpreRIC=iRic+iRicAOB+iRicSFC+iRicATVP+iRicDNSPI+iRicCONSULTANCY+iRicHQENC+iRicAMWP;
				int totalpreAE=iAE+iAEAOB+iAESFC+iAEATVP+iAEDNSPI+iAECONSULTANCY+iAEHQENC+iAEAMWP;
				int totalpreAA=iAA+iAAAOB+iAASFC+iAAATVP+iAADNSPI+iAACONSULTANCY+iAAHQENC+iAAAMWP;
				int totalunderExecution=iUnderExecution+iUnderExecutionAOB+iUnderExecutionSFC+iUnderExecutionATVP+iUnderExecutionDNSPI+iUnderExecutionCONSULTANCY+iUnderExecutionHQENC+iUnderExecutionAMWP;
				int totalunderExecutionOntime=iOnTime+iOnTimeAOB+iOnTimeSFC+iOnTimeATVP+iOnTimeDNSPI+iOnTimeCONSULTANCY+iOnTimeHQENC+iOnTimeAMWP;
				int totalunderExecutionDeleyed=iDelayed+iDelayedAOB+iDelayedSFC+iDelayedATVP+iDelayedDNSPI+iDelayedCONSULTANCY+iDelayedHQENC+iDelayedAMWP;
				int totalunderExecutionCompleted=iCompleted+iCompletedAOB+iCompletedSFC+iCompletedATVP+iCompletedDNSPI+iCompletedCONSULTANCY+iCompletedHQENC+iCompletedAMWP;
				
				//Workbook wb = new HSSFWorkbook();   
				//creates an excel file at the specified location  
				//OutputStream fileOut = new FileOutputStream("/home/admin/Desktop/rahul/" +strPersonName+ ".xlsx"); 
				try{
					
String filename = "C:\\mainDashboard\\" +strPersonName+ ".xls"; 			
HSSFWorkbook workbook = new HSSFWorkbook();  
//invoking creatSheet() method and passing the name of the sheet to be created   
HSSFSheet sheet = workbook.createSheet("January");   
//creating the 0th row using the createRow() method  
HSSFRow rowhead = sheet.createRow((short)0);  
//creating cell by using the createCell() method and setting the values to the cell by using the setCellValue() method  
rowhead.createCell(0).setCellValue("pre Total");  
rowhead.createCell(1).setCellValue("Pre RIC");  
rowhead.createCell(2).setCellValue("pre AE");  
rowhead.createCell(3).setCellValue("pre AA");  
rowhead.createCell(4).setCellValue("Post Total");
rowhead.createCell(5).setCellValue("Post Ontime");
rowhead.createCell(6).setCellValue("Post Delayed");
rowhead.createCell(7).setCellValue("Post Completed");
  //creating the 1st row  
HSSFRow rowATWP = sheet.createRow((short)1);  
//inserting Atwp value  
rowATWP.createCell(0).setCellValue(iTotal1);  
rowATWP.createCell(1).setCellValue(iRic);  
rowATWP.createCell(2).setCellValue(iAE);  
rowATWP.createCell(3).setCellValue(iAA);  
rowATWP.createCell(4).setCellValue(iUnderExecution);  
rowATWP.createCell(5).setCellValue(iOnTime);  
rowATWP.createCell(6).setCellValue(iDelayed);  
rowATWP.createCell(7).setCellValue(iCompleted); 

HSSFRow rowAOB = sheet.createRow((short)2);  
//inserting data AOB value 
rowAOB.createCell(0).setCellValue(iTotal1AOB);  
rowAOB.createCell(1).setCellValue(iRicAOB);  
rowAOB.createCell(2).setCellValue(iAEAOB);  
rowAOB.createCell(3).setCellValue(iAAAOB);  
rowAOB.createCell(4).setCellValue(iUnderExecutionAOB);  
rowAOB.createCell(5).setCellValue(iOnTimeAOB);  
rowAOB.createCell(6).setCellValue(iDelayedAOB);  
rowAOB.createCell(7).setCellValue(iCompletedAOB); 

HSSFRow rowSFC = sheet.createRow((short)3);  
//inserting data SFC value 
rowSFC.createCell(0).setCellValue(iTotal1SFC);  
rowSFC.createCell(1).setCellValue(iRicSFC);  
rowSFC.createCell(2).setCellValue(iAESFC);  
rowSFC.createCell(3).setCellValue(iAASFC);  
rowSFC.createCell(4).setCellValue(iUnderExecutionSFC);  
rowSFC.createCell(5).setCellValue(iOnTimeSFC);  
rowSFC.createCell(6).setCellValue(iDelayedSFC);  
rowSFC.createCell(7).setCellValue(iCompletedSFC); 

HSSFRow rowATVP = sheet.createRow((short)4);  
//inserting data ATVP value 
rowATVP.createCell(0).setCellValue(iTotal1ATVP);  
rowATVP.createCell(1).setCellValue(iRicATVP);  
rowATVP.createCell(2).setCellValue(iAEATVP);  
rowATVP.createCell(3).setCellValue(iAAATVP);  
rowATVP.createCell(4).setCellValue(iUnderExecutionATVP);  
rowATVP.createCell(5).setCellValue(iOnTimeATVP);  
rowATVP.createCell(6).setCellValue(iDelayedATVP);  
rowATVP.createCell(7).setCellValue(iCompletedATVP); 

HSSFRow rowDNSPI = sheet.createRow((short)5);  
//inserting data DNSPI value 
rowDNSPI.createCell(0).setCellValue(iTotal1DNSPI);  
rowDNSPI.createCell(1).setCellValue(iRicDNSPI);  
rowDNSPI.createCell(2).setCellValue(iAEDNSPI);  
rowDNSPI.createCell(3).setCellValue(iAADNSPI);  
rowDNSPI.createCell(4).setCellValue(iUnderExecutionDNSPI);  
rowDNSPI.createCell(5).setCellValue(iOnTimeDNSPI);  
rowDNSPI.createCell(6).setCellValue(iDelayedDNSPI);  
rowDNSPI.createCell(7).setCellValue(iCompletedDNSPI); 

HSSFRow rowCONSULTANCY = sheet.createRow((short)6);  
//inserting data CONSULTANCY value 
rowCONSULTANCY.createCell(0).setCellValue(iTotal1CONSULTANCY);  
rowCONSULTANCY.createCell(1).setCellValue(iRicCONSULTANCY);  
rowCONSULTANCY.createCell(2).setCellValue(iAECONSULTANCY);  
rowCONSULTANCY.createCell(3).setCellValue(iAACONSULTANCY);  
rowCONSULTANCY.createCell(4).setCellValue(iUnderExecutionCONSULTANCY);  
rowCONSULTANCY.createCell(5).setCellValue(iOnTimeCONSULTANCY);  
rowCONSULTANCY.createCell(6).setCellValue(iDelayedCONSULTANCY);  
rowCONSULTANCY.createCell(7).setCellValue(iCompletedCONSULTANCY); 

HSSFRow rowHQENC = sheet.createRow((short)7);  
//inserting data HQENC value 
rowHQENC.createCell(0).setCellValue(iTotal1HQENC);  
rowHQENC.createCell(1).setCellValue(iRicHQENC);  
rowHQENC.createCell(2).setCellValue(iAEHQENC);  
rowHQENC.createCell(3).setCellValue(iAAHQENC);  
rowHQENC.createCell(4).setCellValue(iUnderExecutionHQENC);  
rowHQENC.createCell(5).setCellValue(iOnTimeHQENC);  
rowHQENC.createCell(6).setCellValue(iDelayedHQENC);  
rowHQENC.createCell(7).setCellValue(iCompletedHQENC);

HSSFRow rowAMWP = sheet.createRow((short)8);  
//inserting data HQENC value 
rowAMWP.createCell(0).setCellValue(iTotal1AMWP);  
rowAMWP.createCell(1).setCellValue(iRicAMWP);  
rowAMWP.createCell(2).setCellValue(iAEAMWP);  
rowAMWP.createCell(3).setCellValue(iAAAMWP);  
rowAMWP.createCell(4).setCellValue(iUnderExecutionAMWP);  
rowAMWP.createCell(5).setCellValue(iOnTimeAMWP);  
rowAMWP.createCell(6).setCellValue(iDelayedAMWP);  
rowAMWP.createCell(7).setCellValue(iCompletedAMWP);

HSSFRow rowTotal = sheet.createRow((short)9);  
//inserting data Total Value value 
rowTotal.createCell(0).setCellValue(totalpreTotal);  
rowTotal.createCell(1).setCellValue(totalpreRIC);  
rowTotal.createCell(2).setCellValue(totalpreAE);  
rowTotal.createCell(3).setCellValue(totalpreAA);  
rowTotal.createCell(4).setCellValue(totalunderExecution);  
rowTotal.createCell(5).setCellValue(totalunderExecutionOntime);  
rowTotal.createCell(6).setCellValue(totalunderExecutionDeleyed);  
rowTotal.createCell(7).setCellValue(totalunderExecutionCompleted); 

  
FileOutputStream fileOut = new FileOutputStream(filename);  
workbook.write(fileOut);  
//closing the Stream  
fileOut.close();  
//closing the workbook   
//prints the message on the console  
System.out.println("Excel file has been generated successfully.");
}   
catch (Exception e)   
{  
e.printStackTrace();  
}     
}  
}    
}
