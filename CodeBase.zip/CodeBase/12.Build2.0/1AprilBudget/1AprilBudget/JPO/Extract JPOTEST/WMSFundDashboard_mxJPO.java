/*---------------------------------------------------------------------------------------------------------------
NAME        : ${CLASSNAME}.java

DESCRIPTION    : Purpose of JPO is to Create Admin Approvals  and perform the utility operations on it

CREATED        : August 13 2019

AUTHOR        : Divyashree B K

HISTORY        :

    Divyashree B K    13-08-2019        Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;
import java.math.BigDecimal;
import java.util.Locale;
import java.math.RoundingMode;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectConcept;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import matrix.db.Policy;
import com.matrixone.jdom.Element;
import matrix.util.Pattern;

import java.util.Date;

public class WMSFundDashboard_mxJPO extends WMSConstants_mxJPO {
    
    public static final String ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTotalAllotmentAmount");
    public static final String ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSCYAllotmentAmount");
    public static final String ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTotalExpendedAmount");
    public static final String ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSCYExpendedAmount");
    public static final String ATTRIBUTE_WMS_FUND_BALANCE_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSFundBalanceAmount");
    public static final String ATTRIBUTE_WMS_CODE_HEAD_NAME = PropertyUtil.getSchemaProperty("attribute_WMSCodeHeadName");

    
    /**
    * Constructor.
    *
    * @param context the eMatrix <code>Context</code> object.
    * @param args holds no arguments.
    * @throws Exception if the operation fails.
    * @since EC 9.5.JCI.0.
    **/
    public WMSFundDashboard_mxJPO (Context context, String[] args) throws Exception {
      super(context, args);
    }
        
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getFundRequestDashboard(Context context, String[] args) throws Exception {
        MapList mlFinalList = new MapList();
        try
        {
			String strYear = DomainConstants.EMPTY_STRING;
            LocalDateTime now = LocalDateTime.now();
            int year = now.getYear();
            int month = now.getMonthValue();
            
            if(month>3){
                strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
            }else{
                strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
            }
			
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainObject.SELECT_ID);
            strListBusSelects.add(DomainObject.SELECT_NAME);
            strListBusSelects.add(DomainObject.SELECT_TYPE);
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            MapList mlFundItems = DomainObject.findObjects(context,
                                                            TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            "current==Review",               // where expression
                                                            DomainConstants.EMPTY_STRING,
                                                            true,
                                                            strListBusSelects, // object selects
                                                            (short) 0);
															System.out.println("mlFundItems----"+mlFundItems);
															
                    
            Map mTemp = null;
            Map mFinalMap = null;
            String strType = "";
            String strCodeHeadId = "";
            String strCodeHeadAllocation = "";
            StringList slWorkOrderList = new StringList();
            String strWOID = "";
            for(int i = 0; i < mlFundItems.size(); i++){
                mTemp = (Map)mlFundItems.get(i);
                strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                if (!slWorkOrderList.contains(strWOID)) {
                    slWorkOrderList.add(strWOID);
                }
            }
            int iWOListSize = slWorkOrderList.size();
            String[] saWOArray = new String[iWOListSize];
            StringList slWOSelectable = new StringList();
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
            slWOSelectable.add(DomainConstants.SELECT_ID);
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.description");
			slWOSelectable.add("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
			slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
			
            //make the array for WO objects
            for(int j = 0; j < iWOListSize; j++){
                saWOArray[j] = (String)slWorkOrderList.get(j);
            }
            MapList mlWOInfo = DomainObject.getInfo(context, saWOArray, slWOSelectable);
            //Get other fields for the WO
            Map mWOTemp = null;
            Map mCurrentWorkOrderDetails = new HashMap();
            Map mWorkOrderDetails = new HashMap();
            for(int k = 0; k < mlWOInfo.size(); k++){
                mCurrentWorkOrderDetails = new HashMap();
                mWOTemp = (Map)mlWOInfo.get(k);
                strWOID = (String)mWOTemp.get(DomainConstants.SELECT_ID);
                Map mFinancialDetails = getWOFinancials(context, strWOID);
                mCurrentWorkOrderDetails.putAll(mFinancialDetails);
                mCurrentWorkOrderDetails.put("CodeHead", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]"));
                mCurrentWorkOrderDetails.put("CodeHeadDesc", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]"));
                mCurrentWorkOrderDetails.put("ProjectName", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name"));
                mCurrentWorkOrderDetails.put("WorkName", (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]"));
				String CodeHead= (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				String CodeHeadName= (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
				String ProjectName = (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
				String WorkName = (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
				
				String strWOAmount = (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
				String strTSAmount = (String)mWOTemp.get("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
				
				if(UIUtil.isNullOrEmpty(strWOAmount)){
					strWOAmount = "0";
				}
				if(UIUtil.isNullOrEmpty(strTSAmount)){
					strTSAmount = "0";
				}
				mCurrentWorkOrderDetails.put("WOAmount", String.format("%.2f", Double.valueOf(strWOAmount)));
				mCurrentWorkOrderDetails.put("TSAmount", String.format("%.2f", Double.valueOf(strTSAmount)));
				mCurrentWorkOrderDetails.put("CodeHeadId", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id"));
                mWorkOrderDetails.put(strWOID, mCurrentWorkOrderDetails);
            }
            //Prepare Final Map to be returned to the Table
            Map mFundMap = null;
            Map mTableRowMap = new HashMap();
            for(int l = 0; l < mlFundItems.size(); l++){
                mFundMap = (Map)mlFundItems.get(l);
                strType = (String)mFundMap.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                Map mWOTableDeatils = (Map)mWorkOrderDetails.get(strWOID);
                mFundMap.putAll(mWOTableDeatils);
                mlFinalList.add(mFundMap);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        return mlFinalList;
    }
    
    public Map getWOFinancials(Context context, String strWOID) throws Exception 
    {
        Map mFinalMap = new HashMap();
        try{
            String strYear = DomainConstants.EMPTY_STRING;
            LocalDateTime now = LocalDateTime.now();
            int year = now.getYear();
            int month = now.getMonthValue();
            
            if(month>3){
                strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
            }else{
                strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
            }
            
            MapList mlWOData = getWorkOrderData(context, strWOID);
            
            BigDecimal bgZero = new BigDecimal(0);
            Map mTemp = null;
            Map mAMBDetails = new HashMap();
            mAMBDetails.put("CYExpendedAmount", bgZero);
            mAMBDetails.put("TotalExpendedAmount", bgZero);
            Map mFundReqDetails = new HashMap();
            mFundReqDetails.put("CYAllotmentAmount", bgZero);
            mFundReqDetails.put("TotalAllotmentAmount", bgZero);
            Map mFundRelDetails = new HashMap();
            mFundRelDetails.put("CYAllotmentAmount", bgZero);
            mFundRelDetails.put("TotalAllotmentAmount", bgZero);
            String strType = "";
            String strFY = "";

            
            for(int i = 0; i < mlWOData.size(); i++){
                mTemp = (Map)mlWOData.get(i);
                strType = (String)mTemp.get(DomainConstants.SELECT_TYPE);
                //if type is AMB then do the calculation for Fund Expended overall and CY
                if (strType.equals(TYPE_ABSTRACT_MBE)) {
                    mAMBDetails = getAMBFundDetails(mTemp, strYear, mAMBDetails);
                } else if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    //get the Allottment details for Current Year and total
                    mFundReqDetails = getFundRequestDetails(mTemp, strYear, mFundReqDetails);
                } else {
                    //get Release Details for Current Year and total
                    mFundRelDetails = getFundRequestDetails(mTemp, strYear, mFundRelDetails);
                }
            }
            mFinalMap.putAll(mAMBDetails);
            BigDecimal bgCYRequestAmount = (BigDecimal)mFundReqDetails.get("CYAllotmentAmount");
            BigDecimal bgTotalRequestAmount = (BigDecimal)mFundReqDetails.get("TotalAllotmentAmount");
            BigDecimal bgCYReleaseAmount = (BigDecimal)mFundRelDetails.get("CYAllotmentAmount");
            BigDecimal bgTotalReleaseAmount = (BigDecimal)mFundRelDetails.get("TotalAllotmentAmount");
            BigDecimal bgTotalAllotmentAmount = bgTotalRequestAmount.subtract(bgTotalReleaseAmount);
            BigDecimal bgCYAllotmentAmount = bgCYRequestAmount.subtract(bgCYReleaseAmount);
            mFinalMap.put("TotalAllotment", bgTotalAllotmentAmount);
            mFinalMap.put("CYAllotment", bgCYAllotmentAmount);
        }catch(Exception ex){
            System.out.println("error in getSubAllocationForCHY method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return mFinalMap;
    }
    
    public Map getFundRequestDetails(Map mAMBMap, String strYear, Map mFundReqDetails) throws Exception{
        Map mFinalMap = new HashMap();
        try{
            BigDecimal bgZero = new BigDecimal(0);
            //Get the Certified Amount from the Map
            String strAmount = (String)mAMBMap.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
            BigDecimal bgFundAmount = new BigDecimal(strAmount);
            //If FY matches the passed FY then get the same
            String strFundFY = (String)mAMBMap.get("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
            
            //Check if the Details map already has the keys, if yes, add else add keys and values.
            if (mFundReqDetails.containsKey("CYAllotmentAmount")) {
                BigDecimal bgCYTemp = (BigDecimal)mFundReqDetails.get("CYAllotmentAmount");
                if (strFundFY.equals(strYear)) {
                    bgCYTemp = bgCYTemp.add(bgFundAmount);
                }
                mFinalMap.put("CYAllotmentAmount", bgCYTemp);
                BigDecimal bgTotalTemp = (BigDecimal)mFundReqDetails.get("TotalAllotmentAmount");
                bgTotalTemp = bgTotalTemp.add(bgFundAmount);
                mFinalMap.put("TotalAllotmentAmount", bgTotalTemp);
            }
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        return mFinalMap;
    }
    
    public Map getAMBFundDetails(Map mAMBMap, String strYear, Map mAMBDetails) throws Exception{
        Map mFinalMap = new HashMap();
        try{
            BigDecimal bgZero = new BigDecimal(0);
            //Get the Certified Amount from the Map
            String strCertifiedAmount = (String)mAMBMap.get("attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"]");
            BigDecimal bgAMBCertAmount = new BigDecimal(strCertifiedAmount);
            //If FY matches the passed FY then get the same
            String strAMBFY = (String)mAMBMap.get("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
            
            //Check if the Details map already has the keys, if yes, add else add keys and values.
            if (mAMBDetails.containsKey("CYExpendedAmount")) {
                BigDecimal bgCYTemp = (BigDecimal)mAMBDetails.get("CYExpendedAmount");
                if (strAMBFY.equals(strYear)) {
                    bgCYTemp = bgCYTemp.add(bgAMBCertAmount);
                }
                mFinalMap.put("CYExpendedAmount", bgCYTemp);
                BigDecimal bgTotalTemp = (BigDecimal)mAMBDetails.get("TotalExpendedAmount");
                bgTotalTemp = bgTotalTemp.add(bgAMBCertAmount);
                mFinalMap.put("TotalExpendedAmount", bgTotalTemp);
            }
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        return mFinalMap;
    }
    
    public MapList getWorkOrderData(Context context, String strWOID) throws Exception 
    {
        MapList mlWOData = new MapList();
        try{
            DomainObject doWOObj = DomainObject.newInstance(context, strWOID);
            StringList slObjectSelects = new StringList();
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
            slObjectSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"]");
            slObjectSelects.add(DomainConstants.SELECT_CURRENT);
            slObjectSelects.add(DomainConstants.SELECT_TYPE);
            
            
            mlWOData = doWOObj.getRelatedObjects(context,
                                                RELATIONSHIP_WMS_WO_FUND_REQUEST+","+RELATIONSHIP_WMS_WO_FUND_RELEASE+","+RELATIONSHIP_WORKORDER_ABSTRACT_MBE,
                                                TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE+","+TYPE_ABSTRACT_MBE,
                                                slObjectSelects,
                                                null,       // relationshipSelects
                                                false,      // getTo
                                                true,       // getFrom
                                                (short) 1,  // recurseToLevel
                                                "(current==Approved || current==Paid)",// objectWhere
                                                null);
            mlWOData.sortStructure(DomainConstants.SELECT_TYPE, "descending", "string");
        } catch(Exception ex){
            System.out.println("error in getWorkOrderData method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return mlWOData;
    }
    
    
    
    
    public Vector getExistingAllotment(Context context, String[] args) throws Exception{
        Vector colVector = new Vector();
        try{
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            
            Map mTemp = null;
            BigDecimal bgTotalAllotment = new BigDecimal(0);
            BigDecimal bgCYAllotment = new BigDecimal(0);
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
                bgTotalAllotment = (BigDecimal)mTemp.get("TotalAllotment");
                bgCYAllotment = (BigDecimal)mTemp.get("CYAllotment");
                Double dblTotalValue = Double.parseDouble(bgTotalAllotment.toString());
                String strTotalAmount = String.format("%.2f", dblTotalValue);
                Double dblCYValue = Double.parseDouble(bgCYAllotment.toString());
                String strCYAmount = String.format("%.2f", dblCYValue);
                StringBuilder sb= new StringBuilder();
				sb.append("<b><u>").append("TOT:").append("</u>").append("</b>");
                sb.append(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strTotalAmount)));
                sb.append("<br/>");
                sb.append("<b><u>").append("CFY:").append("</u>").append("</b>");
				sb.append(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strCYAmount)));
                colVector.add(sb.toString());
            }
            return colVector;
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
    }
    
    
    
    public Vector getFundExpended(Context context, String[] args) throws Exception{
        Vector colVector = new Vector();
        try{
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            
            Map mTemp = null;
            BigDecimal bgTotalExpended = new BigDecimal(0);
            BigDecimal bgCYExpended = new BigDecimal(0);
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
                bgTotalExpended = (BigDecimal)mTemp.get("TotalExpendedAmount");
                bgCYExpended = (BigDecimal)mTemp.get("CYExpendedAmount");
                Double dblTotalValue = Double.parseDouble(bgTotalExpended.toString());
                String strTotalAmount = String.format("%.2f", dblTotalValue);
                Double dblCYValue = Double.parseDouble(bgCYExpended.toString());
                String strCYAmount = String.format("%.2f", dblCYValue);
                StringBuilder sb= new StringBuilder();
				sb.append("<b>").append("<u>").append("TOT:").append("</u>").append("</b>");
                sb.append(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strTotalAmount)));
                sb.append("<br/>");
                sb.append("<b>").append("<u>").append("CFY:").append("</u>").append("</b>");
				sb.append(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strCYAmount)));
                colVector.add(sb.toString());
            }

            return colVector;
            
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        
    }
    
    
    public StringList getFundBalance(Context context, String[] args) throws Exception{
        try{
            StringList slReturnList = new StringList();
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            BigDecimal bgTotalExpended = new BigDecimal(0);
            BigDecimal bgTotalAllotment = new BigDecimal(0);
            BigDecimal bgFundBalance = new BigDecimal(0);
            Map mTemp = null;
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
                bgTotalExpended = (BigDecimal)mTemp.get("TotalExpendedAmount");
                bgTotalAllotment = (BigDecimal)mTemp.get("TotalAllotment");
                bgFundBalance = bgTotalAllotment.subtract(bgTotalExpended);
                Double dblTotalValue = Double.parseDouble(bgFundBalance.toString());
                String strTotalAmount = String.format("%.2f", dblTotalValue);
                slReturnList.add(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strTotalAmount)));
            }

            return slReturnList;
            
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        
    }
    
    public StringList getColumnValue(Context context, String[] args) throws Exception{
        try{
            StringList slReturnList = new StringList();
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Map mColumnMap = (Map)programMap.get("columnMap");
            Map mSettingMap = (Map)mColumnMap.get("settings");
            String strKey = (String)mSettingMap.get("mapKey");
            Map mTemp = null;
            String strKeyValue = "";
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
				if (mTemp.containsKey(strKey))
				{
					strKeyValue = (String)mTemp.get(strKey);
					if(WMSUtil_mxJPO.isNumeric(strKeyValue)){
						slReturnList.add(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strKeyValue)));
					}else{
						slReturnList.add(strKeyValue);
					}
					
				}
				else
				{
					if("numeric".equals((String)mSettingMap.get("format")))
					{
						slReturnList.add("0.0");
					}
					else
					{
						slReturnList.add("");
					}
				}
            }
            return slReturnList;
            
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        
    }
    
   
    public StringList getFundRequiredStyle(Context context, String[] args) throws Exception {
        StringList slResults    = new StringList();
        Map programMap          = (Map) JPO.unpackArgs(args);
        MapList objectList             = (MapList) programMap.get("objectList");
        int iobjectListSize            = objectList.size();
        String strType = "";
        Map objectMap = null;
        for (int i=0; i < iobjectListSize; i++)
        {
            objectMap=(Map)objectList.get(i);
            strType = (String)objectMap.get(DomainObject.SELECT_TYPE);
            if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                slResults.addElement("ResourcePlanningYellowBackGroundColor");
            } else {
                slResults.addElement("ResourcePlanningGreenBackGroundColor");
            }
        }
        return slResults;
     }
     
    public int copyFinancialAttrs(Context context, String[] args) throws Exception {
        try {
            String sObjectId = args[0];
            String strType = args[1];
            DomainObject doBus = DomainObject.newInstance(context, sObjectId);
            String strCurObjAmount = doBus.getAttributeValue(context, ATTRIBUTE_WMSTOTALAMOUNT);
            BigDecimal bgCurrObjAmount = new BigDecimal(strCurObjAmount);
            String strWOID = "";
            if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                strWOID = doBus.getInfo(context, "to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            } else {
                strWOID = doBus.getInfo(context, "to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            }
            Map mFinancialDetails = getWOFinancials(context, strWOID);
            BigDecimal bgTotalExpended = (BigDecimal)mFinancialDetails.get("TotalExpendedAmount");
            BigDecimal bgCYExpended = (BigDecimal)mFinancialDetails.get("CYExpendedAmount");
            BigDecimal bgTotalAllotment = (BigDecimal)mFinancialDetails.get("TotalAllotment");
            //Reduce/Add the value of the current object from the total/CY
            BigDecimal bgCYAllotment = (BigDecimal)mFinancialDetails.get("CYAllotment");
            if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                bgTotalAllotment = bgTotalAllotment.subtract(bgCurrObjAmount);
                bgCYAllotment = bgCYAllotment.subtract(bgCurrObjAmount);
            } else {
                bgTotalAllotment = bgTotalAllotment.add(bgCurrObjAmount);
                bgCYAllotment = bgCYAllotment.add(bgCurrObjAmount);
            }
            BigDecimal bgFundBalance = bgTotalAllotment.subtract(bgTotalExpended);
            //Prepare AttrMap
            Map mapAttributes = new HashMap();
            mapAttributes.put(ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT, convertBGToString(bgTotalAllotment));
            mapAttributes.put(ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT, convertBGToString(bgCYAllotment));
            mapAttributes.put(ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT, convertBGToString(bgTotalExpended));
            mapAttributes.put(ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT, convertBGToString(bgCYExpended));
            mapAttributes.put(ATTRIBUTE_WMS_FUND_BALANCE_AMOUNT, convertBGToString(bgFundBalance));
            ContextUtil.pushContext(context);
            doBus.setAttributeValues(context, mapAttributes);
            ContextUtil.popContext(context);
            return 0;
        }
        catch (Exception e) {
            e.printStackTrace();
            return 1;
        }
    }
    
    public String convertBGToString(BigDecimal bgNumber)throws Exception {
        String strReturn = "";
        try {
            Double dblValue = Double.parseDouble(bgNumber.toString());
            strReturn = String.format("%.2f", dblValue);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return strReturn;
    }
    
    
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getFundRequestApprovedDashboard(Context context, String[] args) throws Exception {
        MapList mlFinalList = new MapList();
        try
        {
            HashMap hashmap = (HashMap) JPO.unpackArgs(args);
            String strWMSFYFilter = (String)hashmap.get("WMSFYFilter");
            if (UIUtil.isNullOrEmpty(strWMSFYFilter)) {
                String strYear = DomainConstants.EMPTY_STRING;
                LocalDateTime now = LocalDateTime.now();
                int year = now.getYear();
                int month = now.getMonthValue();
                
                if(month>3){
                    strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
                }else{
                    strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
                }
                strWMSFYFilter = strYear;
            }
            String strWhere = "current==Approved && attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]=='"+strWMSFYFilter+"'";
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainObject.SELECT_ID);
            strListBusSelects.add(DomainObject.SELECT_NAME);
            strListBusSelects.add(DomainObject.SELECT_TYPE);
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT+"]");
            
            
            MapList mlFundItems = DomainObject.findObjects(context,
                                                            TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            strWhere,               // where expression
                                                            DomainConstants.EMPTY_STRING,
                                                            true,
                                                            strListBusSelects, // object selects
                                                            (short) 0);
															
															System.out.println("-------mlFundItems----"+mlFundItems);
                    
            Map mTemp = null;
            Map mFinalMap = null;
            String strType = "";
            StringList slWorkOrderList = new StringList();
            String strWOID = "";
            for(int i = 0; i < mlFundItems.size(); i++){
                mTemp = (Map)mlFundItems.get(i);
                strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                if (!slWorkOrderList.contains(strWOID)) {
                    slWorkOrderList.add(strWOID);
                }
            }
            int iWOListSize = slWorkOrderList.size();
            String[] saWOArray = new String[iWOListSize];
            StringList slWOSelectable = new StringList();
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slWOSelectable.add(DomainConstants.SELECT_ID);
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
            //make the array for WO objects
            for(int j = 0; j < iWOListSize; j++){
                saWOArray[j] = (String)slWorkOrderList.get(j);
            }
            MapList mlWOInfo = DomainObject.getInfo(context, saWOArray, slWOSelectable);
            //Get other fields for the WO
            Map mWOTemp = null;
            Map mCurrentWorkOrderDetails = new HashMap();
            Map mWorkOrderDetails = new HashMap();
            for(int k = 0; k < mlWOInfo.size(); k++){
                mCurrentWorkOrderDetails = new HashMap();
                mWOTemp = (Map)mlWOInfo.get(k);
                strWOID = (String)mWOTemp.get(DomainConstants.SELECT_ID);
                mCurrentWorkOrderDetails.put("CodeHead", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]"));
                mCurrentWorkOrderDetails.put("ProjectName", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name"));
                mCurrentWorkOrderDetails.put("WorkName", (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]"));
                mCurrentWorkOrderDetails.put("CodeHeadName", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]"));
                mWorkOrderDetails.put(strWOID, mCurrentWorkOrderDetails);
            }
            //Prepare Final Map to be returned to the Table
            Map mFundMap = null;
            for(int l = 0; l < mlFundItems.size(); l++){
                mFundMap = (Map)mlFundItems.get(l);
                strType = (String)mFundMap.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                Map mWOTableDeatils = (Map)mWorkOrderDetails.get(strWOID);
                mFundMap.putAll(mWOTableDeatils);
                //Add values in specific keys of Map
                mFundMap.put("TotalExpendedAmount",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT+"]")));
                mFundMap.put("CYExpendedAmount",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT+"]")));
                mFundMap.put("TotalAllotment",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT+"]")));
                mFundMap.put("CYAllotment",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT+"]")));
                mlFinalList.add(mFundMap);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        return mlFinalList;
    }
	   /* public  MapList getFundRequestApprovedDashboard(Context context, String[] args) throws Exception {
        MapList mlFinalList = new MapList();
        try
        {
            HashMap hashmap = (HashMap) JPO.unpackArgs(args);
            String strWMSFYFilter = (String)hashmap.get("WMSFYFilter");
            if (UIUtil.isNullOrEmpty(strWMSFYFilter)) {
                String strYear = DomainConstants.EMPTY_STRING;
                LocalDateTime now = LocalDateTime.now();
                int year = now.getYear();
                int month = now.getMonthValue();
                
                if(month>3){
                    strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
                }else{
                    strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
                }
                strWMSFYFilter = strYear;
            }
            String strWhere = "current==Approved && attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]=='"+strWMSFYFilter+"'";
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainObject.SELECT_ID);
            strListBusSelects.add(DomainObject.SELECT_NAME);
            strListBusSelects.add(DomainObject.SELECT_TYPE);
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT+"]");
            
            
            MapList mlFundItems = DomainObject.findObjects(context,
                                                            TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            strWhere,               // where expression
                                                            DomainConstants.EMPTY_STRING,
                                                            true,
                                                            strListBusSelects, // object selects
                                                            (short) 0);
															System.out.println("mlFundItems-----"+mlFundItems);
                    
            Map mTemp = null;
            Map mFinalMap = null;
            String strType = "";
            StringList slWorkOrderList = new StringList();
            String strWOID = "";
            for(int i = 0; i < mlFundItems.size(); i++){
                mTemp = (Map)mlFundItems.get(i);
                strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                if (!slWorkOrderList.contains(strWOID)) {
                    slWorkOrderList.add(strWOID);
                }
            }
            int iWOListSize = slWorkOrderList.size();
            String[] saWOArray = new String[iWOListSize];
            StringList slWOSelectable = new StringList();
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slWOSelectable.add(DomainConstants.SELECT_ID);
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
            //make the array for WO objects
            for(int j = 0; j < iWOListSize; j++){
                saWOArray[j] = (String)slWorkOrderList.get(j);
            }
            MapList mlWOInfo = DomainObject.getInfo(context, saWOArray, slWOSelectable);
            //Get other fields for the WO
            Map mWOTemp = null;
            Map mCurrentWorkOrderDetails = new HashMap();
            Map mWorkOrderDetails = new HashMap();
            for(int k = 0; k < mlWOInfo.size(); k++){
                mCurrentWorkOrderDetails = new HashMap();
                mWOTemp = (Map)mlWOInfo.get(k);
                strWOID = (String)mWOTemp.get(DomainConstants.SELECT_ID);
                mCurrentWorkOrderDetails.put("CodeHead", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]"));
                mCurrentWorkOrderDetails.put("ProjectName", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name"));
                mCurrentWorkOrderDetails.put("WorkName", (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]"));
                mCurrentWorkOrderDetails.put("CodeHeadName", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]"));
                mWorkOrderDetails.put(strWOID, mCurrentWorkOrderDetails);
            }
            //Prepare Final Map to be returned to the Table
            Map mFundMap = null;
            for(int l = 0; l < mlFundItems.size(); l++){
                mFundMap = (Map)mlFundItems.get(l);
                strType = (String)mFundMap.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                Map mWOTableDeatils = (Map)mWorkOrderDetails.get(strWOID);
                mFundMap.putAll(mWOTableDeatils);
                //Add values in specific keys of Map
                mFundMap.put("TotalExpendedAmount",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT+"]")));
                mFundMap.put("CYExpendedAmount",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT+"]")));
                mFundMap.put("TotalAllotment",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT+"]")));
                mFundMap.put("CYAllotment",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT+"]")));
                mlFinalList.add(mFundMap);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        return mlFinalList;
    }*/
    
    @com.matrixone.apps.framework.ui.ProgramCallable
    public HashMap getFYDropdown(Context context, String[] args) throws Exception
    {
        HashMap mapFYs = new HashMap();
        Map programMap = (HashMap) JPO.unpackArgs(args);
        Map requestMap = (Map) programMap.get("requestMap");
        String strWMSFYFilter = (String) requestMap.get("WMSFYFilter");
        StringList slFYIds = new StringList();
        if (UIUtil.isNullOrEmpty(strWMSFYFilter)) {
            String strYear = DomainConstants.EMPTY_STRING;
            LocalDateTime now = LocalDateTime.now();
            int year = now.getYear();
            int month = now.getMonthValue();
            
            if(month>3){
                strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
            }else{
                strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
            }
            strWMSFYFilter = strYear;
        }
        slFYIds.add(strWMSFYFilter);
        
        StringList strListBusSelects = new StringList(2);
        strListBusSelects.add("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
        
        MapList mlFundItems = DomainObject.findObjects(context,
                                                        TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                        DomainConstants.QUERY_WILDCARD,
                                                        DomainConstants.QUERY_WILDCARD,
                                                        DomainConstants.QUERY_WILDCARD,
                                                        DomainConstants.QUERY_WILDCARD,
                                                        "current==Approved",               // where expression
                                                        DomainConstants.EMPTY_STRING,
                                                        true,
                                                        strListBusSelects, // object selects
                                                        (short) 0);
        
        
        
        mlFundItems.sortStructure("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]","ascending","string");
        //get the FYs
        Map mpObjInfo;
        String strFY = "";
        for (Object obj : mlFundItems) {
            mpObjInfo = (Map) obj;
            strFY = (String) mpObjInfo.get("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
            if (strWMSFYFilter.equals(strFY)) {
                continue;
            }
            if (!slFYIds.contains(strFY)) {
                slFYIds.add(strFY);
            }
        }
        
        mapFYs.put("field_choices", slFYIds);
        mapFYs.put("field_display_choices", slFYIds);
        return mapFYs;
    }
	@com.matrixone.apps.framework.ui.ProgramCallable
    public HashMap getTypeOfReportsDropdown(Context context, String[] args) throws Exception
    {
        HashMap mapTypes = new HashMap();
        Map programMap = (HashMap) JPO.unpackArgs(args);
        Map requestMap = (Map) programMap.get("requestMap");

		String strFYFilter = (String) requestMap.get("WMSFinancialProgressFYFilter");
		String strFinancialProgressTypeOfReportFilter = (String) requestMap.get("WMSFinancialProgressTypeOfReportFilter");
		String strFinancialProgressCodeHeadFilter = (String) requestMap.get("WMSFinancialProgressCodeHeadFilter");
		
		StringList slTypeOfReports = new StringList(4);
		slTypeOfReports.addElement("Preliminary Revised Estimate");
		slTypeOfReports.addElement("Monthly Appropriation Report");
		slTypeOfReports.addElement("Budget Estimate");
		slTypeOfReports.addElement("Revised Estimate");
		
		if (!UIUtil.isNullOrEmpty(strFinancialProgressTypeOfReportFilter))
		{
			slTypeOfReports.removeElement(strFinancialProgressTypeOfReportFilter);
			slTypeOfReports.add(0, strFinancialProgressTypeOfReportFilter);
		}
        
        mapTypes.put("field_choices", slTypeOfReports);
        mapTypes.put("field_display_choices", slTypeOfReports);
        return mapTypes;
    }
	@com.matrixone.apps.framework.ui.ProgramCallable
    public HashMap getCodeHeadDropdown(Context context, String[] args) throws Exception
    {
		HashMap mapCodeHeads = new HashMap();
		Map programMap = (HashMap) JPO.unpackArgs(args);
		Map requestMap = (Map) programMap.get("requestMap");

		String strFYFilter = (String) requestMap.get("WMSFinancialProgressFYFilter");
		String strFinancialProgressTypeOfReportFilter = (String) requestMap.get("WMSFinancialProgressTypeOfReportFilter");
		String strFinancialProgressCodeHeadFilter = (String) requestMap.get("WMSFinancialProgressCodeHeadFilter");

		StringList strListBusSelects = new StringList();
		strListBusSelects.add(DomainObject.SELECT_ID);
		strListBusSelects.add(DomainObject.SELECT_NAME);
		strListBusSelects.add("attribute[WMSCodeHeadName].value");
		MapList mlCodeHeads = DomainObject.findObjects(
													context,
													TYPE_WMS_CODE_HEAD,
													DomainConstants.QUERY_WILDCARD,
													DomainConstants.QUERY_WILDCARD,
													DomainConstants.QUERY_WILDCARD,
													DomainConstants.QUERY_WILDCARD,
													null,// where expression
													DomainConstants.EMPTY_STRING,
													true,
													strListBusSelects, // object selects
													(short) 0);
		
		StringList slCodeHeads = new StringList(mlCodeHeads.size());
		for(int i = 0 ; i < mlCodeHeads.size() ; i++)
		{
			slCodeHeads.addElement((String)((Map)mlCodeHeads.get(i)).get("name"));
		}
		if (!UIUtil.isNullOrEmpty(strFinancialProgressCodeHeadFilter))
		{
			slCodeHeads.removeElement(strFinancialProgressCodeHeadFilter);
			slCodeHeads.add(0, strFinancialProgressCodeHeadFilter);
		}
		else
		{
			slCodeHeads.add(0, "all");
		}
        
        mapCodeHeads.put("field_choices", slCodeHeads);
        mapCodeHeads.put("field_display_choices", slCodeHeads);
        return mapCodeHeads;
    }
	
	
	public Vector getCodeHeadAllocation(Context context, String[] args) throws Exception{
		Vector colVector = new Vector();
		try{
			String strYear = DomainConstants.EMPTY_STRING;
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			StringList slYinFY = FrameworkUtil.split(strYear, "-");
			String sStartFY = "\'4/1/"+slYinFY.get(0)+" 12:00:00 AM\'";
			String sEndFY = "\'3/31/"+slYinFY.get(1)+" 11:59:59 PM\'";
			System.out.println("sStartFY :: "+sStartFY);
			System.out.println("sEndFY :: "+sEndFY);
			
			StringList slReturnList = new StringList();
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
			System.out.println("Spot it pending:: objectList :: "+objectList);
            Map mTemp = null;
            String strCodeHeadId = "";
            String strCodeHeadAllocation = "";
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
				strCodeHeadId = (String)mTemp.get("CodeHeadId");
				strCodeHeadAllocation = "";
				if(UIUtil.isNotNullAndNotEmpty(strCodeHeadId)){
				
					String strTotalAllocation = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].to.from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					StringList slTotalAllocation = FrameworkUtil.split(strTotalAllocation,"|");
					double dTotalAllocation = 0;
					for(int j=0;j<slTotalAllocation.size();j++){
						dTotalAllocation = dTotalAllocation + Double.valueOf((String)slTotalAllocation.get(j));
					}
					
					String strTotalAllocationCFY = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]=='"+strYear+"'].to.from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					StringList slTotalAllocationCFY = FrameworkUtil.split(strTotalAllocationCFY,"|");
					double dTotalAllocationCFY = 0;
					for(int j=0;j<slTotalAllocationCFY.size();j++){
						dTotalAllocationCFY = dTotalAllocationCFY + Double.valueOf((String)slTotalAllocationCFY.get(j));
					}

					StringBuilder sb= new StringBuilder();
					sb.append(WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAllocation));
					sb.append("<br/>");
					sb.append("CFY: " + WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAllocationCFY));
					
					StringBuilder sbNew = new StringBuilder();
sbNew.append("<html><head><style>").append("div {").append("word-wrap: break-word;}").append("</style></head>");
sbNew.append("<body><div class=\"A\">");
					
					sbNew.append("<b>").append("<u>").append("IHQ Allot.").append("</u>").append("</b>").append("<br/>").append(WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAllocationCFY)).append("<br/>");

					String sFRId = (String) mTemp.get("id");
					DomainObject domFR = new DomainObject(sFRId);
					String sWOId = (String) domFR.getInfo(context, "to[WMSWOFundRequest].from.id");

					//StringList slWODetails = FrameworkUtil.split(sWODetails, "|");
					//String sWOId = slWODetails.get(slWODetails.size()-1);
					System.out.println("spot2 sWOId = "+sWOId);
					Double dRow2Amt = 0.0;
					Double dRow3Amt = 0.0;
					Double dRow5Amt = 0.0;
					
					if(UIUtil.isNotNullAndNotEmpty(sWOId))
					{
						
						DomainObject domWO = new DomainObject(sWOId);
						StringList slFundSels = new StringList();
						slFundSels.add(DomainConstants.SELECT_ID);
						slFundSels.add("attribute[WMSTotalAmount]");
						String sWhere = "current == Approved && current.actual >= "+sStartFY+" && current.actual <= "+sEndFY+"";
						MapList mlFR = domWO.getRelatedObjects(context,
												"WMSWOFundRequest",
												"WMSFundRequest",
												slFundSels,
												null,
												false, //toDir
												true, //fromDir
												(short)1,
												sWhere,
												null,
												0);
						if(mlFR != null && !mlFR.isEmpty())
						{							
							for(int k = 0; k < mlFR.size(); k++)
							{
								Map mFR = (Map) mlFR.get(k);
								dRow2Amt += Double.parseDouble((String)mFR.get("attribute[WMSTotalAmount]"));
							}
						}
						
						//Row 3: Start
						
						StringList slBillSels = new StringList();
						slBillSels.add(DomainConstants.SELECT_ID);
						slBillSels.add("attribute[WMSCertifiedAmount]");
						String sWhereRow3 = "( current == Approved || current == Paid ) && current.actual >= "+sStartFY+" && current.actual <= "+sEndFY+"";
						MapList mlApprovedBills = domWO.getRelatedObjects(context,
																"WMSWOAbstractMBE",
																"WMSAbstractMeasurementBookEntry",
																slBillSels,
																null,
																false, //toDir
																true, //fromDir
																(short)1,
																sWhereRow3,
																null,
																0);
						if(mlApprovedBills != null && !mlApprovedBills.isEmpty())
						{
							for(int k = 0; k < mlApprovedBills.size(); k++)
							{
								Map mApprovedBill = (Map) mlApprovedBills.get(k);
								dRow3Amt += Double.parseDouble((String)mApprovedBill.get("attribute[WMSCertifiedAmount]"));
							}
						}
						//Row 3: End
						
						//Row 5: Start
						
						MapList mlApprovedBillsAll = domWO.getRelatedObjects(context,
																"WMSWOAbstractMBE",
																"WMSAbstractMeasurementBookEntry",
																slBillSels,
																null,
																false, //toDir
																true, //fromDir
																(short)1,
																"(current == Approved || current == Paid )",
																null,
																0);						
						if(mlApprovedBills != null && !mlApprovedBills.isEmpty())
						{
							for(int k = 0; k < mlApprovedBills.size(); k++)
							{
								Map mApprovedBill = (Map) mlApprovedBills.get(k);
								dRow5Amt += Double.parseDouble((String)mApprovedBill.get("attribute[WMSCertifiedAmount]"));
							}
						}
						//Row 5: End
					}
					
					sbNew.append("<b>").append("<u>").append("Allot. prior CFY(W)").append("</u>").append("</b>").append("<br/>").append(WMSUtil_mxJPO.converToIndianCurrency(context,dRow2Amt)).append("<br/>");

					
					sbNew.append("<b>").append("<u>").append("Bills Expended CFY(W)").append("</u>").append("</b>").append("<br/>").append(WMSUtil_mxJPO.converToIndianCurrency(context,dRow3Amt)).append("<br/>");
					
					sbNew.append("<b>").append("<u>").append("Allot. Bal(SOBT) CFY(W)").append("</u>").append("</b>").append("<br/>").append(WMSUtil_mxJPO.converToIndianCurrency(context,dRow2Amt-dRow3Amt)).append("<br/>");
					
					sbNew.append("<b>").append("<u>").append("Expdr Till Now (SO/RC/WO)").append("</u>").append("</b>").append("<br/>").append(WMSUtil_mxJPO.converToIndianCurrency(context,dRow5Amt)).append("<br/>");
					sbNew.append("</div></body></html>");
					colVector.add(sbNew.toString());
					
				}
				
				
            }
            return colVector;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	 public StringList getFundRequired(Context context, String[] args) throws Exception{
        try{
            StringList slReturnList = new StringList();
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Map mTemp = null;
			String strObjectId = "";
			String strFundRequired = "";
			DomainObject doFundRequest = DomainObject.newInstance(context);
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
                strObjectId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
					doFundRequest.setId(strObjectId);
					strFundRequired = doFundRequest.getAttributeValue(context,ATTRIBUTE_WMSTOTALAMOUNT);
					slReturnList.add(WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strFundRequired)));
				}else{
					slReturnList.add("0.00");
				}
				
            }

            return slReturnList;
            
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        
    }
	 @com.matrixone.apps.framework.ui.ProgramCallable
    public  Vector getCodeHeadProjectWorkName(Context context, String[] args) throws Exception {
		Vector colVector = new Vector();
       // MapList mlFinalList = new MapList();
        try
        {
			String strYear = DomainConstants.EMPTY_STRING;
            LocalDateTime now = LocalDateTime.now();
            int year = now.getYear();
            int month = now.getMonthValue();
            
            if(month>3){
                strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
            }else{
                strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
            }
			
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainObject.SELECT_ID);
            strListBusSelects.add(DomainObject.SELECT_NAME);
            strListBusSelects.add(DomainObject.SELECT_TYPE);
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            MapList mlFundItems = DomainObject.findObjects(context,
                                                            TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            "current==Review",               // where expression
                                                            DomainConstants.EMPTY_STRING,
                                                            true,
                                                            strListBusSelects, // object selects
                                                            (short) 0);
                    
            Map mTemp = null;
            Map mFinalMap = null;
            String strType = "";
            String strCodeHeadId = "";
            String strCodeHeadAllocation = "";
            StringList slWorkOrderList = new StringList();
            String strWOID = "";
            for(int i = 0; i < mlFundItems.size(); i++){
                mTemp = (Map)mlFundItems.get(i);
                strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                if (!slWorkOrderList.contains(strWOID)) {
                    slWorkOrderList.add(strWOID);
                }
            }
            int iWOListSize = slWorkOrderList.size();
            String[] saWOArray = new String[iWOListSize];
            StringList slWOSelectable = new StringList();
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
            slWOSelectable.add(DomainConstants.SELECT_ID);
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.description");
			slWOSelectable.add("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
			slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
			
            //make the array for WO objects
            for(int j = 0; j < iWOListSize; j++){
                saWOArray[j] = (String)slWorkOrderList.get(j);
            }
            MapList mlWOInfo = DomainObject.getInfo(context, saWOArray, slWOSelectable);
            //Get other fields for the WO
            Map mWOTemp = null;
            Map mCurrentWorkOrderDetails = new HashMap();
            Map mWorkOrderDetails = new HashMap();
            for(int k = 0; k < mlWOInfo.size(); k++){
                mCurrentWorkOrderDetails = new HashMap();
                mWOTemp = (Map)mlWOInfo.get(k);
                strWOID = (String)mWOTemp.get(DomainConstants.SELECT_ID);
                Map mFinancialDetails = getWOFinancials(context, strWOID);
                mCurrentWorkOrderDetails.putAll(mFinancialDetails);
				String CodeHead= (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				String CodeHeadName= (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
				String ProjectName = (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
				String WorkName = (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
				 StringBuilder sb= new StringBuilder();
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Code Head");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(CodeHead + "      " +CodeHeadName);
				sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Project Name");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(ProjectName.replace("&","&amp;"));
				sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Work Name");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(WorkName);
                colVector.add(sb.toString());
            }
			 return colVector;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
	}
	
	 public  Vector getTSWorkOrderDetails(Context context, String[] args) throws Exception {
       Vector colVector1 = new Vector();
        try
        {
			String strYear = DomainConstants.EMPTY_STRING;
            LocalDateTime now = LocalDateTime.now();
            int year = now.getYear();
            int month = now.getMonthValue();
            
            if(month>3){
                strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
            }else{
                strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
            }
			
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainObject.SELECT_ID);
            strListBusSelects.add(DomainObject.SELECT_NAME);
            strListBusSelects.add(DomainObject.SELECT_TYPE);
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            MapList mlFundItems = DomainObject.findObjects(context,
                                                            TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            "current==Review",               // where expression
                                                            DomainConstants.EMPTY_STRING,
                                                            true,
                                                            strListBusSelects, // object selects
                                                            (short) 0);
                    
            Map mTemp = null;
            Map mFinalMap = null;
            String strType = "";
            String strCodeHeadId = "";
            String strCodeHeadAllocation = "";
            StringList slWorkOrderList = new StringList();
            String strWOID = "";
            for(int i = 0; i < mlFundItems.size(); i++){
                mTemp = (Map)mlFundItems.get(i);
                strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                if (!slWorkOrderList.contains(strWOID)) {
                    slWorkOrderList.add(strWOID);
                }
            }
            int iWOListSize = slWorkOrderList.size();
            String[] saWOArray = new String[iWOListSize];
            StringList slWOSelectable = new StringList();
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_PO_NUMBER+"]");
            slWOSelectable.add(DomainConstants.SELECT_ID);
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.description");
			slWOSelectable.add("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
			slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
			slWOSelectable.add("originated");
			slWOSelectable.add("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMS_TS_LETTER_NUMBER+"]");
			slWOSelectable.add("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute[WMSTSNumber]");
			slWOSelectable.add("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.state[Approved].actual");
			
			
			
            //make the array for WO objects
            for(int j = 0; j < iWOListSize; j++){
                saWOArray[j] = (String)slWorkOrderList.get(j);
            }
            MapList mlWOInfo = DomainObject.getInfo(context, saWOArray, slWOSelectable);
            //Get other fields for the WO
            Map mWOTemp = null;
            Map mCurrentWorkOrderDetails = new HashMap();
            Map mWorkOrderDetails = new HashMap();
            for(int k = 0; k < mlWOInfo.size(); k++){
                mCurrentWorkOrderDetails = new HashMap();
                mWOTemp = (Map)mlWOInfo.get(k);
                  strWOID = (String)mWOTemp.get(DomainConstants.SELECT_ID);
                Map mFinancialDetails = getWOFinancials(context, strWOID);
                mCurrentWorkOrderDetails.putAll(mFinancialDetails);
				String strWOAmount = (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
				String strWOAGNumber = (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_PO_NUMBER+"]");
				String strWODate = (String)mWOTemp.get("originated");
				String strTSAmount = (String)mWOTemp.get("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
				System.out.println("strWODate"+strWODate);
				String strTSLetterNumber = (String)mWOTemp.get("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMS_TS_LETTER_NUMBER+"]");
				String strTSNumber = (String)mWOTemp.get("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute[WMSTSNumber]");
				String strTSApprovedDate = (String)mWOTemp.get("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.state[Approved].actual");

				
				if(UIUtil.isNullOrEmpty(strWOAmount)){
					strWOAmount = "0";
				}
				if(UIUtil.isNullOrEmpty(strTSAmount)){
					strTSAmount = "0";
				}
				//strWOAmount= String.format("%.2f", Double.valueOf(strWOAmount));
				//String strTSConvertedAmount= String.format("%.2f", Double.valueOf(strTSAmount));
				StringBuilder sb= new StringBuilder();
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("TS Ref. Letter No. and Date");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(strTSLetterNumber);
				sb.append("<br/>");
				sb.append("Dated of "+strTSApprovedDate);
				sb.append("<br/>");
				//sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("TS Amount ");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				 sb.append(String.format("%.2f", Double.valueOf(strTSAmount)));
				 sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("TS Serial Number ");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				 sb.append(strTSNumber);
				sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Order Letter No and Date");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(strWOAGNumber.replace("&","&amp;"));
				sb.append("<br/>");
				sb.append("Dated of "+strWODate);
				sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Order Amount");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(String.format("%.2f", Double.valueOf(strWOAmount)));	
                colVector1.add(sb.toString());
			}
			 return colVector1;
				
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }
	
	 @com.matrixone.apps.framework.ui.ProgramCallable
    public  Vector getCodeHeadProjectNameApproved(Context context, String[] args) throws Exception {
       Vector colVector = new Vector();
        try
        {
            HashMap hashmap = (HashMap) JPO.unpackArgs(args);
            String strWMSFYFilter = (String)hashmap.get("WMSFYFilter");
            if (UIUtil.isNullOrEmpty(strWMSFYFilter)) {
                String strYear = DomainConstants.EMPTY_STRING;
                LocalDateTime now = LocalDateTime.now();
                int year = now.getYear();
                int month = now.getMonthValue();
                
                if(month>3){
                    strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
                }else{
                    strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
                }
                strWMSFYFilter = strYear;
            }
            String strWhere = "current==Approved && attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]=='"+strWMSFYFilter+"'";
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainObject.SELECT_ID);
            strListBusSelects.add(DomainObject.SELECT_NAME);
            strListBusSelects.add(DomainObject.SELECT_TYPE);
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT+"]");
            
            
            MapList mlFundItems = DomainObject.findObjects(context,
                                                            TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            strWhere,               // where expression
                                                            DomainConstants.EMPTY_STRING,
                                                            true,
                                                            strListBusSelects, // object selects
                                                            (short) 0);
                    
            Map mTemp = null;
            Map mFinalMap = null;
            String strType = "";
            StringList slWorkOrderList = new StringList();
            String strWOID = "";
            for(int i = 0; i < mlFundItems.size(); i++){
                mTemp = (Map)mlFundItems.get(i);
                strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                if (!slWorkOrderList.contains(strWOID)) {
                    slWorkOrderList.add(strWOID);
                }
            }
            int iWOListSize = slWorkOrderList.size();
            String[] saWOArray = new String[iWOListSize];
            StringList slWOSelectable = new StringList();
          slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.description");
			slWOSelectable.add("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
			slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
			slWOSelectable.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
            slWOSelectable.add(DomainConstants.SELECT_ID);
            //make the array for WO objects
            for(int j = 0; j < iWOListSize; j++){
                saWOArray[j] = (String)slWorkOrderList.get(j);
            }
            MapList mlWOInfo = DomainObject.getInfo(context, saWOArray, slWOSelectable);
            //Get other fields for the WO
           Map mWOTemp = null;
            Map mCurrentWorkOrderDetails = new HashMap();
            Map mWorkOrderDetails = new HashMap();
            for(int k = 0; k < mlWOInfo.size(); k++){
                mCurrentWorkOrderDetails = new HashMap();
                mWOTemp = (Map)mlWOInfo.get(k);
                strWOID = (String)mWOTemp.get(DomainConstants.SELECT_ID);
                Map mFinancialDetails = getWOFinancials(context, strWOID);
                mCurrentWorkOrderDetails.putAll(mFinancialDetails);
				String CodeHead= (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				String CodeHeadName= (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
				String ProjectName = (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
				String WorkName = (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
				 StringBuilder sb= new StringBuilder();
				 sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Code Head");
				sb.append("</u>");
				sb.append("</b>");
				 sb.append("</h6>");
				sb.append("<br/>");
                sb.append(CodeHead + "      " +CodeHeadName);
				sb.append("<br/>");
				 sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Project Name");
				sb.append("</u>");
				sb.append("</b>");
				 sb.append("</h6>");
				sb.append("<br/>");
                sb.append(ProjectName);
				sb.append("<br/>");
				 sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Work Name");
				sb.append("</u>");
				sb.append("</b>");
				 sb.append("</h6>");
				sb.append("<br/>");
                sb.append(WorkName);
                colVector.add(sb.toString());
            }
			 return colVector;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
	}

	
	/*public Vector getAllocationAndExpenditureDetails(Context context, String[] args) throws Exception{
		Vector colVector = new Vector();
		try{
			String strYear = DomainConstants.EMPTY_STRING;
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			
			StringList slReturnList = new StringList();
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Map mTemp = null;
            String strCodeHeadId = "";
            String strCodeHeadAllocation = "";
			BigDecimal bgTotalExpended = new BigDecimal(0);
            BigDecimal bgCYExpended = new BigDecimal(0);
			BigDecimal bgTotalAllotment = new BigDecimal(0);
            BigDecimal bgCYAllotment = new BigDecimal(0);
			BigDecimal bgFundBalance = new BigDecimal(0);
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
				strCodeHeadId = (String)mTemp.get("CodeHeadId");
				strCodeHeadAllocation = "";
				String strTotalAllocationCFY1 = "";
				String strTotalAllocation1 = "";
				if(UIUtil.isNotNullAndNotEmpty(strCodeHeadId)){
				
					String strTotalAllocation = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].to.from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					StringList slTotalAllocation = FrameworkUtil.split(strTotalAllocation,"|");
					double dTotalAllocation = 0;
					for(int j=0;j<slTotalAllocation.size();j++){
						dTotalAllocation = dTotalAllocation + Double.valueOf((String)slTotalAllocation.get(j));
					}
					
					String strTotalAllocationCFY = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]=='"+strYear+"'].to.from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					StringList slTotalAllocationCFY = FrameworkUtil.split(strTotalAllocationCFY,"|");
					double dTotalAllocationCFY = 0;
					for(int j=0;j<slTotalAllocationCFY.size();j++){
						dTotalAllocationCFY = dTotalAllocationCFY + Double.valueOf((String)slTotalAllocationCFY.get(j));
						
					
					}
					strTotalAllocation1 =${CLASS:WMSUtil}.converToIndianCurrency(context,dTotalAllocation);
						System.out.println("strTotalAllocation1--------------"+strTotalAllocation1);
						strTotalAllocationCFY1 =${CLASS:WMSUtil}.converToIndianCurrency(context,dTotalAllocationCFY);
				}
			
					
					bgTotalExpended = (BigDecimal)mTemp.get("TotalExpendedAmount");
                bgCYExpended = (BigDecimal)mTemp.get("CYExpendedAmount");
                Double dblTotalValueExp = Double.parseDouble(bgTotalExpended.toString());
                String strTotalAmountExpended = String.format("%.2f", dblTotalValueExp);
                Double dblCYValue = Double.parseDouble(bgCYExpended.toString());
                String strCYAmountExp = String.format("%.2f", dblCYValue);
				
				  bgTotalAllotment = (BigDecimal)mTemp.get("TotalAllotment");
                bgCYAllotment = (BigDecimal)mTemp.get("CYAllotment");
                Double dblTotalValueAllot = Double.parseDouble(bgTotalAllotment.toString());
                String strTotalAmountAllocated = String.format("%.2f", dblTotalValueAllot);
                Double dblCYValueAllot = Double.parseDouble(bgCYAllotment.toString());
                String strCYAmountAllot = String.format("%.2f", dblCYValue);
				
				bgFundBalance = bgTotalAllotment.subtract(bgTotalExpended);
                Double dblTotalValue = Double.parseDouble(bgFundBalance.toString());
                String strTotalAmountBalance = String.format("%.2f", dblTotalValue);
                StringBuilder sb= new StringBuilder();
					
					
					sb.append(${CLASS:WMSUtil}.converToIndianCurrency(context,Double.parseDouble(strTotalAmountExpended)));
					sb.append("<br/>");
					sb.append("CFY: "+${CLASS:WMSUtil}.converToIndianCurrency(context,Double.parseDouble(strCYAmountExp)));
					sb.append("<br/>");
				
					 sb.append(${CLASS:WMSUtil}.converToIndianCurrency(context,Double.parseDouble(strTotalAmountAllocated)));
					sb.append("<br/>");
					sb.append("CFY: "+${CLASS:WMSUtil}.converToIndianCurrency(context,Double.parseDouble(strCYAmountAllot)));
					sb.append("<br/>");
					
					sb.append(${CLASS:WMSUtil}.converToIndianCurrency(context,Double.parseDouble(strTotalAmountBalance)));
					
				
					colVector.add(sb.toString());
					
				}
				    return colVector;
				
            }
        catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}*/
	
	public Vector getLetterDateAndNumber(Context context, String[] args) throws Exception{
        Vector colVector = new Vector();
        try{
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
			//System.out.println("objectList"+objectList);
			
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			           
            Map mTemp = null;
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
				String FRQID= (String)mTemp.get("id");
				String letterNumber =MqlUtil.mqlCommand(context,"print bus "+FRQID+"  select attribute[WMSFRQLetterNumber].value  dump");
				String letterDate = MqlUtil.mqlCommand(context,"print bus "+FRQID+"  select state[Review].actual  dump");
                StringBuilder sb= new StringBuilder();
                sb.append(letterNumber.replace("&","&amp;"));
                sb.append("<br/>");
				
				if(UIUtil.isNotNullAndNotEmpty(letterDate))
				{
					Date dLetterDate = sdf.parse(letterDate);
					letterDate = sdf.format(dLetterDate);
					sb.append("dated of: "+letterDate);
				}
				else
					sb.append("dated of: ");
								
                colVector.add(sb.toString());
            }
            return colVector;
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
    }
	
	public StringList getFundRequestApprovalHistory(Context context, String[] args) throws Exception
	{
		StringList slReturnList = new StringList();
		Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
		String strFRQId = "";
		Map mTemp = null;
		for (int i = 0 ; i < objectList.size(); i++)
		{
			mTemp = (Map)objectList.get(i);
			strFRQId = (String)mTemp.get("id");
			StringBuilder sb=new StringBuilder();
			String shref = "../common/emxIndentedTable.jsp?program=WMSApprovalHistory:getAllApprovedTask&amp;table=WMSApprovalHistory&amp;header=Approval History&amp;HelpMarker=emxhelplifecycleapprovaltab&amp;selection=none&amp;freezePane=SNo,ApprovedUser";
			sb.append("<a href=\"javascript:showModalDialog('"+shref+"&amp;objectId="+strFRQId+"','600','400','false');\" >");            
			sb.append("View");
			sb.append("</a>");
			
			slReturnList.add(sb.toString());
		}
		return slReturnList;
	}
	
	@com.matrixone.apps.framework.ui.PostProcessCallable
	public void connectFRToWO(Context context, String args[]) throws Exception
	{
		Map CrucialMap = (Map) JPO.unpackArgs(args);
		//System.out.println("CrucialMap :: "+CrucialMap);
		Map ParamsMap = (Map) CrucialMap.get("paramMap");
		String sFRId = (String) ParamsMap.get("newObjectId");
		System.out.println("Crucial sFRID :: "+sFRId);		
		
		Map FormMap = (Map) CrucialMap.get("formMap");
		Map RequestMap = (Map) FormMap.get("requestMap");
		String sWOId = (String) RequestMap.get("parentOID");
		System.out.println("Crucial sWOId :: "+sWOId);
		
		DomainObject domToConnect = new DomainObject(sFRId);
		DomainObject domFromConnect = new DomainObject(sWOId);
		
		DomainRelationship.connect(context, domFromConnect, "WMSWOFundRequest", domToConnect);
		
	}
	
	public String getTotalBillsAmt(Context context, String args[]) throws Exception
	{
		Double dTotalBillsAmt = 0.0;
		
		Map pgmMap = (Map) JPO.unpackArgs(args);
		Map RequestMap = (Map) pgmMap.get("requestMap");		
		String sWOId = (String)RequestMap.get("parentOID");		
		DomainObject domWO = new DomainObject(sWOId);
		StringList slBillSels = new StringList();
		slBillSels.add(DomainConstants.SELECT_ID);
		slBillSels.add("attribute[WMSCertifiedAmount]");
		MapList mlApprovedBills = domWO.getRelatedObjects(context,
												"WMSWOAbstractMBE",
												"WMSAbstractMeasurementBookEntry",
												slBillSels,
												null,
												false, //toDir
												true, //fromDir
												(short)1,
												"current == Approved || current == Paid",
												null,
												0);

		if(mlApprovedBills != null && !mlApprovedBills.isEmpty())
		{
			for(int i = 0; i < mlApprovedBills.size(); i++)
			{
				Map mApprovedBill = (Map) mlApprovedBills.get(i);
				dTotalBillsAmt += Double.parseDouble((String)mApprovedBill.get("attribute[WMSCertifiedAmount]"));
			}
		}
		
		return String.valueOf(dTotalBillsAmt);
	}
	

	public String getBalanceAmt(Context context, String args[]) throws Exception
	{
		Double dBalanceAmt = 0.0;
		
		Map pgmMap = (Map) JPO.unpackArgs(args);
		Map RequestMap = (Map) pgmMap.get("requestMap");		
		String sWOId = (String)RequestMap.get("parentOID");
		DomainObject domWO = new DomainObject(sWOId);
		Double dWOValueOfContract = Double.parseDouble((String)domWO.getInfo(context, "attribute[WMSValueOfContract]"));
		
		// Get Total Bills  Amt : START
		Double dTotalBillsAmt = 0.0;
		StringList slBillSels = new StringList();
		slBillSels.add(DomainConstants.SELECT_ID);
		slBillSels.add("attribute[WMSCertifiedAmount]");
		MapList mlApprovedBills = domWO.getRelatedObjects(context,
												"WMSWOAbstractMBE",
												"WMSAbstractMeasurementBookEntry",
												slBillSels,
												null,
												false, //toDir
												true, //fromDir
												(short)1,
												"current == Approved || current == Paid",
												null,
												0);
		if(mlApprovedBills != null && !mlApprovedBills.isEmpty())
		{
			for(int i = 0; i < mlApprovedBills.size(); i++)
			{
				Map mApprovedBill = (Map) mlApprovedBills.get(i);
				dTotalBillsAmt += Double.parseDouble((String)mApprovedBill.get("attribute[WMSCertifiedAmount]"));
			}
		}
		
		dBalanceAmt = dWOValueOfContract - dTotalBillsAmt;
		
		return String.valueOf(dBalanceAmt);
	}

	public String getWOValueOfContract(Context context, String args[]) throws Exception
	{
		Double dWOValueOfContract = 0.0;
		Map pgmMap = (Map) JPO.unpackArgs(args);
		Map RequestMap = (Map) pgmMap.get("requestMap");
		
		String sWOId = (String)RequestMap.get("parentOID");
		DomainObject domWO = new DomainObject(sWOId);
		dWOValueOfContract = Double.parseDouble((String)domWO.getInfo(context, "attribute[WMSValueOfContract]"));
		
		return String.valueOf(dWOValueOfContract);
	}

	public String getTotalApprovedFundRequestAmt(Context context, String args[]) throws Exception
	{
		//String sReturnAmt = "";
		Double dReturnAmt = 0.0;
		Map pgmMap = (Map) JPO.unpackArgs(args);
		System.out.println("latest pgmMap :: "+pgmMap);
		Map RequestMap = (Map) pgmMap.get("requestMap");
		
		String sWOId = (String)RequestMap.get("parentOID");
		DomainObject domWO = new DomainObject(sWOId);
		StringList slFundSels = new StringList();
		slFundSels.add(DomainConstants.SELECT_ID);
		slFundSels.add("attribute[WMSTotalAmount]");
		MapList mlFR = domWO.getRelatedObjects(context,
												"WMSWOFundRequest",
												"WMSFundRequest",
												slFundSels,
												null,
												false, //toDir
												true, //fromDir
												(short)1,
												"current == Approved",
												null,
												0);

		if(mlFR != null && !mlFR.isEmpty())
		{
			for(int i = 0; i < mlFR.size(); i++)
			{
				Map mFR = (Map) mlFR.get(i);
				String sWMSTotalAmount = (String) mFR.get("attribute[WMSTotalAmount]");
				dReturnAmt += Double.parseDouble(sWMSTotalAmount);
			}
		}
		return String.valueOf(dReturnAmt);		
	}

	public HashMap getFundRequestDataForPDF(Context context, String args[]) throws Exception
	{
		//String sFundRequestId = "34288.53217.4655.57175";
		//System.out.println("DEBUG :: START :: getFundRequestDataForPDF");
		//String sFundRequestId = args[0];
		  HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String sFundRequestId = (String)programMap.get("objectId");
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		HashMap hmFundRequestPDF = new HashMap();
		Map mFundRequestPDF = new HashMap();
		StringList slFundSels = new StringList();
		slFundSels.add("attribute[WMSCYAllotmentAmount]");
		slFundSels.add("attribute[WMSTotalAmount]");
		slFundSels.add("attribute[WMSFundRequestFolioNumber]");
		slFundSels.add("current.actual");
		slFundSels.add("to[WMSWOFundRequest].from.attribute[WMSWorkorderTitle]");
		slFundSels.add("to[WMSWOFundRequest].from.to[WMSProjectWorkOrder].from.name");
		slFundSels.add("owner");
		//slFundSels.add("attribute[WMSCYAllotmentAmount]");
		
		
		DomainObject domFundReq = new DomainObject(sFundRequestId);
		System.out.println("before");
		mFundRequestPDF = domFundReq.getInfo(context, slFundSels);
		//System.out.println("1. mFundRequestPDF = "+mFundRequestPDF);
		
		String sFundRequestOwner = (String) mFundRequestPDF.get("owner");
		//WMSPersonDesignation
		String sOwnerDesignation = MqlUtil.mqlCommand(context, "print bus Person $1 $2 select $3 dump",sFundRequestOwner, "-", "attribute[WMSPersonDesignation]");
		hmFundRequestPDF.put("designation", sOwnerDesignation);
		String sOwnerorganization = MqlUtil.mqlCommand(context, "print bus Person "+sFundRequestOwner+ " - select from[Assigned Security Context].to.from[Security Context Organization].to.name dump");
		String strPlanningOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Planning");
		String strWorksOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Works");
		String strEqupmentsOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Equipments");
		String strDepartment="";
		if(strWorksOrgName.equals(sOwnerorganization)){
		strDepartment="SO1 Works";	
		hmFundRequestPDF.put("department", strDepartment);
		}
		if(strEqupmentsOrgName.equals(sOwnerorganization)){
		strDepartment="CWE (E)";	
		hmFundRequestPDF.put("department", strDepartment);
		}
		if(strPlanningOrgName.equals(sOwnerorganization)){
		strDepartment="        ";	
		hmFundRequestPDF.put("department", strDepartment);
		}
		//System.out.println("2. mFundRequestPDF = "+mFundRequestPDF);
		
		String sFundApprovedDate = (String) mFundRequestPDF.get("current.actual");
		Date dFundApprovedDate = sdf.parse(sFundApprovedDate);
		sFundApprovedDate = sdf.format(dFundApprovedDate);
		hmFundRequestPDF.put("Fund Approved Date", sFundApprovedDate);
		
		String sFundRequestAllotmentamount = (String) mFundRequestPDF.get("attribute[WMSCYAllotmentAmount]");
			hmFundRequestPDF.put("AllotmentAmount", sFundRequestAllotmentamount);
		String sFundRequestTotalAmount = (String) mFundRequestPDF.get("attribute[WMSTotalAmount]");
			hmFundRequestPDF.put("TotalAmount", sFundRequestTotalAmount);
		String sFundRequestFolionumber = (String) mFundRequestPDF.get("attribute[WMSFundRequestFolioNumber]");
			hmFundRequestPDF.put("FolioNumber", sFundRequestFolionumber);
		String sFundRequestWkName = (String) mFundRequestPDF.get("to[WMSWOFundRequest].from.attribute[WMSWorkorderTitle]");
			hmFundRequestPDF.put("WorkName", sFundRequestWkName);
		String sFundRequestProjectName = (String) mFundRequestPDF.get("to[WMSWOFundRequest].from.to[WMSProjectWorkOrder].from.name");
			hmFundRequestPDF.put("ProjectName", sFundRequestProjectName);
		
		
		
		StringList busSelects = new StringList();
		busSelects.add(DomainConstants.SELECT_ID);
		busSelects.add(DomainConstants.SELECT_TYPE);
		busSelects.add(DomainConstants.SELECT_NAME);
		//busSelects.add("attribute[WMSWorkorderTitle]");
		
		//busSelects.add("DomainConstants.SELECT_ID");
		//busSelects.add("DomainConstants.SELECT_ID");
		//busSelects.add("DomainConstants.SELECT_ID");
		MapList mlForCodeHead = domFundReq.getRelatedObjects(context,
															 "WMSWOFundRequest,WMSProjectWorkOrder,WMSProjectCodeHead",
															 "*",
															 busSelects,
															 new StringList(),
															true, //toDir
															true, //fromDir
															(short)0,
															null,
															null,
															0);
		//System.out.println("mlForCodeHead = "+mlForCodeHead);
		String sCodeHeadID = "";
		if(mlForCodeHead != null && !mlForCodeHead.isEmpty())
		{
			for(int i = 0; i < mlForCodeHead.size(); i++)
			{
				Map mForCodeHead = (Map) mlForCodeHead.get(i);
				String sObjType = (String) mForCodeHead.get("type");
				if(sObjType.equals("WMSCodeHead"))
				{
					sCodeHeadID = (String) mForCodeHead.get("id");
					hmFundRequestPDF.put("CodeHead Name", (String)mForCodeHead.get("name")); 
					break;
				}
			}
		}
		
		//attribute[WMSCYAllotmentAmount]
		//attribute[WMSTotalAmount]
		//attribute[WMSFundRequestFolioNumber]
		//owner
		//type :WMSWorkOrder,'Project Space',WMSCodeHead
		//rel: WMSWOFundRequest,WMSProjectWorkOrder,WMSProjectCodeHead
		System.out.println("code head ID:: "+sCodeHeadID);
		DomainObject domCodeHead = new DomainObject(sCodeHeadID);
		hmFundRequestPDF.put("CodeHead Title", (String) domCodeHead.getInfo(context, "attribute[WMSCodeHeadTitle]"));
		
		StringList slAllocationSels = new StringList();
		slAllocationSels.add(DomainConstants.SELECT_ID);
		slAllocationSels.add(DomainConstants.SELECT_TYPE);
		slAllocationSels.add("attribute[WMSAllocationLetterNumber]");
		slAllocationSels.add("attribute[WMSAllocationDate]");
		
		MapList mlCodeHeadAllocations = domCodeHead.getRelatedObjects(context,
															 "WMSCodeHeadYear,WMSCodeHeadYearAllocation",
															 "WMSCodeHeadYear,WMSCodeHeadYearAllocation",
															 slAllocationSels,
															 null,
															 false, //toDir
															 true, //fromDir
															 (short)0,
															 null,
															 null,
															 0);
		//System.out.println("main mlCodeHeadAllocations :: "+mlCodeHeadAllocations);
		
		MapList mlAllocations = new MapList();
		
		if(mlCodeHeadAllocations != null && !mlCodeHeadAllocations.isEmpty())
		{
			for(int i = 0; i < mlCodeHeadAllocations.size(); i++)
			{
				Map mCodeHeadAllocations = (Map) mlCodeHeadAllocations.get(i);
				String sObjType2 = (String) mCodeHeadAllocations.get("type");
				if(sObjType2.equals("WMSCodeHeadYearAllocation"))
				{
					mlAllocations.add(mCodeHeadAllocations);
				}				
			}
		}
		System.out.println(" mlAllocations :: "+mlAllocations);
		String sAllocationLetterNos = "";
		
		if(!mlAllocations.isEmpty())
		{
			mlAllocations.sort("attribute[WMSAllocationDate]", "ascending", "date");
			for(int i = 0; i < mlAllocations.size(); i++)
			{
				Map mAllocation = (Map) mlAllocations.get(i);
				if(UIUtil.isNullOrEmpty(sAllocationLetterNos))
				{
					sAllocationLetterNos = (String) mAllocation.get("attribute[WMSAllocationLetterNumber]");					
				}
				else
					sAllocationLetterNos += ", "+ (String) mAllocation.get("attribute[WMSAllocationLetterNumber]");
			}
			String sLastAllocationDate = (String) ((Map)mlAllocations.get(mlAllocations.size()-1)).get("attribute[WMSAllocationDate]");
			
			Date dLastAllocationDate = sdf.parse(sLastAllocationDate);
			sLastAllocationDate = sdf.format(dLastAllocationDate);
			sAllocationLetterNos += "dated " + sLastAllocationDate;
			
		}
		hmFundRequestPDF.put("AllocationData", sAllocationLetterNos);
		System.out.println("final:: mFundRequestPDF :: "+hmFundRequestPDF);
		
		
		return hmFundRequestPDF;
		
		//type: WMSCodeHeadYear, WMSCodeHeadYearAllocation
		//rel : WMSCodeHeadYear, WMSCodeHeadYearAllocation
		//current.actual
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public  Vector getCodeHeadProjectWorkNameApprovedTab(Context context, String[] args) throws Exception {
		Vector colVector = new Vector();
       // MapList mlFinalList = new MapList();
        try
        {
			Map programMap = (Map) JPO.unpackArgs(args);
			MapList mlFundObjList = (MapList) programMap.get("objectList");
			
			if(mlFundObjList != null && !mlFundObjList.isEmpty())
			{
				for(int i = 0; i < mlFundObjList.size(); i++)
				{
					Map mTemp = (Map) mlFundObjList.get(i);
					String sFRId = (String) mTemp.get("id");
					DomainObject domFR = new DomainObject(sFRId);
					String sWOId = "";
					String sFundType = (String) domFR.getInfo(context, "type");
					if(sFundType.equals("WMSFundRelease"))
						sWOId = (String) mTemp.get("to[WMSWOFundRelease].from.id");
					else if(sFundType.equals("WMSFundRequest"))
						sWOId = (String) mTemp.get("to[WMSWOFundRequest].from.id");
					
					DomainObject domWO = new DomainObject(sWOId);
					StringList slProjectSels = new StringList();
					slProjectSels.add("to[WMSProjectWorkOrder].from.id");
					slProjectSels.add("to[WMSProjectWorkOrder].from.name");
					slProjectSels.add("name");
					//WMSProjectWorkOrder
					Map mProject = domWO.getInfo(context, slProjectSels);
					String sWOName = (String) mProject.get("name");
					String sProjectName = (String) mProject.get("to[WMSProjectWorkOrder].from.name");
					String sProjectId = (String) mProject.get("to[WMSProjectWorkOrder].from.id");
					
					DomainObject domProject = new DomainObject(sProjectId);
					String sCodeHeadName = domProject.getInfo(context, "from[WMSProjectCodeHead].to.name");
					
					
					
				 StringBuilder sb= new StringBuilder();
				 //sb.append("<h6>");
sb.append("<html><head><style>").append("div {").append("word-wrap: break-word;}").append("</style></head>");
sb.append("<body><div class=\"A\">");
				 
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Code Head");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(sCodeHeadName);
				sb.append("<br/>");
				sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Project Name");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(sProjectName);
				sb.append("<br/>");
				sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Work Name");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(sWOName);
				sb.append("</div></body></html>");
                colVector.add(sb.toString());
				}
			}
				
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
		return colVector;
	}
	

    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getFundRequestApprovedDashboardNew(Context context, String[] args) throws Exception {
        MapList mlFinalList = new MapList();
		Map PgmMap = (Map) JPO.unpackArgs(args);
		String sFYFilterData = (String) PgmMap.get("WMSFundsApprovedFYFilter");
		String sCodeHeadFilterData = (String) PgmMap.get("WMSFundsApprovedCodeHeadFilter");
		
        try
        {
			String strYear = DomainConstants.EMPTY_STRING;
            LocalDateTime now = LocalDateTime.now();
            int year = now.getYear();
            int month = now.getMonthValue();
            
            if(month>3){
                strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
            }else{
                strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
            }
			
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainObject.SELECT_ID);
            strListBusSelects.add(DomainObject.SELECT_NAME);
            strListBusSelects.add(DomainObject.SELECT_TYPE);
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
			
			String sWhere = "current==Approved";
			if(UIUtil.isNotNullAndNotEmpty(sFYFilterData))
			{
				sWhere += " && attribute[WMSFinancialYear] == '"+ sFYFilterData +"'";
				//attribute[WMSFinancialYear]
			}
			//String sCodeHeadFilterName = "";
			if(UIUtil.isNotNullAndNotEmpty(sCodeHeadFilterData))
			{
				if(!"all".equals(sCodeHeadFilterData))
				{
					sWhere += " && to[WMSWOFundRequest].from.to[WMSProjectWorkOrder].from.from[WMSProjectCodeHead|to.name=='"+sCodeHeadFilterData+"'].to.name == "+sCodeHeadFilterData+"";
					//1  WMSWOFundRequest  from  WMSWorkOrder  W/O-4  1
					//1  WMSProjectWorkOrder  from  Project Space  Construction of Finger Jetty-1  401614763460129
					//1  WMSProjectCodeHead  to  WMSCodeHead  1/914/38  1
					//id = 34288.53217.21675.1142
				}				
			}
			System.out.println("*");
			System.out.println("*");
			System.out.println("My Filter Where == "+sWhere);
			System.out.println("*");
			System.out.println("*");
			
            MapList mlFundItems = DomainObject.findObjects(context,
                                                            TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            sWhere,               // where expression
                                                            DomainConstants.EMPTY_STRING,
                                                            true,
                                                            strListBusSelects, // object selects
                                                            (short) 0);
															System.out.println("mlFundItems----"+mlFundItems);
															
            System.out.println("check 1 pass");       
            Map mTemp = null;
            Map mFinalMap = null;
            String strType = "";
            String strCodeHeadId = "";
            String strCodeHeadAllocation = "";
            StringList slWorkOrderList = new StringList();
            String strWOID = "";
            for(int i = 0; i < mlFundItems.size(); i++){
                mTemp = (Map)mlFundItems.get(i);
                strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                if (!slWorkOrderList.contains(strWOID)) {
                    slWorkOrderList.add(strWOID);
                }
            }
            int iWOListSize = slWorkOrderList.size();
            String[] saWOArray = new String[iWOListSize];
            StringList slWOSelectable = new StringList();
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
            slWOSelectable.add(DomainConstants.SELECT_ID);
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.description");
			slWOSelectable.add("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
			slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
			
            //make the array for WO objects
            for(int j = 0; j < iWOListSize; j++){
                saWOArray[j] = (String)slWorkOrderList.get(j);
            }
            MapList mlWOInfo = DomainObject.getInfo(context, saWOArray, slWOSelectable);
            //Get other fields for the WO
            Map mWOTemp = null;
            Map mCurrentWorkOrderDetails = new HashMap();
            Map mWorkOrderDetails = new HashMap();
            for(int k = 0; k < mlWOInfo.size(); k++){
                mCurrentWorkOrderDetails = new HashMap();
                mWOTemp = (Map)mlWOInfo.get(k);
                strWOID = (String)mWOTemp.get(DomainConstants.SELECT_ID);
                Map mFinancialDetails = getWOFinancials(context, strWOID);
                mCurrentWorkOrderDetails.putAll(mFinancialDetails);
                mCurrentWorkOrderDetails.put("CodeHead", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]"));
                mCurrentWorkOrderDetails.put("CodeHeadDesc", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]"));
                mCurrentWorkOrderDetails.put("ProjectName", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name"));
                mCurrentWorkOrderDetails.put("WorkName", (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]"));
				String CodeHead= (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				String CodeHeadName= (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
				String ProjectName = (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
				String WorkName = (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
				
				String strWOAmount = (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
				String strTSAmount = (String)mWOTemp.get("from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
				
				if(UIUtil.isNullOrEmpty(strWOAmount)){
					strWOAmount = "0";
				}
				if(UIUtil.isNullOrEmpty(strTSAmount)){
					strTSAmount = "0";
				}
				mCurrentWorkOrderDetails.put("WOAmount", String.format("%.2f", Double.valueOf(strWOAmount)));
				mCurrentWorkOrderDetails.put("TSAmount", String.format("%.2f", Double.valueOf(strTSAmount)));
				mCurrentWorkOrderDetails.put("CodeHeadId", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id"));
                mWorkOrderDetails.put(strWOID, mCurrentWorkOrderDetails);
            }
            //Prepare Final Map to be returned to the Table
            Map mFundMap = null;
            Map mTableRowMap = new HashMap();
            for(int l = 0; l < mlFundItems.size(); l++){
                mFundMap = (Map)mlFundItems.get(l);
                strType = (String)mFundMap.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                Map mWOTableDeatils = (Map)mWorkOrderDetails.get(strWOID);
                mFundMap.putAll(mWOTableDeatils);
                mlFinalList.add(mFundMap);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
		System.out.println("mlFinalList :: Approved New ::: "+mlFinalList);
        return mlFinalList;
    }	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public  Vector getTSWorkOrderDetailsApproved(Context context, String[] args) throws Exception {
       Vector colVector = new Vector();
	   
        try
        {
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            //String strWMSFYFilter = (String)hashmap.get("WMSFYFilter");
			System.out.println("DEBUG :: START :: getTSWorkOrderDetailsApproved ");
			MapList objectList = (MapList) programMap.get("objectList");
			System.out.println("TS Col :: objectList :: "+objectList);			
				StringList slWOSels = new StringList();
				slWOSels.add("from[WMSWorkOrderTS].to.id");
				slWOSels.add("attribute[WMSValueOfContract]");
				slWOSels.add("attribute[WMSPONumber]");
				slWOSels.add("originated");
				String sWOvalueofContract = "";
				String sWOPONumber = "";
				String sWOOriginated = "";				
				Map mWOInfo = new HashMap();

				StringList slTSSels = new StringList();
				slTSSels.add("state[Approved].actual");
				slTSSels.add("attribute[WMSTSLetterNumber]");
				slTSSels.add("attribute[WMSTSAmount]");
				slTSSels.add("attribute[WMSTSNumber]");
				String sTSLetterNumber = "";
				String sTSNumber = "";
				String sTSAmount = "";
				String sTSApproved = "";
				Map mTSInfo = new HashMap();
				
			if(objectList != null && !objectList.isEmpty())
			{
            for(int k = 0; k < objectList.size(); k++)
			{
				Map mTemp = (Map) objectList.get(k);
				System.out.println("TS Prints mTemp :: "+mTemp);
				String sFRId = (String) mTemp.get("id");
				System.out.println("TS print sFRId :: "+sFRId);
				DomainObject domFR = new DomainObject(sFRId);
				String sWOId = "";
				String sFundType = (String) domFR.getInfo(context, "type");
				System.out.println("TS print sFundType :: "+sFundType);
				if("WMSFundRelease".equals(sFundType))
					sWOId = (String) mTemp.get("to[WMSWOFundRelease].from.id");
				else if("WMSFundRequest".equals(sFundType))
					sWOId = (String) mTemp.get("to[WMSWOFundRequest].from.id");
				
				System.out.println("TS print WO ID :: "+sWOId);
				DomainObject domWO = new DomainObject(sWOId);				
				mWOInfo = domWO.getInfo(context, slWOSels);
				String sTSId = (String) mWOInfo.get("from[WMSTechnicalSanction].to.id");
				sWOvalueofContract = (String) mWOInfo.get("attribute[WMSValueOfContract]");
				sWOPONumber = (String) mWOInfo.get("attribute[WMSPONumber]");
				sWOOriginated = (String) mWOInfo.get("originated");
				if(UIUtil.isNotNullAndNotEmpty(sTSId))
				{
					DomainObject domTS = new DomainObject(sTSId);
					mTSInfo = domTS.getInfo(context, slTSSels);
					sTSLetterNumber = (String) mTSInfo.get("attribute[WMSTSLetterNumber]");
					sTSNumber = (String) mTSInfo.get("attribute[WMSTSNumber]");
					sTSAmount = (String) mTSInfo.get("attribute[WMSTSAmount]");
					sTSApproved =(String) mTSInfo.get("state[Approved].actual");
				}
				//System.out.println(sTSLetterNumber+ " " +sTSApproved+ " " +sTSAmount+ " " +sTSNumber+ " " +sWOOriginated+ " " +sWOPONumber+ " " +sWOvalueofContract+ " ");
				//strWOAmount= String.format("%.2f", Double.valueOf(strWOAmount));
				//String strTSConvertedAmount= String.format("%.2f", Double.valueOf(strTSAmount));
				if(UIUtil.isNotNullAndNotEmpty(sWOOriginated))
				{
					Date dWOOriginated = sdf.parse(sWOOriginated);
					sWOOriginated = sdf.format(dWOOriginated);
				}
				
				if(UIUtil.isNotNullAndNotEmpty(sTSApproved))
				{
					Date dTSApproved = sdf.parse(sTSApproved);
					sTSApproved = sdf.format(dTSApproved);
				}
				
				StringBuilder sb= new StringBuilder();
				sb.append("<html><head><style>").append("div {").append("word-wrap: break-word;}").append("</style></head>");
				 sb.append("<body><div class=\"A\">");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("TS REF.Letter No and Date");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");				
                sb.append(sTSLetterNumber);
				sb.append("<br/>");
				sb.append("Dated of "+sTSApproved);
				sb.append("<br/>");
				//sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("TS Amount:");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				 sb.append(sTSAmount);
				 sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("TS Serial Number:");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				 sb.append(sTSNumber);
				sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Order Letter No and Date");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(sWOPONumber);
				sb.append("<br/>");
				sb.append("Dated of "+sWOOriginated);
				sb.append("<br/>");
				 //sb.append("<h6>");
				 sb.append("<b>");
				 sb.append("<u>");
                sb.append("Order Amount");
				sb.append("</u>");
				sb.append("</b>");
				 //sb.append("</h6>");
				sb.append("<br/>");
                sb.append(sWOvalueofContract);
				sb.append("</div></body></html>");
				//System.out.println("TS details colVector = "+sb.toString());				
                colVector.add(sb.toString());
			}
			}
			
			return colVector;
				
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList returnEmptyInitially(Context context, String args[]) throws Exception
	{
		MapList mlEmptyReturn = new MapList();
		return mlEmptyReturn;
	}

	@com.matrixone.apps.framework.ui.ProgramCallable
	public  Vector getFundDemandSectionName(Context context, String[] args) throws Exception 
	{
		Vector ColVector = new Vector();
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            //String strWMSFYFilter = (String)hashmap.get("WMSFYFilter");
			System.out.println("DEBUG :: START :: getTSWorkOrderDetailsApproved ");
			MapList objectList = (MapList) programMap.get("objectList");
			if(objectList != null && !objectList.isEmpty())
			{
				for(int i = 0; i < objectList.size(); i++)
				{
					Map mTemp = (Map) objectList.get(i);
					String sFRId = (String) mTemp.get("id");
					DomainObject domFR = new DomainObject(sFRId);
					String sFROwner = (String) domFR.getInfo(context, "owner");
					String sFROwnerID = PersonUtil.getPersonObjectID(context, sFROwner);
					System.out.println("sFROwnerID = "+sFROwnerID);
					
					if(UIUtil.isNotNullAndNotEmpty(sFROwnerID))
					{
						DomainObject domPerson = new DomainObject(sFROwnerID);
						String sPersonRole = (String) domPerson.getInfo(context, "attribute[WMSPersonDesignation]");
						ColVector.add(sPersonRole);
					}
				}
			}
		return ColVector;
	}

	public Vector getLetterDateAndNumberApprovedTab(Context context, String[] args) throws Exception{
        Vector colVector = new Vector();
        try{
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
			//System.out.println("objectList"+objectList);
			
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			           
            Map mTemp = null;
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
				String FRQID= (String)mTemp.get("id");
				String letterNumber =MqlUtil.mqlCommand(context,"print bus "+FRQID+"  select attribute[WMSFRQLetterNumber].value  dump");
				String letterDate = MqlUtil.mqlCommand(context,"print bus "+FRQID+"  select state[Approved].actual  dump");
                StringBuilder sb= new StringBuilder();
                sb.append(letterNumber.replace("&","&amp;"));
                sb.append("<br/>");
				
				if(UIUtil.isNotNullAndNotEmpty(letterDate))
				{
					Date dLetterDate = sdf.parse(letterDate);
					letterDate = sdf.format(dLetterDate);
					sb.append("dated of: "+letterDate);
				}
				else
					sb.append("dated of: ");
								
                colVector.add(sb.toString());
            }
            return colVector;
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
    }	
	


}
