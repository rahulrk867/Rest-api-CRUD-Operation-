import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import java.text.SimpleDateFormat;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.framework.ui.UIUtil;
import java.util.Iterator;
import java.util.Vector;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import java.text.DateFormat;
import java.util.Calendar;
import java.time.LocalDateTime;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.PropertyUtil;


public class WMSObservation_mxJPO extends WMSConstants_mxJPO
{
	  private static final String TYPE_Observation = "WMSObservation";
	  
	   public WMSObservation_mxJPO (Context context, String[] args)
        throws Exception
    {
        super(context, args);
    }
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getAllObservation (Context context, String[] args) throws Exception 
    {
        try
        {     
		 
            MapList mapListObservation = new MapList();
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
		    if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
                DomainObject domObjOB = DomainObject.newInstance(context, strObjectId);
                mapListObservation = getAllObservation(context, domObjOB);
			 
            }
            return mapListObservation;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
    private MapList getAllObservation(Context context, DomainObject domObjProjectSpace)
            throws Exception {
        try
        {
            StringList strListBusSelects     = new StringList(3);
            strListBusSelects.add(DomainConstants.SELECT_ID);
            strListBusSelects.add(DomainConstants.SELECT_NAME);
            strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			strListBusSelects.addElement("state[Response].actual");
			strListBusSelects.addElement("state[Forward].actual");
            StringList strListRelSelects     = new StringList(1);
            strListRelSelects.add(DomainRelationship.SELECT_ID);

            MapList mapListObservation = domObjProjectSpace.getRelatedObjects(context, // matrix context
                    "WMSProjectObservations",//RELATIONSHIP_PROJECT_WO, // relationship pattern
                    "WMSObservation", //TYPE_WMSWorkorder, // type pattern
                    strListBusSelects, // object selects
                    strListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 0, // recursion level
                    "revision==last", // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
			
			Map mTemp = null;
			String strState = "";
			
			for(int i=0;i<mapListObservation.size();i++){
				mTemp = (Map)mapListObservation.get(i);
				strState = (String)mTemp.get(DomainConstants.SELECT_CURRENT);
				if(UIUtil.isNotNullAndNotEmpty(strState) && "Create".equalsIgnoreCase(strState) == false){
					mTemp.put("RowEditable", "readonly");
				}
			}
			
					
            return mapListObservation;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }


	  @com.matrixone.apps.framework.ui.ProgramCallable
	  public MapList getAllObservationDetails(Context context, String[] args)throws Exception
				{  
		  			MapList programList = null;
		  			try
		  				{
		  					StringList busSelects = new StringList();
		  					busSelects.add("id");
							busSelects.add("name");
							busSelects.add("attribute[WMSObservationheads]");
							busSelects.add("attribute[WMSObservationDate]");
		  					programList = DomainObject.findObjects(context,
							TYPE_Observation,
							"eService Production",
							null,			
							busSelects);		
		  				} 
		  			catch (Exception ex)
		  			{
		  				throw ex;
		  			}
					
		return programList;

}
	  @com.matrixone.apps.framework.ui.CellRangeJPOCallable
		public Map getRangeObservationHead(Context context, String[] args)throws Exception
		{
			try
			{
				Map newObservationRange = new HashMap(); //map object 
				String strobservationRange = EnoviaResourceBundle.getProperty(context, "WMS.Head.Observation");
				StringList slRange = new StringList(); 
				if((UIUtil.isNotNullAndNotEmpty(strobservationRange)))//conditional statement to check is empty or not
				{
					slRange = FrameworkUtil.split(strobservationRange,",");//splitting method separated by comma 
					newObservationRange.put("field_choices", slRange);
					newObservationRange.put("field_display_choices",slRange);
				}
				return newObservationRange;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				throw e;
			}
		}
		
			public Vector getSNOColumn(Context context, String[] args) throws Exception 
			{
		try {
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			Iterator iterator = objectList.iterator();
			for (int i = 1; i < intSize + 1; i++) {
				vecResponse.add(String.valueOf(i));
			}

			return vecResponse;
		} catch (Exception exception) {
			exception.printStackTrace();
			throw exception;
		}
	}
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getObservationAssignees (Context context, String[] args) throws Exception 
	{
		try
		{
			
			MapList mapListAssignees = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjOBS = DomainObject.newInstance(context, strObjectId);
                String strObservationOwner = domObjOBS.getInfo(context, DomainConstants.SELECT_OWNER);
				
                mapListAssignees = getObservationAssignees(context, domObjOBS);
                Iterator iterator   = mapListAssignees.iterator();
                while (iterator.hasNext()) {
                    Map mapAssigneInfo = (Map) iterator.next();
                    String strAssignee = (String) mapAssigneInfo.get(DomainConstants.SELECT_NAME);
                    if (strObservationOwner.equalsIgnoreCase(strAssignee)) {
                        mapAssigneInfo.put("disableSelection", "true");
                    }
                }
			}
			
			return mapListAssignees;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	public static MapList getObservationAssignees(Context context, DomainObject domObjOBS) throws FrameworkException
	{
		try
		{
			StringList strListBusSelects     = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_NAME);
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			
             MapList mapListAssignees = domObjOBS.getRelatedObjects(context, // matrix context
            		                                                 RELATIONSHIP_WMS_OBSERVATION_ASSIGNEE, // relationship pattern
																	DomainConstants.TYPE_PERSON, // type pattern
																	strListBusSelects, // object selects
																	strListRelSelects, // relationship selects
																	true, // to direction
																	false, // from direction
																	(short) 1, // recursion level
																	DomainConstants.EMPTY_STRING, // object where clause
																	DomainConstants.EMPTY_STRING, // relationship where clause
																	0);
																

			return mapListAssignees;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
 @com.matrixone.apps.framework.ui.PostProcessCallable
    public Map connectObservationInProjects(Context context, String[] args) throws Exception {
        HashMap mapReturnMap = new HashMap();
     
        try {
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
			
            HashMap paramMap             = (HashMap)programMap.get("paramMap");
            HashMap requestMap           = (HashMap)programMap.get("requestMap");
            String strWOOID             = (String) paramMap.get("objectId");
            String strProjectOID     = (String) requestMap.get("parentOID");
         
            if(UIUtil.isNotNullAndNotEmpty(strProjectOID) && UIUtil.isNotNullAndNotEmpty(strWOOID))
            {
                ContextUtil.pushContext(context);
                DomainRelationship.connect(context, strProjectOID, RELATIONSHIP_WMS_PROJECT_OBSERVATIONS, strWOOID, true);
                ContextUtil.popContext(context);
				StringBuffer strBuffer = new StringBuffer();
                strBuffer.append("<mxRoot>");
                strBuffer.append("<action><![CDATA[add]]></action>");
                strBuffer.append("<data status=\"committed\">");
                strBuffer.append("<item oid=\""+strWOOID+"\" relId=\""+""+"\" pid=\""+strWOOID+"\"  direction=\"from\" />");
                strBuffer.append("</data>");
                strBuffer.append("</mxRoot>");
                mapReturnMap.put("selectedOID", strProjectOID);
                mapReturnMap.put("rows",strBuffer.toString());
                mapReturnMap.put("Insertdata",strBuffer.toString());
                mapReturnMap.put("Action","success");
            }
        } catch (Exception exception) {
         exception.printStackTrace();
            mapReturnMap.put("Action","Stop");
            mapReturnMap.put("Message",exception.getMessage());
        }
        return mapReturnMap;
    } 

public MapList getObservationFilterWise(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String strobservationyearFromURL = (String)programMap.get("Observationyear");
	String strobservationTypeFromURL = (String) programMap.get("ObservationType");
	String strobservationletterNoFromURL = (String) programMap.get("ObservationletterNo");
	String strobservationpartnoFromURL = (String) programMap.get("Observationpartno");
	String strobservationFromURL = (String) programMap.get("Observationhead");
	
		MapList mlobservation = new MapList();
		try
		{
			DomainObject doPerson = PersonUtil.getPersonObject(context);
			String strWhere = null;
			if (UIUtil.isNotNullAndNotEmpty(strobservationyearFromURL) && "All".equals(strobservationyearFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSSOCFinancialYear].value=='" + strobservationyearFromURL + "'";
				} else {
					strWhere = "attribute[WMSSOCFinancialYear].value=='" + strobservationyearFromURL + "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strobservationTypeFromURL) && "All".equals(strobservationTypeFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSObservationType].value=='" + strobservationTypeFromURL + "'";
				} else {
					strWhere = "attribute[WMSObservationType].value=='" + strobservationTypeFromURL + "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strobservationletterNoFromURL) && "All".equals(strobservationletterNoFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSObservationLetterNo].value=='" + strobservationletterNoFromURL + "'";
				} else {
					strWhere = "attribute[WMSObservationLetterNo].value=='" + strobservationletterNoFromURL + "'";
				}
			}
			
			if (UIUtil.isNotNullAndNotEmpty(strobservationpartnoFromURL) && "All".equals(strobservationpartnoFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSObservationPartNo].value=='" + strobservationpartnoFromURL + "'";
				} else {
					strWhere = "attribute[WMSObservationPartNo].value=='" + strobservationpartnoFromURL + "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strobservationFromURL) && "All".equals(strobservationFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSObservationheads].value=='" + strobservationFromURL + "'";
				} else {
					strWhere = "attribute[WMSObservationheads].value=='" + strobservationFromURL + "'";
				}
			}
			String whereCondition = strWhere;
		StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			//strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			//slObjSelects.addElement("id");
			strListBusSelects.addElement("id");
			strListBusSelects.addElement("physicalid");
			strListBusSelects.addElement("type");
			strListBusSelects.addElement("current");
			strListBusSelects.addElement("policy");
			strListBusSelects.addElement("name");
			strListBusSelects.addElement("description");
			strListBusSelects.addElement("attribute[WMSObservationheads]");
			strListBusSelects.addElement("attribute[WMSObservationType]");
			strListBusSelects.addElement("attribute[WMSObservationLetterNo]");
			strListBusSelects.addElement("attribute[WMSObservationPartNo]");
			strListBusSelects.addElement("attribute[WMSSOCFinancialYear]");
			strListBusSelects.addElement("attribute[WMSObservationDate]");
			strListBusSelects.addElement("attribute[WMSObservationComments]");
			strListBusSelects.addElement("attribute[WMSObservationDeadlineDate]");
			strListBusSelects.addElement("state[Response].actual");
			strListBusSelects.addElement("state[Forward].actual");
			strListBusSelects.addElement("to[WMSProjectObservations].from.name");
			strListBusSelects.addElement("to[WMSProjectObservations].from.id");
			strListBusSelects.addElement("to[WMSObservationAssignee].from.name");
			strListBusSelects.addElement("originated");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlobservation = doPerson.findObjects(context, TYPE_WMSOBSERVATION, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					whereCondition, // where clause
					strListBusSelects); // object selects
					
			
				/*String StrDateFormat1= " ";
				String StrDateFormat2= " ";
				String StrDateFormat3= " ";
			for (int i = 0; i < mlobservation.size(); i++) {
				Map mMap = (Map) mlobservation.get(i);
				StrDateFormat1=(String) mMap.get("attribute[WMSObservationDate]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat1);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("observationDate", (dt1.format(date))+"");
				StrDateFormat2=(String) mMap.get("attribute[WMSObservationResponseDate]");
				SimpleDateFormat dt2 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date1 = dt2.parse(StrDateFormat2);
				SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("ResponseDate", (dt21.format(date))+"");
				StrDateFormat3=(String) mMap.get("originated");
				SimpleDateFormat dt3 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date2 = dt3.parse(StrDateFormat3);
				SimpleDateFormat dt31 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("CurrentDate", (dt31.format(date))+"");
		}*/
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return mlobservation;
}
	public int checkObservationDocuments(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId);
			StringList slRefDocs = doObj.getInfoList(context, "from["+DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT+"].to.id");
			if ((slRefDocs.size() == 0)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Observation.NoRefDoc");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}	
			StringList slmember = doObj.getInfoList(context, "to["+RELATIONSHIP_WMS_OBSERVATION_ASSIGNEE+"].from.id");
			if ((slmember.size() == 0)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Observation.Member");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	public boolean getObservationMembers(Context context, String[] args) throws FrameworkException {
		String strContextId = args[0];
		String strType      = args[1];
		MapList mlobservation = new MapList();
		
		try
		{
		if(strType.equalsIgnoreCase(TYPE_WMSOBSERVATION)){
		
		DomainObject observationDomainObject = DomainObject.newInstance(context,strContextId);
		mlobservation = getObservationAssignees (context, observationDomainObject);
			StringList sMembers = (StringList) observationDomainObject.getInfoList(context, "to[WMSObservationAssignee].from.name");
				if(sMembers.contains(context.getUser())) {
					return true;
				}											
				}
				}catch(Exception e) {
			e.printStackTrace();
		}
		return false;

	}

public int checkObservationResponseDocuments(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId);
			StringList slRefDocs = doObj.getInfoList(context, "from["+RELATIONSHIP_WMS_OBSERVATION_RESPONSE_DOCUMENTS+"].to.id");
			if ((slRefDocs.size() == 0)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Observation.NoResDoc");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			StringList slComments = doObj.getInfoList(context, "from[WMSObservationComments].to.id");
			if ((slComments.size() == 0)) {
				emxContextUtil_mxJPO.mqlNotice(context,"Please provide comments");
				return 1;
			}
				
			StringList slAssignees = (StringList)doObj.getInfoList(context, "to[WMSObservationAssignee].from.name");
			
			String strContextUser = context.getUser();
			
			if(slAssignees.contains(strContextUser)){
				DomainObject doPerson = PersonUtil.getPersonObject(context);
				String strPersonRole = (String)doPerson.getAttributeValue(context,"HostPersonRole");
				String defaultOrg = PersonUtil.getDefaultOrganization(context, strContextUser);
				
				String strPlanningOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Planning");
				String strWorksOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Works");
				String strEqupmentsOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Equipments");
				
				if(defaultOrg.equals(strPlanningOrgName))
				{
					if("RESOURCE".equals(strPersonRole)==false){
						emxContextUtil_mxJPO.mqlNotice(context,"Planning member should respond to this observation. Please contact planning section");
						return 1;
					}
				}
				if(defaultOrg.equals(strEqupmentsOrgName)){
					if("MIO".equals(strPersonRole)==false || "CWE".equals(strPersonRole)==false){
						emxContextUtil_mxJPO.mqlNotice(context,"MIO/CWE should respond to this observation. Please contact MIO/CWE");
						return 1;
					}
				}
				if(defaultOrg.equals(strWorksOrgName)){
					if("SO1 Works".equals(strPersonRole)==false){
						emxContextUtil_mxJPO.mqlNotice(context,"SO1 Works should respond to this observation. Please contact SO1 Works");
						return 1;
					}
				}				
			}			
			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public String getAssociatedProject (Context context,String[] args)throws Exception {
		StringBuilder sb = null;
		try { 
			String strURL="../common/emxTree.jsp";
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			String sprojectName = DomainConstants.EMPTY_STRING;
			String sprojectId = DomainConstants.EMPTY_STRING;
			
			DomainObject doObject = new DomainObject(sObjectId);
			MapList sList = doObject.getRelatedObjects(context, // matrix context
												RELATIONSHIP_WMSPROJECTSOC, // relationship pattern
												TYPE_PROJECTSPACE, // type pattern
												busSelects, // object selects
												null, // relationship selects
												true, // to direction
												false, // from direction
												(short) 1, // recursion level
												null, // object where clause
												null); // relationship where clause
			if (sList.size() == 1) {
				Map objMap = (Map) sList.get(0);
				sprojectId = (String) objMap.get(DomainConstants.SELECT_ID);
				sprojectName = (String) objMap.get(DomainConstants.SELECT_NAME);
			}
			
			sb = new StringBuilder();
			sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+sprojectId+"','600','400','false')\" >");            
			sb.append(sprojectName);
			sb.append("</a>");
		} catch(Exception e) {
			e.printStackTrace();
		} 
		return sb.toString();
	}
	
	
	@com.matrixone.apps.framework.ui.CellRangeJPOCallable
		public Map getObservationTypes(Context context, String[] args)throws Exception
		{
			try
			{
				Map newObservationRange = new HashMap(); //map object 
				String strobservationRange = EnoviaResourceBundle.getProperty(context, "WMS.Observation.Type");
				StringList slRange = new StringList(); 
				if((UIUtil.isNotNullAndNotEmpty(strobservationRange)))//conditional statement to check is empty or not
				{
					slRange = FrameworkUtil.split(strobservationRange,",");//splitting method separated by comma 
					newObservationRange.put("field_choices", slRange);
					newObservationRange.put("field_display_choices",slRange);
				}
				return newObservationRange;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				throw e;
			}
		}

public void updateObservationHead(Context context,String[] args) throws Exception{
	
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		HashMap hmRequestMap = (HashMap)programMap.get("paramMap");
		String strBus = (String)hmRequestMap.get("objectId");
		String strNewValue = (String)hmRequestMap.get("New Value");
		ContextUtil.pushContext(context);
		if(UIUtil.isNotNullAndNotEmpty(strBus)){
			DomainObject doBus = DomainObject.newInstance(context,strBus);
			doBus.setAttributeValue(context, "WMSObservationheads", strNewValue);
		}
		 
		}catch(Exception e) {
			  
			 e.printStackTrace();
		}finally{
			ContextUtil.popContext(context);
		}
	}
	  @com.matrixone.apps.framework.ui.ProgramCallable
	  public MapList getAllsObservationDetails(Context context, String[] args)throws Exception
				{  
				HashMap programMap = (HashMap)JPO.unpackArgs(args);
				String strobservationyearFromURL = (String)programMap.get("Observationyear");
				String strobservationTypeFromURL = (String) programMap.get("ObservationType");
				String strobservationletterNoFromURL = (String) programMap.get("ObservationletterNo");
				String strobservationpartnoFromURL = (String) programMap.get("Observationpartno");
				String strobservationFromURL = (String) programMap.get("Observationhead");
		  			MapList programList = null;
		  			try
		  				{
							//DomainObject doPerson = PersonUtil.getPersonObject(context);
			String strWhere = null;
			if (UIUtil.isNotNullAndNotEmpty(strobservationyearFromURL) && "All".equals(strobservationyearFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSSOCFinancialYear].value=='" + strobservationyearFromURL + "'";
				} else {
					strWhere = "attribute[WMSSOCFinancialYear].value=='" + strobservationyearFromURL + "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strobservationTypeFromURL) && "All".equals(strobservationTypeFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSObservationType].value=='" + strobservationTypeFromURL + "'";
				} else {
					strWhere = "attribute[WMSObservationType].value=='" + strobservationTypeFromURL + "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strobservationletterNoFromURL) && "All".equals(strobservationletterNoFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSObservationLetterNo].value=='" + strobservationletterNoFromURL + "'";
				} else {
					strWhere = "attribute[WMSObservationLetterNo].value=='" + strobservationletterNoFromURL + "'";
				}
			}
			
			if (UIUtil.isNotNullAndNotEmpty(strobservationpartnoFromURL) && "All".equals(strobservationpartnoFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSObservationPartNo].value=='" + strobservationpartnoFromURL + "'";
				} else {
					strWhere = "attribute[WMSObservationPartNo].value=='" + strobservationpartnoFromURL + "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strobservationFromURL) && "All".equals(strobservationFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSObservationheads].value=='" + strobservationFromURL + "'";
				} else {
					strWhere = "attribute[WMSObservationheads].value=='" + strobservationFromURL + "'";
				}
			}
		  					StringList busSelects = new StringList();
		  					busSelects.add("id");
							busSelects.add("name");
							busSelects.add("attribute[WMSObservationheads]");
							busSelects.add("attribute[WMSObservationDate]");
							busSelects.add("attribute[WMSObservationType]");
							busSelects.add("attribute[WMSObservationLetterNo]");
							busSelects.add("attribute[WMSObservationPartNo]");
							busSelects.add("attribute[WMSSOCFinancialYear]");
							busSelects.add("to[WMSProjectObservations].from.name");
							busSelects.add("description");
							busSelects.add("attribute[WMSObservationDeadlineDate]");
							busSelects.add("attribute[WMSObservationComments]");
							busSelects.add("state[Response].actual");
							busSelects.add("state[Forward].actual");
							busSelects.add("to[WMSObservationAssignee].from.attribute[WMSPersonDesignation]");
							busSelects.add("to[WMSProjectObservations].from.id");
							busSelects.add("current");
		  					programList = DomainObject.findObjects(context,
							TYPE_Observation,
							"eService Production",
							strWhere,			
							busSelects);	
							
							/*Date dBGDate = new Date();
							String strBGDate = "";
							
							 for (int i = 0; i < programList.size(); i++) {
								Map mMap = (Map) programList.get(i);
								StrDateFormat=(String) mMap.get("attribute[WMSObservationDeadlineDate].value");
								
								/*SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
								Date date = dt.parse(StrDateFormat);
								SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
								mMap.put("DeadLineDate", (dt1.format(date))+"");*/
								
								/*SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
								dBGDate = eMatrixDateFormat.getJavaDate(StrDateFormat);
								strBGDate = sdf.format(dBGDate);
								mMap.put("DeadlineDate",strBGDate );
												
								/*StrDateFormat1=(String) mMap.get("state[Response].actual");
								SimpleDateFormat dt11 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
								Date date1 = dt11.parse(StrDateFormat2);
								SimpleDateFormat dt111 = new SimpleDateFormat("dd-MM-yyyy");
								mMap.put("Response", (dt111.format(date1))+"");
								
								StrDateFormat2=(String) mMap.get("state[Forward].actual");
								SimpleDateFormat dt22 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
								Date date2 = dt.parse(StrDateFormat2);
								SimpleDateFormat dt122 = new SimpleDateFormat("dd-MM-yyyy");
								mMap.put("Forward", (dt122.format(date2))+"");
								
								/*System.out.println("strOwner---"+strOwner);
								String strOwnerID = PersonUtil.getPersonObjectID(context, strOwner);
								DomainObject dom=DomainObject.newInstance(context,strOwnerID);
								String strOwnerFullName =dom.getInfo(context, "attribute[WMSPersonDesignation].value");
								mMap.put("Member",strOwnerFullName);
							}
						}*/
				}
		  			catch (Exception ex)
		  			{
		  				throw ex;
		  			}	
		return programList;

}


@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getObservationComments(Context context, String[] args) throws Exception 
    {
        try
        { 	 
            MapList mapListObservation = new MapList();
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
		    if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
                StringList strListBusSelects     = new StringList();
				strListBusSelects.add(DomainObject.SELECT_ID);
				strListBusSelects.add(DomainObject.SELECT_DESCRIPTION);
				strListBusSelects.add(DomainObject.SELECT_ORIGINATED);
				strListBusSelects.add(DomainObject.SELECT_OWNER);
				StringList strListRelSelects     = new StringList(1);
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				
				DomainObject doObservation = DomainObject.newInstance(context,strObjectId);
				String strCurremt = (String)doObservation.getInfo(context,DomainObject.SELECT_CURRENT);

				mapListObservation = doObservation.getRelatedObjects(context, // matrix context
                    "WMSObservationComments",//RELATIONSHIP_PROJECT_WO, // relationship pattern
                    "WMSObservationComments", //TYPE_WMSWorkorder, // type pattern
                    strListBusSelects, // object selects
                    strListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 0, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
			
					Map mTemp = null;
					String strOwner = "";
					for(int i=0;i<mapListObservation.size();i++){
						mTemp = (Map)mapListObservation.get(i);
						strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
						if(UIUtil.isNotNullAndNotEmpty(strCurremt) && "Forward".equalsIgnoreCase(strCurremt) && strOwner.equals(context.getUser())){
							
						}else{
							mTemp.put("disableSelection", "true");
							mTemp.put("RowEditable", "readonly");
						}
					}			 
				}
				mapListObservation.sort("originated", "ascending", "date");
            return mapListObservation;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
	
	
	@com.matrixone.apps.framework.ui.CreateProcessCallable
    public Map createObservationComment(Context context, String[] args) throws Exception 
	{
		boolean bIsContextPushed = false;
        HashMap requestMap  = (HashMap) JPO.unpackArgs(args);
		String sPolicyName = (String) requestMap.get("Policy");
		String sObservationId = (String)requestMap.get("objectId");
		
		Map returnMap  = new HashMap();
        
        try {
            
            String symbolicTypeName = PropertyUtil.getAliasForAdmin(context, "Type", "WMSObservationComments", true);
            String symbolicPolicyName = PropertyUtil.getAliasForAdmin(context, "Policy",sPolicyName , true);
            
            DomainObject dNewObject = DomainObject.newInstance(context, "WMSObservationComments");
            String strGClassName = FrameworkUtil.autoName(context,
                                                        symbolicTypeName,
                                                        null,
                                                        symbolicPolicyName,
                                                        null,
                                                        null,
                                                        true,
                                                        true);                        
                            
            dNewObject.createObject(context, "WMSObservationComments", strGClassName, null,sPolicyName, null);
            String objectId = dNewObject.getId();
            returnMap.put("id", objectId);
       
            dNewObject.setId(objectId);
			
			ContextUtil.pushContext(context);
			bIsContextPushed = true;
			DomainObject domParent = new DomainObject(sObservationId);
			DomainRelationship.connect(context, domParent, "WMSObservationComments", dNewObject);

		}catch (Exception e) {
            throw new FrameworkException(e);
        }finally{
			if(bIsContextPushed)
				ContextUtil.popContext(context);
		}
        return returnMap;
    }	

	public void sendNotificationToMembers(Context context, String args[]) throws Exception
	{
		try{
			String strObjId = (String)args[0];
			if(UIUtil.isNotNullAndNotEmpty(strObjId)){
				DomainObject doObj = DomainObject.newInstance(context,strObjId);
				
				StringList slObsSelect = new StringList();
				String strOwner = (String)doObj.getInfo(context,DomainObject.SELECT_OWNER);
				String strProjectName = (String)doObj.getInfo(context,"to[WMSProjectObservations].from.name");
				
				StringList slToList = (StringList)doObj.getInfoList(context,"to[WMSObservationAssignee].from.name");
			
				String sMessageBody = "Observation as been forawarded from Audit section against project "+strProjectName+". Please respond before the due date.";
				emxNotificationUtil_mxJPO.sendJavaMail(context,slToList, null, null, "Observation Forwarded", sMessageBody, sMessageBody, context.getUser(), null,null, "both");
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public void sendNotificationToOwner(Context context, String args[]) throws Exception
	{
		try{
			String strObjId = (String)args[0];
			if(UIUtil.isNotNullAndNotEmpty(strObjId)){
				String strContextUser = (String)context.getUser();
				DomainObject doObj = DomainObject.newInstance(context,strObjId);
				
				StringList slObsSelect = new StringList();
				String strOwner = (String)doObj.getInfo(context,DomainObject.SELECT_OWNER);
				String strProjectName = (String)doObj.getInfo(context,"to[WMSProjectObservations].from.name");
				String strObsName = (String)doObj.getInfo(context,DomainObject.SELECT_NAME);
				
				StringList slToList = (StringList)doObj.getInfoList(context,"to[WMSObservationAssignee].from.name");
				
				String strFullName = (String)MqlUtil.mqlCommand(context,"print person "+strContextUser+" select fullname dump");
				String sMessageBody = strFullName +" has responded to the observation "+strObsName+" reported against project "+strProjectName;
				emxNotificationUtil_mxJPO.sendJavaMail(context,slToList, null, null, "Observation Response", sMessageBody, sMessageBody, context.getUser(), null,null, "both");
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}

	@com.matrixone.apps.framework.ui.PostProcessCallable
    public void reviseObservation(Context context, String[] args)throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
			String strProjectId = (String)requestMap.get("projectId");
			String strObjectId = (String)requestMap.get("objectId");
			String strDesc = (String)requestMap.get("Description");
			
			if(UIUtil.isNotNullAndNotEmpty(strObjectId) && UIUtil.isNotNullAndNotEmpty(strProjectId)){
				DomainObject doObs = DomainObject.newInstance(context,strObjectId);
				DomainObject doProj = DomainObject.newInstance(context,strProjectId);
				DomainObject doNewObs = new DomainObject(doObs
                                        .reviseObject(context, true));
				DomainRelationship.connect(context,doProj,RELATIONSHIP_WMS_PROJECT_OBSERVATIONS,doNewObs);
				doNewObs.setDescription(context,strDesc);		
			}
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public void sendObservationDueReminders(Context context, String args[]) throws Exception
	{
		try{
			
			String sFirstWeekRoles = EnoviaResourceBundle.getProperty(context,"WMS.Audit.DueNotification.FirstWeek");			
			String sSecondWeekRoles = EnoviaResourceBundle.getProperty(context,"WMS.Audit.DueNotification.SecondWeek");			
			String sThirdWeekRoles = EnoviaResourceBundle.getProperty(context,"WMS.Audit.DueNotification.ThirdWeek");
			
			
			StringList slFirstWeekRoles = FrameworkUtil.split(sFirstWeekRoles,",");
			StringList slSecondWeekRoles = FrameworkUtil.split(sSecondWeekRoles,",");
			StringList slThirdWeekRoles = FrameworkUtil.split(sThirdWeekRoles,",");
			
			StringList slObservationSelect = new StringList();
			slObservationSelect.add(DomainObject.SELECT_ID);
			slObservationSelect.add(DomainObject.SELECT_CURRENT);
			slObservationSelect.add(DomainObject.SELECT_NAME);
			slObservationSelect.add("attribute[WMSObservationDeadlineDate]");
			slObservationSelect.add("to[WMSProjectObservations].from.name");
			
			MapList mlObservationList = DomainObject.findObjects(context,
							"WMSObservation",
							"eService Production",
							"current==Forward",			
							slObservationSelect);
							
			StringList slAssigneeSelect = new StringList();
			slAssigneeSelect.add(DomainObject.SELECT_NAME);
			slAssigneeSelect.add(DomainObject.SELECT_ID);
			slAssigneeSelect.add("attribute[HostPersonRole]");

			StringList slAssigneeRelSel = new StringList();
			slAssigneeRelSel.add(DomainRelationship.SELECT_ID);
			
			Date dToday = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
			
			//int diffInDays = (int) ((dBGExpdate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
			String strId = "";
			String strDueDate = "";
			String strProjectName = "";
			String strName = "";
			String strPersonName = "";
			String strRole = "";
			
			StringList slToList = new StringList();
			Map mTemp = null;
			Map mPersonMap = null;
			DomainObject doObservation = DomainObject.newInstance(context);
			StringList slAssignees = new StringList();
			for(int i=0;i<mlObservationList.size();i++){
				slToList = new StringList();
				strDueDate = "";
				mTemp = (Map)mlObservationList.get(i);
				strDueDate = (String)mTemp.get("attribute[WMSObservationDeadlineDate]");
				strName = (String)mTemp.get(DomainObject.SELECT_NAME);
				strProjectName = (String)mTemp.get("to[WMSProjectObservations].from.name");
				strId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strId) && UIUtil.isNotNullAndNotEmpty(strDueDate)){
					Date dDueDate = sdf.parse(strDueDate);
					int diffInDays = (int) ((dToday.getTime() - dDueDate.getTime()) / (1000 * 60 * 60 * 24));
					doObservation.setId(strId);
					if(diffInDays>0){
						 MapList mapListAssignees = doObservation.getRelatedObjects(context, RELATIONSHIP_WMS_OBSERVATION_ASSIGNEE,DomainConstants.TYPE_PERSON,slAssigneeSelect,slAssigneeRelSel,true,false,(short) 1,DomainConstants.EMPTY_STRING,DomainConstants.EMPTY_STRING,0);
						 
						 for(int j=0;j<mapListAssignees.size();j++){
							 mPersonMap = (Map)mapListAssignees.get(j);
							 strPersonName = (String)mPersonMap.get(DomainObject.SELECT_NAME);
							 strRole = (String)mPersonMap.get("attribute[HostPersonRole]");
							 
							 if(diffInDays<8){
								if(slFirstWeekRoles.contains(strRole)){
									slToList.add(strPersonName);
								}
							 }else  if(diffInDays>7 && diffInDays<15){
								if(slSecondWeekRoles.contains(strRole)){
									slToList.add(strPersonName);
								}								 
							 }else if(diffInDays>14){
								if(slThirdWeekRoles.contains(strRole)){
									slToList.add(strPersonName);
								}								 
							 }
						 }
						 
						 
						 if(slToList.size()>0){
							String sMessageBody = "Observation "+strName+" reported under project "+strProjectName+" has not recieved any reponse since "+diffInDays+"days post due date.";
							emxNotificationUtil_mxJPO.sendJavaMail(context,slToList, null, null, "Observation Response Delayed by "+diffInDays+"days", sMessageBody, sMessageBody, context.getUser(), null,null, "both");
						 }
						 
					}
				}
			}
			
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}

	@com.matrixone.apps.framework.ui.PostProcessCallable
	public void connectObservationToProject(Context context, String args[]) throws Exception
	{
		Map PgmMap = (Map) JPO.unpackArgs(args);
		//System.out.println("connect ob & project data :: "+PgmMap);
		Map RequestMap = (Map) PgmMap.get("requestMap");
		String sFromObjId = (String) RequestMap.get("RelatedProjectOID");
		DomainObject domFrom = new DomainObject(sFromObjId);
		
		Map ParamsMap = (Map) PgmMap.get("paramMap");
		String sToObjId = (String) ParamsMap.get("newObjectId");
		DomainObject domTo = new DomainObject(sToObjId);
		ContextUtil.pushContext(context);
		DomainRelationship.connect(context, domFrom, "WMSProjectObservations", domTo);
		ContextUtil.popContext(context);
	}

	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAllObservationsBesideMyDesk(Context context, String args[]) throws Exception
	{
		MapList mlObs = new MapList();
		
		StringList slObSels = new StringList();
        slObSels.add(DomainConstants.SELECT_ID);
        slObSels.add(DomainConstants.SELECT_NAME);
        slObSels.add(DomainConstants.SELECT_CURRENT);
		slObSels.add(DomainConstants.SELECT_DESCRIPTION);
		slObSels.addElement("state[Response].actual");
		slObSels.addElement("state[Forward].actual");
		slObSels.addElement("attribute[WMSObservationType]");
		slObSels.addElement("attribute[WMSObservationLetterNo]");
		slObSels.addElement("attribute[WMSObservationPartNo]");
		slObSels.addElement("attribute[WMSSOCFinancialYear]");
		slObSels.addElement("attribute[WMSObservationheads]");
		slObSels.addElement("attribute[WMSObservationDeadlineDate]");
		slObSels.addElement("to[WMSObservationAssignee].from.name");
		slObSels.addElement("attribute[WMSObservationComments]");
		//slObSels.addElement("attribute[WMSObservationType]");
		//slObSels.addElement("attribute[WMSObservationType]");
		//slObSels.addElement("attribute[WMSObservationType]");
				
		slObSels.add("to[WMSProjectObservations].from.name");
		mlObs = DomainObject.findObjects(context,
		TYPE_Observation,
		"eService Production",
		"revision == last",			
		slObSels);	
		
		return mlObs;
	}

    public String deleteObservationObjects(Context context, String[] args)throws Exception 
	{
		String strErrorMessage = "Please select only the Observations which are in create state.";
		try {
			StringList slObjects = new StringList();
			String sContextUser = context.getUser();
			
			for(int i=0;i<args.length;i++) 
			{
				String sObjectId = args[i];
				StringList slObjList = FrameworkUtil.split(sObjectId,"|");
				sObjectId = (String)slObjList.get(slObjList.size()-3);
				
				DomainObject doObj = new DomainObject(sObjectId);
				String sState = doObj.getInfo(context, DomainConstants.SELECT_CURRENT);
				String strOwner = doObj.getInfo(context, DomainConstants.SELECT_OWNER);
								
				if ("Create".equals(sState) && strOwner.equals(sContextUser)) {
					slObjects.add(sObjectId);
				} else 
				{
					return strErrorMessage;
				} 

			}
			
			if(slObjects.size() > 0)
			{
				String[] objIds = new String[slObjects.size()];
				objIds = slObjects.toArray(objIds);
				ContextUtil.pushContext(context);
				DomainObject.deleteObjects(context, objIds);
				ContextUtil.popContext(context);
				strErrorMessage = "success";					
			}
		} catch(Exception ex){
			strErrorMessage = ex.getMessage();
			ex.printStackTrace();
		}
		return strErrorMessage;
    }
	
}
