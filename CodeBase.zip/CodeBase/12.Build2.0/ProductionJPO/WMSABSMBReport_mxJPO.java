import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHMerge;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblBorders;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTTblPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STBorder;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STMerge;

import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.common.Person;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.Currency;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;

import matrix.db.Context;
import matrix.db.FileList;
import matrix.db.JPO;
import matrix.db.RelationshipType;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringList;


public  class WMSABSMBReport_mxJPO {
	public static final String SYMBOLIC_type_WMSPaymentItem = "type_WMSPaymentItem";
	public static final String SYMBOLIC_type_WMSPaymentSchedule = "type_WMSPaymentSchedule";
	public static final String SYMBOLIC_attribute_WMSMBEItemType = "attribute_WMSMBEItemType";
	public static final String ATTRIBUTE_WMS_MBE_ITEM_TYPE = PropertyUtil.getSchemaProperty("attribute_WMSMBEItemType");
	public static final String TYPE_WMS_PAYMENT_ITEM = PropertyUtil.getSchemaProperty("type_WMSPaymentItem");
  	public static String ATTRIBUTE_TRAVERSE_ALTPATH = PropertyUtil.getSchemaProperty("attribute_TraverseAltPath");
	public static final String SELECT_ATTRIBUTE_TRAVERSE_ALTPATH = "attribute["+ATTRIBUTE_TRAVERSE_ALTPATH+"]";
	public static String PRIMARY_IMAGE_FROM_ALTPATH = PropertyUtil.getSchemaProperty("attribute_PrimaryImageFromAltPath");
	public static final String SELECT_ATTRIBUTE_PRIMARY_IMAGE_FROM_ALTPATH = "attribute["+PRIMARY_IMAGE_FROM_ALTPATH+"]";
	public static final String SYMBOLIC_relationship_WMSAbstractMBETechnicalDeductionRelease = "relationship_WMSAbstractMBETechnicalDeductionRelease";
	public static final String RELATIONSHIP_ABSMBE_TECHNICALDEDUCTION_RELEASE = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBETechnicalDeductionRelease");
	public static final String FORMAT_GENERIC = PropertyUtil.getSchemaProperty("format_generic");

	public static final String SELECT_GENERIC_FORMAT_FILES = "format[" + FORMAT_GENERIC + "].file.name";

	public static final String  SYMBOLIC_ATTRIBUTE_WMSABSMBETYPE = "attribute_WMSAbsMBEType";
    public static final String  ATTRIBUTE_WMSABSMBETYPE = PropertyUtil.getSchemaProperty( SYMBOLIC_ATTRIBUTE_WMSABSMBETYPE);	
    public static final String REL_ActualTransactionItem                  = PropertyUtil.getSchemaProperty("relationship_ActualTransactionItem");
	public static final String RELATIONSHIP_WORKORDER_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");
	public static final String TYPE_WMS_WORK_ORDER = PropertyUtil.getSchemaProperty("type_WMSWorkOrder");
	public static final String TYPE_WMS_MEASUREMENT_TASK = PropertyUtil.getSchemaProperty("type_WMSMeasurementTask");
	public static final String RELATIONSHIP_MBE_TASKS = PropertyUtil.getSchemaProperty("relationship_WMSMBEActivities");
	public static final String TYPE_WMS_MEASUREMENT_BOOK_ENTRY = PropertyUtil.getSchemaProperty("type_WMSMeasurementBookEntry");
	public static final String RELATIONSHIP_TASK_SOR = PropertyUtil.getSchemaProperty("relationship_WMSTaskSOR");
	public static final String RELATIONSHIP_ABSTRACT_MBE_ITEMS 	= PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBEActivities");
	public static final String RELATIONSHIP_WORKORDER_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOMBE");
	public static final String TYPE_SEGMENT = PropertyUtil.getSchemaProperty("type_WMSSegment");
	public static final String RELATIONSHIP_ITEM_TECHNICALDEDUCTION = PropertyUtil.getSchemaProperty("relationship_WMSItemTechnicalDeduction");
	 public static final String ATTRIBUTE_CURRENTBILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT= PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionReleaseCurrentBill");
	 public static final String TYPE_TECHNICAL_DEDUCTION = PropertyUtil.getSchemaProperty("type_WMSTechnicalDeduction");
	 public static final String ATTRIBUTE_TECHNICAL_DEDUCTION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionAmount");
	 public static final String ATTRIBUTE_TECHNICAL_DEDUCTION_RELEASE_AMOUNT= PropertyUtil.getSchemaProperty("attribute_WMSTechnicalDeductionReleaseAmount");
	 public static final String TYPE_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("type_WMSAbstractMeasurementBookEntry");
	 public static final String RELATIONSHIP_ABSMBE_TECHNICALDEDUCTION = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBETechnicalDeduction");
	 public static final String ATTRIBUTE_PLANT_AND_MACHINERY_ADVANCE_REVOVERED= PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEPlantAndMachinaryAdvanceRecovered");
	 
	 
	 public static final String SYMBOLIC_attribute_WMSAbstractMBEMobilistionAdvanceRecovered = "attribute_WMSAbstractMBEMobilistionAdvanceRecovered";
     public static final String ATTRIBUTE_MOBILISTION_ADVANCE_REVOVERED= PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBEMobilistionAdvanceRecovered);
     public static final String SYMBOLIC_attribute_WMSAbstractMBESecuredAdvanceRecovered = "attribute_WMSAbstractMBESecuredAdvanceRecovered";
     public static final String ATTRIBUTE_SECURED_ADVANCE_REVOVERED= PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBESecuredAdvanceRecovered);
     public static final String SYMBOLIC_attribute_WMSAbstractMBEPlantAndMachinaryAdvancePaid = "attribute_WMSAbstractMBEPlantAndMachinaryAdvancePaid";
     public static final String ATTRIBUTE_PLANT_AND_MACHINERY_ADVANCE_PAID= PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBEPlantAndMachinaryAdvancePaid);
     public static final String SYMBOLIC_attribute_WMSAbstractMBEMobilistionAdvancePaid = "attribute_WMSAbstractMBEMobilistionAdvancePaid";
     public static final String ATTRIBUTE_MOBILISTION_ADVANCE_PAID= PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBEMobilistionAdvancePaid);
     public static final String SYMBOLIC_attribute_WMSAbstractMBESecuredAdvancePaid = "attribute_WMSAbstractMBESecuredAdvancePaid";
     public static final String ATTRIBUTE_SECURED_ADVANCE_PAID= PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBESecuredAdvancePaid);
	 public static final String SYMBOLIC_attribute_WMSAbstractMBEWithHeldAmount = "attribute_WMSAbstractMBEWithHeldAmount";
     public static final String ATTRIBUTE_WITHHELD_AMOUNT= PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBEWithHeldAmount);
     public static final String SYMBOLIC_attribute_WMSAbstractMBEWithHeldReleasedAmount = "attribute_WMSAbstractMBEWithHeldReleasedAmount";
     public static final String ATTRIBUTE_WITHHELD_RELEASE_AMOUNT= PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBEWithHeldReleasedAmount);
	 public static final String SYMBOLIC_attribute_WMSAbstractMBETechnicalDeductionAmount = "attribute_WMSAbstractMBETechnicalDeductionAmount";
     public static final String ATTRIBUTE_ABS_MBE_TECHNICALDEDUCTION_AMOUNT= PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBETechnicalDeductionAmount);
     public static final String SYMBOLIC_attribute_WMSAbstractMBETechnicalDeductionReleaseAmount = "attribute_WMSAbstractMBETechnicalDeductionReleaseAmount";
     public static final String ATTRIBUTE_ABS_MBE_TECHNICALDEDUCTION_RELEASE_AMOUNT= PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBETechnicalDeductionReleaseAmount);
	 public static final String PERSON_USER_AGENT = PropertyUtil.getSchemaProperty("person_UserAgent");
	 public static final String ATTR_REDUCED_RATE_FOR_ADVANCE        = PropertyUtil.getSchemaProperty("attribute_WMSReducedRateforAdvance");
	 public static final String REL_ABS_STOCK						        = PropertyUtil.getSchemaProperty("relationship_WMSABSStock");
	 public static final String ATTR_SECURED_ADVANCE_TEMP            = PropertyUtil.getSchemaProperty("attribute_WMSSecuredAdvanceTemp");
	  public static final String ATTR_RECOVERY_AMOUNT                 = PropertyUtil.getSchemaProperty("attribute_WMSRecoveryAmount");
	  public static final String TYPE_MATERIAL_CONSUMPTION           = PropertyUtil.getSchemaProperty("type_WMSMaterialConsumption");
	  public static final String TYPE_STOCK_ENTRIES					= PropertyUtil.getSchemaProperty("type_WMSStockEntries");
	  public static final String REL_MATERIAL_CONSUMPTION_TO_AMB             = PropertyUtil.getSchemaProperty("relationship_WMSMaterialConsumptionToAMB");
	  public static final String REL_MATERIALCONSUMPTION_TO_STOCK    = PropertyUtil.getSchemaProperty("relationship_WMSMaterialConsumptionToStock");
	  public static final String ATTRIBUTE_HEAD_OTHER_DEDUCTION_DESCRIPTION   = PropertyUtil.getSchemaProperty("attribute_WMSHeadDeductionDescription");
	  public static final String ATTRIBUTE_HEAD_OTHER_DEDUCTION_AMOUNT        = PropertyUtil.getSchemaProperty("attribute_WMSHeadDeductionAmount");
	  public static final String RELATIONSHIP_HEAD_DEDUCTION                  = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBEHeadDeduction");
	  public static final String TYPE_OTER_HEAD_DEDUCTION                     = PropertyUtil.getSchemaProperty("type_WMSOtherHeadDeduction");
	  public static final String ATTRIBUTE_OTHERDEDUCTION_AMOUNT= PropertyUtil.getSchemaProperty("attribute_WMSAbstractMBEOtherDeduction");
	  public static final String ATTR_STOCK_RECOVERY_AMOUNT           = PropertyUtil.getSchemaProperty("attribute_WMSStockRecoveryAmount");
	     
    DecimalFormat df = new DecimalFormat("#.##");

   	public String writeFiles(Context context , String [] args) throws Exception
	{
		String strResturn    =    DomainConstants.EMPTY_STRING;
		try {
			Boolean bCheck          = false;
			HashMap programMap      = (HashMap)JPO.unpackArgs(args);
			String strObjID         = (String) programMap.get("objectId");
			String strDpt         = (String) programMap.get("Department");

			//DomainObject doAbstractMBE = DomainObject.newInstance(context, strObjID);
			//String sWorkOrderFormType = doAbstractMBE.getInfo(context, "to["+ RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ ATTRIBUTE_WMS_FORM_TYPE+"]");
			//if ("FormF".equals(sWorkOrderFormType)&&!"CGRDC".equals(strDpt)) {
			//		strResturn = generateForm26ForFormFWOAbstractMBE(context, strObjID,strDpt);	
			//}
			//else if("CGRDC".equals(strDpt))
			//{
			//	strResturn = generateForm26ForCGRDC(context, strObjID);
			//}
			//else {
			strResturn=generateForm26(context ,strObjID );
			//}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strResturn;
	}
	
	public String generateForm26(Context context  , String strObjID) throws Exception
	{
		String strReturn = DomainConstants.EMPTY_STRING;
		try {
			Boolean bCheck          = false;
            DomainObject domABSMB   = DomainObject.newInstance(context , strObjID);
            //String strOwner         = domABSMB.getInfo(context, DomainConstants.SELECT_OWNER);
			String strOwner         = context.getUser();
            String userID           = PersonUtil.getPersonObjectID(context, strOwner);
			ContextUtil.pushContext(context);
            String strTransPath     = context.createWorkspace();
			String sTemplateFileName = "Form26Template.docx";
			System.out.println("strTransPath---------"+strTransPath);
            getTemplated(context ,userID, strTransPath, sTemplateFileName);
            System.out.println("strTransPath1---------"+strTransPath);
            HashMap<String , String> workOrderData    =    getworkOrderDetails(context , strObjID );

            MapList mlSORItem       = getABSItemDetails(context , strObjID  , true);
            
            MapList  mlSchduleSOR		= getSORItem(true  , mlSORItem);
            MapList  mlNOnSchduleSOR	= getSORItem(false ,  mlSORItem);
            
           
            MapList mlNonSORItem    = getABSItemDetails(context , strObjID , false );
            File file               = new File(strTransPath+File.separator+"Form26Template.docx");
            FileInputStream in      = new FileInputStream(file);
            XWPFDocument document   = new XWPFDocument(in);
            
            String strPERCENTAGERATE    = workOrderData.get("PERCENTAGERATE");
            String strPERCENTAGEFLAG    = workOrderData.get("PERCENTAGEFLAG");
            Double iParcen              = Double.parseDouble(strPERCENTAGERATE);
            workOrderData.remove("PERCENTAGERATE");
            workOrderData.remove("PERCENTAGEFLAG");
            
            for (String strKey : workOrderData.keySet()) {
                bCheck     = replaceValue(document  , strKey , workOrderData.get(strKey));
                if(bCheck==false)
                {
                    //throw new Exception("Error In Replace "+strKey);
                }
            }
            String str5ColumnTotal = DomainConstants.EMPTY_STRING;
            String strSorTotal = DomainConstants.EMPTY_STRING;
            double d5ColumnTable = 0d;
            double dSorTotal = 0d;
			double	dSorNOnSchduleSORTotal	= 0d;
			
            int strTableIndex = 0;
            
           if(!mlSchduleSOR.isEmpty()) {
             strSorTotal         = CreateBelowTables(context,strObjID,document, mlSchduleSOR , strTableIndex , iParcen , strPERCENTAGEFLAG, true );
             dSorTotal = WMSUtil_mxJPO.convertToDouble(strSorTotal);
             strTableIndex++;
           }else
           {
        	   deleteTable(document, strTableIndex);
           }
             
           if(!mlNOnSchduleSOR.isEmpty()) {
               strSorTotal         = CreateBelowTables(context,strObjID,document, mlNOnSchduleSOR , strTableIndex , iParcen , strPERCENTAGEFLAG, true );
               dSorNOnSchduleSORTotal = WMSUtil_mxJPO.convertToDouble(strSorTotal);
             strTableIndex++;
            
           
           }else
           {
        	   deleteTable(document, strTableIndex);
           }
            
            
           if(!mlNonSORItem.isEmpty()) {
            str5ColumnTotal     = CreateBelowTables(context,strObjID,document, mlNonSORItem , strTableIndex , iParcen , strPERCENTAGEFLAG , false);
            d5ColumnTable = WMSUtil_mxJPO.convertToDouble(str5ColumnTotal);
           
            strTableIndex++;
           
           }
           else {
        	   deleteTable(document, strTableIndex);
           }
            Double d5Final             = 0.0;
            try {
                d5Final= dSorTotal + d5ColumnTable + dSorNOnSchduleSORTotal;
            } catch (Exception e) {
                
            }
            String strPrevAbsId     = getLastBilLDatails(context , domABSMB );
            Map mapCurrentABSInfo   = getABSinfoForLastTable( context ,  domABSMB   , false , strObjID);
            Map mapPreABSInfo       =  new HashMap();
            if(strPrevAbsId != null && !"".equals(strPrevAbsId))
            {
            	
            	DomainObject domPreMBE	=	DomainObject.newInstance( context , strPrevAbsId);
            	String strPreMBEName 	=	domPreMBE.getInfo(context, DomainConstants.SELECT_NAME);
            	String strApproveDate	=	domPreMBE.getInfo(context, "current[Approved].actual");
            	String strFinalDate = DomainConstants.EMPTY_STRING;
            	if(strApproveDate!=null && !"".equals(strApproveDate))
            	{
              		Date dtApproveDate	 	=   eMatrixDateFormat.getJavaDate(strApproveDate);
    	    		DateFormat df 			=   new SimpleDateFormat("MM-dd-yyyy");
    	    		strFinalDate 			=	df.format(dtApproveDate);
            	}
	    		bCheck     = replaceValue(document  , "No. and date of previous bill for this work: -" , "No. and date of previous bill for this work: - Name  "+strPreMBEName+"  Date "+strFinalDate);
                mapPreABSInfo =  getABSinfoForLastTableFromWO( context ,  domPreMBE  , true , strObjID);
            }
            else
            {
                mapPreABSInfo.put("dSumReductionRelease", 0.0);
                mapPreABSInfo.put("dSumReductionAmount", 0.0);
                mapPreABSInfo.put("dSumSecuredAdvancePaid" , 0.0);
                mapPreABSInfo.put("dSumPlantAndMoAdvancePaid" , 0.0);
                mapPreABSInfo.put("dSumSecuredRecovery" , 0.0);
                mapPreABSInfo.put("dSumPlantandMoRecovery" ,0.0);
                mapPreABSInfo.put("dSumPlantandMoRecovery" ,0.0);
                mapPreABSInfo.put("attribute[WMSTotalCost].value" ,"0.0");
            }
            
            CreateFinalTables(context , domABSMB , document, d5Final , mapCurrentABSInfo , mapPreABSInfo , strPrevAbsId, strTableIndex);
            document.write(new FileOutputStream(new File(strTransPath+File.separator+"Form26Report.docx")));
            StringList strFileList = new StringList();
            strFileList.add("Form26Report.docx");
            try 
            {
                System.out.println("strFileList-----------"+strFileList);
				 ContextUtil.pushContext(context, PERSON_USER_AGENT,DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
                domABSMB.checkinFromServer(context, false, false, DomainConstants.FORMAT_GENERIC, null, strFileList);
            }
            catch (Exception exception)
            {
            	System.out.println("An Error Occured in generateForm26 " +exception.getMessage());
            }
            finally 
           {
                ContextUtil.popContext(context);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
		finally 
            {
                ContextUtil.popContext(context);
            }
        return strReturn;
    }
	
	public MapList getTemplated (Context context,String strPersonId , String strTransPath, String sTemplateFileName) throws Exception
	{
            MapList mapList = null;
            StringList stringList = new StringList();
            stringList.addElement(DomainConstants.SELECT_ID);
            
            StringList relList = new StringList();
            relList.addElement(DomainConstants.SELECT_RELATIONSHIP_ID);
               try {
                     Person person =(Person)DomainObject.newInstance(context,DomainConstants.TYPE_PERSON);
                     person.setId(strPersonId);
					  System.out.println("strPersonId--------"+strPersonId);
                     mapList=person.getRelatedObjects(context,DomainConstants.RELATIONSHIP_MEMBER,DomainConstants.TYPE_DEPARTMENT,stringList,relList,true,false,(short)1,"","");
                     System.out.println("mapList--------"+mapList);
                     if(mapList.size()>0)
                     {
                            String strDeptId    =    (String) ((Map)mapList.get(0)).get(DomainConstants.SELECT_ID);
                            DomainObject domainDept    =     DomainObject.newInstance(context , strDeptId);
                            java.io.File fileEmatrixWebRoot = new java.io.File(strTransPath);
                           // String XMLFORMAT = PropertyUtil.getSchemaProperty(context, );
                            try 
                            {
                                ContextUtil.pushContext(context);
                                domainDept.checkoutFile(context, false, DomainConstants.FORMAT_GENERIC, sTemplateFileName, strTransPath);
                            }
                            catch(Exception exception)
                            {
                               System.out.println("An Error Occured in getTemplated" +exception.getMessage());
                            }
                            finally
                            {
                            	ContextUtil.popContext(context);
                            }
                     }
                     
               } catch (Exception ex) {
                 throw ex;
            }
        return mapList;
}

	  public HashMap getworkOrderDetails(Context context , String strObjectId) throws Exception
     {
         HashMap<String , String> returnMap = new HashMap<String , String>();
         try {
                StringList strListBusSelects     = new StringList(2);
                strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_NAME);
                strListBusSelects.add("to[WMSProjectWorkOrder].from.attribute[WMSProjectDiv_C].value");
                strListBusSelects.add("to[WMSProjectWorkOrder].from.attribute[WMSSubDivision_C].value");
                strListBusSelects.add("to[WMSProjectWorkOrder].from.description"); 
                strListBusSelects.add("to[Responsible Organization].from.name"); 
                
                strListBusSelects.add("attribute[WMSWorkOrderDate].value");
                strListBusSelects.add("attribute[WMSValueOfContract].value");
                strListBusSelects.add("attribute[WMSValueOfContract].value");
                strListBusSelects.add("attribute[WMSPACAmmount].value");
                strListBusSelects.add("attribute[WMSAgreementNo].value");
                
                
 
                strListBusSelects.add("attribute["+ProgramCentralConstants.ATTRIBUTE_TASK_ESTIMATED_FINISH_DATE+"].value");
                strListBusSelects.add("attribute[WMSWorkOrderDate].value");
                strListBusSelects.add("attribute[WMSCompletionDueDate].value");

               
                //strListBusSelects.add("attribute["+ProgramCentralConstants.ATTRIBUTE_TASK_ACTUAL_FINISH_DATE+"].value");
                strListBusSelects.add("attribute[WMSValueOfContract].value");
                strListBusSelects.add("attribute[WMSSanctionedRateStatus].value");
                strListBusSelects.add("attribute[WMSSanctionedRate].value");
				
                strListBusSelects.add("state[Complete].actual");

                StringList strListRelSelects     = new StringList(1);
                if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
                    DomainObject domObjAMBE = DomainObject.newInstance(context,strObjectId);
					String strABSNAME = domObjAMBE.getInfo(context , "name");
					returnMap.put("ABSNAME",strABSNAME);
					String sMBEType = domObjAMBE.getAttributeValue(context,  ATTRIBUTE_WMSABSMBETYPE);
                    returnMap.put("AMBEBILLTYPE", sMBEType.toUpperCase());
					String sMeasurmentEntries = getAbsMBEMeasurmentEntries(context, strObjectId);
					returnMap.put("MBENUMBERS", sMeasurmentEntries);
                    MapList mapListMBEs = domObjAMBE.getRelatedObjects(context, // matrix context
                                                                             RELATIONSHIP_WORKORDER_ABSTRACT_MBE, // relationship pattern
                                                                             TYPE_WMS_WORK_ORDER, // type pattern
                                                                            strListBusSelects, // object selects
                                                                            strListRelSelects, // relationship selects
                                                                            true, // to direction
                                                                            false, // from direction
                                                                            (short) 1, // recursion level
                                                                            DomainConstants.EMPTY_STRING, // object where clause
                                                                            DomainConstants.EMPTY_STRING, // relationship where clause
                                                                            0);

                    
                    returnMap.put("CASVOUNUMBER", "...............");
                    returnMap.put("CASVOUDATE", "...............");
                    //returnMap.put("WORKNOSERIAL", "3");
                   // returnMap.put("REFERENCEDATE", "");
                    //returnMap.put("REFERENCETO", "");
                    returnMap.put("PROBABLEUNIT", " Lac");
        
                    Map  objectData                 =    null;
                    String strSanctionedRateStatus    =    DomainConstants.EMPTY_STRING;
                    String strWMSSanctionedRate    =    DomainConstants.EMPTY_STRING;
                    for (int i=0 ; i<mapListMBEs.size();i++ ) {
                          objectData = (Map) mapListMBEs.get(i);
                          returnMap.put("SUBDIVISION"        , (String) objectData.get("to[WMSProjectWorkOrder].from.attribute[WMSProjectDiv_C].value"));
                          returnMap.put("DIVISION"            , (String) objectData.get("to[WMSProjectWorkOrder].from.attribute[WMSSubDivision_C].value"));
                         
                          
                          //returnMap.put("ESTCOMTDATE"        ,(String) objectData.get("attribute["+ProgramCentralConstants.ATTRIBUTE_TASK_ESTIMATED_FINISH_DATE+"].value") );
                          //returnMap.put("ACTCOMTDATE"        ,(String) objectData.get("attribute["+ProgramCentralConstants.ATTRIBUTE_TASK_ACTUAL_FINISH_DATE+"].value") );
                         
                            String strApproveDate	= (String) objectData.get("attribute[WMSWorkOrderDate].value");
	                       String strWorkOrderCompletionDate = (String) objectData.get("attribute[WMSCompletionDueDate].value");
                            String strWOStartDate 	= DomainConstants.EMPTY_STRING;
                            String strWOCompletionDate 	= DomainConstants.EMPTY_STRING;
	                      	if((strApproveDate!=null && !"".equals(strApproveDate)) && (strWorkOrderCompletionDate!=null && !"".equals(strWorkOrderCompletionDate)))
	                      	{
	                        	 Date dtApproveDate	 	=   eMatrixDateFormat.getJavaDate(strApproveDate);
	                        	 Date dtCompletionDate	 	=   eMatrixDateFormat.getJavaDate(strWorkOrderCompletionDate);
	              	    		 DateFormat df 			=   new SimpleDateFormat("dd-MMM-yyyy");
	              	    		
	              	    		 strWOStartDate			= 	df.format(dtApproveDate);
	              	    		 strWOCompletionDate 	=	df.format(dtCompletionDate);
	              	    		 
	                      	}
                          
	                      	returnMap.put("REFERENCEDATE", strWOStartDate);
	                      	returnMap.put("REFERENCETO", strWOCompletionDate);
	                      	returnMap.put("ESTCOMTDATE"        , strWOCompletionDate );
							returnMap.put("ACTCOMTDATE"        , "" );
							String sWOActualCompletionDate = (String) objectData.get("state[Complete].actual");
							if(sWOActualCompletionDate!=null && !"".equals(sWOActualCompletionDate)) {
								Date dtWOActualCompletionDate = eMatrixDateFormat.getJavaDate(sWOActualCompletionDate);
	              	    		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
	              	    		sWOActualCompletionDate = df.format(dtWOActualCompletionDate);
								returnMap.put("ACTCOMTDATE", sWOActualCompletionDate);
							}

                          returnMap.put("PROBABLEAMOUNT"    ,(String) objectData.get("attribute[WMSValueOfContract].value") );
                          strSanctionedRateStatus        =    (String) objectData.get("attribute[WMSSanctionedRateStatus].value");
                          strWMSSanctionedRate        =    (String) objectData.get("attribute[WMSSanctionedRate].value");
						  if(strWMSSanctionedRate == null || strWMSSanctionedRate.equals(""))
							  strWMSSanctionedRate = "0";
						  returnMap.put("PROBABLERATE"," @ "+strWMSSanctionedRate+" % " +  strSanctionedRateStatus );
                          returnMap.put("PERCENTAGERATE",strWMSSanctionedRate );
                          returnMap.put("PERCENTAGEFLAG",strSanctionedRateStatus );
                          returnMap.put("NAMEOFWORK", (String)objectData.get("to[WMSProjectWorkOrder].from.description") );
						  if(null != (String)objectData.get("to[Responsible Organization].from.name"))
						  {
							   returnMap.put("CONTRACTORSNAME", (String)objectData.get("to[Responsible Organization].from.name"));
						  }
						  else{
							  returnMap.put("CONTRACTORSNAME", "  ");
						  }
                         
                          returnMap.put("WORKNOSERIAL", (String)objectData.get("attribute[WMSAgreementNo].value") );
                    }
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
         return returnMap;
     }


	 public String getAbsMBEMeasurmentEntries(Context context, String strObjectId) throws Exception
	{
		String sMeasurementEntries = "";
		StringList slMMeasurementEntries = new StringList();
		DomainObject doAbsMBE = DomainObject.newInstance(context, strObjectId);
		StringList slObjectSelects = new StringList();
		slObjectSelects.add(DomainConstants.SELECT_ID);
		slObjectSelects.add(DomainConstants.SELECT_NAME);
		StringList slRelSelects = null;
		MapList mlItems = doAbsMBE.getRelatedObjects(context,  RELATIONSHIP_ABSTRACT_MBE_ITEMS,  TYPE_WMS_MEASUREMENT_TASK, slObjectSelects, slRelSelects, false, true, (short) 1, "", "");
		for (int x=0,y=mlItems.size(); x<y; x++)
		{
			Map objMap = (Map) mlItems.get(x);
			String sItemOid = (String) objMap.get(DomainConstants.SELECT_ID);
			DomainObject doItem = DomainObject.newInstance(context, sItemOid);
			MapList mlMBE = doItem.getRelatedObjects(context,  RELATIONSHIP_MBE_TASKS,  TYPE_WMS_MEASUREMENT_BOOK_ENTRY, slObjectSelects, slRelSelects, true, false, (short) 1, "current==Submitted", "");
			if (mlMBE.size() > 0)
			{
				mlMBE.sort(DomainConstants.SELECT_NAME, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_STRING);
				objMap = (Map) mlMBE.get(0);
				if (slMMeasurementEntries.contains((String) objMap.get(DomainConstants.SELECT_NAME))){
					continue;
				}
				slMMeasurementEntries.add((String) objMap.get(DomainConstants.SELECT_NAME));
				if ("".equals(sMeasurementEntries)) {
					sMeasurementEntries = (String) objMap.get(DomainConstants.SELECT_NAME);
				}
				else {
					sMeasurementEntries = sMeasurementEntries + "," + (String) objMap.get(DomainConstants.SELECT_NAME);
				}
			}
		}
		return sMeasurementEntries;
	}

	 public MapList getABSItemDetails(Context context , String strObjectId , Boolean isSORItem) throws Exception
     {
         MapList mlReturnList     =    new MapList();
         try
            {
                 DomainObject domObjAbstractMBE    = DomainObject.newInstance(context ,strObjectId );
                SelectList strListBusSelects    = new SelectList(1);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                strListBusSelects.add(DomainConstants.SELECT_NAME);
                strListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
                strListBusSelects.add("attribute[WMSUnitOfMeasure].value");
                strListBusSelects.add("attribute[WMSReducedSORRate].value");
                strListBusSelects.add("attribute[Title].value");
                strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");
                
                if(isSORItem)
                {
                	strListBusSelects.add("from["+RELATIONSHIP_TASK_SOR+"].to.to[WMSWorkOrderSOR]");
                }
                
                StringList strListRelSelects      = new StringList(1);
                strListRelSelects.add(DomainRelationship.SELECT_ID);
                strListRelSelects.add("attribute[WMSQtyPaidTillDate].value");
                strListRelSelects.add("attribute[WMSTotalDeduction].value");
                strListRelSelects.add("attribute[WMSAbstractMBEItemPayableQuantity].value");
                strListRelSelects.add("attribute[WMSAMBItemTotalCost].value");
                strListRelSelects.add("attribute[WMSAbsMBEItemCost].value");
                strListRelSelects.add("attribute[WMSDeductionRate].value");
                strListRelSelects.add("attribute[WMSMBEActivityQuantity].value");
                strListRelSelects.add("attribute[Assessment Comments].value");
                
                String strWhere = DomainConstants.EMPTY_STRING;
                
                
                strWhere        = isSORItem ? "from["+ RELATIONSHIP_TASK_SOR+"]==True" : "from["+ RELATIONSHIP_TASK_SOR+"]==False";
                mlReturnList    = domObjAbstractMBE.getRelatedObjects(context, // matrix context
                                                                         RELATIONSHIP_ABSTRACT_MBE_ITEMS, // relationship pattern
                                                                         TYPE_WMS_MEASUREMENT_TASK, // type pattern
                                                                        strListBusSelects, // object selects
                                                                        strListRelSelects, // relationship selects
                                                                        false, // to direction
                                                                        true, // from direction
                                                                        (short) 1, // recursion level
                                                                        strWhere, // object where clause
                                                                        DomainConstants.EMPTY_STRING, // relationship where clause
                                                                        0);
                
                String strWhereForABSItem ="";
               
                if(isSORItem)
                {
                     //strWhereForABSItem = "("+DomainConstants.SELECT_TYPE+"=="+ TYPE_SEGMENT+")||("+DomainConstants.SELECT_TYPE+"=="+ TYPE_MBE+"&&current==Submitted)||("+DomainConstants.SELECT_TYPE+"=="+ TYPE_WMS_MEASUREMENT_TASK+" && to[WMSAbstractMBEActivities]==True && from[WMSTaskSOR]==True)";
					 strWhereForABSItem = "("+DomainConstants.SELECT_TYPE+"=="+ TYPE_SEGMENT+")||("+DomainConstants.SELECT_TYPE+"==WMSMeasurementBook)||("+DomainConstants.SELECT_TYPE+"=="+ TYPE_WMS_MEASUREMENT_TASK+" && to[WMSAbstractMBEActivities]==True && from[WMSTaskSOR]==True)";
                }
                else
                {
                     //strWhereForABSItem = "("+DomainConstants.SELECT_TYPE+"=="+ TYPE_SEGMENT+")||("+DomainConstants.SELECT_TYPE+"=="+ TYPE_MBE+"&&current==Submitted)||("+DomainConstants.SELECT_TYPE+"=="+ TYPE_WMS_MEASUREMENT_TASK+"&& to[WMSAbstractMBEActivities]==True && from[WMSTaskSOR]==False)";
					 strWhereForABSItem = "("+DomainConstants.SELECT_TYPE+"=="+ TYPE_SEGMENT+")||("+DomainConstants.SELECT_TYPE+"==WMSMeasurementBook)||("+DomainConstants.SELECT_TYPE+"=="+ TYPE_WMS_MEASUREMENT_TASK+"&& to[WMSAbstractMBEActivities]==True && from[WMSTaskSOR]==False)";
                }

                MapList mapListItems = getAbsMBEParticularsMBEs(context,domObjAbstractMBE, strWhereForABSItem , mlReturnList , isSORItem); 
                mlReturnList.addAll(mapListItems);
            }
            catch(Exception frameworkException)
            {
                frameworkException.printStackTrace();
                throw frameworkException;
            }
         return mlReturnList;
     }
	
	
	private MapList getAbsMBEParticularsMBEs(Context context,DomainObject domObjAbsMBE, String strWhere , MapList mlPreList , Boolean isSORItem)throws FrameworkException {
            try
            {
                String strABSMBId      =    domObjAbsMBE.getId(context);
                //String strRelWhere     =    "(name[connection]=="+RELATIONSHIP_WORKORDER_MBE+") || (name[connection]=="+RELATIONSHIP_MBE_TASKS+"&&attribute[WMSAbsMBEOID].value!="+strABSMBId+")";
                String strRelWhere     =    DomainConstants.EMPTY_STRING;
                
                ArrayList<String> alAllPreListId 	=	 new ArrayList<String>();
                Map mapData 	= null;
                for (int i = 0; i < mlPreList.size(); i++) {
                	mapData	=	(Map) mlPreList.get(i);
                	alAllPreListId.add((String)mapData.get(DomainConstants.SELECT_ID));
				}


                String strWOOID = domObjAbsMBE.getInfo(context, "relationship["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
                MapList mapListItems = new MapList();
                if(UIUtil.isNotNullAndNotEmpty(strWOOID))
                {
                    domObjAbsMBE.setId(strWOOID);
                    SelectList strListBusSelects    = new SelectList(1);
                    strListBusSelects.add(DomainConstants.SELECT_ID);
                    strListBusSelects.add(DomainConstants.SELECT_NAME);
                    strListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
                    strListBusSelects.add("attribute[WMSUnitOfMeasure].value");
                    strListBusSelects.add("attribute[WMSReducedSORRate].value");
                    strListBusSelects.add("attribute[WMSQtyPaidTillDate].value");
                    strListBusSelects.add("attribute[Title].value");

                    if(isSORItem)
                    {
                        strListBusSelects.add("from[WMSTaskSOR].to.to[WMSWorkOrderSOR]");
                    }

                    StringList strListRelSelects      = new StringList(1);

                    Pattern patternRel  = new Pattern(RELATIONSHIP_WORKORDER_MBE);
                    patternRel.addPattern(RELATIONSHIP_MBE_TASKS);
                    Pattern patternType = new Pattern("WMSMeasurementBook");
                    patternType.addPattern(TYPE_WMS_MEASUREMENT_TASK);    
                    patternType.addPattern(TYPE_SEGMENT);  
					

                    mapListItems 		= domObjAbsMBE.getRelatedObjects(context,
                                                                    //patternRel.getPattern(),  // relationship pattern
																	"WMSMeasurementBookItems",
                                                                    patternType.getPattern(),  // object pattern
                                                                    false,                                                        // to direction
                                                                    true,                                                       // from direction
                                                                    (short)0,                                                      // recursion level
                                                                    strListBusSelects,                                                 // object selects
                                                                    strListRelSelects,                                                         // relationship selects
                                                                    strWhere,                                // object where clause
                                                                    strRelWhere,                                // relationship where clause
                                                                    (short)0,                                                      // No expand limit
                                                                    DomainConstants.EMPTY_STRING,                                // postRelPattern
                                                                    TYPE_WMS_MEASUREMENT_TASK,                                                // postTypePattern
                                                                    null);
                    

					Map dataMap     	=    null;
                    MapList mlFinalList = new MapList();
                    
                    
                    
                    String strItemIds 	=	DomainConstants.EMPTY_STRING;
                    for (int i = 0; i < mapListItems.size(); i++) {
                        dataMap    	=    (Map) mapListItems.get(i);
                        strItemIds	= (String) dataMap.get(DomainConstants.SELECT_ID);
                        if(!alAllPreListId.contains(strItemIds))
                        {
                        	 dataMap.put("isOther", "true");
                             mlFinalList.add(dataMap);
                        }
                       
                    }
                    mapListItems.clear();
                    mapListItems.addAll(mlFinalList);
                }
                return mapListItems;
            }
            catch(FrameworkException frameworkException)
            {
                frameworkException.printStackTrace();
                throw frameworkException;
            }
        }
	
	
	public boolean replaceValue( XWPFDocument doc , String srtKey , String stValue )
     {
        boolean breturn = false;    
        try {
            for (XWPFParagraph p : doc.getParagraphs()) {
                List<XWPFRun> runs = p.getRuns();
                if (runs != null) {
                    for (XWPFRun r : runs) {
                        String text = r.getText(0);
                        if (text != null && srtKey.equalsIgnoreCase(text)) {
                            text = text.replace(srtKey, stValue);
                            r.setText(text, 0);
                            breturn=true;  
                            break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return breturn;
     }

	 private String  CreateBelowTables(Context context,String strAbstractMBEOID,XWPFDocument document, MapList mlItemDetails , int tableIndex , Double iSORPar , String strPERCENTAGEFLAG, Boolean isSOR) throws Exception
    {
        XWPFTable tbl     = document.getTables().get(tableIndex);
        Map MapDetails    = null;
        String strReturn  = DomainConstants.EMPTY_STRING;
        
        ArrayList<Double> al5Double = new ArrayList<Double>();
        ArrayList<Double> al6Double = new ArrayList<Double>();
    	
    	ArrayList<Double> arrayListTDCurrent = new ArrayList<Double>();
    	ArrayList<Double> arrayListTDTillDate = new ArrayList<Double>();
    	ArrayList<Double> arrayListTDReleaseCurrent = new ArrayList<Double>();
    	ArrayList<Double> arrayListTDReleaseTillDate = new ArrayList<Double>();
    	
        int totalRow                 = mlItemDetails.size()+3;
        replaceVauleInTable(tbl,"PERCENTAGERATE",""+ iSORPar);
        String strDescriptionValue	=	DomainConstants.EMPTY_STRING;
    	MapList mapListReleasedTDs = new MapList();
    	if(UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID) )
    	{
    		DomainObject domObjAbsMBE = DomainObject.newInstance(context, strAbstractMBEOID);
    		StringList strListBusSelects     = new StringList(2);
    		strListBusSelects.add(DomainConstants.SELECT_ID);
    		strListBusSelects.add("to["+RELATIONSHIP_ITEM_TECHNICALDEDUCTION+"].from.id");
    		StringList strListRelSelects     = new StringList(2);
    		strListRelSelects.add(DomainRelationship.SELECT_ID);
    		strListRelSelects.add("attribute["+ATTRIBUTE_CURRENTBILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
    		mapListReleasedTDs =  domObjAbsMBE.getRelatedObjects(context, // matrix context
    				RELATIONSHIP_ABSMBE_TECHNICALDEDUCTION_RELEASE, // relationship pattern
    				TYPE_TECHNICAL_DEDUCTION, // type pattern
    				strListBusSelects, // object selects
    				strListRelSelects, // relationship selects
    				false, // to direction
    				true, // from direction
    				(short) 1, // recursion level
    				DomainConstants.EMPTY_STRING, // object where clause
    				DomainConstants.EMPTY_STRING, // relationship where clause
    				0);
    	}    
    	int intIndex = 3;
    	for (int i = 0 ; i < mlItemDetails.size() ; i++) 
    	{
    		XWPFTableRow    row     = tbl.insertNewTableRow(intIndex);
             MapDetails                = (Map) mlItemDetails.get(i);
    		String strItemOID = (String) MapDetails.get(DomainConstants.SELECT_ID);

    		Map<String, Double> mapTDAmount = getItemTechnicalDeducationData(context, strItemOID, strAbstractMBEOID,mapListReleasedTDs);
    		arrayListTDCurrent.add( mapTDAmount.get("CurrentBillDeductionAmount"));
    		arrayListTDTillDate.add( mapTDAmount.get("UptoDateDeductionAmount"));
    		arrayListTDReleaseCurrent.add( mapTDAmount.get("CurrentBillDeductionReleaseAmount"));
    		arrayListTDReleaseTillDate.add( mapTDAmount.get("UptoDateDeductionReleaseAmount"));

             Double dSecColumnSum    = 0.0;
             Double dFourColumnSum    = 0.0;
    		for (int j = 0; j < 7; j++) 
    		{
                if( j==0 )
                {
                    row.createCell().setText( (String) MapDetails.get("attribute[WMSUnitOfMeasure].value"));
                }
                else if(j==1)
                {
                    String  strQtyPaidTillDate             = (String) MapDetails.get("attribute[WMSQtyPaidTillDate].value");
                    String  strMBEActivityQuantity         = (String) MapDetails.get("attribute[WMSMBEActivityQuantity].value");
					if(null == strMBEActivityQuantity || "null".equalsIgnoreCase(strMBEActivityQuantity) || strMBEActivityQuantity.length() == 0)
                    {
                        strMBEActivityQuantity="0.0";
                    }
                    if(null == strQtyPaidTillDate || "null".equalsIgnoreCase(strQtyPaidTillDate) || strQtyPaidTillDate.length() == 0)
					{
                        strQtyPaidTillDate="0.0";
                    }
                    try {
	                        Double dQtyPaidTillDate            =    Double.parseDouble(strQtyPaidTillDate);
	                        Double dMBEActivityQuantity        =    Double.parseDouble(strMBEActivityQuantity);
	                        dSecColumnSum    = dMBEActivityQuantity + dQtyPaidTillDate;
	                        //row.createCell().setText(""+  df.format(dSecColumnSum)  );
	                        row.createCell().setText(""+  round(dSecColumnSum)  );
                        } catch (Exception e) {
							e.printStackTrace();
                    }
                }
                else if( j==2 )
                {
                	strDescriptionValue	=	(String) MapDetails.get("attribute[Title].value") +" - "+(String) MapDetails.get(DomainConstants.SELECT_DESCRIPTION);
                    row.createCell().setText(strDescriptionValue );
                }
                else if( j==3 )
                {
                    row.createCell().setText( (String)  MapDetails.get("attribute[WMSReducedSORRate].value"));
                }
                else if( j==4 )
                {
                    String strQtyPaidTillDate             = (String) MapDetails.get("attribute[WMSQtyPaidTillDate].value");
                    String strMBEActivityQuantity         = (String) MapDetails.get("attribute[WMSMBEActivityQuantity].value");
                    String strFourthColumn                 = (String) MapDetails.get("attribute[WMSReducedSORRate].value");
					if(null == strMBEActivityQuantity || "null".equalsIgnoreCase(strMBEActivityQuantity) || strMBEActivityQuantity.length() == 0)
                    {
                        strMBEActivityQuantity="0.0";
                    }
                    if(null == strQtyPaidTillDate || "null".equalsIgnoreCase(strQtyPaidTillDate) || strQtyPaidTillDate.length() == 0)
					{
                        strQtyPaidTillDate="0.0";
                    }
                    try {    
                        dFourColumnSum                    = Double.parseDouble(strFourthColumn);
                        Double dQtyPaidTillDate            = "".equals(strQtyPaidTillDate) ? 0.0: Double.parseDouble(strQtyPaidTillDate);
                        Double dMBEActivityQuantity        = Double.parseDouble(strMBEActivityQuantity);
                        dSecColumnSum                    = dMBEActivityQuantity + dQtyPaidTillDate;
                        Double dTotal                    = dSecColumnSum*dFourColumnSum;
                        dFourColumnSum=dTotal;
                        
                            al5Double.add(dTotal);
                        
                        //row.createCell().setText("".equals(strQtyPaidTillDate)? "-":" "+ df.format(dTotal)  );
                        row.createCell().setText("".equals(strQtyPaidTillDate)? "-":" "+ round(dTotal));
                        
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                else if(j==5)
                {
                    String  strIsOther             = (String) MapDetails.get("isOther");
                    if(!"True".equalsIgnoreCase(strIsOther))
                    {
                        String  strMBEActivityQuantity         = (String) MapDetails.get("attribute[WMSMBEActivityQuantity].value");
                        String strWMSReducedSORRate          = (String) MapDetails.get("attribute[WMSReducedSORRate].value");
						String strFourthColumn                 = (String) MapDetails.get("attribute[WMSReducedSORRate].value");
						if(null == strMBEActivityQuantity || "null".equalsIgnoreCase(strMBEActivityQuantity) || strMBEActivityQuantity.length() == 0)
						{
							strMBEActivityQuantity="0.0";
						}
                        try {
                            Double dMBEActivityQuantity        =    Double.parseDouble(strMBEActivityQuantity);
                            Double dWMSReducedSORRate        =    Double.parseDouble(strWMSReducedSORRate);
                            Double bFinalTotal                = dMBEActivityQuantity * dWMSReducedSORRate;
                            al6Double.add(bFinalTotal);
                            //row.createCell().setText(""+df.format(bFinalTotal) );
                            row.createCell().setText(""+round(bFinalTotal));
                        } catch (Exception e) {
							e.printStackTrace();                            
                        }
                    }
                    else
                    {
                        row.createCell().setText("  ");
                    }
                }
                else if(j==6)
                {
                    row.createCell().setText((String) MapDetails.get("attribute[Assessment Comments].value"));
                }
            }
    		
    		boolean booleanRowAdded = addTechnicalDeductionRow(tbl, mapTDAmount,intIndex);
    		if(booleanRowAdded)
    		{
    			intIndex++;
    			totalRow++;
    		}
    		booleanRowAdded =  addTechnicalDeductionReleaseRow(tbl, mapTDAmount,intIndex);
    		if(booleanRowAdded)
    		{
    			totalRow++;
    		}
    		intIndex++;
        }
         
         Double  d5ColumeSum     = listTotal(al5Double);
         Double  d6ColumeSum     = listTotal(al6Double);
         
         Double  doubleTDCurrent     		= listTotal(arrayListTDCurrent);
         Double  doubleTDTillDate     		= listTotal(arrayListTDTillDate);
         Double  doubleTDReleaseCurrent     = listTotal(arrayListTDReleaseCurrent);
         Double  doubleTDReleaseTillDate    = listTotal(arrayListTDReleaseTillDate);
         
         //strReturn    =    d5ColumeSum.toString();
         d5ColumeSum = d5ColumeSum.doubleValue()-doubleTDCurrent.doubleValue()+doubleTDReleaseCurrent.doubleValue();
         d6ColumeSum = d6ColumeSum.doubleValue()-doubleTDTillDate.doubleValue()+doubleTDReleaseTillDate.doubleValue();
         XWPFTableRow    row      = tbl.getRow(totalRow);
         //row.getCell(1).setText(""+df.format(d5ColumeSum)); 
         //row.getCell(2).setText(""+df.format(d6ColumeSum));
         
         row.getCell(1).setText(""+round(d5ColumeSum)); 
         row.getCell(2).setText(""+round(d6ColumeSum));
         
         
         if(isSOR)
         {
             Double    d5ColumePar        = (iSORPar*d5ColumeSum )/ 100 ;
             Double    d6ColumePar        = (iSORPar*d6ColumeSum )/ 100 ;
                 
             totalRow++;
             String strSign               = strPERCENTAGEFLAG.equalsIgnoreCase("below") ? "-":"+";
             row                          = tbl.getRow(totalRow);
             //row.getCell(1).setText(strSign + " "+df.format(d5ColumePar) );
             //row.getCell(2).setText(strSign + " "+ df.format(d6ColumePar) );
             row.getCell(1).setText(strSign + " "+ round(d5ColumePar) );
             row.getCell(2).setText(strSign + " "+ round(d6ColumePar) );
             
             
            totalRow++;
            Double d5FinalToal            = 0.0;
            Double d6FinalToal            = 0.0;
            
            if(strPERCENTAGEFLAG.equalsIgnoreCase("below"))
            {
                d5FinalToal =d5ColumeSum - d5ColumePar;
                d6FinalToal =d6ColumeSum - d6ColumePar;
            }
            else
            {
                d5FinalToal =d5ColumeSum + d5ColumePar;
                d6FinalToal =d6ColumeSum + d6ColumePar;
            }
            row      = tbl.getRow(totalRow);
            
            //row.getCell(1).setText(""+df.format(d5FinalToal) );
            //row.getCell(2).setText(""+df.format(d6FinalToal) );
            
            row.getCell(1).setText(""+round(d5FinalToal) );
            row.getCell(2).setText(""+round(d6FinalToal) );
            
            strReturn= d5FinalToal.toString();
            
            totalRow++;
            totalRow++;
            row      = tbl.getRow(totalRow);
            //row.getCell(2).setText(""+df.format(d5FinalToal) );
            row.getCell(2).setText(""+round(d5FinalToal) );
            
            totalRow++;
            totalRow++;
            row      = tbl.getRow(totalRow);
            //row.getCell(2).setText(""+df.format(d6FinalToal) );
            row.getCell(2).setText(""+round(d6FinalToal) );
            
            totalRow++;
            
            
            
            totalRow++;
            row      		= tbl.getRow(totalRow);
            //String value    = NumberToWord(""+d6FinalToal.longValue());
            String value = ""+d6FinalToal;
            if(d6FinalToal>0)
            {
                value    =  NumberToWord(""+round(d6FinalToal));
            }

            value            = "".equals(value)?"Zero":value;
            row.getCell(1).setText(""+value+" Only");
         }
         else
         {
             totalRow++;
             totalRow++;
             row      = tbl.getRow(totalRow);
             row.getCell(2).setText(""+round(d5ColumeSum));
             
             strReturn=d5ColumeSum.toString();

             totalRow++;
             totalRow++;
             row      = tbl.getRow(totalRow);
             row.getCell(2).setText(""+round(d6ColumeSum));
            
             totalRow++;
             totalRow++;
             row      = tbl.getRow(totalRow);
             // String value    =        NumberToWord(""+d6ColumeSum.longValue());
             String value       =        NumberToWord(""+round(d6ColumeSum));
             row.getCell(1).setText(""+value +" Only");
         }
         return strReturn;
    }

	 
	 private Map<String, Double> getItemTechnicalDeducationData(Context context, String strItemOID,
			String strAbstractMBEOID, MapList mapListAbsMBEReleasedTDs) throws FrameworkException {
		Map<String,Double> mapTDAmount = new HashMap<String,Double>(4);

		 
		 if(UIUtil.isNotNullAndNotEmpty(strItemOID) )
		 {
		     double doubleDeductionAmount = 0d;
		     double doubleCurrentBillDeductionAmount = 0d;
		     double doubleDeductionReleaseAmount = 0d;
		     double doubleCurrentBillDeductionReleaseAmount = 0d;
			 
			 Iterator<Map<String,String>> iteratorCurrentReleases = mapListAbsMBEReleasedTDs.iterator();
			 Map<String,String> mapReleasedTD;
			 while(iteratorCurrentReleases.hasNext())
			 {
				 mapReleasedTD = iteratorCurrentReleases.next();
				 String strConnectedItemOID = mapReleasedTD.get("to["+RELATIONSHIP_ITEM_TECHNICALDEDUCTION+"].from.id");
				 if(strConnectedItemOID.equals(strItemOID))
				 {
					 String strCurrentReleaseAmount  = mapReleasedTD.get("attribute["+ATTRIBUTE_CURRENTBILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
					 double doubleCurrentReleaseAmount = WMSUtil_mxJPO.convertToDouble(strCurrentReleaseAmount);
					 doubleCurrentBillDeductionReleaseAmount += doubleCurrentReleaseAmount;
				 }
			 }
			 
			String strBusWhere = "to["+RELATIONSHIP_ABSMBE_TECHNICALDEDUCTION+"].from.id=="+strAbstractMBEOID;
			 DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
			 StringList strListBusSelects=new StringList(3);
			 strListBusSelects.add(DomainConstants.SELECT_ID);
			 strListBusSelects.add("attribute["+ATTRIBUTE_TECHNICAL_DEDUCTION_AMOUNT+"]");
			 strListBusSelects.add("attribute["+ATTRIBUTE_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
			 StringList strListRelSelects=new StringList(2);
			 strListRelSelects.add(DomainRelationship.SELECT_ID);
			 
			 MapList mapListTechnicalDeductions = domObjItem.getRelatedObjects(context, // matrix context
					 RELATIONSHIP_ITEM_TECHNICALDEDUCTION, // relationship pattern
					 TYPE_TECHNICAL_DEDUCTION, // type pattern
					 strListBusSelects, // object selects
					 strListRelSelects, // relationship selects
					 false, // to direction
					 true, // from direction
					 (short) 1, // recursion level
					 DomainConstants.EMPTY_STRING, // object where clause
					 DomainConstants.EMPTY_STRING, // relationship where clause
					 0);
			 strListRelSelects.add("attribute["+ATTRIBUTE_CURRENTBILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
			 MapList mapListCurrentBillTechnicalDeductions = domObjItem.getRelatedObjects(context, // matrix context
					 RELATIONSHIP_ITEM_TECHNICALDEDUCTION, // relationship pattern
					 TYPE_TECHNICAL_DEDUCTION, // type pattern
					 strListBusSelects, // object selects
					 strListRelSelects, // relationship selects
					 false, // to direction
					 true, // from direction
					 (short) 1, // recursion level
					 strBusWhere, // object where clause
					 DomainConstants.EMPTY_STRING, // relationship where clause
					 0);
			 
			 Iterator<Map<String,String>> iterator = mapListTechnicalDeductions.iterator();
			 Map<String,String> mapData;
			 while(iterator.hasNext())
			 {
				 mapData = iterator.next();
				 String strAmount = mapData.get("attribute["+ATTRIBUTE_TECHNICAL_DEDUCTION_AMOUNT+"]");
				 double doubleAmount = WMSUtil_mxJPO.convertToDouble(strAmount);
				 doubleDeductionAmount+=doubleAmount;
				 
				 String strReleaseImport = mapData.get("attribute["+ATTRIBUTE_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
				 doubleAmount = WMSUtil_mxJPO.convertToDouble(strReleaseImport);
				 doubleDeductionReleaseAmount+=doubleAmount;
			 }
			 iterator = mapListCurrentBillTechnicalDeductions.iterator();
			 while(iterator.hasNext())
			 {
				 mapData = iterator.next();
				 String strAmount = mapData.get("attribute["+ATTRIBUTE_TECHNICAL_DEDUCTION_AMOUNT+"]");
				 double doubleAmount = WMSUtil_mxJPO.convertToDouble(strAmount);
				 doubleCurrentBillDeductionAmount+=doubleAmount;
			 }
			 mapTDAmount.put("UptoDateDeductionAmount", new Double(doubleDeductionAmount));
			 mapTDAmount.put("CurrentBillDeductionAmount", new Double(doubleCurrentBillDeductionAmount));
			 mapTDAmount.put("UptoDateDeductionReleaseAmount", new Double(doubleDeductionReleaseAmount));
			 mapTDAmount.put("CurrentBillDeductionReleaseAmount", new Double(doubleCurrentBillDeductionReleaseAmount));
		 }
		return mapTDAmount;
	}

	private boolean addTechnicalDeductionRow(XWPFTable tbl, Map<String, Double> mapTDAmount ,int intIndex) {
		boolean booleanRowAdded = false;
		Double doubleUptoDateDeductionAmount = mapTDAmount.get("UptoDateDeductionAmount");
		 Double doubleCurrentBillDeductionAmount = mapTDAmount.get("CurrentBillDeductionAmount");
		 Double doubleZERO = new Double(0d);
		 if(doubleCurrentBillDeductionAmount.compareTo(doubleZERO)>0 || doubleUptoDateDeductionAmount.compareTo(doubleZERO)>0)
		 {
			 booleanRowAdded = true;
		     String strDeductionAmount = "0";
		     String strCurrentBillDeductionAmount = "0";
		     
			 strDeductionAmount = new BigDecimal(doubleUptoDateDeductionAmount).toPlainString();
			 strCurrentBillDeductionAmount = new BigDecimal(doubleCurrentBillDeductionAmount).toPlainString();
			 //strDeductionAmount
			 //strCurrentBillDeductionAmount
			 intIndex++;
			XWPFTableRow    xWPFTableRowTDRow     = tbl.insertNewTableRow(intIndex);
			 for (int j = 0; j < 7; j++) {
				 {
					 xWPFTableRowTDRow.createCell();
				 }
			 }
			 setColoredText(strDeductionAmount, xWPFTableRowTDRow, 4, "FF0000");
			 setColoredText(strCurrentBillDeductionAmount, xWPFTableRowTDRow, 5, "FF0000");
			 xWPFTableRowTDRow.getCell(6).setText("Amount includes all Technical Deductions considered till date");
		 }
		 return booleanRowAdded;
	}

	private boolean addTechnicalDeductionReleaseRow(XWPFTable tbl, Map<String, Double> mapTDAmount,int  intIndex) {
		Double doubleZERO = new Double(0d);
		boolean booleanRowAdded = false;
		 Double doubleUptoDateDeductionReleaseAmount = mapTDAmount.get("UptoDateDeductionReleaseAmount");
		 Double doubleCurrentBillDeductionReleaseAmount = mapTDAmount.get("CurrentBillDeductionReleaseAmount");
		 if(doubleUptoDateDeductionReleaseAmount.compareTo(doubleZERO)>0 || doubleCurrentBillDeductionReleaseAmount.compareTo(doubleZERO)>0)
		 {
			 booleanRowAdded = true;
		     String strDeductionReleaseAmount = "0";
		     String strCurrentBillDeductionReleaseAmount = "0";
			 strDeductionReleaseAmount = new BigDecimal(doubleUptoDateDeductionReleaseAmount).toPlainString();
			 strCurrentBillDeductionReleaseAmount = new BigDecimal(doubleCurrentBillDeductionReleaseAmount).toPlainString();
			 
			 intIndex++;
				XWPFTableRow    xWPFTableRowTDRow     = tbl.insertNewTableRow(intIndex);
			 for (int j = 0; j < 7; j++) {
				 {
					 xWPFTableRowTDRow.createCell();
				 }
			 }
			 setColoredText(strDeductionReleaseAmount, xWPFTableRowTDRow, 4, "00FF00");
			 setColoredText(strCurrentBillDeductionReleaseAmount, xWPFTableRowTDRow, 5, "00FF00");
			 xWPFTableRowTDRow.getCell(6).setText("Amount includes all payment releases against past Technical Deductions considered till date");
		 }
		 return booleanRowAdded;
	}

	public static void deleteTable( XWPFDocument document, int iTableIndex ) {
        try {
			XWPFTable table = document.getTables().get(iTableIndex);
            int bodyElement = document.getPosOfTable(table);
            document.removeBodyElement( bodyElement );
        } catch ( Exception e ) {
        }
    }

	
	 public String getLastBilLDatails(Context  context , DomainObject domABSMB )
    {
        String strReturn = DomainConstants.EMPTY_STRING;
        try {
            
                String strCurrentSeq    = domABSMB.getAttributeValue(context, DomainConstants.ATTRIBUTE_SEQUENCE_ORDER);
                Integer iCurrentSeq        = Integer.parseInt(strCurrentSeq);
                iCurrentSeq--;

                String strWorkOrder     = domABSMB.getInfo(context , "to[WMSWOAbstractMBE].from.id");
                DomainObject domWOOrder = DomainObject.newInstance(context , strWorkOrder);                    
                StringList strListBusSelects  = new StringList(1);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                StringList strListRelSelects  = new StringList(2);
                strListRelSelects.add(DomainRelationship.SELECT_ID);
                strListBusSelects.add("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"].value");
                MapList mapListABSMBEs           = domWOOrder.getRelatedObjects(context, // matrix context
                                                                                RELATIONSHIP_WORKORDER_ABSTRACT_MBE, // relationship pattern
                                                                                TYPE_ABSTRACT_MBE, // type pattern
                                                                                strListBusSelects, // object selects
                                                                                strListRelSelects, // relationship selects
                                                                                false, // to direction
                                                                                true, // from direction
                                                                                (short) 1, // recursion level
                                                                                "attribute["+DomainConstants.ATTRIBUTE_SEQUENCE_ORDER+"]=="+iCurrentSeq, // object where clause
                                                                                DomainConstants.EMPTY_STRING, // relationship where clause
                                                                                0);
                String strFinalids    = DomainConstants.EMPTY_STRING;
                for (Object dataobject : mapListABSMBEs) {
                    strReturn     = (String) ((Map)dataobject).get(DomainConstants.SELECT_ID);
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return strReturn;
    }
	
	  public Map getABSinfoForLastTable(Context context , DomainObject domABSMB , Boolean isLastBill , String stABSID)
    {
        Map returnMap   = new HashMap();
        try {
            StringList slBusSelect     = new StringList();


            if(isLastBill)
            {
                slBusSelect.add("attribute[WMSTotalCost].value");
            }

            //TODO use single DB call
            
            
            Double dSumTechnicalDeduction     = getTechnicalDeductionAmount(context , 
            		RELATIONSHIP_ABSMBE_TECHNICALDEDUCTION ,
                    domABSMB ,
                    "attribute["+ATTRIBUTE_TECHNICAL_DEDUCTION_AMOUNT+"]");
            Double dSumTechnicalDeductionReleaseAmount     = getTechnicalDeductionAmount(context , 
            		RELATIONSHIP_ABSMBE_TECHNICALDEDUCTION_RELEASE ,
                    domABSMB ,
                    "attribute["+ATTRIBUTE_CURRENTBILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
            Double dSumReductionRelease     = getReductionItem(context , 
                                                                "WMSBillReductionRelease" ,
                                                                domABSMB ,
                                                                "attribute[WMSReductionReleaseAmount].value");
            Double dSumReductionAmount      = getReductionItem(context ,
                                                                "WMSBillReduction" ,
                                                                domABSMB ,
                                                                "attribute[WMSBillReductionAmount].value");    
            returnMap = (Map) domABSMB.getInfo(context , slBusSelect);
                        
            /*Double dSumSecuredAdvancePaid      = getAdvanceItem(context ,
                                                                "WMSAMBAdvanceRecovery" , 
                                                                "attribute[WMSTypeofAdvance].value==Secured", 
                                                                domABSMB ,
                                                                "attribute[WMSAdvanceAmount].value");*/
                                                                
            String strWOrkOrderID = domABSMB.getInfo(context, "to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
            Double dSumSecuredAdvancePaid              =  getSecuredAdvancePaid( context , strWOrkOrderID ,  isLastBill , stABSID ); 
            Double dSumSecuredRecovery                 =  getSecuredRecoveryPaid( context , strWOrkOrderID ,  isLastBill , stABSID );
            DecimalFormat decimalFormat = new DecimalFormat("##.##");
            
            dSumSecuredAdvancePaid = Double.parseDouble(decimalFormat.format(dSumSecuredAdvancePaid));
            dSumSecuredRecovery = Double.parseDouble(decimalFormat.format(dSumSecuredRecovery));
                                                                
            Double dSumPlantAndMachinaryAdvancePaid    = getAdvanceItem(context , 
                                                                "WMSAMBAdvanceRecovery" , 
                                                                "attribute[WMSTypeofAdvance].value=='Plant and Machinary' ", 
                                                                domABSMB ,
                                                                "attribute[WMSAdvanceAmount].value");
            Double dSumMobilizationAdvancePaid    = getAdvanceItem(context , 
                                                                "WMSAMBAdvanceRecovery" , 
                    "attribute[WMSTypeofAdvance].value=='Mobilization'", 
                                                                domABSMB ,
                                                                "attribute[WMSAdvanceAmount].value");    
            Double dSumMiscellaneousAdvancePaid    = getAdvanceItem(context , 
													                    "WMSAMBAdvanceRecovery" , 
													                    "attribute[WMSTypeofAdvance].value=='Miscellaneous' ", 
													                    domABSMB ,
													                    "attribute[WMSAdvanceAmount].value");
            /*Double dSumSecuredRecovery         = getAdvanceItem(context ,
                                                            "WMSAMBRecovery" ,
                                                            "attribute[WMSTypeofAdvance].value==Secured",
                                                            domABSMB ,
                                                            "attribute[WMSRecoveryAmount].value");*/    
            Double dSumPlantAndMachinaryAdvanceRecovery     = getAdvanceItem(context ,
                                                            "WMSAMBRecovery" ,
                                                            "attribute[WMSTypeofAdvance].value=='Plant and Machinary' ", 
                                                            domABSMB ,
                                                            "attribute[WMSRecoveryAmount].value");
            Double dSumMobilizationAdvanceRecovery     = getAdvanceItem(context ,
                                                            "WMSAMBRecovery" ,
                    "attribute[WMSTypeofAdvance].value=='Mobilization'", 
                                                            domABSMB ,
                                                            "attribute[WMSRecoveryAmount].value");
            Double dSumMiscellaneousAdvanceRecovery     = getAdvanceItem(context ,
										                    "WMSAMBRecovery" ,
										                    "attribute[WMSTypeofAdvance].value=='Miscellaneous'", 
										                    domABSMB ,
										                    "attribute[WMSRecoveryAmount].value");
            HashMap<String,String> hashMapAdvancesAttribute = new HashMap<String,String>(10);
            hashMapAdvancesAttribute.put(ATTRIBUTE_PLANT_AND_MACHINERY_ADVANCE_REVOVERED, new BigDecimal(dSumPlantAndMachinaryAdvanceRecovery).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            hashMapAdvancesAttribute.put(ATTRIBUTE_MOBILISTION_ADVANCE_REVOVERED, new BigDecimal(dSumMobilizationAdvanceRecovery).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            hashMapAdvancesAttribute.put(ATTRIBUTE_SECURED_ADVANCE_REVOVERED, new BigDecimal(dSumSecuredRecovery).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            hashMapAdvancesAttribute.put(ATTRIBUTE_PLANT_AND_MACHINERY_ADVANCE_PAID, new BigDecimal(dSumPlantAndMachinaryAdvancePaid).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            hashMapAdvancesAttribute.put(ATTRIBUTE_MOBILISTION_ADVANCE_PAID, new BigDecimal(dSumMobilizationAdvancePaid).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            hashMapAdvancesAttribute.put(ATTRIBUTE_SECURED_ADVANCE_PAID, new BigDecimal(dSumSecuredAdvancePaid).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            hashMapAdvancesAttribute.put(ATTRIBUTE_WITHHELD_RELEASE_AMOUNT, new BigDecimal(dSumReductionRelease).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            hashMapAdvancesAttribute.put(ATTRIBUTE_WITHHELD_AMOUNT, new BigDecimal(dSumReductionAmount).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            hashMapAdvancesAttribute.put(ATTRIBUTE_ABS_MBE_TECHNICALDEDUCTION_AMOUNT, new BigDecimal(dSumTechnicalDeduction).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            hashMapAdvancesAttribute.put(ATTRIBUTE_ABS_MBE_TECHNICALDEDUCTION_RELEASE_AMOUNT, new BigDecimal(dSumTechnicalDeductionReleaseAmount).setScale(2, BigDecimal.ROUND_UP).toPlainString());
            try
			{
            	ContextUtil.pushContext(context, PERSON_USER_AGENT,DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
            domABSMB.setAttributeValues(context, hashMapAdvancesAttribute);
			}
			catch(Exception exception)
			{
			}
			finally
			{
				ContextUtil.popContext(context);
			}
            returnMap.put("dSumReductionRelease", dSumReductionRelease);
            returnMap.put("dSumReductionAmount", dSumReductionAmount);
            returnMap.put("dSumSecuredAdvancePaid" , dSumSecuredAdvancePaid);
            returnMap.put("dSumPlantAndMoAdvancePaid" , Double.valueOf(dSumPlantAndMachinaryAdvancePaid.doubleValue() + dSumMobilizationAdvancePaid.doubleValue()) + dSumMiscellaneousAdvancePaid );
            returnMap.put("dSumPlantandMoRecovery" ,Double.valueOf(dSumPlantAndMachinaryAdvanceRecovery.doubleValue() + dSumMobilizationAdvanceRecovery.doubleValue()) + dSumMiscellaneousAdvanceRecovery);
            returnMap.put("dSumSecuredRecovery" , dSumSecuredRecovery);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnMap;
    }
	
	
	public Double  getTechnicalDeductionAmount(Context  context , String strRel ,DomainObject domABSMB, String strCalc )    
    {
        Double bReturn    =0.0;
    
        try {
			StringList strListBusSelects     = new StringList(2);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add("attribute["+ATTRIBUTE_TECHNICAL_DEDUCTION_AMOUNT+"]");
			StringList strListRelSelects     = new StringList(2);
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			strListRelSelects.add("attribute["+ATTRIBUTE_CURRENTBILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
            
            MapList mlReductionItem = domABSMB.getRelatedObjects(context, // matrix context
                                                                    strRel, // relationship pattern
                                                                    TYPE_TECHNICAL_DEDUCTION, // type pattern
                                                                    strListBusSelects, // object selects
                                                                    strListRelSelects , // relationship selects
                                                                    false, // to direction
                                                                    true, // from direction
                                                                    (short) 1, // recursion level
                                                                    DomainConstants.EMPTY_STRING, // object where clause
                                                                    DomainConstants.EMPTY_STRING, // relationship where clause
                                                                    0);
            ArrayList<Double> alCalc= new ArrayList<Double>();
            Map object=null;
            for (Iterator iterator = mlReductionItem.iterator(); iterator.hasNext();) {
                 object = (Map) iterator.next();
                 String strValue = (String )object.get(strCalc);
                 double doubleValue = WMSUtil_mxJPO.convertToDouble(strValue);
                alCalc.add( new Double(doubleValue));
            }
            bReturn     =    listTotal(alCalc);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bReturn;
    }
	
	 public Double  getReductionItem(Context  context , String strRel ,DomainObject domABSMB, String strCalc )    
    {
        MapList mlReturnList    = new MapList();
        Double bReturn          = 0.0;
        try {
            StringList slBusSelect     =     new StringList();
            slBusSelect.add(DomainConstants.SELECT_NAME);
            slBusSelect.add(DomainConstants.SELECT_ID);
            slBusSelect.add("attribute[WMSSBillReductionAmount].value");
            slBusSelect.add("attribute[WMSSBillReductionReleaseAmountTillDate].value");
            
            
            StringList slRelSelect = new StringList();
            slRelSelect.add(DomainRelationship.SELECT_ID);        
            slRelSelect.add("attribute[WMSSReductionReleaseAmount].value");

            
            MapList mlReductionItem = domABSMB.getRelatedObjects(context, // matrix context
                                                                    strRel, // relationship pattern
                                                                    "WMSSBillReductionItem", // type pattern
                                                                    slBusSelect, // object selects
                                                                    slRelSelect , // relationship selects
                                                                    false, // to direction
                                                                    true, // from direction
                                                                    (short) 1, // recursion level
                                                                    DomainConstants.EMPTY_STRING, // object where clause
                                                                    DomainConstants.EMPTY_STRING, // relationship where clause
                                                                    0);
            
            ArrayList<Double> alCalc = new ArrayList<Double>();
            Map object               = null;
            for (Iterator iterator = mlReductionItem.iterator(); iterator.hasNext();) {
                 object = (Map) iterator.next();
                alCalc.add( Double.parseDouble((String )object.get(strCalc)));
            }
            bReturn     =    listTotal(alCalc);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bReturn;
    }
 
	 public Double getAdvanceItem(Context  context , String strRel , String strType , DomainObject domABSMB, String strCalc )    
    {
        MapList mlReturnList     =    new MapList();
        Double bReturn = 0.0;
        try {
                StringList slBusSelect     =     new StringList();
                slBusSelect.add(DomainConstants.SELECT_NAME);
                slBusSelect.add(DomainConstants.SELECT_ID);
                slBusSelect.add("attribute[WMSAdvanceAmount].value");
                
                StringList slRelSelect = new StringList();
                slRelSelect.add(DomainRelationship.SELECT_ID);
                slRelSelect.add("attribute[WMSRecoveryAmount].value");
                MapList mlReductionItem = domABSMB.getRelatedObjects(context, // matrix context
                                                                        strRel, // relationship pattern
                                                                        "WMSAdvanceRecoveryItem", // type pattern
                                                                        slBusSelect, // object selects
                                                                        slRelSelect , // relationship selects
                                                                        false, // to direction
                                                                        true, // from direction
                                                                        (short) 1, // recursion level
                                                                        strType, // object where clause
                                                                        DomainConstants.EMPTY_STRING, // relationship where clause
                                                                        0);
                
                ArrayList<Double> alCalc= new ArrayList<Double>();
                Map object=null;
                for (Iterator iterator = mlReductionItem.iterator(); iterator.hasNext();) {
                     object = (Map) iterator.next();
                    alCalc.add( Double.parseDouble((String )object.get(strCalc)));
                }
                bReturn     =    listTotal(alCalc);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bReturn;
    }

	public Double  getSecuredAdvancePaid( Context context ,String  strWOrkOrderID ,  Boolean isLastBill ,  String strABSID ) throws Exception
   {
       Double bReturnValue =    0.0;
       try {
           String strWhere              = DomainConstants.EMPTY_STRING;
           if(null != strWOrkOrderID && !"".equals(strWOrkOrderID) && !"null".equals(strWOrkOrderID))
           {
               DomainObject domWorkOrder    = DomainObject.newInstance(context , strWOrkOrderID);

               StringList slBusSelect       = new StringList(2);
               slBusSelect.add(DomainConstants.SELECT_ID);
               slBusSelect.add("attribute["+ATTR_REDUCED_RATE_FOR_ADVANCE+"]");
               slBusSelect.add("to["+REL_ABS_STOCK+"|from.id=="+strABSID+"]");
               slBusSelect.add("to["+REL_ABS_STOCK+"|from.id=="+strABSID+"].attribute["+ATTR_SECURED_ADVANCE_TEMP+"]");
               

               StringList slRelSelect       =     new StringList();
               slRelSelect.add(DomainRelationship.SELECT_ID);
              
               Pattern patternType          = new Pattern(TYPE_ABSTRACT_MBE);
               patternType.addPattern(TYPE_STOCK_ENTRIES);
               
               Pattern patternRel           = new Pattern(RELATIONSHIP_WORKORDER_ABSTRACT_MBE);
               patternRel.addPattern(REL_ABS_STOCK);
 
               if(isLastBill)
               {
                   strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+TYPE_ABSTRACT_MBE+"' && id!="+strABSID+" ) || ("+DomainConstants.SELECT_TYPE+"=="+TYPE_STOCK_ENTRIES+")";
               }
               else
               {
                   strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+TYPE_ABSTRACT_MBE+"' && id=="+strABSID+" ) || ("+DomainConstants.SELECT_TYPE+"=="+TYPE_STOCK_ENTRIES+")";
               }
               MapList mlStockList         = domWorkOrder.getRelatedObjects(context, // matrix context
                                                                   patternRel.getPattern(),               // relationship pattern
                                                                   patternType.getPattern(),                     // object pattern
                                                                   true,                                            // to direction
                                                                   true,                                            // from direction
                                                                   (short)2,                                     // recursion level
                                                                   slBusSelect,                          // object selects
                                                                   slRelSelect,                             // relationship selects
                                                                   strWhere,                                // object where clause
                                                                   DomainConstants.EMPTY_STRING,             // relationship where clause
                                                                   (short)0,                                  // No expand limit
                                                                   DomainConstants.EMPTY_STRING,             // postRelPattern
                                                                   TYPE_STOCK_ENTRIES,                            // postTypePattern
                                                                   null);
               Map dataMap  =   null;
               String strAdavnceAmount  =   DomainConstants.EMPTY_STRING;
               ArrayList<Double>    alAmountList    =   new ArrayList<Double>();
               for (int i = 0; i < mlStockList.size(); i++) {
                   dataMap  = (Map)  mlStockList.get(i);
                   if(isLastBill)
                   {
                       strAdavnceAmount =(String) dataMap.get("attribute["+ATTR_REDUCED_RATE_FOR_ADVANCE+"]");
                   }
                   else
                   {
                       strAdavnceAmount =(String) dataMap.get("to["+REL_ABS_STOCK+"].attribute["+ATTR_SECURED_ADVANCE_TEMP+"]");
                       if("".equals(strAdavnceAmount) || "".equals(strAdavnceAmount) || "null".equals(strAdavnceAmount))
                       {
                           strAdavnceAmount="0.0";
                       }
    
                   }
                   alAmountList.add(Double.parseDouble(strAdavnceAmount));
               }
               Double   returnValue     =   listTotal(alAmountList);
               bReturnValue =   returnValue;
           }
        } catch (Exception e) {
            e.printStackTrace();
        }
       return bReturnValue;
   }
	
	
	 public Double  getSecuredRecoveryPaid( Context context ,String  strWOrkOrderID ,  Boolean isLastBill ,  String strABSID ) throws Exception
   {
       Double bReturnValue  =    0.0;
       try {
           String strWhere              = DomainConstants.EMPTY_STRING;
           if(null != strWOrkOrderID && !"".equals(strWOrkOrderID) && !"null".equals(strWOrkOrderID))
           {
               DomainObject domWorkOrder    = DomainObject.newInstance(context , strWOrkOrderID);
               
               StringList slBusSelect       = new StringList(2);
               slBusSelect.add(DomainConstants.SELECT_ID);
               slBusSelect.add("to["+REL_ABS_STOCK+"|from.id=="+strABSID+"]");
               slBusSelect.add("to["+REL_ABS_STOCK+"|from.id=="+strABSID+"].attribute["+ATTR_SECURED_ADVANCE_TEMP+"]");
               slBusSelect.add("attribute["+ATTR_STOCK_RECOVERY_AMOUNT+"]");
               slBusSelect.add("attribute["+ATTR_REDUCED_RATE_FOR_ADVANCE+"]");

               StringList slRelSelect       =     new StringList();
               slRelSelect.add(DomainRelationship.SELECT_ID);
               slRelSelect.add("attribute["+ATTR_RECOVERY_AMOUNT+"]");

              
               Pattern patternType          = new Pattern(TYPE_ABSTRACT_MBE);
               patternType.addPattern(TYPE_MATERIAL_CONSUMPTION);
               patternType.addPattern(TYPE_STOCK_ENTRIES);
               
               Pattern patternRel           = new Pattern(RELATIONSHIP_WORKORDER_ABSTRACT_MBE);
               patternRel.addPattern(REL_MATERIAL_CONSUMPTION_TO_AMB);
               patternRel.addPattern(REL_MATERIALCONSUMPTION_TO_STOCK);
 
               if(isLastBill)
               {
                   strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+TYPE_ABSTRACT_MBE+"' && id!="+strABSID+" ) ||  ("+DomainConstants.SELECT_TYPE+"=="+TYPE_MATERIAL_CONSUMPTION+")  || ("+DomainConstants.SELECT_TYPE+"=="+TYPE_STOCK_ENTRIES+")";
               }
               else
               {
                   strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+TYPE_ABSTRACT_MBE+"' && id=="+strABSID+" ) ||  ("+DomainConstants.SELECT_TYPE+"=="+TYPE_MATERIAL_CONSUMPTION+")  || ("+DomainConstants.SELECT_TYPE+"=="+TYPE_STOCK_ENTRIES+")";
               }
               MapList mlStockList         = domWorkOrder.getRelatedObjects(context, // matrix context
                                                                           patternRel.getPattern(),// relationship pattern
                                                                           patternType.getPattern(), // object pattern
                                                                           true,// to direction
                                                                           true, // from direction
                                                                           (short)3,// recursion level
                                                                           slBusSelect, // object selects
                                                                           slRelSelect,// relationship selects
                                                                           strWhere,// object where clause
                                                                           DomainConstants.EMPTY_STRING,// relationship where clause
                                                                           (short)0,// No expand limit
                                                                           DomainConstants.EMPTY_STRING,// postRelPattern
                                                                           TYPE_STOCK_ENTRIES,// postTypePattern
                                                                           null);
																		   
			  
			    if(isLastBill)
				{
				   MapList mlFinalList  = new MapList();
				   Map dataMap1			= null;
				   ArrayList alIdList 	= new ArrayList();
				   String strIds		= "";
				   
				   for (int i = 0; i < mlStockList.size(); i++) {
					   dataMap1   = (Map)  mlStockList.get(i);
					   strIds	  =	(String)dataMap1.get("id");
					   if(!alIdList.contains(strIds))
					   {
						   alIdList.add(strIds);
						   mlFinalList.add(dataMap1);
					   }
				   }
				   
				   mlStockList	=	new MapList();
				   mlStockList.addAll(mlFinalList);				  
				   
				}
			  
			   
			   
			  

               Map dataMap  =   null;
               String strRecoveryAmount             = DomainConstants.EMPTY_STRING;
               ArrayList<Double>    alAmountList    = new ArrayList<Double>();
               String strStockAdvRate               = DomainConstants.EMPTY_STRING;
               String strStockAdvRateTemp           = DomainConstants.EMPTY_STRING;
               for (int i = 0; i < mlStockList.size(); i++) {
                   dataMap  = (Map)  mlStockList.get(i);
                  if(isLastBill)
                  {
                       strRecoveryAmount =(String) dataMap.get("attribute["+ATTR_STOCK_RECOVERY_AMOUNT+"]");
                       alAmountList.add(Double.parseDouble(strRecoveryAmount));
                  }
                  else
                  {
                      strStockAdvRate               = (String) dataMap.get("attribute["+ATTR_REDUCED_RATE_FOR_ADVANCE+"]");                    
                      strStockAdvRateTemp           = (String) dataMap.get("to["+REL_ABS_STOCK+"].attribute["+ATTR_SECURED_ADVANCE_TEMP+"]");
                      strRecoveryAmount             = (String) dataMap.get("attribute["+ATTR_RECOVERY_AMOUNT+"]");

                      if(strStockAdvRateTemp==null || "".equals(strStockAdvRateTemp) || "null".equals(strStockAdvRateTemp))
                      {
                          strStockAdvRateTemp="0.0";
                      }
                      Double dStockAdvRate          = Double.parseDouble(strStockAdvRate);
                      Double dStockAdvRateTemp      = Double.parseDouble(strStockAdvRateTemp);   
                      if(dStockAdvRate>0 || dStockAdvRateTemp>0)
                      {
                          alAmountList.add(Double.parseDouble(strRecoveryAmount));
                      }
                  }
               }
               Double returnValue     =   listTotal(alAmountList);
               bReturnValue =   returnValue;
           }
        } catch (Exception e) {
            e.printStackTrace();
        }
       return bReturnValue;
   }
   
    public Map getABSinfoForLastTableFromWO(Context context , DomainObject domABSMB , Boolean isLastBill , String strCurrentABSId)
    {
        Map returnMap   = new HashMap();
        try {
        	
        		StringList slBusSelect     = new StringList();
        		slBusSelect.add("attribute[WMSTotalCost].value");
        		returnMap 	= (Map) domABSMB.getInfo(context , slBusSelect);
        		
	            String strWOrkOrderID = domABSMB.getInfo(context, "relationship["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
	            domABSMB.setId(strWOrkOrderID); 

            	
	            HashMap mapAdvanceDetails	=	getAdvanceDetailsFromWorkOrder(context , domABSMB  , isLastBill,  strCurrentABSId );
	            
	             
	            
	            returnMap.putAll(mapAdvanceDetails);									
	            //-------
            	/*Double dSumSecuredAdvancePaid      		= getAdvanceItem(context ,
													                     "WMSWorkOrderAdvances" , 
													                     "attribute[WMSTypeofAdvance].value==Secured", 
													                     domABSMB ,
													                     "attribute[WMSAdvanceAmount].value");  
             
            	Double dSumSecuredRecovery         		= getAdvanceItem(context ,
													                     "WMSWorkOrderAdvances" ,
													                     "attribute[WMSTypeofAdvance].value==Secured",
													                     domABSMB ,
													                     "attribute[WMSRecoveryAmount].value");              
            
            	Double dSumPlantAndMoAdvancePaid    	= getAdvanceItem(context , 
													                     "WMSWorkOrderAdvances" , 
													                     "attribute[WMSTypeofAdvance].value=='Mobilization' || attribute[WMSTypeofAdvance].value=='Plant and Machinary' ", 
													                     domABSMB ,
													                     "attribute[WMSAdvanceAmount].value");    

            	Double dSumPlantandMoRecovery     		= getAdvanceItem(context ,
														                 "WMSWorkOrderAdvances" ,
														                 "attribute[WMSTypeofAdvance].value=='Mobilization' || attribute[WMSTypeofAdvance].value=='Plant and Machinary' ", 
														                 domABSMB ,
														                 "attribute[WMSRecoveryAmount].value");*/
            	
            	
            //----------------	

            	Double dSumReductionAmount      		= getReductionItem(context ,
			                                                                "WMSWorkOrderReduction" ,
			                                                                domABSMB ,
			                                                                "attribute[WMSBillReductionAmount].value");  
            	
            	Double dSumReductionRelease     		= getReductionItem(context , 
														                    "WMSWorkOrderReduction" ,
														                    domABSMB ,
														                    "attribute[WMSBillReductionReleaseAmountTillDate].value");
           
	            
	            returnMap.put("dSumReductionRelease", dSumReductionRelease);
	            returnMap.put("dSumReductionAmount", dSumReductionAmount);
	            //returnMap.put("dSumSecuredAdvancePaid" , dSumSecuredAdvancePaid);
	            //returnMap.put("dSumPlantAndMoAdvancePaid" , dSumPlantAndMoAdvancePaid);
	            //returnMap.put("dSumSecuredRecovery" , dSumSecuredRecovery);
	            //returnMap.put("dSumPlantandMoRecovery" ,dSumPlantandMoRecovery);
	           

        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnMap;
    }
   
    public HashMap getAdvanceDetailsFromWorkOrder(Context  context ,DomainObject domABSMB , Boolean isLastBill ,  String strCurrentABSID)    
    {
        MapList mlReturnList    = new MapList();
        Double bReturn 			= 0.0;
        HashMap reteurnMap 		= new HashMap();
        try {
                StringList slBusSelect     =     new StringList();
                slBusSelect.add(DomainConstants.SELECT_NAME);
                slBusSelect.add(DomainConstants.SELECT_ID);
                slBusSelect.add("attribute[WMSAdvanceAmount].value");
                slBusSelect.add("attribute[WMSRecoveryAmount].value");
                slBusSelect.add("attribute[WMSTypeofAdvance].value");

                StringList slRelSelect = new StringList();
                slRelSelect.add(DomainRelationship.SELECT_ID);
                
                MapList mlReductionItem = domABSMB.getRelatedObjects(context, // matrix context
                                                                        "WMSWorkOrderAdvances", // relationship pattern
                                                                        "WMSAdvanceRecoveryItem", // type pattern
                                                                        slBusSelect, // object selects
                                                                        slRelSelect , // relationship selects
                                                                        false, // to direction
                                                                        true, // from direction
                                                                        (short) 1, // recursion level
                                                                        DomainConstants.EMPTY_STRING, // object where clause
                                                                        DomainConstants.EMPTY_STRING, // relationship where clause
                                                                        0);
                
                ArrayList<Double> alSumSecuredAdvancePaid	 = new ArrayList<Double>();
                ArrayList<Double> alSumSecuredRecovery		 = new ArrayList<Double>();
                ArrayList<Double> alSumMobilizationPaid		 = new ArrayList<Double>();
                ArrayList<Double> alSumMobilizationRecovery	 = new ArrayList<Double>();
                ArrayList<Double> alSumPlantAndMoAdvancePaid = new ArrayList<Double>();
                ArrayList<Double> alSumPlantandMoRecovery	 = new ArrayList<Double>();
                ArrayList<Double> alSumMiscellaneousAdvancePaid	 = new ArrayList<Double>();
                ArrayList<Double> alSumMiscellaneousRecovery		 = new ArrayList<Double>();
                
                String strType 	= DomainConstants.EMPTY_STRING;
                Map object      = null;
                for (Iterator iterator = mlReductionItem.iterator(); iterator.hasNext();) 
                {
                     object     = (Map) iterator.next();
                     strType    = (String) object.get("attribute[WMSTypeofAdvance].value");
                     if("Secured".equals(strType))
                     {
                    	 //alSumSecuredAdvancePaid.add( Double.parseDouble((String )object.get("attribute[WMSAdvanceAmount].value")));
                    	 //alSumSecuredRecovery.add( Double.parseDouble((String )object.get("attribute[WMSRecoveryAmount].value")));
                     }
                     else if("Mobilization".equals(strType))
                     {
                    	 alSumMobilizationPaid.add( Double.parseDouble((String )object.get("attribute[WMSAdvanceAmount].value")));
                    	 alSumMobilizationRecovery.add( Double.parseDouble((String )object.get("attribute[WMSRecoveryAmount].value")));
                     }                     
                     else if("Miscellaneous".equals(strType))
                     {
                    	 alSumMiscellaneousAdvancePaid.add( Double.parseDouble((String )object.get("attribute[WMSAdvanceAmount].value")));
                    	 alSumMiscellaneousRecovery.add( Double.parseDouble((String )object.get("attribute[WMSRecoveryAmount].value")));
                     } 
                     else
                     {
                    	 alSumPlantAndMoAdvancePaid.add( Double.parseDouble((String )object.get("attribute[WMSAdvanceAmount].value")));
                    	 alSumPlantandMoRecovery.add( Double.parseDouble((String )object.get("attribute[WMSRecoveryAmount].value"))); 
                     }
                }
                
                    
                double doubleSecuredAdvancePaid     = listTotal(alSumSecuredAdvancePaid);
                double doubleSecuredRecovery        = listTotal(alSumSecuredRecovery);
                double doubleMobilizationPaid       = listTotal(alSumMobilizationPaid);
                double doubleMobilizationRecovery   = listTotal(alSumMobilizationRecovery);
                double doublePlantMachineryPaid     = listTotal(alSumPlantAndMoAdvancePaid);
                double doublePlantMachineryRecovery = listTotal(alSumPlantandMoRecovery);
               
                double dSumMiscellaneousAdvancePaid     = listTotal(alSumMiscellaneousAdvancePaid);
                double dSumMiscellaneousRecovery = listTotal(alSumMiscellaneousRecovery);
                //reteurnMap.put("dSumSecuredAdvancePaid"			, doubleSecuredAdvancePaid);
                //reteurnMap.put("dSumSecuredRecovery"			, doubleSecuredRecovery);
                
                Double dSumSecuredAdvancePaid   =  getSecuredAdvancePaid( context , domABSMB.getInfo(context, DomainConstants.SELECT_ID) ,  isLastBill , strCurrentABSID ); 
                Double dSumSecuredRecovery      =  getSecuredRecoveryPaid( context , domABSMB.getInfo(context, DomainConstants.SELECT_ID) ,  isLastBill , strCurrentABSID );
               
                DecimalFormat decimalFormat     = new DecimalFormat("##.##");
                dSumSecuredAdvancePaid          = Double.parseDouble(decimalFormat.format(dSumSecuredAdvancePaid));
                dSumSecuredRecovery             = Double.parseDouble(decimalFormat.format(dSumSecuredRecovery));

                reteurnMap.put("dSumSecuredAdvancePaid"         , dSumSecuredAdvancePaid);
                reteurnMap.put("dSumSecuredRecovery"            , dSumSecuredRecovery);
                reteurnMap.put("dSumPlantAndMoAdvancePaid"		, (doubleMobilizationPaid+doublePlantMachineryPaid+dSumMiscellaneousAdvancePaid));
                reteurnMap.put("dSumPlantandMoRecovery"			,  (doubleMobilizationRecovery+doublePlantMachineryRecovery+dSumMiscellaneousRecovery));  
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reteurnMap;
    }

	 public String CreateFinalTables(Context context ,DomainObject domABSMB,   XWPFDocument document, Double bTotal  , Map mapCurrentABSInfo , Map mapPreABSInfo , String strPrevAbsId , int iTableIndex)
    {
        String strReturn = DomainConstants.EMPTY_STRING;
        try {
            XWPFTable tbl              = document.getTables().get(iTableIndex);
            ArrayList<Double> alTotal  = new ArrayList<Double> ();
            Double d1thRow	 = bTotal ;//((Double)mapCurrentABSInfo.get("dSumPlantAndMoAdvancePaid"));
            Double d2thRow	 = ((Double)mapPreABSInfo.get("dSumSecuredAdvancePaid"));
            Double d3thRow	 = ((Double)mapPreABSInfo.get("dSumSecuredRecovery"));
            Double d4thRow	 = ((Double)mapCurrentABSInfo.get("dSumSecuredAdvancePaid"));
            Double d5thRow	 = ((Double)mapCurrentABSInfo.get("dSumSecuredRecovery"));
            Double d6thRow	 = ((Double)mapPreABSInfo.get("dSumPlantAndMoAdvancePaid"));
            Double d7thRow	 = ((Double)mapPreABSInfo.get("dSumPlantandMoRecovery"));
            Double d8thRow	 = ((Double)mapCurrentABSInfo.get("dSumPlantAndMoAdvancePaid"));
            Double d9thRow   = (Double)mapCurrentABSInfo.get("dSumPlantandMoRecovery");
           
         
            //Total (1+2-3+4-5+6-7+8-9)
            Double d10RowTotal				 = d1thRow + d2thRow - d3thRow +  d4thRow - d5thRow+ d6thRow -  d7thRow + d8thRow - d9thRow;
            Double d11thRow                  = (Double) mapPreABSInfo.get("dSumReductionAmount");    
            Double d12thRow                  = (Double) mapPreABSInfo.get("dSumReductionRelease");
            Double d13thRow                  = (Double) mapCurrentABSInfo.get("dSumReductionAmount");
            Double d14thRow                  = (Double) mapCurrentABSInfo.get("dSumReductionRelease");

            //(10 -11 + 12 - 13 + 14)
            Double d15RowTotal              = d10RowTotal - d11thRow +  d12thRow -d13thRow  +d14thRow ;

            try
            {
                ContextUtil.pushContext(context, PERSON_USER_AGENT,DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);

            domABSMB.setAttributeValue(context, "WMSTotalCost", ""+d15RowTotal);
            }
    		catch(Exception e)
    		{
    			e.printStackTrace();
    			throw e;
    		}
            finally
            {
                    ContextUtil.popContext(context);
            }
           
            double d16RowTotal      = Double.parseDouble((String)mapPreABSInfo.get("attribute[WMSTotalCost].value"));
            double d17RowTotal      = d15RowTotal -  d16RowTotal;

            XWPFTable itemTable     = tbl.getRow(18).getCell(1).getTables().get(0);
            Double d18RowTotal      = createItemTable(context  , itemTable ,domABSMB );
            Double d19RowTotal      = d17RowTotal	-	d18RowTotal;

            tbl.getRow(1).getCell(2).setText(""+round(bTotal) );
            tbl.getRow(2).getCell(2).setText(""+round(d2thRow));
            tbl.getRow(3).getCell(2).setText(""+round(d3thRow));
            tbl.getRow(4).getCell(2).setText(""+round(d4thRow));
            tbl.getRow(5).getCell(2).setText(""+round(d5thRow));
            tbl.getRow(6).getCell(2).setText(""+round(d6thRow));
            tbl.getRow(7).getCell(2).setText(""+round(d7thRow));
            tbl.getRow(8).getCell(2).setText(""+round(d8thRow));
            tbl.getRow(9).getCell(2).setText(""+round(d9thRow));
            tbl.getRow(10).getCell(2).setText(""+round(d10RowTotal));
            tbl.getRow(11).getCell(2).setText(""+round(d11thRow));
            tbl.getRow(12).getCell(2).setText(""+round(d12thRow));
            tbl.getRow(13).getCell(2).setText(""+round(d13thRow));
            tbl.getRow(14).getCell(2).setText(""+round(d14thRow));
            tbl.getRow(15).getCell(2).setText(""+round(d15RowTotal));
            tbl.getRow(16).getCell(2).setText(""+round(d16RowTotal));
            tbl.getRow(17).getCell(2).setText(""+round(d17RowTotal));
            tbl.getRow(18).getCell(2).setText(""+round(d18RowTotal));
            tbl.getRow(19).getCell(2).setText(""+round(d19RowTotal));
	            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  strReturn;
	}
	
	 public Double createItemTable(Context context  , XWPFTable itemTable ,DomainObject domABSMB )throws Exception
    {
    	Double dReturn 	=	0.0;
    	try {
	    		StringList strListBusSelects = new StringList();
	            strListBusSelects.add(DomainConstants.SELECT_ID);
	            strListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
	            strListBusSelects.add("attribute[WMSHeadDeductionSequence].value");

	            StringList strListRelSelects = new StringList();
	            strListRelSelects.add(DomainRelationship.SELECT_ID);
	            strListRelSelects.add("attribute["+ATTRIBUTE_HEAD_OTHER_DEDUCTION_DESCRIPTION+"]");
	            strListRelSelects.add("attribute["+ATTRIBUTE_HEAD_OTHER_DEDUCTION_AMOUNT+"]");
	            
	            
	            
	    		MapList mlOtherDi = domABSMB.getRelatedObjects(context, // matrix context
											                     RELATIONSHIP_HEAD_DEDUCTION, // relationship pattern
											                     TYPE_OTER_HEAD_DEDUCTION, // type pattern
											                     strListBusSelects, // object selects
											                     strListRelSelects, // relationship selects
											                     false, // to direction
											                     true, // from direction
											                     (short) 0, // recursion level
											                     DomainConstants.EMPTY_STRING, // object where clause
											                     DomainConstants.EMPTY_STRING, // relationship where clause
											                     0);
	    		
	    		
	    		
	    		mlOtherDi.sort("attribute[WMSHeadDeductionSequence].value" , "descending",  "integer");
	    		
	    		ArrayList<Double> alAllMount 	=	 new ArrayList<Double>();
	    		double doubleOtherDeduction = 0d;
	    		Map dataMap 			= null;
	    		String strAmount 		= DomainConstants.EMPTY_STRING;
	    		String strDescrition 	= DomainConstants.EMPTY_STRING;
	    		for (int i = 0; i < mlOtherDi.size(); i++) {
	    			dataMap		=	(Map) mlOtherDi.get(i);
	    			strAmount	=	(String ) dataMap.get("attribute[WMSHeadDeductionAmount]");
	    			double doubleAmount = WMSUtil_mxJPO.convertToDouble(strAmount);
	    			doubleOtherDeduction+=doubleAmount;
	    			alAllMount.add(Double.parseDouble(strAmount));
	    			
					strDescrition	=	(String ) dataMap.get("attribute[WMSHeadDeductionDescription]");
	    			XWPFTableRow    row     = itemTable.insertNewTableRow(i+1);
	    			row.createCell().setText( strDescrition );
	    			//row.createCell().setText( df.format(Double.parseDouble(strAmount)) );
	    			row.createCell().setText( ""+round(Double.parseDouble(strAmount)) );
				}
	    		ContextUtil.pushContext(context, PERSON_USER_AGENT,DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
				domABSMB.setAttributeValue(context, ATTRIBUTE_OTHERDEDUCTION_AMOUNT, new BigDecimal(doubleOtherDeduction).toPlainString());
    		 dReturn =	 listTotal(alAllMount);
    		 
		} catch (Exception e) {
			e.printStackTrace();
		}
    	finally
    	{
				ContextUtil.popContext(context);
    	}
    	return dReturn;
    }
	
	 public double listTotal(ArrayList<Double> alDouble)
    {
        double sum = 0;
        for(int i = 0; i < alDouble.size(); i++)
        {
            sum += alDouble.get(i);
        }
        return sum;
    }
	
	
	private int round(double d){
	   
	    double dAbs = Math.abs(d);
	    int i = (int) dAbs;
	    int iReturn    =    0;
	    double result = dAbs - (double) i;
	    if(result<0.5){
	        iReturn= d<0 ? -i : i;            
	    }else{
	        iReturn= d<0 ? -(i+1) : i+1;          
	    }
	   
	    return iReturn;
	}
	
	private void setColoredText(String strDeductionAmount, XWPFTableRow xWPFTableRowTDRow, int intCellIndex,String strColor) {

		XWPFTableCell xWPFTableCell = xWPFTableRowTDRow.getCell(intCellIndex);
		 xWPFTableCell.removeParagraph(0);
		 XWPFParagraph addParagraph = xWPFTableCell.addParagraph();
		 XWPFRun run = addParagraph.createRun();
		/* run.setFontFamily("Calibri");
		 run.setFontSize(10);*/
		 run.setColor(strColor);
        DecimalFormat decimalFormat = new DecimalFormat("##.##");
        Double dValue               = Double.parseDouble(decimalFormat.format(Double.parseDouble(strDeductionAmount)));
        strDeductionAmount          =   ""+dValue;
		 run.setText(strDeductionAmount);
	}
	
	
	public MapList getSORItem(Boolean isSOR , MapList mlDataList)
	{
		MapList mlReturnList = new MapList();
		try {
			
			Map dataMap = null;
			String strValue = DomainConstants.EMPTY_STRING;
			String strCheck = isSOR ? "True" : "False";
		
			for (int i = 0; i < mlDataList.size(); i++) {
				dataMap	=	(Map) mlDataList.get(i);
				strValue	=	(String) dataMap.get("from["+RELATIONSHIP_TASK_SOR+"].to.to[WMSWorkOrderSOR]") ;
				if(strCheck.equals(strValue))
				{
					mlReturnList.add(dataMap);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mlReturnList;
	}
	
	public Boolean replaceVauleInTable (XWPFTable tbl ,String srtKey , String stValue)
     {
         Boolean  bReturn =false;
         try {
             for (XWPFTableRow row : tbl.getRows()) {
                  for (XWPFTableCell cell : row.getTableCells()) {
                     for (XWPFParagraph p : cell.getParagraphs()) {
                        for (XWPFRun r : p.getRuns()) {
                          String text = r.getText(0);
                          if (text != null && text.contains(srtKey)) {
                              text = text.replace(srtKey, stValue);
                              r.setText(text,0);
                              bReturn=true;  
                              break;
                        }
                     }
                  }
               }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bReturn;
     }
	
	
	private  String NumberToWord (String number)throws Exception
    {
        String twodigitword="";
        String word="";
        String[] HTLC = {"", "Hundred", "Thousand", "Lakh", "Crore"}; //H-hundread , T-Thousand, ..
        int split[]={0,2, 3, 5, 7,9};
        String[] temp=new String[split.length];
        boolean addzero=true;
        int len1=number.length();
        if (len1>split[split.length-1]) {
            throw new Exception();
        }
        for (int l=1 ; l<split.length; l++ )
        if (number.length()==split[l] ) addzero=false;
        if (addzero==true) number="0"+number;
        int len=number.length();
        int j=0;
        //spliting & putting numbers in temp array.
        while (split[j]<len)
        {
            int beg=len-split[j+1];
            int end=beg+split[j+1]-split[j];
            temp[j]=number.substring(beg , end);
            j=j+1;
        }
     
        for (int k=0;k<j;k++)
        {
            twodigitword=ConvertOnesTwos(temp[k]);
            if (k>=1){
            if (twodigitword.trim().length()!=0) word=twodigitword+" " +HTLC[k] +" "+word;
            }
            else word=twodigitword ;
        }
       return (word);
    }

	
	private  String ConvertOnesTwos(String t)
    {
        final String[] ones ={"", "One", "Two", "Three", "Four", "Five","Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve","Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"};
        final String[] tens = {"", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty","Ninety"};
        String word="";
        int num=Integer.parseInt(t);
        if (num%10==0) word=tens[num/10]+" "+word ;
        else if (num<20) word=ones[num]+" "+word ;
        else
        {
            word=tens[(num-(num%10))/10]+word ;
            word=word+" "+ones[num%10] ;
        }
        return word;
    }
	
	
	}