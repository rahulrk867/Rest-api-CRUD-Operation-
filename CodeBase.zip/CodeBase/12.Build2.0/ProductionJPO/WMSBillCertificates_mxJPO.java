/**
 *  WMSBillCertificates.java
 *
 * (c) Dassault Systemes, 1993 - 2017. All rights reserved.
 * This program contains proprietary and trade secret information of
 * ENOVIA MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
 import java.util.HashMap;
 import java.util.Map;
 import java.text.SimpleDateFormat;
 import java.util.Vector;
 import java.util.Iterator;
 import java.text.DecimalFormat;
 import java.util.ArrayList;
 
 import matrix.db.Context;
 import matrix.db.JPO;
 import matrix.util.StringList;
 import java.math.BigDecimal;
 import java.util.Locale;
 import java.util.Date;
 
 import com.matrixone.jdom.Element;
 import matrix.util.MatrixException;
 import com.matrixone.apps.program.ProgramCentralUtil;
 import com.matrixone.apps.domain.util.ContextUtil;
 import com.matrixone.apps.domain.util.FrameworkException;
 import com.matrixone.apps.domain.util.EnoviaResourceBundle;
 import com.matrixone.apps.domain.util.MqlUtil;
 import com.matrixone.apps.domain.util.MapList;
 import com.matrixone.apps.domain.DomainRelationship;
 import com.matrixone.apps.domain.DomainConstants;
 import com.matrixone.apps.domain.DomainObject;
 import com.matrixone.apps.framework.ui.UITableIndented;
 import com.matrixone.apps.domain.util.eMatrixDateFormat;
 import com.matrixone.apps.domain.util.FrameworkUtil;
 import com.matrixone.apps.framework.ui.UIUtil;
 import com.matrixone.apps.program.ProgramCentralConstants;
 import com.matrixone.apps.domain.util.PersonUtil;
 
 /**
 * This JPO includes the code related to the Approval History Functionality
 */
public class WMSBillCertificates_mxJPO extends WMSConstants_mxJPO
{

 /**
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments
     * @throws Exception if the operation fails
     * @grade 0
     */
    public WMSBillCertificates_mxJPO (Context context, String[] args) throws Exception
    {
		super(context,args);
    }
  /**
     * Method is used to populate the data for Royalty Charges page
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args The packed argument for JPO, containing the program map.
     *             This program map will have request parameter information, objectId and information about the UI table object.
     * @return MapList of data
     * @throws Exception
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getAllBillCertificates(Context context, String[] args) throws Exception {
		MapList mlBillCertificates = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");

			DomainObject dObject = DomainObject.newInstance(context,sParentOID);
			String strType = dObject.getInfo(context,DomainConstants.SELECT_TYPE);
			
			
            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add(DomainObject.SELECT_OWNER);
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
                mlBillCertificates = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_BILL_CERTIFICATES,
															TYPE_WMS_BILL_CERTIFICATES,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		
		Map mTemp = null;
		String strOwner = DomainConstants.EMPTY_STRING;
		for(int i=0;i<mlBillCertificates.size();i++){
			mTemp = (Map)mlBillCertificates.get(i);
			strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
			
			if(context.getUser().equals(strOwner) == false){
				mTemp.put("RowEditable", "readonly");
				mTemp.put("disableSelection", "true");
			}
			
		}
		
		
		
		return mlBillCertificates;
	}
	
 
 /**
     * To create a SOR Library
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds the following input arguments
     *      0 - requestMap
     * @return Map contains created objectId
     * @throws Exception
     */
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public HashMap createBillCertificate(Context context, String [] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Map paramMap = (Map) programMap.get("paramMap");
		String sObjectId=(String)paramMap.get("objectId");

		String sRowId = "" ;
		String strNewObject = "";

		HashMap columnsMap;
		HashMap changedRowMap;
		HashMap doc = new HashMap();
		HashMap retMap;
		DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
		DomainObject doAdvancObject = DomainObject.newInstance(context);

		Element elm = (Element) programMap.get("contextData");        
		MapList mlItems = new MapList();
		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		Map mapAttr = new HashMap();     

		for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
		{
			try
			{   
				retMap = new HashMap();
				changedRowMap = (HashMap) chgRowsMapList.get(i);
				columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");

				String strDesc = (String) columnsMap.get("Desc");

				strNewObject = FrameworkUtil.autoName(context,
                        "type_WMSBillCertificates",
                        null,
                        "policy_WMSBillCertificates",
                        null,
                        null,
                        true,
                        true);
				DomainRelationship domRel   = doAdvancObject.createAndConnect(context,
						TYPE_WMS_BILL_CERTIFICATES,
						strNewObject,
						"-",
					   POLICY_WMS_BILL_CERTIFICATES,
						null,
						RELATIONSHIP_WMS_BILL_CERTIFICATES,
						domAmbObject,
						true);

				mapAttr = new HashMap();

				if (strDesc != null && !"".equals(strDesc)) {
					doAdvancObject.setDescription(context,strDesc);
				}
				doAdvancObject.setAttributeValues(context,mapAttr);
				retMap = new HashMap();
				retMap.put("oid", doAdvancObject.getObjectId(context));
				retMap.put("relid", domRel.toString());
				retMap.put("pid", "");
				retMap.put("rid", "");
				retMap.put("markup", "new");
				retMap.put("rowId", sRowId);
				columnsMap.putAll(retMap);
				retMap.put("columns", columnsMap);
				mlItems.add(retMap);
				doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
				doc.put("Action", "success"); // Here the action can be "Success" or "refresh"
			}
			catch(Exception Ex)
			{
				Ex.printStackTrace();
				throw Ex;
			}
		}
		return doc;
	}
@com.matrixone.apps.framework.ui.ProgramCallable
	     public MapList getCertificateTemplate(Context context,String[] args) throws Exception
    {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);    
		String strParentId = (String) programMap.get("parentId");	
		StringList slWOConnectedList  = new StringList();
		if(UIUtil.isNotNullAndNotEmpty(strParentId)){
			DomainObject doParent = new DomainObject(strParentId);
			String strType = (String)doParent.getInfo(context,DomainObject.SELECT_TYPE);
			if(TYPE_WMS_WORK_ORDER.equals(strType)){
				slWOConnectedList = doParent.getInfoList(context,"from["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"].to.id");
			}
		}
		
		String  strObjId          = (String) programMap.get("objectId");	
        MapList mapListObjects = new MapList();
        StringList selListBusSelects     = new StringList();
        selListBusSelects.add(DomainConstants.SELECT_ID);
        selListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
        selListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
        StringList relListSelects = new StringList();
					relListSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
        if(UIUtil.isNotNullAndNotEmpty(strObjId)){
            DomainObject domObj = DomainObject.newInstance(context, strObjId); 
			mapListObjects = domObj.getRelatedObjects(context, // matrix context
                		  RELATIONSHIP_WMS_CERTIFICATE_CLASSIFICATION_TEMPLATE, // relationship pattern
                          TYPE_WMS_CERTIFICATE_TEMPLATE, // type pattern
                          selListBusSelects, // object selects
                          relListSelects, // relationship selects
                          false, // to direction
                          true, // from direction
                          (short) 1, // recursion level
                          DomainConstants.EMPTY_STRING, // object where clause
                          DomainConstants.EMPTY_STRING, // relationship where clause
                          0);
						  
			Map mTemp = null;
			String strId = DomainConstants.EMPTY_STRING;
			for(int i=0;i<mapListObjects.size();i++){
				mTemp = (Map)mapListObjects.get(i);
				strId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(slWOConnectedList.contains(strId)){
					mTemp.put("disableSelection", "true");					
				}
			}		
						  
		}															
        return mapListObjects;
    }
	@com.matrixone.apps.framework.ui.ProgramCallable
     public  MapList getCertificateClassificationObjects(Context context, String []  args)    throws Exception {
         MapList mlReturnList     =     new MapList();
         try
         {
             String strVault = context.getVault().getName();
             StringList strListBusInfo = new StringList(2);
             strListBusInfo.add(DomainConstants.SELECT_ID);
             strListBusInfo.add(DomainConstants.SELECT_DESCRIPTION);
             strListBusInfo.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
             String strWhere =  DomainConstants.EMPTY_STRING; 
             mlReturnList =  DomainObject.findObjects(
                                             context,
                                             TYPE_WMS_CERTIFICATE_CLASSIFICATION,
                                             DomainConstants.QUERY_WILDCARD,
                                             DomainConstants.QUERY_WILDCARD,
                                             DomainConstants.QUERY_WILDCARD,
                                             strVault,
                                             strWhere,               // where expression
                                             DomainConstants.EMPTY_STRING,
                                             false,
                                             strListBusInfo, // object selects
                                             (short) 0);       // limit
											 
			//Map mTemp = null;
			//for(int i=0;i<mlReturnList.size();i++){
			//	mTemp = (Map)mlReturnList.get(i);
			//	mTemp.put("disableSelection", "true");
			//}					 
			
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
         return mlReturnList;
     }
	//
 public Map<String,String> addCertificateTemplate (Context context, String[] args) throws Exception 
     {
         try
         {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
             Map<String,String> mapObject = new HashMap<String, String>();
                  
             if(emxTableRowId !=null && emxTableRowId.length>0)
             {
                 ArrayList<String> arrayListRelOIDs = getSelectedActivities(context, emxTableRowId);                               
                 String strItemOID = emxTableRowId[0];
                 
                 String strItemMBERelOID = DomainConstants.EMPTY_STRING;
                 if(!arrayListRelOIDs.isEmpty())
                 {
                     strItemMBERelOID = arrayListRelOIDs.get(0);
                 }
                 if(UIUtil.isNotNullAndNotEmpty(strItemOID))
                 {
                     DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
                     StringList strListInfoSelects = new StringList(3);
                     strListInfoSelects.add(DomainConstants.SELECT_TYPE);
                     strListInfoSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
                     Map<String,String> mapInfo = domObjItem.getInfo(context, strListInfoSelects);
                     String strName = mapInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
                     String strType = mapInfo.get(DomainConstants.SELECT_TYPE);
                         int intSequence = getMeasurementSequence(context, strItemOID);
                         int intMeasurementToAdd =0;
                             intMeasurementToAdd = getNumberOfMeasurements(programMap);

                         StringBuffer strBuffer = new StringBuffer();
                         strBuffer.append("<mxRoot>");
                         strBuffer.append("<action><![CDATA[add]]></action>");
                         for(int i=0;i<intMeasurementToAdd;i++)
                         {
                             String strMeasurementOID = FrameworkUtil.autoName(context,
                                     "type_WMSCertificateTemplate",
                                     "policy_WMSCertificate");
                             String strMQLCommand = "connect bus "+strItemOID+" rel "+RELATIONSHIP_WMS_CERTIFICATE_CLASSIFICATION_TEMPLATE+" to "+strMeasurementOID;
                             MqlUtil.mqlCommand(context, strMQLCommand);
                             DomainObject domObjMeasurement = DomainObject.newInstance(context, strMeasurementOID);
                             String strMTitle = strName+" - "+intSequence;
                             domObjMeasurement.setAttributeValue(context,"Title",strMTitle);
                             String strRelOID = domObjMeasurement.getInfo(context, "relationship["+RELATIONSHIP_WMS_CERTIFICATE_CLASSIFICATION_TEMPLATE+"].id");

                             strBuffer.append("<data status=\"committed\">");
                             strBuffer.append("<item oid=\""+strMeasurementOID+"\" relId=\""+strRelOID+"\" pid=\""+strItemOID+"\"  direction=\"\" />");
                             strBuffer.append("</data>");
                             intSequence++;
                         }
                         Locale strLocale = context.getLocale();
                         String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.Create.Certificate.Alert");
                         strBuffer.append("</mxRoot>");
                         mapObject.put("selectedOID", strItemOID);
                         mapObject.put("rows",strBuffer.toString());
                         mapObject.put("message",strMessage);
                         mapObject.put("SOR_TYPE","SORItem");
                     
                 }
             }
             return mapObject;
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
	 private ArrayList<String> getSelectedActivities(Context context,
             String[] emxTableRowId) throws  FrameworkException ,MatrixException {
         try
         {
             ArrayList<String> arrrayListSelectedRelOIDS = new ArrayList<String>();
             ArrayList<String> arrayListRelOIDs = getRelationshipOIDs(emxTableRowId);
             emxTableRowId = ProgramCentralUtil.parseTableRowId(context, emxTableRowId);
             StringList strListInfo = getSelectedActivitiesInfo();
             MapList mapListInfo = DomainObject.getInfo(context, emxTableRowId, strListInfo);
             Iterator iterator = mapListInfo.iterator();
             int intCounter = 0;
             int intSize = mapListInfo.size();
             for(int i=0 ; i<intSize;i++ )
             {
                 Map<String,String> mapInfo = (Map<String,String>)iterator.next();
                 String strType = mapInfo.get(DomainConstants.SELECT_TYPE);
 				if(TYPE_WMS_CERTIFICATE_CLASSIFICATION.equals(strType))
                 {
                     arrrayListSelectedRelOIDS.add(arrayListRelOIDs.get(intCounter));
                 }
                 intCounter++;
             }
             return arrrayListSelectedRelOIDS;
         }
         catch(FrameworkException frameworkException)
         {
             frameworkException.printStackTrace();
             throw frameworkException;
         }
         catch(MatrixException matrixException)
         {
             matrixException.printStackTrace();
             throw matrixException;
         }

     }
	 private ArrayList<String> getRelationshipOIDs(String[] emxTableRowId) {
         ArrayList<String> arrayListRelOIDs = new ArrayList<String>();
         int intSize = emxTableRowId.length;
         for (int i = 0; i < intSize; i++)
         {
             String strRelOID = emxTableRowId[i].split("[|]")[0];

             arrayListRelOIDs.add(strRelOID);
         }
         return arrayListRelOIDs;
     }
	 private StringList getSelectedActivitiesInfo() {
         StringList strListInfo = new StringList(3);
         strListInfo.add(DomainConstants.SELECT_TYPE);
         strListInfo.add(DomainConstants.SELECT_ID);
         return strListInfo;
     }
	 private int getMeasurementSequence(Context context, String strItemOID) throws FrameworkException {
         StringList strListInfoSelectsRel=new StringList(2);
         strListInfoSelectsRel.add("from["+RELATIONSHIP_WMS_CERTIFICATE_CLASSIFICATION_TEMPLATE+"].to.id");
		 DomainObject dObject = DomainObject.newInstance(context,strItemOID);
         StringList strListObjOIDs = dObject.getInfoList(context, "from["+RELATIONSHIP_WMS_CERTIFICATE_CLASSIFICATION_TEMPLATE+"].to.id");
         StringList strlTitle=new StringList();
         int intSequence = strListObjOIDs.size();
         intSequence++;
         return intSequence;
     }
	 private int getNumberOfMeasurements(HashMap programMap) {
         String strMeasurementToAdd = (String)programMap.get("WMSMeasurementsToBeAdded");
         int intMeasurementToAdd = 0;
         if(UIUtil.isNotNullAndNotEmpty(strMeasurementToAdd))
         {
             try
             {
                 intMeasurementToAdd = Integer.parseInt(strMeasurementToAdd);
             }catch(NumberFormatException numberFormatException)
             {
                 intMeasurementToAdd = 1;
             }
         }
         return intMeasurementToAdd;
     }
     
     public HashMap getRoleRange(Context context, String[] args)
    throws Exception
    {
        HashMap mapReturnRoleRange = new HashMap();
        try
        {
            String sLanguage = context.getSession().getLanguage();
			StringList projectRoleList = new StringList();
			
			String strprojectRoleList  = EnoviaResourceBundle.getProperty(context,"WMS.Certificate.Roles");
			if(UIUtil.isNotNullAndNotEmpty(strprojectRoleList)){
				projectRoleList = FrameworkUtil.split(strprojectRoleList, ",");
			}
			mapReturnRoleRange.put("field_choices", projectRoleList);
			 mapReturnRoleRange.put("field_display_choices", projectRoleList);

        }
        catch (Exception e)
        {
            e.printStackTrace();
            throw e;
        }        
        return  mapReturnRoleRange;
    }
    public void updateResponsibleRoleForCertificate(Context context, String[] args) throws Exception
    {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
        Map mpParamMap = (HashMap)programMap.get("paramMap");
        String strNewVal = (String)mpParamMap.get("New Value");
        String RelId = (String)mpParamMap.get("relId");
        if (UIUtil.isNotNullAndNotEmpty(RelId))
        {   
            ContextUtil.pushContext(context);
            DomainRelationship Reldomain = new DomainRelationship(RelId);
           	Reldomain.setAttributeValue(context,ATTRIBUTE_WMS_RESPONSIBLE_ROLE,strNewVal);
            ContextUtil.popContext(context);
        }
    }
    /**
      * Method to get the disconnected Certificate template under the WorkOrder
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return String containing the message
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public String removeSelectedCertificateTemplate (Context context, String[] args) throws Exception 
     {
         try
         {
			 
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");

             String strMBEID = (String) programMap.get("objectId");
             String strItemOID = emxTableRowId[0].split("[|]")[1];
			 
			if(emxTableRowId !=null && emxTableRowId.length>0)
             {   
                 ArrayList<String> arrayListRelOIDs =new ArrayList<String>();
                 for(int y=0;y<emxTableRowId.length;y++){
                 String strRelOid = emxTableRowId[y].split("[|]")[0];		
                 arrayListRelOIDs.add(strRelOid);
                  }
                 WMSUtil_mxJPO.disconnect(context, arrayListRelOIDs);
                 return "Selected objects sucessfully removed";
             }                    
             return "Selected objects sucessfully removed";
         }catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
      /**
      * Method to get the disconnected Certificate template under the Certificate Classification
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return String containing the message
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
      public String removeSelectedCertificateTemplateFromClassification (Context context, String[] args) throws Exception 
     {
         try
         {
			 
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
             String strResult = "";
             String strMBEID = (String) programMap.get("objectId");
             String strItemOID = emxTableRowId[0].split("[|]")[1];	 
			if(emxTableRowId !=null && emxTableRowId.length>0)
             {   
                 ArrayList<String> arrayListRelOIDs =new ArrayList<String>();
                 ArrayList<String> arrayListObjectOIDs =new ArrayList<String>();
                 for(int y=0;y<emxTableRowId.length;y++){
                 String strRelOid = emxTableRowId[y].split("[|]")[0];
                 String strTemplateOid = emxTableRowId[y].split("[|]")[1];
                 DomainObject domObj = DomainObject.newInstance(context, strTemplateOid);
                 String strType = domObj.getInfo(context,DomainConstants.SELECT_TYPE);
                 String strIsConnected = "" ;
                 if(TYPE_WMS_CERTIFICATE_CLASSIFICATION.equals(strType))
                 {
                        strIsConnected = domObj.getInfo(context,"from["+RELATIONSHIP_WMS_CERTIFICATE_CLASSIFICATION_TEMPLATE+"]");
                      if("False".equals(strIsConnected))
                      {
                        domObj.delete(context);
                        strResult = "Selected objects sucessfully removed";
                      }
                      else
                      {
                         strResult = "Object has References. Hence cannot be deleted";                 
                      }
                 }
                 else
                 {
                      strIsConnected = domObj.getInfo(context,"to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"]"); 
                      if("False".equals(strIsConnected))
                      {
                           arrayListRelOIDs.add(strRelOid);
                           arrayListObjectOIDs.add(strRelOid);
                           strResult = "Selected objects sucessfully removed";
                      }
                      else
                      {
                        strResult = "Object has References. Hence cannot be deleted";
                      }
                  }
                 
                  }
                 WMSUtil_mxJPO.disconnect(context, arrayListRelOIDs);
				         deleteSelected(context, arrayListObjectOIDs);
                 return strResult;
             }                    
             return strResult;
         }catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
	 /**
	     * disconnects an arraylist of Temlate IDs
	     * 
	     * @param context the eMatrix <code>Context</code> object 
	     * @param arrayListClonedTCIds is array list containing Classified Item relationship IDs
	     * @throws FrameworkException - if the operation fails
	     * @author WMS
	     * @since R418
	     */
	    public static void deleteSelected(Context context, ArrayList<String>  arrayListObjectOIDs)

            throws Exception {

            try {
                  
                 int intSize = arrayListObjectOIDs.size();
                 
                 String [] strReqObjectIds = new String[intSize];
                 
				     ContextUtil.startTransaction(context, true);
                                                
				 if(intSize>0)
	            {
	                strReqObjectIds = arrayListObjectOIDs.toArray(new String[intSize]);
	            }
                for (int i = 0; i < strReqObjectIds.length; i++) {

                    String objId = strReqObjectIds[i];

                        DomainObject doTemplateId=new DomainObject(objId);

                        doTemplateId.delete(context);
                }

                ContextUtil.commitTransaction(context);

            }  catch (FrameworkException e) {
                    
					ContextUtil.abortTransaction(context);
					
                    e.printStackTrace();
                    
                    throw new Exception(e.getMessage());

                }

            }
            	
    @com.matrixone.apps.framework.ui.ProgramCallable
	     public MapList getConnectedWO(Context context,String[] args) throws Exception
    {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String  strObjId          = (String) programMap.get("objectId");
        MapList mapListObjects = new MapList();
        StringList selListBusSelects     = new StringList();
        selListBusSelects.add(DomainConstants.SELECT_ID);
        selListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
        selListBusSelects.add("attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"]");
        selListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
        StringList relListSelects = new StringList();
					relListSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
        if(UIUtil.isNotNullAndNotEmpty(strObjId)){
            DomainObject domObj = DomainObject.newInstance(context, strObjId); 
			mapListObjects = domObj.getRelatedObjects(context, // matrix context
                          RELATIONSHIP_WORKORDER_ABSTRACT_MBE, // relationship pattern
                          TYPE_WMS_WORK_ORDER, // type pattern
                          selListBusSelects, // object selects
                          relListSelects, // relationship selects
                          true, // to direction
                          false, // from direction
                          (short) 1, // recursion level
                          DomainConstants.EMPTY_STRING, // object where clause
                          DomainConstants.EMPTY_STRING, // relationship where clause
                          0);
						  
			Map mTemp = null;
			for(int i=0;i<mapListObjects.size();i++){
				mTemp = (Map)mapListObjects.get(i);
				mTemp.put("disableSelection", "true");
			}
		}															
        return mapListObjects;
    }
   @com.matrixone.apps.framework.ui.ProgramCallable
	     public MapList getTemplate(Context context,String[] args) throws Exception
    {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strContextUser = context.getUser();
		String userContextUserID = PersonUtil.getPersonObjectID(context, strContextUser);
		DomainObject doPerson = new DomainObject(userContextUserID);
		String strHostRole = doPerson.getAttributeValue(context,ATTRIBUTE_HOST_ROLE);
		
		String  strObjId          = (String) programMap.get("objectId");
		String  strParentId          = (String) programMap.get("parentId");
		
		if(UIUtil.isNotNullAndNotEmpty(strParentId)){
			DomainObject doBill = new DomainObject(strParentId);
			String strType = doBill.getInfo(context,DomainObject.SELECT_TYPE);
			if(TYPE_ABSTRACT_MBE.equals(strType) == false){
				strParentId          = (String) programMap.get("parentOID");
			}
		}
		
        MapList mapListObjects = new MapList();
		MapList mlFinalList = new MapList();
        StringList selListBusSelects     = new StringList();
        selListBusSelects.add(DomainConstants.SELECT_ID);
        selListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
        selListBusSelects.add("attribute["+ATTRIBUTE_WMS_IS_MANDATORY+"]");
        selListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
        StringList relListSelects = new StringList();
		relListSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
		relListSelects.add("attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"]");
        if(UIUtil.isNotNullAndNotEmpty(strObjId)){
			
			String strCompanyType = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+strContextUser+"'].from.to["+DomainRelationship.RELATIONSHIP_MEMBER+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_COMPANY+"].value dump");
			
			String strWhere = DomainConstants.EMPTY_STRING;
			
			if(UIUtil.isNotNullAndNotEmpty(strCompanyType)){
				if(strCompanyType.contains("Contractor")){
					String strCompanyId = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+strContextUser+"'].from.to["+DomainRelationship.RELATIONSHIP_MEMBER+"].from.id dump");
					String strContractCompanyId = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.id dump");
					if(strCompanyId.contains(strContractCompanyId)){
						if(UIUtil.isNullOrEmpty(strWhere))
							strWhere = "to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ *Contractor*";
						else
							strWhere = strWhere + " || " +"to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ *Contractor*";
						
					}
				}
				
				if(strCompanyType.contains("PMC")){
					String strCompanyId = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+strContextUser+"' && attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"] ~~ '*Quantity Surveyor*'].from.to["+DomainRelationship.RELATIONSHIP_MEMBER+"].from.id dump");
					String strPMCCompanyId = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WORKORDER_PMC_CONSULTANT+"].from.id dump");
					if(strCompanyId.contains(strPMCCompanyId)){
						if(UIUtil.isNullOrEmpty(strWhere))
							strWhere = "to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ *PMC*";
						else
							strWhere = strWhere + " || " +"to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ *PMC*";
					}
				}
				
				if(strCompanyType.contains("QA")){
					if(UIUtil.isNullOrEmpty(strWhere))
						strWhere = "to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ *QA*";
					else
						strWhere = strWhere + " || " +"to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ *QA*";
					
				}
				
				if(strCompanyType.contains("PgMC")){
					if(UIUtil.isNullOrEmpty(strWhere))
						strWhere = "to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ *PgMC*";
					else
						strWhere = strWhere + " || " +"to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ *PgMC*";
					
				}
				
				if(strCompanyType.contains("Host") || UIUtil.isNullOrEmpty(strCompanyType)){
					if(UIUtil.isNullOrEmpty(strWhere))
						strWhere = "to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ '*"+strHostRole+"*'";
					else
						strWhere = strWhere + " || " +"to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ '*"+strHostRole+"*'";
				}
			}else{
						strWhere = "to["+RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE+"|from.id=="+strObjId+"].attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value ~~ '*"+strHostRole+"*'";
			}
			
            DomainObject domObj = DomainObject.newInstance(context, strObjId); 
			mapListObjects = domObj.getRelatedObjects(context, // matrix context
                		  RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE, // relationship pattern
                          TYPE_WMS_CERTIFICATE_TEMPLATE, // type pattern
                          selListBusSelects, // object selects
                          relListSelects, // relationship selects
                          false, // to direction
                          true, // from direction
                          (short) 1, // recursion level
                          strWhere, // object where clause
                          DomainConstants.EMPTY_STRING, // relationship where clause
                          0);
						  
			Map mCertMap = null;
			for(int j=0;j<mapListObjects.size();j++){
				mCertMap = (Map)mapListObjects.get(j);
				String strCertId = (String)mCertMap.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strCertId)){
					String strMQLResult = MqlUtil.mqlCommand(context,"print bus "+strCertId+" select to["+RELATIONSHIP_WMS_AMB_CERTIFICATE_TEMPLATE+"|from.id=="+strParentId+" && attribute["+ATTRIBUTE_WMS_ADDED_BY+"]=='"+strContextUser+"'] dump");
					if("true".equalsIgnoreCase(strMQLResult)){
						mCertMap.put("disableSelection", "true");
					}
					
				}
				
			}
						  
						  
			if(strCompanyType.contains("Host") || UIUtil.isNullOrEmpty(strCompanyType)){
				Map mTemp = null;
				for(int i=0;i<mapListObjects.size();i++){
					mTemp = (Map)mapListObjects.get(i);
					String strResponsibleRole = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"]");
					if(UIUtil.isNotNullAndNotEmpty(strResponsibleRole)){
						StringList slResponsibleRoles = FrameworkUtil.split(strResponsibleRole,",");
						if(slResponsibleRoles.contains(strHostRole)){
							mlFinalList.add(mTemp);
						}
					}
					
				}
				return mlFinalList;
			}else{
				return mapListObjects;
			}
						  
		}															
        return mapListObjects;
    
	}
	
	public void updateCertificateDetails(Context context,String[] args)throws Exception{
		boolean isContextPushed = false;
		try{
			String strRelId = args[0];
			if(UIUtil.isNotNullAndNotEmpty(strRelId)){
				Date dToday = new Date();
				long lToday = dToday.getTime();
				SimpleDateFormat mxDateFrmt = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
				String strFormattedDate = mxDateFrmt.format(lToday);
				
				Map mRelAttrMap = new HashMap();
				mRelAttrMap.put(ATTRIBUTE_WMS_ADDED_BY, context.getUser());
				mRelAttrMap.put(ATTRIBUTE_WMS_ADDED_ON, strFormattedDate);
				ContextUtil.pushContext(context);
				isContextPushed = true;
				DomainRelationship.setAttributeValues(context, strRelId, mRelAttrMap);

			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(isContextPushed)
				ContextUtil.popContext(context);

		}		
	}
	
	public int isCertificateAdded(Context context,String[] args)throws Exception{
		try{
			String strObjectId = args[0];
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				String strContextUser = context.getUser();
				DomainObject doBill = new DomainObject(strObjectId);
				String strWOId = (String)doBill.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				Map packArgs=new HashMap();		
				packArgs.put("objectId", strWOId); 
				
				MapList mlUserCertificates = getTemplate(context,JPO.packArgs(packArgs));
				
				StringList slMandatoryCertificates = new StringList();
				
				Map mTemp = null;
				String strId = DomainConstants.EMPTY_STRING;
				String strIsMandatory = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlUserCertificates.size();i++){
					mTemp = (Map)mlUserCertificates.get(i);
					strIsMandatory = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_IS_MANDATORY+"]");
					strId = (String)mTemp.get(DomainObject.SELECT_ID);
					if("Yes".equalsIgnoreCase(strIsMandatory)){
						slMandatoryCertificates.add(strId);
					}
				}
				
				String strCertificatesAdded = MqlUtil.mqlCommand(context,"print bus "+strObjectId+" select from["+RELATIONSHIP_WMS_AMB_CERTIFICATE_TEMPLATE+"|attribute["+ATTRIBUTE_WMS_ADDED_BY+"].value=='"+strContextUser+"'].to.id dump |");
				
				StringList slAddedCertificates = FrameworkUtil.split(strCertificatesAdded,"|");
				
				String strAddedCertificate = DomainConstants.EMPTY_STRING;
				for(int i=0;i<slMandatoryCertificates.size();i++){
					strAddedCertificate = (String)slMandatoryCertificates.get(i);
					if(slAddedCertificates.contains(strAddedCertificate) == false){
						String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.IncompleteCertificate");
						emxContextUtil_mxJPO.mqlNotice(context,strMessage);
						return 1;
					}
				}
				
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}

		return 0;
	}
	
	public String checkCertificateAdded(Context context,String[] args)throws Exception{
		String strReturnMessage = DomainConstants.EMPTY_STRING;
		try{
			
			String strObjectId = args[0];
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				String strMqlQuery = "print bus "+strObjectId+" select from["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|from.type=='"+TYPE_ABSTRACT_MBE+"'].from.id dump";
				String strAMBObjectId = MqlUtil.mqlCommand(context,strMqlQuery);
				if(UIUtil.isNotNullAndNotEmpty(strAMBObjectId)){
					String strContextUser = context.getUser();
					DomainObject doBill = new DomainObject(strAMBObjectId);
					String strWOId = (String)doBill.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
					Map packArgs=new HashMap();		
					packArgs.put("objectId", strWOId); 
					
					MapList mlUserCertificates = getTemplate(context,JPO.packArgs(packArgs));
					
					StringList slMandatoryCertificates = new StringList();
					
					Map mTemp = null;
					String strId = DomainConstants.EMPTY_STRING;
					String strIsMandatory = DomainConstants.EMPTY_STRING;
					for(int i=0;i<mlUserCertificates.size();i++){
						mTemp = (Map)mlUserCertificates.get(i);
						strIsMandatory = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_IS_MANDATORY+"]");
						strId = (String)mTemp.get(DomainObject.SELECT_ID);
						if("Yes".equalsIgnoreCase(strIsMandatory)){
							slMandatoryCertificates.add(strId);
						}
					}
					
					String strCertificatesAdded = MqlUtil.mqlCommand(context,"print bus "+strAMBObjectId+" select from["+RELATIONSHIP_WMS_AMB_CERTIFICATE_TEMPLATE+"|attribute["+ATTRIBUTE_WMS_ADDED_BY+"].value=='"+strContextUser+"'].to.id dump |");
					
					StringList slAddedCertificates = FrameworkUtil.split(strCertificatesAdded,"|");
					
					String strAddedCertificate = DomainConstants.EMPTY_STRING;
					
					for(int i=0;i<slMandatoryCertificates.size();i++){
						strAddedCertificate = (String)slMandatoryCertificates.get(i);
						if(strCertificatesAdded.contains(strAddedCertificate) == false){
							strReturnMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.IncompleteCertificate");
						}
					}
					
				}				
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}

		return strReturnMessage;
	}
	
	
	public MapList getCertifiatesConntected(Context context, String[] args)throws Exception{
		try{
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String  strObjId          = (String) programMap.get("objectId");
			MapList mapListObjects = new MapList();
			StringList selListBusSelects     = new StringList();
			selListBusSelects.add(DomainConstants.SELECT_ID);
			selListBusSelects.add(DomainObject.SELECT_DESCRIPTION);
			StringList relListSelects = new StringList();
			relListSelects.add(DomainObject.SELECT_RELATIONSHIP_ID);
			relListSelects.add("attribute["+ATTRIBUTE_WMS_ADDED_BY+"]");
			relListSelects.add("attribute["+ATTRIBUTE_WMS_ADDED_ON+"]");
			if(UIUtil.isNotNullAndNotEmpty(strObjId)){
				DomainObject domObj = DomainObject.newInstance(context, strObjId); 
				mapListObjects = domObj.getRelatedObjects(context, // matrix context
							  RELATIONSHIP_WMS_AMB_CERTIFICATE_TEMPLATE, // relationship pattern
							  TYPE_WMS_CERTIFICATE_TEMPLATE, // type pattern
							  selListBusSelects, // object selects
							  relListSelects, // relationship selects
							  false, // to direction
							  true, // from direction
							  (short) 1, // recursion level
							  DomainConstants.EMPTY_STRING, // object where clause
							  DomainConstants.EMPTY_STRING, // relationship where clause
							  0);
							  
			  mapListObjects.sort("attribute["+ATTRIBUTE_WMS_ADDED_ON+"]","ascending","date");
			}															
			return mapListObjects;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}		
	}

	public int checkCertificatesAddedWithRole(Context context,String[] args)throws Exception{
		try{
			String strObjectId = args[0];
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				StringList selListBusSelects = new StringList();
				selListBusSelects.add(DomainObject.SELECT_ID);
				selListBusSelects.add("attribute["+ATTRIBUTE_WMS_IS_MANDATORY+"].value");
				
				StringList relListSelects = new StringList();
				relListSelects.add(DomainRelationship.SELECT_ID);
				relListSelects.add("attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value");
				
				DomainObject domObj = DomainObject.newInstance(context, strObjectId); 
				MapList mapListObjects = domObj.getRelatedObjects(context, // matrix context
							  RELATIONSHIP_WMS_WORKORDER_CERTIFICATE_TEMPLATE, // relationship pattern
							  TYPE_WMS_CERTIFICATE_TEMPLATE, // type pattern
							  selListBusSelects, // object selects
							  relListSelects, // relationship selects
							  false, // to direction
							  true, // from direction
							  (short) 1, // recursion level
							  DomainConstants.EMPTY_STRING, // object where clause
							  DomainConstants.EMPTY_STRING, // relationship where clause
							  0);
				
				if(mapListObjects.size()==0){
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.WorkOrder.CertificateMissing");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
				Map mTemp = null;
				String strIsMandatory = DomainConstants.EMPTY_STRING;
				String strResponsibleRole = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mapListObjects.size();i++){
					mTemp = (Map)mapListObjects.get(i);
					strIsMandatory = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_IS_MANDATORY+"].value");
					strResponsibleRole = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_RESPONSIBLE_ROLE+"].value");
					if("Yes".equalsIgnoreCase(strIsMandatory) && UIUtil.isNullOrEmpty(strResponsibleRole)){
						String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.WorkOrder.CertificateMissing");
						emxContextUtil_mxJPO.mqlNotice(context,strMessage);
						return 1;
					}
				}
				
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}

		return 0;
	}
	
}