/**
 *  WMSBillOtherAdditions.java
 *
 * (c) Dassault Systemes, 1993 - 2017. All rights reserved.
 * This program contains proprietary and trade secret information of
 * ENOVIA MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
 import java.util.HashMap;
 import java.util.Map;
 import java.text.SimpleDateFormat;
 import java.util.Vector;
 import java.util.Iterator;
 import java.text.DecimalFormat;
 
 import matrix.db.Context;
 import matrix.db.JPO;
 import matrix.util.StringList;
 import java.math.BigDecimal;
 
 import com.matrixone.jdom.Element;
 import com.matrixone.apps.domain.util.MapList;
 import com.matrixone.apps.domain.DomainRelationship;
 import com.matrixone.apps.domain.DomainConstants;
 import com.matrixone.apps.domain.DomainObject;
 import com.matrixone.apps.framework.ui.UITableIndented;
 import com.matrixone.apps.domain.util.eMatrixDateFormat;
 import com.matrixone.apps.domain.util.FrameworkUtil;
 
 /**
 * This JPO includes the code related to the Approval History Functionality
 */
public class WMSBillOtherAdditions_mxJPO extends WMSConstants_mxJPO
{

 /**
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments
     * @throws Exception if the operation fails
     * @grade 0
     */
    public WMSBillOtherAdditions_mxJPO (Context context, String[] args) throws Exception
    {
		super(context,args);
    }
  /**
     * Method is used to populate the data for Royalty Charges page
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args The packed argument for JPO, containing the program map.
     *             This program map will have request parameter information, objectId and information about the UI table object.
     * @return MapList of data
     * @throws Exception
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getAllBillOtherAdditions(Context context, String[] args) throws Exception {
		MapList otherAdditions = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");

            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_BASE_RATE+"]");
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
                otherAdditions = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_BILL_OTHER_ADDITION,
															TYPE_WMS_BILL_OTHER_ADDITION,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return otherAdditions;
	}
	
 /**
     * To create a SOR Library
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds the following input arguments
     *      0 - requestMap
     * @return Map contains created objectId
     * @throws Exception
     */
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public HashMap createBillOtherAddition(Context context, String [] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Map paramMap = (Map) programMap.get("paramMap");
		String sObjectId=(String)paramMap.get("objectId");

		String sRowId = "" ;
		String strNewObject = "";

		HashMap columnsMap;
		HashMap changedRowMap;
		HashMap doc = new HashMap();
		HashMap retMap;
		DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
		DomainObject doAdvancObject = DomainObject.newInstance(context);

		Element elm = (Element) programMap.get("contextData");        
		MapList mlItems = new MapList();
		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		Map mapAttr = new HashMap();     

		for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
		{
			try
			{   
				retMap = new HashMap();
				changedRowMap = (HashMap) chgRowsMapList.get(i);
				columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");

				String strRate = (String) columnsMap.get("Rate");
				String strDesc = (String) columnsMap.get("Desc");

				strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
						"type_WMSBillOtherAddition",
						"",
						"policy_WMSBillOtherAddition",
						context.getVault().getName(),
						"-"
						);
				
				DomainRelationship domRel   = doAdvancObject.createAndConnect(context,
						TYPE_WMS_BILL_OTHER_ADDITION,
						strNewObject,
						"-",
					    POLICY_WMS_BILL_OTHER_ADDITION,
						null,
						RELATIONSHIP_WMS_BILL_OTHER_ADDITION,
						domAmbObject,
						true);

				mapAttr = new HashMap();
				if (strRate != null && !"".equals(strRate)) {
					mapAttr.put(ATTRIBUTE_WMS_BASE_RATE, strRate);
				}
				if (strDesc != null && !"".equals(strDesc)) {
					doAdvancObject.setDescription(context,strDesc);
				}
				doAdvancObject.setAttributeValues(context,mapAttr);
				retMap = new HashMap();
				retMap.put("oid", doAdvancObject.getObjectId(context));
				retMap.put("relid", domRel.toString());
				retMap.put("pid", "");
				retMap.put("rid", "");
				retMap.put("markup", "new");
				retMap.put("rowId", sRowId);
				columnsMap.putAll(retMap);
				retMap.put("columns", columnsMap);
				mlItems.add(retMap);
				doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
				doc.put("Action", "success"); // Here the action can be "Success" or "refresh"
			}
			catch(Exception Ex)
			{
				Ex.printStackTrace();
				throw Ex;
			}
		}
		return doc;
	}
	
}