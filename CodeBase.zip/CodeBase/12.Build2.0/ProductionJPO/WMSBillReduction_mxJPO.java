
/** Name of the JPO     : WMSBillReduction
 ** Developed by        : DSIS Team 
 ** Client              : WMS
 ** Description         : The purpose of this JPO is to create a Bill Reduction
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------
 ** DSIS                  28-March-2018                  Original Version
 ** -----------------------------------------------------------------
 **/

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import java.util.ArrayList;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.jdom.Element;

import matrix.db.AttributeItr;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.RelationshipType;
import matrix.util.StringList;

/**
 * The purpose of this JPO is to create a Measurement Book Entry.
 * 
 * @author WMS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSBillReduction_mxJPO {
    // Attributes
    public static final String SYMBOLIC_attribute_WMSBillReductionParticulars = "attribute_WMSBillReductionParticulars";
    public static final String SYMBOLIC_attribute_WMSBillReductionAmount = "attribute_WMSBillReductionAmount";
    public static final String SYMBOLIC_attribute_WMSBillReductionReleaseAmountTillDate = "attribute_WMSBillReductionReleaseAmountTillDate";
    public static final String SYMBOLIC_attribute_WMSBillReductionRemarks = "attribute_WMSBillReductionRemarks";
    public static final String SYMBOLIC_attribute_WMSReductionReleaseAmount = "attribute_WMSReductionReleaseAmount";
    public static final String SYMBOLIC_attribute_WMSReductionReleaseAmountTillPrevious = "attribute_WMSReductionReleaseAmountTillPrevious";
    public static final String SYMBOLIC_attribute_WMSReductionReleaseRemarks = "attribute_WMSReductionReleaseRemarks";
    public static final String SYMBOLIC_attribute_WMSBillWithheldItemType = "attribute_WMSBillWithheldItemType";
    public static final String SYMBOLIC_attribute_WMSAbstractMBEWithHeldAmount = "attribute_WMSAbstractMBEWithHeldAmount";
    public static final String SYMBOLIC_attribute_WMSAbstractMBEWithHeldReleasedAmount = "attribute_WMSAbstractMBEWithHeldReleasedAmount";
    public static final String SYMBOLIC_attribute_WMSSReductionReleaseAmount = "attribute_WMSReductionReleaseAmount";


    public static final String ATTRIBUTE_REDUCTION_PARTICULARS = PropertyUtil
            .getSchemaProperty(SYMBOLIC_attribute_WMSBillReductionParticulars);
    public static final String ATTRIBUTE_REDUCTION_AMOUNT = PropertyUtil
            .getSchemaProperty(SYMBOLIC_attribute_WMSBillReductionAmount);
    public static final String ATTRIBUTE_REDUCTION_RELEASE_AMOUNT_TILL_DATE = PropertyUtil
            .getSchemaProperty(SYMBOLIC_attribute_WMSBillReductionReleaseAmountTillDate);
    public static final String ATTRIBUTE_REDUCTION_REMARKS = PropertyUtil
            .getSchemaProperty(SYMBOLIC_attribute_WMSBillReductionRemarks);
    public static final String ATTRIBUTE_REDUCTION_RELEASE_AMOUNT = PropertyUtil
            .getSchemaProperty(SYMBOLIC_attribute_WMSReductionReleaseAmount);
    public static final String ATTRIBUTE_REDUCTION_RELEASE_AMOUNT_PREVIOUS = PropertyUtil
            .getSchemaProperty(SYMBOLIC_attribute_WMSReductionReleaseAmountTillPrevious);
    public static final String ATTRIBUTE_REDUCTION_RELEASE_REMARKS = PropertyUtil
            .getSchemaProperty(SYMBOLIC_attribute_WMSReductionReleaseRemarks);
    
    public static final String ATTRIBUTE_WITHHELD_TYPE = PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSBillWithheldItemType);
    
    public static final String ATTRIBUTE_WITHHELD_AMOUNT = PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBEWithHeldAmount);
    public static final String ATTRIBUTE_WITHHELD_RELEASE_AMOUNT = PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_WMSAbstractMBEWithHeldReleasedAmount);

	public static final String  ATTRIBUTE_WMS_IS_LD_ITEM = PropertyUtil.getSchemaProperty("attribute_WMSIsLDItem");
	public static final String ATTRIBUTE_WMS_BILL_REDUCTION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSBillReductionAmount");

    
    

    // Relationships
    public static final String RELATIONSHIP_WORKORDER_ABSTRACT_MBE="WMSWOAbstractMBE";
    public static final String SYMBOLIC_relationship_WMSBillReduction = "relationship_WMSBillReduction";
    public static final String SYMBOLIC_relationship_WMSBillReductionRelease = "relationship_WMSBillReductionRelease";
    public static final String SYMBOLIC_relationship_WMSWorkOrderReduction = "relationship_WMSWorkOrderReduction";
    public static final String RELATIONSHIP_BILL_REDUCTION = PropertyUtil
            .getSchemaProperty(SYMBOLIC_relationship_WMSBillReduction);
    public static final String RELATIONSHIP_BILL_REDUCTION_RELEASE = PropertyUtil
            .getSchemaProperty(SYMBOLIC_relationship_WMSBillReductionRelease);
    public static final String RELATIONSHIP_WORKORDER_REDUCTION = PropertyUtil
            .getSchemaProperty(SYMBOLIC_relationship_WMSWorkOrderReduction);

    // Types

    public static final String SYMBOLIC_type_WMSBillReductionItem = "type_WMSBillReductionItem";

    public static final String TYPE_BILL_REDUCTION_ITEM = PropertyUtil
            .getSchemaProperty(SYMBOLIC_type_WMSBillReductionItem);

    public static final String TYPE_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("type_WMSAbstractMeasurementBookEntry");

    // Policy

    public static final String SYMBOLIC_policy_WMSBillReductionItem = "policy_WMSBillReductionItem";

    public static final String POLICY_BILL_REDUCTION_ITEM = PropertyUtil
            .getSchemaProperty(SYMBOLIC_policy_WMSBillReductionItem);

    /**
     * Create a new ${CLASS:BillReduction} object from a given id.
     *
     * @param context
     *            the eMatrix <code>Context</code> object
     * @param args
     *            holds no arguments.
     * @throws Exception
     *             if the operation fails
     * @author WMS
     * @since R418
     */

    public WMSBillReduction_mxJPO(Context context, String[] args) throws Exception {

    }

    /**
     * PENDING header and annotation //USED
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getReduction(Context context, String[] args) throws Exception {
        MapList mapListAMBReduction = new MapList();
        try {
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
                StringList strListBusSelects = new StringList(4);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                strListBusSelects.add(DomainConstants.SELECT_TYPE);
                strListBusSelects.add("attribute["+ATTRIBUTE_WMS_BILL_REDUCTION_AMOUNT+"].value");
                StringList strListRelSelects = new StringList(1);
                strListRelSelects.add(DomainRelationship.SELECT_ID);
                
                DomainObject domObjTask = DomainObject.newInstance(context, strObjectId);
                mapListAMBReduction = domObjTask.getRelatedObjects(context, // matrix
                        // context
                        RELATIONSHIP_BILL_REDUCTION, // relationship pattern
                        TYPE_BILL_REDUCTION_ITEM, // type pattern
                        strListBusSelects, // object selects
                        strListRelSelects, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        "attribute["+ATTRIBUTE_WMS_IS_LD_ITEM+"] == No", // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where
                        // clause
                        0);
            }
        } catch (Exception exception) {
            System.out.println("Exception in getReduction method of JPO WMSBillReduction");
            System.out.println("Called from command WMSDeductionWithHeldCmd");
            exception.printStackTrace();
            throw exception;
        }
        return mapListAMBReduction;
    }

    /**
     * PENDING header and annotation //USED
     */
    public Vector getSNOColumn(Context context, String[] args) throws Exception {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            int intSize = objectList.size();
            Vector vecResponse = new Vector(intSize);
            Iterator iterator = objectList.iterator();
            for (int i = 1; i < intSize + 1; i++) {
                vecResponse.add(String.valueOf(i));
            }

            return vecResponse;
        } catch (Exception exception) {
            System.out.println("Exception in getSNOColumn method of JPO WMSBillReduction");
            System.out.println("Called from WMSBillReductionDetails table");
            exception.printStackTrace();
            throw exception;
        }
    }

    /**
     * PENDING header and annotation //USED
     */
    @com.matrixone.apps.framework.ui.ConnectionProgramCallable
    public HashMap createReductionItem(Context context, String[] args) throws Exception {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
        Map paramMap = (Map) programMap.get("paramMap");
        String sObjectId = (String) paramMap.get("objectId");

        String sRowId = DomainConstants.EMPTY_STRING;
        String strReductionObjectParticulars = DomainConstants.EMPTY_STRING;
        String strReductionObjectAmount = DomainConstants.EMPTY_STRING;
        String strReductionObjectRemarks = DomainConstants.EMPTY_STRING;
        String strNewReductionObject = DomainConstants.EMPTY_STRING;
        String strReductionType = DomainConstants.EMPTY_STRING;
        HashMap columnsMap;
        HashMap changedRowMap;
        HashMap doc = new HashMap();
        HashMap retMap;

        DomainObject domAmbObject = DomainObject.newInstance(context, sObjectId);
        DomainObject doReductionObject = DomainObject.newInstance(context);

        Element elm = (Element) programMap.get("contextData");
        MapList mlItems = new MapList();
        MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
        Map mapAttr = new HashMap();

        for (int i = 0, size = chgRowsMapList.size(); i < size; i++) {
            try {
                retMap = new HashMap();
                changedRowMap = (HashMap) chgRowsMapList.get(i);
                columnsMap = (HashMap) changedRowMap.get("columns");
                sRowId = (String) changedRowMap.get("rowId");
                strReductionObjectParticulars = (String) columnsMap.get("Particulars");
                strReductionObjectAmount = (String) columnsMap.get("ReductionAmount");
                strReductionObjectRemarks = (String) columnsMap.get("Remarks");
                strReductionType = (String) columnsMap.get("WMSBillWithheldItemType");
                if(UIUtil.isNullOrEmpty(strReductionType))
                {
                    strReductionType = "PayableLater";
                }

                strNewReductionObject = FrameworkUtil.autoName(context, SYMBOLIC_type_WMSBillReductionItem, null,
                        SYMBOLIC_policy_WMSBillReductionItem, null, null, true, true);

                DomainRelationship domRel = doReductionObject.createAndConnect(context, TYPE_BILL_REDUCTION_ITEM,
                        strNewReductionObject, "-", POLICY_BILL_REDUCTION_ITEM, null, RELATIONSHIP_BILL_REDUCTION,
                        domAmbObject, true);

                mapAttr = new HashMap();
                mapAttr.put(ATTRIBUTE_REDUCTION_PARTICULARS, strReductionObjectParticulars);
                if (strReductionObjectAmount != null && !"".equals(strReductionObjectAmount)) {
                    mapAttr.put(ATTRIBUTE_REDUCTION_AMOUNT, strReductionObjectAmount);
                }
                if (strReductionObjectRemarks != null && !"".equals(strReductionObjectRemarks)) {
                    mapAttr.put(ATTRIBUTE_REDUCTION_REMARKS, strReductionObjectRemarks);
                }
                mapAttr.put(ATTRIBUTE_WITHHELD_TYPE, strReductionType);

                doReductionObject.setAttributeValues(context, mapAttr);

                retMap = new HashMap();
                retMap.put("oid", doReductionObject.getObjectId(context));
                retMap.put("relid", domRel.toString());
                retMap.put("pid", "");
                retMap.put("rid", "");
                retMap.put("markup", "new");
                retMap.put("rowId", sRowId);
                columnsMap.putAll(retMap);
                retMap.put("columns", columnsMap);
                mlItems.add(retMap);
                doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
                doc.put("Action", "success"); // Here the action can be
                // "Success" or "refresh"

            } catch (Exception e) {
                System.out.println("Exception in createReductionItem method of JPO WMSBillReduction");
                System.out.println("Called from Connection program Recovery, WMSRecoveryDetails");
                e.printStackTrace();
                throw e;
            }
        }
        return doc;
    }

//USED
    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getReductionRelease(Context context, String[] args) throws Exception {
        MapList mapListAMBReductionRelease = new MapList();
        try {
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
                StringList strListBusSelects = new StringList(2);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                strListBusSelects.add(DomainConstants.SELECT_TYPE);
                StringList strListRelSelects = new StringList(2);
                strListRelSelects.add(DomainRelationship.SELECT_ID);
                strListRelSelects.add("attribute["+ATTRIBUTE_REDUCTION_RELEASE_AMOUNT+"].value");
                DomainObject domObjTask = DomainObject.newInstance(context, strObjectId);
                mapListAMBReductionRelease = domObjTask.getRelatedObjects(context, // matrix
                        // context
                        RELATIONSHIP_BILL_REDUCTION_RELEASE, // relationship
                        // pattern
                        TYPE_BILL_REDUCTION_ITEM, // type pattern
                        strListBusSelects, // object selects
                        strListRelSelects, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        "attribute["+ATTRIBUTE_WMS_IS_LD_ITEM+"] == No", // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where
                        // clause
                        0);

            }
        } catch (Exception exception) {
            System.out.println("Exception in getRecoveries method of JPO WMSAdvanceRecovery");
            System.out.println("Called from AMB Tree command Recovery, WMSRecoveryDetails");
            exception.printStackTrace();
            throw exception;
        }
        return mapListAMBReductionRelease;
    }


    //USED
    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getWorkOrderReductions(Context context, String[] args) throws Exception {

        try {
            MapList mapListConnectedReds = new MapList();
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);

            if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
                DomainObject domObjWO = DomainObject.newInstance(context, strObjectId);
                String strWorkOrderOID = domObjWO.getInfo(context,
                        "relationship[" + RELATIONSHIP_WORKORDER_ABSTRACT_MBE + "].from.id");
                StringList slExistingObjs = domObjWO.getInfoList(context,
                        "from[" + RELATIONSHIP_BILL_REDUCTION_RELEASE + "].to.id");
                DomainObject domObjWORed = DomainObject.newInstance(context, strWorkOrderOID);
                MapList mapListReductions = getWorkOrderReductions(context, domObjWORed, slExistingObjs);
                mapListConnectedReds = WMSUtil_mxJPO.getSubMapList(mapListReductions, "attribute[" + ATTRIBUTE_WITHHELD_TYPE + "].value", "PayableLater");
                mapListConnectedReds = WMSUtil_mxJPO.getSubMapList(mapListReductions, "attribute[" + ATTRIBUTE_WMS_IS_LD_ITEM + "].value", "No");
            }
            return mapListConnectedReds;
        } catch (Exception exception) {
            System.out.println("Exception in getSNOColumn method of JPO WMSBillReduction");
            System.out.println("Called from AMB Tree command Recovery, WMSRecoveryDetails");
            exception.printStackTrace();
            throw exception;
        }

    }

//USED
    private MapList getWorkOrderReductions(Context context, DomainObject domObjWORed, StringList slExistingObjs)
            throws FrameworkException {
        MapList mapListWORed = new MapList();
        try {
            StringList strListBusSelects = new StringList(4);
            strListBusSelects.add(DomainConstants.SELECT_ID);
            strListBusSelects.add("attribute[" + ATTRIBUTE_REDUCTION_AMOUNT + "].value");
            strListBusSelects.add("attribute[" + ATTRIBUTE_REDUCTION_RELEASE_AMOUNT_TILL_DATE + "].value");
            strListBusSelects.add("attribute[" + ATTRIBUTE_WITHHELD_TYPE + "].value");
            strListBusSelects.add("attribute[" + ATTRIBUTE_WMS_IS_LD_ITEM + "].value");

            StringList strListRelSelects = new StringList(2);
            strListRelSelects.add(DomainRelationship.SELECT_ID);

            String strWhere = "attribute[" + ATTRIBUTE_REDUCTION_AMOUNT + "] > attribute["
                    + ATTRIBUTE_REDUCTION_RELEASE_AMOUNT_TILL_DATE + "]";
            MapList mapListConnectedReds = domObjWORed.getRelatedObjects(context, // matrix
                    // context
                    RELATIONSHIP_WORKORDER_REDUCTION, // relationship pattern
                    TYPE_BILL_REDUCTION_ITEM, // type pattern
                    strListBusSelects, // object selects
                    strListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 1, // recursion level
                    strWhere, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);

            Iterator<Map<String, String>> iteratorMap = mapListConnectedReds.iterator();

            Map<String, String> mapAdvanceData = new HashMap<String, String>();
            String strItemOID = DomainConstants.EMPTY_STRING;

            while (iteratorMap.hasNext()) {
                mapAdvanceData = iteratorMap.next();
                strItemOID = mapAdvanceData.get(DomainConstants.SELECT_ID);

                if (slExistingObjs.contains(strItemOID)) {
                    continue;
                } else {
                    mapListWORed.add(mapAdvanceData);
                }
            }
            // return mapListConnectedReds;
        } catch (FrameworkException frameworkException) {
            System.out.println("Exception in getSNOColumn method of JPO WMSBillReduction");
            System.out.println("Called from AMB Tree command Recovery, WMSRecoveryDetails");
            throw frameworkException;
        }
        return mapListWORed;

    }


     /* This method is used to diaplay default Withheld type value*/ //USED
     public HashMap<String,String> getWithHeldDefaultValue(Context context, String[] args) throws Exception
      {
          HashMap<String,String> defaultMap = new HashMap<String,String>();

            AttributeType attrType = new AttributeType(ATTRIBUTE_WITHHELD_TYPE);
            attrType.open(context);
            String strDefaultAttrValue = attrType.getDefaultValue();
            attrType.close(context);
        if(UIUtil.isNullOrEmpty(strDefaultAttrValue))
        {
            strDefaultAttrValue = "PayableLater";
        }
          defaultMap.put("Default_AddNewRow",strDefaultAttrValue);
         defaultMap.put("Default_ExistingRow",strDefaultAttrValue);
          defaultMap.put("Default_AddNewRow_Display",strDefaultAttrValue);
         defaultMap.put("Default_ExistingRow_Display",strDefaultAttrValue);
          //IR-034174 - Ends
          return defaultMap;
        }
    
     /**    USED
     * PENDING header and annotation
     * to add recovery
     * Trigger method to connect the New Recovery Object to the 
     * Work Orders of the Abstract MBE
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public void connectAMBObjectsToWorkOrder(Context context,String[]args) throws Exception
    {
        boolean isContextPushed = false;
        try {
           // ContextUtil.pushContext(context);
           // isContextPushed = true;
            String strAMBEOID = args[0];
            
            if(UIUtil.isNotNullAndNotEmpty(strAMBEOID))
            {
                DomainObject domObjAbstractMBE = DomainObject.newInstance(context, strAMBEOID);
                StringList strListAdvcRecoverOBJIds =  new StringList();

                String strWorkOrder         = domObjAbstractMBE.getInfo(context, "to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id"); 
                DomainObject domObjAbstractMBEWO = DomainObject.newInstance(context, strWorkOrder);

                String strAMBRelSymbName = args[1];
                String strAMBRelName = PropertyUtil.getSchemaProperty(strAMBRelSymbName);
                strListAdvcRecoverOBJIds = domObjAbstractMBE.getInfoList(context,"from["+strAMBRelName+"].to.id");

                ArrayList<String> arrayListOIDS = new ArrayList<String>(strListAdvcRecoverOBJIds);

                String strWorkOrderRelSymbName = args[2];
                String strWorkOrderRelName = PropertyUtil.getSchemaProperty(strWorkOrderRelSymbName);
                WMSUtil_mxJPO.connect(context, domObjAbstractMBEWO, strWorkOrderRelName, true, arrayListOIDS);
            }
        }
        catch(Exception exception)
        {
            System.out.println("Exception in connectAMBObjectsToWorkOrder method of JPO WMSBillReduction");
            System.out.println("Called from AMB action trigger on Approve State");
            exception.printStackTrace();
            throw exception;
        }
        finally
        {
           // if (isContextPushed)
           // {
           //     ContextUtil.popContext(context);
           // }
        }
    } 

    public void updateTillDateAmount(Context context, String[] args) throws Exception {
        System.out.println("Trigger Called from Reduction");
        boolean isContextPushed = false;
       // ContextUtil.pushContext(context);
        //isContextPushed = true;
        String strAMBEOID = args[0];
        try {
            if (UIUtil.isNotNullAndNotEmpty(strAMBEOID)) {
                DomainObject domObjAbstractMBE = DomainObject.newInstance(context, strAMBEOID);
                String strAMBRelSymbName = args[1];
                String strAMBRelName = PropertyUtil.getSchemaProperty(strAMBRelSymbName);
                // slListConnectedOBJIds =
                // domObjAbstractMBE.getInfoList(context, "from[" +
                // strAMBRelName + "].to.id");
                // getRelatedObjects
                // Relation is AMB and Reduction objects for release
                // rel select , released till date and to be paid in this bill
                // Add these 2 values
                // Store the value in Reduction Object in attr for
                // ReleasedTillDate.
                StringList strListBusSelects = new StringList(1);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                StringList strListRelSelects = new StringList(2);
                strListRelSelects.add("attribute[" + ATTRIBUTE_REDUCTION_RELEASE_AMOUNT + "]");
                strListRelSelects.add("attribute[" + ATTRIBUTE_REDUCTION_RELEASE_AMOUNT_PREVIOUS + "]");
                MapList mapListConnectedObj = domObjAbstractMBE.getRelatedObjects(context, // matrix
                        // context
                        strAMBRelName, // relationship pattern
                        TYPE_BILL_REDUCTION_ITEM, // type pattern
                        strListBusSelects, // object selects
                        strListRelSelects, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        DomainConstants.EMPTY_STRING, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where
                        // clause
                        0);
                Iterator<Map<String, String>> iteratorMap = mapListConnectedObj.iterator();

                Map<String, String> mapAdvanceData = new HashMap<String, String>();
                String strOID = DomainConstants.EMPTY_STRING;
                String strRedRelPrev = "";
                String strRedRelCurrent = "";
                DomainObject doRedObj = DomainObject.newInstance(context);

                while (iteratorMap.hasNext()) {
                    mapAdvanceData = iteratorMap.next();
                    strOID = (String) mapAdvanceData.get(DomainConstants.SELECT_ID);
                    strRedRelPrev = (String) mapAdvanceData
                            .get("attribute[" + ATTRIBUTE_REDUCTION_RELEASE_AMOUNT_PREVIOUS + "]");
                    strRedRelCurrent = (String) mapAdvanceData
                            .get("attribute[" + ATTRIBUTE_REDUCTION_RELEASE_AMOUNT + "]");
                    float fRedRelPrev = Float.valueOf(strRedRelPrev);
                    float fRedRelCurrent = Float.valueOf(strRedRelCurrent);
                    float fFinalValue = fRedRelPrev + fRedRelCurrent;
                    doRedObj.setId(strOID);
                    doRedObj.setAttributeValue(context, ATTRIBUTE_REDUCTION_RELEASE_AMOUNT_TILL_DATE,
                            String.valueOf(fFinalValue));
                }

            }
        } catch (Exception exception) {
            System.out.println(
                    "Exception in conncecting Wrok ordere to Advance Recovery/Withheld Object method of JPO WMSBillReduction");
            System.out.println("Called from AMB after submiting reduction");
            exception.printStackTrace();
            throw exception;
        } finally {
           // if (isContextPushed) {
           //     ContextUtil.popContext(context);
           // }
        }

    }


    /**
     * PENDING header and annotation
     * Trigger    updateupdateTillDateReductionAndReleaseTillDateAdvanceAndRecovery On relationship connection WMSBillReduction
     * to add recovery
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public void updateTillDateReductionAndRelease(Context context,String[]args) throws Exception
    {
        boolean isContextPushed = false;
        try {
            //ContextUtil.pushContext(context);
          //  isContextPushed = true;
            String strObjectID = args[0];
            
            if(UIUtil.isNotNullAndNotEmpty(strObjectID))
            {
                DomainObject domAmbObject = DomainObject.newInstance(context, strObjectID);
            
                //Get the Releases on current AMB
                MapList mapListAMBReleases = new MapList();
                StringList strListRelSelects = new StringList(1);
                strListRelSelects.add("attribute["+ATTRIBUTE_REDUCTION_RELEASE_AMOUNT+"].value");
                
                mapListAMBReleases = domAmbObject.getRelatedObjects(context, // matrix
                            // context
                             RELATIONSHIP_BILL_REDUCTION_RELEASE, // relationship pattern
                             TYPE_BILL_REDUCTION_ITEM, // type pattern
                            null, // object selects
                            strListRelSelects, // relationship selects
                            false, // to direction
                            true, // from direction
                            (short) 1, // recursion level
                            //strWhere, // object where clause
                            DomainConstants.EMPTY_STRING,
                            DomainConstants.EMPTY_STRING, // relationship where
                            // clause
                            0);
            
            
                Iterator<Map<String,String>> iteratorMap = mapListAMBReleases.iterator();
                Map<String,String> mapReleaseData = new HashMap<String, String>();
                String strReleaseAmt = "";
                
                Map mReleaseMap = new HashMap();
                mReleaseMap.put("Release", "0");
                String strRelValue = "";
                float fTempRelValue = 0f;
                float fRelAttrValue = 0f;
                
                while(iteratorMap.hasNext())
                {
                    
                    mapReleaseData = iteratorMap.next();
                    strReleaseAmt = mapReleaseData.get("attribute["+ATTRIBUTE_REDUCTION_RELEASE_AMOUNT+"].value");
                    fRelAttrValue = Float.parseFloat(strReleaseAmt);
                
                    strRelValue = (String)mReleaseMap.get("Release");
                    if(UIUtil.isNotNullAndNotEmpty(strRelValue)){
                        fTempRelValue = Float.parseFloat(strRelValue);
                        
                        mReleaseMap.put("Release", String.valueOf(fRelAttrValue + fTempRelValue));
                    }
                }
            
                

            //Get the Reduction on current AMB
            MapList mapListAMBReduction = new MapList();
                StringList strListBusSelectsReduction = new StringList(1);
                strListBusSelectsReduction.add("attribute["+ATTRIBUTE_REDUCTION_AMOUNT+"].value");
                mapListAMBReduction = domAmbObject.getRelatedObjects(context, // matrix
                            // context
                            RELATIONSHIP_BILL_REDUCTION, // relationship pattern
                            TYPE_BILL_REDUCTION_ITEM, // type pattern
                             strListBusSelectsReduction, // object selects
                            null, // relationship selects
                            false, // to direction
                            true, // from direction
                            (short) 1, // recursion level
                            //strWhere, // object where clause
                            DomainConstants.EMPTY_STRING,
                            DomainConstants.EMPTY_STRING, // relationship where clause
                            0);
                
                
                Iterator<Map<String,String>> iteratorAdvMap = mapListAMBReduction.iterator();
                Map<String,String> mapReductionData = new HashMap<String, String>();
                String strReductionAmt = "";
                Map mReductionMap = new HashMap();
                mReductionMap.put("Reduction", "0");
                String strRedValue = "";
                float fTempRedValue = 0f;
                float fRedAttrValue = 0f;
                
                while(iteratorAdvMap.hasNext())
                {
                    mapReductionData = iteratorAdvMap.next();
                    strReductionAmt = mapReductionData.get("attribute["+ATTRIBUTE_REDUCTION_AMOUNT+"].value");
                    fRedAttrValue = Float.parseFloat(strReductionAmt);
                    
                    
                    strRedValue = (String)mReductionMap.get("Reduction");
                    if(UIUtil.isNotNullAndNotEmpty(strRedValue)){
                        fTempRedValue = Float.parseFloat(strRedValue);
                    
                        mReductionMap.put("Reduction", String.valueOf(fRedAttrValue + fTempRedValue));
                    }
                }
                
                
                Map<String,String> mapAttribute=new HashMap<String,String>();  
                mapAttribute.putAll(mReleaseMap);
                mapAttribute.putAll(mReductionMap);                
                
                Map MapAttributes = new HashMap<>();
                
                //Get attribute from Previous Sequence AMB.
                //Get Previous Sequence AMB.
                StringList strListAmbSelects = new StringList(2);
                strListAmbSelects.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id"); //Workorder relationship
                strListAmbSelects.add("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"]");//Sequence atribute
                
                Map mAMBInfo = domAmbObject.getInfo(context, strListAmbSelects);
                String strWorkOrderId = (String)mAMBInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
                String strSequenceOrder = (String)mAMBInfo.get("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"]");
                
                if (!strSequenceOrder.equals("1")) {
                    DomainObject doWorkOrder = DomainObject.newInstance(context, strWorkOrderId);
                    //Get Previous Sequence
                    int iCurrentSeq = Integer.parseInt(strSequenceOrder);
                    int iPrevSeq = iCurrentSeq - 1;
                    String strWhere = "attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"] == "+String.valueOf(iPrevSeq);
                    
                    StringList strListPrevAmbSelects = new StringList(2);
                    strListPrevAmbSelects.add("attribute["+ATTRIBUTE_WITHHELD_AMOUNT+"]");//convert to constant
                    strListPrevAmbSelects.add("attribute["+ATTRIBUTE_WITHHELD_RELEASE_AMOUNT+"]");
                    
                    MapList mlPreAMB = doWorkOrder.getRelatedObjects(context, // matrix
                                                                    // context
                                                                    RELATIONSHIP_WORKORDER_ABSTRACT_MBE, // relationship pattern
                                                                    TYPE_ABSTRACT_MBE, // type pattern
                                                                    strListPrevAmbSelects, // object selects
                                                                    null, // relationship selects
                                                                    false, // to direction
                                                                    true, // from direction
                                                                    (short) 1, // recursion level
                                                                    strWhere, // object where clause
                                                                    null, // relationship where
                                                                    // clause
                                                                    1);
                    Map mPrevAMBInfo = (Map)mlPreAMB.get(0);
                
                    
                    String strReduction = (String)mPrevAMBInfo.get("attribute["+ATTRIBUTE_WITHHELD_AMOUNT+"]");
                    String strRel = (String)mPrevAMBInfo.get("attribute["+ATTRIBUTE_WITHHELD_RELEASE_AMOUNT+"]");
                    
                    float fReduction = Float.parseFloat(strReduction) + Float.parseFloat(mapAttribute.get("Reduction"));
                    float fRel = Float.parseFloat(strRel) + Float.parseFloat(mapAttribute.get("Release"));
                    
                    mapAttribute.put("Reduction", String.valueOf(strReduction));
                    mapAttribute.put("Release",  String.valueOf(strRel));
                
                }
                
                MapAttributes.put(ATTRIBUTE_WITHHELD_AMOUNT,mapAttribute.get("Reduction"));
                MapAttributes.put(ATTRIBUTE_WITHHELD_RELEASE_AMOUNT,mapAttribute.get("Release"));
    
                domAmbObject.setAttributeValues(context, MapAttributes);
            }
        }
        catch(Exception exception)
        {
            System.out.println("Exception updateTillDateReductionAndRelease method of JPO WMSBillReduction");
            exception.printStackTrace();
            throw exception;
        }
        finally
        {
           // if (isContextPushed)
           // {
           //     ContextUtil.popContext(context);
           // }
        }
    }

    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getReductionsConnectedToWO(Context context, String[] args) throws Exception {
        MapList mapListWOReduction = new MapList();
        try {
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
                StringList strListBusSelects = new StringList(2);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                strListBusSelects.add(DomainConstants.SELECT_TYPE);
                DomainObject domObjTask = DomainObject.newInstance(context, strObjectId);
                mapListWOReduction = domObjTask.getRelatedObjects(context, // matrix
                        // context
                        RELATIONSHIP_WORKORDER_REDUCTION, // relationship pattern
                        TYPE_BILL_REDUCTION_ITEM, // type pattern
                        strListBusSelects, // object selects
                        null, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        "attribute["+ATTRIBUTE_WMS_IS_LD_ITEM+"] == No", // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where
                        // clause
                        0);
            }
            
            return mapListWOReduction;
        } catch (Exception exception) {
            System.out.println("Exception getReductionsConnectedToWO method of JPO WMSBillReduction");
            System.out.println("Called from WMSWorkOrderReduction command");
            exception.printStackTrace();
            throw exception;
        }
    }

    
    @com.matrixone.apps.framework.ui.ProgramCallable
    public void updateRedReleaseAttForReduction(Context context, String[] args) throws Exception {
        boolean isContextPushed = false;
        try {
            ContextUtil.pushContext(context);
            isContextPushed = true;
            String strToObjectID = args[0];
            String strRELID = args[1];

            if (UIUtil.isNotNullAndNotEmpty(strToObjectID)) {
                DomainObject domObjToObject = DomainObject.newInstance(context, strToObjectID);
                StringList slObjSelects = new StringList(2);
                slObjSelects.add(ATTRIBUTE_REDUCTION_AMOUNT);
                slObjSelects.add(ATTRIBUTE_REDUCTION_RELEASE_AMOUNT_TILL_DATE);
                AttributeList alAttrValues = domObjToObject.getAttributeValues(context, slObjSelects);
                AttributeItr atItrAttrVals = new AttributeItr(alAttrValues);
                atItrAttrVals.next();
                String strReductionAmount = atItrAttrVals.obj().getValue();
                atItrAttrVals.next();
                String strRedReleaseTillDateAmount = atItrAttrVals.obj().getValue();

                float fRedAmount = Float.valueOf(strReductionAmount);
                float fRedReleaseTillDateAmount = Float.valueOf(strRedReleaseTillDateAmount);

                float fToRelRedReleaseAmount = fRedAmount - fRedReleaseTillDateAmount;

                String strToRelRedReleaseAmount = String.valueOf(fToRelRedReleaseAmount);

                Map mAttrMap = new HashMap();
                mAttrMap.put(ATTRIBUTE_REDUCTION_RELEASE_AMOUNT, strToRelRedReleaseAmount);
                mAttrMap.put(ATTRIBUTE_REDUCTION_RELEASE_AMOUNT_PREVIOUS, strRedReleaseTillDateAmount);

                DomainRelationship drReleaseRel = new DomainRelationship(strRELID);
                drReleaseRel.setAttributeValues(context, mAttrMap);
            }
        } catch (Exception exception) {
            System.out.println(
                    "Exception in conncecting Wrok ordere to Advance Recovery/Withheld Object method of JPO WMSBillReduction");
            System.out.println("Called from AMB after submiting reduction");
            exception.printStackTrace();
            throw exception;
        } finally {
            if (isContextPushed) {
                ContextUtil.popContext(context);
            }
        }
    }

    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getReductionsConnectedToABS(Context context, String[] args) throws Exception {
        MapList mapListABSReduction = new MapList();
        try {
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
                DomainObject domObjToObject = DomainObject.newInstance(context, strObjectId);
                StringList strListBusSelects = new StringList(1);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                StringList strListRelSelects = new StringList(2);
                strListRelSelects.add(DomainRelationship.SELECT_ID);
                String strWhere = "current==Approved";
                 mapListABSReduction = domObjToObject.getRelatedObjects(context, // matrix
                        // context
                        RELATIONSHIP_BILL_REDUCTION_RELEASE, // relationship pattern
                        TYPE_ABSTRACT_MBE, // type pattern
                        strListBusSelects, // object selects
                        strListRelSelects, // relationship selects
                        true, // to direction
                        false, // from direction
                        (short) 1, // recursion level
                        strWhere, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where
                        // clause
                        0);
            }
            
            return mapListABSReduction;
        } catch (Exception exception) {
            System.out.println("Exception getReductionsConnectedToABS method of JPO WMSBillReduction");
            //System.out.println("Called from WMSShowWorkOrderReduction command");
            exception.printStackTrace();
            throw exception;
        }
    }

	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getLDsToWO(Context context, String[] args) throws Exception {
        MapList mapListWOReduction = new MapList();
        try {
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
                StringList strListBusSelects = new StringList(2);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                strListBusSelects.add(DomainConstants.SELECT_TYPE);
                DomainObject domObjTask = DomainObject.newInstance(context, strObjectId);
                mapListWOReduction = domObjTask.getRelatedObjects(context, // matrix
                        // context
                        RELATIONSHIP_WORKORDER_REDUCTION, // relationship pattern
                        TYPE_BILL_REDUCTION_ITEM, // type pattern
                        strListBusSelects, // object selects
                        null, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        "attribute["+ATTRIBUTE_WMS_IS_LD_ITEM+"] == Yes", // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where
                        // clause
                        0);
            }
            
            return mapListWOReduction;
        } catch (Exception exception) {
            System.out.println("Exception getReductionsConnectedToWO method of JPO WMSBillReduction");
            System.out.println("Called from WMSWorkOrderReduction command");
            exception.printStackTrace();
            throw exception;
        }
    }

@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getLDs(Context context, String[] args) throws Exception {
        MapList mapListAMBReduction = new MapList();
        try {
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
                StringList strListBusSelects = new StringList(3);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                strListBusSelects.add(DomainConstants.SELECT_TYPE);
                strListBusSelects.add("attribute["+ATTRIBUTE_WMS_BILL_REDUCTION_AMOUNT+"].value");
                StringList strListRelSelects = new StringList(1);
                strListRelSelects.add(DomainRelationship.SELECT_ID);
                
                DomainObject domObjTask = DomainObject.newInstance(context, strObjectId);
                mapListAMBReduction = domObjTask.getRelatedObjects(context, // matrix
                        // context
                        RELATIONSHIP_BILL_REDUCTION, // relationship pattern
                        TYPE_BILL_REDUCTION_ITEM, // type pattern
                        strListBusSelects, // object selects
                        strListRelSelects, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        "attribute["+ATTRIBUTE_WMS_IS_LD_ITEM+"] == Yes", // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where
                        // clause
                        0);
            }
        } catch (Exception exception) {
            System.out.println("Exception in getReduction method of JPO WMSBillReduction");
            System.out.println("Called from command WMSDeductionWithHeldCmd");
            exception.printStackTrace();
            throw exception;
        }
        return mapListAMBReduction;
    }
	
	 @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getLDRelease(Context context, String[] args) throws Exception {
        MapList mapListAMBReductionRelease = new MapList();
        try {
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
                StringList strListBusSelects = new StringList(2);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                strListBusSelects.add(DomainConstants.SELECT_TYPE);
                StringList strListRelSelects = new StringList(2);
                strListRelSelects.add(DomainRelationship.SELECT_ID);
                strListRelSelects.add("attribute["+ATTRIBUTE_REDUCTION_RELEASE_AMOUNT+"].value");
                DomainObject domObjTask = DomainObject.newInstance(context, strObjectId);
                mapListAMBReductionRelease = domObjTask.getRelatedObjects(context, // matrix
                        // context
                        RELATIONSHIP_BILL_REDUCTION_RELEASE, // relationship
                        // pattern
                        TYPE_BILL_REDUCTION_ITEM, // type pattern
                        strListBusSelects, // object selects
                        strListRelSelects, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        "attribute["+ATTRIBUTE_WMS_IS_LD_ITEM+"] == Yes", // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where
                        // clause
                        0);

            }
        } catch (Exception exception) {
            System.out.println("Exception in getRecoveries method of JPO WMSAdvanceRecovery");
            System.out.println("Called from AMB Tree command Recovery, WMSRecoveryDetails");
            exception.printStackTrace();
            throw exception;
        }
        return mapListAMBReductionRelease;
    }
	
	
	 @com.matrixone.apps.framework.ui.ConnectionProgramCallable
    public HashMap createLDItem(Context context, String[] args) throws Exception {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
        Map paramMap = (Map) programMap.get("paramMap");
        String sObjectId = (String) paramMap.get("objectId");

        String sRowId = DomainConstants.EMPTY_STRING;
        String strReductionObjectParticulars = DomainConstants.EMPTY_STRING;
        String strReductionObjectAmount = DomainConstants.EMPTY_STRING;
        String strReductionObjectRemarks = DomainConstants.EMPTY_STRING;
        String strNewReductionObject = DomainConstants.EMPTY_STRING;
        String strReductionType = DomainConstants.EMPTY_STRING;
        HashMap columnsMap;
        HashMap changedRowMap;
        HashMap doc = new HashMap();
        HashMap retMap;

        DomainObject domAmbObject = DomainObject.newInstance(context, sObjectId);
        DomainObject doReductionObject = DomainObject.newInstance(context);

        Element elm = (Element) programMap.get("contextData");
        MapList mlItems = new MapList();
        MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
        Map mapAttr = new HashMap();

        for (int i = 0, size = chgRowsMapList.size(); i < size; i++) {
            try {
                retMap = new HashMap();
                changedRowMap = (HashMap) chgRowsMapList.get(i);
                columnsMap = (HashMap) changedRowMap.get("columns");
                sRowId = (String) changedRowMap.get("rowId");
                strReductionObjectParticulars = (String) columnsMap.get("Particulars");
                strReductionObjectAmount = (String) columnsMap.get("ReductionAmount");
                strReductionObjectRemarks = (String) columnsMap.get("Remarks");
                strReductionType = "Permanent";//(String) columnsMap.get("WMSBillWithheldItemType");
                //if(UIUtil.isNullOrEmpty(strReductionType))
                //{
                  //  strReductionType = "PayableLater";
                //}

                strNewReductionObject = FrameworkUtil.autoName(context, SYMBOLIC_type_WMSBillReductionItem, null,
                        SYMBOLIC_policy_WMSBillReductionItem, null, null, true, true);

                DomainRelationship domRel = doReductionObject.createAndConnect(context, TYPE_BILL_REDUCTION_ITEM,
                        strNewReductionObject, "-", POLICY_BILL_REDUCTION_ITEM, null, RELATIONSHIP_BILL_REDUCTION,
                        domAmbObject, true);

                mapAttr = new HashMap();
                mapAttr.put(ATTRIBUTE_REDUCTION_PARTICULARS, strReductionObjectParticulars);
                if (strReductionObjectAmount != null && !"".equals(strReductionObjectAmount)) {
                    mapAttr.put(ATTRIBUTE_REDUCTION_AMOUNT, strReductionObjectAmount);
                }
                if (strReductionObjectRemarks != null && !"".equals(strReductionObjectRemarks)) {
                    mapAttr.put(ATTRIBUTE_REDUCTION_REMARKS, strReductionObjectRemarks);
                }
                mapAttr.put(ATTRIBUTE_WITHHELD_TYPE, strReductionType);
                mapAttr.put(ATTRIBUTE_WMS_IS_LD_ITEM, "Yes");

                doReductionObject.setAttributeValues(context, mapAttr);

                retMap = new HashMap();
                retMap.put("oid", doReductionObject.getObjectId(context));
                retMap.put("relid", domRel.toString());
                retMap.put("pid", "");
                retMap.put("rid", "");
                retMap.put("markup", "new");
                retMap.put("rowId", sRowId);
                columnsMap.putAll(retMap);
                retMap.put("columns", columnsMap);
                mlItems.add(retMap);
                doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
                doc.put("Action", "success"); // Here the action can be
                // "Success" or "refresh"

            } catch (Exception e) {
                System.out.println("Exception in createReductionItem method of JPO WMSBillReduction");
                System.out.println("Called from Connection program Recovery, WMSRecoveryDetails");
                e.printStackTrace();
                throw e;
            }
        }
        return doc;
    }

	 //USED
    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getWorkOrderLDs(Context context, String[] args) throws Exception {

        try {
            MapList mapListConnectedReds = new MapList();
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);

            if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
                DomainObject domObjWO = DomainObject.newInstance(context, strObjectId);
                String strWorkOrderOID = domObjWO.getInfo(context,
                        "relationship[" + RELATIONSHIP_WORKORDER_ABSTRACT_MBE + "].from.id");
                StringList slExistingObjs = domObjWO.getInfoList(context,
                        "from[" + RELATIONSHIP_BILL_REDUCTION_RELEASE + "].to.id");
                DomainObject domObjWORed = DomainObject.newInstance(context, strWorkOrderOID);
                MapList mapListReductions = getWorkOrderReductions(context, domObjWORed, slExistingObjs);
                mapListConnectedReds = WMSUtil_mxJPO.getSubMapList(mapListReductions, "attribute[" + ATTRIBUTE_WITHHELD_TYPE + "].value", "PayableLater");
                mapListConnectedReds = WMSUtil_mxJPO.getSubMapList(mapListReductions, "attribute[" + ATTRIBUTE_WMS_IS_LD_ITEM + "].value", "Yes");
            }
            return mapListConnectedReds;
        } catch (Exception exception) {
            System.out.println("Exception in getSNOColumn method of JPO WMSBillReduction");
            System.out.println("Called from AMB Tree command Recovery, WMSRecoveryDetails");
            exception.printStackTrace();
            throw exception;
        }

    }
	
}