/**
 *  ${CLASSNAME}.java
 *
 * (c) Dassault Systemes, 1993 - 2017. All rights reserved.
 * This program contains proprietary and trade secret information of
 * ENOVIA MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
 import java.util.HashMap;
 import java.util.Map;
 import java.text.SimpleDateFormat;
 import java.util.Vector;
 import java.util.Iterator;
 import java.text.DecimalFormat;
 import java.util.Date;
 import java.util.Locale;
 
 import matrix.db.Context;
 import matrix.db.JPO;
 import matrix.util.StringList;
 import java.math.BigDecimal;

 
 import com.matrixone.jdom.Element;
 import com.matrixone.apps.domain.util.MapList;
 import com.matrixone.apps.domain.DomainRelationship;
 import com.matrixone.apps.domain.DomainConstants;
 import com.matrixone.apps.domain.DomainObject;
 import com.matrixone.apps.framework.ui.UITableIndented;
 import com.matrixone.apps.domain.util.eMatrixDateFormat;
 import com.matrixone.apps.domain.util.FrameworkUtil;
 import com.matrixone.apps.framework.ui.UIUtil;
 import com.matrixone.apps.domain.util.MqlUtil;
 import com.matrixone.apps.domain.util.EnoviaResourceBundle;
 
 /**
 * 
 */
public class WMSCheckLists_mxJPO extends WMSConstants_mxJPO
{

 /**
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments
     * @throws Exception if the operation fails
     * @grade 0
     */
    public WMSCheckLists_mxJPO (Context context, String[] args) throws Exception
    {
		super(context,args);
    }
  /**
     * Method is used to populate the data for Royalty Charges page
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args The packed argument for JPO, containing the program map.
     *             This program map will have request parameter information, objectId and information about the UI table object.
     * @return MapList of data
     * @throws Exception
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getAllCheckListsConnected(Context context, String[] args) throws Exception {
		MapList mlCheckLists = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");
			String strContextUser = context.getUser();
            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_RECURRENCE+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_CHECKED+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_REFERENCE_TO+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_IS_LIBRARY+"]");
				slObjectSelects.add("from[Reference Document]");
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
				mlCheckLists = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_CHECKLIST,
															TYPE_WMS_CHECKLIST,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
				
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlCheckLists;
	}
	
	
	public void createCheckLists(Context context, String[] args) throws Exception {
        try {
            String strAMBId = args[1];
			String strWOId  = args[0];
			
			if(UIUtil.isNotNullAndNotEmpty(strAMBId)){
				DomainObject doAMB = new DomainObject(strAMBId);
				
				StringList strListBusSelects = new StringList(DomainConstants.SELECT_NAME);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                strListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
                strListBusSelects.add("attribute["+ATTRIBUTE_WMS_RECURRENCE+"]");
                MapList mapListObjects = DomainObject.findObjects(
                        context,
                        TYPE_WMS_CHECKLIST,
                        DomainConstants.QUERY_WILDCARD,
                        DomainConstants.QUERY_WILDCARD,
                        DomainConstants.QUERY_WILDCARD,
                        DomainConstants.QUERY_WILDCARD,
                        "attribute["+ATTRIBUTE_WMS_IS_LIBRARY+"]== Yes && attribute["+ATTRIBUTE_WMS_REFERENCE_TO+"] == AMB", 
                        DomainConstants.EMPTY_STRING,
                        true,
                        strListBusSelects, // object selects
                        (short) 0);
						
				Map mapObj = new HashMap();
                String strObjId = "";
                String strParentDescription = "";
                String strParentDefaultValue = "";
                String strNewObject = "";
                for(int i=0;i<mapListObjects.size();i++)
                {
                    mapObj = (Map)mapListObjects.get(i);
                    if(mapObj != null && !mapObj.isEmpty())
                    {
						strObjId = (String)(String)mapObj.get(DomainConstants.SELECT_ID);
                        strParentDescription = (String)mapObj.get(DomainConstants.SELECT_DESCRIPTION);
                        strParentDefaultValue = (String)mapObj.get("attribute["+ATTRIBUTE_WMS_RECURRENCE+"]");
                        if(UIUtil.isNotNullAndNotEmpty(strObjId))
                        {
							strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
										"type_WMSCheckList",
										"",
										"policy_WMSCheckList",
										context.getVault().getName(),
										"-"
										);
										
										
							if(UIUtil.isNotNullAndNotEmpty(strNewObject)){
								DomainObject doNewBus = new DomainObject(strNewObject);
								if (strParentDescription != null && !"".equals(strParentDescription)) {
									doNewBus.setDescription(context,strParentDescription);
								}
								if (strParentDefaultValue != null && !"".equals(strParentDefaultValue)) {
									doNewBus.setAttributeValue(context,ATTRIBUTE_WMS_RECURRENCE,strParentDefaultValue);
								}
								DomainRelationship.connect(context, doAMB, RELATIONSHIP_WMS_CHECKLIST, doNewBus);
							}							
                        }
                    }
                }
				
				StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_RECURRENCE+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_CHECKED+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_REFERENCE_TO+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_IS_LIBRARY+"]");
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject doWO = DomainObject.newInstance(context, strWOId);
				MapList mlCheckLists = doWO.getRelatedObjects(context,
															RELATIONSHIP_WMS_CHECKLIST,
															TYPE_WMS_CHECKLIST,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
							
				mapListObjects = DomainObject.findObjects(
								context,
								TYPE_WMS_CHECKLIST,
								DomainConstants.QUERY_WILDCARD,
								DomainConstants.QUERY_WILDCARD,
								DomainConstants.QUERY_WILDCARD,
								DomainConstants.QUERY_WILDCARD,
								"attribute["+ATTRIBUTE_WMS_IS_LIBRARY+"]== Yes && attribute["+ATTRIBUTE_WMS_REFERENCE_TO+"] == WO", 
								DomainConstants.EMPTY_STRING,
								true,
								strListBusSelects, // object selects
								(short) 0);
							
				if(mlCheckLists.size() == 0){
								
						mapObj = new HashMap();
						strObjId = "";
						strParentDescription = "";
						strParentDefaultValue = "";
						strNewObject = "";
						for(int i=0;i<mapListObjects.size();i++)
						{
							mapObj = (Map)mapListObjects.get(i);
							if(mapObj != null && !mapObj.isEmpty())
							{
								strObjId = (String)(String)mapObj.get(DomainConstants.SELECT_ID);
								strParentDescription = (String)mapObj.get(DomainConstants.SELECT_DESCRIPTION);
								strParentDefaultValue = (String)mapObj.get("attribute["+ATTRIBUTE_WMS_RECURRENCE+"]");
								if(UIUtil.isNotNullAndNotEmpty(strObjId))
								{
									strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
												"type_WMSCheckList",
												"",
												"policy_WMSCheckList",
												context.getVault().getName(),
												"-"
												);
												
									if(UIUtil.isNotNullAndNotEmpty(strNewObject)){
										DomainObject doNewBus = new DomainObject(strNewObject);
										if (strParentDescription != null && !"".equals(strParentDescription)) {
											doNewBus.setDescription(context,strParentDescription);
										}
										if (strParentDefaultValue != null && !"".equals(strParentDefaultValue)) {
											doNewBus.setAttributeValue(context,ATTRIBUTE_WMS_RECURRENCE,strParentDefaultValue);
										}
										DomainRelationship.connect(context, doWO, RELATIONSHIP_WMS_CHECKLIST, doNewBus);
										DomainRelationship.connect(context, doAMB, RELATIONSHIP_WMS_CHECKLIST, doNewBus);
									}							
								}
							}
						}
					
				}else{
					Map mTemp = null;
					for(int i=0;i<mlCheckLists.size();i++){
						mTemp = (Map)mlCheckLists.get(i);
						strObjId = (String)mTemp.get(DomainObject.SELECT_ID);
						if(UIUtil.isNotNullAndNotEmpty(strObjId))
						{
							DomainRelationship.connect(context, doAMB, RELATIONSHIP_WMS_CHECKLIST, new DomainObject(strObjId));
						}
					}
				}

				/*if(mapListObjects.size() > mlCheckLists.size()){
					for(int i=0;i<mapListObjects.size();i++){
						Map mTemp = (Map)mapListObjects.get(i);
						String strLibDescription = (String)mTemp.get(DomainObject.SELECT_DESCRIPTION);
						boolean bFound = false;
						for(int j=0;j<mlCheckLists.size();j++){
							Map mTemp1 = (Map)mlCheckLists.get(j);
							String strCLDescription = (String)mTemp1.get(j);
							if(UIUtil.isNotNullAndNotEmpty(strCLDescription) && UIUtil.isNotNullAndNotEmpty(strLibDescription) && strLibDescription.equals(strCLDescription)){
								bFound = true;
								break;
							}
						}
						if(bFound == false){
							strObjId = (String)mTemp.get(DomainConstants.SELECT_ID);
							strParentDescription = (String)mTemp.get(DomainConstants.SELECT_DESCRIPTION);
							strParentDefaultValue = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_RECURRENCE+"]");
							if(UIUtil.isNotNullAndNotEmpty(strObjId)){
								strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
												"type_WMSCheckList",
												"",
												"policy_WMSCheckList",
												context.getVault().getName(),
												"-"
												);
												
									if(UIUtil.isNotNullAndNotEmpty(strNewObject)){
										DomainObject doNewBus = new DomainObject(strNewObject);
										if (strParentDescription != null && !"".equals(strParentDescription)) {
											doNewBus.setDescription(context,strParentDescription);
										}
										if (strParentDefaultValue != null && !"".equals(strParentDefaultValue)) {
											doNewBus.setAttributeValue(context,ATTRIBUTE_WMS_RECURRENCE,strParentDefaultValue);
										}
										DomainRelationship.connect(context, doWO, RELATIONSHIP_WMS_CHECKLIST, doNewBus);
										DomainRelationship.connect(context, doAMB, RELATIONSHIP_WMS_CHECKLIST, doNewBus);
									}			
								
							}
						}
						
					}					
				}*/
				
			}
			
        }
        catch(Exception exception)
        {
            System.out.println("exception   "+exception.getMessage());
            exception.printStackTrace();
            throw exception;            
        }
    }

	 public Vector getCheckBox(Context context, String[] args) throws Exception {
         
         Vector returnVector = new Vector();
         try
         {
             Map programMap        = (Map)JPO.unpackArgs(args);
             MapList objectList = (MapList)programMap.get("objectList");
             int intSize = objectList.size();
			 
		     Map paramList      = (HashMap) programMap.get("paramList");
			 String strParentId = (String)paramList.get("objectId");
			 boolean bDisable = true;
			 if(UIUtil.isNotNullAndNotEmpty(strParentId)){
				 DomainObject doParent = new DomainObject(strParentId);
				 String strCurrent = (String)doParent.getInfo(context,DomainObject.SELECT_CURRENT);
				 if("Create".equals(strCurrent)){
					 bDisable = false;
				 }
			 }
             
             String strHtml        = new String();
             Map dataMap         = null;
             String strObjectId    = DomainConstants.EMPTY_STRING;
			 String strValidated     = DomainConstants.EMPTY_STRING;		
			 String strReferenceDocument     = DomainConstants.EMPTY_STRING;		
			 
             for (int i = 0; i < intSize ; i++) {
				 dataMap            = (Map) objectList.get(i);
				 strObjectId     = (String) dataMap.get("id");
				 strValidated    =    (String) dataMap.get("attribute["+ATTRIBUTE_WMS_CHECKED+"]");
				 strReferenceDocument = (String)dataMap.get("from[Reference Document]");
				 boolean bRefDocAttached = true;
				 if(UIUtil.isNotNullAndNotEmpty(strReferenceDocument) && "False".equalsIgnoreCase(strReferenceDocument)){
					 bRefDocAttached = false;
				 }
				 if(!bDisable && bRefDocAttached){
					 if("Yes".equals(strValidated)){
						strHtml="<input type='checkbox' name='CheckBox' value='Yes' checked='true' onchange= \"updateChecked('"+strObjectId+"')\"></input>";
					 }else{
						strHtml="<input type='checkbox' name='CheckBox' value='Yes' onchange= \"updateChecked('"+strObjectId+"')\"></input>";
					 }
				 }else{
					if("Yes".equals(strValidated)){
						strHtml="<input type='checkbox' name='CheckBox' value='Yes' checked='true' disabled='true'></input>";
					}else if(!bRefDocAttached){
						strHtml="<input title='Upload Files' type='checkbox' name='CheckBox' value='Yes' disabled='true'></input>";
					}else{
						strHtml="<input type='checkbox' name='CheckBox' value='Yes' disabled='true'></input>";
					}
				 }
				returnVector.add(strHtml);
             }
         }
         catch (Exception e) {
             e.printStackTrace();
         }
         
         return returnVector;
     }

	 
	  public int isCheckListComplete(Context context, String[] args) throws Exception{
    	 try {
    		 String strExistRel ="";
    		  String strAMBId = args[0];
    		  DomainObject domMBE = DomainObject.newInstance(context, strAMBId);	
    		  
			  StringList slObjectSelects = new StringList();
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_RECURRENCE+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_CHECKED+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_REFERENCE_TO+"]");
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_IS_LIBRARY+"]");
				slObjectSelects.add("from[Reference Document]");
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

				MapList mlCheckLists = domMBE.getRelatedObjects(context,
															RELATIONSHIP_WMS_CHECKLIST,
															TYPE_WMS_CHECKLIST,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															"attribute["+ATTRIBUTE_WMS_RECURRENCE+"] == 'One Time' || attribute["+ATTRIBUTE_WMS_RECURRENCE+"] == 'Recurring'",// objectWhere
															null);
					
				Map mTemp = null;
				String strChecked = DomainConstants.EMPTY_STRING;
				String strReferenceDocument = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlCheckLists.size();i++){
					mTemp = (Map)mlCheckLists.get(i);
					strChecked = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_CHECKED+"]");
					strReferenceDocument = (String)mTemp.get("from[Reference Document]");
					if("No".equals(strChecked)|| "False".equalsIgnoreCase(strReferenceDocument)){
						  Locale strLocale = context.getLocale();
						  String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.Alert.CompleteCheckList");
						  emxContextUtil_mxJPO.mqlNotice(context,strMessage);
						 return 1;
					}			
					
				}			  
			  
     	    }catch(Exception e) {
    		 e.printStackTrace();
			}
    	 
    	 
         return 0; 
      }
	
}