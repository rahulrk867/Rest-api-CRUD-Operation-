/** Name of the JPO    : ${CLASSNAME}
 ** Developed by    : DSIS 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to manage all code for Workorder
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/
import com.matrixone.apps.domain.util.MailUtil;
import org.joda.time.LocalDate;
import org.joda.time.Days;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Calendar;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import java.text.DateFormat;

import matrix.util.Pattern;
import matrix.util.StringList;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.Page;
import java.util.Vector;
import java.text.DecimalFormat;
import java.lang.Math;
 
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
 
import com.matrixone.apps.common.Company;


/**
 * The purpose of this JPO is to handle functionality of SOR
 * @author DSIS
 */
public class WMSEquipmentLibrary_mxJPO
{
    /**
     * Constructor.
     * @param context - the eMatrix <code>Context</code> object
     * @param args - holds no arguments
     * @throws Exception if the operation fails
     * @author DSIS
     */

    public WMSEquipmentLibrary_mxJPO(Context context, String[] args) throws Exception
    {
       //super(context,args);
    }
/**
     * Method to get the connected Work Orders from the Project
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command or form or table
     * @return mapListWorkOrders MapList containing the Work Order MBEs
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	@com.matrixone.apps.framework.ui.ProgramCallable 
	public static MapList getCivilLibraries(Context context, String[] args) throws Exception
	{
		MapList mlCivilLibraries = new MapList();
		
		StringList slEquipSels = new StringList();
		slEquipSels.add(DomainConstants.SELECT_NAME);
		slEquipSels.add(DomainConstants.SELECT_ID);
		slEquipSels.add(DomainConstants.SELECT_DESCRIPTION);
		slEquipSels.add(DomainConstants.SELECT_OWNER);
		slEquipSels.add("attribute[WMSEquipmentType]");
		slEquipSels.add("attribute[WMSYearOfProcurement]");
		slEquipSels.add("attribute[WMSEquipmentCost]");
		slEquipSels.add("attribute[WMSMakeAndModel]");
		slEquipSels.add("attribute[WMSOEMorSupplier]");
		slEquipSels.add("attribute[WMSSupplierAddress]");
		
		String sWhere = "attribute[WMSEquipmentType] == Civil";
		mlCivilLibraries = DomainObject.findObjects(context, 
												"WMSEquipmentLibrary", // type filter
												DomainConstants.QUERY_WILDCARD, // vault filter
												sWhere, // where clause
												slEquipSels);
		mlCivilLibraries.sortStructure("attribute[WMSYearOfProcurement]", "descending", "integer");
		return mlCivilLibraries;
	}

	@com.matrixone.apps.framework.ui.ProgramCallable
	public static MapList getMechanicalLibraries(Context context, String[] args) throws Exception
	{
		
		MapList mlMechanicalLibraries = new MapList();
		
		StringList slEquipSels = new StringList();
		slEquipSels.add(DomainConstants.SELECT_ID);
		slEquipSels.add(DomainConstants.SELECT_NAME);
		slEquipSels.add(DomainConstants.SELECT_DESCRIPTION);
		slEquipSels.add(DomainConstants.SELECT_OWNER);
		slEquipSels.add("attribute[WMSEquipmentType]");
		slEquipSels.add("attribute[WMSYearOfProcurement]");
		slEquipSels.add("attribute[WMSEquipmentCost]");
		slEquipSels.add("attribute[WMSMakeAndModel]");
		slEquipSels.add("attribute[WMSOEMorSupplier]");
		slEquipSels.add("attribute[WMSSupplierAddress]");
		
		String sWhere = "attribute[WMSEquipmentType] == Mechanical";
		mlMechanicalLibraries = DomainObject.findObjects(context, 
												"WMSEquipmentLibrary", // type filter
												DomainConstants.QUERY_WILDCARD, // vault filter
												sWhere, // where clause
												slEquipSels);
		mlMechanicalLibraries.sortStructure("attribute[WMSYearOfProcurement]", "descending", "integer");
		return mlMechanicalLibraries;		
	}

	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public static MapList getElectricalLibraries(Context context, String[] args) throws Exception
	{
		MapList mlElectricalLibraries = new MapList();
		StringList slEquipSels = new StringList();
		slEquipSels.add(DomainConstants.SELECT_NAME);
		slEquipSels.add(DomainConstants.SELECT_ID);
		slEquipSels.add(DomainConstants.SELECT_DESCRIPTION);
		slEquipSels.add(DomainConstants.SELECT_OWNER);
		slEquipSels.add("attribute[WMSEquipmentType]");
		slEquipSels.add("attribute[WMSYearOfProcurement]");
		slEquipSels.add("attribute[WMSEquipmentCost]");
		slEquipSels.add("attribute[WMSMakeAndModel]");
		slEquipSels.add("attribute[WMSOEMorSupplier]");
		slEquipSels.add("attribute[WMSSupplierAddress]");
		
		String sWhere = "attribute[WMSEquipmentType] == Electrical";
		mlElectricalLibraries = DomainObject.findObjects(context, 
												"WMSEquipmentLibrary", // type filter
												DomainConstants.QUERY_WILDCARD, // vault filter
												sWhere, // where clause
												slEquipSels);
		mlElectricalLibraries.sortStructure("attribute[WMSYearOfProcurement]", "descending", "integer");
		return mlElectricalLibraries;		
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public static MapList getITLibraries(Context context, String[] args) throws Exception
	{
		MapList mlITLibraries = new MapList();
		StringList slEquipSels = new StringList();
		slEquipSels.add(DomainConstants.SELECT_NAME);
		slEquipSels.add(DomainConstants.SELECT_ID);
		slEquipSels.add(DomainConstants.SELECT_DESCRIPTION);
		slEquipSels.add("attribute[WMSEquipmentType]");
		slEquipSels.add("attribute[WMSYearOfProcurement]");
		slEquipSels.add("attribute[WMSEquipmentCost]");
		slEquipSels.add("attribute[WMSMakeAndModel]");
		slEquipSels.add("attribute[WMSOEMorSupplier]");
		slEquipSels.add("attribute[WMSSupplierAddress]");
		
		String sWhere = "attribute[WMSEquipmentType] == IT";
		mlITLibraries = DomainObject.findObjects(context, 
												"WMSEquipmentLibrary", // type filter
												DomainConstants.QUERY_WILDCARD, // vault filter
												sWhere, // where clause
												slEquipSels);
		mlITLibraries.sortStructure("attribute[WMSYearOfProcurement]", "descending", "integer");
		return mlITLibraries;		
	}


	@com.matrixone.apps.framework.ui.ProgramCallable
	public static MapList getProjectLibraries(Context context, String[] args) throws Exception
	{
		
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		MapList mlCivilLibraries = new MapList();
		String strObjectId = (String)programMap.get("objectId");
		StringList slEquipSels = new StringList();
		slEquipSels.add(DomainConstants.SELECT_NAME);
		slEquipSels.add(DomainConstants.SELECT_ID);
		slEquipSels.add(DomainConstants.SELECT_DESCRIPTION);
		slEquipSels.add("attribute[WMSEquipmentType]");
		slEquipSels.add("attribute[WMSYearOfProcurement]");
		slEquipSels.add("attribute[WMSEquipmentCost]");
		slEquipSels.add("attribute[WMSMakeAndModel]");
		slEquipSels.add("attribute[WMSOEMorSupplier]");
		slEquipSels.add("attribute[WMSSupplierAddress]");
		
		StringList slRelSels = new StringList();
		slRelSels.add(DomainRelationship.SELECT_ID);
		
		DomainObject domProject = DomainObject.newInstance(context,strObjectId);
		mlCivilLibraries = domProject.getRelatedObjects(context, // matrix context
                		"WMSProjectEquipmentLibrary", // relationship pattern
                        "WMSEquipmentLibrary", // type pattern
                        slEquipSels, // object selects
                        slRelSels, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        "", // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);
		return mlCivilLibraries;
	}
		
	@com.matrixone.apps.framework.ui.CreateProcessCallable
    public Map createWMSEquipmentLibraryObject(Context context, String[] args) throws Exception 
	{
		boolean bIsContextPushed = false;
        HashMap requestMap  = (HashMap) JPO.unpackArgs(args);
		String sPolicyName = (String) requestMap.get("Policy");
		String sDescription = (String)requestMap.get("WMSEquipmentDetails");
		String sProjects = (String)requestMap.get("WMSRelatedProjectsOID");
		String strSlNo = "";
		
		String strNumberGenerator = MqlUtil.mqlCommand(context,"print bus 'eService Number Generator' 'type_WMSEquipmentLibrary' '' select id dump");
		if(UIUtil.isNotNullAndNotEmpty(strNumberGenerator)){
			DomainObject doNumGen = DomainObject.newInstance(context,strNumberGenerator);
			strSlNo = (String)doNumGen.getAttributeValue(context,"eService Next Number");
		}
		
		Map mAttribute = new HashMap();
		mAttribute.put("WMSMakeAndModel",(String)requestMap.get("WMSMakeAndModel"));
		mAttribute.put("WMSEquipmentCost",(String)requestMap.get("WMSEquipmentCost"));
		mAttribute.put("WMSEquipmentLibrarySequence",strSlNo);
		mAttribute.put("WMSEquipmentType",(String)requestMap.get("WMSEquipmentType"));
		mAttribute.put("WMSYearOfProcurement",(String)requestMap.get("WMSYearOfProcurement"));

        Map returnMap       = new HashMap();
        
        try {
            
            String symbolicTypeName = PropertyUtil.getAliasForAdmin(context, "Type", "WMSEquipmentLibrary", true);
            String symbolicPolicyName = PropertyUtil.getAliasForAdmin(context, "Policy",sPolicyName , true);
            
            DomainObject dNewObject = DomainObject.newInstance(context, "WMSEquipmentLibrary");
            String strGClassName = FrameworkUtil.autoName(context,
                                                        symbolicTypeName,
                                                        null,
                                                        symbolicPolicyName,
                                                        null,
                                                        null,
                                                        true,
                                                        true);                        
                            
            dNewObject.createObject(context, "WMSEquipmentLibrary", strGClassName, null,sPolicyName, null);
            String objectId = dNewObject.getId();
            returnMap.put("id", objectId);
        
            dNewObject.setId(objectId);
			dNewObject.setAttributeValues(context, mAttribute);
			
			StringList slProjects = new StringList();			
			if(UIUtil.isNotNullAndNotEmpty(sProjects))
			{
				slProjects = FrameworkUtil.split(sProjects, "|");
			}
			
			if(slProjects.size() > 0)
			{
				ContextUtil.pushContext(context);
				bIsContextPushed = true;
				for(int i = 0; i < slProjects.size(); i++)
				{
					String sProjectId = slProjects.get(i);
					DomainObject domParent = new DomainObject(sProjectId);
					DomainRelationship.connect(context, domParent, "WMSProjectEquipmentLibrary", dNewObject);
				}
			}
        } catch (Exception e) {
            throw new FrameworkException(e);
        }finally{
			if(bIsContextPushed)
				ContextUtil.popContext(context);
		}
        return returnMap;
    }	
	
	@com.matrixone.apps.framework.ui.CreateProcessCallable
    public Map createWMSEquipmentUnderProject(Context context, String[] args) throws Exception 
	{
		boolean bIsContextPushed = false;
        HashMap requestMap  = (HashMap) JPO.unpackArgs(args);
		String sPolicyName = (String) requestMap.get("Policy");
		String sDescription = (String)requestMap.get("WMSEquipmentDetails");
		String sProjectId = (String)requestMap.get("parentOID");
		
		String strSlNo = "";
		
		String strNumberGenerator = MqlUtil.mqlCommand(context,"print bus 'eService Number Generator' 'type_WMSEquipmentLibrary' '' select id dump");
		if(UIUtil.isNotNullAndNotEmpty(strNumberGenerator)){
			DomainObject doNumGen = DomainObject.newInstance(context,strNumberGenerator);
			strSlNo = (String)doNumGen.getAttributeValue(context,"eService Next Number");
		}
		
		Map mAttribute = new HashMap();
		mAttribute.put("WMSMakeAndModel",(String)requestMap.get("WMSMakeAndModel"));
		mAttribute.put("WMSEquipmentCost",(String)requestMap.get("WMSEquipmentCost"));
		mAttribute.put("WMSEquipmentLibrarySequence",strSlNo);
		mAttribute.put("WMSEquipmentType",(String)requestMap.get("WMSEquipmentType"));
		mAttribute.put("WMSYearOfProcurement",(String)requestMap.get("WMSYearOfProcurement"));

        Map returnMap  = new HashMap();
        
        try {
            
            String symbolicTypeName = PropertyUtil.getAliasForAdmin(context, "Type", "WMSEquipmentLibrary", true);
            String symbolicPolicyName = PropertyUtil.getAliasForAdmin(context, "Policy",sPolicyName , true);
            
            DomainObject dNewObject = DomainObject.newInstance(context, "WMSEquipmentLibrary");
            String strGClassName = FrameworkUtil.autoName(context,
                                                        symbolicTypeName,
                                                        null,
                                                        symbolicPolicyName,
                                                        null,
                                                        null,
                                                        true,
                                                        true);                        
                            
            dNewObject.createObject(context, "WMSEquipmentLibrary", strGClassName, null,sPolicyName, null);
            String objectId = dNewObject.getId();
            returnMap.put("id", objectId);
        
            dNewObject.setId(objectId);
			dNewObject.setAttributeValues(context, mAttribute);
			
			ContextUtil.pushContext(context);
			bIsContextPushed = true;
			DomainObject domParent = new DomainObject(sProjectId);
			DomainRelationship.connect(context, domParent, "WMSProjectEquipmentLibrary", dNewObject);

		}catch (Exception e) {
            throw new FrameworkException(e);
        }finally{
			if(bIsContextPushed)
				ContextUtil.popContext(context);
		}
        return returnMap;
    }	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public Map getEquipmentLibraryTypeRanges(Context context, String args[]) throws Exception
	{
		Map RangeMap = new HashMap();
		StringList slEquipmentTypeRanges = new StringList();
		slEquipmentTypeRanges.add("");
		Locale locale = context.getLocale();
		String sEquipLibTypes = EnoviaResourceBundle.getProperty(context,"WMS.EquipmentLibrary.Types");
		if(UIUtil.isNotNullAndNotEmpty(sEquipLibTypes))
		{
			StringList slEquipLibTypes = FrameworkUtil.split(sEquipLibTypes, ",");
			for(int i = 0; i < slEquipLibTypes.size(); i++){
				slEquipmentTypeRanges.add((String)slEquipLibTypes.get(i));
			}
		}
				
		RangeMap.put("field_choices", slEquipmentTypeRanges);
		RangeMap.put("field_display_choices", slEquipmentTypeRanges);
		return RangeMap;
	}
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAssociatedProjects(Context context, String args[]) throws Exception
	{
		MapList mlAssociatedProjects = new MapList();
		boolean bIsContextPushed = false;
		try{
		ContextUtil.pushContext(context);
		bIsContextPushed = true;
		
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strObjectId = (String)programMap.get("objectId");

		StringList slProjectSels = new StringList();
		slProjectSels.add(DomainObject.SELECT_ID);
		slProjectSels.add(DomainObject.SELECT_NAME);
		slProjectSels.add(DomainObject.SELECT_DESCRIPTION);
		StringList slRelSels = new StringList();
		slRelSels.add(DomainRelationship.SELECT_ID);
		
		DomainObject domEquipmentLib = DomainObject.newInstance(context,strObjectId);										
		mlAssociatedProjects = domEquipmentLib.getRelatedObjects(context, // matrix context
                		"WMSProjectEquipmentLibrary", // relationship pattern
                        "Project Space", // type pattern
                        slProjectSels, // object selects
                        slRelSels, // relationship selects
                        true, // to direction
                        false, // from direction
                        (short) 1, // recursion level
                        "", // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);
						
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(bIsContextPushed)
				ContextUtil.popContext(context);
		}
		return mlAssociatedProjects;
	}
	
	public Vector getEquipementProjects(Context context, String[] args)throws Exception{
		boolean bIsContextPushed = false;
		Vector colVector = new Vector();
		try { 
			ContextUtil.pushContext(context);
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramList = (HashMap) programMap.get("paramList");
			MapList objectList  = (MapList) programMap.get("objectList");
			StringBuilder sb= null;
			Iterator<Map> itr = objectList.iterator();
			String strId = DomainConstants.EMPTY_STRING;
			String strProjectNames = "";
			while(itr.hasNext()) {
				Map m = itr.next();
				strId = (String)m.get(DomainObject.SELECT_ID);
				strProjectNames = MqlUtil.mqlCommand(context,"print bus "+strId+" select to[WMSProjectEquipmentLibrary].from.name dump");
				colVector.add(strProjectNames);				
			}
			 
		} catch(Exception e) {
			e.printStackTrace();
		} finally{
			if(bIsContextPushed)
				ContextUtil.popContext(context);
		}
		return colVector;
		
	}
	
	public MapList getEquipmentLibrariesByTypeWithProjectInfo(Context context, String args[]) throws Exception
	{
		boolean bIsContextPushed = false;
		MapList mlReturn = new MapList();
		try{
			ContextUtil.pushContext(context);
			bIsContextPushed = true;
			String sWhere = args[0];
			
			MapList mlEquipmentLibraries = new MapList();
			if(sWhere != null)
			{
				StringList slEquipSels = new StringList();
				slEquipSels.add(DomainConstants.SELECT_NAME);
				slEquipSels.add(DomainConstants.SELECT_ID);
				slEquipSels.add(DomainConstants.SELECT_DESCRIPTION);
				slEquipSels.add("attribute[WMSYearOfProcurement]");
				slEquipSels.add("attribute[WMSEquipmentCost]");
				slEquipSels.add("attribute[WMSMakeAndModel]");
				slEquipSels.add("attribute[WMSOEMorSupplier]");
				slEquipSels.add("attribute[WMSSupplierAddress]");
				slEquipSels.add("attribute[WMSEquipmentLibrarySequence]");
				slEquipSels.add("attribute[WMSEquipmentLibraryTitle]");
				slEquipSels.add("attribute[WMSEquipmentType]");
				
				mlEquipmentLibraries = DomainObject.findObjects(context, 
														"WMSEquipmentLibrary", // type filter
														DomainConstants.QUERY_WILDCARD, // vault filter
														sWhere, // where clause
														slEquipSels);
				if(mlEquipmentLibraries.size() > 0)
				{
					Map mEquipLib = null;
					String sELid = "";
					String strProjectName = "";
					String strCost = "";
					DomainObject domEL = DomainObject.newInstance(context);
					for(int i = 0; i < mlEquipmentLibraries.size(); i++)
					{
						strProjectName = "";
						mEquipLib = (Map) mlEquipmentLibraries.get(i);
						sELid = (String) mEquipLib.get("id");
						strCost = (String) mEquipLib.get("attribute[WMSEquipmentCost]");
						
						if(WMSUtil_mxJPO.isNumeric(strCost)){
							strCost = WMSUtil_mxJPO.converToIndianCurrency(context,Double.parseDouble(strCost));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(sELid)){
							domEL.setId(sELid);
							StringList slProjects = domEL.getInfoList(context, "to[WMSProjectEquipmentLibrary].from.name");
							for(int j=0;j<slProjects.size();j++){
								if(j==0)
									strProjectName = (String)slProjects.get(j);
								else
									strProjectName = strProjectName+ ", "+(String)slProjects.get(j);
							}
						}						
						mEquipLib.put("Projects", strProjectName);
						mEquipLib.put("attribute[WMSEquipmentCost]", strCost);
						mlReturn.add(mEquipLib);
					}
					mlReturn.sort("attribute[WMSEquipmentLibrarySequence]", "ascending", "integer");
				}				
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(bIsContextPushed)
				ContextUtil.popContext(context);
		}
		
		return mlReturn;		 
	}
}

