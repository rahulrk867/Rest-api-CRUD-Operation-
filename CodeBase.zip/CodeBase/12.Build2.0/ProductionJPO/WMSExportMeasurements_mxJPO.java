import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringBufferInputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.util.XMLResourceDescriptor;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.jdom.transform.JDOMResult;

import matrix.db.Context;
import matrix.db.FileList;
import matrix.db.MQLCommand;
import matrix.db.RelationshipType;
import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringList;

/** Name of the JPO    : WMSExportMeasurements
 ** Developed by    : Matrixone 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to export measurements
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/


public class WMSExportMeasurements_mxJPO extends WMSConstants_mxJPO
{     

	    public static String ATTRIBUTE_TRAVERSE_ALTPATH = PropertyUtil.getSchemaProperty("attribute_TraverseAltPath");
		public static final String SELECT_ATTRIBUTE_TRAVERSE_ALTPATH = "attribute["+ATTRIBUTE_TRAVERSE_ALTPATH+"]";
		public static String PRIMARY_IMAGE_FROM_ALTPATH = PropertyUtil.getSchemaProperty("attribute_PrimaryImageFromAltPath");
		public static final String SELECT_ATTRIBUTE_PRIMARY_IMAGE_FROM_ALTPATH = "attribute["+PRIMARY_IMAGE_FROM_ALTPATH+"]";
		public static final String FORMAT_GENERIC = PropertyUtil.getSchemaProperty("format_generic");

		public static final String SELECT_GENERIC_FORMAT_FILES = "format[" + FORMAT_GENERIC + "].file.name";
	    
		public static final String ATTRIBUTE_PAYMENT_SCHEDULE_SEQUENCE = PropertyUtil.getSchemaProperty("attribute_WMSPaymentScheduleSequence");
		public static final String ATTRIBUTE_PERCENTAGE_WEIGHTAGE = PropertyUtil.getSchemaProperty("attribute_WMSPercentageOfWeightage");
		public static final String ATTRIBUTE_REDUCED_SOR_RATE = PropertyUtil.getSchemaProperty("attribute_WMSReducedSORRate");
		public static final String ATTRIBUTE_UNIT_OF_MEASUREMENT = PropertyUtil.getSchemaProperty("attribute_WMSUnitOfMeasure");
		public static final String TYPE_PAYMENT_ITEM = PropertyUtil.getSchemaProperty("type_WMSPaymentItem");
		public static final String RELATIONSHIP_MEASUREMENT_SES = PropertyUtil.getSchemaProperty("relationship_WMSMeasurementsToSES");
		public static final String ATTRIBUTE_SES_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSSESNumber");
		public static final String RELATIONSHIP_MEASUREMENT_GRN = PropertyUtil.getSchemaProperty("relationship_WMSMeasurementsToGRN");
		public static final String ATTR_GRN_NUMBER              = PropertyUtil.getSchemaProperty("attribute_WMSGRNNumber");
	/**
	 * Constructor.
	 * @param context - the eMatrix <code>Context</code> object
	 * @param args - holds no arguments
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */

	public WMSExportMeasurements_mxJPO(Context context, String[] args) throws Exception
	{
		super(context,args);
	}
	
	
	/**
     * Function to document object to write XML file
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
	private Document getXMLWriter() throws ParserConfigurationException {
		try
		{
		DocumentBuilderFactory docFactory 	= DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder 			= docFactory.newDocumentBuilder();
		Document docWrite 					= docBuilder.newDocument();
		return docWrite;
	}
		catch(ParserConfigurationException parserConfigurationException)
		{
			parserConfigurationException.printStackTrace();
			throw parserConfigurationException;
		}
	}
	/**
     * Function to get Work Order informations
     * @param context the eMatrix <code>Context</code> object
     * @param domOBjWO DomainObject instance of Work Order
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
	private Map<String, String> getWorkOrderInfo(Context context, DomainObject domOBjWO) throws FrameworkException {
		//TODO convert to Constants
		StringList strListWOInfoSelects = new StringList();
		strListWOInfoSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"]");
		strListWOInfoSelects.add("attribute["+ATTRIBUTE_WMS_PO_NUMBER+"]");
		strListWOInfoSelects.add("attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
		strListWOInfoSelects.add(DomainConstants.SELECT_DESCRIPTION);
		strListWOInfoSelects.add(DomainConstants.SELECT_NAME);
		strListWOInfoSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
		strListWOInfoSelects.add("to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.name");
		Map<String,String> mapData = domOBjWO.getInfo(context, strListWOInfoSelects);
		return mapData;
	}
	/**
     * Function to get the MBEs connected to the selected Work Order
     *
     * @param context the eMatrix <code>Context</code> object
     * @param domObj DomainObject instance of selected Object
     * @param strRelationship string value containing the relation with which the Object is connected
     * @return mapListMBEs MapList containing the MBEs connected to Work Order with ID
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
    private MapList getConnectedMBEs(Context context, DomainObject domObj,String strRelationship,String strWhere)
            throws FrameworkException {
        try
        {
		StringList strListBusSelects     = new StringList(6);
		strListBusSelects.add(DomainConstants.SELECT_ID);
		strListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_TYPE+"].value");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_FINALIZED+"].value");
		strListBusSelects.add("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"].value");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_DATE_OF_MEASUREMENT+"].value");
		StringList strListRelSelects     = new StringList(2);
		strListRelSelects.add(DomainRelationship.SELECT_ID);
		MapList mapListMBEs = domObj.getRelatedObjects(context, // matrix context
				strRelationship, // relationship pattern
				TYPE_WMS_MEASUREMENT_BOOK_ENTRY, // type pattern
				strListBusSelects, // object selects
				strListRelSelects, // relationship selects
				false, // to direction
				true, // from direction
				(short) 1, // recursion level
				strWhere, // object where clause
				DomainConstants.EMPTY_STRING, // relationship where clause
				0);
            return mapListMBEs;
        }
        catch(FrameworkException frameworkException)
        {
            throw frameworkException;
        }
    }
    /**
     * Function to get Measurement selects
     * @return select list of Measurements
     * @author WMS
     * @since 418
     */
    private SelectList getMeasurementInfoRelSelects() {
		SelectList selListRelSelects     = new SelectList(2);
		selListRelSelects.add(DomainRelationship.SELECT_ID);
		selListRelSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSUWD].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Title].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSIsDeduction].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSItemCoEfficientFactor].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEBreadth].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSIsManualQuanity].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBERadius].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBELength].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEFrequency].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEDepth].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute[WMSMBEActivityQuantity].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Assessment Comments].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.relationship["+RELATIONSHIP_MEASUREMENT_SES+"].to.attribute["+ATTRIBUTE_SES_NUMBER+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.relationship["+RELATIONSHIP_MEASUREMENT_GRN+"].to.attribute["+ATTR_GRN_NUMBER+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension1].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension2].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension3].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension4].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSShapeImage].value");
		
		return selListRelSelects;
	}
    /**
     * Function to get Item selects
     * @return select list of Item
     * @author WMS
     * @since 418
     */
	private SelectList getItemBusInfoSelects() {
		SelectList strListItemSelects     = new SelectList(3);
		strListItemSelects.add(DomainConstants.SELECT_ID);
		strListItemSelects.add(DomainConstants.SELECT_DESCRIPTION);
		strListItemSelects.add(DomainConstants.SELECT_TYPE);
		strListItemSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
		strListItemSelects.add("attribute["+ATTRIBUTE_PAYMENT_SCHEDULE_SEQUENCE+"]");
		strListItemSelects.add("attribute["+ATTRIBUTE_PERCENTAGE_WEIGHTAGE+"]");
		strListItemSelects.add("attribute["+ATTRIBUTE_REDUCED_SOR_RATE+"]");
		strListItemSelects.add("attribute["+ATTRIBUTE_UNIT_OF_MEASUREMENT+"]");
		
		return strListItemSelects;
	}
	
	/**
     * Function to get Item selects
     * @param context the eMatrix <code>Context</code> object
     * @args arguments for method includes work order id
     * @return generated file name
     * @author WMS
     * @since 418
     */
	public String createMeasurementBookExport(Context context, String[] args) throws Exception 
	{

		String strFileName = DomainConstants.EMPTY_STRING;
		String  strDocumentId = DomainConstants.EMPTY_STRING;
		try
		{
			Document docWrite = getXMLWriter();	
			String strTransPath = context.createWorkspace();
			String strObjectId 	=	 args[0];
			String strWOOID 	=	 args[1];
			String strType 	=	 args[2];
			
			if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType)){
				strWOOID = args[1];
			}else{
				strWOOID = args[0];
			}
			if(UIUtil.isNotNullAndNotEmpty(strWOOID))
			{
				DomainObject domObjWO = DomainObject.newInstance(context, strWOOID);
				Map<String, String> mapWOInfoData = getWorkOrderInfo(context, domObjWO);
				String strWorkOrderType = mapWOInfoData.get("attribute[WMSWorkOrderType]");
				String strWhere = "((current==Review)||(current==Submitted))";
				if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType)){
					strWhere = strWhere + " && id == '"+strObjectId+"'";
				}
				MapList mapListConnectedMBEs = getConnectedMBEs(context, domObjWO,RELATIONSHIP_WMS_WORK_ORDER_MBE,strWhere);
				SelectList strListItemSelects = getItemBusInfoSelects();
				SelectList selListRelSelects = getMeasurementInfoRelSelects();
				
				Iterator<Map<String,String>> iterator = mapListConnectedMBEs.iterator();
				Map<String,String> mapMBEData ;
				DateFormat formatter = DateFormat.getDateInstance(DateFormat.SHORT, context.getLocale());
				//get Work Order details xml
				Element docWOWrite = getWorkOrderDetails(docWrite,mapWOInfoData,context);
				ArrayList<Element>arrListMBEDetails = new ArrayList<Element>();
				StringList strListMeasurementBusSelects = new StringList(2);
				strListMeasurementBusSelects.add(DomainObject.SELECT_IMAGE_HOLDER_ID);
				strListMeasurementBusSelects.add(DomainObject.SELECT_ID);					

				Pattern typePattern = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
				typePattern.addPattern(TYPE_PAYMENT_ITEM);
				String strItemType = DomainConstants.EMPTY_STRING;
				while(iterator.hasNext())
				{
					mapMBEData = iterator.next();
					String strMBEOID = mapMBEData.get(DomainConstants.SELECT_ID);
					String strMBETitle = mapMBEData.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
					String strMeasurementDate =  mapMBEData.get("attribute["+ATTRIBUTE_WMS_DATE_OF_MEASUREMENT+"].value");
					Date dateMeasurementDate = eMatrixDateFormat.getJavaDate(strMeasurementDate);
					strMeasurementDate = formatter.format(dateMeasurementDate);
					if(UIUtil.isNotNullAndNotEmpty(strMBEOID))
					{
						Element docMBEWrite;
						DomainObject domObjMBE = DomainObject.newInstance(context,strMBEOID);
						MapList mapListMeasurements = domObjMBE.getRelatedObjects(context, // matrix context
								RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship pattern
								typePattern.getPattern(), // type pattern
								strListItemSelects, // object selects
								selListRelSelects, // relationship selects
								false, // to direction
								true, // from direction
								(short) 1, // recursion level
								DomainConstants.EMPTY_STRING, // object where clause
								DomainConstants.EMPTY_STRING, // relationship where clause
								0);
						Iterator<Map<String,String>> measurementItr = mapListMeasurements.iterator();
			    		Map<String,String> mapMeasurementData;
			    		while(measurementItr.hasNext())
			    		{
			    			mapMeasurementData = measurementItr.next();
			    			
			    			strItemType = mapMeasurementData.get(DomainConstants.SELECT_TYPE);
			    			
			    			if(TYPE_PAYMENT_ITEM.equals(strItemType)) {
			    				strItemType = TYPE_PAYMENT_ITEM;
			    			}
			    		}
						if(mapListMeasurements.size()>0)
						{
							if((UIUtil.isNotNullAndNotEmpty(strItemType))&&(strItemType!=null)&&(TYPE_PAYMENT_ITEM.equals(strItemType))) {
								docMBEWrite = getMBEPaymentMeasurementDetails(context,docWrite,mapListMeasurements,strMBETitle,strMeasurementDate);
								arrListMBEDetails.add(docMBEWrite);
							}
							else {
								System.out.println("getMBEMeasurementDetails---");
								docMBEWrite = getMBEMeasurementDetails(context,docWrite,mapListMeasurements,strMBETitle,strMeasurementDate);
								arrListMBEDetails.add(docMBEWrite);
							}
							//get MBE details xml
						}
					}
				}
				//combine xml of MBE details and Work Order details and create single xml
				Document docXmlSource = generateXMLForMeasurements(docWrite,arrListMBEDetails,docWOWrite);
				
				//get xsl file to generate pdf using xml
				MQLCommand mql = new MQLCommand();
				mql.open(context);
				if(TYPE_PAYMENT_ITEM.equals(strItemType)) {
					mql.executeCommand(context, "print program ExportPaymentMeasurement.xsl select code dump");
    			}
				else {
					mql.executeCommand(context, "print program ExportMeasurements.xsl select code dump");
    			}
				mql.close(context);
				Transformer transformer = TransformerFactory.newInstance().newTransformer(new StreamSource(new StringBufferInputStream(mql.getResult())));
				DOMSource in = new DOMSource(docXmlSource);
				//FopFactory fopFactory = FopFactory.newInstance();
				FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
				FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
				//pdf file name
				strFileName = "MBE Export-"+Calendar.getInstance().getTimeInMillis()+".pdf";
				OutputStream out = new java.io.FileOutputStream(strTransPath + File.separator+strFileName);
				Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);
				Result res = new SAXResult(fop.getDefaultHandler());
				System.out.println("in---------"+in);				
				System.out.println("res---------"+res);				
				transformer.transform(in, res);
				System.out.println("transformer111---------");
				String strOwner = context.getUser();
				try
				{
					//ContextUtil.pushContext(context);
				     strDocumentId = FrameworkUtil.autoName(context, CommonDocument.SYMBOLIC_type_Document, CommonDocument.SYMBOLIC_policy_Document);
					DomainObject domObj = DomainObject.newInstance(context, strDocumentId);
				    domObj.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, strFileName);
					
					if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType)){
						DomainObject doMBE = new DomainObject(strObjectId);
						doMBE.connect(context,new RelationshipType(DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT),true, DomainObject.newInstance(context,strDocumentId));
					}else{
						domObjWO.connect(context,new RelationshipType(DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT),true, DomainObject.newInstance(context,strDocumentId));
					}
					
					domObj.setOwner(context, strOwner);
					WMSImport_mxJPO.checkInFile(context, strDocumentId, strFileName, DomainConstants.EMPTY_STRING, context.getSession().getVault(),strTransPath);
				}
				catch(Exception exception)
				{
			
				}
				//finally
				//{
				//	 ContextUtil.popContext(context);
				//}
			}

		}
		catch(Exception e) {
			e.printStackTrace();

		}
		finally
		{
			DomainConstants.MULTI_VALUE_LIST.remove(SELECT_GENERIC_FORMAT_FILES);
			return strFileName;
		}
	}
	
	
	private Element getMBEPaymentMeasurementDetails(Context context, Document docWrite, MapList mapListPaymentItemDetails,
			String strMBETitle, String strMeasurementDate)throws Exception {
		
		Element embedetails = docWrite.createElement("mbedetails");
		Element embename = docWrite.createElement("mbename");
		Element embedate = docWrite.createElement("mbedate");
		
		embename.appendChild(docWrite.createTextNode(strMBETitle));
		embedate.appendChild(docWrite.createTextNode(strMeasurementDate));
		embedetails.appendChild(embename);
		embedetails.appendChild(embedate);
		
		StringList strListMeasurementBusSelects = new StringList(2);
		strListMeasurementBusSelects.add(DomainObject.SELECT_IMAGE_HOLDER_ID);		
		strListMeasurementBusSelects.add(DomainObject.SELECT_ID);
		
		for(int i=0;i<mapListPaymentItemDetails.size();i++)
		{
			Map map = (Map)mapListPaymentItemDetails.get(i);
			if(map!=null&&!map.isEmpty())
			{
				Element ePAYMENT_ITEM = docWrite.createElement("PAYMENT_ITEM");
				Element ePAYMENT_ITEM_SEQUENCE = docWrite.createElement("PAYMENT_ITEM_SEQUENCE");
				Element ePAYMENT_ITEM_NAME = docWrite.createElement("PAYMENT_ITEM_NAME");
				Element ePAYMENT_ITEM_WEIGHTAGE = docWrite.createElement("WEIGHTAGE_PERCENTAGE");
				Element ePAYMENT_ITEM_UNIT = docWrite.createElement("UNIT");
				Element ePAYMENT_ITEM_SUBMITTED_QUANTITY = docWrite.createElement("PAYMENT_ITEM_SUBMITTED_QUANTITY");
				
				ePAYMENT_ITEM_SEQUENCE.appendChild(docWrite.createTextNode((String)map.get("attribute["+ATTRIBUTE_WMS_PAYMENT_SCHEDULE_SEQUENCE+"]")));
				ePAYMENT_ITEM_NAME.appendChild(docWrite.createTextNode((String)map.get("attribute[Title]")));
				
				
				
				double dWtPct = Double.parseDouble((String)map.get("attribute["+ATTRIBUTE_PERCENTAGE_WEIGHTAGE+"]"));
				ePAYMENT_ITEM_WEIGHTAGE.appendChild(docWrite.createTextNode(new BigDecimal(dWtPct).setScale(2, BigDecimal.ROUND_UP).toPlainString()));
				
				ePAYMENT_ITEM_UNIT.appendChild(docWrite.createTextNode((String)map.get("attribute["+ATTRIBUTE_UNIT_OF_MEASUREMENT+"]")));
				double dSORQty = Double.parseDouble((String)map.get("attribute[WMSMBEActivityQuantity].value"));
				ePAYMENT_ITEM_SUBMITTED_QUANTITY.appendChild(docWrite.createTextNode(new BigDecimal(dSORQty).setScale(2, BigDecimal.ROUND_UP).toPlainString()));

				ePAYMENT_ITEM.appendChild(ePAYMENT_ITEM_SEQUENCE);
				ePAYMENT_ITEM.appendChild(ePAYMENT_ITEM_NAME);
				ePAYMENT_ITEM.appendChild(ePAYMENT_ITEM_WEIGHTAGE);
				ePAYMENT_ITEM.appendChild(ePAYMENT_ITEM_UNIT);
				ePAYMENT_ITEM.appendChild(ePAYMENT_ITEM_SUBMITTED_QUANTITY);
				
				
				StringList slper = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Title].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Title].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Title].value"));
				StringList strListMeasurementOIDs = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id"));
				Map<String, String> mapMeasurementImageHolder = getMeasurementImageHolderOIDs(context,strListMeasurementBusSelects, strListMeasurementOIDs);
				for(int ii=0;ii<strListMeasurementOIDs.size();ii++)
				{
					StringList slimg = getGenericFormatImageNames(context,mapMeasurementImageHolder,(String)strListMeasurementOIDs.get(ii));
					Element eimgholder = docWrite.createElement("imgholder");
					Element eparticular1 = docWrite.createElement("particular1");
					for(int p=0;p<slimg.size();p++)
					{
						
						Element eper1 = docWrite.createElement("per1");
						eper1.appendChild(docWrite.createTextNode((String)slper.get(ii)));
						
						Element eimg = docWrite.createElement("img");
						Element eimgsrc = docWrite.createElement("imgsrc");
						eimgsrc.appendChild(docWrite.createTextNode((String)slimg.get(p)));
						eimg.appendChild(eimgsrc);
						eimgholder.appendChild(eimg);
						
						eparticular1.appendChild(eimgholder);
						eparticular1.appendChild(eper1);
					}
					ePAYMENT_ITEM.appendChild(eparticular1);
				}
				embedetails.appendChild(ePAYMENT_ITEM);
			}
		}
		return embedetails;
	}


	/**
     * Function to get xml element for Work Order details
     *
     * @param Document docWrite object to create xml elements
     * @param Map mapWODetails - Work Order details
     * @return XML element of Work Order details
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	public Element getWorkOrderDetails(Document docWrite,Map mapWODetails,Context context) throws Exception
	{
		String strWorkOrderType = (String) mapWODetails.get("attribute[WMSWorkOrderType]");	
		Element ewoDetails= docWrite.createElement("wodetails");
		
		Element eDetails = docWrite.createElement("details");		
		Element ewolabel = docWrite.createElement("wolabel");
		Element ewovalue = docWrite.createElement("wovalue");


		Element eDetails1 = docWrite.createElement("details");		
		Element ewolabel1 = docWrite.createElement("wolabel");
		Element ewovalue1 = docWrite.createElement("wovalue");
		
		Element eDetails2 = docWrite.createElement("details");		
		Element ewolabel2 = docWrite.createElement("wolabel");
		Element ewovalue2 = docWrite.createElement("wovalue");
		
		
		Element eDetails3 = docWrite.createElement("details");		
		Element ewolabel3 = docWrite.createElement("wolabel");
		Element ewovalue3 = docWrite.createElement("wovalue");
		
		
		
		ewolabel.appendChild(docWrite.createTextNode("Name of Work"));
		ewovalue.appendChild(docWrite.createTextNode((String)mapWODetails.get("attribute[Title]")));
		eDetails.appendChild(ewolabel);
		eDetails.appendChild(ewovalue);
		
		ewolabel1.appendChild(docWrite.createTextNode("Agreement Number"));
		ewovalue1.appendChild(docWrite.createTextNode((String)mapWODetails.get("attribute["+ATTRIBUTE_WMS_PO_NUMBER+"]")));
		eDetails1.appendChild(ewolabel1);
		eDetails1.appendChild(ewovalue1);
		
		ewolabel2.appendChild(docWrite.createTextNode("Agreement By"));
		ewovalue2.appendChild(docWrite.createTextNode((String)mapWODetails.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"]")));
		eDetails2.appendChild(ewolabel2);
		eDetails2.appendChild(ewovalue2);
		
			
		if(UIUtil.isNotNullAndNotEmpty((String)mapWODetails.get("to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.name"))){
				ewolabel3.appendChild(docWrite.createTextNode("Name of Contractor"));
				ewovalue3.appendChild(docWrite.createTextNode((String)mapWODetails.get("to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.name")));
				eDetails3.appendChild(ewolabel3);
				eDetails3.appendChild(ewovalue3);
		}
	
		ewoDetails.appendChild(eDetails);
		ewoDetails.appendChild(eDetails1);
		ewoDetails.appendChild(eDetails2);
		
		return ewoDetails;
	}
	
	/**
     * Function to get xml element for Measurements  details
     * @param context the eMatrix <code>Context</code> object
     * @param Document docWrite object to create xml elements
     * @param Map mapMBEDetails - MBE details
     * @param String strMBETitle - MBE title
     * @param String strMeasurementDate - MBE Measurement date
     * @return XML element of MBE details
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	public Element getMBEMeasurementDetails(Context context,Document docWrite,MapList mapMBEDetails,String strMBETitle,String strMeasurementDate) throws Exception
	{		
		
		Element embedetails = docWrite.createElement("mbedetails");
		Element embename = docWrite.createElement("mbename");
		Element embedate = docWrite.createElement("mbedate");	
		try{
		embename.appendChild(docWrite.createTextNode(strMBETitle));
		embedate.appendChild(docWrite.createTextNode(strMeasurementDate));
		embedetails.appendChild(embename);
		embedetails.appendChild(embedate);

		StringList strListMeasurementBusSelects = new StringList(2);
		strListMeasurementBusSelects.add(DomainObject.SELECT_IMAGE_HOLDER_ID);		
		strListMeasurementBusSelects.add(DomainObject.SELECT_ID);		
		for(int i=0;i<mapMBEDetails.size();i++)
		{
			Map map = (Map)mapMBEDetails.get(i);
			if(map!=null&&!map.isEmpty())
			{
				Element eSOR = docWrite.createElement("SOR");
				Element eSOR_NAME = docWrite.createElement("SOR_NAME");
				Element eSOR_DES = docWrite.createElement("SOR_DES");
				Element eSOR_QUANTITY = docWrite.createElement("SOR_QUANTITY");

				eSOR_NAME.appendChild(docWrite.createTextNode((String)map.get("attribute[Title]")));
				eSOR_DES.appendChild(docWrite.createTextNode((String)map.get("description")));
				double dSORQty = Double.parseDouble((String)map.get("attribute[WMSMBEActivityQuantity].value"));	
				eSOR_QUANTITY.appendChild(docWrite.createTextNode(new BigDecimal(dSORQty).setScale(2, BigDecimal.ROUND_UP).toPlainString()));

				eSOR.appendChild(eSOR_NAME);
				eSOR.appendChild(eSOR_DES);
				eSOR.appendChild(eSOR_QUANTITY);
				
				StringList slRad = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBERadius].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBERadius].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBERadius].value"));
				StringList slRem = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Assessment Comments].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Assessment Comments].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Assessment Comments].value"));
				StringList sldep = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEDepth].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEDepth].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEDepth].value"));
				StringList slQty = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute[WMSMBEActivityQuantity].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute[WMSMBEActivityQuantity].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute[WMSMBEActivityQuantity].value"));
				StringList slper = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Title].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Title].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[Title].value"));
				StringList slcff = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSItemCoEfficientFactor].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSItemCoEfficientFactor].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSItemCoEfficientFactor].value"));
				StringList sluwd = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSUWD].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSUWD].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSUWD].value"));
				StringList slded = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSIsDeduction].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSIsDeduction].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSIsDeduction].value"));
				StringList slnum = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEFrequency].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEFrequency].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEFrequency].value"));
				StringList sllen = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBELength].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBELength].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBELength].value"));
				StringList slbre = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEBreadth].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEBreadth].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSMBEBreadth].value"));
				StringList slDim1 = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension1].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension1].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension1].value"));
				StringList slDim2 = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension2].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension2].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension2].value"));
				StringList slDim3 = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension3].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension3].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension3].value"));
				StringList slDim4 = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension4].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension4].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSDimension4].value"));
				StringList slShapeImage = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSShapeImage].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSShapeImage].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute[WMSShapeImage].value"));
				
				StringList strListMeasurementOIDs = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id"));
				
				Map<String, String> mapMeasurementImageHolder = getMeasurementImageHolderOIDs(context,strListMeasurementBusSelects, strListMeasurementOIDs);
				
				for(int ii=0;ii<strListMeasurementOIDs.size();ii++)
				{
					Element eparticular1 = docWrite.createElement("particular1");
					Element eper1 = docWrite.createElement("per1");
					eper1.appendChild(docWrite.createTextNode((String)slper.get(ii)));
					Element en1 = docWrite.createElement("n1");
					en1.appendChild(docWrite.createTextNode((String)slnum.get(ii)));					
					Element er1 = docWrite.createElement("r1");
					if(UIUtil.isNotNullAndNotEmpty((String)slDim1.get(ii))){
					er1.appendChild(docWrite.createTextNode((String)slDim1.get(ii)));
					}
					else
					{
						er1.appendChild(docWrite.createTextNode((String)slRad.get(ii)));
					}
					Element el1 = docWrite.createElement("l1");
					if(UIUtil.isNotNullAndNotEmpty((String)slDim2.get(ii))){
						el1.appendChild(docWrite.createTextNode((String)slDim2.get(ii)));
						}
						else
						{
							el1.appendChild(docWrite.createTextNode((String)sllen.get(ii)));
						}
					Element eb1 = docWrite.createElement("b1");
					if(UIUtil.isNotNullAndNotEmpty((String)slDim3.get(ii))){
						eb1.appendChild(docWrite.createTextNode((String)slDim3.get(ii)));
						}
						else
						{
							eb1.appendChild(docWrite.createTextNode((String)slbre.get(ii)));
						}
					Element ed1 = docWrite.createElement("d1");
					if(UIUtil.isNotNullAndNotEmpty((String)slDim4.get(ii))){
						ed1.appendChild(docWrite.createTextNode((String)slDim4.get(ii)));
						}
						else
						{
							ed1.appendChild(docWrite.createTextNode((String)sldep.get(ii)));
						}
					Element ece1 = docWrite.createElement("ce1");
					ece1.appendChild(docWrite.createTextNode((String)slcff.get(ii)));
					Element eq1 = docWrite.createElement("q1");
					String strQtry = "";
					if(slQty!= null && (slQty.size()>0&&slQty.get(0)!=null)){
					strQtry = (String)slQty.get(ii);
					if(UIUtil.isNotNullAndNotEmpty(strQtry)){
					double dQty = Double.parseDouble(strQtry);					
					eq1.appendChild(docWrite.createTextNode(new BigDecimal(dQty).setScale(2, BigDecimal.ROUND_UP).toPlainString()));
					}
					}
					Element erm1 = docWrite.createElement("rm1");
					erm1.appendChild(docWrite.createTextNode((String)slRem.get(ii)));
					Element eded1 = docWrite.createElement("ded1");
					eded1.appendChild(docWrite.createTextNode((String)slded.get(ii)));
					Element euwd1 = docWrite.createElement("uwd1");
					euwd1.appendChild(docWrite.createTextNode((String)sluwd.get(ii)));
					StringList slimg = getGenericFormatImageNames(context,mapMeasurementImageHolder,(String)strListMeasurementOIDs.get(ii));
					Element eimgholder = docWrite.createElement("imgholder");
					
					for(int p=0;p<slimg.size();p++)
					{
						Element eimg = docWrite.createElement("img");
						if(UIUtil.isNotNullAndNotEmpty((String)slShapeImage.get(ii)))
						{
							String strSVGContent = getFileForShape(context,(String)slShapeImage.get(ii),(String)slDim1.get(ii),(String)slDim2.get(ii),(String)slDim3.get(ii),(String)slDim4.get(ii));
							Element eshapeimg = docWrite.createElement("imgShape");
							eshapeimg.appendChild(docWrite.createTextNode(strSVGContent));
							eimg.appendChild(eshapeimg);
							eimgholder.appendChild(eimg);
						}						
						Element eimgsrc = docWrite.createElement("imgsrc");
						eimgsrc.appendChild(docWrite.createTextNode((String)slimg.get(p)));
						eimg.appendChild(eimgsrc);
						eimgholder.appendChild(eimg);						
					}
					if(UIUtil.isNotNullAndNotEmpty((String)slShapeImage.get(ii))&&slimg.size()==0)
					{
						Element eimg = docWrite.createElement("img");
						String strSVGContent = getFileForShape(context,(String)slShapeImage.get(ii),(String)slDim1.get(ii),(String)slDim2.get(ii),(String)slDim3.get(ii),(String)slDim4.get(ii));
						Element eshapeimg = docWrite.createElement("imgShape");
						eshapeimg.appendChild(docWrite.createTextNode(strSVGContent));
						eimg.appendChild(eshapeimg);
						eimgholder.appendChild(eimg);
					}
					
					eparticular1.appendChild(eimgholder);
					eparticular1.appendChild(eper1);
					eparticular1.appendChild(en1);
					eparticular1.appendChild(el1);
					eparticular1.appendChild(eb1);
					eparticular1.appendChild(ed1);
					eparticular1.appendChild(er1);
					eparticular1.appendChild(ece1);
					eparticular1.appendChild(eq1);
					eparticular1.appendChild(erm1);
					eparticular1.appendChild(eded1);
					eparticular1.appendChild(euwd1);
					eSOR.appendChild(eparticular1);
				}
				embedetails.appendChild(eSOR);
			}


		}
		}catch(Exception ex){
			System.out.println("ex-------"+ex.getMessage());
			ex.printStackTrace();
			throw ex;
		}
		return embedetails;
	}
	
	/**
     * Function to get xml to generate pdf
     * @param Document docWrite object to create xml elements
     * @param ArrayList<Element>arrMBEElement - MBE detail element
     * @param Element woElement - Work Order element
     * @return Document object for xml
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	public Document generateXMLForMeasurements(Document docWrite,ArrayList<Element>arrMBEElement,Element woElement) throws Exception
	{		
		Element ePage = docWrite.createElement("page");
		ePage.appendChild(woElement);
		for(int i=0;i<arrMBEElement.size();i++)
		{
			ePage.appendChild(arrMBEElement.get(i));
		}
		
		docWrite.appendChild(ePage);
		return docWrite;
	}
	
	/**
     * Function to Measurements images(location of images with name)
     * @param Context context
     * @param Map<String,String> mapMeasurementImageHolder - Image Holder object details
     * @param String strMeasurementOID - Measurement object id
     * @return StringList measurement file names 
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	private StringList getGenericFormatImageNames(Context context,
			Map<String,String> mapMeasurementImageHolder,String strMeasurementOID) throws Exception {
		StringList genericFormatImageNames = new StringList();
		StringList slFileNames = new StringList();
		String strWorkSpacePath = context.getWorkspacePath();
		StringList strListImageHolderBusSelects = new StringList(6);
		strListImageHolderBusSelects.add(SELECT_ATTRIBUTE_PRIMARY_IMAGE_FROM_ALTPATH);
		strListImageHolderBusSelects.add(SELECT_ATTRIBUTE_TRAVERSE_ALTPATH);
		strListImageHolderBusSelects.add(DomainObject.SELECT_MX_SMALL_IMAGE_FILE_NAMES);
		strListImageHolderBusSelects.add(SELECT_GENERIC_FORMAT_FILES);
		DomainConstants.MULTI_VALUE_LIST.add(SELECT_GENERIC_FORMAT_FILES);
		
		String strImageHolderOID = mapMeasurementImageHolder.get(strMeasurementOID);
		if(UIUtil.isNotNullAndNotEmpty(strImageHolderOID)){
		DomainObject domObjImageHolder = DomainObject.newInstance(context,strImageHolderOID);
		Map<String,Object> imgHolderObjMaplist = domObjImageHolder.getInfo(context, strListImageHolderBusSelects);
		
		Object obj = imgHolderObjMaplist.get(DomainObject.SELECT_MX_SMALL_IMAGE_FILE_NAMES);
		if(obj instanceof String) {
		    genericFormatImageNames = new StringList((String)imgHolderObjMaplist.get(SELECT_GENERIC_FORMAT_FILES));
		} else if(obj instanceof StringList) {
		    genericFormatImageNames =new StringList((StringList)imgHolderObjMaplist.get(SELECT_GENERIC_FORMAT_FILES));
		} else {
		    genericFormatImageNames = new StringList();
		}
		slFileNames = getFileName(context, genericFormatImageNames, domObjImageHolder, strWorkSpacePath);
		}
		
		
		return slFileNames;
	}
	
	/**
     * Function to get image holder id of specific measurement object
     * @param Context context
     * @param StringList strListImageHolderBusSelects - select for image holder
     * @param String strMeasurementOID - Measurement object id
     * @return StringList strListMeasurementOIDs - measurement ids
     * @return Map image holder id for specific measurement
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
	private Map<String, String> getMeasurementImageHolderOIDs(Context context, StringList strListImageHolderBusSelects,
			StringList strListMeasurementOIDs) throws FrameworkException {
		String oidsArray[] = new String[strListMeasurementOIDs.size()];
		strListMeasurementOIDs.toArray(oidsArray);

		MapList mapListImageHolder = DomainObject.getInfo(context, oidsArray, strListImageHolderBusSelects);
		Map<String,String> mapMeasurementImageHolder = new HashMap<String,String>(mapListImageHolder.size());
		Map<String,String> mapImageHolderData;
		Iterator<Map<String,String>> iteratorImageHolder = mapListImageHolder.iterator();
		while(iteratorImageHolder.hasNext())
		{
			mapImageHolderData =iteratorImageHolder.next();
			mapMeasurementImageHolder.put(mapImageHolderData.get(DomainObject.SELECT_ID), mapImageHolderData.get(DomainObject.SELECT_IMAGE_HOLDER_ID));
		}
		return mapMeasurementImageHolder;
	}
	
	/**
     * Function to get file name and location as per image holder object
     * @param Context context
     * @param StringList genericFormatImageNames - image names
     * @param DomainObject domObjImageHolder - image holder object
     * @return String strWorkSpacePath - Work space path
     * @return file name
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	private StringList getFileName(Context context,StringList genericFormatImageNames,DomainObject domObjImageHolder,String strWorkSpacePath) throws Exception
	{
		StringList slFileName = new StringList();
		FileList files = getGenericFormatFiles(genericFormatImageNames);
		domObjImageHolder.checkoutFiles(context, false, FORMAT_GENERIC, files, strWorkSpacePath);
		Iterator<String> iteratorImage = genericFormatImageNames.iterator();
		while(iteratorImage.hasNext())
		{
			String strImageName = iteratorImage.next();
			slFileName.add(strWorkSpacePath+ File.separator + strImageName);			
		}
		
		return slFileName;
	}
	
	/**
     * Function to get file name 
     * @param StringList genericFormatImageNames - image name
     * @return FileList
     * @author WMS
     * @since 418
     */
	private FileList getGenericFormatFiles(StringList genericFormatImageNames) {
		FileList files = new FileList();
		Iterator<String> iteratorImageFielNames = genericFormatImageNames.iterator();
		while(iteratorImageFielNames.hasNext())
		{
			String strFileName = iteratorImageFielNames.next();
			matrix.db.File file = new matrix.db.File(strFileName, FORMAT_GENERIC);
			files.addElement(file);
		}
		return files;
	}
	/**
     * Function to get file name to show shape on pdf  file 
     * @param Context
     * @param String filename
     * @param String dimensions
     * @return String full path of file
     * @author WMS
     * @since 418
     */
	public String getFileForShape(Context context,String sSVGFile,String sDim1,String sDim2,String sDim3,String sDim4) throws Exception
	{
		String sSVGContent=DomainConstants.EMPTY_STRING;
		
		String dim1="";
		String dim2="";
		String dim3="";
		String dim4="";
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		strpath = newFile.getCanonicalPath()+"\\webapps\\3dspace\\common\\images\\"+sSVGFile;
		newFile = new File(strpath);
		String parser = XMLResourceDescriptor.getXMLParserClassName();
		SAXSVGDocumentFactory f = new SAXSVGDocumentFactory(parser);
		java.net.URI localFileAsUri = newFile.toURI(); 
		String uri = localFileAsUri.toASCIIString();
		Document svgDoc = f.createDocument(uri);
		NodeList nodes = svgDoc.getChildNodes();
		Element elmD1 = (Element)svgDoc.getElementById("D1");
		Element elmD2 = (Element)svgDoc.getElementById("D2");
		Element elmD3 = (Element)svgDoc.getElementById("D3");
		Element elmD4 = (Element)svgDoc.getElementById("D4");
		NodeList nodeList = svgDoc.getElementsByTagName("svg");
		Node rootNode = (Node)nodeList.item(0);
		Element rootElement = (Element)rootNode;
		rootElement.setAttribute("width", "250");
		rootElement.setAttribute("height", "250");
		if(elmD1!=null)
		{
			dim1 = elmD1.getTextContent();
			elmD1.setTextContent(sDim1);
		}
		if(elmD2!=null)
		{
			dim2 = elmD2.getTextContent();
			elmD2.setTextContent(sDim2);
		}
		if(elmD3!=null)
		{
			dim3 = elmD3.getTextContent();
			elmD3.setTextContent(sDim3);
		}	
		if(elmD4!=null)
		{
			dim4 = elmD4.getTextContent();
			elmD4.setTextContent(sDim4);
		}	
		
		DOMSource domSource = new DOMSource(svgDoc);
		StringWriter writer = new StringWriter();
		String strWS = context.createWorkspace();
		String strFileName = "MBE Export-"+Calendar.getInstance().getTimeInMillis()+".svg";
		FileOutputStream outputStream = new FileOutputStream(strWS+File.separator+strFileName);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		StreamResult result = new StreamResult(outputStream);
		transformer.transform(domSource, result);
		String svg_URI_input = new File(strWS+File.separator+strFileName).toURI().toURL().toString();
		InputStream svg_istream = new FileInputStream(strWS+File.separator+strFileName);		 
		TranscoderInput input_svg_image = new TranscoderInput(svg_URI_input);        
        //Step-2: Define OutputStream to JPG file and attach to TranscoderOutput
        String strOutputFileName = "MBE Export-"+Calendar.getInstance().getTimeInMillis()+".jpg";
        OutputStream jpg_ostream = new FileOutputStream(strWS+File.separator+strOutputFileName);
        //TranscoderOutput output_jpg_image = new TranscoderOutput(jpg_ostream);              
        OutputStream png_ostream = new FileOutputStream(strWS+File.separator+strOutputFileName);
        TranscoderOutput output_png_image = new TranscoderOutput(png_ostream);              
        // Step-3: Create PNGTranscoder and define hints if required
        JPEGTranscoder my_converter = new JPEGTranscoder();        
        // Step-4: Convert and Write output
        my_converter.addTranscodingHint(JPEGTranscoder.KEY_QUALITY,new Float(.9));
        my_converter.transcode(input_svg_image, output_png_image);
        // Step 5- close / flush Output Stream
        png_ostream.flush();
        png_ostream.close();      
		sSVGContent=strWS+File.separator+strOutputFileName;		
		return sSVGContent;
	}
}
