/** Name of the JPO    : WMSMeasurementBookEntry
 ** Developed by    : Matrixone 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to create a Measurement Book Entry
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.Properties;
import matrix.db.Page;
import java.math.BigDecimal;

import org.apache.commons.io.FileUtils;
import org.joda.time.LocalDate;

import org.xml.sax.InputSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import org.w3c.dom.Document;

import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.common.Route;
import com.matrixone.apps.common.util.DocumentUtil;
import com.matrixone.apps.common.util.ImageManagerImageInfo;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;

import matrix.db.Context;
import matrix.db.File;
import matrix.db.FileItr;
import matrix.db.FileList;
import matrix.db.JPO;
import matrix.db.RelationshipType;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringItr;
import matrix.util.StringList;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;
import matrix.db.BusinessObject;
import matrix.db.AttributeList;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
/**
 * The purpose of this JPO is to create a Measurement Book Entry.
 * @author WMS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSMeasurementBookEntry_mxJPO extends WMSConstants_mxJPO
{
	 
    /**
     * Create a new ${CLASS:WMSMeasurementBookEntry} object from a given id.
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments.
     * @throws Exception if the operation fails
     * @author WMS
     * @since R418
     */

    public WMSMeasurementBookEntry_mxJPO (Context context, String[] args)
        throws Exception
    {
       super(context,args);
    }

    /**
     * Method to get the connected Objects on expansion
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command or form or table
     * @return mapListConnectedObject MapList containing the connected objects
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */    
    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getConnectedObjects(Context context, String[] args) throws Exception{
        MapList mapListObjects = new MapList();
        try {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strObjectOID = (String)programMap.get("objectId");
            if(UIUtil.isNotNullAndNotEmpty(strObjectOID))
            {
                DomainObject domObj = DomainObject.newInstance(context, strObjectOID);
                //mapListObjects = getConnectedObjects(context, domObj,strObjectOID);
                mapListObjects = getConnectedObjects(context, domObj,strObjectOID);
                // @Added to filter data by ATTRIBUTE_WMS_MBE_ITEM_TYPE Values Normal, Payment and Rebate - End
            }
            mapListObjects.sort("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"].value", ProgramCentralConstants.ASCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return mapListObjects;
    }

    /**
     * Method to get the connected Objects on expansion
     *
     * @param context the eMatrix <code>Context</code> object
     * @param domObj context domain Object
     * @param strObjectOID String value containing the context object ID
     * @return mapListConnectedObject MapList containing the connected objects
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */    
    private MapList getConnectedObjects(Context context, DomainObject domObj,String strObjectOID)
            throws Exception {
        try
        {
            MapList mapListObjects = new MapList();
            //String strExpandType = getExpandType(context, domObj);
            String strType = domObj.getInfo(context, DomainConstants.SELECT_TYPE);
            StringList strListBusSelects     = new StringList();
            strListBusSelects.add(DomainConstants.SELECT_ID);
            strListBusSelects.add(DomainConstants.SELECT_NAME);
            strListBusSelects.add(DomainConstants.SELECT_TYPE);
            strListBusSelects.add(DomainConstants.SELECT_CURRENT);
            strListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_ITEM_RATE_ESCALATION+"].value");
            strListBusSelects.add("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_PREV_QUANTITY+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_DEVIATION_QUANTITY+"]");
            strListBusSelects.add("from["+RELATIONSHIP_WMS_BOQ_SUB_ITEMS+"]");
            StringList strListRelSelects     = new StringList();
            strListRelSelects.add(DomainRelationship.SELECT_ID);
            Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
            patternType.addPattern(TYPE_WMS_SEGMENT);
            Pattern patternRel = new Pattern(RELATIONSHIP_BILL_OF_QUANTITY);        

            if(TYPE_WMS_WORK_ORDER.equals(strType))
            {
                mapListObjects = getWorkOrderSegment(context, strObjectOID);
                MapList mapListItems = getWorkOrderItems(context, strObjectOID);
                mapListObjects.addAll(mapListItems);
                insertKeyValue(mapListObjects, DomainConstants.SELECT_LEVEL, "1");
            }
            else
            {
                mapListObjects = domObj.getRelatedObjects(context, // matrix context
                		                                    RELATIONSHIP_BILL_OF_QUANTITY,                                     // relationship pattern
															patternType.getPattern(),    
															strListBusSelects, // object selects
															strListRelSelects, // relationship selects
															false, // to direction
															true, // from direction
															(short) 1, // recursion level
															DomainConstants.EMPTY_STRING, // object where clause
															DomainConstants.EMPTY_STRING, // relationship where clause
															0);
                String strSubmittedMBEQty=DomainConstants.EMPTY_STRING;
                String strCurrent=DomainConstants.EMPTY_STRING;
                String strSubItem=DomainConstants.EMPTY_STRING;
                for(int i=0;i<mapListObjects.size();i++) {
                	Map m = (Map) mapListObjects.get(i);
                	strSubmittedMBEQty=(String)m.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
                	strCurrent=(String)m.get(DomainConstants.SELECT_CURRENT);
                	strSubItem=(String)m.get("from["+RELATIONSHIP_WMS_BOQ_SUB_ITEMS+"]");
                 	if(Double.parseDouble(strSubmittedMBEQty)!=0 || !strCurrent.equalsIgnoreCase("Create")) {
                		//m.put("RowEditable", "readonly");
                		//if(strCurrent.equalsIgnoreCase("REVIEW"))
                		if(!strCurrent.equalsIgnoreCase("Create"))
                			m.put("disableSelection", "true");
                		
					}
					if(UIUtil.isNotNullAndNotEmpty(strSubItem) && "TRUE".equalsIgnoreCase(strSubItem)){
						m.put("styleRows", "ResourcePlanningYellowBackGroundColor");
					}
                }
                
            }
            return mapListObjects;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
    /**
     * Function to get the connected Segments to the Work Order
     *
     * @param context the eMatrix <code>Context</code> object
     * @param strWorkOrderOID String value containing the project object ID
     * @return mapListSegments MapList containing the Work Orders with name and ID
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
    private MapList getWorkOrderSegment(Context context, String strWorkOrderOID)
            throws FrameworkException {
        try
        {
            StringList objectSelects     = new StringList(3);
            objectSelects .add(DomainConstants.SELECT_ID);
            objectSelects .add(DomainConstants.SELECT_NAME);
            objectSelects .add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
            objectSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");
            
            DomainObject domObjWorkOrder  = DomainObject.newInstance(context, strWorkOrderOID);

            Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_BOOK);
            patternType.addPattern(TYPE_WMS_SEGMENT);
            MapList mapListSegments = domObjWorkOrder.getRelatedObjects(context,
            	                                                   	   RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
																		patternType.getPattern(),                                    // object pattern
																		false,                                                        // to direction
																		true,                                                       // from direction
																		(short)2,                                                      // recursion level
																		objectSelects,                                                 // object selects
																		null,                                                         // relationship selects
																		DomainConstants.EMPTY_STRING,                                // object where clause
																		DomainConstants.EMPTY_STRING,                                // relationship where clause
																		(short)0,                                                      // No expand limit
																		DomainConstants.EMPTY_STRING,                                // postRelPattern
																		TYPE_WMS_SEGMENT,                                                // postTypePattern
																		null);                                                      // postPatterns

            return mapListSegments;
        }
        catch(FrameworkException frameworkException)
        {
            throw frameworkException;
        }
    }
    /**
     * Function to get the connected Items to the Work Order directly
     *
     * @param context the eMatrix <code>Context</code> object
     * @param strWorkOrderOID String value containing the project object ID
     * @return mapListItems MapList containing the items with name and ID
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
    public MapList getWorkOrderItems(Context context, String strWorkOrderOID)
            throws FrameworkException {
        try
        {
            StringList objectSelects     = new StringList(3);
            objectSelects .add(DomainConstants.SELECT_ID);
            objectSelects .add(DomainConstants.SELECT_NAME);
            objectSelects .add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
            objectSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");
            
            DomainObject domObjWorkOrder  = DomainObject.newInstance(context, strWorkOrderOID);

            Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_BOOK);
            patternType.addPattern(TYPE_WMS_MEASUREMENT_TASK);
            MapList mapListItems = domObjWorkOrder.getRelatedObjects(context,
            		                                                    RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
																		patternType.getPattern(),                                    // object pattern
																		false,                                                        // to direction
																		true,                                                       // from direction
																		(short)2,                                                      // recursion level
																		objectSelects,                                                 // object selects
																		null,                                                         // relationship selects
																		DomainConstants.EMPTY_STRING,                                // object where clause
																		DomainConstants.EMPTY_STRING,                                // relationship where clause
																		(short)0,                                                      // No expand limit
																		DomainConstants.EMPTY_STRING,                                // postRelPattern
																		TYPE_WMS_MEASUREMENT_TASK,                                                // postTypePattern
																		null);                                                      // postPatterns

            return mapListItems;
        }
        catch(FrameworkException frameworkException)
        {
            throw frameworkException;
        }
    }
    /**
     * Method to insert value for the specific key in all map of the map list
     *
     * @param mapListConnectedMBEs MapList containing the connected objects
     * @param strKey String value containing the key
     * @param strValue String value containing the value
     * @author WMS
     * @since 418
     */    
    public static void insertKeyValue(MapList mapListConnectedMBEs, String strKey,
            String strValue) {
        Iterator<Map<String,String>> iterator = mapListConnectedMBEs.iterator();
        Map<String,String> mapData;
        while(iterator.hasNext())
        {
            mapData = iterator.next();
            mapData.put(strKey, strValue);
        }
    }
	
    // MBE - Start
    /** 
     * Method MBE Entry AutoName as Title
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.PostProcessCallable
    public HashMap setTitleMBE(Context context, String[] args) throws Exception {
             HashMap returnMap              = new HashMap();    
        try {
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
            HashMap paramMap               = (HashMap)programMap.get("paramMap");
            String strMBEOID             = (String) paramMap.get("objectId");
            
            if(UIUtil.isNotNullAndNotEmpty(strMBEOID))
            {
                StringList strListMBEInfo = new StringList();
                String strNameSelect = DomainConstants.SELECT_NAME;
                String strTitleNameSelect = "attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]";
                strListMBEInfo.add(strNameSelect);
                strListMBEInfo.add(strTitleNameSelect);
                strListMBEInfo.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value");
                strListMBEInfo.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_PO_NUMBER+"].value");
                strListMBEInfo.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
                strListMBEInfo.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
				
				String styIsFormalize =  EnoviaResourceBundle.getProperty(context, "WMS.Measurement.ConsiderFormalPolicy");
				
                DomainObject domObjMBE = DomainObject.newInstance(context,strMBEOID);
				ContextUtil.pushContext(context);
                Map<String, String> mapAMB = domObjMBE.getInfo(context, strListMBEInfo);
                ContextUtil.popContext(context);
				String strName =  DomainConstants.EMPTY_STRING;   
                String strTitleName =  DomainConstants.EMPTY_STRING;
                strName = mapAMB.get(strNameSelect);
                strTitleName = mapAMB.get(strTitleNameSelect);
				
				String strWOId = (String)mapAMB.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
				String strTypeOfContract = (String)mapAMB.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value");
				String strAgreementNumber = (String)mapAMB.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value");
				String strProjectCoce = (String)mapAMB.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
                
				StringList strListBusSelects = new StringList();
				strListBusSelects.add(DomainObject.SELECT_ID);
				DomainObject domObjWorkOrder = new DomainObject(strWOId);
				MapList mapListMBEs = domObjWorkOrder.getRelatedObjects(context, // matrix context
                        WMSConstants_mxJPO.RELATIONSHIP_WMS_WORK_ORDER_MBE, // relationship pattern
                        WMSConstants_mxJPO.TYPE_WMS_MEASUREMENT_BOOK_ENTRY, // type pattern
                        strListBusSelects, // object selects
                        null, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        DomainConstants.EMPTY_STRING, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);
				
				int intSequence = mapListMBEs.size();
				if(intSequence==0){
						intSequence = 1;
				}
				NumberFormat numberFormat = new DecimalFormat("000000");
				String strSequence = numberFormat.format(intSequence);
				
				if(UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && "EPC".equals(strTypeOfContract) == false && "true".equalsIgnoreCase(styIsFormalize)){					
					String strPrefix =  EnoviaResourceBundle.getProperty(context, "WMS.ProgressMeasurementBook.Numbering.Prefix");
					//strName = strProjectCoce.concat("-").concat(strPrefix).concat("-").concat(strSequence);					
					strName = strProjectCoce.concat("-").concat(strAgreementNumber).concat("-").concat(strSequence);					
					ContextUtil.pushContext(context);
					domObjMBE.setName(context,strName);
					domObjMBE.changePolicy(context, POLICY_WMS_MEASUREMENT_BOOK_ENTRY_NONEPC);
					ContextUtil.popContext(context);
				}else{
					String strPrefix =  EnoviaResourceBundle.getProperty(context, "WMS.MeasurementBook.Numbering.Prefix");
					//strName = strProjectCoce.concat("-").concat(strPrefix).concat("-").concat(strSequence);
					strName = strProjectCoce.concat("-").concat(strAgreementNumber).concat("-").concat(strSequence);
					ContextUtil.pushContext(context);
					domObjMBE.setName(context,strName);
					domObjMBE.setAttributeValue(context,ATTRIBUTE_WMS_FORMALIZED,"Yes");
					ContextUtil.popContext(context);
					
				}
				
				if(UIUtil.isNullOrEmpty(strTitleName))
                {
					ContextUtil.pushContext(context);
                    domObjMBE.setAttributeValue(context,ATTRIBUTE_WMS_WORK_ORDER_TITLE,strName);
					ContextUtil.popContext(context);
                }
            }
						
		/*	//Check if current date is in between 25th-current month to 5th-next month-start
			Locale strLocale = context.getLocale();
			String strMsg = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.MBE.CheckDate.Alert");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date today = new Date();
			Calendar cal = Calendar.getInstance();
			int curMonth = cal.get(cal.MONTH)+1;
			int curYear = (cal.get(cal.YEAR));
			Date CurrentMonthFirstLimit = sdf.parse(curYear+"-"+curMonth+"-5");
			Date CurrentMonthSecondLimit = sdf.parse(curYear+"-"+curMonth+"-25");
			if(today.after(CurrentMonthSecondLimit) && today.before(CurrentMonthFirstLimit)) {
				returnMap.put("Action","Stop");
				returnMap.put("Message",strMsg);
				return returnMap;
			}*/
			//Check if current date is in between 25th-current month to 5th-next month-end
			
             //returnMap.put("Message","Successfully created Measurement Entry ");
             returnMap.put("Action","success");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnMap;
    }
/** 
     * Method AMBE AutoName as Title
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.CreateProcessCallable
    public HashMap setTitle(Context context, String[] args) throws Exception {
             HashMap returnMap              = new HashMap();    
        try {
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
            HashMap paramMap               = (HashMap)programMap.get("paramMap");
            HashMap requestMap           = (HashMap)programMap.get("requestMap");
            //String strAbsMBEOID             = (String) paramMap.get("objectId");
            Locale strLocale = context.getLocale();
            StringList strListBusSelects     = new StringList(1);
            strListBusSelects.add(DomainConstants.SELECT_CURRENT);
            strListBusSelects.add(DomainConstants.SELECT_ID);
            String strWorkOrderOID        = (String) programMap.get("WorkOrder");
            String strDescription        = (String) programMap.get("Description");
			String strStartDate        = (String) programMap.get("StartDate");
			String strEndDate        = (String) programMap.get("EndDate");
            String strUser	= context.getUser();
            if(UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))//&&UIUtil.isNotNullAndNotEmpty(strAbsMBEOID))
            {
            	//Check if current date is in between 25th-current month to 5th-next month-start
				String strMsg = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.AMBE.CheckDate.Alert");
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				LocalDate ldToday=new LocalDate();
				int iDay = ldToday.getDayOfMonth();
		 	 	//if(iDay<=5 || iDay >=25) {
				//	returnMap.put("Action","Stop");
				//	returnMap.put("ErrorMessage",strMsg);
				//	return returnMap;
				//}
            	WMSSupplierDevelopmentPlan_mxJPO wmsSDP=new WMSSupplierDevelopmentPlan_mxJPO(context, args);
            	Map mArgs=new HashMap();
            	mArgs.put("WORKORDEROiD", strWorkOrderOID);
            	strMsg = wmsSDP.triggerAreMandatoryDocumentsUploaded(context,JPO.packArgs(mArgs));
            	if(!strMsg.isEmpty()) {
            		returnMap.put("Action","Stop");
                    returnMap.put("ErrorMessage",strMsg);
                    return returnMap;
            	}
                DomainObject domObjWorkOrder = DomainObject.newInstance(context,strWorkOrderOID);
				
				String strWorkOrderType = domObjWorkOrder.getAttributeValue(context,ATTRIBUTE_WMS_TYPE_OF_CONTRACT);
				ContextUtil.pushContext(context);
				String strProjectCoce = domObjWorkOrder.getInfo(context,"to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
				ContextUtil.popContext(context);
				if(UIUtil.isNotNullAndNotEmpty(strWorkOrderType)&& "EPC".equals(strWorkOrderType)){
					if(UIUtil.isNullOrEmpty(strStartDate) || UIUtil.isNullOrEmpty(strEndDate)){
						String strAlert = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.Alert.Message.StartEndDateForEPC");
						returnMap.put("Action","Stop");
						returnMap.put("ErrorMessage",strAlert);
						return returnMap;
					}
				}
				
                String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.AMBE.Statecheck.Alert");
                //Collect Only ABMEObjs which are in state Create,Submitted and Approved
                MapList mapListAMBEs = domObjWorkOrder.getRelatedObjects(context, // matrix context
                        WMSConstants_mxJPO.RELATIONSHIP_WORKORDER_ABSTRACT_MBE, // relationship pattern
                        WMSConstants_mxJPO.TYPE_ABSTRACT_MBE, // type pattern
                        strListBusSelects, // object selects
                        null, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        DomainConstants.EMPTY_STRING, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);
                Iterator<Map<String,String>> iterator = mapListAMBEs.iterator();
                Map<String,String> mapData;
				
                while(iterator.hasNext())
                {
                    mapData = iterator.next();
                    String strState  = mapData.get(DomainConstants.SELECT_CURRENT);
                    String objId  = mapData.get(DomainConstants.SELECT_ID);
                    if(!(STATE_PLAN.equals(strState)|| STATE_APPROVED.equals(strState) || "Cancelled".equals(strState)))
                     {
                         returnMap.put("Action","Stop");
                         returnMap.put("ErrorMessage",strMessage);
                         return returnMap;
                     }
					
                }
			
				//Check if current date is in between 25th-current month to 5th-next month-end
				
				String strMMOid  = FrameworkUtil.autoName(context, "type_WMSAbstractMeasurementBookEntry", "policy_WMSAbstractMeasurementBookEntry");
				DomainObject domObjAbsMBE  = DomainObject.newInstance(context, strMMOid);
				domObjAbsMBE.setDescription(context,strDescription);
				domObjAbsMBE.setOwner(context, strUser);
				returnMap.put("id",strMMOid);
				DomainRelationship domRel = DomainRelationship.connect(context, domObjWorkOrder, WMSConstants_mxJPO.RELATIONSHIP_WORKORDER_ABSTRACT_MBE, domObjAbsMBE);
				int intSequence = mapListAMBEs.size()+1;
				NumberFormat numberFormat = new DecimalFormat("000000");
				String strSequence = numberFormat.format(intSequence);
				//TODO use constant entry
				String strAgreementNumber = domObjWorkOrder.getAttributeValue(context, ATTRIBUTE_WMS_PO_NUMBER);
				//ContextUtil.popContext(context);
				String strPrefix =  EnoviaResourceBundle.getProperty(context, "WMS.AbstractBill.Numbering.Prefix");
				//String strName = strAgreementNumber.concat("-").concat(strPrefix).concat("-").concat(strSequence);
				//String strName = strProjectCoce.concat("-").concat(strPrefix).concat("-").concat(strSequence);
				String strName = strProjectCoce.concat("-").concat(strAgreementNumber).concat("-").concat(strSequence);
				domObjAbsMBE.setName(context,strName);

				//String strName = domObjAbsMBE.getInfo(context,DomainConstants.SELECT_NAME);
				Map<String,String> hashMapAttributes = new HashMap<String,String>();
				hashMapAttributes.put(DomainConstants.ATTRIBUTE_TITLE, strName);
				hashMapAttributes.put(ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER, String.valueOf(intSequence));
				
				if(UIUtil.isNotNullAndNotEmpty(strStartDate) && UIUtil.isNotNullAndNotEmpty(strEndDate)){
					hashMapAttributes.put(ATTRIBUTE_WMS_ABS_START_DATE, strStartDate);
					hashMapAttributes.put(ATTRIBUTE_WMS_ABS_END_DATE, strEndDate);
				}
				domObjAbsMBE.setAttributeValues(context,hashMapAttributes);
				
				String strRetentionObjectid = MqlUtil.mqlCommand(context,"print bus "+strMMOid+" select from["+RELATIONSHIP_WMSAMBRETENTION_RECOVERY+"].to.id dump");
				if(UIUtil.isNotNullAndNotEmpty(strRetentionObjectid)){
					DomainObject doRetention = new DomainObject(strRetentionObjectid);
					doRetention.setDescription(context,strDescription);
				}

			}
        } catch (Exception ex) {
            throw ex;
        }
        returnMap.put("Action","Success");
        
        return returnMap;
    }
    /**
     * Function to get the Work Order Field Map
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the Web Form
     * @return mapField Map<String,Object> containing the keys RangeValues and RangeDisplayValues
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public HashMap<String,Object> getProjectWorkOrder(Context context, String[] args) throws Exception
    {
        try
        {
            Map<String,Object> mapProgram = (Map<String,Object>)JPO.unpackArgs(args);
            Map requestMap = (HashMap)mapProgram.get("requestMap");
            String strPersonId = PersonUtil.getPersonObjectID(context);
            HashMap<String,Object> mapField         = new HashMap<String,Object>(3);
            if(UIUtil.isNotNullAndNotEmpty(strPersonId))
            {
                StringList slCustomerActualValList = new StringList();
                StringList slCustomerDisplayValList = new StringList();
                String sType = (String) requestMap.get("TypeActual");
			
				String strWherCond = "(attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]==EPC && current==Active && from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.current == Approved) || ((attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]!='EPC') && current==Active)";				
				String strWorkOrderCreateRole  = EnoviaResourceBundle.getProperty(context,"WMS.WorkOrder.CreateMeasurementAndBill.Role");
				String strWorkOrderCreateCompanyType  = EnoviaResourceBundle.getProperty(context,"WMS.WorkOrder.CreateMeasurementAndBill.CompanyType");
				StringList slCreateRoles = FrameworkUtil.split(strWorkOrderCreateRole,",");
								
				StringList objectSelects     = new StringList();
                objectSelects .add(DomainConstants.SELECT_ID);
                objectSelects .add(DomainConstants.SELECT_NAME);
                objectSelects .add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value");   

				StringList relSelect     = new StringList();	
				relSelect.add(DomainRelationship.SELECT_ID);				
				relSelect.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"].value");				
                
				DomainObject personObject  = DomainObject.newInstance(context,strPersonId);
				
				String strTypeOfComany = (String)personObject.getInfo(context,"to["+DomainRelationship.RELATIONSHIP_MEMBER+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_COMPANY+"].value");
				//if(UIUtil.isNotNullAndNotEmpty(strTypeOfComany) && strWorkOrderCreateCompanyType.contains(strTypeOfComany)){ 
					ContextUtil.pushContext(context);
					MapList mapListWorkOrders = personObject.getRelatedObjects(context, // matrix context
																				RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE, // relationship pattern
																				TYPE_WMS_WORK_ORDER, // type pattern
																				objectSelects, // object selects
																				relSelect, // relationship selects
																				false, // to direction
																				true, // from direction
																				(short) 1, // recursion level
																				strWherCond, // object where clause "current==Active"
																				DomainConstants.EMPTY_STRING, // relationship where clause
																				0);
					ContextUtil.popContext(context);
					Iterator<Map<String,String>> iterator = mapListWorkOrders.iterator();
					while(iterator.hasNext())
					{
						Map<String,String> mapWorkOrder = iterator.next();
						String strAccessRoleValue = (String)mapWorkOrder.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"].value");
						
						for(int i=0;i<slCreateRoles.size();i++){
							String strRole = (String)slCreateRoles.get(i);
							String strWOId = (String)mapWorkOrder.get(DomainConstants.SELECT_ID);
							String strWOTitle = (String)mapWorkOrder.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value");
							if(/*strAccessRoleValue.contains(strRole) && */ slCustomerActualValList.contains(strWOId) == false){
								slCustomerActualValList.add(strWOId);  
								slCustomerDisplayValList.add(strWOTitle);
							}
						}
					}
				//}
                slCustomerActualValList.add(DomainConstants.EMPTY_STRING);
                slCustomerDisplayValList.add(DomainConstants.EMPTY_STRING);
                mapField.put("field_choices", slCustomerActualValList);
                mapField.put("field_display_choices", slCustomerDisplayValList);
				
            }
            return mapField;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw new Exception(exception);
        }

    }
    /**
     * Method to connect the Work Order and MBE
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public void connectWorkOrder(Context context,String[]args)throws Exception
    {
        try
        {
			Map programMap                 = JPO.unpackArgs(args);
			HashMap paramMap             = (HashMap) programMap.get("paramMap");
			String strMBEOID             = (String) paramMap.get("objectId");
			String strWorkOrderOID             = (String) paramMap.get("New OID");
			if(UIUtil.isNullOrEmpty(strWorkOrderOID))
			{
				strWorkOrderOID = (String) paramMap.get("New Value");
			}
			if(UIUtil.isNotNullAndNotEmpty(strMBEOID)&& UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))
			{
				DomainObject domObjWO  = DomainObject.newInstance(context, strWorkOrderOID);
				DomainObject domObjMBE  = DomainObject.newInstance(context, strMBEOID);
				//DomainRelationship domRel = DomainRelationship.connect(context, domObjWO, WMSDomainConstant.RELATIONSHIP_WORKORDER_MBE, domObjMBE);
				DomainRelationship domRel = DomainRelationship.connect(context, domObjWO, RELATIONSHIP_WMS_WORK_ORDER_MBE, domObjMBE);
			}
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
    }
	// MBE - End
    
    
    public Map reloadMBEType(Context context, String[] args) throws Exception
    {
        Map argMap = (Map)JPO.unpackArgs(args);
        Map fieldValues = (Map)argMap.get("fieldValues");
        String sWorkOrderOid = (String) fieldValues.get("WorkOrder");
        String sWOCurrentState = "";
        if(UIUtil.isNotNullAndNotEmpty(sWorkOrderOid))
        {
        	ContextUtil.pushContext(context);
            DomainObject doWorkOrder = DomainObject.newInstance(context, sWorkOrderOid);
            sWOCurrentState = doWorkOrder.getInfo(context, "current");
            ContextUtil.popContext(context);
        }
        String sMBEType = "Running";
        if ("Complete".equals(sWOCurrentState)) {
            sMBEType = "Final";
        }
        Map fieldMap = new HashMap();
        fieldMap.put("SelectedValues", sMBEType);
        fieldMap.put("SelectedDisplayValues", sMBEType);
        return fieldMap;
    }
    
    /**
	 * Method to get the connected Activities under the MBE
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedTasks MapList containing the Task IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getMBEActivities (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListConnectedTasks = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			String strMBCurrentState = DomainConstants.EMPTY_STRING;
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
				mapListConnectedTasks = getMBEActivities(context, domObjMBE);
				strMBCurrentState = domObjMBE.getInfo(context, DomainConstants.SELECT_CURRENT);
            }
			insertKeyValue(mapListConnectedTasks, "MBCurrent", strMBCurrentState);
				
            return mapListConnectedTasks;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
	
	
	/**
     * Function to get the Tasks connected to the selected MBE
     * DON'T MODIFY
     * @param context the eMatrix <code>Context</code> object
     * @param domObjMBE DomainObject instance of selected Work Order 
     * @return mapListTasks MapList containing the MBEs connected to Work Order with ID
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
    private MapList getMBEActivities(Context context, DomainObject domObjMBE)
            throws FrameworkException {
        try
        {
            SelectList selListBusSelects     = new SelectList(13);
            selListBusSelects.add(DomainConstants.SELECT_ID);
            selListBusSelects.add(DomainConstants.SELECT_TYPE);
            selListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
            selListBusSelects.add("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
            selListBusSelects.add(DomainConstants.SELECT_REVISION);
            selListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            selListBusSelects.add("attribute["+ATTRIBUTE_WMS_BOQ_SERIAL_NUMBER+"]");
            selListBusSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
            selListBusSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
            selListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_COST+"]");
            selListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
            selListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]"); 
            selListBusSelects.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]"); 
            SelectList selListRelSelects     = new SelectList(2);
            selListRelSelects.add(DomainRelationship.SELECT_ID);
            selListRelSelects.add("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"]");
            selListRelSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
			   selListRelSelects.add("tomid[WMSActivityMeasurements].from.from[WMSMeasurementsToGRN].to.name");
            selListRelSelects.add("tomid[WMSActivityMeasurements].from.from[WMSMeasurementsToGRN].to.id");
            selListRelSelects.add("tomid[WMSActivityMeasurements].from.from[WMSMeasurementsToSES].to.name");
            selListRelSelects.add("tomid[WMSActivityMeasurements].from.from[WMSMeasurementsToSES].to.id");
			
            MapList mapListTasks = domObjMBE.getRelatedObjects(context, // matrix context
            		RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship pattern
                    TYPE_WMS_MEASUREMENT_TASK, // type pattern
                    selListBusSelects, // object selects
                    selListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 1, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
            /*            Iterator<Map<String,String>> iterator = mapListTasks.iterator();
            while(iterator.hasNext())
            {
                Map<String,String> mapData = iterator.next();
                String strSORConnection = mapData.get("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
            }*/
            return mapListTasks;
        }
        catch(FrameworkException frameworkException)
        {
            throw frameworkException;
        }
    }

    /**
  	 * Method to get the connected Activities/Payment under the MBE
       *
       * @param context the eMatrix <code>Context</code> object
       * @param args Packed program and request maps from the command
       * @return mapListConnectedTasks MapList containing the Task IDs
       * @throws Exception if the operation fails
       * @author WMS
       * @since 418
       */
      @com.matrixone.apps.framework.ui.ProgramCallable
    	public MapList getMBEPreviewBillActivities (Context context, String[] args) throws Exception 
      {
          try
          {
              MapList mapListConnectedTasks = new MapList();
  			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
  			String strMBCurrentState = DomainConstants.EMPTY_STRING;
              if(UIUtil.isNotNullAndNotEmpty(strObjectId))
              {
                  DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
                  mapListConnectedTasks = getMBEActivities(context, domObjMBE);
  				MapList mapListPaidPaymentScheduleItems = WMSPaymentSchedule_mxJPO.getPaidPaymentScheduleItems(context, domObjMBE);
                  mapListConnectedTasks.addAll(mapListPaidPaymentScheduleItems);
  				strMBCurrentState = domObjMBE.getInfo(context, DomainConstants.SELECT_CURRENT);
  			}
  			insertKeyValue(mapListConnectedTasks, "MBCurrent", strMBCurrentState);
  			return mapListConnectedTasks;
  		}
  		catch(Exception exception)
  		{
  			exception.printStackTrace();
  			throw exception;
  		}
  	}
	
      /**
       * Method to get the connected Items under the Work Order from MBE add existing 
       *
       * @param context the eMatrix <code>Context</code> object
       * @param args Packed program and request maps from the command
       * @return mapListConnectedTasks MapList containing the Task IDs
       * @throws Exception if the operation fails
       * @author WMS
       * @since 418
       */
      @com.matrixone.apps.framework.ui.IncludeOIDProgramCallable
      public StringList getRelatedActivitiesForAbstractMBE (Context context, String[] args) throws Exception 
      {
          try
          {
              StringList strListActivitiesOIDs = new StringList();
  			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
              String strRel = DomainConstants.EMPTY_STRING;
              if(UIUtil.isNotNullAndNotEmpty(strObjectId))
              {
                  StringList strListBusSelects     = new StringList(1);
                  strListBusSelects.add(DomainConstants.SELECT_ID);
                  strListBusSelects.add("to[WMSAbstractMBEActivities]");

                  DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
                  if(domObjMBE.isKindOf(context, TYPE_WMS_MEASUREMENT_BOOK_ENTRY)){
                      strRel= RELATIONSHIP_WMS_WORK_ORDER_MBE;
                  }
                  else if(domObjMBE.isKindOf(context, TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY)){
                      strRel=RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE;
                  }
                  MapList mapListConnectedActivities = getMBEActivities(context, domObjMBE);
  				StringList strListConnectdActivities = WMSUtil_mxJPO.convertToStringList(mapListConnectedActivities, DomainConstants.SELECT_ID);
                  String strWorkOrderOID = domObjMBE.getInfo(context, "to["+strRel+"].from.id");
                  if(UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))
                  {
                      String strMBOID = getMeasurementBookOID(context,strListBusSelects, strWorkOrderOID);
                      if(UIUtil.isNotNullAndNotEmpty(strMBOID))
                      {
                          StringList strListOBJ = getRelatedActivitiesForAbstractMBE(context,
                                  strListBusSelects, strMBOID);
                          strListActivitiesOIDs.addAll(strListOBJ);
                          strListActivitiesOIDs.removeAll(strListConnectdActivities);
                      }
                  }
              }
              return strListActivitiesOIDs;
          }
          catch(Exception exception)
          {
              exception.printStackTrace();
              throw exception;
          }
      }
      
      
      /**
       * Function to get the Tasks connected to the selected Measurement Book
       *
       * @param context the eMatrix <code>Context</code> object
       * @param strMBOID String value containing the Measurement Book OID 
       * @param strListBusSelects StringList containing the bus selects
       * @return strListOBJ StringList  containing the Measurement Activities OIDs
       * @throws FrameworkException if the operation fails
       * @author WMS
       * @since 418
       */
      private StringList getRelatedActivitiesForAbstractMBE(Context context,
              StringList strListBusSelects, String strMBOID)
                      throws FrameworkException {
          try
          {
              DomainObject domObjMB= DomainObject.newInstance(context, strMBOID);

              Pattern patternType = new Pattern(TYPE_WMS_SEGMENT);
              patternType.addPattern(TYPE_WMS_MEASUREMENT_TASK);
              MapList mapListActivities = domObjMB.getRelatedObjects(context,
                      RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
                      patternType.getPattern(),                                    // object pattern
                      false,                                                        // to direction
                      true,                                                       // from direction
                      (short)0,                                                      // recursion level
                      strListBusSelects,                                                 // object selects
                      null,                                                         // relationship selects
                      null,                                // object where clause
                      DomainConstants.EMPTY_STRING,                                // relationship where clause
                      (short)0,                                                      // No expand limit
                      DomainConstants.EMPTY_STRING,                                // postRelPattern
                      TYPE_WMS_MEASUREMENT_TASK,                                                // postTypePattern
                      null);                                                      // postPatterns

              Iterator<Hashtable<String, String>> Itr = mapListActivities.iterator();
              while (Itr.hasNext()) {
                  Hashtable<java.lang.String, java.lang.String> hashMap = (Hashtable<java.lang.String, java.lang.String>) Itr.next();
                  String strIsConnected = hashMap.get("to[WMSAbstractMBEActivities]");
                  if(strIsConnected.equalsIgnoreCase("true"))
                      Itr.remove();
              }

  			StringList strListOBJ = WMSUtil_mxJPO.convertToStringList(mapListActivities, DomainConstants.SELECT_ID);
              return strListOBJ;
          }
          catch(FrameworkException frameworkException)
          {
              throw frameworkException;
          }
      }

      
      
      /**
       * Function to get the Tasks connected to the selected Work Order
       *
       * @param context the eMatrix <code>Context</code> object
       * @param strWorkOrderOID String value containing the Work Order OID 
       * @param strListBusSelects StringList containing the bus selects
       * @return strMBOID String value containing the Measurement Book OID
       * @throws FrameworkException if the operation fails
       * @author WMS
       * @since 418
       */
      private String getMeasurementBookOID(Context context,
              StringList strListBusSelects, String strWorkOrderOID)
                      throws FrameworkException 
      {
          try
          {
              
              DomainObject domObjWO= DomainObject.newInstance(context, strWorkOrderOID);
              String strMBOID = domObjWO.getInfo(context, "from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");

              return strMBOID;
          }
          catch(FrameworkException frameworkException)
          {
              throw frameworkException;
          }
        }

      /**
       * Method to get the connected Objects on expansion of Items for Copy Measurements
       *
       * @param context the eMatrix <code>Context</code> object
       * @param args Packed program and request maps from the command or form or table
       * @return mapListConnectedObject MapList containing the connected objects
       * @throws Exception if the operation fails
       * @author WMS
       * @since 418
       */    
      @com.matrixone.apps.framework.ui.ProgramCallable
      public MapList getConnectedMeasurementObjects(Context context, String[] args) throws Exception
      {
          MapList mapListObjects = new MapList();
          try 
          {
              
              HashMap programMap = (HashMap) JPO.unpackArgs(args);
              String strObjectOID = (String)programMap.get("objectId");
              String strParentObjectOId = (String) programMap.get("parentOID");
              if(UIUtil.isNotNullAndNotEmpty(strObjectOID))
              {
                  StringList strListBusSelects     = new StringList(2);
                  strListBusSelects.add(DomainConstants.SELECT_ID);
                  strListBusSelects .add(DomainConstants.SELECT_LEVEL);
                  
                  SelectList selListRelSelects = new SelectList(1);
                  selListRelSelects.add(DomainRelationship.SELECT_ID);
                  String strWhere = DomainConstants.EMPTY_STRING;
                  if(strParentObjectOId.equals(strObjectOID))
                  {
                      strWhere ="("+ DomainConstants.SELECT_ID+"!="+strParentObjectOId +")&&(id==last.id)";
                  }
                  else
                  {
                  strWhere  = "(id==last.id)";
                  }
                  
                  DomainObject domObjTask= DomainObject.newInstance(context, strObjectOID);
                  mapListObjects = domObjTask.getRelatedObjects(context, // matrix context
                		  RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship pattern
                          TYPE_WMS_MEASUREMENT_BOOK_ENTRY, // type pattern
                          strListBusSelects, // object selects
                          selListRelSelects, // relationship selects
                          true, // to direction
                          false, // from direction
                          (short) 1, // recursion level
                          strWhere, // object where clause
                          DomainConstants.EMPTY_STRING, // relationship where clause
                          0);
                  //mapListObjects.add(0, mapListObjects.size());
              }
          }
          
          catch(Exception exception)
          {
              exception.printStackTrace();
              throw exception;
          }
          return mapListObjects;
  }
      /**
	 * Function to get the Abstarct MBEs connected to the selected Work Order
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjWO DomainObject instance of selected Work Order 
	 * @return mapListMBEs MapList containing the Abstract MBEs connected to Work Order with ID
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	public MapList getWorkOrderAbstractMBEs(Context context, DomainObject domObjWO)
			throws FrameworkException {
		boolean isContextPushed = false;
		try
		{
			StringList strListBusSelects     = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			strListBusSelects.add(DomainConstants.SELECT_OWNER);
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_ENABLE_ESIGN+"].value");
			StringList strListRelSelects     = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			strListBusSelects.add("attribute[atttibute_SequenceOrder].value");
            String strUser = context.getUser();
            //ContextUtil.pushContext(context);
			MapList membersList = WMSMeasurementBookItem_mxJPO.getWorkOrderAssignees(context,domObjWO);
		    StringList strListMembers     = new StringList();
			if(membersList.size()>0)
			{
			    Iterator<Map<String,String>> iterator  = membersList.iterator();
                Map<String,String> mapData;
				   
					while(iterator.hasNext())
					{
						mapData =  iterator.next();
						String strWOMemberName = mapData.get(DomainConstants.SELECT_NAME);
						strListMembers.add(strWOMemberName);
					}
			}		
            if(strListMembers.contains(strUser))
			{	
					isContextPushed = true;
					ContextUtil.pushContext(context);
			}		
          
			 //String strObjWhere = "current != Create";
            String strObjWhere = DomainConstants.EMPTY_STRING;
            String strOwner=DomainConstants.EMPTY_STRING;
            String strCurrent=DomainConstants.EMPTY_STRING;
            String strESignDisabled=DomainConstants.EMPTY_STRING;
			MapList mapListMBEs = domObjWO.getRelatedObjects(context, // matrix context
					WMSConstants_mxJPO.RELATIONSHIP_WORKORDER_ABSTRACT_MBE, // relationship pattern
					WMSConstants_mxJPO.TYPE_ABSTRACT_MBE, // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					strObjWhere, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
			
			Iterator<Map> itrListMBEs = mapListMBEs.iterator();
			MapList mlFiltered=new MapList();
			while(itrListMBEs.hasNext()) {
				 Map m = itrListMBEs.next();
				 strOwner=(String) m.get(DomainConstants.SELECT_OWNER);
				 strCurrent=(String) m.get(DomainConstants.SELECT_CURRENT);
				 strESignDisabled=(String) m.get("attribute["+ATTRIBUTE_WMS_ENABLE_ESIGN+"].value");
				 if(!strOwner.equalsIgnoreCase(strUser) && strCurrent.equalsIgnoreCase("Create")) {
					continue;
				 }
				 
				 if(UIUtil.isNotNullAndNotEmpty(strESignDisabled) && "No".equalsIgnoreCase(strESignDisabled)){
					 m.put("styleRows", "ResourcePlanningYellowBackGroundColor");
				 }
				 mlFiltered.add(m);
			}
			
			//ContextUtil.popContext(context);
			return mlFiltered;
		}
		catch(FrameworkException frameworkException)
		{
			throw frameworkException;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}

		}
	}
      /**
       * Method to get the connected Active Work Orders from the context user
       *
       * @param context the eMatrix <code>Context</code> object
       * @param args Packed program and request maps from the command or form or table
       * @return mapListWorkOrders MapList containing the Work Order data
       * @throws Exception if the operation fails
       * @author WMS
       * @since 418
       */
      @com.matrixone.apps.framework.ui.ProgramCallable
      public MapList getActiveWorkOrders (Context context, String[] args) throws Exception 
      {
      	try
      	{

      		String strPersonId = PersonUtil.getPersonObjectID(context,context.getUser());
      		String strWherCond = DomainConstants.SELECT_CURRENT+"==Active";
      		MapList mapListWorkOrders = getContextUserWorkOrders(context, strPersonId, strWherCond);
      		return mapListWorkOrders;
      	}
      	catch(Exception exception)
      	{
      		exception.printStackTrace();
      		throw exception;
      	}
      }
      
      
      /**
       * Method to get the connected Work Orders from the context user
       *
       * @param context the eMatrix <code>Context</code> object
       * @param strPersonId context user BusOID
       * @param strWherCond String value containing the where cause
       * @return mapListWorkOrders MapList containing the Work Order data
       * @throws FrameworkException if the operation fails
       * @author WMS
       * @since 418
       */
      private MapList getContextUserWorkOrders(Context context, String strPersonId, String strWherCond)
      		throws FrameworkException {
      	try
      	{
      		MapList mapListWorkOrders = new MapList();
      		if(UIUtil.isNotNullAndNotEmpty(strPersonId))
      		{
      			DomainObject domObjPerson = DomainObject.newInstance(context, strPersonId);
      			StringList strListBusSelects     = new StringList();
      			strListBusSelects.add(DomainConstants.SELECT_ID);
      			strListBusSelects.add(DomainConstants.SELECT_TYPE);
				strListBusSelects.add("attribute[WMSWorkorderTitle]");
				strListBusSelects.add("attribute[WMSValueOfContract]");
				strListBusSelects.add("attribute[WMSCompletionDueDate]");
				strListBusSelects.add("attribute[WMSWOUser]");
				strListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
      			StringList strListRelSelects     = new StringList(1);
      			strListRelSelects.add(DomainRelationship.SELECT_ID);
      			mapListWorkOrders = domObjPerson.getRelatedObjects(context, // matrix context
      					RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE, // relationship pattern
      					TYPE_WMS_WORK_ORDER, // type pattern
      					strListBusSelects, // object selects
      					strListRelSelects, // relationship selects
      					false, // to direction
      					true, // from direction
      					(short) 1, // recursion level
      					strWherCond, // object where clause "current==Active"
      					DomainConstants.EMPTY_STRING, // relationship where clause
      					0);   
      		}
      		return mapListWorkOrders;
      	}
      	catch(FrameworkException frameworkException)
      	{
      		frameworkException.printStackTrace();
      		throw frameworkException;
      	}
      }
      
      /**
       * Method to get the connected completed Work Orders from the context user
       *
       * @param context the eMatrix <code>Context</code> object
       * @param args Packed program and request maps from the command or form or table
       * @return mapListWorkOrders MapList containing the Work Order data
       * @throws Exception if the operation fails
       * @author WMS
       * @since 418
       */
      @com.matrixone.apps.framework.ui.ProgramCallable
      public MapList getCompleteWorkOrders (Context context, String[] args) throws Exception 
      {
      	try
      	{

      		String strPersonId = PersonUtil.getPersonObjectID(context,context.getUser());
      		String strWherCond = DomainConstants.SELECT_CURRENT+"==Complete";
      		MapList mapListWorkOrders = getContextUserWorkOrders(context, strPersonId, strWherCond);
      		return mapListWorkOrders;
      	}
      	catch(Exception exception)
      	{
      		exception.printStackTrace();
      		throw exception;
      	}
      }
      /**
	 * Method to get the connected Abstract MBEs under the Work Order
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command or form or table
	 * @return mapListConnectedMBEs MapList containing the Abstract MBEs IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getWorkOrderAbstractMBEs (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListConnectedMBEs = new MapList();
			 
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjWO = DomainObject.newInstance(context, strObjectId);
				mapListConnectedMBEs = getWorkOrderAbstractMBEs(context, domObjWO);
			}
		 
			return mapListConnectedMBEs;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
    /**
      * Method to get the connected all Work Orders from the context user
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command or form or table
      * @return mapListWorkOrders MapList containing the Work Order data
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public MapList getAllWorkOrders (Context context, String[] args) throws Exception 
     {
     	try
     	{

     		String strPersonId = PersonUtil.getPersonObjectID(context,context.getUser());
     		String strWherCond = DomainConstants.EMPTY_STRING;
     		MapList mapListWorkOrders = getContextUserWorkOrders(context, strPersonId, strWherCond);
     		return mapListWorkOrders;
     	}
     	catch(Exception exception)
     	{
     		exception.printStackTrace();
     		throw exception;
     	}
     }
     
     
     @com.matrixone.apps.framework.ui.ProgramCallable
     public  MapList getAllMyWIPMBE(Context context, String []  args)    throws Exception {
         MapList mlReturnList     =     new MapList();
         try
         {
             String strVault = context.getVault().getName();
             StringList strListBusInfo = new StringList(2);
             strListBusInfo.add(DomainConstants.SELECT_ID);
             strListBusInfo.add(DomainConstants.SELECT_CURRENT);
             String strWhere =    DomainConstants.SELECT_OWNER+"=='"+context.getUser()+"' && current==Create";
             mlReturnList =  DomainObject.findObjects(
                                             context,
                                             TYPE_WMS_MEASUREMENT_BOOK_ENTRY,
                                             DomainConstants.QUERY_WILDCARD,
                                             DomainConstants.QUERY_WILDCARD,
                                             DomainConstants.QUERY_WILDCARD,
                                             strVault,
                                             strWhere,               // where expression
                                             DomainConstants.EMPTY_STRING,
                                             false,
                                             strListBusInfo, // object selects
                                             (short) 0);       // limit
                 //enableSelection(mapListContractorAbsMBEs);
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
         return mlReturnList;
     }
	 
     @com.matrixone.apps.framework.ui.ProgramCallable
     public  MapList getAllMyMBEForApproval(Context context, String [] args)    throws Exception {
         MapList mlReturnList     =     new MapList();
         MapList mlFinalReturnList     =     new MapList();
         try
         {
             String strVault = context.getVault().getName();
             
             
             StringList strListBusInfo = new StringList(2);
             strListBusInfo.add(DomainConstants.SELECT_ID);
             strListBusInfo.add(DomainConstants.SELECT_CURRENT);
            // strListBusInfo.add("attribute["+ATTRIBUTE_WMS_CONTRACTOR_REVIEW+"]");
             
             StringList slRelSelect     =    new StringList();
             slRelSelect.add(DomainRelationship.SELECT_ID);
             
             String strWhere =    "current==Review || current==Formalized";
             String strRelWhere     =     DomainConstants.EMPTY_STRING;
             com.matrixone.apps.common.Person contextPerson = com.matrixone.apps.common.Person.getPerson(context);
             
             
             Pattern patternRel  = new Pattern(DomainConstants.RELATIONSHIP_ROUTE_TASK);
             patternRel.addPattern(DomainConstants.RELATIONSHIP_OBJECT_ROUTE);
             patternRel.addPattern(DomainConstants.RELATIONSHIP_PROJECT_TASK);

             Pattern patternType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
             patternType.addPattern(DomainConstants.TYPE_ROUTE);    
             patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK_ENTRY);  
             
             strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+DomainConstants.TYPE_INBOX_TASK+"' && current==Assigned )||("+DomainConstants.SELECT_TYPE+"=="+DomainConstants.TYPE_ROUTE+")||("+DomainConstants.SELECT_TYPE+"=="+TYPE_WMS_MEASUREMENT_BOOK_ENTRY+" && current==Review)";


             mlReturnList         = contextPerson.getRelatedObjects(context,
                                                             //patternRel.getPattern(),  // relationship pattern
                                                             patternRel.getPattern(),
                                                             patternType.getPattern(),  // object pattern
                                                             true,                                                        // to direction
                                                             true,                                                       // from direction
                                                             (short)0,                                                      // recursion level
                                                             strListBusInfo,                                                 // object selects
                                                             slRelSelect,                                                         // relationship selects
                                                             strWhere,                                // object where clause
                                                             strRelWhere,                                // relationship where clause
                                                             (short)0,                                                      // No expand limit
                                                             DomainConstants.EMPTY_STRING,                                // postRelPattern
                                                             TYPE_WMS_MEASUREMENT_BOOK_ENTRY,                                                // postTypePattern
                                                             null);
             
             
             String strOwnWhere =    DomainConstants.SELECT_OWNER+"=='"+context.getUser()+"' && (current==Review || current==Formalized)";
             //String strOwnWhere =    "(current==Review || current==Formalized) && from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name == '"+context.getUser()+"'";
             MapList mlOwnMBList =  DomainObject.findObjects(
                                             context,
                                             TYPE_WMS_MEASUREMENT_BOOK_ENTRY,
                                             DomainConstants.QUERY_WILDCARD,
                                             DomainConstants.QUERY_WILDCARD,
                                             DomainConstants.QUERY_WILDCARD,
                                             strVault,
                                             strOwnWhere,               // where expression
                                             DomainConstants.EMPTY_STRING,
                                             false,
                                             strListBusInfo, // object selects
                                             (short) 0);
             
             
             mlReturnList.addAll(mlOwnMBList);
			 StringList slObjIds = new StringList();
			 String strId = DomainConstants.EMPTY_STRING;
			 Map mTemp = null;
			 for(int i=0;i<mlReturnList.size();i++){
				 mTemp = (Map)mlReturnList.get(i);
				 strId = (String)mTemp.get(DomainObject.SELECT_ID);
				 if(slObjIds.contains(strId) == false){
					 slObjIds.add(strId);
					 mlFinalReturnList.add(mTemp);
				 }
			 }
			 
			 
           insertKeyValue(mlFinalReturnList, DomainConstants.SELECT_LEVEL, "1");  
     
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
         return mlFinalReturnList;
     }
     /**
	 * Method to get the connected Abstract MBEs under the PMCMyDesk
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command or form or table
	 * @return mapListConnectedMBEs MapList containing the Abstract MBEs IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public  MapList getAllMyWIPAbstractMBE(Context context, String []  args)    throws Exception {
        MapList mlReturnList     =     new MapList();
        try
        {
            String strVault = context.getVault().getName();
            StringList strListBusInfo = new StringList(2);
            strListBusInfo.add(DomainConstants.SELECT_ID);
            strListBusInfo.add(DomainConstants.SELECT_CURRENT);
            String strWhere =    DomainConstants.SELECT_OWNER+"=='"+context.getUser()+"' && current==Create";
            //String strWhere =   "current==Create";
            mlReturnList =  DomainObject.findObjects(
                                            context,
                                            WMSConstants_mxJPO.TYPE_ABSTRACT_MBE,
                                            DomainConstants.QUERY_WILDCARD,
                                            DomainConstants.QUERY_WILDCARD,
                                            DomainConstants.QUERY_WILDCARD,
                                            strVault,
                                            strWhere,               // where expression
                                            DomainConstants.EMPTY_STRING,
                                            false,
                                            strListBusInfo, // object selects
                                            (short) 0);       // limit
                //enableSelection(mapListContractorAbsMBEs);
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return mlReturnList;
    }
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public  MapList getAllMyAbstractMBEForApproval(Context context, String [] args)    throws Exception {
        MapList mlReturnList     =     new MapList();
        MapList mlFinalReturnList     =     new MapList();
        try
        {
            String strVault = context.getVault().getName();
            
            
            StringList strListBusInfo = new StringList(2);
            strListBusInfo.add(DomainConstants.SELECT_ID);
            strListBusInfo.add(DomainConstants.SELECT_CURRENT);
            //strListBusInfo.add("attribute["+ATTRIBUTE_CONTRECTOR_REVIEW+"]");
            
            StringList slRelSelect     =    new StringList();
            slRelSelect.add(DomainRelationship.SELECT_ID);
            
            String strWhere =    "current==Review";
            String strRelWhere     =     DomainConstants.EMPTY_STRING;
            com.matrixone.apps.common.Person contextPerson = com.matrixone.apps.common.Person.getPerson(context);
            
            
            Pattern patternRel  = new Pattern(DomainConstants.RELATIONSHIP_ROUTE_TASK);
            patternRel.addPattern(DomainConstants.RELATIONSHIP_OBJECT_ROUTE);
            patternRel.addPattern(DomainConstants.RELATIONSHIP_PROJECT_TASK);

            Pattern patternType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
            patternType.addPattern(DomainConstants.TYPE_ROUTE);    
            patternType.addPattern(WMSConstants_mxJPO.TYPE_ABSTRACT_MBE);  
            
            strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+DomainConstants.TYPE_INBOX_TASK+"' && current==Assigned )||("+DomainConstants.SELECT_TYPE+"=="+DomainConstants.TYPE_ROUTE+")||("+DomainConstants.SELECT_TYPE+"=="+WMSConstants_mxJPO.TYPE_ABSTRACT_MBE+"&& current==Review)";


            mlReturnList         = contextPerson.getRelatedObjects(context,
                                                            //patternRel.getPattern(),  // relationship pattern
                                                            patternRel.getPattern(),
                                                            patternType.getPattern(),  // object pattern
                                                            true,                                                        // to direction
                                                            true,                                                       // from direction
                                                            (short)0,                                                      // recursion level
                                                            strListBusInfo,                                                 // object selects
                                                            slRelSelect,                                                         // relationship selects
                                                            strWhere,                                // object where clause
                                                            strRelWhere,                                // relationship where clause
                                                            (short)0,                                                      // No expand limit
                                                            DomainConstants.EMPTY_STRING,                                // postRelPattern
                                                            WMSConstants_mxJPO.TYPE_ABSTRACT_MBE,                                                // postTypePattern
                                                            null);
            
            
            String strOwnWhere         =    DomainConstants.SELECT_OWNER+"=='"+context.getUser()+"' && current==Review";
           //String strOwnWhere         =    "current==Review";
            MapList mlOwnAbsMBList  =  DomainObject.findObjects(
                                            context,
                                            WMSConstants_mxJPO.TYPE_ABSTRACT_MBE,
                                            DomainConstants.QUERY_WILDCARD,
                                            DomainConstants.QUERY_WILDCARD,
                                            DomainConstants.QUERY_WILDCARD,
                                            strVault,
                                            strOwnWhere,               // where expression
                                            DomainConstants.EMPTY_STRING,
                                            false,
                                            strListBusInfo, // object selects
                                            (short) 0);
            
            
            mlReturnList.addAll(mlOwnAbsMBList);
			
			
			StringList slObjIds = new StringList();
			 String strId = DomainConstants.EMPTY_STRING;
			 Map mTemp = null;
			 for(int i=0;i<mlReturnList.size();i++){
				 mTemp = (Map)mlReturnList.get(i);
				 strId = (String)mTemp.get(DomainObject.SELECT_ID);
				 if(slObjIds.contains(strId) == false){
					 slObjIds.add(strId);
					 mlFinalReturnList.add(mTemp);
				 }
			 }
			
			
			
            insertKeyValue(mlFinalReturnList, DomainConstants.SELECT_LEVEL, "1");            

        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return mlFinalReturnList;
    }
	 @com.matrixone.apps.framework.ui.ProgramCallable
     public  MapList getAllMyMBE(Context context, String [] args)    throws Exception {
         MapList mlReturnList     =     new MapList();
         try
         {
             String strVault = context.getVault().getName();
             
             
             StringList strListBusInfo = new StringList(2);
             strListBusInfo.add(DomainConstants.SELECT_ID);
             strListBusInfo.add(DomainConstants.SELECT_CURRENT);
             
             StringList slRelSelect     =    new StringList();
             slRelSelect.add(DomainRelationship.SELECT_ID);
             
             String strWhere     = DomainConstants.EMPTY_STRING;
             String strRelWhere     = DomainConstants.EMPTY_STRING;
             com.matrixone.apps.common.Person contextPerson = com.matrixone.apps.common.Person.getPerson(context);
             
             
             Pattern patternRel  = new Pattern(DomainConstants.RELATIONSHIP_ROUTE_TASK);
             patternRel.addPattern(DomainConstants.RELATIONSHIP_OBJECT_ROUTE);
             patternRel.addPattern(DomainConstants.RELATIONSHIP_PROJECT_TASK);

             Pattern patternType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
             patternType.addPattern(DomainConstants.TYPE_ROUTE);    
             patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK_ENTRY);  
             
             strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+DomainConstants.TYPE_INBOX_TASK+"' && current==Complete )||("+DomainConstants.SELECT_TYPE+"=="+DomainConstants.TYPE_ROUTE+")||("+DomainConstants.SELECT_TYPE+"=="+TYPE_WMS_MEASUREMENT_BOOK_ENTRY+" && current==Submitted)";
             String strWhereOnwer =    DomainConstants.SELECT_OWNER+"=='"+context.getUser()+"' && current==Submitted";

            /* mlReturnList                     = contextPerson.getRelatedObjects(context,
                                                             //patternRel.getPattern(),  // relationship pattern
                                                             patternRel.getPattern(),
                                                             patternType.getPattern(),  // object pattern
                                                             true,                                                        // to direction
                                                             true,                                                       // from direction
                                                             (short)0,                                                      // recursion level
                                                             strListBusInfo,                                                 // object selects
                                                             slRelSelect,                                                         // relationship selects
                                                             strWhere,                                // object where clause
                                                             strRelWhere,                                // relationship where clause
                                                             (short)0,                                                      // No expand limit
                                                             DomainConstants.EMPTY_STRING,                                // postRelPattern
                                                             TYPE_WMS_MEASUREMENT_BOOK_ENTRY,                                                // postTypePattern
                                                             null);*/
             
             
             MapList mlOwnerMBE                =  DomainObject.findObjects(context,
                                                                         TYPE_WMS_MEASUREMENT_BOOK_ENTRY,
                                                                         DomainConstants.QUERY_WILDCARD,
                                                                         DomainConstants.QUERY_WILDCARD,
                                                                         DomainConstants.QUERY_WILDCARD,
                                                                         strVault,
                                                                         strWhereOnwer,               // where expression
                                                                         DomainConstants.EMPTY_STRING,
                                                                         false,
                                                                         strListBusInfo, // object selects
                                                                         (short) 0); 
             
             mlReturnList.addAll(mlOwnerMBE);
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
         insertKeyValue(mlReturnList, DomainConstants.SELECT_LEVEL, "1");
         return mlReturnList;
     }
     
     /**
      * Method to get the disconnected Tasks under the MBE
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return String containing the message
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public String removeSelectedActivities (Context context, String[] args) throws Exception 
     {
         try
         {
			 
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");

             String strMBEID = (String) programMap.get("objectId");
             String strItemOID = emxTableRowId[0].split("[|]")[1];
             StringList strListInfo =new StringList();
             strListInfo.add(DomainConstants.SELECT_TYPE);
             strListInfo.add(DomainConstants.SELECT_CURRENT);
             DomainObject domItemId= DomainObject.newInstance(context,strItemOID);
             Map<String,String> mapInfo = domItemId.getInfo(context,strListInfo);
             String strType =  mapInfo.get(DomainConstants.SELECT_TYPE);
			 
			if(emxTableRowId !=null && emxTableRowId.length>0)
             {
                 if(strType.equals(TYPE_WMS_MEASUREMENTS)){
                      ArrayList<String> arrayListRelOIDs = getSelectedActivities(context,emxTableRowId,strMBEID);
 					WMSUtil_mxJPO.disconnect(context, arrayListRelOIDs);
                     return "Selected objects sucessfully removed";

                 }
                 //else if(strType.equalsIgnoreCase(WMSDomainConstant.TYPE_ITEM)){

                 ArrayList<String> arrayListRelOIDs = getSelectedActivities(context,
                         emxTableRowId);
                 WMSUtil_mxJPO.disconnect(context, arrayListRelOIDs);
                 return "Selected objects sucessfully removed";

                 //}
             }                    
             return "Selected objects sucessfully removed";
         }catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
     
     /**
      * Method to set Quantity in Current MBE And to select Measurement for Remove operation
      * Also Check Rollup of Quantity in Current MBE after removing the Measurement
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return mapListConnectedTasks MapList containing the Task IDs
      * @return strMBEID Object id OF MBE
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */

     private ArrayList<String> getSelectedActivities(Context context,
             String[] emxTableRowId,String strMBEID) throws  FrameworkException ,MatrixException {
         try
         {
        	
             ArrayList<String> arrrayListSelectedRelOIDS = new ArrayList<String>();
             ArrayList<String> arrayListRelOIDs = getRelationshipOIDs(emxTableRowId);

             DomainObject domMBEID = DomainObject.newInstance(context,strMBEID);
             for(int y=0;y<emxTableRowId.length;y++){
                 double doubleFinalQuantity =0.0f;
                 String strItemOid = emxTableRowId[y].split("[|]")[2];
                 String mqlQuery = "Print bus "+domMBEID.getId(context)+" select from["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"|to.id=="+strItemOid+"].id dump";
                 String strMBEItemRelId =MqlUtil.mqlCommand(context, mqlQuery);
                 DomainRelationship domrelID= DomainRelationship.newInstance(context,strMBEItemRelId);
                 String strFinalQuantity = domrelID.getAttributeValue(context,ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY);
                 double doubleItemFinalQuantity = Double.valueOf(strFinalQuantity);
                 DomainRelationship domrelAM=null;
                 String strMesurementQuantity =null;
                 domrelAM= DomainRelationship.newInstance(context,arrayListRelOIDs.get(y));
                 strMesurementQuantity = domrelAM.getAttributeValue(context,ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY);
                 doubleFinalQuantity = doubleFinalQuantity+(Double.valueOf(strMesurementQuantity));
                 doubleItemFinalQuantity = doubleItemFinalQuantity-doubleFinalQuantity;
                 domrelID.setAttributeValue(context, ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY, String.valueOf(doubleItemFinalQuantity));
             }
             emxTableRowId = ProgramCentralUtil.parseTableRowId(context, emxTableRowId);
             StringList strListInfo = getSelectedActivitiesInfo();
             MapList mapListInfo = DomainObject.getInfo(context, emxTableRowId, strListInfo);
             Iterator iterator = mapListInfo.iterator();
             int intCounter = 0;
             while(iterator.hasNext())
             {
                 Map<String,String> mapInfo = (Map<String,String>)iterator.next();
                 String strType = mapInfo.get(DomainConstants.SELECT_TYPE);
                 String strRelOID = mapInfo.get("relationship["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].id");

                 if(TYPE_WMS_MEASUREMENTS.equals(strType))
                 {
                     arrrayListSelectedRelOIDS.add(arrayListRelOIDs.get(intCounter));
                 }

                 if(TYPE_WMS_MEASUREMENT_TASK.equals(strType))
                 {
                     arrrayListSelectedRelOIDS.add(arrayListRelOIDs.get(intCounter));
                 }

                 intCounter++;
             }
             return arrrayListSelectedRelOIDS;
         }
         catch(FrameworkException frameworkException)
         {
             frameworkException.printStackTrace();
             throw frameworkException;
         }


     }
     
     /**
      * Method to get the disconnected Tasks under the MBE
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return mapListConnectedTasks MapList containing the Task IDs
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */

     private ArrayList<String> getSelectedActivities(Context context,
             String[] emxTableRowId) throws  FrameworkException ,MatrixException {
         try
         {
             ArrayList<String> arrrayListSelectedRelOIDS = new ArrayList<String>();
             ArrayList<String> arrayListRelOIDs = getRelationshipOIDs(emxTableRowId);
             emxTableRowId = ProgramCentralUtil.parseTableRowId(context, emxTableRowId);
             StringList strListInfo = getSelectedActivitiesInfo();
             MapList mapListInfo = DomainObject.getInfo(context, emxTableRowId, strListInfo);
             Iterator iterator = mapListInfo.iterator();
             int intCounter = 0;
             //while(iterator.hasNext())
             int intSize = mapListInfo.size();
             for(int i=0 ; i<intSize;i++ )
             {
                 Map<String,String> mapInfo = (Map<String,String>)iterator.next();
                 String strType = mapInfo.get(DomainConstants.SELECT_TYPE);
                 //String strRelOID = mapInfo.get(WMSConstants.relationship+WMSDomainConstant.RELATIONSHIP_MBE_TASKS+WMSConstants.idClause);
 				if(TYPE_WMS_MEASUREMENT_TASK.equals(strType)|| TYPE_WMS_PAYMENT_ITEM.equals(strType))
                 {
                     arrrayListSelectedRelOIDS.add(arrayListRelOIDs.get(intCounter));
                 }
                 intCounter++;
             }
             return arrrayListSelectedRelOIDS;
         }
         catch(FrameworkException frameworkException)
         {
             frameworkException.printStackTrace();
             throw frameworkException;
         }
         catch(MatrixException matrixException)
         {
             matrixException.printStackTrace();
             throw matrixException;
         }

     }
     
     
     private StringList getSelectedActivitiesInfo() {
         StringList strListInfo = new StringList(3);
         strListInfo.add(DomainConstants.SELECT_TYPE);
         strListInfo.add(DomainConstants.SELECT_ID);
         strListInfo.add("relationship["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].id");
         return strListInfo;
     }
     
     private ArrayList<String> getRelationshipOIDs(String[] emxTableRowId) {
         ArrayList<String> arrayListRelOIDs = new ArrayList<String>();
         int intSize = emxTableRowId.length;
         for (int i = 0; i < intSize; i++)
         {
             String strRelOID = emxTableRowId[i].split("[|]")[0];

             arrayListRelOIDs.add(strRelOID);
         }
         return arrayListRelOIDs;
     }
     
     
     

     public  Boolean isTaskOpenForCotextUser(Context context, String [] args)    throws Exception {
         Boolean bReturn = new Boolean(Boolean.FALSE);
         try
         {
             HashMap programMap          = (HashMap)JPO.unpackArgs(args);
             
             String strMbId     = (String)programMap.get("objectId");
             
             String strVault = context.getVault().getName();
             
             
             StringList strListBusInfo = new StringList(2);
             strListBusInfo.add(DomainConstants.SELECT_ID);
             strListBusInfo.add(DomainConstants.SELECT_CURRENT);
             
             StringList slRelSelect     =    new StringList();
             slRelSelect.add(DomainRelationship.SELECT_ID);
             
             String strWhere     = DomainConstants.EMPTY_STRING;
             String strRelWhere     = DomainConstants.EMPTY_STRING;
             com.matrixone.apps.common.Person contextPerson = com.matrixone.apps.common.Person.getPerson(context);
             
             
             Pattern patternRel  = new Pattern(DomainConstants.RELATIONSHIP_ROUTE_TASK);
             patternRel.addPattern(DomainConstants.RELATIONSHIP_OBJECT_ROUTE);
             patternRel.addPattern(DomainConstants.RELATIONSHIP_PROJECT_TASK);

             Pattern patternType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
             patternType.addPattern(DomainConstants.TYPE_ROUTE);    
             patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK_ENTRY);  
             patternType.addPattern(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY);              
             
             DomainObject domObj = DomainObject.newInstance(context,strMbId);
             String strObjectType= domObj.getInfo(context,DomainConstants.SELECT_TYPE);
             if(strObjectType.equals(TYPE_WMS_MEASUREMENT_BOOK_ENTRY))
             {
             strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+DomainConstants.TYPE_INBOX_TASK+"' && current==Assigned )||("+DomainConstants.SELECT_TYPE+"=="+DomainConstants.TYPE_ROUTE+")||("+DomainConstants.SELECT_TYPE+"=="+TYPE_WMS_MEASUREMENT_BOOK_ENTRY+"&& current==Review && id=="+strMbId+")";
             }
             else
             {
             strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+DomainConstants.TYPE_INBOX_TASK+"' && current==Assigned )||("+DomainConstants.SELECT_TYPE+"=="+DomainConstants.TYPE_ROUTE+")||("+DomainConstants.SELECT_TYPE+"=="+TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY+"&& current==Review && id=="+strMbId+")";
             }

             
             MapList mlMBEList                     = contextPerson.getRelatedObjects(context,
                                                                                     //patternRel.getPattern(),  // relationship pattern
                                                                                     patternRel.getPattern(),
                                                                                     patternType.getPattern(),  // object pattern
                                                                                     true,                                                        // to direction
                                                                                     true,                                                       // from direction
                                                                                     (short)0,                                                      // recursion level
                                                                                     strListBusInfo,                                                 // object selects
                                                                                     slRelSelect,                                                         // relationship selects
                                                                                     strWhere,                                // object where clause
                                                                                     strRelWhere,                                // relationship where clause
                                                                                     (short)0,                                                      // No expand limit
                                                                                     DomainConstants.EMPTY_STRING,                                // postRelPattern
                                                                                     TYPE_WMS_MEASUREMENT_BOOK_ENTRY,                                                // postTypePattern
                                                                                     null);
            
             if(mlMBEList.size()>0)
             {
                 bReturn=    Boolean.TRUE;
             }   
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
         return bReturn;
     }
     
     
	public Boolean isMBEditable (Context context, String[] args) throws Exception 
	{
		Boolean bReturn = false ;
		try 
		{
			HashMap programMap 			= (HashMap)JPO.unpackArgs(args);
			String sMeasurementOid 		= (String)programMap.get("objectId");
			String strContextUser = context.getUser();
			String strPersonId = PersonUtil.getPersonObjectID(context);
			
			String strTypeOfComany = MqlUtil.mqlCommand(context,"print bus "+strPersonId+" select to["+DomainRelationship.RELATIONSHIP_MEMBER+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_COMPANY+"].value dump");
			if(UIUtil.isNotNullAndNotEmpty(sMeasurementOid))
			{
				DomainObject doMBE = new DomainObject(sMeasurementOid);
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_OWNER);
				slSelect.add(DomainObject.SELECT_CURRENT);
				slSelect.add("attribute["+ATTRIBUTE_WMS_FORMALIZED+"].value");
				Map mObjInfo = doMBE.getInfo(context,slSelect);
				
				String strOwner = (String)mObjInfo.get(DomainObject.SELECT_OWNER);
				String strState = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);
				String strIsFormalized = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_FORMALIZED+"].value");
				if(UIUtil.isNotNullAndNotEmpty(strOwner) && strContextUser.equals(strOwner) && ("Create".equals(strState) || ("Formalized".equals(strState) && "Yes".equals(strIsFormalized)))){
					bReturn = true;					
				}else {
					String mqlQuery = "print bus "+sMeasurementOid+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
					String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
					if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
						mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name dump";
						String strUser = MqlUtil.mqlCommand(context, mqlQuery);
						if(UIUtil.isNotNullAndNotEmpty(strUser) && strUser.contains(strContextUser) && "Contractor".equals(strTypeOfComany) == false){
							bReturn = true;
						}
					}
				}				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return bReturn;
	}
     
     
     /**
      * Method to get the connected Measurements of a activity under
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return mapListConnectedTasks MapList containing the Task IDs
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public MapList getActivityMeasurements (Context context, String[] args) throws Exception 
     {
         try
         {
             MapList mapListConnectedMeasurements = new MapList();
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String strObjectId = (String) programMap.get("objectId");
             String strRelOID  = (String)programMap.get("relId");
             String strParentId  = (String)programMap.get("parentId");
             if(UIUtil.isNotNullAndNotEmpty(strRelOID)&& UIUtil.isNotNullAndNotEmpty(strObjectId))
             {
                 DomainObject domObj = DomainObject.newInstance(context, strObjectId);
                 DomainObject domMBE = DomainObject.newInstance(context, strParentId);
				 String strMBEState = (String)domMBE.getInfo(context,DomainObject.SELECT_CURRENT);
				 String strOwner = (String)domObj.getInfo(context,"to["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].from.owner");
              if(domObj.isKindOf(context, TYPE_WMS_MEASUREMENT_TASK) )  // we dont need this ||domObj.isKindOf(context, TYPE_WMS_PAYMENT_ITEM))
                 {
                     StringList strListInfoSelects=new StringList(2);
                     strListInfoSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].id");
                     strListInfoSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
                     strListInfoSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");

                     DomainObject.MULTI_VALUE_LIST.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].id");
                     DomainObject.MULTI_VALUE_LIST.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
                     DomainObject.MULTI_VALUE_LIST.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");
                     String[] strEBOMList={strRelOID};
                     MapList mapListInfo = DomainRelationship.getInfo(context, strEBOMList, strListInfoSelects);
                     DomainObject.MULTI_VALUE_LIST.remove("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].id");
                     DomainObject.MULTI_VALUE_LIST.remove("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
                     DomainObject.MULTI_VALUE_LIST.remove("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");
                     mapListConnectedMeasurements = getActivityMeasurements(context,mapListInfo);
					 					 
					
						 Map mTemp = null;
						 for(int i=0;i<mapListConnectedMeasurements.size();i++){
							 mTemp = (Map)mapListConnectedMeasurements.get(i);
							  if("Review".equals(strMBEState)){
									mTemp.put("disableSelection", "true");	
							  }						  
						 }						 
					 
					 mapListConnectedMeasurements.sort("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]", ProgramCentralConstants.ASCENDING_SORT, ProgramCentralConstants.SORTTYPE_STRING);
                 }
              }
		 
             return mapListConnectedMeasurements;
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
     
     
     
     
     private MapList getActivityMeasurements(Context context,
             MapList mapListInfo) throws FrameworkException {
         try
         {
             MapList mapListConnectedMeasurements = new MapList();
             StringList strListRelOIDs = new StringList();
             StringList strListObjOIDs = new StringList();
             StringList strListRelQtys = new StringList();
             Iterator iterator = mapListInfo.iterator();
             while(iterator.hasNext())
             {
                 Map<String,Object> mapInfo = (Map<String,Object>)iterator.next();
                 Object objectRelOIDs = (Object) mapInfo.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].id");
                 Object objectObjOIDs = (Object) mapInfo.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
                 Object objectRelQtys = (Object) mapInfo.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");

                 //check whether the dependency list has one or many ids
                 if (objectRelOIDs instanceof String){
                     strListRelOIDs.add((String)objectRelOIDs);
                     strListObjOIDs.add((String)objectObjOIDs);
                     strListRelQtys.add((String)objectRelQtys);
                 } else if (objectRelOIDs instanceof StringList) {
                     strListRelOIDs = (StringList) objectRelOIDs;
                     strListObjOIDs = (StringList) objectObjOIDs;
                     strListRelQtys = (StringList) objectRelQtys;
                 }
             }

             int intSize = strListObjOIDs.size();
             MapList mapListMeasurementInfo = new MapList(intSize);
             if(intSize>0)
             {
                 ArrayList<String> arrayListOIDS = new ArrayList<String>(strListObjOIDs);
                 String [] strMeasurementOIds = arrayListOIDS.toArray(new String[intSize]);
                 StringList strListInfo = new StringList(12);
                 strListInfo.add(DomainConstants.SELECT_ID);
                 strListInfo.add(DomainConstants.SELECT_TYPE);
                 strListInfo.add(DomainConstants.SELECT_CURRENT);
                 strListInfo.add(DomainConstants.SELECT_REVISION);
                 strListInfo.add(DomainConstants.SELECT_DESCRIPTION);
                 strListInfo.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
                 strListInfo.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_HISTORY+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_UWD+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"]");
 				 strListInfo.add("attribute["+ATTRIBUTE_WMS_SHAPE_IMAGE+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_DIMENSION_1+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_DIMENSION_2+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_DIMENSION_3+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_DIMENSION_4+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_IS_MODIFIED+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_CONTRACTOR_COMMENT+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY+"]");
				 strListInfo.add("attribute["+ATTRIBUTE_WMS_IS_COMMENTED+"]");
 				
                 mapListMeasurementInfo = DomainObject.getInfo(context, strMeasurementOIds, strListInfo);
             }
             Iterator<Map<String,String>> iteratorMeasurement = mapListMeasurementInfo.iterator();
             String isDuduction = "no";
			 StringList slHistoryEntryList = null;
			 String strFrequency = DomainConstants.EMPTY_STRING;
			 String strLength = DomainConstants.EMPTY_STRING;
			 String strBreadth = DomainConstants.EMPTY_STRING;
			 String strDepth = DomainConstants.EMPTY_STRING;
			 String strRadius = DomainConstants.EMPTY_STRING;
			 String strUWD = DomainConstants.EMPTY_STRING;
			 String strIdDeduction = DomainConstants.EMPTY_STRING;
			 String strCoFactor = DomainConstants.EMPTY_STRING;
			 String strIsShape = DomainConstants.EMPTY_STRING;
			 String strIsCommented = DomainConstants.EMPTY_STRING;
			 String strApprovalComment = DomainConstants.EMPTY_STRING;
			 
             while(iteratorMeasurement.hasNext())
             {
                 Map<String,String> mapMeasurement = iteratorMeasurement.next();
                 String strMeasurementOID= mapMeasurement.get(DomainConstants.SELECT_ID);
                 isDuduction=mapMeasurement.get("attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"]");
                 strIsShape=mapMeasurement.get("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"]");
                 strIsCommented=mapMeasurement.get("attribute["+ATTRIBUTE_WMS_IS_COMMENTED+"]");
                 strApprovalComment=mapMeasurement.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY+"]");
                 if(isDuduction.equalsIgnoreCase("Yes"))
                	 mapMeasurement.put("styleRows", "ResourcePlanningRedBackGroundColor");
				 
				 //if(strIsShape.equalsIgnoreCase("Yes")){
					//  mapMeasurement.put("RowEditable", "readonly");
				 //}
				 if(UIUtil.isNotNullAndNotEmpty(strIsCommented) && "Yes".equalsIgnoreCase(strIsCommented)){
					 mapMeasurement.put("styleRows", "ResourcePlanningGreenBackGroundColor");
				 }	
				 /*if(UIUtil.isNotNullAndNotEmpty(strApprovalComment)){
					 mapMeasurement.put("styleRows", "ResourcePlanningGreenBackGroundColor");
				 }	*/				 
				 
				 String strMeasurementHistory = (String)mapMeasurement.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_HISTORY+"]");
				 String strLastEntry = DomainConstants.EMPTY_STRING;
				 String strSecondLastEntry = DomainConstants.EMPTY_STRING;
				 String strCurrentValue = DomainConstants.EMPTY_STRING;
				 slHistoryEntryList = FrameworkUtil.split(strMeasurementHistory, "\n");
				 int iSize = slHistoryEntryList.size();
				 if(iSize>1){
					strLastEntry = (String)slHistoryEntryList.get(iSize-1);
					strSecondLastEntry = (String)slHistoryEntryList.get(iSize-2);
					
					strFrequency = (String)mapMeasurement.get("attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"]");
					strLength = (String)mapMeasurement.get("attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"]");
					strBreadth = (String)mapMeasurement.get("attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"]");
					strDepth = (String)mapMeasurement.get("attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"]");
					strRadius = (String)mapMeasurement.get("attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"]");
					strUWD = (String)mapMeasurement.get("attribute["+ATTRIBUTE_WMS_UWD+"]");
					strIdDeduction = (String)mapMeasurement.get("attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"]");
					strCoFactor = (String)mapMeasurement.get("attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"]");					
					strCurrentValue = strFrequency+"|"+strLength+"|"+strBreadth+"|"+strDepth+"|"+strRadius+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor;
					
					if(strSecondLastEntry.contains(strCurrentValue) == false){
						mapMeasurement.put("styleRows", "ResourcePlanningYellowBackGroundColor");
					}
				 }
				 
                 int intIndex = strListObjOIDs.indexOf(strMeasurementOID);
                 if(intIndex>=0)
                 {
                     String strExpandRelOID = (String)strListRelOIDs.get(intIndex);
                     String strExpandRelQty = (String)strListRelQtys.get(intIndex);
                     mapMeasurement.put(DomainConstants.SELECT_LEVEL, "1");
                     mapMeasurement.put(DomainRelationship.SELECT_ID, strExpandRelOID);
                     mapMeasurement.put("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]", strExpandRelQty);
                     mapListConnectedMeasurements.add(mapMeasurement);
                 }
             }
             return mapListConnectedMeasurements;
         }
         catch(FrameworkException frameworkException)
         {
             frameworkException.printStackTrace();
             throw frameworkException;
         }
     }
     
     /**
      * Method to MBE title while connecting the Work Order and MBE
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed MBE and Work Order Id
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     public void updateMBETitle(Context context,String[]args)throws Exception
     {
         try
         {
             String strMBEOID = args[0];
             String  strWorkOrderOID = args[1];
             String  strRelID = args[2];
             boolean isContextPushed = false;
             if(UIUtil.isNotNullAndNotEmpty(strMBEOID)&& UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))
             {
                 DomainObject domObjWO  = DomainObject.newInstance(context, strWorkOrderOID);
                 DomainObject domObjMBE  = DomainObject.newInstance(context, strMBEOID);
                 int intSequence = getNewMBESequence(context, domObjWO,RELATIONSHIP_WMS_WORK_ORDER_MBE);
                 intSequence--;
                 NumberFormat numberFormat = new DecimalFormat("0000");
                 String strSequence = numberFormat.format(intSequence);
                 //TODO use constant entry
                 String strAgreementNumber = domObjWO.getAttributeValue(context, ATTRIBUTE_WMS_PO_NUMBER);
                 String strPrefix =  EnoviaResourceBundle.getProperty(context, "emxProgramCentral.Prefix.MBE");
                 String strName = strAgreementNumber.concat("-").concat(strPrefix).concat("-").concat(strSequence);
                 domObjMBE.setName(context,strName);
                 DomainRelationship domRel = DomainRelationship.newInstance(context, strRelID);
                 try
                 {
                     ContextUtil.pushContext(context, "User Agent",DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
                     domRel.setAttributeValue(context, ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER, String.valueOf(intSequence));
                     isContextPushed = true;
                 }
                 catch (Exception exception)
                 {
                     throw exception;
                 }
                 finally
                 {
                     if (isContextPushed)
                     {
                         ContextUtil.popContext(context);
                     }
                 }
             }
         }
         catch(Exception e)
         {
             e.printStackTrace();
             throw e;
         }
     }    

     
     /**
      * Method to get the connected Items under the Work Order from MBE add existing 
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return mapListConnectedTasks MapList containing the Task IDs
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.IncludeOIDProgramCallable
     public StringList getRelatedActivities (Context context, String[] args) throws Exception 
     {
         try
         {
             StringList strListActivitiesOIDs = new StringList();
 			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
             String strRel = DomainConstants.EMPTY_STRING;
             String strRelSeg = DomainConstants.EMPTY_STRING;
             if(UIUtil.isNotNullAndNotEmpty(strObjectId))
             {
                 StringList strListBusSelects     = new StringList(1);
                 strListBusSelects.add(DomainConstants.SELECT_ID);

                 DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
                 String strType = domObjMBE.getInfo(context, DomainConstants.SELECT_TYPE);
                 if( TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType))
                 {
                     strRel= RELATIONSHIP_WMS_WORK_ORDER_MBE;
                     strRelSeg = RELATIONSHIP_WMS_SEGMENT_MBE;
                 }
                 else if( TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY.equals(strType))
                 {
                     strRel= RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE;
                 }
                 String strWorkOrderOID = domObjMBE.getInfo(context, "relationship["+strRel+"].from.id");

                 MapList mapListConnectedActivities = getMBEActivities(context, domObjMBE);
 				StringList strListConnectdActivities = WMSUtil_mxJPO.convertToStringList(mapListConnectedActivities, DomainConstants.SELECT_ID);

                 if(UIUtil.isNotNullAndNotEmpty(strRelSeg))
                 {
                     String strSegmentOID = domObjMBE.getInfo(context,"relationship["+strRelSeg+"].from.id");
                     if(UIUtil.isNotNullAndNotEmpty(strSegmentOID))
                     {
 						StringList strListOBJ = getRelatedActivities(context,
 								strListBusSelects, strSegmentOID);
                         strListActivitiesOIDs.addAll(strListOBJ);
                     }
                     else
                     {
                         if(UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))
                         {
                             String strMBOID = getMeasurementBookOID(context,strListBusSelects, strWorkOrderOID);
                             if(UIUtil.isNotNullAndNotEmpty(strMBOID))
                             {
                                 StringList strListOBJ = getRelatedActivities(context,
                                 strListBusSelects, strMBOID);
                                 strListActivitiesOIDs.addAll(strListOBJ);

                             }
                         }
                     }
                     
                 }
                 else
                 {
                     if(UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))
                     {
                         String strMBOID = getMeasurementBookOID(context,strListBusSelects, strWorkOrderOID);
                         if(UIUtil.isNotNullAndNotEmpty(strMBOID))
                         {
                             StringList strListOBJ = getRelatedActivities(context,
                             strListBusSelects, strMBOID);
                             strListActivitiesOIDs.addAll(strListOBJ);
                         }
                     }
                 }
                 strListActivitiesOIDs.removeAll(strListConnectdActivities);
             }
             return strListActivitiesOIDs;
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
     
     /**
      * Function to get the Tasks connected to the selected Measurement Book
      *
      * @param context the eMatrix <code>Context</code> object
      * @param strMBOID String value containing the Measurement Book OID 
      * @param strListBusSelects StringList containing the bus selects
      * @return strListOBJ StringList  containing the Measurement Activities OIDs
      * @throws FrameworkException if the operation fails
      * @author WMS
      * @since 418
      */
     private StringList getRelatedActivities(Context context,
             StringList strListBusSelects, String strMBOID)
                     throws FrameworkException {
         try
         {
             DomainObject domObjMB= DomainObject.newInstance(context, strMBOID);

             Pattern patternType = new Pattern(TYPE_WMS_SEGMENT);
             patternType.addPattern(TYPE_WMS_MEASUREMENT_TASK);
             MapList mapListActivities = domObjMB.getRelatedObjects(context,
                     RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
                     patternType.getPattern(),                                    // object pattern
                     false,                                                        // to direction
                     true,                                                       // from direction
                     (short)0,                                                      // recursion level
                     strListBusSelects,                                                 // object selects
                     null,                                                         // relationship selects
                     DomainConstants.EMPTY_STRING,                                // object where clause
                     DomainConstants.EMPTY_STRING,                                // relationship where clause
                     (short)0,                                                      // No expand limit
                     DomainConstants.EMPTY_STRING,                                // postRelPattern
                     TYPE_WMS_MEASUREMENT_TASK,                                                // postTypePattern
                     null);                                                      // postPatterns
 			StringList strListOBJ = WMSUtil_mxJPO.convertToStringList(mapListActivities, DomainConstants.SELECT_ID);
             return strListOBJ;
         }
         catch(FrameworkException frameworkException)
         {
             throw frameworkException;
         }
     }
    
     /**
      * Function to new Sequence number of the newly created MBE
      *
      * @param context the eMatrix <code>Context</code> object
      * @param domObjWO DomainObject instance of selected Work Order 
      * @return intSequence Integer containing the sequence of the newly created MBE in that project
      * @throws FrameworkException if the operation fails
      * @author WMS
      * @since 418
      */
     private int getNewMBESequence(Context context, DomainObject domObjWO,String strRelationship)
             throws FrameworkException {
         try
         {
             int intSequence = 0;
             MapList mapListConnectedMBEs = new MapList();
             String strWhere  = CommonDocument.SELECT_REVISION+"==last";
             try
             {
                         ContextUtil.pushContext(context, "User Agent",DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
                 mapListConnectedMBEs = getConnectedMBEs(context, domObjWO,strRelationship,strWhere);
             }
             catch(Exception exception)
             {
             }
             finally
             {
                  ContextUtil.popContext(context);
             }
             
             if(mapListConnectedMBEs!=null )
             {
                 intSequence = mapListConnectedMBEs.size();
             }
             intSequence++;
             return intSequence;
         }
         catch(FrameworkException frameworkException)
         {
             frameworkException.printStackTrace();
             throw frameworkException;
         }
     }
     
     /**
      * Function to get the MBEs connected to the selected Work Order
      *
      * @param context the eMatrix <code>Context</code> object
      * @param domObj DomainObject instance of selected Object
      * @param strRelationship string value containing the relation with which the Object is connected
      * @return mapListMBEs MapList containing the MBEs connected to Work Order with ID
      * @throws FrameworkException if the operation fails
      * @author WMS
      * @since 418
      */
     private MapList getConnectedMBEs(Context context, DomainObject domObj,String strRelationship,String strWhere)
             throws FrameworkException {
         MapList mapListMBEs  = new MapList();
         MapList mlFiltered=new MapList();
         try
         {
        	 String strUser=context.getUser();
             StringList strListBusSelects     = new StringList(6);
             strListBusSelects.add(DomainConstants.SELECT_ID);
             strListBusSelects.add(DomainConstants.SELECT_OWNER);
             strListBusSelects.add(DomainConstants.SELECT_NAME);
             strListBusSelects.add(DomainConstants.SELECT_CURRENT);
             strListBusSelects.add(DomainConstants.SELECT_TYPE);
             strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"]");
             StringList strListRelSelects     = new StringList(2);
             strListRelSelects.add(DomainRelationship.SELECT_ID);
             strListRelSelects.add("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"]");
                 mapListMBEs = domObj.getRelatedObjects(context, // matrix context
                         strRelationship, // relationship pattern
                          TYPE_WMS_MEASUREMENT_BOOK_ENTRY, // type pattern
                         strListBusSelects, // object selects
                         strListRelSelects, // relationship selects
                         false, // to direction
                         true, // from direction
                         (short) 1, // recursion level
                         strWhere, // object where clause
                         DomainConstants.EMPTY_STRING, // relationship where clause
                         0);
                 
                Iterator<Map> itrListMBEs = mapListMBEs.iterator();
     			String strOwner=DomainConstants.EMPTY_STRING;
     			String strCurrent=DomainConstants.EMPTY_STRING;
     			while(itrListMBEs.hasNext()) {
     				 Map m = itrListMBEs.next();
     				 strOwner=(String) m.get(DomainConstants.SELECT_OWNER);
     				 strCurrent=(String) m.get(DomainConstants.SELECT_CURRENT);
     				 if(!strOwner.equalsIgnoreCase(strUser) && strCurrent.equalsIgnoreCase("Create")) {
     					continue;
     				 }
     				 mlFiltered.add(m);
     			}
           }
         catch(Exception Exception)
         {
             throw Exception;
         }
         return mlFiltered;
     }
     
   /**
    * Trigger method on WMSWorkOrder Create promote action which promotes all its child  
    *   
    *   
    *   
    * @param context
    * @param args
    * @throws Exception
    */
     
     public void promoteChildTasks(Context context, String[] args) throws Exception {
         try {
             String strBOQID = args[0];
             String strType  = args[1];
             String strWherCond =DomainConstants.SELECT_CURRENT+"==Create";
             StringList strListBusSelects     = new StringList(1);
             strListBusSelects.add(DomainConstants.SELECT_ID);
                         if (UIUtil.isNotNullAndNotEmpty(strBOQID)) {
                     
                 if(TYPE_WMS_WORK_ORDER.equals(strType))
                 {
					 if(UIUtil.isNotNullAndNotEmpty(strBOQID)){
					 
                     DomainObject domObjWorkOrder = DomainObject.newInstance(context,strBOQID);
                     String strMBOID = getMeasurementBookOID(context,strListBusSelects, strBOQID);
                     if(UIUtil.isNotNullAndNotEmpty(strMBOID))
                     {
                     DomainObject domObjMBO = DomainObject.newInstance(context,strMBOID);
                         domObjMBO.promote(context);
                     Pattern patternType = new Pattern(TYPE_WMS_SEGMENT);
                     patternType.addPattern(TYPE_WMS_MEASUREMENT_TASK);
                     MapList mapListBOQItems = domObjMBO.getRelatedObjects(context,
											 RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
											 patternType.getPattern(),                                    // object pattern
											 false,                                                        // to direction
											 true,                                                       // from direction
														 (short)0,                                                      // recursion level
											 strListBusSelects,                                                 // object selects
											 null,                                                         // relationship selects
											 strWherCond,                                // object where clause
											 DomainConstants.EMPTY_STRING,                                // relationship where clause
											 (short)0,                                                      // No expand limit
											 RELATIONSHIP_BILL_OF_QUANTITY,                                // postRelPattern
											 patternType.getPattern(),                                                // postTypePattern
											 null);   
											 
											 
                     if(mapListBOQItems.size() == 0 || mapListBOQItems == null){
						 throw new Exception("No BOQ defined");
					 }
                     Iterator<Map<String,String>> ChildIterator = mapListBOQItems.iterator();
                     Map<String,String> childmapData;
					 String strTotalQty = DomainConstants.EMPTY_STRING;
                     DomainObject domChildObjItem  = DomainObject.newInstance(context);
                         while(ChildIterator.hasNext())
                         {
                             childmapData = ChildIterator.next();
                             String strChildOID = childmapData.get(DomainConstants.SELECT_ID);
                             String strChildType = childmapData.get(DomainConstants.SELECT_TYPE);                             
                             domChildObjItem.setId(strChildOID);
							 
							 if(TYPE_WMS_MEASUREMENT_TASK.equals(strChildType)){
								 strTotalQty = (String)domChildObjItem.getAttributeValue(context,ATTRIBUTE_WMS_TOTAL_QUANTITY);
								 domChildObjItem.setAttributeValue(context,ATTRIBUTE_WMS_PREV_QUANTITY,strTotalQty);
							 }
                             //domChildObjItem.promote(context);   Added new intermediate state Create-Review-Active 
                             domChildObjItem.setState(context, "Active");
                         }
                     }
                 }
						 }
             }//End If
         }//End Try
         catch (Exception exception) 
         {
             exception.printStackTrace();
         }
     }
     /**
      * Table WMSMBEActivities : column ImageDropZone
      * 
      * 
      * 
      * @param context
      * @param args
      * @return
      * @throws Exception
      */
     
     public Vector getImageHolder(Context context, String[] args) throws Exception {
         
         Vector returnVector = new Vector();
         try
         {
             com.matrixone.apps.common.util.ImageManagerImageInfo info = new ImageManagerImageInfo();
             
             Map programMap        = (Map)JPO.unpackArgs(args);
             Map paramList      = (HashMap) programMap.get("paramList");
             MapList objectList = (MapList)programMap.get("objectList");
             int intSize = objectList.size();
             
             String strHtml        = new String();
             Map dataMap         = null;
             String strObjectId    = DomainConstants.EMPTY_STRING;
             String strRowId    =    DomainConstants.EMPTY_STRING;
             String strType     = DomainConstants.EMPTY_STRING;
             for (int i = 0; i < intSize ; i++) {
                 dataMap            = (Map) objectList.get(i);
                 strObjectId     = (String) dataMap.get("id");
                 strRowId     = (String) dataMap.get("id[level]");
                 strType    =    (String) dataMap.get("type");
                 if(TYPE_WMS_MEASUREMENTS.equals(strType))
                 {
                     strHtml="<div ><form id='imageUpload"+strObjectId+"' action='../common/emxExtendedPageHeaderFileUploadImage.jsp?objectId="+strObjectId+"' method='post'>   <div style='height:30px' id='divDropImages"+strObjectId+"' class='dropArea' ondrop='ImageDropColumn(event, &quot;imageUpload"+strObjectId+"&quot;, &quot;divDropImages"+strObjectId+"&quot; , &quot;"+strRowId+"&quot; )' ondragover='ImageDragHover(event, &quot;divDropImages"+strObjectId+"&quot;)' ondragleave='ImageDragHover(event, &quot;divDropImages"+strObjectId+"&quot;)'> Drop<br></br>images</div></form></div>";
                 }
                 else
                 {
                     strHtml="";
                 }
                 returnVector.add(strHtml);
             }
         }
         catch (Exception e) {
             e.printStackTrace();
         }
         
         return returnVector;
     }
     
     
     
     
     /**
      * Method to add measurement to the Item in the MBE
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return Map<String,String> containing the newly created measurements and relOIDs 
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public Map<String,String> addMeasurements (Context context, String[] args) throws Exception 
     {
         try
         {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
             Map<String,String> mapObject = new HashMap<String, String>();

             if(emxTableRowId !=null && emxTableRowId.length>0)
             {
                 ArrayList<String> arrayListRelOIDs = getSelectedActivities(context, emxTableRowId);
                
                 
                 String strItemOID = emxTableRowId[0];
                 String strItemMBERelOID = DomainConstants.EMPTY_STRING;
                 if(!arrayListRelOIDs.isEmpty())
                 {
                     strItemMBERelOID = arrayListRelOIDs.get(0);
                 }
                 if(UIUtil.isNotNullAndNotEmpty(strItemOID)&& UIUtil.isNotNullAndNotEmpty(strItemMBERelOID))
                 {
                     DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
                     StringList strListInfoSelects = new StringList(3);
                     strListInfoSelects.add(DomainConstants.SELECT_TYPE);
                     strListInfoSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
                     strListInfoSelects.add("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
                     Map<String,String> mapInfo = domObjItem.getInfo(context, strListInfoSelects);
                     String strName = mapInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
                     String strType = mapInfo.get(DomainConstants.SELECT_TYPE);
                     String strSORConnection = mapInfo.get("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
                     if(UIUtil.isNullOrEmpty(strSORConnection))
                     {
                         strSORConnection = "false";
                     }
                     if(TYPE_WMS_MEASUREMENT_TASK.equals(strType) ) // we do not need this  ||TYPE_WMS_PAYMENT_ITEM.equals(strType))
                     {
                         int intSequence = getMeasurementSequence(context, strItemMBERelOID);
                         int intMeasurementToAdd =0;
                     if(TYPE_WMS_MEASUREMENT_TASK.equals(strType))
                     {
                             intMeasurementToAdd = getNumberOfMeasurements(programMap);
                         }
                         else
                         {
                             intMeasurementToAdd=1;
                         }
                         StringBuffer strBuffer = new StringBuffer();
                         strBuffer.append("<mxRoot>");
                         strBuffer.append("<action><![CDATA[add]]></action>");
                         for(int i=0;i<intMeasurementToAdd;i++)
                         {
                             String strMeasurementOID = FrameworkUtil.autoName(context,
                                     "type_WMSMeasurements",
                                     "policy_WMSMeasurements");
                             //TODO Use MQl Arguments
                             String strMQLCommand = "add connection WMSActivityMeasurements torel "+strItemMBERelOID+" from "+strMeasurementOID;
                             MqlUtil.mqlCommand(context, strMQLCommand);
                             DomainObject domObjMeasurement = DomainObject.newInstance(context, strMeasurementOID);
                             String strMTitle = strName+" - "+intSequence;
                             domObjMeasurement.setAttributeValue(context,"Title",strMTitle);
                             String strRelOID = domObjMeasurement.getInfo(context, "relationship["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].id");

                             strBuffer.append("<data status=\"committed\">");
                             strBuffer.append("<item oid=\""+strMeasurementOID+"\" relId=\""+strRelOID+"\" pid=\""+strItemOID+"\"  direction=\"\" />");
                             strBuffer.append("</data>");
                             intSequence++;
                         }

                         Locale strLocale = context.getLocale();
                         String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.MBE.CREATEMEASUREMENT.Alert ");
                         strBuffer.append("</mxRoot>");
                         mapObject.put("selectedOID", strItemOID);
                         mapObject.put("rows",strBuffer.toString());
                         mapObject.put("message",strMessage);
                         mapObject.put("SOR_TYPE","SORItem");
                     }
                 }
             }
             return mapObject;
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
     
     
     
     private int getMeasurementSequence(Context context, String strItemMBERelOID) throws FrameworkException {
         StringList strListInfoSelectsRel=new StringList(2);
         strListInfoSelectsRel.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");

         DomainObject.MULTI_VALUE_LIST.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
         String[] strEBOMList={strItemMBERelOID};
         MapList mapListConnectionInfo = DomainRelationship.getInfo(context, strEBOMList, strListInfoSelectsRel);
         DomainObject.MULTI_VALUE_LIST.remove("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
         StringList strListObjOIDs = new StringList();
         Iterator iteratorTemp = mapListConnectionInfo.iterator();
         StringList strlTitle=new StringList();
         while(iteratorTemp.hasNext())
         {
             Map<String,Object> mapInfoMeasureMent = (Map<String,Object>)iteratorTemp.next();
             Object objectRelOIDs = (Object) mapInfoMeasureMent.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
             //check whether the dependency list has one or many ids
             if (objectRelOIDs instanceof String){
                 strListObjOIDs.add((String)objectRelOIDs);
             } else if (objectRelOIDs instanceof StringList) {
                 strListObjOIDs = (StringList) objectRelOIDs;
             }
         }
         int intSequence = strListObjOIDs.size();
         intSequence++;
         return intSequence;
     }
     private int getNumberOfMeasurements(HashMap programMap) {
         String strMeasurementToAdd = (String)programMap.get("WMSMeasurementsToBeAdded");
         int intMeasurementToAdd = 0;
         if(UIUtil.isNotNullAndNotEmpty(strMeasurementToAdd))
         {
             try
             {
                 intMeasurementToAdd = Integer.parseInt(strMeasurementToAdd);
             }catch(NumberFormatException numberFormatException)
             {
                 intMeasurementToAdd = 1;
             }
         }
         return intMeasurementToAdd;
     }
     
     
     	@com.matrixone.apps.framework.ui.ProgramCallable
	public  MapList getAllMyAbstractMBE(Context context, String [] args)    throws Exception {
        MapList mlReturnList     =     new MapList();
        try
        {
            String strVault = context.getVault().getName();
            
            
            StringList strListBusInfo = new StringList(2);
            strListBusInfo.add(DomainConstants.SELECT_ID);
            strListBusInfo.add(DomainConstants.SELECT_CURRENT);
            
            StringList slRelSelect     =    new StringList();
            slRelSelect.add(DomainRelationship.SELECT_ID);
            
            String strWhere     = DomainConstants.EMPTY_STRING;
            String strRelWhere     = DomainConstants.EMPTY_STRING;
            com.matrixone.apps.common.Person contextPerson = com.matrixone.apps.common.Person.getPerson(context);
            
            
            Pattern patternRel  = new Pattern(DomainConstants.RELATIONSHIP_ROUTE_TASK);
            patternRel.addPattern(DomainConstants.RELATIONSHIP_OBJECT_ROUTE);
            patternRel.addPattern(DomainConstants.RELATIONSHIP_PROJECT_TASK);

            Pattern patternType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
            patternType.addPattern(DomainConstants.TYPE_ROUTE);    
            patternType.addPattern(WMSConstants_mxJPO.TYPE_ABSTRACT_MBE);  
            
            strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+DomainConstants.TYPE_INBOX_TASK+"' && current==Assigned )||("+DomainConstants.SELECT_TYPE+"=="+DomainConstants.TYPE_ROUTE+")||("+DomainConstants.SELECT_TYPE+"=="+WMSConstants_mxJPO.TYPE_ABSTRACT_MBE+"&& current==Approved)";
			String strWhereOnwer =    DomainConstants.SELECT_OWNER+"=='"+context.getUser()+"' && (current==Approved || current==Paid)";

            /*mlReturnList                     = contextPerson.getRelatedObjects(context,
                                                            //patternRel.getPattern(),  // relationship pattern
                                                            patternRel.getPattern(),
                                                            patternType.getPattern(),  // object pattern
                                                            true,                                                        // to direction
                                                            true,                                                       // from direction
                                                            (short)0,                                                      // recursion level
                                                            strListBusInfo,                                                 // object selects
                                                            slRelSelect,                                                         // relationship selects
                                                            strWhere,                                // object where clause
                                                            strRelWhere,                                // relationship where clause
                                                            (short)0,                                                      // No expand limit
                                                            DomainConstants.EMPTY_STRING,                                // postRelPattern
                                                            ${CLASS:WMSConstants}.TYPE_ABSTRACT_MBE,                                                // postTypePattern
                                                            null);*/
            
            
            MapList mlOwnerMBE                =  DomainObject.findObjects(context,
                                                                        WMSConstants_mxJPO.TYPE_ABSTRACT_MBE,
                                                                        DomainConstants.QUERY_WILDCARD,
                                                                        DomainConstants.QUERY_WILDCARD,
                                                                        DomainConstants.QUERY_WILDCARD,
                                                                        strVault,
                                                                        strWhereOnwer,               // where expression
                                                                        DomainConstants.EMPTY_STRING,
                                                                        false,
                                                                        strListBusInfo, // object selects
                                                                        (short) 0); 
            
            mlReturnList.addAll(mlOwnerMBE);
      insertKeyValue(mlReturnList, DomainConstants.SELECT_LEVEL, "1");
            
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        
        return mlReturnList;
    }
     
     public Vector displayLocation(Context context, String[] args) throws Exception {
         
         Vector returnVector = new Vector();
         try
         {
             Map programMap        = (Map)JPO.unpackArgs(args);
             Map paramList      = (HashMap) programMap.get("paramList");
             MapList objectList = (MapList)programMap.get("objectList");
             int intSize = objectList.size();
             
             String strHtml        = new String();
             Map dataMap         = null;
             String strObjectId    = DomainConstants.EMPTY_STRING;
             String strRowId    =    DomainConstants.EMPTY_STRING;
             String strType     = DomainConstants.EMPTY_STRING;
             String sObjectName     = DomainConstants.EMPTY_STRING;
             for (int i = 0; i < intSize ; i++) {
                 dataMap            = (Map) objectList.get(i);
                 
                 strObjectId     = (String) dataMap.get("id");
                 strRowId     = (String) dataMap.get("id[level]");
                 strType    =    (String) dataMap.get("type");
                 sObjectName = (String)dataMap.get("attribute[Title]");
                 
                 StringList sl = new StringList("attribute["+ATTRIBUTE_WMS_MEASUREMENT_LOCATION+"]");
                 sl.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_ADDRESS+"].value");
                 Map attList = new DomainObject(strObjectId).getInfo(context, sl);
             
                  StringBuilder strUrl = new StringBuilder();
                 String strGPSLocation = (String)attList.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_LOCATION+"]");
                 if(TYPE_WMS_MEASUREMENTS.equals(strType) && UIUtil.isNotNullAndNotEmpty(strGPSLocation))
                 {
                     String strLink = "../wms/wmsMeasurementGSPlocator.jsp?GPSLocation="+strGPSLocation;
                     strUrl.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");            
                     strUrl.append("<img border='0' title='map' src='../common/images/map.png' height='25px' name='map' id='map' alt='map' />");
                     strUrl.append("</a>");
                 }
                 else
                 {
                     strUrl.append(attList.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_ADDRESS+"]"));
                 }
                 returnVector.add(strUrl.toString());
                 
             }
         }
         catch (Exception e) {
             e.printStackTrace();
         }
         
         return returnVector;
     }
    /**Method to connect Approval Template with MBE 
     * 
     * @param context
     * @param args
     * @throws Exception
     */
     
     public void updateMBEApprovalTemplate(Context context,String[] args) throws Exception
     {
    	try { 
    		String strExistRelId ="";
    	    Map mInput  = JPO.unpackArgs(args);
    	    Map paramMap = (Map)mInput.get("paramMap");
    	    String strNewAprTemplate =(String) paramMap.get("New Value");
    	    String strMBEOid  = (String)paramMap.get("objectId");
    	    DomainObject dom=DomainObject.newInstance(context,strMBEOid);
    	    String strType = dom.getInfo(context, DomainConstants.SELECT_TYPE);
    	    String strRel=RELATIONSHIP_WMS_AMBE_APPROVAL_TEMPLATE;
            if(strType.equals(TYPE_WMS_MEASUREMENT_BOOK_ENTRY)) {
            	strRel =RELATIONSHIP_WMS_MBE_APPROVAL_TEMPLATE;
            }else if(strType.equals(TYPE_WMS_MATERIAL_BILL)) {
             	strRel = RELATIONSHIP_WMS_MB_APPROVAL_TEMPLATE;
            }
            strExistRelId = dom.getInfo(context, "from["+strRel+"].id");
    	    if(strExistRelId!=null && !strExistRelId.isEmpty()) {
    	    	DomainRelationship.disconnect(context, strExistRelId);
    	    }
    	    if(strNewAprTemplate!=null && !strNewAprTemplate.isEmpty()) {
				    ContextUtil.pushContext(context);
    	     		DomainRelationship.connect(context, dom, new RelationshipType(strRel), new DomainObject(strNewAprTemplate));
					ContextUtil.popContext(context);
              }
    	 
    	 
      	}catch(Exception e) {
    		e.printStackTrace();
    	}}
     
	  public void updateMBEFormalApprovalTemplate(Context context,String[] args) throws Exception
     {
    	try { 
    		String strExistRelId ="";
    	    Map mInput  = JPO.unpackArgs(args);
    	    Map paramMap = (Map)mInput.get("paramMap");
    	    String strNewAprTemplate =(String) paramMap.get("New Value");
    	    String strMBEOid  = (String)paramMap.get("objectId");
    	    DomainObject dom=DomainObject.newInstance(context,strMBEOid);
    	    String strType = dom.getInfo(context, DomainConstants.SELECT_TYPE);
    	    String strRel=RELATIONSHIP_WMS_MBE_FORMAL_APPROVAL_TEMPLATE;
            
            strExistRelId = dom.getInfo(context, "from["+strRel+"].id");
    	    if(strExistRelId!=null && !strExistRelId.isEmpty()) {
    	    	DomainRelationship.disconnect(context, strExistRelId);
    	    }
    	    if(strNewAprTemplate!=null && !strNewAprTemplate.isEmpty()) {
				    ContextUtil.pushContext(context);
    	     		DomainRelationship.connect(context, dom, new RelationshipType(strRel), new DomainObject(strNewAprTemplate));
					ContextUtil.popContext(context);
              }
    	 
    	 
      	}catch(Exception e) {
    		e.printStackTrace();
    	}}
     
     /**
      * Method to get the connected MBEs under the Work Order
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command or form or table
      * @return mapListConnectedMBEs MapList containing the MBEs IDs
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public MapList getWorkOrderMBEs (Context context, String[] args) throws Exception 
     {
         try
         {
             MapList mapListConnectedMBEs = new MapList();
 			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
             if(UIUtil.isNotNullAndNotEmpty(strObjectId))
             {
                 DomainObject domObjWO = DomainObject.newInstance(context, strObjectId);
                // mapListConnectedMBEs = getConnectedMBEs(context, domObjWO,RELATIONSHIP_WMS_WORK_ORDER_MBE,"current.access[read]==TRUE && attribute["+ATTRIBUTE_WMS_FORMALIZED+"].value == Yes");
                 mapListConnectedMBEs = getConnectedMBEs(context, domObjWO,RELATIONSHIP_WMS_WORK_ORDER_MBE,"current.access[read]==TRUE");
                 mapListConnectedMBEs.addSortKey(DomainConstants.SELECT_NAME, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_STRING);
                 mapListConnectedMBEs.addSortKey(DomainObject.SELECT_REVISION, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
                 mapListConnectedMBEs.sort();
				Map<String,String> mapData;
                 Iterator<Map<String,String>> iterator = mapListConnectedMBEs.iterator();
                 while(iterator.hasNext())
                 {
                     mapData =  (Map<String,String>)iterator.next();
                     String strOID =  mapData.get(DomainConstants.SELECT_ID);
					if(UIUtil.isNotNullAndNotEmpty(strOID))
						{
							DomainObject doMBE = new DomainObject(strOID);
							StringList slSelect = new StringList();
							slSelect.add(DomainObject.SELECT_CURRENT);
							Map mObjInfo = doMBE.getInfo(context,slSelect);
							String strState = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);
							if("Review".equals(strState) || "Submitted".equals(strState)){
								mapData.put("RowEditable", "readonly");
								mapData.put("disableSelection", "true");
							}							
						}
                 }
             }
             return mapListConnectedMBEs;
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
     
     /**Create Promote Check Trigger on Policy WMSMeasurementBookEntry 
      * 
      * @param context
      * @param args
      * @return
      * @throws Exception
      */
     
     public int triggerIsApprovalTemplateConnected(Context context, String[] args) throws Exception{
    	 try {
    		 String strExistRel ="";
    		  String strMEBOid = args[0];
    		  DomainObject domMBE = DomainObject.newInstance(context, strMEBOid);	
			  
			  String strBusWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\" || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
			  MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, domMBE, strBusWhere);
			  
			  if(mlExtRoutes.size()==0){
					String strMessage = "Please add Route and then proceed";
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
	
			return 0;
    		  /*String strType = domMBE.getInfo(context, DomainConstants.SELECT_TYPE);
    		  String strRel=RELATIONSHIP_WMS_AMBE_APPROVAL_TEMPLATE;
    		  if(strType.equals(TYPE_WMS_MATERIAL_BILL)) {
    			  strRel=RELATIONSHIP_WMS_MB_APPROVAL_TEMPLATE;
    		  }
    		  if(strType.equals(TYPE_WMS_MEASUREMENT_BOOK_ENTRY)) {
    			  strRel = RELATIONSHIP_WMS_MBE_APPROVAL_TEMPLATE;
    		  }
			  ContextUtil.pushContext(context);
    		  strExistRel = domMBE.getInfo(context, "from["+strRel+"]");
			  ContextUtil.popContext(context);
    		  if(strExistRel.equalsIgnoreCase("FALSE")) {
    			  Locale strLocale = context.getLocale();
                  String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.alert.NoApprovalTemplate");
                  ${CLASS:emxContextUtil}.mqlNotice(context,strMessage);
                  return 1;
    		  }*/
     	    }catch(Exception e) {
    		 e.printStackTrace();
    	 }
    	 
    	 
         return 0; 
      }
     
     
     
     /**
      * update function
      * updates Measurement Title
      * @param context
      * @param args new title for Measurement and object id of measurement
      *    objectId - Measurement id
      *    New Value -Title
      * @throws Exception if the operation fails
      */
     public void updateMeasurementTitle (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String sTitle = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
             doMeasurement.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, sTitle);
         }
         catch (Exception e) {
             throw e;
         }
     }
     
     
     public int triggerAutoCreateApprovalRoute(Context context,String[] args) throws Exception
     {
		 boolean isContextPushed = false;
      try {	  
			String strContectUser =  context.getUser();
			//ContextUtil.pushContext(context);
			//isContextPushed = true;
    	   String strApprovalTemplOid ="";
    	   String strMBEOid = args[0];
    	   String strPurpose=args[1];
    	   String strBasePolicy=args[2];
		   String strBaseState=args[3];
		   
		if(POLICY_WMS_MEASUREMENT_BOOK_ENTRY_NONEPC.equals(strBasePolicy) == false){
				
			   String strRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"  || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
			   DomainObject domMBE= DomainObject.newInstance(context, strMBEOid);
			   String strRel=RELATIONSHIP_WMS_AMBE_APPROVAL_TEMPLATE;
			   String strType = domMBE.getInfo(context, DomainConstants.SELECT_TYPE);
			   if(strType.equals(TYPE_WMS_MATERIAL_BILL)) {
				   strRel=RELATIONSHIP_WMS_MB_APPROVAL_TEMPLATE;
			   }if(strType.equals(TYPE_WMS_MEASUREMENT_BOOK_ENTRY)) {
				  strRel=RELATIONSHIP_WMS_MBE_APPROVAL_TEMPLATE;
			   }
			   strApprovalTemplOid = domMBE.getInfo(context, "from["+strRel+"].to.id");
			   Map mRouteAttrib= new HashMap();
			   Map reviewerInfo= new HashMap();
			   mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
			   MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, domMBE, strRelWhere);
			   if(mlExtRoutes.size()>0) {
				   WMSUtil_mxJPO.restartExistingRoute(context,mlExtRoutes);
			   }else {
					 Map objectRouteAttributeMap=new HashMap(); 
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strBasePolicy,false ));;
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Review");
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,strPurpose);
					ContextUtil.pushContext(context);
					Route.createAndStartRouteFromTemplateAndReviewers(context,
						   strApprovalTemplOid,
							"Measurement Review",
							 strContectUser , 
							strMBEOid,
							strBasePolicy,
							strBaseState, 
							mRouteAttrib,
							objectRouteAttributeMap, 
							reviewerInfo,
							true);
				   ContextUtil.popContext(context);
				  
			   }

			   StringList slMBESelect = new StringList();
			   slMBESelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
			   slMBESelect.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
			   slMBESelect.add("to["+RELATIONSHIP_WMS_WO_MATERIAL_BILL+"].from.id");
			   slMBESelect.add("to["+RELATIONSHIP_WMS_WO_MATERIAL_BILL+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
			   slMBESelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
			   slMBESelect.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
			   slMBESelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_PO_NUMBER+"].value");
			   slMBESelect.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_PO_NUMBER+"].value");
			   slMBESelect.add("to["+RELATIONSHIP_WMS_WO_MATERIAL_BILL+"].from.attribute["+ATTRIBUTE_WMS_PO_NUMBER+"].value");
			   ContextUtil.pushContext(context);
			   Map mMBEInfo = (Map)domMBE.getInfo(context,slMBESelect);
			   ContextUtil.popContext(context);
			   String strWOId = DomainConstants.EMPTY_STRING;
			   String strProjectCode = DomainConstants.EMPTY_STRING;
			   String strAgreementNumber = DomainConstants.EMPTY_STRING;
			   String strRelPattern = DomainConstants.EMPTY_STRING;
			   String strTypePattern = DomainConstants.EMPTY_STRING;
			   String strPrefix = DomainConstants.EMPTY_STRING;
			   if(TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType)){
					strWOId = (String)mMBEInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
					strProjectCode = (String)mMBEInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
					strAgreementNumber = (String)mMBEInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_PO_NUMBER+"].value");
					strRelPattern = RELATIONSHIP_WMS_WORK_ORDER_MBE;
					strPrefix = EnoviaResourceBundle.getProperty(context, "WMS.MeasurementBook.Numbering.Prefix");
					if(UIUtil.isNullOrEmpty(strPrefix)){
						strPrefix = "MB";
					}
			   } else if(TYPE_WMS_MATERIAL_BILL.equals(strType)){
					strWOId = (String)mMBEInfo.get("to["+RELATIONSHIP_WMS_WO_MATERIAL_BILL+"].from.id");
					strProjectCode = (String)mMBEInfo.get("to["+RELATIONSHIP_WMS_WO_MATERIAL_BILL+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value"); ;
					strAgreementNumber = (String)mMBEInfo.get("to["+RELATIONSHIP_WMS_WO_MATERIAL_BILL+"].from.attribute["+ATTRIBUTE_WMS_PO_NUMBER+"].value");
					strRelPattern = RELATIONSHIP_WMS_WO_MATERIAL_BILL;
					strPrefix = EnoviaResourceBundle.getProperty(context, "WMS.MaterialBill.Numbering.Prefix");
					if(UIUtil.isNullOrEmpty(strPrefix)){
						strPrefix = "MTB";
					}
			   } 
			   else{
					strWOId = (String)mMBEInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
					strProjectCode = (String)mMBEInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value"); 
					strAgreementNumber = (String)mMBEInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_PO_NUMBER+"].value"); 
					strRelPattern = RELATIONSHIP_WORKORDER_ABSTRACT_MBE;
					strPrefix = EnoviaResourceBundle.getProperty(context, "WMS.AbstractBill.Numbering.Prefix");
					if(UIUtil.isNullOrEmpty(strPrefix)){
						strPrefix = "AB";
					}
			   }

			   DomainObject doWO = new DomainObject(strWOId);
			   StringList strListBusSelects = new StringList();
				strListBusSelects.add(DomainObject.SELECT_ID);
				MapList mapListMBEs = doWO.getRelatedObjects(context, // matrix context
                        strRelPattern, // relationship pattern
                        strType, // type pattern
                        strListBusSelects, // object selects
                        null, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        DomainConstants.EMPTY_STRING, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);
				
				int intSequence = mapListMBEs.size();
				if(intSequence==0){
						intSequence = 1;
				}
				NumberFormat numberFormat = new DecimalFormat("000000");
				String strSequence = numberFormat.format(intSequence);
				String strName = strProjectCode.concat("-").concat(strPrefix).concat("-").concat(strAgreementNumber).concat("-").concat(strSequence);		
				ContextUtil.pushContext(context);
				domMBE.setName(context,strName);
				ContextUtil.popContext(context);
			   
			   
			   
		   }
         }catch(Exception e) {
        	//  ContextUtil.popContext(context);
    	  e.printStackTrace();
      } 
	  finally{
		  //if(isContextPushed){
		//	  ContextUtil.popContext(context);
		  //}
	  }
      return 0;
     } 
     /**Method to show MeasurebookEntry dashbord page  check if user is Supplier representative or  part of CIVIL dept 
      *  WMSMyApprovalMBE 
      *   WMSALLApprovalMBE
      * @param contet
      * @param args
      * @return
      * @throws Exception
      */
     
     public boolean showMBEDashboardCommnad(Context contet,String[] args) throws Exception{
    	 
    	
      try { 
    	    if(!PersonUtil.hasAssignment(context, DomainConstants.ROLE_SUPPLIER_REPRESENTATIVE)) {
				 return true;
    	      }
    	    return true;
    	  
      	}catch(Exception e) {
    		
    		e.printStackTrace();
    	}
       
       return false;
     }
     
     
     public Map calculateArea(Context context,String strShapeName,String strDim1,String strDim2,String strDim3,String strDim4){
    		Map attributeMap = new HashMap();
    		double dbArea = 0.0;
    		switch(strShapeName)
    		{
    			case "Line":
    				dbArea = WMSUtil_mxJPO.convertToDouble(strDim2);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Circle":
    				dbArea = 3.14*WMSUtil_mxJPO.convertToDouble(strDim1)*WMSUtil_mxJPO.convertToDouble(strDim1);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_1, strDim1);
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Square":
    				dbArea = WMSUtil_mxJPO.convertToDouble(strDim2)*WMSUtil_mxJPO.convertToDouble(strDim2);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Rectangle":
    				dbArea = WMSUtil_mxJPO.convertToDouble(strDim2)*WMSUtil_mxJPO.convertToDouble(strDim3);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_3, strDim3);
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Trapezoid":
    				dbArea = ((WMSUtil_mxJPO.convertToDouble(strDim2)+WMSUtil_mxJPO.convertToDouble(strDim3))/2)*WMSUtil_mxJPO.convertToDouble(strDim4);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_3, strDim3);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_4, strDim4);
    				attributeMap.put("Area", dbArea);
    				break;		
    			case "Hexagon":
    				//3root(3)/2)*Side*Side
    				dbArea = 3*Math.sqrt(3)/2*(WMSUtil_mxJPO.convertToDouble(strDim2)*WMSUtil_mxJPO.convertToDouble(strDim2));
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);	
    				attributeMap.put("Area", dbArea);
    				break;
    			
    			case "HexagonalPrism":
    				dbArea = (3*Math.sqrt(3)/2)*(WMSUtil_mxJPO.convertToDouble(strDim2)*WMSUtil_mxJPO.convertToDouble(strDim2))*(WMSUtil_mxJPO.convertToDouble(strDim4)*WMSUtil_mxJPO.convertToDouble(strDim4));
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_4, strDim4);
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Cube":
    				dbArea = WMSUtil_mxJPO.convertToDouble(strDim2)*WMSUtil_mxJPO.convertToDouble(strDim2)*WMSUtil_mxJPO.convertToDouble(strDim2);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);	
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Cuboid":
    				dbArea = WMSUtil_mxJPO.convertToDouble(strDim2)*WMSUtil_mxJPO.convertToDouble(strDim3)+WMSUtil_mxJPO.convertToDouble(strDim4);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_3, strDim3);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_4, strDim4);
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Trapezoidal":
    				dbArea = (((WMSUtil_mxJPO.convertToDouble(strDim2)+WMSUtil_mxJPO.convertToDouble(strDim1))/2)*(WMSUtil_mxJPO.convertToDouble(strDim3)))*WMSUtil_mxJPO.convertToDouble(strDim4);					
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_3, strDim3);//a,b
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_4, strDim4);//h
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);//l
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_1, strDim1);//l
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Cylinder":
    				//2*3.14*Radius*Height+2*3.14*Radius*Radius
    				dbArea = 3.14*(WMSUtil_mxJPO.convertToDouble(strDim1)*WMSUtil_mxJPO.convertToDouble(strDim1))*WMSUtil_mxJPO.convertToDouble(strDim4);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_1, strDim1);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_4, strDim4);	
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Cone":
    				//3.14*Radius(Radius+root(Height*Height+Radius*Radius)
    				dbArea = 3.14*WMSUtil_mxJPO.convertToDouble(strDim1)*WMSUtil_mxJPO.convertToDouble(strDim4);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_1, strDim1);
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_4, strDim4);	
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Pyramid":
    				//Length*Width+Length*root((Width*2)*(Width*2)+Height*Height)+Width*root(Lenght/2+Height)
    				dbArea = (WMSUtil_mxJPO.convertToDouble(strDim2)*WMSUtil_mxJPO.convertToDouble(strDim3)*WMSUtil_mxJPO.convertToDouble(strDim4))/3;
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_2, strDim2);//l
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_3, strDim3);//w
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_4, strDim4);//h
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Sphere":
    				dbArea = 4/3*3.14*(WMSUtil_mxJPO.convertToDouble(strDim1)*WMSUtil_mxJPO.convertToDouble(strDim1));
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_1, strDim1);	
    				attributeMap.put("Area", dbArea);
    				break;
    			case "Hemisphere":
    				dbArea = 2/3*3.14*(WMSUtil_mxJPO.convertToDouble(strDim1)*WMSUtil_mxJPO.convertToDouble(strDim1));
    				attributeMap.put(ATTRIBUTE_WMS_DIMENSION_1, strDim1);	
    				attributeMap.put("Area", dbArea);
    				break;
    		}
    		return attributeMap;
    		

    	}
     /**  Trigger method on Review Promote of Policy WMSMeasurementBookEntry 
      * 
      * @param context
      * @param args
      * @return
      * @throws Exception
      */
     
     public int triggerUpdateMBESubmittedQuantity(Context context,String[] args) throws Exception {
     	 try {
    	      String strMBEOid = args[0];
     		  DomainObject domMBE=DomainObject.newInstance(context, strMBEOid);
     		  SelectList selListBusSelects = new SelectList(4);
              selListBusSelects.add(DomainConstants.SELECT_ID);
              selListBusSelects.add(DomainConstants.SELECT_TYPE);
                selListBusSelects.add("to[" + RELATIONSHIP_WMS_MBE_ACTIVITIES 
                      + "|from.current==Create && from.id!=" + strMBEOid + "].id");
                 selListBusSelects.add(
                     "attribute[" + ATTRIBUTE_WMS_MBE_QUANTITY + "]");
                 selListBusSelects.add(
                         "attribute[" + ATTRIBUTE_WMS_MBE_QUANTITY + "]");
               MapList mapListTasks = domMBE.getRelatedObjects(context, // matrix
                      // context
            		  RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship
                      // pattern
                      TYPE_WMS_MEASUREMENT_TASK, // type pattern
                      selListBusSelects, // object selects
                      null, // relationship selects
                      false, // to direction
                      true, // from direction
                      (short) 1, // recursion level
                      DomainConstants.EMPTY_STRING, // object where clause
                      DomainConstants.EMPTY_STRING, // relationship where
                      // clause
                      0);

              // float itemQty = 0;
              Iterator iterator = mapListTasks.iterator();
              String strMBEQty = "";
              StringList strListObjOIDs = new StringList(10, 2);
              String strTemp = "";
              String strRelId = "";

              while (iterator.hasNext()) {
                  strListObjOIDs.clear();
                  Map<String, String> mapActivity = (Map<String, String>) iterator.next();
                  strMBEQty = (String) mapActivity.get(
                         "attribute[" + ATTRIBUTE_WMS_MBE_QUANTITY + "]");
                  Object objectMBEOIDs = (Object) mapActivity
                          .get("to[" + RELATIONSHIP_WMS_MBE_ACTIVITIES + "].id");

                  // check whether the MBE list has one or many ids
                  if (objectMBEOIDs instanceof String) {
                      strListObjOIDs.add((String) objectMBEOIDs);
                  } else if (objectMBEOIDs instanceof StringList) {
                      strListObjOIDs.addAll((StringList) objectMBEOIDs);
                  }

                  if (!strListObjOIDs.isEmpty()) {
                      StringItr strItr = new StringItr(strListObjOIDs);
                      while (strItr.next()) {
                          strRelId = (String) strItr.value();
                          DomainRelationship.setAttributeValue(context, strRelId, ATTRIBUTE_WMS_QTY_SUBMITTED_TILL_DATE,
                                  strMBEQty);
                          DomainRelationship.setAttributeValue(context, strRelId, ATTRIBUTE_WMS_ABS_MBE_OID,
                        		  strMBEOid);
                      }
                  }
              }
    	 
    	 
    	   }catch(Exception e) {
    		 
    		e.printStackTrace(); 
    	 }
    	 return 0;
     }
     @com.matrixone.apps.framework.ui.ProgramCallable
     public MapList getFiles(Context context,String[] args) throws Exception{
      
    	 MapList mlFiles=new MapList();
    	try {
    	 
    
    		 HashMap programMap         = (HashMap) JPO.unpackArgs(args);
             String  masterObjectId     = (String) programMap.get("objectId");
             DomainObject masterObject  = DomainObject.newInstance(context, masterObjectId);
            // DocumentUtil.checkout(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7)
             FileList  _fileList =  masterObject.getFiles(context);
             FileItr  fileItr = new FileItr(_fileList);
             Iterator<File>  itr  =   fileItr.iterator();
             String _fileId = "";
             String _fileName ="";
             String _fileFormat ="";
            
              while(itr.hasNext()) {
            	  Map m =new HashMap();
                  File file = itr.next();
             	 _fileId = file.getId();
              	 _fileName = file.getName();
            	 _fileFormat = file.getFormat();
            	 
                 m.put(DomainConstants.SELECT_ID, _fileId);
                 m.put("FileName", _fileName);
                 m.put("objReadAccess", "TRUE");
                 m.put("FileFormat", _fileFormat);
             	 
             	 System.out.println(_fileName);
             	 System.out.println(_fileId);
             	 System.out.println(_fileFormat);
             	mlFiles.add(m) ;
              }
    	 
    	 
    	 
    	}catch(Exception e) {
    		
    		e.printStackTrace();
    	}
    	return mlFiles;
     }
     
     public Vector getFileColumn(Context context,String[] args) throws Exception
     {
    	Vector colVector = new Vector();
	     try { 
	     	 
	    	 HashMap programMap         = (HashMap) JPO.unpackArgs(args);
	    	 HashMap columnMap = (HashMap) programMap.get("columnMap");
	    	 Map settings = (Map) columnMap.get("settings");
	    	 String sColumnKey = (String) settings.get("ColumnName");
             String  masterObjectId     = (String) programMap.get("objectId");
	    	 MapList objectList  = (MapList) programMap.get("objectList");
	    	 Iterator<Map> itr = objectList.iterator();
	    	 while(itr.hasNext()) {
	    		 Map m = itr.next();
	    		 colVector.add((String)m.get(sColumnKey));
	    	 }
	    	 
	    }catch(Exception e) {
	    	e.printStackTrace();
	    } 
	  return colVector;
     }
     
     public Vector getDownloadLink(Context context,String[] args) throws Exception
     {
    	Vector colVector = new Vector();
	     try { 
	     	 
	    	 String downloadURL="../wms/wmsDownloadFileProcess.jsp?action=download";
	    	 String strDownLoadTip="Download";
	    	 String _fileId = "";
             String _fileName ="";
             String _fileFormat ="";
	    	 HashMap programMap         = (HashMap) JPO.unpackArgs(args);
	    	  HashMap paramList = (HashMap) programMap.get("paramList");
	    	// Map settings = (Map) columnMap.get("settings");
	    	// String sColumnKey = (String) settings.get("ColumnName");
             String  strMBEId     = (String) paramList.get("objectId");
	    	 MapList objectList  = (MapList) programMap.get("objectList");
	    	
	    	 Iterator<Map> itr = objectList.iterator();
	    	 while(itr.hasNext()) {
	    		 Map m = itr.next();
	    		 _fileName = (String) m.get("FileName");
	    		 _fileFormat = (String) m.get("FileFormat");
	    		 _fileId = (String) m.get("id");
	    		  downloadURL=downloadURL+"&amp;fileName="+_fileName+"&amp;fileFormat="+_fileFormat+"&amp;fileId="+_fileId+"&amp;objectId="+strMBEId;
	    		  StringBuilder sb=new StringBuilder();
	    		 sb.append("<a href=\"" + downloadURL + "\"  target=\"hiddenFrame\"   >");
	 	    	 sb.append("<img border=\"0\" src=\"../common/images/iconActionDownload.gif\" alt=\""
	 			+ strDownLoadTip + "\" title=\"" + strDownLoadTip + "\"></img></a>&#160;");
	    		
	    		 colVector.add(sb.toString());
	    	 }
	    	 
	    }catch(Exception e) {
	    	e.printStackTrace();
	    } 
	  return colVector;
     }
     
     
     /**
      * Method will Add MBE Quantity from Type to AtySubmitedTillDate in
      * MBEAvtivities Relationip
      * 
      * @param context the eMatrix <code>Context</code> object
      * @throws Exception
      *             if the operation fails
      * @author WMS
      * @since 418
      */
     public void updateQtySubmittedTillDate(Context context, String[] args) throws Exception {
         boolean isContextPushed = false;
         try {
             
             String strToObjItemID = args[0];
             String strRELID = args[1];
             DomainObject domObjToObject = DomainObject.newInstance(context, strToObjItemID);
             String strMBEQuantity = domObjToObject.getAttributeValue(context,ATTRIBUTE_WMS_MBE_QUANTITY);
             DomainRelationship.setAttributeValue(context, strRELID, ATTRIBUTE_WMS_QTY_SUBMITTED_TILL_DATE, strMBEQuantity);
         } catch (Exception exception) {
                   
             exception.printStackTrace();
             throw exception;
         } 
     }

     /** 
 	 * Method will update MBE Quantity
 	 * 
 	 * @param context the eMatrix <code>Context</code> object
 	 * @param args with program arguments
 	 *             args[0]- MBE OID
 	 * @throws Exception if the operation fails
 	 * @author WMS
 	 * @since 418
 	 */
     public void updateMBEQuantity(Context context, String[] args) throws Exception {
         boolean isContextPushed = false;
         try {
             String strMBEOID = args[0];
             if (UIUtil.isNotNullAndNotEmpty(strMBEOID)) {
                 DomainObject domObjMBE = DomainObject.newInstance(context, strMBEOID);
                 DomainObject domObjMBItem = DomainObject.newInstance(context);
                 MapList mapListConnectedActivities = getMBEActivities(context, domObjMBE);    
 				//MapList mapListPaidPaymentScheduleItems = ${CLASS:WMSPaymentScheduleJPO}.getPaidPaymentScheduleItems(context, domObjMBE);
                 //mapListConnectedActivities.addAll(mapListPaidPaymentScheduleItems);                //Get whether the MBE is Running or not and also if its first revision or not
                 StringList slObjSelects = new StringList(3);
                // slObjSelects.add("attribute["+WMSDomainConstant.ATTRIBUTE_MBE_TYPE+"]");
                 slObjSelects.add("previous");
                 slObjSelects.add("previous.id");
                 Map mObjInfo = domObjMBE.getInfo(context, slObjSelects);
               //  String strPrevious = (String)mObjInfo.get("previous");
                 String strMBType = DomainConstants.EMPTY_STRING; //(String)mObjInfo.get("attribute["+WMSDomainConstant.ATTRIBUTE_MBE_TYPE+"]");
               /*  if(UIUtil.isNullOrEmpty(strMBType))
                 {
                     strMBType = DomainConstants.EMPTY_STRING;
                 }
                 //if MBE is running MBE and not first revision then call another method
                 if ("Running".equals(strMBType) && strPrevious.length() > 0) {
                     String strPreviousId = (String)mObjInfo.get("previous.id");
                     updateRunningMBEQuantity(context, strPreviousId, mapListConnectedActivities);
                     //domObjMBItem.setAttributeValues(context, attrMap);
                 } else {*/
                     Map attrMap = new HashMap();
                     float itemQty = 0;                
                     Iterator iterator = mapListConnectedActivities.iterator();
                     while (iterator.hasNext()) {
                         Map<String,String> mapActivity = (Map<String,String>) iterator.next();
                         String strMBItemId = mapActivity.get(DomainObject.SELECT_ID);
                         String strObjType = mapActivity.get(DomainObject.SELECT_TYPE);
                         domObjMBItem.setId(strMBItemId);
                         String strItemMBEQunatity = mapActivity.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
                         String strTotalQunatity = mapActivity.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
                         itemQty = 0;
                        if (UIUtil.isNullOrEmpty(strItemMBEQunatity)) {
                             strItemMBEQunatity = "0";
                         }
                         if (UIUtil.isNullOrEmpty(strTotalQunatity)) {
                             strTotalQunatity = "0";
                         }
                         itemQty = itemQty + Float.parseFloat(strItemMBEQunatity);
                         itemQty = itemQty + Float.parseFloat(strTotalQunatity);
                         attrMap.put(ATTRIBUTE_WMS_MBE_QUANTITY, String.valueOf(itemQty));
                         if(TYPE_WMS_MEASUREMENT_TASK.equals(strObjType))
                         {
                           //  attrMap.put(WMSDomainConstant.ATTRIBUTE_PREVIOUS_MBE_QUANTITY,strItemMBEQunatity);
                         }
                         ContextUtil.pushContext(context, PropertyUtil.getSchemaProperty(context, "person_UserAgent"),DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
                         isContextPushed = true;
                         domObjMBItem.setAttributeValues(context,attrMap);                        
                     }
                 }
            // }
         }
         catch (Exception exception) 
         {
             exception.printStackTrace();
         }
         finally
         {
             if (isContextPushed)
             {
                 ContextUtil.popContext(context);
             }
         }
    
     }
    
     /** Trigger method on MBE Create state promote which checks for Contract Value 
      * 
      * 
      * 
      * @param context
      * @param args
      * @return
      */
     
     
     public  int triggerContractValueLimitCheck(Context context ,String[] args) {
        	 try {
                 String strMBEOid = args[0];
        		 String strMBEName=args[1];
        		 SelectList selListBusSelects     = new SelectList(7);
                 selListBusSelects.add(DomainConstants.SELECT_ID);
                 selListBusSelects.add(DomainConstants.SELECT_TYPE);
                 selListBusSelects.add(DomainConstants.SELECT_NAME);
                 
                 // selListBusSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_COST+"]");
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
                 selListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
                // selListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]"); 
                 SelectList selListRelSelects     = new SelectList(2);
                 selListRelSelects.add(DomainRelationship.SELECT_ID);
                 selListRelSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
                 selListRelSelects.add("attribute["+ATTRIBUTE_WMS_QTY_SUBMITTED_TILL_DATE+"]");
                 selListRelSelects.add("from.id");
                 selListRelSelects.add("from.current");
        		 
        		 DomainObject domMBE= DomainObject.newInstance(context, strMBEOid);
        	 	// MapList mlCurrentBOQs  = getMBEActivities(context,domMBE);
        		 StringList slSelects = new StringList();
        		 slSelects.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
        		 slSelects.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
        		 slSelects.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
        		 Map mWOInfo = domMBE.getInfo(context, slSelects);
        		 
        	 	 String strWOId = (String)mWOInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
        	 	 double dWOContractValue = Double.parseDouble((String)mWOInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]"));
				 dWOContractValue = dWOContractValue*1.1;
				  System.out.println("----dWOContractValue"+dWOContractValue);
				 String strTypeOfContract = (String)mWOInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
				 
        		 DomainObject domWO=DomainObject.newInstance(context, strWOId);
        		 Pattern typePattern = new Pattern(TYPE_WMS_MEASUREMENT_BOOK_ENTRY);
        		 typePattern.addPattern(TYPE_WMS_MEASUREMENT_TASK);
        		 
        		 Pattern relPattern = new Pattern(RELATIONSHIP_WMS_WORK_ORDER_MBE);
        		 relPattern.addPattern(RELATIONSHIP_WMS_MBE_ACTIVITIES);
        		 MapList mapListItems = domWO.getRelatedObjects(context,
        				    relPattern.getPattern(),                         // relationship pattern
                            typePattern.getPattern(),                                    // object pattern
							false,                                                        // to direction
							true,                                                       // from direction
							(short)2,                                                      // recursion level
							selListBusSelects,                                                 // object selects
							selListRelSelects,                                                         // relationship selects
							DomainConstants.EMPTY_STRING,                                // object where clause
							DomainConstants.EMPTY_STRING,                                // relationship where clause
							(short)0,                                                      // No expand limit
							DomainConstants.EMPTY_STRING,                                // postRelPattern
							TYPE_WMS_MEASUREMENT_TASK,                                                // postTypePattern
							null);          
        		
        		 Iterator<Map> itr = mapListItems.iterator();
        		 String strMTOid = DomainConstants.EMPTY_STRING;
        		 double dQtySubmittedtd= 0.0;
        		 double dRunningQty= 0.0;
        		 double dRate= 0.0;
        		 Map<String,Map> mMTDetails= new HashMap<String,Map>();
        		 Map<String,Map> mCurrentMT = new HashMap<String,Map>();
        		 double dTotalQtySubmittedtd= 0.0;
        		 String strTitle=DomainConstants.EMPTY_STRING;
        		 String strMBEId=DomainConstants.EMPTY_STRING;
        		 String strMBEState=DomainConstants.EMPTY_STRING;
        		 Map mMBEDetails = new HashMap();
        		 String strUOM = DomainConstants.EMPTY_STRING;
        		 while(itr.hasNext()) {
        			 dQtySubmittedtd=0;
        			 dRunningQty=0;
        			 dRate=0;
        			 Map m = itr.next();
        			 Map mDetails = new HashMap();
        			 Map mMBETaskDetails = new HashMap();
        			 strMTOid= (String)m.get(DomainConstants.SELECT_ID);
        			 strMBEId= (String)m.get("from.id");
        			 strUOM=(String)m.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
        			 strMBEState= (String)m.get("from.current");
        			 dQtySubmittedtd=Double.parseDouble((String)m.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]"));
        			 
        			 if(strMBEOid.equalsIgnoreCase(strMBEId)) {
        				 mMBETaskDetails.put("MBESTATE", strMBEState);
        				 mMBETaskDetails.put("MBEQTY", (String) m.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]"));
        				 mMBEDetails.put(strMTOid, mMBETaskDetails);
        				 mCurrentMT.put(strMBEOid, mMBEDetails);
        			 }
        	  			 dRate= Double.parseDouble((String)m.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]"));
	        			 strTitle=(String)m.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
	        			 if(mMTDetails.containsKey(strMTOid)) {
	        				 mDetails = mMTDetails.get(strMTOid);
	        			     dRunningQty= Double.parseDouble((String)mDetails.get("TotalRunning"));
	        			 }
	        			 if(!strMBEState.equalsIgnoreCase("Submitted")) 
       				 		  dRunningQty=dRunningQty+Double.parseDouble( (String) m.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]"));
	        		 
        			 
        		  	   mDetails.put(("TotalSubmitted"), String.valueOf(dQtySubmittedtd));
        		       mDetails.put(("TotalRunning"), String.valueOf(dRunningQty));
        			   mDetails.put(("Rate"), String.valueOf(dRate));
        			   mDetails.put(("name"),strTitle);
        			   mDetails.put(("UoM"),strUOM);
        			   mMTDetails.put(strMTOid, mDetails);
        			 
        		 }
        		
        		Set<String> set =  mMTDetails.keySet();
        		Iterator<String> itrSet = set.iterator();
        		String strKey=DomainConstants.EMPTY_STRING;
        		Map m =new HashMap();
        		double dTotalContractValue=0;
        		 StringBuilder sb=new StringBuilder();
            	 sb.append("=====================================================================================================================\n");
            	 sb.append("=                                                                                                                    =\n");
            	 sb.append("=   Title   UoM      Rate   Since Previous Bill    Submitted Till Date   Total Runnning Cost  Total Submitted Cost  =\n");
            	 sb.append("=                                                                                                                    =\n");
            	 sb.append("======================================================================================================================\n");
            	double dMBEQty=0;
            	Map mMTData = (Map)mCurrentMT.get(strMBEOid);
        		while(itrSet.hasNext()) {
        			dMBEQty=0;
        			strKey=itrSet.next();
        			m = mMTDetails.get(strKey);
        			dQtySubmittedtd = Double.parseDouble((String) m.get("TotalSubmitted"));
        			dRunningQty= Double.parseDouble((String) m.get("TotalRunning"));
        			dRate= Double.parseDouble((String) m.get("Rate"));
        			strUOM=(String)m.get("UoM");
        			strTitle=(String) m.get("name");
       			    dTotalContractValue=dTotalContractValue+((dQtySubmittedtd+dRunningQty)*dRate);
					System.out.println("----dTotalContractValue----"+dTotalContractValue);
        	 		/*if(dRunningQty==0) {
        	 			dRunningQty=dQtySubmittedtd;
        	 			dQtySubmittedtd=0;
        	 		}*/
        	 		 if(mMTData.containsKey(strKey)) {
	        	 	 		 Map mDataDetails  =(Map) mMTData.get(strKey);
	        	 	 		 dMBEQty =Double.parseDouble((String) mDataDetails.get("MBEQTY")); 
	        	 	 		 String strState = (String) mDataDetails.get("MBESTATE");
	        	 	 		 if(strState.equalsIgnoreCase("Review") && dQtySubmittedtd==0)  {dQtySubmittedtd=dMBEQty;dMBEQty=0 ;}// if this is 1st MBE and submitted running should e moved as 
	        	 	 		 sb.append("= ").append(strTitle).append("     ")
	        	 	 		.append(strUOM).append("       ")
	        	 	 	 	.append(dRate).append("        ")
	        	 	 		.append(dMBEQty).append("             ")
	        	 	 		.append(dQtySubmittedtd).append("               ")
	        	 	 		.append(dMBEQty*dRate).append("                  ")
	            	 		.append(dQtySubmittedtd*dRate).append("                               =\n");
        			 }
         	 		
        		 }
        		DecimalFormat df2 = new DecimalFormat(".##");
        		
                if(dTotalContractValue>dWOContractValue && (UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && "EPC".equalsIgnoreCase(strTypeOfContract) == false))
        		{
        		 String strAlert = 	MessageUtil.getMessage(context, null, "WMS.alert.ContractValueBeyondDefinedContractValue",
        					new String[] {df2.format(dTotalContractValue),String.valueOf(dWOContractValue)}, null, context.getLocale(),
        					"wmsStringResource");	
        		 emxContextUtil_mxJPO.mqlNotice(context,strAlert);
        		  return 1;
        		}
        		
          		String strFilePath  = context.createWorkspace();
          	    String strFileName= strMBEName+".txt";
        		java.io.File file = new java.io.File(strFilePath, strFileName);
        	    FileUtils.writeStringToFile(file, sb.toString());
        	    domMBE.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strFilePath);
        	    file.delete();
        	  
        	 }catch(Exception e) {
        		 e.printStackTrace();
        	 }
        
         
         return 0;
         
    
        }
     
     
     /**
      * Method to get the disconnected Tasks under the MBE
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return String containing the message
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public String removeDeductionss (Context context, String[] args) throws Exception 
     {
         try
         {
             
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
                       
             if(emxTableRowId !=null && emxTableRowId.length>0)
             {
                 
                 ArrayList<String> arrayListRelOIDs = new ArrayList<String>();
                 for(int i=0;i<emxTableRowId.length;i++)
                 {
                   StringTokenizer st = new StringTokenizer(emxTableRowId[i], "|");
                   String sObjId = st.nextToken();
                   arrayListRelOIDs.add(sObjId);          
                  
                         while (st.hasMoreTokens()) 
                         {
                            sObjId = st.nextToken();
                         }      
                 }        
                   
 				 WMSUtil_mxJPO.disconnect(context, arrayListRelOIDs);
                 return "Selected objects sucessfully removed";

             }                    
             return "Selected objects sucessfully removed";
         }catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
     
     /**
      * Method to get the connected MBE under the Item(Submitted)
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command
      * @return mapListMBEs MapList containing the MBE IDs
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public MapList getActivitySubmittedMBEs (Context context, String[] args) throws Exception 
     {
         try
         {
             MapList mapListMBEs = new MapList();
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             String strObjectId = (String) programMap.get("objectId");
             String strMBEOID             = (String) programMap.get("mbeOID");
             if(UIUtil.isNotNullAndNotEmpty(strObjectId))
             {
                 DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
                 MapList mapListMBEsTemp = getActivityMBEs(context, domObjMBE);
                 //TODO convert to Constant entries
 				mapListMBEs = WMSUtil_mxJPO.getSubMapList(mapListMBEsTemp, DomainConstants.SELECT_CURRENT, "Submitted");
                 insertKeyValue(mapListMBEs, DomainConstants.SELECT_LEVEL, "1");
             }
             return mapListMBEs;
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
     /**
      * Function to get the Tasks connected to the selected MBE
      *
      * @param context the eMatrix <code>Context</code> object
      * @param domObjItem DomainObject instance of selected Item
      * @return mapListTasks MapList containing the MBEs connected to Work Order with ID
      * @throws FrameworkException if the operation fails
      * @author WMS
      * @since 418
      */
     private MapList getActivityMBEs(Context context, DomainObject domObjItem)
             throws FrameworkException {
         try
         {
             SelectList selListBusSelects     = new SelectList(1);
             selListBusSelects.add(DomainConstants.SELECT_ID);
             selListBusSelects.add(DomainConstants.SELECT_CURRENT);
             SelectList selListRelSelects     = new SelectList(1);
             selListRelSelects.add(DomainRelationship.SELECT_ID);

             MapList mapListMBEs = domObjItem.getRelatedObjects(context, // matrix context
            		 RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship pattern
            		 TYPE_WMS_MEASUREMENT_BOOK_ENTRY, // type pattern
                     selListBusSelects, // object selects
                     selListRelSelects, // relationship selects
                     true, // to direction
                     false, // from direction
                     (short) 1, // recursion level
                     DomainConstants.EMPTY_STRING, // object where clause
                     DomainConstants.EMPTY_STRING, // relationship where clause
                     0);
             return mapListMBEs;
         }
         catch(FrameworkException frameworkException)
         {
             throw frameworkException;
         }
     }
	/** 
     * Method will connect AbstractMBE/MBE and RouteTemplate, When we have only one AMBE/MBE Route template on work order
     * 
     * @param context the eMatrix <code>Context</code> object    
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public void connectAMBERouteTemplate (Context context, String args[]) throws Exception {
		Map mObjectDetail = null;
		MapList mlConnectedRouteTemplate = null;
		String strTypeSelected = null;
		String strRelWhereClause = null;
		String strRTId = null;
		boolean isContextPushed = false;
		try{
			
			String strWOId = args[0];
			String strAMBEId = args[1];
			String strRange = args[2];
			String strRelationshipName = args[3];
			
			StringList slBusSelects = new StringList(1);
			slBusSelects.add(DomainConstants.SELECT_ID);
			 
			strRelWhereClause = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] =='"+strRange+"'";
			if(UIUtil.isNotNullAndNotEmpty(strWOId)&& UIUtil.isNotNullAndNotEmpty(strAMBEId)) {
				ContextUtil.pushContext(context);
				isContextPushed = true;
				DomainObject domWO = DomainObject.newInstance(context,strWOId);
				mlConnectedRouteTemplate = domWO.getRelatedObjects(context, // matrix context
																	RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE, // relationship pattern
																	DomainConstants.TYPE_ROUTE_TEMPLATE, // type pattern
																	slBusSelects, // object selects
																	null, // relationship selects
																	false, // to direction
																	true, // from direction
																	(short) 0, // recursion level
																	DomainConstants.EMPTY_STRING, // object where clause
																	strRelWhereClause, // relationship where clause
																	0);
				if(mlConnectedRouteTemplate.size() == 1){
					mObjectDetail = (Map)mlConnectedRouteTemplate.get(0);
					strRTId = (String)mObjectDetail.get(DomainConstants.SELECT_ID);
					
					DomainRelationship.connect(context, strAMBEId, PropertyUtil.getSchemaProperty(strRelationshipName), strRTId, true);
				}
			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;            
		}finally{
			if(isContextPushed){
				ContextUtil.popContext(context);
			}
		}
	}

	/** 
      * Method will connect the Work Order In Projects
      * @param args Packed program and request maps for the table
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
    @com.matrixone.apps.framework.ui.PostProcessCallable
    public Map updateMeasurementHistory(Context context, String[] args) throws Exception {
        HashMap mapReturnMap = new HashMap();
        try {
			DecimalFormat decFor = new DecimalFormat("#.###");
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
            HashMap hmTableData 			= (HashMap) programMap.get("tableData");
            HashMap hmRequestMap 			= (HashMap) programMap.get("requestMap");
			String strObjectid = (String)hmRequestMap.get("objectId");
			String strCurrentState = DomainConstants.EMPTY_STRING;
			
			if(UIUtil.isNotNullAndNotEmpty(strObjectid)){
				DomainObject doMBE = new DomainObject(strObjectid);
				strCurrentState = doMBE.getInfo(context,DomainConstants.SELECT_CURRENT);
			}
			
			MapList mlMeasList = new MapList();
			Map mMeasInfoMap = null;
			
            MapList mlObjectList 			= (MapList) hmTableData.get("ObjectList");

			
			String strPersonId = PersonUtil.getPersonObjectID(context);
			StringList slPersonSelect = new StringList();
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			
			DomainObject doPerson = new DomainObject(strPersonId);
			Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
			String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			
			if(UIUtil.isNullOrEmpty(strFirstName)){
				strFirstName = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strLastName)){
				strLastName = DomainConstants.EMPTY_STRING;
			}
			
			String strUser = strFirstName + " " +strLastName;
			
			if(mlObjectList != null){				
				String strType = DomainConstants.EMPTY_STRING;
				String strMeasId = DomainConstants.EMPTY_STRING;
				String strMeasRelId = DomainConstants.EMPTY_STRING;
				String strFrequency = DomainConstants.EMPTY_STRING;
				String strLength = DomainConstants.EMPTY_STRING;
				String strBreadth = DomainConstants.EMPTY_STRING;
				String strDepth = DomainConstants.EMPTY_STRING;
				String strRadius = DomainConstants.EMPTY_STRING;
				String strUWD = DomainConstants.EMPTY_STRING;
				String strIdDeduction = DomainConstants.EMPTY_STRING;
				String strCoFactor = DomainConstants.EMPTY_STRING;
				String strMBEQty = DomainConstants.EMPTY_STRING;
				String strHistoryOld = DomainConstants.EMPTY_STRING;
				String strHistoryNew = DomainConstants.EMPTY_STRING;
				String strTime  =  DomainConstants.EMPTY_STRING;
				String strLastEntry  =  DomainConstants.EMPTY_STRING;
				String strLastValue = DomainConstants.EMPTY_STRING;
				String strIsShape = DomainConstants.EMPTY_STRING;
				String strShapeName = DomainConstants.EMPTY_STRING;
				String strDim1 = DomainConstants.EMPTY_STRING;
				String strDim2 = DomainConstants.EMPTY_STRING;
				String strDim3 = DomainConstants.EMPTY_STRING;
				String strDim4 = DomainConstants.EMPTY_STRING;
				String strTitle = DomainConstants.EMPTY_STRING;
				String strScope = DomainConstants.EMPTY_STRING;
				
				Calendar calendarDate = Calendar.getInstance();
				String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
				SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
				strTime = formatter.format(calendarDate.getTime());
			
				Map mTemp = null;
				Map mObjInfo = null;
				
				int iOldHistoryEntrySize = 0;
				
				DomainObject doMeas = null;
				StringList slHistoryEntryList = new StringList();
			
				StringList slSelect = new StringList();
				slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_UWD+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_HISTORY+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_DIMENSION_1+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_DIMENSION_2+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_DIMENSION_3+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_DIMENSION_4+"].value");
				slSelect.add("attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"].value");
				
				for(int i=0;i<mlObjectList.size();i++){
					iOldHistoryEntrySize = 0;
					strFrequency = DomainConstants.EMPTY_STRING;
					strLength = DomainConstants.EMPTY_STRING;
					strBreadth = DomainConstants.EMPTY_STRING;
					strDepth = DomainConstants.EMPTY_STRING;
					strRadius = DomainConstants.EMPTY_STRING;
					strUWD = DomainConstants.EMPTY_STRING;
					strIdDeduction = DomainConstants.EMPTY_STRING;
					strCoFactor = DomainConstants.EMPTY_STRING;
					strMBEQty = DomainConstants.EMPTY_STRING;
					strHistoryOld = DomainConstants.EMPTY_STRING;
					strHistoryNew = DomainConstants.EMPTY_STRING;
					strIsShape = DomainConstants.EMPTY_STRING;
					strDim1 = DomainConstants.EMPTY_STRING;
					strDim2 = DomainConstants.EMPTY_STRING;
					strDim3 = DomainConstants.EMPTY_STRING;
					strDim4 = DomainConstants.EMPTY_STRING;
					strTitle = DomainConstants.EMPTY_STRING;
					strShapeName = DomainConstants.EMPTY_STRING;
					strScope = DomainConstants.EMPTY_STRING;
					
					mTemp = (Map)mlObjectList.get(i);
					strType = (String)mTemp.get(DomainConstants.SELECT_TYPE);
					if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENTS.equals(strType)){
						strMeasId = (String)mTemp.get(DomainConstants.SELECT_ID);		
						strMeasRelId = (String)mTemp.get(DomainRelationship.SELECT_ID);		
						if(UIUtil.isNotNullAndNotEmpty(strMeasRelId)){
							DomainRelationship domrelID= DomainRelationship.newInstance(context,strMeasRelId);
							strMBEQty = domrelID.getAttributeValue(context,ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY);
						}else{
							strMBEQty = "0";
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strMeasId)){
							doMeas = new DomainObject(strMeasId);
							mObjInfo = (Map)doMeas.getInfo(context,slSelect);
							if(mObjInfo != null && mObjInfo.isEmpty() == false){
								strFrequency = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"].value");
								strLength = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"].value");
								strBreadth = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"].value");
								strDepth = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"].value");
								strRadius = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"].value");
								strUWD = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_UWD+"].value");
								strIdDeduction = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"].value");
								strCoFactor = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"].value");
								strHistoryOld = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_HISTORY+"].value");
								strIsShape = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"].value");
								strDim1 = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_DIMENSION_1+"].value");
								strDim2 = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_DIMENSION_2+"].value");
								strDim3 = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_DIMENSION_3+"].value");
								strDim4 = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_DIMENSION_4+"].value");
								strTitle = (String)mObjInfo.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
								strShapeName = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value");
								strScope = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"].value");
								
								if(UIUtil.isNotNullAndNotEmpty(strFrequency))
									strFrequency = decFor.format(Double.valueOf(strFrequency));
								if(UIUtil.isNotNullAndNotEmpty(strLength))
									strLength = decFor.format(Double.valueOf(strLength));
								if(UIUtil.isNotNullAndNotEmpty(strBreadth))
									strBreadth = decFor.format(Double.valueOf(strBreadth));
								if(UIUtil.isNotNullAndNotEmpty(strDepth))
									strDepth = decFor.format(Double.valueOf(strDepth));
								if(UIUtil.isNotNullAndNotEmpty(strRadius))
									strRadius = decFor.format(Double.valueOf(strRadius));
								if(UIUtil.isNotNullAndNotEmpty(strCoFactor))
									strCoFactor = decFor.format(Double.valueOf(strCoFactor));
								if(UIUtil.isNotNullAndNotEmpty(strDim1))
									strDim1 = decFor.format(Double.valueOf(strDim1));
								if(UIUtil.isNotNullAndNotEmpty(strDim2))
									strDim2 = decFor.format(Double.valueOf(strDim2));
								if(UIUtil.isNotNullAndNotEmpty(strDim3))
									strDim3 = decFor.format(Double.valueOf(strDim3));
								if(UIUtil.isNotNullAndNotEmpty(strDim4))
									strDim4 = decFor.format(Double.valueOf(strDim4));
							}
							if(UIUtil.isNotNullAndNotEmpty(strMBEQty))
									strMBEQty = decFor.format(Double.valueOf(strMBEQty));

							if(UIUtil.isNotNullAndNotEmpty(strIsShape) && "No".equalsIgnoreCase(strIsShape)){
								strHistoryNew = strUser+"|"+strTime+"|"+strFrequency+"|"+strLength+"|"+strBreadth+"|"+strDepth+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor+"|"+strScope+"|"+strMBEQty;
								strLastValue = strFrequency+"|"+strLength+"|"+strBreadth+"|"+strDepth+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor+"|"+strScope+"|"+strMBEQty;
							}else if(UIUtil.isNotNullAndNotEmpty(strIsShape) && "Yes".equalsIgnoreCase(strIsShape)){
								if(UIUtil.isNotNullAndNotEmpty(strShapeName) && ("Circle".equalsIgnoreCase(strShapeName) || "Cylinder".equalsIgnoreCase(strShapeName) || "Cone".equalsIgnoreCase(strShapeName) || "Sphere".equalsIgnoreCase(strShapeName) || "Hemisphere".equalsIgnoreCase(strShapeName))){
									strHistoryNew = strUser+"|"+strTime+"|"+strFrequency+"|"+strDim1+"|"+strDim3+"|"+strDim4+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor+"|"+strScope+"|"+strMBEQty;
									strLastValue = strFrequency+"|"+strDim1+"|"+strDim3+"|"+strDim4+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor+"|"+strScope+"|"+strMBEQty;
								}else{
									strHistoryNew = strUser+"|"+strTime+"|"+strFrequency+"|"+strDim2+"|"+strDim3+"|"+strDim4+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor+"|"+strScope+"|"+strMBEQty;
									strLastValue = strFrequency+"|"+strDim2+"|"+strDim3+"|"+strDim4+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor+"|"+strScope+"|"+strMBEQty;
								}
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strHistoryNew) || "Create".equals(strCurrentState) || "Formalized".equals(strCurrentState)){
								if(UIUtil.isNullOrEmpty(strHistoryOld)){
									strHistoryOld = strHistoryNew;
								}else if("Create".equals(strCurrentState) || "Formalized".equals(strCurrentState)){
									strHistoryOld = strHistoryNew;
								}else{
									slHistoryEntryList = FrameworkUtil.split(strHistoryOld, "\n");
									iOldHistoryEntrySize = slHistoryEntryList.size();
									strLastEntry = (String)slHistoryEntryList.get(iOldHistoryEntrySize-1);
									if(strLastEntry.startsWith(strUser)){
										slHistoryEntryList.remove(strLastEntry);
										slHistoryEntryList.add(iOldHistoryEntrySize-1,strHistoryNew);
										for(int k=0;k<slHistoryEntryList.size();k++){
											if(k==0){
												strHistoryOld = (String)slHistoryEntryList.get(k);
											}else{
												strHistoryOld = strHistoryOld +"\n"+(String)slHistoryEntryList.get(k);
											}
										}
									}else{
										if(strHistoryOld.endsWith(strLastValue)==false){
											strHistoryOld = strHistoryOld + "\n"+ strHistoryNew;
										}
									}
								}

								doMeas.setAttributeValue(context, ATTRIBUTE_WMS_MEASUREMENT_HISTORY, strHistoryOld);
								if(UIUtil.isNotNullAndNotEmpty(strCurrentState) && "Review".equals(strCurrentState)){
									StringList slHistoryLines = FrameworkUtil.split(strHistoryOld,"\n");
									if(slHistoryLines.size()>1){
										doMeas.setAttributeValue(context, ATTRIBUTE_WMS_IS_MODIFIED, "Yes");
										mMeasInfoMap = new HashMap();
										mMeasInfoMap.put(DomainObject.SELECT_ID,strMeasId);
										mMeasInfoMap.put(DomainObject.ATTRIBUTE_TITLE,strTitle);
										mlMeasList.add(mMeasInfoMap);
									}
								}
							}
						}
					}

				}
			}	
			
            mapReturnMap.put("Action","success");
        } catch (Exception exception) {
         exception.printStackTrace();
            mapReturnMap.put("Action","Stop");
            mapReturnMap.put("Message",exception.getMessage());
        }
        return mapReturnMap;
    }

	
	
	
	public Vector getMeasurementHistory(Context context,String[] args) throws Exception
     {
    	Vector colVector = new Vector();
	     try { 
	     	 
	    	 String strURL="../wms/wmsMeasurementHistory.jsp";
	    	 HashMap programMap         = (HashMap) JPO.unpackArgs(args);
			 HashMap paramList = (HashMap) programMap.get("paramList");
	    	 MapList objectList  = (MapList) programMap.get("objectList");
	    	 StringBuilder sb= null;
	    	 Iterator<Map> itr = objectList.iterator();
			 String strType = DomainConstants.EMPTY_STRING;
			 String strId = DomainConstants.EMPTY_STRING;
	    	 while(itr.hasNext()) {
	    		 Map m = itr.next();
				 strType = (String)m.get(DomainObject.SELECT_TYPE);
				 strId = (String)m.get(DomainObject.SELECT_ID);
				 sb=new StringBuilder();
				 if(strType.equals(TYPE_WMS_MEASUREMENTS)){
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strId+"','600','400','false');\" >");            
					sb.append("<img border='0' title='History' src='../common/images/iconNewWindow.gif' height='15px' name='History' id='History' alt='History' onmouseover='openHistory()'/>");
					sb.append("</a>");
					sb.append("<script>");
					sb.append("function openHistory(){");
					sb.append("javascript:showModalDialog('"+strURL+"?objectId="+strId+"','600','400','false');");
					sb.append("}");
					sb.append("</script>");
				 }				
	    		 colVector.add(sb.toString());
	    	 }
	    	 
	    }catch(Exception e) {
	    	e.printStackTrace();
	    } 
	  return colVector;
     }
	
	/**
     * This method is display the total quantity and agreed rate in the change item form
     * @param context - the eMatrix <code>Context</code> object
     * @param String array args containing the programMap
     * @return - String
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */    
    public String getChangeItemAttriubteValue(Context context, String[] args) throws Exception {
        StringBuilder sb = new StringBuilder();
        try 
        { 
            HashMap programMap = (HashMap) JPO.unpackArgs(args);                
            HashMap paramMap = (HashMap) programMap.get("paramMap");                
            String strObjectId       = (String) paramMap.get("objectId");
            if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
                DomainObject domItem = DomainObject.newInstance(context, strObjectId);
                StringList sSelect = new StringList();
                sSelect.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
                sSelect.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
                sSelect.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
                String strTotalQuantity = DomainConstants.EMPTY_STRING;
                String strReducedSORRate = DomainConstants.EMPTY_STRING;
                String strTitle = DomainConstants.EMPTY_STRING;
                Map map = domItem.getInfo(context, sSelect);
                if(map!=null&&!map.isEmpty())
                {
                    strTotalQuantity = (String)map.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
					double doubleTotalQUantity = WMSUtil_mxJPO.convertToDouble(strTotalQuantity);
					MapList mapListDepartment = WMSUtil_mxJPO.getContextUserDepartment(context);
					StringList strListDepartment = WMSUtil_mxJPO.convertToStringList(mapListDepartment, DomainConstants.SELECT_NAME);
					int changePercent = 10;
					if(strListDepartment.contains("NRDA")) {
						changePercent = 25;
					}
                    doubleTotalQUantity = doubleTotalQUantity*changePercent/100;
                    strReducedSORRate = (String)map.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
                    strTitle = (String)map.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
                    Locale strLocale = context.getLocale();
                    String strTitleHeader = "Title";//EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.attribute.WMSTitle");
                    String strQtyHeader = "Item Qty";//EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.WebForm.Label.ItemQuantity");
                    String strReducedRateHeader = "Rate";//EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.WebForm.Label.WMSReducedSORRate");
                    sb.append("<table>");
                    sb.append("<th>");
                    sb.append(strTitleHeader);
                    sb.append("</th>");
                    sb.append("<th>");
                    sb.append(strQtyHeader);
                    sb.append("</th>");
                    sb.append("<th>");
                    sb.append(strReducedRateHeader);                    
                    sb.append("</th>");
                    sb.append("<tr>");
                    sb.append("<td>");
                    sb.append("<input type=\"text\"  size=\"10\" name=\"WMSTitle\" value=\""+strTitle+"\" id=\"WMSTitle\">");
                    sb.append("</td>");
                    sb.append("<td>");
                    sb.append("<input type=\"text\" readonly=\"true\" size=\"10\" name=\"WMSTotalQunatity\" value=\""+doubleTotalQUantity+"\" id=\"WMSTotalQunatity\">");
                    sb.append("</td>");
                    sb.append("<td>");
                    sb.append("<input type=\"text\" readonly=\"true\" size=\"10\" name=\"WMSReducedRate\" value=\""+strReducedSORRate+"\" id=\"WMSTotalCost\">");
                    sb.append("</td>");
                    sb.append("</tr>");
                    sb.append("<tr>");
                    sb.append("<td>");
                    sb.append("<input type=\"text\"  size=\"10\" name=\"WMSTitle1\" value=\""+strTitle+"\" id=\"WMSTitle1\">");
                    sb.append("</td>");
                    sb.append("<td>");
                    sb.append("<input type=\"text\" size=\"10\" name=\"WMSTotalQunatity1\" value=\"\" onchange= \"validateQuantity(this.value,this)\" id=\"WMSTotalQunatity1\">");
                    sb.append("</td>");
                    sb.append("<td>");
                    sb.append("<input type=\"text\" size=\"10\" name=\"WMSReducedRate1\" value=\"\" onchange= \"validateQuantity(this.value,this)\" id=\"WMSTotalCost1\">");
                    sb.append("</td>");
                    sb.append("</tr>");
                    sb.append("</table>");
                    sb.append("<script>");
                    sb.append("function validateQuantity(varValue,textfield){");
                    sb.append("if(isNaN(varValue))");
                    sb.append("{");
                    sb.append("textfield.value = \"0\";");
                    sb.append("alert(\" Value must be a Real Number.\");");

                    sb.append("return false;");
                    sb.append("}");
                    sb.append("}");
                    sb.append("</script>");
                }
            }
        }
        catch(Exception exception) 
        {
            exception.printStackTrace();
            throw exception;
        }                 
        return sb.toString();
    }
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public  MapList getAllCancelledMyAbstractMBE(Context context, String [] args)    throws Exception {
        MapList mlReturnList     =     new MapList();
        try
        {
            String strVault = context.getVault().getName();
            
            
            StringList strListBusInfo = new StringList(2);
            strListBusInfo.add(DomainConstants.SELECT_ID);
            strListBusInfo.add(DomainConstants.SELECT_CURRENT);
            
            StringList slRelSelect     =    new StringList();
            slRelSelect.add(DomainRelationship.SELECT_ID);
            
            String strWhere     = DomainConstants.EMPTY_STRING;
            String strRelWhere     = DomainConstants.EMPTY_STRING;
            com.matrixone.apps.common.Person contextPerson = com.matrixone.apps.common.Person.getPerson(context);
            
            
            Pattern patternRel  = new Pattern(DomainConstants.RELATIONSHIP_ROUTE_TASK);
            patternRel.addPattern(DomainConstants.RELATIONSHIP_OBJECT_ROUTE);
            patternRel.addPattern(DomainConstants.RELATIONSHIP_PROJECT_TASK);

            Pattern patternType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
            patternType.addPattern(DomainConstants.TYPE_ROUTE);    
            patternType.addPattern(WMSConstants_mxJPO.TYPE_ABSTRACT_MBE);  
            
            strWhere = "("+DomainConstants.SELECT_TYPE+"=='"+DomainConstants.TYPE_INBOX_TASK+"' && current==Assigned )||("+DomainConstants.SELECT_TYPE+"=="+DomainConstants.TYPE_ROUTE+")||("+DomainConstants.SELECT_TYPE+"=="+WMSConstants_mxJPO.TYPE_ABSTRACT_MBE+"&& current==Cancelled)";


            mlReturnList                     = contextPerson.getRelatedObjects(context,
                                                            //patternRel.getPattern(),  // relationship pattern
                                                            patternRel.getPattern(),
                                                            patternType.getPattern(),  // object pattern
                                                            true,                                                        // to direction
                                                            true,                                                       // from direction
                                                            (short)0,                                                      // recursion level
                                                            strListBusInfo,                                                 // object selects
                                                            slRelSelect,                                                         // relationship selects
                                                            strWhere,                                // object where clause
                                                            strRelWhere,                                // relationship where clause
                                                            (short)0,                                                      // No expand limit
                                                            DomainConstants.EMPTY_STRING,                                // postRelPattern
                                                            WMSConstants_mxJPO.TYPE_ABSTRACT_MBE,                                                // postTypePattern
                                                            null);
            
             String strOwnerWhere = DomainConstants.SELECT_OWNER+"=='"+context.getUser()+"' && current==Cancelled";
            MapList mlOwnerMBE                =  DomainObject.findObjects(context,
                                                                        WMSConstants_mxJPO.TYPE_ABSTRACT_MBE,
                                                                        DomainConstants.QUERY_WILDCARD,
                                                                        DomainConstants.QUERY_WILDCARD,
                                                                        DomainConstants.QUERY_WILDCARD,
                                                                        strVault,
                                                                        strOwnerWhere,               // where expression
                                                                        DomainConstants.EMPTY_STRING,
                                                                        false,
                                                                        strListBusInfo, // object selects
                                                                        (short) 0); 
            
            mlReturnList.addAll(mlOwnerMBE);
      insertKeyValue(mlReturnList, DomainConstants.SELECT_LEVEL, "1");
            
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        
        return mlReturnList;
    }
	
	
		/**
     * Check whether column is having Edit Access or not depending on type of object, Checking For type WMSMeasurements
     * @param context The Matrix Context object
     * @param  
     * @param args holds the following input arguments:
     *     1) ObjectList : List of objects in table
     *     2) ProgramMap : Contains all info about table columns        
     * @throws Exception if the operation fails
     */    
    public StringList checkForMeasurementType(Context context,String args[]) throws Exception
    {
        StringList strListAccess = new StringList();;
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();

            while (objectListIterator.hasNext()) {

                Map<String,String> mapData = objectListIterator.next();
                String strType = mapData.get(DomainConstants.SELECT_TYPE);
                if(TYPE_WMS_MEASUREMENTS.equals(strType))
                    strListAccess.add(String.valueOf(true));
                else
                    strListAccess.add(String.valueOf(false));
            }

        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListAccess;

    }
	
	   /**
     * Method to get the Title and Description of Measurements Under the MBE 
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return String containing the message
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public Vector getTitleAndDescription(Context context, String[] args) throws Exception
    {
         try{
             Map programMap                  = (Map)JPO.unpackArgs(args);
             MapList objectList              = (MapList)programMap.get("objectList");
             Iterator iterator               = objectList.iterator();
             Vector returnList               = new Vector();
             Map<String,String> mapData      = null;
             
             String strTitle                 = DomainConstants.EMPTY_STRING;
             String strDescription    = DomainConstants.EMPTY_STRING;
             String strNewTitle = DomainConstants.EMPTY_STRING;
             
             while(iterator.hasNext())
             {
                 mapData     = (Map<String,String>) iterator.next();
                 strTitle = (String) mapData.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
                 strDescription = (String) mapData.get(DomainConstants.SELECT_DESCRIPTION);
                 
                 strNewTitle = strTitle+"  "+strDescription;
                 returnList.add(strNewTitle);
             }
             
             return returnList;
         }catch (Exception exception) {
             exception.printStackTrace();
             throw exception;
        }
         
    }
	
	/**
 * Method will return shape images
 * 
 * @throws Exception
 *             if the operation fails
 * @author WMS
 * @since 418
 */


public Vector getShapeImage(Context context, String[] args) throws Exception
{
	Vector showIcon = new Vector();
	HashMap programMap = (HashMap) JPO.unpackArgs(args);
	MapList objectList = (MapList)programMap.get("objectList");
	int objSize = objectList.size();
	for(int i=0;i<objSize;i++){
		Map objMap = (Map)objectList.get(i);
		String image = (String)objMap.get("attribute["+ATTRIBUTE_WMS_SHAPE_IMAGE+"]");
		String strDim1 = (String)objMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_1+"]");
		String strDim2 = (String)objMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_2+"]");
		String strDim3 = (String)objMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_3+"]");
		String strDim4 = (String)objMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_4+"]");

		if(UIUtil.isNotNullAndNotEmpty(image) && !("No Shape".equals(image)||"Number".equals(image))){	
			String strParam = DomainConstants.EMPTY_STRING;
			if(UIUtil.isNotNullAndNotEmpty(strDim1))
			{
				strParam = strParam+"&dim1="+strDim1;
			}
			if(UIUtil.isNotNullAndNotEmpty(strDim2))
			{
				strParam = strParam+"&dim2="+strDim2;
			}
			if(UIUtil.isNotNullAndNotEmpty(strDim3))
			{
				strParam = strParam+"&dim3="+strDim3;
			}
			if(UIUtil.isNotNullAndNotEmpty(strDim4))
			{
				strParam = strParam+"&dim4="+strDim4;
			}
			String strLink = com.matrixone.apps.domain.util.XSSUtil.encodeForURL("../wms/wmsMeasurementsShapeFS.jsp?svgContent="+image+strParam);
			String strShapeName = image.replaceAll("Shape.svg","");
			image = image.replaceAll(".svg", "_32.svg");
			StringBuilder strUrl = new StringBuilder().append("<a href=\"javascript:showModalDialog('"+strLink+"','50','50','true');\" >");            
			strUrl.append("<img border='0' title='"+strShapeName+"' src='../common/images/"+image+"' />");
			strUrl.append("</a><br></br>"+strShapeName);
			showIcon.add(strUrl.toString());
		}
		else
		{
			if(UIUtil.isNotNullAndNotEmpty(image)){
			showIcon.add(image);
			}
			else
			{
				showIcon.add(DomainConstants.EMPTY_STRING);
			}
		}
	}

	return showIcon;
}

	/**
     * Check whether column is having Edit Access or not depending on type of object, Checking For type WMSMeasurements
     * @param context The Matrix Context object
     * @param  
     * @param args holds the following input arguments:
     *     1) ObjectList : List of objects in table
     *     2) ProgramMap : Contains all info about table columns        
     * @throws Exception if the operation fails
     */    
    public StringList checkForManualColumn(Context context,String args[]) throws Exception
    {
        StringList strListAccess = new StringList();;
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();

            while (objectListIterator.hasNext()) {

                Map<String,String> mapData = objectListIterator.next();
                String strType = mapData.get(DomainConstants.SELECT_TYPE);
                if(TYPE_WMS_MEASUREMENTS.equals(strType))
                {
                    String strManualCalculation = mapData.get("attribute["+ATTRIBUTE_WMS_IS_MANUALQUANTITY+"]");
                    if("Yes".equalsIgnoreCase(strManualCalculation))
                    {
                        strListAccess.add(String.valueOf(false));
                    }
                    else
                    {
                        strListAccess.add(String.valueOf(true));
                    }
                }
                else
                {                    
                    strListAccess.add(String.valueOf(false));
                }
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListAccess;
    }

	/**
 * Method will return Ranges for ShapeName field
 * 
 * @throws Exception
 *             if the operation fails
 * @author WMS
 * @since 418
 */

public Map getShapeNameRange(Context context, String[] args) throws MatrixException{

	String strShapeName = EnoviaResourceBundle.getProperty(context, "wmsStringResource",
			context.getLocale(),"WMS.data.WMSShapeName");
	StringList slShapeNameRange     = new StringList();
	slShapeNameRange = FrameworkUtil.split(strShapeName, ",");
	Map newShapeNameRange = new HashMap();
	newShapeNameRange.put("field_choices", slShapeNameRange);
	newShapeNameRange.put("field_display_choices", slShapeNameRange);
	return newShapeNameRange;

}
	
  /**
     * Method to get the connected MBEs under the Work Order  while copying measurements for an Item in a MBE
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return strListMBEs StringList containing the MBEs IDs
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
     @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getWorkOrderActivities (Context context, String[] args) throws Exception 
    {
    	MapList mlReturnList = new MapList();
        try
        {
            StringList strItemsOIDs         = new StringList();
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
            String strMBEOID                = (String) programMap.get("mbeOID");
            String emxTableRowId            = (String)programMap.get("emxTableRowId");
            Map<String,String> mapSelectedData = ProgramCentralUtil.parseTableRowId(context, emxTableRowId);
            String strItemOID               = mapSelectedData.get("objectId");
            String strRel                   = DomainConstants.EMPTY_STRING;
            if(UIUtil.isNotNullAndNotEmpty(strItemOID))
            {
                DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
                String strSORConnection = domObjItem.getInfo(context, "relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
                if(UIUtil.isNullOrEmpty(strSORConnection))
                {
                    strSORConnection = "false";
                }
                if(UIUtil.isNotNullAndNotEmpty(strMBEOID)&& "true".equalsIgnoreCase(strSORConnection))
                {
                    StringList strListBusSelects     = new StringList(1);
                    strListBusSelects.add(DomainConstants.SELECT_ID);
                    DomainObject domObjMBE= DomainObject.newInstance(context, strMBEOID);
                    if(domObjMBE.isKindOf(context, "WMSMeasurementBookEntry")){
                        strRel= RELATIONSHIP_WMS_WORK_ORDER_MBE;
                    }
                    else if(domObjMBE.isKindOf(context, "WMSAbstractMeasurementBookEntry")){
                        strRel= RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE;
                    }
                    String strWorkOrderOID = domObjMBE.getInfo(context, "relationship_"+strRel+"from.id");

                    if(UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))
                    {
                        DomainObject domObjWO= DomainObject.newInstance(context, strWorkOrderOID);
                        {
                            String strMBOID = getMeasurementBookOID(context,strListBusSelects, strWorkOrderOID);
                            if(UIUtil.isNotNullAndNotEmpty(strMBOID))
                            {
                                strItemsOIDs = getRelatedActivities(context,
                                        strListBusSelects, strMBOID);
                            }
                        }
                    }
                }
            }  
            for (int i = 0; i < strItemsOIDs.size(); i++) {
				HashMap dataMap = new HashMap();
				dataMap.put(DomainConstants.SELECT_ID, strItemsOIDs.get(i));
				mlReturnList.add(dataMap);
			}
            return mlReturnList;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }

    }	
	
	    /** 
     * Method will revise the Running MBE
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */

    public String finalizeRunningMBE(Context context, String[] args) throws Exception 
    {
        try 
        {

            HashMap programMap      = (HashMap) JPO.unpackArgs(args);
            String strRunningMBEOID = (String)programMap.get("objectId");
            if(UIUtil.isNotNullAndNotEmpty(strRunningMBEOID))
            {
                DomainObject domObjRunningMBE = DomainObject.newInstance(context, strRunningMBEOID);
                domObjRunningMBE.setAttributeValue(context, ATTRIBUTE_WMS_MBE_FINALIZED, String.valueOf(true));
                return "Running MBE is sucessfully finalized";
            }
            else
            {
                return "Couldn't process data";
            }

        } catch (Exception exception) {
            exception.printStackTrace();
            return "An error occured while finilazing the MBE";
        }

    }

	
	   /** 
     * Method will revise the Running MBE
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */

    public String reviseRunningMBE(Context context, String[] args) throws Exception 
    {
        try 
        {
            HashMap programMap      = (HashMap) JPO.unpackArgs(args);
            String strRunningMBEOID = (String)programMap.get("objectId");
            if(UIUtil.isNotNullAndNotEmpty(strRunningMBEOID))
            {
                DomainObject domObjRunningMBE = DomainObject.newInstance(context, strRunningMBEOID);
                MapList mapListOldRevisionActivites = getMBEActivities(context, domObjRunningMBE);
                BusinessObject busObjNewMBE =  domObjRunningMBE.reviseObject(context, false);
                DomainObject domNewRevObj = DomainObject.newInstance(context,busObjNewMBE);    
                MapList mapListNewRevisionActivities = getMBEActivities(context, domNewRevObj);
                Iterator<Map<String,String>> iterator = mapListOldRevisionActivites.iterator();

                while(iterator.hasNext())
                {
                    Map<String,String> mapData = iterator.next();
                    String strOldRelOID = mapData.get(DomainRelationship.SELECT_ID);
                    String strItemOID = mapData.get(DomainObject.SELECT_ID);
                    String strMBEQuantity =  mapData.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
                    String strNewRelOID = getNewRevisionRelOID(mapListNewRevisionActivities,strItemOID);
                    if(UIUtil.isNotNullAndNotEmpty(strItemOID) && UIUtil.isNotNullAndNotEmpty(strOldRelOID)&& UIUtil.isNotNullAndNotEmpty(strNewRelOID))
                    {
                        MapList mapListInfo = getConnectedMeasurement(context,strOldRelOID);
                        DomainRelationship.setAttributeValue(context, strNewRelOID, ATTRIBUTE_WMS_QTY_SUBMITTED_TILL_DATE, strMBEQuantity);
                        StringList strListObjOIDs = new StringList();
                        StringList strListObjTotals = new StringList();
                        Iterator<Map<String,Object>> iteratorInfo = mapListInfo.iterator();
                        while(iteratorInfo.hasNext())
                        {
                            Map<String,Object> mapInfo = iteratorInfo.next();
                            Object objectObjOIDs = (Object) mapInfo.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
                            Object objectObjTotals = (Object) mapInfo.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");

                            //check whether the dependency list has one or many ids
                            if (objectObjOIDs instanceof String)
                            {
                                strListObjOIDs.add((String)objectObjOIDs);
                                strListObjTotals.add((String)objectObjTotals);
                            }
                            else if (objectObjOIDs instanceof StringList) 
                            {
                                strListObjOIDs = (StringList) objectObjOIDs;
                                strListObjTotals= (StringList) objectObjTotals;
                            }
                        }
                        Iterator iteratorList = strListObjOIDs.iterator();
                        Iterator iteratorTotalList = strListObjTotals.iterator();
                        while(iteratorList.hasNext())
                        {
                            String strMeasurementOID = (String)iteratorList.next();
                            String strMeasuerementTotal = (String)iteratorTotalList.next();
                            if(UIUtil.isNullOrEmpty(strMeasuerementTotal))
                            {
                                strMeasuerementTotal = "0";
                            }
                            if(UIUtil.isNotNullAndNotEmpty(strMeasurementOID))
                            {
                                String strTypeAlias = FrameworkUtil.getAliasForAdmin(context,
                                        DomainObject.SELECT_TYPE, "WMSMeasurements", true);
                                String strName = FrameworkUtil.autoName(context, strTypeAlias, DomainConstants.EMPTY_STRING,
                                        DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING, true,
                                        false);
                                DomainObject domObj = DomainObject.newInstance(context,strMeasurementOID);
                                AttributeList attl =  domObj.getAttributeValues(context);

                                BusinessObject busObjMeasurement =domObj.cloneObject(context,strName,domObj.getUniqueName(DomainConstants.EMPTY_STRING),null);
                                DomainObject domObjCloneMeasurement     = DomainObject.newInstance(context,busObjMeasurement);
                                domObjCloneMeasurement.setAttributeValues(context, attl);
                                strMeasurementOID = domObjCloneMeasurement.getInfo(context,DomainConstants.SELECT_ID);
                                String strMQLCommand = "add connection '"+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"' torel "+strNewRelOID+" from "+strMeasurementOID +" WMSMBEActivityQuantity "+strMeasuerementTotal;
                                MqlUtil.mqlCommand(context, strMQLCommand);
                            }
                        }
                    }
                }
                return domNewRevObj.getInfo(context,DomainConstants.SELECT_ID);
            }
            else
            {
                return DomainConstants.EMPTY_STRING;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
            return DomainConstants.EMPTY_STRING;
        }
    }
	 private MapList getConnectedMeasurement(Context context, String strOldRelOID)
            throws FrameworkException {
        DomainRelationship domRel = DomainRelationship.newInstance(context,strOldRelOID);
        StringList strListInfoSelects=new StringList(2);
        strListInfoSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
        strListInfoSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");

        DomainObject.MULTI_VALUE_LIST.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
        DomainObject.MULTI_VALUE_LIST.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");
        String[] strEBOMList={strOldRelOID};
        MapList mapListInfo = DomainRelationship.getInfo(context, strEBOMList, strListInfoSelects);
        DomainObject.MULTI_VALUE_LIST.remove("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
        DomainObject.MULTI_VALUE_LIST.remove("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");
        return mapListInfo;
    }
	
	
	private String getNewRevisionRelOID(MapList mapListNewRevisionActivities,
            String strItemOID) {
        Iterator<Map<String,String>> iteratorNew = mapListNewRevisionActivities.iterator();
        while(iteratorNew.hasNext())
        {
            Map<String,String> mapNewData = iteratorNew.next();

            String strNewItemOID = mapNewData.get(DomainObject.SELECT_ID);
            if(strItemOID.equals(strNewItemOID))
            {
                String strNewRelOID = mapNewData.get(DomainRelationship.SELECT_ID);
                return strNewRelOID;
            }
        }
        return DomainConstants.EMPTY_STRING;
    }
	
	public String addMeasurementsWithShape(Context context,String[]args) throws Exception
{

	String strDimensionsName = DomainConstants.EMPTY_STRING;
	StringList slDimensionsName = new StringList();
	String strArea = DomainConstants.EMPTY_STRING;
	try {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);		
		String strShapeName          = (String)programMap.get("shapName");
		String MQLResult           = MqlUtil.mqlCommand(context, "print page $1 select content dump", "WMSShapeMeasurements");
		DocumentBuilder db      = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource is          = new InputSource();
		is.setCharacterStream(new StringReader(MQLResult));
		Document doc    = db.parse(is);
		NodeList nodes  = doc.getElementsByTagName("ShapeName");

		StringList slShapeName= new StringList();
		StringList slteml= new StringList();
		for (int i = 0; i < nodes.getLength(); i++) {
			Element element = (Element) nodes.item(i);
			String strTagShapeName = element.getAttribute("name"); 
			if (strShapeName.equalsIgnoreCase(strTagShapeName)) {
				NodeList dimensions = element.getElementsByTagName("d");			
				for (int j = 0; j < dimensions.getLength(); j++) {

					Element dimensionElement = (Element) dimensions.item(j);
					slDimensionsName.add(dimensionElement.getAttribute("name"));	

				}
			}
		}		

		for(int i=0;i<slDimensionsName.size();i++)
		{			
			strDimensionsName = strDimensionsName+"#"+(String)slDimensionsName.get(i);
		}

	} catch (Exception ex) {
		ex.printStackTrace();
		throw ex ;
	}
	return strDimensionsName+"#"+strArea;
	

}
    /**
     * This program closes the open Task for One on MBE
     * @param context
     * @param args
     * @return
     */
    public Object closeOpenTasks(Context context,String args[]) throws Exception
    {
        HashMap hashMap = (HashMap) JPO.unpackArgs(args);
        try{
            String strObjectId = (String)hashMap.get("objectId");
            String strTaskActionType = (String)hashMap.get("TaskActionType");
            closeOpenTasks(context, strObjectId,strTaskActionType);
        }catch (Exception e) {
            e.printStackTrace();
        }
        return new Object();
    }
	
	    /**
     * This program closes the open tasks on  MBE
     *
     * @param context       the eMatrix Context object.
     * @param strObjectId   MBE Id
     * @return              None
     * @throws Exception    if the operation fails.
     * @author
     */
    public static int closeOpenTasks(Context context, String strObjectId,String strTaskActionType) throws Exception
    {
        int isRoutesClosed = 0;
        try
        {
            
            StringList busSelect      =   new StringList(3);
            busSelect.add(DomainObject.SELECT_ID);
            busSelect.add(DomainObject.SELECT_NAME);
            busSelect.add(DomainObject.SELECT_CURRENT);
            StringList relSelect      =   new StringList(2);
            relSelect.add(DomainRelationship.SELECT_ID);
            relSelect.add(DomainRelationship.SELECT_NAME);
            String strWhere               = "";
            DomainObject doMBE            = DomainObject.newInstance(context,strObjectId);
        
            strWhere                        = "current != "+DomainConstants.STATE_ROUTE_COMPLETE+" && current != Archive";
            MapList mlRoute               = doMBE.getRelatedObjects(context,
                                                                        DomainConstants.RELATIONSHIP_OBJECT_ROUTE,
                                                                        DomainConstants.TYPE_ROUTE,
                                                                        busSelect,
                                                                        relSelect,
                                                                        false,
                                                                        true,
                                                                        (short)1,
                                                                        strWhere,
                                                                        DomainConstants.EMPTY_STRING,
                                                                        0);

            int iRoutesCount          = mlRoute.size();
            Map mpObjectInfo          = null;
            Map mpTaskInfo            = null;
            String strRouteId         = DomainConstants.EMPTY_STRING;
            String strTaskId          = DomainConstants.EMPTY_STRING;
            Route routeObject         = (Route)DomainObject.newInstance(context,DomainConstants.TYPE_ROUTE);
            DomainObject doInboxTask  = DomainObject.newInstance(context);
            MapList mlRouteTasks      = new MapList();
            int iOpenTaskCount        = 0;

          
            strWhere = "current != "+DomainConstants.STATE_INBOX_TASK_COMPLETE +"&& owner=="+context.getUser();
            if(iRoutesCount>0)
            {
                for (int i=0;i< iRoutesCount;i++ )
                {
                    mpObjectInfo = (Map)mlRoute.get(i); //Route Map
                    strRouteId  = (String)mpObjectInfo.get(DomainObject.SELECT_ID); //Route Id
                    routeObject.setId(strRouteId);
                    //routeObject.setAttributeValue(context, DomainObject.ATTRIBUTE_ROUTE_STATUS, "Stopped");

                    //START: Get the opens tasks for this Route and complete them
                    mlRouteTasks = routeObject.getRouteTasks(context, busSelect, DomainConstants.EMPTY_STRINGLIST, strWhere, false);
                   
                    

                    //If there are any open tasks then close them first before closing the route
                    if(!mlRouteTasks.isEmpty())
                    {
                        iOpenTaskCount = mlRouteTasks.size();
                        //There would be only one Task open (Not Complete) at a time
                        for(int j=0; j<iOpenTaskCount; j++)
                        {
                            mpTaskInfo = (Map)mlRouteTasks.get(j);
                            strTaskId  = (String)mpTaskInfo.get(DomainConstants.SELECT_ID);
                            doInboxTask.setId(strTaskId);
                            doInboxTask.setAttributeValue(context, DomainConstants.ATTRIBUTE_COMMENTS, "Approve");
                            doInboxTask.promote(context); //will promote the task to complete
                        }
                    }
                }
            }
        }
         catch(Exception ex)
        {
            ex.printStackTrace();
            isRoutesClosed=1;
        }
         return isRoutesClosed;
    }
     
	/** 
 * Method will set the name of MBE as Title
 * @param context the eMatrix <code>Context</code> object
 * @param args Packed program and request maps for the table
 * @throws Exception if the operation fails
 * @author WMS
 * @since 418
 */
@com.matrixone.apps.framework.ui.PostProcessCallable
public void addMeasurementWithShape(Context context, String[] args) throws Exception {

	try
	{
		DecimalFormat decFor = new DecimalFormat("#.###");
		String strPersonId = PersonUtil.getPersonObjectID(context);
		StringList slPersonSelect = new StringList();
		slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
		slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
		
		DomainObject doPerson = new DomainObject(strPersonId);
		Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
		String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
		String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
		
		if(UIUtil.isNullOrEmpty(strFirstName)){
			strFirstName = DomainConstants.EMPTY_STRING;
		}
		if(UIUtil.isNullOrEmpty(strLastName)){
			strLastName = DomainConstants.EMPTY_STRING;
		}
		
		String strUser = strFirstName + " " +strLastName;
		
		HashMap programMap              = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap               = (HashMap)programMap.get("paramMap");
		HashMap requestMap           = (HashMap)programMap.get("requestMap");
		String strMeasurementOID             = (String) paramMap.get("objectId");
		String emxTableRowId = (String) requestMap.get("emxTableRowId");
		Map<String,String> mapObject = new HashMap<String, String>();
		Calendar calendarDate = Calendar.getInstance();
		String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
		SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
		String strTime = formatter.format(calendarDate.getTime());
		String strHistoryNew = DomainConstants.EMPTY_STRING;
		
		if(UIUtil.isNotNullAndNotEmpty(emxTableRowId))
		{

			StringList slROWID = FrameworkUtil.split(emxTableRowId, "|");
			String strItemOID = (String)slROWID.get(1);
			String strItemMBERelOID = (String)slROWID.get(0);
			if(UIUtil.isNotNullAndNotEmpty(strItemOID)&& UIUtil.isNotNullAndNotEmpty(strItemMBERelOID))
			{
				DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
				StringList strListInfoSelects = new StringList(3);
				strListInfoSelects.add(DomainConstants.SELECT_TYPE);
				strListInfoSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
				strListInfoSelects.add("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
				Map<String,String> mapInfo = domObjItem.getInfo(context, strListInfoSelects);
				String strName = mapInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
				
				int intSequence = getMeasurementSequence(context, strItemMBERelOID);
				String strMQLCommand = "add connection "+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+" torel "+strItemMBERelOID+" from "+strMeasurementOID;
				MqlUtil.mqlCommand(context, strMQLCommand);
				DomainObject domObjMeasurement = DomainObject.newInstance(context, strMeasurementOID);
				//String strMTitle = strName+" - "+intSequence;
				String strMeasutmentRelID = (String)domObjMeasurement.getInfo(context,"from["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].id");
				//domObjMeasurement.setAttributeValue(context,"Title",strMTitle);
				Map attributeMap = new HashMap();
				attributeMap.put(ATTRIBUTE_WMS_IS_SHAPE,"Yes");
				
				//attributeMap.put("Title", strMTitle);
				
				String strShapeName = (String)requestMap.get(ATTRIBUTE_WMS_SHAPE_NAME);
				String strShapeImage = (String)requestMap.get(ATTRIBUTE_WMS_SHAPE_IMAGE);
				String strDim1 = (String)requestMap.get(ATTRIBUTE_WMS_DIMENSION_1);
				String strDim2 = (String)requestMap.get(ATTRIBUTE_WMS_DIMENSION_2);
				String strDim3 = (String)requestMap.get(ATTRIBUTE_WMS_DIMENSION_3);
				String strDim4 = (String)requestMap.get(ATTRIBUTE_WMS_DIMENSION_4);
				
				String strNumber= (String)requestMap.get("WMSNumber");				
				String strUWT = (String)requestMap.get("WMSUWT");
				String strCoff =  (String)requestMap.get("WMSCoeffFact");				
				String strISManual = (String)requestMap.get("WMSISManual");
				String strManualValue = (String)requestMap.get("WMSManualEntry");
				String strDeduction = (String)requestMap.get("WMSISDeduction");
				String strTitle = (String)requestMap.get("Title");
				
				if(UIUtil.isNotNullAndNotEmpty(strNumber))
					strNumber = decFor.format(Double.valueOf(strNumber));
				if(UIUtil.isNotNullAndNotEmpty(strManualValue))
					strManualValue = decFor.format(Double.valueOf(strManualValue));
				if(UIUtil.isNotNullAndNotEmpty(strCoff))
					strCoff = decFor.format(Double.valueOf(strCoff));
				if(UIUtil.isNotNullAndNotEmpty(strDim1))
					strDim1 = decFor.format(Double.valueOf(strDim1));
				if(UIUtil.isNotNullAndNotEmpty(strDim2))
					strDim2 = decFor.format(Double.valueOf(strDim2));
				if(UIUtil.isNotNullAndNotEmpty(strDim3))
					strDim3 = decFor.format(Double.valueOf(strDim3));
				if(UIUtil.isNotNullAndNotEmpty(strDim4))
					strDim4 = decFor.format(Double.valueOf(strDim4));
				
				
				attributeMap.put("Title", strTitle);
				double duwt = 1;
		        if(UIUtil.isNotNullAndNotEmpty(strUWT))
		        {
		        	attributeMap.put("WMSUWD", strUWT);
		        	StringList slSplitUWD = FrameworkUtil.split(strUWT, "-");
		        	if(slSplitUWD.size() > 0)
		        	{
		        		strUWT = slSplitUWD.get(1).toString();
		        		duwt = Double.parseDouble(strUWT);
		        	} 
		        	else
		        	{
		        		duwt = 1;
		        	}
		        }
				
				double dbArea = 1.0;
				double dbQty = 0.0;
				if("No Shape".equals(strShapeName)||"Number".equals(strShapeName)){
					if("No Shape".equals(strShapeName)){
						attributeMap.put(ATTRIBUTE_WMS_IS_MANUALQUANTITY,"yes");
						if(UIUtil.isNotNullAndNotEmpty(strManualValue))
						{						
							dbQty = WMSUtil_mxJPO.convertToDouble(strManualValue);
						}
					}
					else
					{
						attributeMap.put(ATTRIBUTE_WMS_MBE_FREQUENCY, strNumber);
						if(UIUtil.isNotNullAndNotEmpty(strNumber))
						{						
							dbQty = WMSUtil_mxJPO.convertToDouble(strNumber);
						}
					}
				}
				else{
					if(UIUtil.isNotNullAndNotEmpty(strNumber))
					{
						attributeMap.put(ATTRIBUTE_WMS_MBE_FREQUENCY, strNumber);
					}
					else
					{
						strNumber = "1";
					}
					if(UIUtil.isNullOrEmpty(strCoff))
					{
						strCoff = "1";
					}
								
					attributeMap.put(ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR, strCoff);					
					attributeMap.putAll(calculateArea(context, strShapeName, strDim1, strDim2, strDim3,strDim4));
					dbArea = (double)attributeMap.get("Area");
					attributeMap.remove("Area");
					dbQty = dbArea*duwt * WMSUtil_mxJPO.convertToDouble(strCoff)*WMSUtil_mxJPO.convertToDouble(strNumber);
					
				}
				if(UIUtil.isNullOrEmpty(strDeduction)){
					strDeduction = "no";
				}
				if(UIUtil.isNotNullAndNotEmpty(strShapeName) && ("Circle".equalsIgnoreCase(strShapeName) || "Cylinder".equalsIgnoreCase(strShapeName) || "Cone".equalsIgnoreCase(strShapeName) || "Sphere".equalsIgnoreCase(strShapeName) || "Hemisphere".equalsIgnoreCase(strShapeName))){
					strHistoryNew = strUser+"|"+strTime+"|"+strNumber+"|"+strDim1+"|"+strDim3+"|"+strDim4+"|"+strUWT+"|"+strDeduction+"|"+strCoff+"|Within Scope|"+decFor.format(dbQty);
				}else{
					strHistoryNew = strUser+"|"+strTime+"|"+strNumber+"|"+strDim2+"|"+strDim3+"|"+strDim4+"|"+strUWT+"|"+strDeduction+"|"+strCoff+"|Within Scope|"+decFor.format(dbQty);
				}
				
				attributeMap.put(ATTRIBUTE_WMS_MEASUREMENT_HISTORY,strHistoryNew);
				
				if(dbQty > 0.0)
				{
					DomainRelationship domRelMeasurement = new DomainRelationship(strMeasutmentRelID);
					DomainRelationship domRelItem = new DomainRelationship(strItemMBERelOID);
					String strItemQty = (String)domRelItem.getAttributeValue(context, ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY);
					double dbItemQty = Double.parseDouble(strItemQty);
					if("yes".equals(strDeduction)){
						domRelMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY, "-"+String.valueOf(dbQty));
						attributeMap.put(ATTRIBUTE_WMS_IS_DEDUCTION, strDeduction);
					}
					else
					{
						domRelMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY, String.valueOf(dbQty));
						attributeMap.put(ATTRIBUTE_WMS_IS_DEDUCTION, strDeduction);
					}					
				}
				String strCommand = "modify $1 $2 add interface $3";
                if(!"No Shape".equals(strShapeName)&&!"Number".equals(strShapeName))
                {
                	attributeMap.put(ATTRIBUTE_WMS_SHAPE_IMAGE,strShapeName+"Shape.svg");
                	MqlUtil.mqlCommand(context,strCommand, "bus", strMeasurementOID, "WMS"+strShapeName);
                	attributeMap.put(ATTRIBUTE_WMS_SHAPE_NAME,strShapeName);                    
                }
                domObjMeasurement.setAttributeValues(context, attributeMap);
			}
		}		
	} catch (Exception e) {
		e.printStackTrace();
	}
}
 
 /**
     * Method to get the MBE activities
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return mapListConnectedTasks MapList containing the Task IDs
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getRelatedMBE(Context context, String[] args) throws Exception 
    {
        try
        {
            MapList mapListConnectedTasks = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
                DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
				
				StringList busSelect = new StringList();
				busSelect.add(DomainObject.SELECT_ID);
				
				StringList relSelect = new StringList();
				relSelect.add(DomainRelationship.SELECT_ID);
				
				mapListConnectedTasks = domObjMBE.getRelatedObjects(context,
									RELATIONSHIP_WMS_RELATED_MBE,
									TYPE_WMS_MEASUREMENT_BOOK_ENTRY,
									busSelect,
									relSelect,
									false,
									true,
									(short)1,
									DomainConstants.EMPTY_STRING,
									DomainConstants.EMPTY_STRING,
									0);
                
            }
            return mapListConnectedTasks;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

	@com.matrixone.apps.framework.ui.ExcludeOIDProgramCallable
	public StringList excludeMBEs(Context context, String[] args)throws Exception{
		StringList slReturnList = new StringList();
		try{
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			slReturnList.add(strObjectId);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
				DomainObject doObj = new DomainObject(strObjectId);
				String strRelatedMBE = (String)doObj.getInfo(context,"from["+RELATIONSHIP_WMS_RELATED_MBE+"].to.id");
				if(UIUtil.isNotNullAndNotEmpty(strRelatedMBE))
				{
					slReturnList.add(strRelatedMBE);
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return slReturnList;
		
	}
	
	@com.matrixone.apps.framework.ui.IncludeOIDProgramCallable
	public StringList includeMBEs(Context context, String[] args)throws Exception{
		StringList slReturnList = new StringList();
		try{
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
				DomainObject doObj = new DomainObject(strObjectId);
				String strWOId = (String)doObj.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
				if(UIUtil.isNotNullAndNotEmpty(strWOId))
				{
					doObj = new DomainObject(strWOId);
					slReturnList = doObj.getInfoList(context,"from["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].to.id");
				}
			}
			slReturnList.remove(strObjectId);
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return slReturnList;
		
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getMBEActivitiesForParentMBE (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListConnectedTasks = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			String strMBCurrentState = DomainConstants.EMPTY_STRING;
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
				mapListConnectedTasks = getMBEActivities(context, domObjMBE);
				strMBCurrentState = domObjMBE.getInfo(context, DomainConstants.SELECT_CURRENT);
            }
			insertKeyValue(mapListConnectedTasks, "MBCurrent", strMBCurrentState);
				
            return mapListConnectedTasks;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getMBEActivitiesForChildMBE (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListConnectedTasks = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			String strMBCurrentState = DomainConstants.EMPTY_STRING;
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
				String strRelatedMBE = (String)domObjMBE.getInfo(context,"from["+RELATIONSHIP_WMS_RELATED_MBE+"].to.id");
				if(UIUtil.isNotNullAndNotEmpty(strRelatedMBE)){
					domObjMBE= DomainObject.newInstance(context, strRelatedMBE);
					mapListConnectedTasks = getMBEActivities(context, domObjMBE);
					strMBCurrentState = domObjMBE.getInfo(context, DomainConstants.SELECT_CURRENT);
					insertKeyValue(mapListConnectedTasks, "MBCurrent", strMBCurrentState);
				}				
            }
			return mapListConnectedTasks;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

	
	
	public Vector displaySEValidated(Context context, String[] args) throws Exception {
         
         Vector returnVector = new Vector();
         try
         {
             Map programMap        = (Map)JPO.unpackArgs(args);
             Map paramList      = (HashMap) programMap.get("paramList");
             MapList objectList = (MapList)programMap.get("objectList");
             int intSize = objectList.size();
			 
			 String strMBEId = (String)paramList.get("objectId");
			 
			 HashMap requestMap = new HashMap();
			 requestMap.put("objectId", strMBEId);
		     boolean isEditable = isMBEditable(context, JPO.packArgs (requestMap));
			 
			 boolean bHasAccess = false;
			 if(UIUtil.isNotNullAndNotEmpty(strMBEId)){
				 DomainObject doObj = new DomainObject(strMBEId);
				 StringList slSelect = new StringList();
				 slSelect.add(DomainObject.SELECT_CURRENT);
				 slSelect.add(DomainObject.SELECT_TYPE);
				 slSelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
				 slSelect.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				 Map mObjInfo = doObj.getInfo(context,slSelect);
				 String strType = (String)mObjInfo.get(DomainObject.SELECT_TYPE);
				 String strWOId = DomainConstants.EMPTY_STRING;
				 if(TYPE_ABSTRACT_MBE.equals(strType))
					strWOId = (String)mObjInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				 else
					 strWOId = (String)mObjInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
				if(UIUtil.isNotNullAndNotEmpty(strWOId)){
					String strQuery = "print bus "+strWOId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value=='GE'].from.name dump";
					 String strSEusers = MqlUtil.mqlCommand(context,strQuery);
					if(UIUtil.isNotNullAndNotEmpty(strSEusers) && strSEusers.contains(context.getUser()) && isEditable){
						bHasAccess = true;
					}
				 }
			 }
			 
             String strHtml        = new String();
             Map dataMap         = null;
             String strObjectId    = DomainConstants.EMPTY_STRING;
             String strRowId    =    DomainConstants.EMPTY_STRING;
             String strType     = DomainConstants.EMPTY_STRING;
             String strValidated     = DomainConstants.EMPTY_STRING;
			 
             for (int i = 0; i < intSize ; i++) {
				 dataMap            = (Map) objectList.get(i);
				 strObjectId     = (String) dataMap.get("id");
				 strRowId     = (String) dataMap.get("id[level]");
				 strType    =    (String) dataMap.get("type");
				 strValidated    =    (String) dataMap.get("attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"]");
				
				 if(TYPE_WMS_MEASUREMENTS.equals(strType))
                 {
                    if(bHasAccess){
						 if("Yes".equals(strValidated)){
							strHtml="<input type='checkbox' name='SEValidated' value='Yes' checked='true' onchange= \"updateSEValidated('"+strObjectId+"')\"></input>";
						 }else{
							strHtml="<input type='checkbox' name='SEValidated' value='Yes' onchange= \"updateSEValidated('"+strObjectId+"')\"></input>";
						 }
					}else{
						if("Yes".equals(strValidated)){
							strHtml="<input type='checkbox' name='SEValidated' value='Yes' checked='true' disabled='true'></input>";
						}else{
							strHtml="<input type='checkbox' name='SEValidated' value='Yes' disabled='true'></input>";
						}
						 
					} 
                 }
                 else
                 {
                     strHtml=DomainConstants.EMPTY_STRING;
                 }
				returnVector.add(strHtml);
             }
         }
         catch (Exception e) {
             e.printStackTrace();
         }
         
         return returnVector;
     }
	 
	 public Vector displayEEValidated(Context context, String[] args) throws Exception {
         
         Vector returnVector = new Vector();
         try
         {
             Map programMap        = (Map)JPO.unpackArgs(args);
             Map paramList      = (HashMap) programMap.get("paramList");
             MapList objectList = (MapList)programMap.get("objectList");
             int intSize = objectList.size();
			 
			 String strMBEId = (String)paramList.get("objectId");
		     HashMap requestMap = new HashMap();
			 requestMap.put("objectId", strMBEId);
			 boolean isEditable = isMBEditable(context, JPO.packArgs (requestMap));
			 
			 boolean bHasAccess = false;
			 if(UIUtil.isNotNullAndNotEmpty(strMBEId)){
				 DomainObject doObj = new DomainObject(strMBEId);
				 StringList slSelect = new StringList();
				 slSelect.add(DomainObject.SELECT_CURRENT);
				 slSelect.add(DomainObject.SELECT_TYPE);
				 slSelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
				 slSelect.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				 Map mObjInfo = doObj.getInfo(context,slSelect);
				 String strType = (String)mObjInfo.get(DomainObject.SELECT_TYPE);
				 String strWOId = DomainConstants.EMPTY_STRING;
				 if(TYPE_ABSTRACT_MBE.equals(strType))
					strWOId = (String)mObjInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				 else
					 strWOId = (String)mObjInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
				 
				 if(UIUtil.isNotNullAndNotEmpty(strWOId)){
					 String strQuery = "print bus "+strWOId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value=='AGE'].from.name dump";
					 String strEEusers = MqlUtil.mqlCommand(context,strQuery);
					if(UIUtil.isNotNullAndNotEmpty(strEEusers) && strEEusers.contains(context.getUser()) && isEditable){
						bHasAccess = true;
					}
				 }
			 }
             
             String strHtml        = new String();
             Map dataMap         = null;
             String strObjectId    = DomainConstants.EMPTY_STRING;
             String strRowId    =    DomainConstants.EMPTY_STRING;
             String strType     = DomainConstants.EMPTY_STRING;
			 String strValidated     = DomainConstants.EMPTY_STRING;
			
			 
             for (int i = 0; i < intSize ; i++) {
				 dataMap            = (Map) objectList.get(i);
				 strObjectId     = (String) dataMap.get("id");
				 strRowId     = (String) dataMap.get("id[level]");
				 strType    =    (String) dataMap.get("type");
				 strValidated    =    (String) dataMap.get("attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"]");
				
				 if(TYPE_WMS_MEASUREMENTS.equals(strType))
                 {
					if(bHasAccess){
						 if("Yes".equals(strValidated)){
							strHtml="<input type='checkbox' name='EEValidated' value='Yes' checked='true' onchange= \"updateEEValidated('"+strObjectId+"')\"></input>";
						 }else{
							strHtml="<input type='checkbox' name='EEValidated' value='Yes' onchange= \"updateEEValidated('"+strObjectId+"')\"></input>";
						 }
					}else{
						if("Yes".equals(strValidated)){
							strHtml="<input type='checkbox' name='EEValidated' value='Yes' checked='true' disabled='true'></input>";
						}else{
							strHtml="<input type='checkbox' name='EEValidated' value='Yes' disabled='true'></input>";
						}
						 
					}                  
                 }
                 else
                 {
                     strHtml=DomainConstants.EMPTY_STRING;
                 }
					
				returnVector.add(strHtml);
             }
         }
         catch (Exception e) {
             e.printStackTrace();
         }
         
         return returnVector;
     }
	 
	 
	 
	 public String getActiveTask(Context context, String[] args) throws Exception {
	 StringBuilder sbReturn = new StringBuilder();
		try 
		{
			HashMap programMap 			= (HashMap)JPO.unpackArgs(args);
			HashMap hmRequestMap = (HashMap)programMap.get("requestMap");
			String sMeasurementOid 		= (String)hmRequestMap.get("objectId");
			String strContextUser = context.getUser();
			
			if(UIUtil.isNotNullAndNotEmpty(sMeasurementOid))
			{
				DomainObject doMBE = new DomainObject(sMeasurementOid);
				String mqlQuery = "print bus "+sMeasurementOid+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
				String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
				
				if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
					mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name dump";
					String strUser = MqlUtil.mqlCommand(context, mqlQuery);
					mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.id dump";
					String strTaskId = MqlUtil.mqlCommand(context, mqlQuery);
					
					if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
						DomainObject doTask = new DomainObject(strTaskId);
						String strName = (String)doTask.getAttributeValue(context,DomainObject.ATTRIBUTE_TITLE);
						
						if(UIUtil.isNotNullAndNotEmpty(strUser) && strUser.equals(strContextUser)){
							StringBuilder strUrl = new StringBuilder();
							String strLink = "../common/emxTree.jsp?objectId="+strTaskId;
							strUrl.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");     
							strUrl.append(strName);							
							strUrl.append("</a>");							
							/*strLink = "../components/emxTaskCompletePreProcess.jsp?action=Approve&objectId="+strTaskId;
							strUrl.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");     
							strUrl.append("<img style='height:20px;width:20px' src='../common/images/buttonDialogDone.gif'></img>");							
							strUrl.append("</a>");*/
							
							sbReturn.append(strUrl);
						}else{
							sbReturn.append(strName);
						}
					}else{
						sbReturn.append(DomainConstants.EMPTY_STRING);
					}
				}
			}				
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
         
         return sbReturn.toString();
     }
	 
	 public Vector getRelatedMBEIcon(Context context, String[] args)throws Exception{
		Vector returnVector = new Vector();
		try{
			Map programMap        = (Map)JPO.unpackArgs(args);
			Map paramList      = (HashMap) programMap.get("paramList");
			MapList objectList = (MapList)programMap.get("objectList");

			String strRelatedMBEId = DomainConstants.EMPTY_STRING;
			DomainObject doMBE = null;
			Map dataMap         = null;
			String strObjectId    = DomainConstants.EMPTY_STRING;

			for(int i=0;i<objectList.size();i++){
				dataMap            = (Map) objectList.get(i);
				strObjectId     = (String) dataMap.get(DomainObject.SELECT_ID);
				doMBE = new DomainObject(strObjectId);
				strRelatedMBEId = (String)doMBE.getInfo(context,"from["+RELATIONSHIP_WMS_RELATED_MBE+"].to.id");
				if(UIUtil.isNotNullAndNotEmpty(strRelatedMBEId)){
					StringBuilder strUrl = new StringBuilder();
				 
					 strUrl.append("<a  title='Related MBE' href ='javascript:showModalDialog(\"");
				strUrl.append("../common/emxPortal.jsp?portal=WMSRelatedMBEPortal&amp;objectId=");
				strUrl.append(strObjectId);
				strUrl.append("\", \"875\", \"550\", \"false\", \"popup\")'>");
				strUrl.append("<img style='height:20px;width:20px' src='../common/images/iconActionNewWindow.gif'></img>");
				strUrl.append("</a>");
				returnVector.add(strUrl.toString());
					 
				}else{
					returnVector.add(DomainConstants.EMPTY_STRING);
				}				
			}
			 
		 }catch(Exception ex){
			 ex.printStackTrace();
			 throw ex;
		 }
		 
		 return returnVector;
	 }
	 
	
	  public int triggerAutoCreateApprovalRouteForPayment(Context context,String[] args) throws Exception
     {
		 boolean isContextPushed = false;
      try {	  
			ContextUtil.pushContext(context);
			isContextPushed = true;
    	   String strApprovalTemplOid ="";
    	   String strMBEOid = args[0];
    	   String strPurpose=args[1];
    	   String strBasePolicy=args[2];
    	   String strBaseState=args[3];
    	   String strRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
    	   DomainObject domMBE= DomainObject.newInstance(context, strMBEOid);
		   
		   String strOwner = domMBE.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.owner");
    	   
		   strApprovalTemplOid = MqlUtil.mqlCommand(context,"print bus "+strMBEOid+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.from["+RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE+"|attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"].value=='Finance Approval'].to.id dump");
		   	   
    	   Map mRouteAttrib= new HashMap();
    	   Map reviewerInfo= new HashMap();
    	   mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
    	   MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, domMBE, strRelWhere);
    	   if(mlExtRoutes.size()>0) {
    		   WMSUtil_mxJPO.restartExistingRoute(context,mlExtRoutes);
    	   }else {    		     
				if(UIUtil.isNotNullAndNotEmpty(strApprovalTemplOid)){
					Map objectRouteAttributeMap=new HashMap(); 
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strBasePolicy,false ));;
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Approved");
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,strPurpose);
					
					Route.createAndStartRouteFromTemplateAndReviewers(context,
						   strApprovalTemplOid,
							"Bill Approval",
							 strOwner , 
							strMBEOid,
							strBasePolicy,
							strBaseState, 
							mRouteAttrib,
							objectRouteAttributeMap, 
							reviewerInfo,
							true);
				 }
    	   }
    	 
         }catch(Exception e) {
    	  e.printStackTrace();
      } 
	  finally{
		  if(isContextPushed){
			  ContextUtil.popContext(context);
		  }
	  }
	  
      return 0;
     } 

	public void updateMeasurementQuantity(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String strNewValue = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
             doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_MBE_FREQUENCY, strNewValue);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 
	 public void updateMeasurementLength(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String strNewValue = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
			 StringList slSelect = new StringList();
			 slSelect.add("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"].value");
			 slSelect.add("attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value");
			 Map mInfo = doMeasurement.getInfo(context,slSelect);
			 String isShape = (String)mInfo.get("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"].value");
			 String strShapeName = (String)mInfo.get("attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value");
			 if(UIUtil.isNotNullAndNotEmpty(isShape) && "No".equalsIgnoreCase(isShape)){
				doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_MBE_LENGTH, strNewValue);
			 }else{
				 if(UIUtil.isNotNullAndNotEmpty(strShapeName) && ("Circle".equalsIgnoreCase(strShapeName) || "Cylinder".equalsIgnoreCase(strShapeName) || "Cone".equalsIgnoreCase(strShapeName) || "Sphere".equalsIgnoreCase(strShapeName) || "Hemisphere".equalsIgnoreCase(strShapeName))){
					 doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_DIMENSION_1, strNewValue);
				 }else{
					doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_DIMENSION_2, strNewValue);
				 }
			 }
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	  public void updateMeasurementBreadth(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String strNewValue = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
			 String isShape = (String)doMeasurement.getAttributeValue(context,ATTRIBUTE_WMS_IS_SHAPE);
			 if(UIUtil.isNotNullAndNotEmpty(isShape) && "No".equalsIgnoreCase(isShape)){
				doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_MBE_BREADTH, strNewValue);
			 }else{
				 doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_DIMENSION_3, strNewValue);
			 }
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 public void updateMeasurementDeapth(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String strNewValue = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
			 String isShape = (String)doMeasurement.getAttributeValue(context,ATTRIBUTE_WMS_IS_SHAPE);
			 if(UIUtil.isNotNullAndNotEmpty(isShape) && "No".equalsIgnoreCase(isShape)){
				   doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_MBE_DEPTH, strNewValue);
			 }else{
				 doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_DIMENSION_4, strNewValue);
			 }
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 public void updateMeasurementRadius(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String strNewValue = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
			 String isShape = (String)doMeasurement.getAttributeValue(context,ATTRIBUTE_WMS_IS_SHAPE);
			 if(UIUtil.isNotNullAndNotEmpty(isShape) && "No".equalsIgnoreCase(isShape)){
			    doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_MBE_RADIUS, strNewValue);
			 }else{
				doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_DIMENSION_1, strNewValue);
			 }
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 
	  public StringList checkMeasurementEditable(Context context,String args[]) throws Exception
    {
        StringList strListAccess = new StringList();;
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
			HashMap columnMap = (HashMap)programMap.get("columnMap");
			String strColumnName = (String)columnMap.get("name");
			
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();
			boolean bEditable = false;
			String strAttrValue = DomainConstants.EMPTY_STRING;
            while (objectListIterator.hasNext()) {
				strAttrValue = DomainConstants.EMPTY_STRING;
				bEditable = false;
                Map<String,String> mapData = objectListIterator.next();
                String strType = mapData.get(DomainConstants.SELECT_TYPE);
				
                if(TYPE_WMS_MEASUREMENTS.equals(strType))
                {
                    String strIsShape = mapData.get("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"]");
                    String strShapeName = mapData.get("attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"]");
                    if("Yes".equalsIgnoreCase(strIsShape))
                    {
						if("MBELength".equals(strColumnName)){
							if(UIUtil.isNotNullAndNotEmpty(strShapeName) && ("Number".equalsIgnoreCase(strShapeName) || "No Shape".equalsIgnoreCase(strShapeName))){
								strAttrValue = DomainConstants.EMPTY_STRING;
							}else{
								strAttrValue = (String)mapData.get("attribute["+ATTRIBUTE_WMS_DIMENSION_2+"]");
								if(UIUtil.isNullOrEmpty(strAttrValue)){
									strAttrValue = (String)mapData.get("attribute["+ATTRIBUTE_WMS_DIMENSION_1+"]");
								}
							}
						}
						if("MBEBreadth".equals(strColumnName)){
							strAttrValue = (String)mapData.get("attribute["+ATTRIBUTE_WMS_DIMENSION_3+"]");
						}
						if("MBEDepth".equals(strColumnName)){
							strAttrValue = (String)mapData.get("attribute["+ATTRIBUTE_WMS_DIMENSION_4+"]");
						}
						if("MBERadius".equals(strColumnName)){
							strAttrValue = (String)mapData.get("attribute["+ATTRIBUTE_WMS_DIMENSION_1+"]");
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strAttrValue)){
							strListAccess.add(String.valueOf(true));
						}else{
							strListAccess.add(String.valueOf(false));
						}
                    }
                    else
                    {
                        strListAccess.add(String.valueOf(true));
                    }
                }
                else
                {                    
                    strListAccess.add(String.valueOf(false));
                }
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListAccess;
    }
	
	
  public Vector displayCommentForMeasurement(Context context,String args[]) throws Exception
    {
       Vector returnVector = new Vector();
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
			
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();

            while (objectListIterator.hasNext()) {
               returnVector.add(DomainConstants.EMPTY_STRING);
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return returnVector;
    }
	
	public void updateCommentsForMeasurements(Context context,String args[]) throws Exception
    {
       try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String strNewValue = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
			 doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_CONTRACTOR_COMMENT, strNewValue);
         }
         catch (Exception e) {
             throw e;
         }
    }
	
	
	
public int updateMesurementApprovalHistory(Context context,String[] args) throws Exception
	{
	try {	  
		String strPersonId = PersonUtil.getPersonObjectID(context);
		StringList slPersonSelect = new StringList();
		slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
		slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
		
		DomainObject doPerson = new DomainObject(strPersonId);
		Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
		String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
		String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
		
		if(UIUtil.isNullOrEmpty(strFirstName)){
			strFirstName = DomainConstants.EMPTY_STRING;
		}
		if(UIUtil.isNullOrEmpty(strLastName)){
			strLastName = DomainConstants.EMPTY_STRING;
		}
		
		String strContectUser = strFirstName + " " +strLastName;
		
		String strTaskId = args[0];
		Calendar calendarDate = Calendar.getInstance();
		
		String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
		SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
		String strTime = formatter.format(calendarDate.getTime());
		
		String strRouteId = DomainConstants.EMPTY_STRING;
		String strMBEObjectId = DomainConstants.EMPTY_STRING;
		String strMeasurementObjectId = DomainConstants.EMPTY_STRING;
		String strMeasurementComment = DomainConstants.EMPTY_STRING;
		String strMeasurementApprovalHistory = DomainConstants.EMPTY_STRING;
		String strBOQId = DomainConstants.EMPTY_STRING;
		String strRelId = DomainConstants.EMPTY_STRING;
		String strIsModified = DomainConstants.EMPTY_STRING;
		String strIsTitle = DomainConstants.EMPTY_STRING;
		MapList mlMeasurementDetails = new MapList();
		MapList mlMeasurementDetailsForNotification = new MapList();

		if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
			String strMqlQuery = "print bus "+strTaskId+" select from["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|from.type=='"+TYPE_WMS_MEASUREMENT_BOOK_ENTRY+"'].from.id dump";
			strMBEObjectId = MqlUtil.mqlCommand(context,strMqlQuery);
			if(UIUtil.isNotNullAndNotEmpty(strMBEObjectId)){
				DomainObject doMBE = new DomainObject(strMBEObjectId);
				String strState = (String)doMBE.getInfo(context,DomainObject.SELECT_CURRENT);
				HashMap requestMap = new HashMap();
				requestMap.put("objectId", strMBEObjectId);
				MapList mlMBEActivities = getMBEActivities(context,JPO.packArgs(requestMap));
				if(mlMBEActivities != null){
					Map mTemp = null;
					Map mTempMeas = null;
					Map mMeasMap = null;
					Map mMeasMapNotification = null;
					for(int i=0;i<mlMBEActivities.size();i++){
						mTemp = (Map)mlMBEActivities.get(i);
						if(mTemp != null && mTemp.isEmpty()==false){
							strBOQId = (String)mTemp.get(DomainObject.SELECT_ID);
							strRelId = (String)mTemp.get(DomainRelationship.SELECT_ID);
							requestMap = new HashMap();
							requestMap.put("objectId", strBOQId);
							requestMap.put("relId", strRelId);
							MapList mlMeasurementList = getActivityMeasurements(context,JPO.packArgs(requestMap));
							if(mlMeasurementList != null){
								for(int k=0;k<mlMeasurementList.size();k++){
									mTempMeas = (Map)mlMeasurementList.get(k);
									strMeasurementObjectId = (String)mTempMeas.get(DomainObject.SELECT_ID);
									strMeasurementComment = (String)mTempMeas.get("attribute["+ATTRIBUTE_WMS_CONTRACTOR_COMMENT+"]");
									strMeasurementApprovalHistory = (String)mTempMeas.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY+"]");
									strIsModified = (String)mTempMeas.get("attribute["+ATTRIBUTE_WMS_IS_MODIFIED+"]");
									strIsTitle = (String)mTempMeas.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");

									if(UIUtil.isNotNullAndNotEmpty(strMeasurementComment) && "Review".equals(strState)){
										mMeasMap = new HashMap();
										mMeasMap.put("id",strMeasurementObjectId);
										mMeasMap.put("comment",strMeasurementComment);
										mMeasMap.put("history",strMeasurementApprovalHistory);
										mlMeasurementDetails.add(mMeasMap);
									}
									
									if(UIUtil.isNotNullAndNotEmpty(strIsModified) && "Yes".equalsIgnoreCase(strIsModified)){
										mMeasMapNotification = new HashMap();
										mMeasMapNotification.put(DomainObject.SELECT_ID,strMeasurementObjectId);
										mMeasMapNotification.put(DomainObject.ATTRIBUTE_TITLE,strIsTitle);
										mlMeasurementDetailsForNotification.add(mMeasMapNotification);
									}
								}								
							}							
						}						
					}					
				}				
			}			
		}
		
		strMeasurementObjectId = DomainConstants.EMPTY_STRING;
		strMeasurementComment = DomainConstants.EMPTY_STRING;
		strMeasurementApprovalHistory = DomainConstants.EMPTY_STRING;
		String strMeasurementApprovalHistoryOld = DomainConstants.EMPTY_STRING;
		String strMeasurementApprovalHistoryLastEntry = DomainConstants.EMPTY_STRING;
		StringList slHistoryEntryList = new StringList();
		
		DomainObject doMeasurement = null;
		Map mTempMeasMap = null;
		for(int j=0;j<mlMeasurementDetails.size();j++){
			mTempMeasMap = (HashMap)mlMeasurementDetails.get(j);
			strMeasurementObjectId = (String)mTempMeasMap.get("id");
			strMeasurementComment = (String)mTempMeasMap.get("comment");
			strMeasurementApprovalHistoryOld = (String)mTempMeasMap.get("history");
			strMeasurementApprovalHistory = strContectUser +"|"+strTime+"|"+strMeasurementComment;
			slHistoryEntryList = FrameworkUtil.split(strMeasurementApprovalHistoryOld, "\n");
			if(slHistoryEntryList.size()==0){
				strMeasurementApprovalHistoryOld = strMeasurementApprovalHistory;
			}else if(slHistoryEntryList.size()>0){
				strMeasurementApprovalHistoryLastEntry = (String)slHistoryEntryList.get(slHistoryEntryList.size()-1);
				if(strMeasurementApprovalHistoryLastEntry.endsWith(strMeasurementComment) == false){
					strMeasurementApprovalHistoryOld = strMeasurementApprovalHistoryOld +"\n"+strMeasurementApprovalHistory;
				}
			}
			if(UIUtil.isNotNullAndNotEmpty(strMeasurementObjectId)){
				doMeasurement = new DomainObject(strMeasurementObjectId);
				doMeasurement.setAttributeValue(context,ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY,strMeasurementApprovalHistoryOld);
				doMeasurement.setAttributeValue(context,ATTRIBUTE_WMS_CONTRACTOR_COMMENT,DomainConstants.EMPTY_STRING);
			}
		}
		
		if(mlMeasurementDetailsForNotification.size()>0){
			String strSubject = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Subject.MBEModified");
			String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.MBEModified");
			sendEmailNotificationsToMembers(context,strMBEObjectId,mlMeasurementDetailsForNotification,strSubject,strMessage);
		}
		
	}catch(Exception e){
		e.printStackTrace();
	} 
	return 0;
} 
	
	public void sendEmailNotificationsToMembers(Context context, String strObjectId,MapList mlObjectList, String strSubject,String strMessage)throws Exception{
		try{
			
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				DomainObject doMBE = new DomainObject(strObjectId);
				String strType = doMBE.getInfo(context,DomainObject.SELECT_TYPE);
				StringList slMemberList = new StringList();
				if(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY.equals(strType)){
					slMemberList = doMBE.getInfoList(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"].from.name");
				}else if(TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType)){
					slMemberList = doMBE.getInfoList(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"].from.name");		
				}				
				
				String strPersonId = PersonUtil.getPersonObjectID(context);
				StringList slSelect = new StringList();
				slSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
				slSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
				
				DomainObject doPerson = new DomainObject(strPersonId);
				Map mPersonInfo = doPerson.getInfo(context,slSelect);
				String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
				String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
				
				if(UIUtil.isNullOrEmpty(strFirstName)){
					strFirstName = DomainConstants.EMPTY_STRING;
				}
				if(UIUtil.isNullOrEmpty(strLastName)){
					strLastName = DomainConstants.EMPTY_STRING;
				}
			
				StringBuffer sbMessage = new StringBuffer();
				sbMessage.append("Following items have been modified by "+strFirstName+" "+strLastName+"");
			
			
				StringList objectIdLists = new StringList();
				objectIdLists.add(strObjectId);
				
				StringBuffer sbHTMLBody = new StringBuffer();
				sbHTMLBody.append("<html>");
				sbHTMLBody.append(
						"<head><style>.datagrid table { border-collapse: collapse; text-align: left; width: 100%; } .datagrid {font: normal 12px/150% Arial, Helvetica, sans-serif; background: #fff; overflow: hidden;}.datagrid table td, .datagrid table th { padding: 3px 10px; }.datagrid table thead th {background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #006699), color-stop(1, #00557F) );background:-moz-linear-gradient( center top, #006699 5%, #00557F 100% );filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#006699', endColorstr='#00557F');background-color:#006699; color:#FFFFFF; font-size: 13px; font-weight: bold; border-left: 1px solid #0070A8; } .datagrid table thead th:first-child { border: none; }.datagrid table tbody td { color: #00557F; border-left: 1px solid #E1EEF4;font-size: 12px;font-weight: normal; }.datagrid table tbody .alt td { background: #E1EEf4; color: #00557F; }.datagrid table tbody td:first-child { border-left: none; }.datagrid table tbody tr:last-child td { border-bottom: none; }</style></head>");
				sbHTMLBody.append("<body>");
				sbHTMLBody.append("<div class='datagrid'>");
				sbHTMLBody.append("<b>Dear User , <b> <br><br>");
				sbHTMLBody.append("<BR>");
				sbHTMLBody.append(strMessage);
				sbHTMLBody.append("<BR>");
				sbHTMLBody.append("<BR>");
				sbHTMLBody.append("<center>");
				
				if(mlObjectList.size()>0){
					sbHTMLBody.append("<table width='100%' border='1'>");
					sbHTMLBody.append("<thead>");
					sbHTMLBody.append(
							"<tr align='center'><th width='5%'><b>S.No</b></th><th width='10%'><b>Measurement Title</b></th><th width='15%'><b>History</b></th></tr>");
					sbHTMLBody.append("</thead>");
					sbHTMLBody.append("<tbody>");
			
				
					Map mapMeas = null;
					
					String strURL="../wms/wmsMeasurementHistory.jsp"; 
					for (int iCount = 0; iCount < mlObjectList.size();) {
						
						mapMeas = (Map) mlObjectList.get(iCount);
						iCount++;
						String sMeasId = (String) mapMeas.get(DomainObject.SELECT_ID);
						String sMeasTitle = (String) mapMeas.get(DomainObject.ATTRIBUTE_TITLE);

						StringBuffer sb = new StringBuffer();
						sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+sMeasId+"','600','400','false');\" >");
						sb.append("<img border='0' title='History' src='../common/images/iconNewWindow.gif' height='15px' name='History' id='History' alt='History' />");
						sb.append("</a>");
						
						
						sbHTMLBody.append("<tr><th width='5%'>" + iCount + "</th><th width='10%'>" + sMeasTitle
								+ "</th><th width='15%'>" + sb.toString() + "</th></tr>");
						// For Icon Mail
						//objectIdLists.add(sMeasId);
						sbMessage.append("\n");
						sbMessage.append(iCount + ". ");
						sbMessage.append(sMeasTitle);
						sbMessage.append("\n");
					}
					sbHTMLBody.append("</tbody>");
					sbHTMLBody.append("</table>");
					sbHTMLBody.append("</table>");
				
				}
				sbHTMLBody.append("<BR>");
				sbHTMLBody.append("<b>Thank you<b><br>");
				sbHTMLBody.append(strFirstName+" "+strLastName);
				sbHTMLBody.append("<BR>");
				sbHTMLBody.append("<BR>");
				
				sbHTMLBody.append("</body>");
				sbHTMLBody.append("</html>");
			
				String fromAgent = context.getUser();
				String notifyType = "both";
				emxNotificationUtil_mxJPO.sendJavaMail(context, slMemberList, null, null,
						strSubject+" : "+(String)doMBE.getInfo(context,DomainObject.SELECT_NAME), sbMessage.toString(), sbHTMLBody.toString(), fromAgent, null, objectIdLists,
						notifyType);
				
			}
		}catch(Exception ex){
				ex.printStackTrace();
				throw ex;
		}		
	}	
	
	
	
	
 @com.matrixone.apps.framework.ui.PostProcessCallable
    public Map sendNotificationsOnUpdate(Context context, String[] args) throws Exception {
        HashMap mapReturnMap = new HashMap();
		boolean isModified = false;
        try {
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
            HashMap hmTableData 			= (HashMap) programMap.get("tableData");
            HashMap hmRequestMap 			= (HashMap) programMap.get("requestMap");
			String strObjectid = (String)hmRequestMap.get("objectId");
			String strCurrentState = DomainConstants.EMPTY_STRING;
			
			String strSubject = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Subject.AMBEModified");
			String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.AMBEModified");
			MapList mlMeasList = new MapList();
			
			//sendEmailNotificationsToMembers(context,strObjectid,mlMeasList,strSubject,strMessage);

            mapReturnMap.put("Action","success");
        } catch (Exception exception) {
         exception.printStackTrace();
            mapReturnMap.put("Action","Stop");
            mapReturnMap.put("Message",exception.getMessage());
        }
        return mapReturnMap;
    }
	
	
	
	public Vector getBlankComments(Context context, String[] args) throws Exception {
         
         Vector returnVector = new Vector();
         try
         {
             Map programMap        = (Map)JPO.unpackArgs(args);
             Map paramList      = (HashMap) programMap.get("paramList");
             MapList objectList = (MapList)programMap.get("objectList");
             int intSize = objectList.size();
			 boolean isActiveTaskAvaialble = isCommentsEditable(context,args);
			 Map dataMap = null;
			 String strComments = DomainConstants.EMPTY_STRING;
             for (int i = 0; i < intSize ; i++) {
				dataMap            = (Map) objectList.get(i);
				strComments = (String)dataMap.get("attribute["+ATTRIBUTE_WMS_CONTRACTOR_COMMENT+"]");
				//if(isActiveTaskAvaialble){
					returnVector.add(strComments);
				/*}else{				 
					returnVector.add(DomainConstants.EMPTY_STRING);
				}*/
				returnVector.add(DomainConstants.EMPTY_STRING);
             }
         }
         catch (Exception e) {
             e.printStackTrace();
         }
         
         return returnVector;
     }
	 
	 
	 public void updateContractorComments(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String strNewValue = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
			 String strIsCommented = (String)doMeasurement.getAttributeValue(context,ATTRIBUTE_WMS_IS_COMMENTED);
             doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_CONTRACTOR_COMMENT, strNewValue);
			 
			 if(UIUtil.isNotNullAndNotEmpty(strNewValue) && "No".equalsIgnoreCase(strIsCommented)){
				 doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_IS_COMMENTED, "Yes");
			 }
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 public Boolean isCommentsEditable (Context context, String[] args) throws Exception 
	{
		Boolean bReturn = false ;
		try 
		{
			HashMap programMap 			= (HashMap)JPO.unpackArgs(args);
			String sMeasurementOid 		= (String)programMap.get("objectId");
			String strContextUser = context.getUser();
			if(UIUtil.isNotNullAndNotEmpty(sMeasurementOid))
			{
				DomainObject doMBE = new DomainObject(sMeasurementOid);
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_OWNER);
				slSelect.add(DomainObject.SELECT_CURRENT);
				Map mObjInfo = doMBE.getInfo(context,slSelect);
				
				String strOwner = (String)mObjInfo.get(DomainObject.SELECT_OWNER);
				String strState = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);
				if(UIUtil.isNotNullAndNotEmpty(strState) && "Review".equals(strState)){
					String mqlQuery = "print bus "+sMeasurementOid+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
					String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
					if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
						mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name dump";
						String strUser = MqlUtil.mqlCommand(context, mqlQuery);
						if(UIUtil.isNotNullAndNotEmpty(strUser) && strUser.equals(strContextUser)){
							bReturn = true;
						}
					}
				}		
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return bReturn;
	}
	
	
	public StringList getDimension1(Context context, String[] args)throws Exception{
		 StringList returnVector = new StringList();
         try
         {
			 DecimalFormat decFor = new DecimalFormat("#.###");
             Map programMap        = (Map)JPO.unpackArgs(args);
             Map paramList      = (HashMap) programMap.get("paramList");
             MapList objectList = (MapList)programMap.get("objectList");
             int intSize = objectList.size();
			 String strIsShape = DomainConstants.EMPTY_STRING;
			 String strShapeName = DomainConstants.EMPTY_STRING;
			 String strType = DomainConstants.EMPTY_STRING;
			 Map dataMap = null;
			 
			 String strHtml        = DomainConstants.EMPTY_STRING;
			 for (int i = 0; i < intSize ; i++) {
				 dataMap            = (Map) objectList.get(i);
				 strType    =    (String) dataMap.get("type");
				 strIsShape    =    (String) dataMap.get("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"]");
				 strShapeName    =    (String) dataMap.get("attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"]");
				 strHtml        = DomainConstants.EMPTY_STRING;
				 if(TYPE_WMS_MEASUREMENTS.equals(strType))
                 {
                    if(UIUtil.isNotNullAndNotEmpty(strIsShape) && "Yes".equalsIgnoreCase(strIsShape)){
						if(UIUtil.isNotNullAndNotEmpty(strShapeName) && ("Number".equalsIgnoreCase(strShapeName) || "No Shape".equalsIgnoreCase(strShapeName))){
							 strHtml=DomainConstants.EMPTY_STRING;
						}else{
							strHtml = (String) dataMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_2+"]");
							if(UIUtil.isNullOrEmpty(strHtml)){
								strHtml = (String) dataMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_1+"]");
							}
							if(UIUtil.isNotNullAndNotEmpty(strHtml)){
								double dDimension1 = Double.valueOf(strHtml);
								strHtml = decFor.format(dDimension1);
							}
							
						}						
					}else{
						 strHtml = (String) dataMap.get("attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"]");
						 if(UIUtil.isNotNullAndNotEmpty(strHtml)){
							double dDimension1 = Double.valueOf(strHtml);
							strHtml = decFor.format(dDimension1);
						}
					} 
					
					
					if(UIUtil.isNullOrEmpty(strHtml)){
						strHtml = DomainConstants.EMPTY_STRING;
					}
						
                 }
                 else
                 {
                     strHtml=DomainConstants.EMPTY_STRING;
                 }
				returnVector.add(strHtml);
             }
         }
         catch (Exception e) {
             e.printStackTrace();
         }
         
         return returnVector;
	}
	
	
	public String getApprovalTemplateForMB(Context context, String[] args)throws Exception{
		String strReturnValue = DomainConstants.EMPTY_STRING;
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strMBId = (String) paramMap.get("objectId");
		if(UIUtil.isNotNullAndNotEmpty(strMBId)){
			DomainObject doMB = new DomainObject(strMBId);
			ContextUtil.pushContext(context);
			strReturnValue = (String)doMB.getInfo(context,"from["+RELATIONSHIP_WMS_MBE_APPROVAL_TEMPLATE+"].to.name");
			ContextUtil.popContext(context);
			if(UIUtil.isNullOrEmpty(strReturnValue)){
				strReturnValue = DomainConstants.EMPTY_STRING;
			}
		}
		return strReturnValue;
	}
	
	public String getFormalApprovalTemplateForMB(Context context, String[] args)throws Exception{
		String strReturnValue = DomainConstants.EMPTY_STRING;
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strMBId = (String) paramMap.get("objectId");
		if(UIUtil.isNotNullAndNotEmpty(strMBId)){
			DomainObject doMB = new DomainObject(strMBId);
			ContextUtil.pushContext(context);
			strReturnValue = (String)doMB.getInfo(context,"from["+RELATIONSHIP_WMS_MBE_FORMAL_APPROVAL_TEMPLATE+"].to.name");
			ContextUtil.popContext(context);
			if(UIUtil.isNullOrEmpty(strReturnValue)){
				strReturnValue = DomainConstants.EMPTY_STRING;
			}
		}
		return strReturnValue;
	}
	
	
	
	public String getApprovalTemplateForAMB(Context context, String[] args)throws Exception{
		String strReturnValue = DomainConstants.EMPTY_STRING;
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strMBId = (String) paramMap.get("objectId");
		if(UIUtil.isNotNullAndNotEmpty(strMBId)){
			DomainObject doMB = new DomainObject(strMBId);
			ContextUtil.pushContext(context);
			strReturnValue = (String)doMB.getInfo(context,"from["+RELATIONSHIP_WMS_AMBE_APPROVAL_TEMPLATE+"].to.name");
			ContextUtil.popContext(context);
			if(UIUtil.isNullOrEmpty(strReturnValue)){
				strReturnValue = DomainConstants.EMPTY_STRING;
			}
		}
		return strReturnValue;
	}



public Vector getCurrentState(Context context, String[] args) throws Exception {
         
         Vector returnVector = new Vector();
         try
         {
             Map programMap        = (Map)JPO.unpackArgs(args);
             Map paramList      = (HashMap) programMap.get("paramList");
             MapList objectList = (MapList)programMap.get("objectList");
             int intSize = objectList.size();
			 
             String strHtml        = new String();
             Map dataMap         = null;

             String strType     = DomainConstants.EMPTY_STRING;		
			 
             for (int i = 0; i < intSize ; i++) {
				 dataMap            = (Map) objectList.get(i);
				 strType    =    (String) dataMap.get("type");
				 if(TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType))
                 {
					 strHtml = (String)dataMap.get(DomainObject.SELECT_CURRENT);
                 }
                 else
                 {
                     strHtml=DomainConstants.EMPTY_STRING;
                 }
					
				returnVector.add(strHtml);
             }
         }
         catch (Exception e) {
             e.printStackTrace();
         }
         
         return returnVector;
     }

	   public  MapList getValidatedColumns(Context context, String[] args) throws Exception {
	
	try {
		Map programMap        = (Map)JPO.unpackArgs(args);
		Map requestMap 		  = (Map)programMap.get("requestMap");
		String strObjectId = (String)requestMap.get("objectId");
		DomainObject doMB = new DomainObject(strObjectId);
		String strType = (String)doMB.getInfo(context,DomainObject.SELECT_TYPE);
		String strRelName = DomainConstants.EMPTY_STRING;
		if(TYPE_ABSTRACT_MBE.equals(strType)){
			strRelName = RELATIONSHIP_WORKORDER_ABSTRACT_MBE;
		}else{
			strRelName = RELATIONSHIP_WMS_WORK_ORDER_MBE;
		}
		
		StringList slMemberRoleList = (StringList)doMB.getInfoList(context,"to["+strRelName+"].from.to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"].attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value");
		
		MapList returnList = new MapList();
		String strValidateColumns = EnoviaResourceBundle.getProperty(context, "WMS.Measurement.Validate.RoleAndPercentage");
		String strMappingDate = MqlUtil.mqlCommand(context, "print page WMSValidateMeasurements select content dump");
		StringList slMappingDataList = FrameworkUtil.split(strMappingDate,"\n");
			
		if(UIUtil.isNotNullAndNotEmpty(strValidateColumns)){
			StringList slRolesList = FrameworkUtil.split(strValidateColumns,"|");
			
				
			for(int i=0;i<slRolesList.size();i++){
				String strRoleData = (String)slRolesList.get(i);
				StringList slRoleData = FrameworkUtil.split(strRoleData,"~");
				String strRole = (String)slRoleData.get(0);
				if(slMemberRoleList.contains(strRole)){
					Map settingNewFeature = new HashMap();
					settingNewFeature.put("Registered Suite", "WMS");
					settingNewFeature.put("Width", "25");
					settingNewFeature.put("Group Header","WMS.Group.Validated");
					settingNewFeature.put("Auto Filter","false");
					settingNewFeature.put("Column Type", "programHTMLOutput");
					settingNewFeature.put("program", "WMSMeasurementBookEntry");

					String strFunctionLabel = DomainConstants.EMPTY_STRING;
					for(int k=0;k<slMappingDataList.size();k++){
						strFunctionLabel = (String)slMappingDataList.get(k);
						StringList slColumnRole = FrameworkUtil.split(strFunctionLabel,"|");
						String strColumnRole = (String)slColumnRole.get(0);
						if(UIUtil.isNotNullAndNotEmpty(strColumnRole) && strColumnRole.equals(strRole))
							break;
					}	
				
					if(UIUtil.isNotNullAndNotEmpty(strFunctionLabel)){
						StringList slColumnDetailList = FrameworkUtil.split(strFunctionLabel,"|");
						settingNewFeature.put("function", (String)slColumnDetailList.get(1));
						Map columnNewFeature = new HashMap();
						columnNewFeature.put("settings", settingNewFeature);
						columnNewFeature.put("label",(String)slColumnDetailList.get(2));
						columnNewFeature.put("name", strRole);
						returnList.add(columnNewFeature);
					}
				}
			}
		}
		
		return returnList;
	}catch(Exception exp) {
		exp.printStackTrace();
		throw exp;
	}
	finally {

	}
	}
	 
	 
	public String checkForPercentageValidation(Context context,String[] args) throws Exception
	{
	try {	  
		String strContectUser =  context.getUser();
		String strTaskId = args[0];
		Calendar calendarDate = Calendar.getInstance();
		
		String strMBEObjectId = DomainConstants.EMPTY_STRING;
		String strMeasurementObjectId = DomainConstants.EMPTY_STRING;
		String strEEValidated = DomainConstants.EMPTY_STRING;
		String strSEValidated = DomainConstants.EMPTY_STRING;
		String strActivityQty = DomainConstants.EMPTY_STRING;
		String strBOQId = DomainConstants.EMPTY_STRING;
		String strRelId = DomainConstants.EMPTY_STRING;
		
		double dSORRate = 0.0f;
		double dMBEQty = 0.0f;
		double dTotalQty = 0.0f;
		double dTotalSORQty = 0.0f;
		double dValidatedValue = 0.0f;
		double dValidatedQty = 0.0f;
		double dTotalValue = 0.0f;
		double dTotalSORValue = 0.0f;
		double dTotalValidatedValue = 0.0f;
		double dTotalValidatedQty = 0.0f;
		
		double dValidatedPercentage = 0.0f;
		double dValidationRequiredPercentage = 0.0f;
		double dValidatedValuePercentage = 0.0f;
		
		if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
			String strMqlQuery = "print bus "+strTaskId+" select from["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|from.type=='"+TYPE_WMS_MEASUREMENT_BOOK_ENTRY+"'].from.id dump";
			strMBEObjectId = MqlUtil.mqlCommand(context,strMqlQuery);

			if(UIUtil.isNotNullAndNotEmpty(strMBEObjectId)){
				strMqlQuery = "print bus "+strMBEObjectId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+context.getUser()+"'].attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value dump";
				
				String strWorkOrderRole = MqlUtil.mqlCommand(context,strMqlQuery);
				
				String strTypeOfContract = MqlUtil.mqlCommand(context,"print bus "+strMBEObjectId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value dump");

				if(UIUtil.isNotNullAndNotEmpty(strWorkOrderRole) && ("AGE".equals(strWorkOrderRole) || "GE".equals(strWorkOrderRole))){
	
				HashMap requestMap = new HashMap();
				requestMap.put("objectId", strMBEObjectId);
				MapList mlMBEActivities = getMBEActivities(context,JPO.packArgs(requestMap));
				if(mlMBEActivities != null){
					Map mTemp = null;
					Map mTempMeas = null;
					Map mMeasMap = null;
					Map mMeasMapNotification = null;
					
					for(int i=0;i<mlMBEActivities.size();i++){
						dSORRate = 0.0f;
						dTotalSORQty = 0.0f;
						dValidatedValue = 0.0f;
						dValidatedQty = 0.0f;
						dTotalSORValue = 0.0f;					
						
						mTemp = (Map)mlMBEActivities.get(i);
						if(mTemp != null && mTemp.isEmpty()==false){
							String strSORRate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
							String strTotalActivityQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
							dSORRate = Double.valueOf(strSORRate);	
							
							strBOQId = (String)mTemp.get(DomainObject.SELECT_ID);
							strRelId = (String)mTemp.get(DomainRelationship.SELECT_ID);
							requestMap = new HashMap();
							requestMap.put("objectId", strBOQId);
							requestMap.put("relId", strRelId);
							MapList mlMeasurementList = getActivityMeasurements(context,JPO.packArgs(requestMap));
							if(mlMeasurementList != null){
								for(int k=0;k<mlMeasurementList.size();k++){
									dValidatedQty = 0.0f;
									dValidatedValue = 0.0f;
									mTempMeas = (Map)mlMeasurementList.get(k);
									strSEValidated = (String)(String)mTempMeas.get("attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"]");
									strEEValidated = (String)(String)mTempMeas.get("attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"]");
									strActivityQty = (String)(String)mTempMeas.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
									dTotalSORQty =  dTotalSORQty + Math.abs(Double.valueOf(strActivityQty));
									if("AGE".equals(strWorkOrderRole) && "Yes".equalsIgnoreCase(strEEValidated)){
										dValidatedQty = Double.valueOf(strActivityQty);
										dValidatedValue = Math.abs(dValidatedQty) * dSORRate;
									}else if("GE".equals(strWorkOrderRole) && "Yes".equalsIgnoreCase(strSEValidated)){
										dValidatedQty = Double.valueOf(strActivityQty);
										dValidatedValue =  Math.abs(dValidatedQty) * dSORRate;
									}
									
									dTotalValidatedQty = dTotalValidatedQty + Math.abs(dValidatedQty);
									dTotalValidatedValue = dTotalValidatedValue + dValidatedValue;
								}								
							}
							dTotalSORValue = dSORRate * dTotalSORQty;
							dTotalQty = dTotalQty + dTotalSORQty;
							dTotalValue = dTotalValue + dTotalSORValue;
							
						}						
					}
					
					if("EPC".equalsIgnoreCase(strTypeOfContract)){
						return DomainConstants.EMPTY_STRING;
						/*if(dTotalQty != 0)
							dValidatedPercentage = (dTotalValidatedQty / dTotalQty)*100;*/
					}else{
						if(dTotalValue != 0)
							dValidatedValuePercentage = (dTotalValidatedValue / dTotalValue)*100;
					}
				}	
				
				String strValidateColumns = EnoviaResourceBundle.getProperty(context, "WMS.Measurement.Validate.RoleAndPercentage");
				if(UIUtil.isNotNullAndNotEmpty(strValidateColumns)){
					StringList slRolesList = FrameworkUtil.split(strValidateColumns,"|");
					for(int i=0;i<slRolesList.size();i++){
						String strRoleData = (String)slRolesList.get(i);
						StringList slRoleData = FrameworkUtil.split(strRoleData,"~");
						String strRole = (String)slRoleData.get(0);
						String strWeightage = (String)slRoleData.get(1);
						if(strRole.equals(strWorkOrderRole)){
							DecimalFormat decFor = new DecimalFormat("#.##");
							if("EPC".equalsIgnoreCase(strTypeOfContract)){
								if(dValidatedPercentage < Double.valueOf(strWeightage)){
									String strValidatedPercentage = decFor.format(dValidatedPercentage);
									String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Messsage.ValidateMeasurementsQty");
									String strMessageValidated = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Messsage.ValidationComplete");
									return strWeightage + "% "+strMessage+" "+strRole+". "+strMessageValidated+" "+strValidatedPercentage+"%";
								}
							}else{
								if(dValidatedValuePercentage < Double.valueOf(strWeightage)){
									String strValidatedValuePercentage = decFor.format(dValidatedValuePercentage);
									String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Messsage.ValidateMeasurementsValue");
									String strMessageValidated = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Messsage.ValidationComplete");
									return strWeightage + "% "+strMessage+" "+strRole+". "+strMessageValidated+" "+strValidatedValuePercentage+"%";
								}
							}
						}
					}
				}
				
			}				
		}			
	}
		
	}catch(Exception e){
		e.printStackTrace();
	} 
	return DomainConstants.EMPTY_STRING;
} 


public String checkValidatedMeasurements(Context context,String[] args) throws Exception
	{
	try {	  
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strMBEObjectId = (String)programMap.get("objectId");
		String strEEValidated = DomainConstants.EMPTY_STRING;
		String strSEValidated = DomainConstants.EMPTY_STRING;
		String strActivityQty = DomainConstants.EMPTY_STRING;
		String strBOQId = DomainConstants.EMPTY_STRING;
		String strRelId = DomainConstants.EMPTY_STRING;
		
		double dSORRate = 0.0f;
		double dMBEQty = 0.0f;
		double dTotalQty = 0.0f;
		double dTotalSORQty = 0.0f;
		double dValidatedValue = 0.0f;
		double dValidatedQty = 0.0f;
		double dTotalValue = 0.0f;
		double dTotalSORValue = 0.0f;
		double dTotalValidatedValue = 0.0f;
		double dTotalValidatedQty = 0.0f;
		
		double dValidatedPercentage = 0.0f;
		double dValidationRequiredPercentage = 0.0f;
		double dValidatedValuePercentage = 0.0f;
		String strMqlQuery = DomainConstants.EMPTY_STRING;
		if(UIUtil.isNotNullAndNotEmpty(strMBEObjectId)){
				strMqlQuery = "print bus "+strMBEObjectId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+context.getUser()+"'].attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value dump";
				
				String strWorkOrderRole = MqlUtil.mqlCommand(context,strMqlQuery);
				
				String strTypeOfContract = MqlUtil.mqlCommand(context,"print bus "+strMBEObjectId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value dump");

				if(UIUtil.isNotNullAndNotEmpty(strWorkOrderRole) && ("AGE".equals(strWorkOrderRole) || "GE".equals(strWorkOrderRole))){

				HashMap requestMap = new HashMap();
				requestMap.put("objectId", strMBEObjectId);
				MapList mlMBEActivities = getMBEActivities(context,JPO.packArgs(requestMap));
				if(mlMBEActivities != null){
					Map mTemp = null;
					Map mTempMeas = null;
					Map mMeasMap = null;
					Map mMeasMapNotification = null;
					
					for(int i=0;i<mlMBEActivities.size();i++){
						dSORRate = 0.0f;
						dTotalSORQty = 0.0f;
						dValidatedValue = 0.0f;
						dValidatedQty = 0.0f;
						dTotalSORValue = 0.0f;					
						
						mTemp = (Map)mlMBEActivities.get(i);
						if(mTemp != null && mTemp.isEmpty()==false){
							String strSORRate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
							String strTotalActivityQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
							dSORRate = Double.valueOf(strSORRate);	

							strBOQId = (String)mTemp.get(DomainObject.SELECT_ID);
							strRelId = (String)mTemp.get(DomainRelationship.SELECT_ID);
							requestMap = new HashMap();
							requestMap.put("objectId", strBOQId);
							requestMap.put("relId", strRelId);
							MapList mlMeasurementList = getActivityMeasurements(context,JPO.packArgs(requestMap));
							if(mlMeasurementList != null){
								for(int k=0;k<mlMeasurementList.size();k++){
									dValidatedQty = 0.0f;
									dValidatedValue = 0.0f;
									mTempMeas = (Map)mlMeasurementList.get(k);
									strSEValidated = (String)(String)mTempMeas.get("attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"]");
									strEEValidated = (String)(String)mTempMeas.get("attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"]");
									strActivityQty = (String)(String)mTempMeas.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
									dTotalSORQty =  dTotalSORQty + Math.abs(Double.valueOf(strActivityQty));
									if("AGE".equals(strWorkOrderRole) && "Yes".equalsIgnoreCase(strEEValidated)){
										dValidatedQty = Double.valueOf(strActivityQty);
										dValidatedValue = Math.abs(dValidatedQty) * dSORRate;
									}else if("GE".equals(strWorkOrderRole) && "Yes".equalsIgnoreCase(strSEValidated)){
										dValidatedQty = Double.valueOf(strActivityQty);
										dValidatedValue =  Math.abs(dValidatedQty) * dSORRate;
									}
									
									dTotalValidatedQty = dTotalValidatedQty + Math.abs(dValidatedQty);
									dTotalValidatedValue = dTotalValidatedValue + dValidatedValue;
								}								
							}
							dTotalSORValue = dSORRate * dTotalSORQty;
							dTotalQty = dTotalQty + dTotalSORQty;
							dTotalValue = dTotalValue + dTotalSORValue;
							
						}						
					}
					
					if("EPC".equalsIgnoreCase(strTypeOfContract)){
						return DomainConstants.EMPTY_STRING;
						/*if(dTotalQty != 0)
							dValidatedPercentage = (dTotalValidatedQty / dTotalQty)*100;*/
					}else{
						if(dTotalValue != 0)
							dValidatedValuePercentage = (dTotalValidatedValue / dTotalValue)*100;
					}
				}	
				String strValidateColumns = EnoviaResourceBundle.getProperty(context, "WMS.Measurement.Validate.RoleAndPercentage");
				if(UIUtil.isNotNullAndNotEmpty(strValidateColumns)){
					StringList slRolesList = FrameworkUtil.split(strValidateColumns,"|");
					for(int i=0;i<slRolesList.size();i++){
						String strRoleData = (String)slRolesList.get(i);
						StringList slRoleData = FrameworkUtil.split(strRoleData,"~");
						String strRole = (String)slRoleData.get(0);
						String strWeightage = (String)slRoleData.get(1);
						if(strRole.equals(strWorkOrderRole)){
							DecimalFormat decFor = new DecimalFormat("#.##");
							if("EPC".equalsIgnoreCase(strTypeOfContract)){
								if(dValidatedPercentage > Double.valueOf(strWeightage)){
									String strValidatedPercentage = decFor.format(dValidatedPercentage);
									String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.ValidationComplete.Success");
									return strWeightage + "% "+strMessage+" for "+strRole+". Total "+strValidatedPercentage+"% measurements validated.";
								}
							}else{
								if(dValidatedValuePercentage > Double.valueOf(strWeightage)){
									String strValidatedValuePercentage = decFor.format(dValidatedValuePercentage);
									String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.ValidationComplete.Success");
									return strWeightage + "% "+strMessage+" for "+strRole+". Total "+strValidatedValuePercentage+"% measurements validated.";
								}
							}
						}
					}
				}
			}				
		}			
	}catch(Exception e){
		e.printStackTrace();
	} 
	return DomainConstants.EMPTY_STRING;
} 


public StringList getAmountForBOQ(Context context, String[] args)throws Exception{
	StringList slReturnList = new StringList();
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		MapList objectList = (MapList) programMap.get("objectList");
		DecimalFormat decFor = new DecimalFormat("#.###");
		Iterator<Map<String, String>> iteratorMap = objectList.iterator();
		Map<String, String> mapObjectData = new HashMap<String, String>();
		String strReduceRate = DomainConstants.EMPTY_STRING;
		double fQty = 0d;
		double fReduceRate = 0d;
		double fAmount = 0d;
		String strType  = DomainConstants.EMPTY_STRING;
		String strQty  = DomainConstants.EMPTY_STRING;
		String strRate  = DomainConstants.EMPTY_STRING;
		String strAmount = DomainConstants.EMPTY_STRING;
		while (iteratorMap.hasNext()) {
			mapObjectData = iteratorMap.next();
			strType = (String)mapObjectData.get(DomainObject.SELECT_TYPE);
			if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
				strQty = (String)mapObjectData.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
				strRate = (String)mapObjectData.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				
				if(UIUtil.isNotNullAndNotEmpty(strQty) && UIUtil.isNotNullAndNotEmpty(strRate)){
					fAmount = Double.valueOf(strQty)*Double.valueOf(strRate);
					//strAmount = decFor.format(fAmount);
					strAmount = new BigDecimal(fAmount).setScale(3, BigDecimal.ROUND_UP).toPlainString();
				}
				
				if(UIUtil.isNotNullAndNotEmpty(strAmount)){
					slReturnList.add(strAmount);
				}else{
					slReturnList.add("0.000");
				}
			}else{
				slReturnList.add(DomainConstants.EMPTY_STRING);
			}			
		}
		
	} catch (Exception exception) {
		System.out.println("Exception in getUpToDateAmount method of JPO WMSAbsParticulars");
		exception.printStackTrace();
		throw exception;
	}

	return slReturnList;
}
	 
	 
	 
 public void createValidateObjectsForEPC(Context context, String[] args)throws Exception{
	boolean isContextPushed = false;
	
	try {
		ContextUtil.pushContext(context);
		isContextPushed = true;
		String strMBEId = args[0];
		if(UIUtil.isNotNullAndNotEmpty(strMBEId)){
			DomainObject doMBE = new DomainObject(strMBEId);
			  
			String strTypeOfContract = (String)doMBE.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value");
			
			if(UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && "EPC".equalsIgnoreCase(strTypeOfContract)){
					String strValidateColumns = EnoviaResourceBundle.getProperty(context, "WMS.Measurement.Validate.RoleAndPercentage");
					
					if(UIUtil.isNotNullAndNotEmpty(strValidateColumns)){
						StringList slRolesList = FrameworkUtil.split(strValidateColumns,"|");						
						for(int i=0;i<slRolesList.size();i++){
							DomainObject doAdvancObject = DomainObject.newInstance(context);
							String strRoleData = (String)slRolesList.get(i);
							StringList slRoleData = FrameworkUtil.split(strRoleData,"~");
							String strRole = (String)slRoleData.get(0);
							
							String strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
												"type_WMSMBEValidate",
												"",
												"policy_WMSMBEValidate",
												context.getVault().getName(),
												"-"
												);
				
							DomainRelationship domRel   = doAdvancObject.createAndConnect(context,
												TYPE_WMS_MBE_VALIDATE,
												strNewObject,
												"-",
											   POLICY_WMS_MBE_VALIDATE,
												null,
												RELATIONSHIP_WMS_MBE_VALIDATE,
												doMBE,
												true);
							
							domRel.setAttributeValue(context,ATTRIBUTE_WMS_VALIDATE_ROLE,strRole);
						}
			}			
		}		
	} 
	}catch (Exception exception) {
		exception.printStackTrace();
		throw exception;
	}
	finally{
		if(isContextPushed){
			ContextUtil.popContext(context);
		}
		
	}

}


public String getEEValidate(Context context, String[] args)throws Exception{
	HashMap programMap         = (HashMap) JPO.unpackArgs(args);
	HashMap paramMap = (HashMap) programMap.get("paramMap");
	String strMBEId = (String) paramMap.get("objectId");
	
	String strDesc = MqlUtil.mqlCommand(context,"print bus "+strMBEId+" select from["+RELATIONSHIP_WMS_MBE_VALIDATE+"|attribute["+ATTRIBUTE_WMS_VALIDATE_ROLE+"].value=='AGE'].to.description dump");
	
	if(UIUtil.isNullOrEmpty(strDesc)){
		strDesc = DomainConstants.EMPTY_STRING;
	}
	return strDesc;
	
}


public String getSEValidate(Context context, String[] args)throws Exception{
	HashMap programMap         = (HashMap) JPO.unpackArgs(args);
	HashMap paramMap = (HashMap) programMap.get("paramMap");
	String strMBEId = (String) paramMap.get("objectId");
	
	String strDesc = MqlUtil.mqlCommand(context,"print bus "+strMBEId+" select from["+RELATIONSHIP_WMS_MBE_VALIDATE+"|attribute["+ATTRIBUTE_WMS_VALIDATE_ROLE+"].value=='GE'].to.description dump");
	
	if(UIUtil.isNullOrEmpty(strDesc)){
		strDesc = DomainConstants.EMPTY_STRING;
	}
	return strDesc;
}

public void updateEEValidate(Context context, String[] args)throws Exception{
	Map mInput  = JPO.unpackArgs(args);
	Map paramMap = (Map)mInput.get("paramMap");
	String strNewAprTemplate =(String) paramMap.get("New Value");
	String strMBEOid  = (String)paramMap.get("objectId");
	
	String strValidateId = MqlUtil.mqlCommand(context,"print bus "+strMBEOid+" select from["+RELATIONSHIP_WMS_MBE_VALIDATE+"|attribute["+ATTRIBUTE_WMS_VALIDATE_ROLE+"].value=='AGE'].to.id dump");
	if(UIUtil.isNotNullAndNotEmpty(strValidateId)){
		DomainObject doVal = new DomainObject(strValidateId);
		doVal.setDescription(context,strNewAprTemplate);
	}
	
}


public void updateSEValidate(Context context, String[] args)throws Exception{
	Map mInput  = JPO.unpackArgs(args);
	Map paramMap = (Map)mInput.get("paramMap");
	String strNewAprTemplate =(String) paramMap.get("New Value");
	String strMBEOid  = (String)paramMap.get("objectId");
	
	String strValidateId = MqlUtil.mqlCommand(context,"print bus "+strMBEOid+" select from["+RELATIONSHIP_WMS_MBE_VALIDATE+"|attribute["+ATTRIBUTE_WMS_VALIDATE_ROLE+"].value=='GE'].to.id dump");
	
	if(UIUtil.isNotNullAndNotEmpty(strValidateId)){
		DomainObject doVal = new DomainObject(strValidateId);
		doVal.setDescription(context,strNewAprTemplate);
	}
	
}

	public Boolean isMBValidateEEEditable (Context context, String[] args) throws Exception 
	{
		boolean bHasAccess = false;
		try{
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);
		String strMBEId = (String) programMap.get("objectId");
		
		HashMap requestMap = new HashMap();
		requestMap.put("objectId", strMBEId);
		
		boolean isEditable = isMBEditable(context, JPO.packArgs (requestMap));
		 
		 if(UIUtil.isNotNullAndNotEmpty(strMBEId)){
			 DomainObject doObj = new DomainObject(strMBEId);
			 StringList slSelect = new StringList();
			 slSelect.add(DomainObject.SELECT_CURRENT);
			 slSelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
			 Map mObjInfo = doObj.getInfo(context,slSelect);
			 String strWOId = (String)mObjInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
			 
			 if(UIUtil.isNotNullAndNotEmpty(strWOId)){
				 String strQuery = "print bus "+strWOId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value=='AGE'].from.name dump";
				 String strEEusers = MqlUtil.mqlCommand(context,strQuery);
				if(UIUtil.isNotNullAndNotEmpty(strEEusers) && strEEusers.contains(context.getUser()) && isEditable){
					bHasAccess = true;
				}
			 }
		 }
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return bHasAccess;
	}
	
	public Boolean isMBValidateSEEditable (Context context, String[] args) throws Exception 
	{
		 boolean bHasAccess = false;
	 try{
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);
		
		String strMBEId = (String) programMap.get("objectId");
		
		HashMap requestMap = new HashMap();
		requestMap.put("objectId", strMBEId);
		
		boolean isEditable = isMBEditable(context, JPO.packArgs (requestMap));
		
		 if(UIUtil.isNotNullAndNotEmpty(strMBEId)){
			 DomainObject doObj = new DomainObject(strMBEId);
			 StringList slSelect = new StringList();
			 slSelect.add(DomainObject.SELECT_CURRENT);
			 slSelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
			 Map mObjInfo = doObj.getInfo(context,slSelect);
			 String strWOId = (String)mObjInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
			 
			 if(UIUtil.isNotNullAndNotEmpty(strWOId)){
				 String strQuery = "print bus "+strWOId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value=='GE'].from.name dump";
				 String strEEusers = MqlUtil.mqlCommand(context,strQuery);
				if(UIUtil.isNotNullAndNotEmpty(strEEusers) && strEEusers.contains(context.getUser()) && isEditable){
					bHasAccess = true;
				}
			 }
		 }
		 }catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return bHasAccess;
	}

	@com.matrixone.apps.framework.ui.ProgramCallable
	public Map<String,String> addBOQ(Context context, String[] args) throws Exception 
	{
		try
		{
			Map<String,String> mapResult = new HashMap<String,String>();
			mapResult.put(DomainConstants.SELECT_ID, DomainConstants.EMPTY_STRING);
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
			String strMBEOId = (String) programMap.get("objectId");
			int intSize = emxTableRowId.length;
			
			DomainObject doMBE = new DomainObject(strMBEOId);
			DomainObject doBOQ = null;
			if(emxTableRowId !=null && intSize>0&& UIUtil.isNotNullAndNotEmpty(strMBEOId))
			{
				for(int i = 0; i < intSize; i++){
					String[] emxTableRowIdData = emxTableRowId[i].split("[|]");
					String strItemOID = emxTableRowIdData[1];
					doBOQ = new DomainObject(strItemOID);
					DomainRelationship.connect(context, doMBE, WMSConstants_mxJPO.RELATIONSHIP_WMS_MBE_ACTIVITIES, doBOQ);
					StringList slSubMeasurementsList = doBOQ.getInfoList(context,"from["+RELATIONSHIP_WMS_BOQ_SUB_ITEMS+"].to.id");
					String strSubId = DomainConstants.EMPTY_STRING;
					for(int k=0;k<slSubMeasurementsList.size();k++){
						strSubId = (String)slSubMeasurementsList.get(k);
						DomainRelationship.connect(context, doMBE, WMSConstants_mxJPO.RELATIONSHIP_WMS_MBE_ACTIVITIES, new DomainObject(strSubId));
					}
				}
			}
			return mapResult;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}

	
	/*@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedActivitiesForMBE (Context context, String[] args) throws Exception 
     {
		 MapList mlFinalList = new MapList();
         try
         {
             StringList strListActivitiesOIDs = new StringList();
 			String strObjectId = ${CLASS:WMSUtil}.getContextObjectOIDFromArgs(args);
             String strRel = DomainConstants.EMPTY_STRING;
             String strRelSeg = DomainConstants.EMPTY_STRING;
             if(UIUtil.isNotNullAndNotEmpty(strObjectId))
             {
                 StringList strListBusSelects     = new StringList(1);
                 strListBusSelects.add(DomainConstants.SELECT_ID);

                 DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
                 String strType = domObjMBE.getInfo(context, DomainConstants.SELECT_TYPE);
                 if( TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType))
                 {
                     strRel= RELATIONSHIP_WMS_WORK_ORDER_MBE;
                     strRelSeg = RELATIONSHIP_WMS_SEGMENT_MBE;
                 }
                 else if( TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY.equals(strType))
                 {
                     strRel= RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE;
                 }
                 String strWorkOrderOID = domObjMBE.getInfo(context, "relationship["+strRel+"].from.id");

                 MapList mapListConnectedActivities = getMBEActivities(context, domObjMBE);
				 
				 
				 System.out.println("mapListConnectedActivities---------"+mapListConnectedActivities);
 				StringList strListConnectdActivities = ${CLASS:WMSUtil}.convertToStringList(mapListConnectedActivities, DomainConstants.SELECT_ID);

                 if(UIUtil.isNotNullAndNotEmpty(strRelSeg))
                 {
                     String strSegmentOID = domObjMBE.getInfo(context,"relationship["+strRelSeg+"].from.id");
                     if(UIUtil.isNotNullAndNotEmpty(strSegmentOID))
                     {
 						StringList strListOBJ = getRelatedActivities(context,
 								strListBusSelects, strSegmentOID);
                         strListActivitiesOIDs.addAll(strListOBJ);
                     }
                     else
                     {
                         if(UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))
                         {
                             String strMBOID = getMeasurementBookOID(context,strListBusSelects, strWorkOrderOID);
                             if(UIUtil.isNotNullAndNotEmpty(strMBOID))
                             {
                                 StringList strListOBJ = getRelatedActivities(context,
                                 strListBusSelects, strMBOID);
                                 strListActivitiesOIDs.addAll(strListOBJ);

                             }
                         }
                     }
                     
                 }
                 else
                 {
                     if(UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))
                     {
                         String strMBOID = getMeasurementBookOID(context,strListBusSelects, strWorkOrderOID);
                         if(UIUtil.isNotNullAndNotEmpty(strMBOID))
                         {
                             StringList strListOBJ = getRelatedActivities(context,
                             strListBusSelects, strMBOID);
                             strListActivitiesOIDs.addAll(strListOBJ);
                         }
                     }
                 }
                 strListActivitiesOIDs.removeAll(strListConnectdActivities);
             }
			 
			 Map mTempMap = null;
			 String strBOQId = DomainConstants.EMPTY_STRING;
			 for(int i=0;i<strListActivitiesOIDs.size();i++){
				 strBOQId = (String)strListActivitiesOIDs.get(i);
				 mTempMap = new HashMap();
				 mTempMap.put(DomainObject.SELECT_ID,strBOQId);
				 mlFinalList.add(mTempMap);
			 }
			 
             return mlFinalList;
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }*/
	 
	 
	 @com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedActivitiesForMBE (Context context, String[] args) throws Exception 
     {
		 HashMap programMap = (HashMap) JPO.unpackArgs(args);
		StringList slObjList = new StringList();
        MapList mapListObjects = new MapList();
        StringList strListBusSelects     = new StringList(3);
        strListBusSelects.add(DomainConstants.SELECT_ID);
        strListBusSelects.add(DomainConstants.SELECT_TYPE);
		strListBusSelects.add("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
        strListBusSelects.add("attribute["+"WMSItemRateEscalation"+"].value");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");

		StringList strListRelSelects = new StringList(1);
        strListRelSelects.add(DomainRelationship.SELECT_ID);
        Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
        patternType.addPattern(TYPE_WMS_SEGMENT);
        patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK);
        Pattern patternRel = new Pattern(RELATIONSHIP_BILL_OF_QUANTITY);     
        String strObjId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
        if(UIUtil.isNotNullAndNotEmpty(strObjId)){
            DomainObject domObj = DomainObject.newInstance(context, strObjId);
			String strType = domObj.getInfo(context,DomainObject.SELECT_TYPE);
			slObjList = domObj.getInfoList(context,"from["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].to.id");
			if(TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType)){
				
				String strWOId = domObj.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
				domObj = DomainObject.newInstance(context, strWOId);
			}
           
            mapListObjects = domObj.getRelatedObjects(context,
            	                     	                    RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
															patternType.getPattern(),                                    // object pattern
															false,                                                        // to direction
															true,                                                       // from direction
															(short)2,                                                      // recursion level
															strListBusSelects,                                                 // object selects
															null,                                                         // relationship selects
															DomainConstants.EMPTY_STRING,                                // object where clause
															DomainConstants.EMPTY_STRING,                                // relationship where clause
															(short)0,                                                      // No expand limit
															DomainConstants.EMPTY_STRING,                                // postRelPattern
															TYPE_WMS_MEASUREMENT_TASK+","+TYPE_WMS_SEGMENT, // postTypePattern
															null); 
        }
		
		MapList mlFinalList  = new MapList();
		Map mTemp = null;
		String strId = DomainConstants.EMPTY_STRING;
		String strMeasType = DomainConstants.EMPTY_STRING;
		for(int i=0;i<mapListObjects.size();i++){
			mTemp = (Map)mapListObjects.get(i);
			strId = (String)mTemp.get(DomainObject.SELECT_ID);
			strMeasType = (String)mTemp.get(DomainObject.SELECT_TYPE);
			if(slObjList.contains(strId) == false){
				
				if(TYPE_WMS_SEGMENT.equals(strMeasType)){
            		mTemp.put("disableSelection", "true");
				}
				mlFinalList.add(mTemp);
			}
		}
        return mlFinalList;
		 
     }
	 
	  @com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getExpandViewForChapter (Context context, String[] args) throws Exception 
     {
		 HashMap programMap = (HashMap) JPO.unpackArgs(args);
		 String strMBEId= (String)programMap.get("mbeOID");
 		StringList slObjList = new StringList();
        MapList mapListObjects = new MapList();
        StringList strListBusSelects     = new StringList(3);
        strListBusSelects.add(DomainConstants.SELECT_ID);
        strListBusSelects.add(DomainConstants.SELECT_TYPE);
		strListBusSelects.add("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
        strListBusSelects.add("attribute["+"WMSItemRateEscalation"+"].value");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");

		StringList strListRelSelects = new StringList(1);
        strListRelSelects.add(DomainRelationship.SELECT_ID);
        Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
        patternType.addPattern(TYPE_WMS_SEGMENT);
        patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK);
        Pattern patternRel = new Pattern(RELATIONSHIP_BILL_OF_QUANTITY);     
        String strObjId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
        if(UIUtil.isNotNullAndNotEmpty(strObjId)){
            DomainObject domObj = DomainObject.newInstance(context, strObjId);
			String strType = domObj.getInfo(context,DomainObject.SELECT_TYPE);
			DomainObject doMBE = new DomainObject(strMBEId);
			slObjList = doMBE.getInfoList(context,"from["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].to.id");
			if(TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType)){
				
				String strWOId = domObj.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
				domObj = DomainObject.newInstance(context, strWOId);
			}
           
            mapListObjects = domObj.getRelatedObjects(context,
            	                     	                    RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
															patternType.getPattern(),                                    // object pattern
															false,                                                        // to direction
															true,                                                       // from direction
															(short)2,                                                      // recursion level
															strListBusSelects,                                                 // object selects
															null,                                                         // relationship selects
															DomainConstants.EMPTY_STRING,                                // object where clause
															DomainConstants.EMPTY_STRING,                                // relationship where clause
															(short)0,                                                      // No expand limit
															DomainConstants.EMPTY_STRING,                                // postRelPattern
															TYPE_WMS_MEASUREMENT_TASK+","+TYPE_WMS_SEGMENT, // postTypePattern
															null); 
        }
		
		MapList mlFinalList  = new MapList();
		Map mTemp = null;
		String strId = DomainConstants.EMPTY_STRING;
		String strMeasType = DomainConstants.EMPTY_STRING;
		for(int i=0;i<mapListObjects.size();i++){
			mTemp = (Map)mapListObjects.get(i);
			strId = (String)mTemp.get(DomainObject.SELECT_ID);
			strMeasType = (String)mTemp.get(DomainObject.SELECT_TYPE);
			if(slObjList.contains(strId) == false){
				
				if(TYPE_WMS_SEGMENT.equals(strMeasType)){
            		mTemp.put("disableSelection", "true");
				}
				mlFinalList.add(mTemp);
			}
		}
        return mlFinalList;
		 
     }

	public int validateQualityCertificatesAttached(Context context,String[] args) throws Exception
	{
		try {	  
			String strAMBObjectId = args[0];	
			if(UIUtil.isNotNullAndNotEmpty(strAMBObjectId)){
				String strMqlQuery = "print bus "+strAMBObjectId+" select from["+RELATIONSHIP_WMS_BILL_QUALITY_CERTIFICATES+"].to.id dump";
				String strQCids = MqlUtil.mqlCommand(context,strMqlQuery);
				if(UIUtil.isNullOrEmpty(strQCids)){
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.QualityCertificate.NA");	
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		} 
		return 0;
	} 
	
	
	public StringList getAmountForBOQSA(Context context, String[] args)throws Exception{
	StringList slReturnList = new StringList();
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		MapList objectList = (MapList) programMap.get("objectList");
		DecimalFormat decFor = new DecimalFormat("#.###");
		Iterator<Map<String, String>> iteratorMap = objectList.iterator();
		Map<String, String> mapObjectData = new HashMap<String, String>();
		String strReduceRate = DomainConstants.EMPTY_STRING;
		double fQty = 0d;
		double fReduceRate = 0d;
		double fAmount = 0d;
		String strType  = DomainConstants.EMPTY_STRING;
		String strQty  = DomainConstants.EMPTY_STRING;
		String strRate  = DomainConstants.EMPTY_STRING;
		String strAmount = DomainConstants.EMPTY_STRING;
		while (iteratorMap.hasNext()) {
			strAmount = DomainConstants.EMPTY_STRING;
			mapObjectData = iteratorMap.next();
			strType = (String)mapObjectData.get(DomainObject.SELECT_TYPE);
			if(UIUtil.isNotNullAndNotEmpty(strType) && TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
				strQty = (String)mapObjectData.get("attribute["+ATTRIBUTE_WMS_CHANGE_QUANTITY+"]");
				strRate = (String)mapObjectData.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				
				if(UIUtil.isNullOrEmpty(strQty)){
					strQty = (String)mapObjectData.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
				}
				if(UIUtil.isNotNullAndNotEmpty(strQty) && UIUtil.isNotNullAndNotEmpty(strRate)){
					fAmount = Double.valueOf(strQty)*Double.valueOf(strRate);
					//strAmount = decFor.format(fAmount);
					strAmount = new BigDecimal(fAmount).setScale(3, BigDecimal.ROUND_UP).toPlainString();
				}
				
				
				
				if(UIUtil.isNotNullAndNotEmpty(strAmount)){
					slReturnList.add(strAmount);
				}else{
					slReturnList.add("0.000");
				}
			}else{
				slReturnList.add(DomainConstants.EMPTY_STRING);
			}			
		}
		
	} catch (Exception exception) {
		System.out.println("Exception in getUpToDateAmount method of JPO WMSAbsParticulars");
		exception.printStackTrace();
		throw exception;
	}

	return slReturnList;
}


 public int triggerAutoCreateFormalApprovalRoute(Context context,String[] args) throws Exception
     {
		 boolean isContextPushed = false;
      try {	  
			String strContectUser =  context.getUser();
			//ContextUtil.pushContext(context);
			//isContextPushed = true;
    	   String strApprovalTemplOid ="";
    	   String strMBEOid = args[0];
    	   String strPurpose=args[1];
    	   String strBasePolicy=args[2];
		   String strBaseState=args[3];
		   
		if(POLICY_WMS_MEASUREMENT_BOOK_ENTRY_NONEPC.equals(strBasePolicy)){
				
			   //String strRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
			   String strRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"  || attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Not Started\"";
			   DomainObject domMBE= DomainObject.newInstance(context, strMBEOid);
			   String strRel=RELATIONSHIP_WMS_MBE_FORMAL_APPROVAL_TEMPLATE;
			   String strType = domMBE.getInfo(context, DomainConstants.SELECT_TYPE);
			   
			   strApprovalTemplOid = domMBE.getInfo(context, "from["+strRel+"].to.id");
			   Map mRouteAttrib= new HashMap();
			   Map reviewerInfo= new HashMap();
			   mRouteAttrib.put("Route Completion Action", "Notify Route Owner");
			   MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, domMBE, strRelWhere);
			   if(mlExtRoutes.size()>0) {
				   WMSUtil_mxJPO.restartExistingRoute(context,mlExtRoutes);
			   }else {
					 Map objectRouteAttributeMap=new HashMap(); 
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strBasePolicy,false ));;
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Formalized");
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,strPurpose);
					ContextUtil.pushContext(context);
					Route.createAndStartRouteFromTemplateAndReviewers(context,
						   strApprovalTemplOid,
							"Measurement Review",
							 strContectUser , 
							strMBEOid,
							strBasePolicy,
							strBaseState, 
							mRouteAttrib,
							objectRouteAttributeMap, 
							reviewerInfo,
							true);
				   ContextUtil.popContext(context);
				  
			   }
			   
			   StringList slMBESelect = new StringList();
			   slMBESelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
			   slMBESelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
			   
			   Map mMBEInfo = (Map)domMBE.getInfo(context,slMBESelect);
			   
			   String strWOId = (String)mMBEInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
			   String strProjectCode = (String)mMBEInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
			   
			   DomainObject doWO = new DomainObject(strWOId);
			   
			   
			   StringList strListBusSelects = new StringList();
				strListBusSelects.add(DomainObject.SELECT_ID);
				MapList mapListMBEs = doWO.getRelatedObjects(context, // matrix context
                        RELATIONSHIP_WMS_WORK_ORDER_MBE, // relationship pattern
                        TYPE_WMS_MEASUREMENT_BOOK_ENTRY, // type pattern
                        strListBusSelects, // object selects
                        null, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        DomainConstants.EMPTY_STRING, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);
				
				int intSequence = mapListMBEs.size();
				if(intSequence==0){
						intSequence = 1;
				}
				
				NumberFormat numberFormat = new DecimalFormat("000000");
				String strSequence = numberFormat.format(intSequence);
				
				String strPrefix =  EnoviaResourceBundle.getProperty(context, "WMS.ProgressMeasurementBook.Numbering.Prefix");
				if(UIUtil.isNullOrEmpty(strPrefix)){
					strPrefix = "PG";
				}

				String strName = strProjectCode.concat("-").concat(strPrefix).concat("-").concat(strSequence);	
				ContextUtil.pushContext(context);
				domMBE.setName(context,strName);
				ContextUtil.popContext(context);
			   
		   }
         }catch(Exception e) {
        	//  ContextUtil.popContext(context);
    	  e.printStackTrace();
		  } 
		  finally{
			  //if(isContextPushed){
			//	  ContextUtil.popContext(context);
			  //}
		  }
      return 0;
     } 

	public int triggerIsFormalApprovalTemplateConnected(Context context, String[] args) throws Exception{
    	 try {
    		 String strExistRel ="";
    		  String strMEBOid = args[0];
    		  DomainObject domMBE = DomainObject.newInstance(context, strMEBOid);	
			  String strTypeOfContract = (String)domMBE.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value");
    		  String strType = domMBE.getInfo(context, DomainConstants.SELECT_TYPE);
    		  String strRel=RELATIONSHIP_WMS_MBE_FORMAL_APPROVAL_TEMPLATE;
			  ContextUtil.pushContext(context);
    		  strExistRel = domMBE.getInfo(context, "from["+strRel+"]");
			  ContextUtil.popContext(context);
    		  if(strExistRel.equalsIgnoreCase("FALSE") && "EPC".equals(strTypeOfContract)==false) {
    			  Locale strLocale = context.getLocale();
                  String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.alert.NoFormalApprovalTemplate");
                  emxContextUtil_mxJPO.mqlNotice(context,strMessage);
                  return 1;
    		  }
     	    }catch(Exception e) {
    		 e.printStackTrace();
    	 }
    	 
    	 
         return 0; 
      }

	  
	  public int triggerAutoCreateApprovalRouteForNonEPC(Context context,String[] args) throws Exception
     {
		 boolean isContextPushed = false;
      try {	  
			DecimalFormat decFor = new DecimalFormat("#.###");
			Calendar calendarDate = Calendar.getInstance();
			String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
			SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
			String strTime = formatter.format(calendarDate.getTime());
			String strContextUser =  context.getUser();
			//ContextUtil.pushContext(context);
			//isContextPushed = true;
    	   String strApprovalTemplOid ="";
    	   String strMBEOid = args[0];
    	   String strPurpose=args[1];
    	   String strBasePolicy=args[2];
		   String strBaseState=args[3];
		   
		   String strRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
		   DomainObject domMBE= DomainObject.newInstance(context, strMBEOid);
		   
		   String strFormalApprovalId = domMBE.getInfo(context,"from["+RELATIONSHIP_WMS_MBE_FORMAL_APPROVAL_TEMPLATE+"].to.id");
		   String strWOId = domMBE.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
		   
		   
		  /* if(UIUtil.isNotNullAndNotEmpty(strFormalApprovalId)){
			   DomainObject doTemplate = new DomainObject(strFormalApprovalId);
			   StringList strListBusSelects = new StringList();
			   strListBusSelects.add(DomainObject.SELECT_ID);
			   strListBusSelects.add(DomainObject.SELECT_NAME);
			   
			   StringList strListRelSelects = new StringList();
			   strListRelSelects.add(DomainRelationship.SELECT_ID);
			   strListRelSelects.add("attribute["+DomainConstants.ATTRIBUTE_ROUTE_SEQUENCE+"].value");
			   MapList mapListObjects = doTemplate.getRelatedObjects(context, // matrix context
                		                                    DomainRelationship.RELATIONSHIP_ROUTE_NODE,                                     // relationship pattern
															DomainConstants.TYPE_PERSON,    
															strListBusSelects, // object selects
															strListRelSelects, // relationship selects
															false, // to direction
															true, // from direction
															(short) 1, // recursion level
															DomainConstants.EMPTY_STRING, // object where clause
															DomainConstants.EMPTY_STRING, // relationship where clause
															0);
			   Map mTemp = null;
			   String strSequence = DomainConstants.EMPTY_STRING;
			   int iSeq = 0;
			  for(int i=0;i<mapListObjects.size();i++){
				  mTemp = (Map)mapListObjects.get(i);
				  strSequence = (String)mTemp.get("attribute["+DomainConstants.ATTRIBUTE_ROUTE_SEQUENCE+"].value");
				  if(UIUtil.isNotNullAndNotEmpty(strSequence) && Integer.valueOf(strSequence)>iSeq){
					  strContextUser = (String)mTemp.get(DomainObject.SELECT_NAME);
					  iSeq =  Integer.valueOf(strSequence);
				  }				  
			  }			   
		   }
		   
		   if(UIUtil.isNotNullAndNotEmpty(strContextUser) && "User Agent".equals(strContextUser)){
			   strContextUser = domMBE.getInfo(context,DomainObject.SELECT_OWNER);
		   }*/
		   
		   String strRel=RELATIONSHIP_WMS_AMBE_APPROVAL_TEMPLATE;
		   String strType = domMBE.getInfo(context, DomainConstants.SELECT_TYPE);
		   if(strType.equals(TYPE_WMS_MATERIAL_BILL)) {
			   strRel=RELATIONSHIP_WMS_MB_APPROVAL_TEMPLATE;
		   }if(strType.equals(TYPE_WMS_MEASUREMENT_BOOK_ENTRY)) {
			  strRel=RELATIONSHIP_WMS_MBE_APPROVAL_TEMPLATE;
		   }
		   strApprovalTemplOid = domMBE.getInfo(context, "from["+strRel+"].to.id");
		   Map mRouteAttrib= new HashMap();
		   Map reviewerInfo= new HashMap();
		   mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
		   MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, domMBE, strRelWhere);
		   if(mlExtRoutes.size()>0) {
			   WMSUtil_mxJPO.restartExistingRoute(context,mlExtRoutes);
		   }else {				 
				Map objectRouteAttributeMap=new HashMap(); 
				objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strBasePolicy,false ));;
				objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Review");
				objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,strPurpose);
				ContextUtil.pushContext(context);
				Route.createAndStartRouteFromTemplateAndReviewers(context,
					   strApprovalTemplOid,
						"Measurement Review",
						 strContextUser , 
						strMBEOid,
						strBasePolicy,
						strBaseState, 
						mRouteAttrib,
						objectRouteAttributeMap, 
						reviewerInfo,
						true);

				
			   ContextUtil.popContext(context);
		   }
         }catch(Exception e) {
        	//  ContextUtil.popContext(context);
    	  e.printStackTrace();
		  throw e;
		} 
		finally{
		  //if(isContextPushed){
			//  ContextUtil.popContext(context);
		//	}
		}
      return 0;
     } 

	 /**
      * Method to get the connected MBEs under the Work Order
      *
      * @param context the eMatrix <code>Context</code> object
      * @param args Packed program and request maps from the command or form or table
      * @return mapListConnectedMBEs MapList containing the MBEs IDs
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public MapList getWorkOrderProgressMBEs (Context context, String[] args) throws Exception 
     {
         try
         {
             MapList mapListConnectedMBEs = new MapList();
 			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
             if(UIUtil.isNotNullAndNotEmpty(strObjectId))
             {
                 DomainObject domObjWO = DomainObject.newInstance(context, strObjectId);
                 mapListConnectedMBEs = getConnectedMBEs(context, domObjWO,RELATIONSHIP_WMS_WORK_ORDER_MBE,"attribute["+ATTRIBUTE_WMS_FORMALIZED+"].value == No");
                 mapListConnectedMBEs.addSortKey(DomainConstants.SELECT_NAME, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_STRING);
                 mapListConnectedMBEs.addSortKey(DomainObject.SELECT_REVISION, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
                 mapListConnectedMBEs.sort();
                 Map<String,String> mapData;
                 Iterator<Map<String,String>> iterator = mapListConnectedMBEs.iterator();
                 while(iterator.hasNext())
                 {
                     mapData =  (Map<String,String>)iterator.next();
                     String strOID =  mapData.get(DomainConstants.SELECT_ID);
					if(UIUtil.isNotNullAndNotEmpty(strOID))
						{
							DomainObject doMBE = new DomainObject(strOID);
							StringList slSelect = new StringList();
							slSelect.add(DomainObject.SELECT_OWNER);
							slSelect.add(DomainObject.SELECT_CURRENT);
							Map mObjInfo = doMBE.getInfo(context,slSelect);
							
							String strOwner = (String)mObjInfo.get(DomainObject.SELECT_OWNER);
							String strState = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);
							if("Formalized".equals(strState)){
								String mqlQuery = "print bus "+strOID+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
								String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
								if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
										mapData.put("RowEditable", "readonly");
										mapData.put("disableSelection", "true");
								}
							}else{
								mapData.put("RowEditable", "readonly");
								mapData.put("disableSelection", "true");
							}							
						}
                 }
             }
             return mapListConnectedMBEs;
         }
         catch(Exception exception)
         {
             exception.printStackTrace();
             throw exception;
         }
     }
	 
	public StringList getQuantity(Context context, String[] args)throws Exception{
		
		 StringList slFinalList = new StringList();;
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();

			String strType = DomainConstants.EMPTY_STRING;
			String strTotalQty = DomainConstants.EMPTY_STRING;
			String strDeviation = DomainConstants.EMPTY_STRING;
			String strItemType = DomainConstants.EMPTY_STRING;
			
			double dTotalQty = 0;
			double dDeviationQty = 0;
			double dPrevQty = 0;
            while (objectListIterator.hasNext()) {
                Map<String,String> mapData = objectListIterator.next();
                strType = (String)mapData.get(DomainConstants.SELECT_TYPE);
                strItemType = (String)mapData.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]");
                strTotalQty = (String)mapData.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
                strDeviation = (String)mapData.get("attribute["+ATTRIBUTE_WMS_DEVIATION_QUANTITY+"]");
				
				if(UIUtil.isNullOrEmpty(strTotalQty))
					strTotalQty = "0";
				if(UIUtil.isNullOrEmpty(strDeviation))
					strDeviation = "0";
				
				dTotalQty = Double.valueOf(strTotalQty);
				dDeviationQty = Double.valueOf(strDeviation);
				dPrevQty = dTotalQty - dDeviationQty;
				
				
                if(TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
					if(UIUtil.isNotNullAndNotEmpty(strItemType) && "Deviation".equals(strItemType)){
						slFinalList.add( new BigDecimal(dPrevQty).setScale(3, BigDecimal.ROUND_UP).toPlainString() +" ("+ new BigDecimal(dDeviationQty).setScale(3, BigDecimal.ROUND_UP).toPlainString()+")");
					}else{
						slFinalList.add( new BigDecimal(dTotalQty).setScale(3, BigDecimal.ROUND_UP).toPlainString());
					}
				}else{
					slFinalList.add(DomainConstants.EMPTY_STRING);
				}
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return slFinalList;
	}
	
	
	public Vector getSubItemsForBOQ(Context context, String[] args)throws Exception{
		
		Vector colVector = new Vector();
		String strURL="../wms/wmsBOQSubItemsProcess.jsp";
		 HashMap programMap         = (HashMap) JPO.unpackArgs(args);
		 HashMap paramList = (HashMap) programMap.get("paramList");
		 MapList objectList  = (MapList) programMap.get("objectList");
		 StringBuilder sb= null;
		 Iterator<Map> itr = objectList.iterator();
		 String strType = DomainConstants.EMPTY_STRING;
		 String strId = DomainConstants.EMPTY_STRING;
		 while(itr.hasNext()) {
			 Map m = itr.next();
			 strType = (String)m.get(DomainObject.SELECT_TYPE);
			 strId = (String)m.get(DomainObject.SELECT_ID);
			 sb=new StringBuilder();
			 if(strType.equals(TYPE_WMS_MEASUREMENT_TASK)){
				sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strId+"&amp;mode=ListItems','600','400','false');\" >");            
				sb.append("<img border='0' title='Sub Items' src='../common/images/iconStatusAdded.gif' height='15px' name='Sub Items' id='Sub Items' alt='Sub Items'/>");
				sb.append("</a>");
			 }				
			 colVector.add(sb.toString());
		 }
		 
		 return colVector;
	}
	 
	 
	 
	 public Boolean hasAccessToFormalize (Context context, String[] args) throws Exception 
	{
		Boolean bReturn = false ;
		try 
		{
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
             if(UIUtil.isNotNullAndNotEmpty(strObjectId))
             {
				 String strContectUser = context.getUser();
				 String strFormalizeRole = EnoviaResourceBundle.getProperty(context,"WMS.WorkOrder.Formalize.Role");
				 String strFormalizePerson = MqlUtil.mqlCommand(context,"print bus "+strObjectId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"].value == '"+strFormalizeRole+"'].from.name dump");
				 if(UIUtil.isNotNullAndNotEmpty(strFormalizePerson) && strContectUser.equals(strFormalizePerson)){
					 bReturn = true;
				 }
			 }
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return bReturn;
	}	
	 
	 public String formalizeMBE(Context context,String[] args)throws Exception{
		 
		 try{
			DecimalFormat decFor = new DecimalFormat("#.###");
			 
			Calendar calendarDate = Calendar.getInstance();
			String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
			SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
			String strTime = formatter.format(calendarDate.getTime());
			 
			String strPersonId           = PersonUtil.getPersonObjectID(context, context.getUser());
			StringList slPersonSelect = new StringList();
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			
			DomainObject doPerson = new DomainObject(strPersonId);
			Map mPersonInfo = (Map)doPerson.getInfo(context,slPersonSelect);
			String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			if(UIUtil.isNullOrEmpty(strFirstName)){
				strFirstName = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strLastName)){
				strLastName = DomainConstants.EMPTY_STRING;
			}
			String strUser = strFirstName + " " + strLastName;
			
			String strObjId = args[0];
			DomainObject doObj = null;
			if(UIUtil.isNotNullAndNotEmpty(strObjId)){
					doObj = new DomainObject(strObjId);
					String strWOId = doObj.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
					
					StringList busSelect = new StringList();
					busSelect.add(DomainObject.SELECT_ID);
					
					StringList relSelect = new StringList();
					relSelect.add(DomainRelationship.SELECT_ID);
					
					DomainObject doWO = new DomainObject(strWOId);
					String strProjectCoce = (String)doWO.getInfo(context,"to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.attribute["+ATTRIBUTE_WMS_PROJECT_CODE+"].value");
					
					MapList mlMBEList = (MapList)doWO.getRelatedObjects(context,
										RELATIONSHIP_WMS_WORK_ORDER_MBE,
										TYPE_WMS_MEASUREMENT_BOOK_ENTRY,
										busSelect,
										relSelect,
										false,
										true,
										(short)1,
										"attribute["+ATTRIBUTE_WMS_FORMALIZED+"].value == Yes",
										DomainConstants.EMPTY_STRING,
										0);
					
					int iSize = mlMBEList.size();
					String strPrefix =  EnoviaResourceBundle.getProperty(context, "WMS.MeasurementBook.Numbering.Prefix");
					
					NumberFormat numberFormat = new DecimalFormat("000000");
					String strSequence = numberFormat.format(iSize+1);
					String strName = strProjectCoce.concat("-").concat(strPrefix).concat("-").concat(strSequence);
					doObj.setName(context,strName);
					doObj.setOwner(context, context.getUser());	
					doObj.setAttributeValue(context,ATTRIBUTE_WMS_FORMALIZED,"Yes");
					
					StringList slMeasurementsList = (StringList)doObj.getInfoList(context,"from["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
					
					String strId = DomainConstants.EMPTY_STRING;
					
					StringList slSelect = new StringList();
					slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_UWD+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_HISTORY+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_DIMENSION_1+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_DIMENSION_2+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_DIMENSION_3+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_DIMENSION_4+"].value");
					slSelect.add("attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
					slSelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"].value");
					slSelect.add("from["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");
					
					DomainObject doMeasurement = null;
					Map mMeasInfoMap = null;
					String strHistory = DomainConstants.EMPTY_STRING;
					String strFrequency = DomainConstants.EMPTY_STRING;
					String	strLength = DomainConstants.EMPTY_STRING;
					String	strBreadth = DomainConstants.EMPTY_STRING;
					String	strDepth = DomainConstants.EMPTY_STRING;
					String	strRadius = DomainConstants.EMPTY_STRING;
					String	strUWD = DomainConstants.EMPTY_STRING;
					String	strIdDeduction = DomainConstants.EMPTY_STRING;
					String	strCoFactor = DomainConstants.EMPTY_STRING;
					String	strMBEQty = DomainConstants.EMPTY_STRING;
					String	strHistoryNew = DomainConstants.EMPTY_STRING;
					String	strIsShape = DomainConstants.EMPTY_STRING;
					String	strDim1 = DomainConstants.EMPTY_STRING;
					String	strDim2 = DomainConstants.EMPTY_STRING;
					String	strDim3 = DomainConstants.EMPTY_STRING;
					String	strDim4 = DomainConstants.EMPTY_STRING;
					String	strTitle = DomainConstants.EMPTY_STRING;
					String	strShapeName = DomainConstants.EMPTY_STRING;
					String	strScope = DomainConstants.EMPTY_STRING;
					
					for(int k=0;k<slMeasurementsList.size();k++){
						strId = (String)slMeasurementsList.get(k);
						doMeasurement = new DomainObject(strId);
						mMeasInfoMap = (Map)doMeasurement.getInfo(context,slSelect);
							
						if(mMeasInfoMap != null && mMeasInfoMap.isEmpty() == false){
							strMBEQty = (String)mMeasInfoMap.get("from["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");

							strFrequency = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"].value");
							strLength = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"].value");
							strBreadth = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"].value");
							strDepth = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"].value");
							strRadius = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"].value");
							strUWD = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_UWD+"].value");
							strIdDeduction = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"].value");
							strCoFactor = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"].value");
							strIsShape = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_IS_SHAPE+"].value");
							strDim1 = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_1+"].value");
							strDim2 = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_2+"].value");
							strDim3 = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_3+"].value");
							strDim4 = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_DIMENSION_4+"].value");
							strTitle = (String)mMeasInfoMap.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
							strShapeName = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value");
							strScope = (String)mMeasInfoMap.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"].value");
							
							if(UIUtil.isNotNullAndNotEmpty(strFrequency))
								strFrequency = decFor.format(Double.valueOf(strFrequency));
							if(UIUtil.isNotNullAndNotEmpty(strLength))
								strLength = decFor.format(Double.valueOf(strLength));
							if(UIUtil.isNotNullAndNotEmpty(strBreadth))
								strBreadth = decFor.format(Double.valueOf(strBreadth));
							if(UIUtil.isNotNullAndNotEmpty(strDepth))
								strDepth = decFor.format(Double.valueOf(strDepth));
							if(UIUtil.isNotNullAndNotEmpty(strRadius))
								strRadius = decFor.format(Double.valueOf(strRadius));
							if(UIUtil.isNotNullAndNotEmpty(strCoFactor))
								strCoFactor = decFor.format(Double.valueOf(strCoFactor));
							if(UIUtil.isNotNullAndNotEmpty(strDim1))
								strDim1 = decFor.format(Double.valueOf(strDim1));
							if(UIUtil.isNotNullAndNotEmpty(strDim2))
								strDim2 = decFor.format(Double.valueOf(strDim2));
							if(UIUtil.isNotNullAndNotEmpty(strDim3))
								strDim3 = decFor.format(Double.valueOf(strDim3));
							if(UIUtil.isNotNullAndNotEmpty(strDim4))
								strDim4 = decFor.format(Double.valueOf(strDim4));
						}
						if(UIUtil.isNotNullAndNotEmpty(strMBEQty))
								strMBEQty = decFor.format(Double.valueOf(strMBEQty));

						if(UIUtil.isNotNullAndNotEmpty(strIsShape) && "No".equalsIgnoreCase(strIsShape)){
							strHistoryNew = strUser+"|"+strTime+"|"+strFrequency+"|"+strLength+"|"+strBreadth+"|"+strDepth+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor+"|"+strScope+"|"+strMBEQty;
						}else if(UIUtil.isNotNullAndNotEmpty(strIsShape) && "Yes".equalsIgnoreCase(strIsShape)){
							if(UIUtil.isNotNullAndNotEmpty(strShapeName) && ("Circle".equalsIgnoreCase(strShapeName) || "Cylinder".equalsIgnoreCase(strShapeName) || "Cone".equalsIgnoreCase(strShapeName) || "Sphere".equalsIgnoreCase(strShapeName) || "Hemisphere".equalsIgnoreCase(strShapeName))){
								strHistoryNew = strUser+"|"+strTime+"|"+strFrequency+"|"+strDim1+"|"+strDim3+"|"+strDim4+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor+"|"+strScope+"|"+strMBEQty;
							}else{
								strHistoryNew = strUser+"|"+strTime+"|"+strFrequency+"|"+strDim2+"|"+strDim3+"|"+strDim4+"|"+strUWD+"|"+strIdDeduction+"|"+strCoFactor+"|"+strScope+"|"+strMBEQty;
							}
						}
	
						doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_MEASUREMENT_HISTORY, strHistoryNew);
					}
			
			}
		 }catch(Exception ex){
			 ex.printStackTrace();
			 throw ex;
		 }
		 return "Success";
		 
		 
	 }
	 
	 public String getPendingDays(Context context, String[] args)throws Exception{
	String strReturn = DomainConstants.EMPTY_STRING;
	try { 
	boolean isNegative = false;
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);

		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strMBId = (String) paramMap.get("objectId");
		DomainObject doBus = new DomainObject(strMBId);
			
		StringList slObjSelect = new StringList();
		slObjSelect.add(DomainObject.SELECT_ID);
		slObjSelect.add(DomainObject.SELECT_TYPE);
		slObjSelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"].value");
		slObjSelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"].value");
	
		Map mTemp = (Map)doBus.getInfo(context,slObjSelect);


		String strNoOfDays = (String)mTemp.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"].value");
		String strWODate = (String)mTemp.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"].value");

		SimpleDateFormat simpleDateFormatMatrix  = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(),context.getLocale());
		Date dWODate=simpleDateFormatMatrix.parse(strWODate);	

		Date dToday = new Date();

		long lDifference = dToday.getTime() - dWODate.getTime();
		
		long lDiffDays = lDifference/(60*60*1000*24);
		
		long lDuration = Long.valueOf(strNoOfDays);
		
		long lDiff = lDuration - lDiffDays;
		
		if(lDiff < 0){
			isNegative = true;
			lDiff  = lDiff * -1;
		}
		strReturn = String.valueOf(lDiff);
		
		if(isNegative)
			strReturn = "-"+strReturn;
    
	}catch(Exception e) {
		e.printStackTrace();
	} 
	return strReturn;
	
	
}
	 
	public void updateMBHistory(Context context, String[] args)throws Exception{
			try{
				
				String strPersonId = PersonUtil.getPersonObjectID(context);
				StringList slPersonSelect = new StringList();
				slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
				slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
				
				DomainObject doPerson = new DomainObject(strPersonId);
				Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
				String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
				String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
				
				if(UIUtil.isNullOrEmpty(strFirstName)){
					strFirstName = DomainConstants.EMPTY_STRING;
				}
				if(UIUtil.isNullOrEmpty(strLastName)){
					strLastName = DomainConstants.EMPTY_STRING;
				}
				
				String strUser = strFirstName + " " +strLastName;
				
				
				Calendar calendarDate = Calendar.getInstance();
				String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
				SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
				String strTime = formatter.format(calendarDate.getTime());
				
				String strMBEId = args[0];
				String strBOQId = args[1];
				String strRelId = args[2];
				
				if(UIUtil.isNotNullAndNotEmpty(strMBEId) && UIUtil.isNotNullAndNotEmpty(strBOQId) && UIUtil.isNotNullAndNotEmpty(strRelId)){
					DomainObject doMBE = new DomainObject(strMBEId);
					StringList slMBESelect = new StringList();
					slMBESelect.add(DomainObject.SELECT_CURRENT);
					slMBESelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_HISTORY+"].value");
					
					Map mMBEInfo = (Map)doMBE.getInfo(context,slMBESelect);
					
					String strCurrent = (String)mMBEInfo.get(DomainObject.SELECT_CURRENT);
					String strMBEHistory = (String)mMBEInfo.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_HISTORY+"].value");
					
					if(UIUtil.isNotNullAndNotEmpty(strCurrent) && "Review".equals(strCurrent)){
						DomainObject doBOQ = new DomainObject(strBOQId);
						StringList slBOQSelect = new StringList();
						slBOQSelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"].value");
						slBOQSelect.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
						
						Map mBOQInfo = (Map)doBOQ.getInfo(context,slBOQSelect);
						
						String strTitle = (String)mBOQInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
						String strBOQType = (String)mBOQInfo.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"].value");
						
						DomainRelationship drRel = new DomainRelationship(strRelId);
						
						String strMBEQty = (String)drRel.getAttributeValue(context,ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY);
						
						String strNewEntry = strUser+"|"+strTime+"|"+strTitle +"|"+strMBEQty+"|"+strBOQType;
						
						
						if(UIUtil.isNotNullAndNotEmpty(strMBEHistory)){
							strMBEHistory = strMBEHistory + "\n"+strNewEntry;
						}else{
							strMBEHistory = strNewEntry;
						}
						ContextUtil.pushContext(context);
						doMBE.setAttributeValue(context,ATTRIBUTE_WMS_MEASUREMENT_HISTORY,strMBEHistory);
						ContextUtil.popContext(context);
					}
				}				
				
			}catch(Exception ex){
				
			}		
	}
	 
	 
	 
	 public  int triggerCheckMBEQuantity(Context context ,String[] args) {
        	 try {
                 String strMBEOid = args[0];
        		 SelectList selListBusSelects     = new SelectList(7);
                 selListBusSelects.add(DomainConstants.SELECT_ID);
                 selListBusSelects.add(DomainConstants.SELECT_TYPE);
                 selListBusSelects.add(DomainConstants.SELECT_NAME);
                 
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_COST+"]");
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
                 selListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
                 selListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]"); 
				 
                 SelectList selListRelSelects     = new SelectList(2);
                 selListRelSelects.add(DomainRelationship.SELECT_ID);
                 selListRelSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
                 selListRelSelects.add("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"]");
                 selListRelSelects.add("attribute["+ATTRIBUTE_WMS_QTY_SUBMITTED_TILL_DATE+"]");
                 selListRelSelects.add("from.id");
                 selListRelSelects.add("from.current");
        		 
        		 DomainObject domMBE= DomainObject.newInstance(context, strMBEOid);
				 String strMBEOwner = domMBE.getInfo(context,DomainObject.SELECT_OWNER);
				 String strFormalizeUser = MqlUtil.mqlCommand(context,"print bus "+strMBEOid+" select to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"] ~~ *Formalize*].from.name dump");
				 String strContextUser = context.getUser();
				 StringList slFormalizeUserList = FrameworkUtil.split(strFormalizeUser,",");
				 
				 if(!strContextUser.equals(strMBEOwner) || !slFormalizeUserList.contains(strMBEOwner)){
						String strOwnerMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.alert.TakeOwnership");
						emxContextUtil_mxJPO.mqlNotice(context,strOwnerMessage);
						return 1;
				 }
        	 	 MapList mlCurrentBOQs  = getMBEActivities(context,domMBE);
				 
				 StringList slExceedingBOQ = new StringList();
				 StringList slReviewBOQ = new StringList();
				 
				 Map mTemp = null;
				 String strBOQId = DomainConstants.EMPTY_STRING;
				 String strBOQQty = DomainConstants.EMPTY_STRING;
				 String strTitle = DomainConstants.EMPTY_STRING;
        		 for(int i=0;i<mlCurrentBOQs.size();i++){
					 mTemp = (Map)mlCurrentBOQs.get(i);
					 strBOQId = (String)mTemp.get(DomainObject.SELECT_ID);
					 strBOQQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
					 strTitle = (String)mTemp.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
					 if(UIUtil.isNullOrEmpty(strBOQQty)){
							strBOQQty = "0";
					 }
					 double dBOQQty = Double.valueOf(strBOQQty);
					 if(UIUtil.isNotNullAndNotEmpty(strBOQId)){
						 DomainObject doBOQ = new DomainObject(strBOQId);
						 
						 String strSubmittedMeasurements = MqlUtil.mqlCommand(context,"print bus "+strBOQId+" select to["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"|from.current == Review || from.current == Submitted].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value dump |");
						 
						 String strReviewMeasurements = MqlUtil.mqlCommand(context,"print bus "+strBOQId+" select to["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"|from.current == Review].from.id dump |");
						 
						 if(UIUtil.isNotNullAndNotEmpty(strReviewMeasurements)){
							slReviewBOQ.add(strTitle);
						 }
						 
						 String strCurrentMeasurements = MqlUtil.mqlCommand(context,"print bus "+strBOQId+" select to["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"|from.id == "+strMBEOid+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value dump");
						 
						 if(UIUtil.isNullOrEmpty(strCurrentMeasurements)){
							 strCurrentMeasurements = "0";							 
						 }
						 //StringList slMeasurementList = (StringList)doBOQ.getInfoList(context,"to["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");
						 StringList slMeasurementList =  FrameworkUtil.split(strSubmittedMeasurements,"|");
						 
						 double doMeasuredQty = 0.0;
						 for(int j=0;j<slMeasurementList.size();j++){
							 String strQty = (String)slMeasurementList.get(j);
							 if(UIUtil.isNullOrEmpty(strQty)){
								 strQty = "0";
							 }
							 doMeasuredQty = doMeasuredQty + Double.valueOf(strQty);
						 }
						 
						 doMeasuredQty = doMeasuredQty + Double.valueOf(strCurrentMeasurements);
						 
						 if(doMeasuredQty > dBOQQty){
							 slExceedingBOQ.add(strTitle);
						 }
					 }
				 }
        		
				if(slReviewBOQ.size()>0){
					StringBuilder sbMessage = new StringBuilder();
					for(int k=0;k<slReviewBOQ.size();k++){
						if(k==0){
							sbMessage.append((String)slReviewBOQ.get(k));
						}else{
							sbMessage.append(",");
							sbMessage.append((String)slReviewBOQ.get(k));
						}
					}
					
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.alert.BOQUnderReview");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage+"\n"+sbMessage.toString());
					return 1;
				}
				
				
				if(slExceedingBOQ.size()>0){
					StringBuilder sbMessage = new StringBuilder();
					for(int k=0;k<slExceedingBOQ.size();k++){
						if(k==0){
							sbMessage.append((String)slExceedingBOQ.get(k));
						}else{
							sbMessage.append(",");
							sbMessage.append((String)slExceedingBOQ.get(k));
						}
					}
					
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.alert.QtyExceedingBOQQty");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage+"\n"+sbMessage.toString());
					return 1;
				}
        	  
        	 }catch(Exception e) {
        		 e.printStackTrace();
        	 }
         
         return 0;
         
    
        }
	 
	 
	 public StringList getBOQType(Context context,String args[]) throws Exception
    {
        StringList strListAccess = new StringList();;
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();
			while (objectListIterator.hasNext()) {

                Map<String,String> mapData = objectListIterator.next();
                String strType = mapData.get(DomainConstants.SELECT_TYPE);
                String strItemType = mapData.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]");
                if(TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
                    if(UIUtil.isNotNullAndNotEmpty(strItemType) && "Tender Items".equals(strItemType)){
						strListAccess.add("Original");
					}else if("Non-Tender Items".equals(strItemType) || "Deviation".equals(strItemType)){
						strListAccess.add("Supplemental");
					}else{
						strListAccess.add(strItemType);
					}
                }else{
                    strListAccess.add(DomainConstants.EMPTY_STRING);
				}
            }

        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListAccess;

    }
	 
	 
	 @com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getCostStatusWorkOrderAbstractMBEs (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListConnectedMBEs = new MapList();
			 
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjWO = DomainObject.newInstance(context, strObjectId);
				String strType = domObjWO.getInfo(context,DomainObject.SELECT_TYPE);
				if(UIUtil.isNotNullAndNotEmpty(strType) && "WMSAbstractMeasurementBookEntry".equals(strType)){
					strObjectId = (String)domObjWO.getInfo(context,"to[WMSWOAbstractMBE].from.id");
					domObjWO.setId(strObjectId);
				}
				mapListConnectedMBEs = getWorkOrderAbstractMBEs(context, domObjWO);
			}
		 
			return mapListConnectedMBEs;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	 public void promoteChildToActive(Context context, String[] args) throws Exception {
         try {
			 System.out.println("promoteChildTasks---------8360--------------Shanmukha---->");
             String strBOQID = args[0];
             String strType  = args[1];
             String strWherCond =DomainConstants.SELECT_CURRENT+"==Create";
             StringList strListBusSelects     = new StringList(1);
             strListBusSelects.add(DomainConstants.SELECT_ID);
			 StringList strMBOID = new StringList();
			 String strMBOdId = DomainConstants.EMPTY_STRING;
			 System.out.println("strBOQID---------8371--------------Shanmukha---->"+strBOQID);
			 System.out.println("strType---------8371--------------Shanmukha---->"+strType);
             if (UIUtil.isNotNullAndNotEmpty(strBOQID)) {
                     
             if(UIUtil.isNotNullAndNotEmpty(strBOQID)){
					 System.out.println("strBOQID---------8371--------------Shanmukha---->"+strBOQID);
                     DomainObject domObjWorkOrder = DomainObject.newInstance(context,strBOQID);
					 strMBOID = domObjWorkOrder.getInfoList(context,"from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");
					 System.out.println("strMBOID---------8374--------------Shanmukha---->"+strMBOID);
					 for(int k=0;k<strMBOID.size();k++){
						 
						strMBOdId = (String)strMBOID.get(k);
						DomainObject domObjMBOId = DomainObject.newInstance(context,strMBOdId);
						domObjMBOId.promote(context); 
						String strTotalQty = DomainConstants.EMPTY_STRING;
						strTotalQty = (String)domObjMBOId.getAttributeValue(context,ATTRIBUTE_WMS_TOTAL_QUANTITY);
						domObjMBOId.setAttributeValue(context,ATTRIBUTE_WMS_PREV_QUANTITY,strTotalQty);
                 }
             }//End If
         }//End Try
        }catch (Exception exception) 
         {
             exception.printStackTrace();
         }
     }
	 }