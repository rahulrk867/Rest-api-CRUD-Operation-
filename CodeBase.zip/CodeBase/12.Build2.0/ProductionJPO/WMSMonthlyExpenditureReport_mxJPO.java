/*---------------------------------------------------------------------------------------------------------------
NAME		: ${CLASSNAME}.java

DESCRIPTION	: Purpose of JPO is to Create Admin Approvals  and perform the utility operations on it

CREATED		: August 13 2019

AUTHOR		: Divyashree B K

HISTORY		:

	Divyashree B K	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;
import java.math.BigDecimal;
import java.util.Locale;
import java.math.RoundingMode;
import java.time.format.DateTimeFormatter;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectConcept;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PersonUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import matrix.db.Policy;
import matrix.util.Pattern;
import matrix.util.LicenseUtil;
import matrix.db.MQLCommand;


import java.io.File;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.util.Map;
import java.util.Iterator;
import java.util.Date;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.io.*;

import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.util.XMLResourceDescriptor;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;


import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;

public class WMSMonthlyExpenditureReport_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSMonthlyExpenditureReport_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	
	public String generateMER(Context context,String[] args)throws Exception{
		String strReturn = DomainConstants.EMPTY_STRING;
		String strIsBatchJob = args[0];
		try{
			MapList mlReportDataList = new MapList();
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainObject.SELECT_ID);
			strListBusSelects.add(DomainObject.SELECT_NAME);
			MapList mlRevisionList = DomainObject.findObjects(
					context,
					TYPE_WMS_CODE_HEAD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.EMPTY_STRING,               // where expression
					DomainConstants.EMPTY_STRING,
					true,
					strListBusSelects, // object selects
					(short) 0);
			
			String strYear = DomainConstants.EMPTY_STRING;
			String strMonth = DomainConstants.EMPTY_STRING;		
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			String strMonthName = now.getMonth().name();			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			strMonth = String.valueOf(month);
			
			Map mTemp = null;
			
			for(int i=0;i<mlRevisionList.size();i++){
				String strCodeHeadId = DomainConstants.EMPTY_STRING;
				Map mCodeHeadDataMap = new HashMap();
				StringList slWorkOrderList = new StringList();
				mTemp = (Map)mlRevisionList.get(i);
				strCodeHeadId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strCodeHeadId)){
					mCodeHeadDataMap.put("FinacialYear",strYear);
					mCodeHeadDataMap.put("Name",(String)mTemp.get(DomainObject.SELECT_NAME));
					String strProjectIds = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.id dump |");
					
					StringList slProjectList = FrameworkUtil.split(strProjectIds,"|");
					for(int k=0;k<slProjectList.size();k++){
						
						String strAdminApprovalAmount = "0.00";
			
						Map mProjectDataMap = new HashMap();						
						String strWONames = MqlUtil.mqlCommand(context,"print bus "+(String)slProjectList.get(k)+" select from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value dump \n");
						slWorkOrderList = FrameworkUtil.split(strWONames,",");
						String strProjectName = MqlUtil.mqlCommand(context,"print bus "+(String)slProjectList.get(k)+" select name dump \n");
						String strAAAmount = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"|from.id=="+(String)slProjectList.get(k)+"].from.from["+RELATIONSHIP_WMSPROJECTSOC+"].to.from["+RELATIONSHIP_WMSSOCADMINAPPROVAL+"].to.attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"].value dump |");
						if(UIUtil.isNotNullAndNotEmpty(strAAAmount)){
							StringList slAAList = FrameworkUtil.split(strAAAmount,"|");
							double dSum = 0.0;
							for(int j=0;j<slAAList.size();j++){
								String strAmt = (String)slAAList.get(j);
								if(UIUtil.isNullOrEmpty(strAmt))
									strAmt = "0";
								dSum = dSum+Double.valueOf(strAmt);
							}
							strAdminApprovalAmount = WMSUtil_mxJPO.converToIndianCurrency(context,dSum);
							//strAdminApprovalAmount = String.valueOf(dSum);
						}
						mCodeHeadDataMap.put("AdminApprovalAmount",strAdminApprovalAmount);
						mCodeHeadDataMap.put("ProjectName",strProjectName);
						String strWorkOrderName = DomainConstants.EMPTY_STRING;
						for(int ctr=0;ctr<slWorkOrderList.size();ctr++){
							
							String strExpenditurePevFinancialYear = "0.0";
							String strAllotmentCFY = "0.0";
							String strExpenditurePrevMonthCFY = "0.0";
							String strExpenditureThisMonthCFY = "0.0";
							String strExpenditureCFY = "0.0";
							String strTotalExp = "0.0";
							String strUnitNames = DomainConstants.EMPTY_STRING;
							String strRemarks = DomainConstants.EMPTY_STRING;
							Map mDataMap = new HashMap();		
							if(UIUtil.isNotNullAndNotEmpty(strProjectName)){
								mDataMap.put("ProjectName",strProjectName);
							}else{
								mDataMap.put("ProjectName",DomainConstants.EMPTY_STRING);
							}
							
							strWorkOrderName = (String)slWorkOrderList.get(ctr);
							mDataMap.put("WorkOrderName",strWorkOrderName);
							String strExpPrevFY = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"|to.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value==\""+strWorkOrderName+"\"].to.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value !='"+strYear+"' && (to.current==Approved || to.current==Paid))].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
							
							if(UIUtil.isNotNullAndNotEmpty(strExpPrevFY)){
								StringList slAAList = FrameworkUtil.split(strExpPrevFY,"|");
								double dSum = 0.0;
								for(int j=0;j<slAAList.size();j++){
									String strAmt = (String)slAAList.get(j);
									if(UIUtil.isNullOrEmpty(strAmt))
										strAmt = "0";
									dSum = dSum+Double.valueOf(strAmt);
								}
								//strExpenditurePevFinancialYear = ${CLASS:WMSUtil}.converToIndianCurrency(context,dSum);
								strExpenditurePevFinancialYear = String.valueOf(dSum);
							}
							
							mDataMap.put("ExpenditureUptoPrevFinancialYear",strExpenditurePevFinancialYear);
							
							double dAllotmentCFY = 0.0;
							String strTotalFundRequests = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"|to.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value==\""+strWorkOrderName+"\"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"'&& to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
							if(UIUtil.isNotNullAndNotEmpty(strTotalFundRequests)){
								StringList slAmounts = FrameworkUtil.split(strTotalFundRequests,"|");
								for(int j=0;j<slAmounts.size();j++){
									dAllotmentCFY = dAllotmentCFY + Double.valueOf((String)slAmounts.get(j));
								}
							}
								
							String strTotalFundReleases = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"|to.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value==\""+strWorkOrderName+"\"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.current==Approved)].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
							if(UIUtil.isNotNullAndNotEmpty(strTotalFundReleases)){
								StringList slAmounts = FrameworkUtil.split(strTotalFundReleases,"|");
								for(int j=0;j<slAmounts.size();j++){
									dAllotmentCFY = dAllotmentCFY - Double.valueOf((String)slAmounts.get(j));
								}
							}
							//strAllotmentCFY = ${CLASS:WMSUtil}.converToIndianCurrency(context,dAllotmentCFY);
							strAllotmentCFY = String.valueOf(dAllotmentCFY);
							
							mDataMap.put("AllotmentCFY",strAllotmentCFY);
							
							String strExpPrevMonthCFY = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"|to.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value==\""+strWorkOrderName+"\"].to.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value =='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value !='"+strMonth+"' && (to.current==Approved || to.current==Paid))].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
							
							if(UIUtil.isNotNullAndNotEmpty(strExpPrevMonthCFY)){
								StringList slAAList = FrameworkUtil.split(strExpPrevMonthCFY,"|");
								double dSum = 0.0;
								for(int j=0;j<slAAList.size();j++){
									String strAmt = (String)slAAList.get(j);
									if(UIUtil.isNullOrEmpty(strAmt))
										strAmt = "0";
									dSum = dSum+Double.valueOf(strAmt);
								}
								//strExpenditurePrevMonthCFY = ${CLASS:WMSUtil}.converToIndianCurrency(context,dSum);
								strExpenditurePrevMonthCFY = String.valueOf(dSum);
							}
							mDataMap.put("ExpenditurePrevMonthCFY",strExpenditurePrevMonthCFY);
							
							String strTotalExpThisMonthCFY = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"|to.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value==\""+strWorkOrderName+"\"].to.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value =='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value =='"+strMonth+"' && (to.current==Approved || to.current==Paid))].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
							
							if(UIUtil.isNotNullAndNotEmpty(strTotalExpThisMonthCFY)){
								StringList slAAList = FrameworkUtil.split(strTotalExpThisMonthCFY,"|");
								double dSum = 0.0;
								for(int j=0;j<slAAList.size();j++){
									String strAmt = (String)slAAList.get(j);
									if(UIUtil.isNullOrEmpty(strAmt))
										strAmt = "0";
									dSum = dSum+Double.valueOf(strAmt);
								}
								//strExpenditureThisMonthCFY = ${CLASS:WMSUtil}.converToIndianCurrency(context,dSum);
								strExpenditureThisMonthCFY = String.valueOf(dSum);
							}
							mDataMap.put("ExpenditureThisMonthCFY",strExpenditureThisMonthCFY);
							
							String strTotalExpCFY = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"|to.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value==\""+strWorkOrderName+"\"].to.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value =='"+strYear+"'  && (to.current==Approved || to.current==Paid))].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
							
							if(UIUtil.isNotNullAndNotEmpty(strTotalExpCFY)){
								StringList slAAList = FrameworkUtil.split(strTotalExpCFY,"|");
								double dSum = 0.0;
								for(int j=0;j<slAAList.size();j++){
									String strAmt = (String)slAAList.get(j);
									if(UIUtil.isNullOrEmpty(strAmt))
										strAmt = "0";
									dSum = dSum+Double.valueOf(strAmt);
								}
								//strExpenditureCFY = ${CLASS:WMSUtil}.converToIndianCurrency(context,dSum);
								strExpenditureCFY = String.valueOf(dSum);
							}
							mDataMap.put("TotalExpCFY",strExpenditureCFY);
							
							String strTotal= MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"|to.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value==\""+strWorkOrderName+"\"].to.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.current==Approved || to.current==Paid)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
							
							if(UIUtil.isNotNullAndNotEmpty(strTotal)){
								StringList slAAList = FrameworkUtil.split(strTotal,"|");
								double dSum = 0.0;
								for(int j=0;j<slAAList.size();j++){
									String strAmt = (String)slAAList.get(j);
									if(UIUtil.isNullOrEmpty(strAmt))
										strAmt = "0";
									dSum = dSum+Double.valueOf(strAmt);
								}
								//strTotalExp = ${CLASS:WMSUtil}.converToIndianCurrency(context,dSum);
								strTotalExp = String.valueOf(dSum);
							}
							mDataMap.put("TotalExp",strTotalExp);
							
							String strWorkOwners= MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"|to.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value==\""+strWorkOrderName+"\"].to.owner dump |");
							if(UIUtil.isNotNullAndNotEmpty(strWorkOwners)){
								StringList slOwners = FrameworkUtil.split(strWorkOwners,"|");
								for(int j=0;j<slOwners.size();j++){
									String strOwner = (String)slOwners.get(j);
									String strFullName = MqlUtil.mqlCommand(context,"print person "+strOwner+" select fullname dump");
									String strPersonId = PersonUtil.getPersonObjectID(context,strOwner);
									String strCompanyName = MqlUtil.mqlCommand(context,"print bus "+strPersonId+" select to[Member|from.type==Company].from.name dump");
									strWorkOwners = strFullName +"(" +strCompanyName+")";							
									strUnitNames = strUnitNames+"\n"+strWorkOwners;
								}
							}
							mDataMap.put("Units",strUnitNames);
							mDataMap.put("Remarks",strRemarks);
							
							mProjectDataMap.put(strWorkOrderName,mDataMap);
						}
						mCodeHeadDataMap.put(strProjectName,mProjectDataMap);
						mCodeHeadDataMap.put("WorkOrderList",strWONames);
					}
				}
				mlReportDataList.add(mCodeHeadDataMap);
			}
			strReturn = generateMERFile(context,mlReportDataList);
			//strReturn = generateMERPdf(context,mlReportDataList);
			
			if(UIUtil.isNotNullAndNotEmpty(strIsBatchJob) && "true".equalsIgnoreCase(strIsBatchJob)){
				DomainObject doMER = DomainObject.newInstance(context,strReturn);
				HashMap mAttMap = new HashMap();
				mAttMap.put(ATTRIBUTE_WMS_FINANCIAL_YEAR,strYear);
				mAttMap.put(ATTRIBUTE_WMS_MONTH,strMonthName);
				String strName = "MER_"+strMonthName+"_"+strYear;
				ContextUtil.pushContext(context);
				doMER.setName(context,strName);
				doMER.setAttributeValues(context,mAttMap);
				ContextUtil.popContext(context);
			}
		}catch(Exception ex){
			ex.printStackTrace();
			return "failed";
		}
		return strReturn;
	}	
	
	private String generateMERPdf(Context context,MapList mlReportDataList)throws Exception{
		String strMERId = DomainConstants.EMPTY_STRING;
		try{
			String strHeader = DomainConstants.EMPTY_STRING;
			String strTransPath = context.createWorkspace();
			String xmlSourceFileName = "MERFormSource.xml";
			String xmlFilePath = strTransPath + File.separator+xmlSourceFileName;
			String sCodeHead = DomainConstants.EMPTY_STRING;
			String sProjectName = DomainConstants.EMPTY_STRING;
			String sWorkName = DomainConstants.EMPTY_STRING;
			String sAAAmount = DomainConstants.EMPTY_STRING;
			String sExpUptoPrevFinYr = DomainConstants.EMPTY_STRING;
			String sTotalExpCFY =  DomainConstants.EMPTY_STRING;
			String sAllCFY = DomainConstants.EMPTY_STRING;
			String sExpPrecMCFY = DomainConstants.EMPTY_STRING;
			String sExpThisMCFY = DomainConstants.EMPTY_STRING;
			String sTotalExp = DomainConstants.EMPTY_STRING;
			String sUnits = DomainConstants.EMPTY_STRING;
			String sReamrks = DomainConstants.EMPTY_STRING;
			String sFinancialYear = DomainConstants.EMPTY_STRING;
			String strSeqNo = DomainConstants.EMPTY_STRING;
			
     		DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
			Document document = documentBuilder.newDocument();
			Element root = document.createElement("page");
			document.appendChild(root);
			String strpath = System.getProperty("user.dir");
		    File newFile = new File(strpath+"/..");
			
			String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
			String strLogo = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Logo");
			String strWatermark = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Watermark");
			strWatermark = strWatermark.replace("\\", "/");
			strLogo = strLogo.replace("\\", "/");
			Element embLogo = document.createElement("logo1");
			embLogo.appendChild(document.createTextNode("file:"+strLogo));
		
			Element embHeader = document.createElement("header-footer");
			Element embWatermark = document.createElement("watermark");
			embWatermark.appendChild(document.createTextNode("file:"+strWatermark));
			strHeader = "";
			embHeader.appendChild(document.createTextNode(strHeader));
			root.appendChild(embHeader);
			root.appendChild(embWatermark);
			root.appendChild(embLogo);
			
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			String strYear = DomainConstants.EMPTY_STRING;
			String strMonth = DomainConstants.EMPTY_STRING;
			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			Calendar cal = Calendar.getInstance();
			strMonth = cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH);
			
			LocalDateTime today = LocalDateTime.now();
			LocalDateTime lastMonthDate = today.minusMonths(1);
			LocalDateTime lastMonthNextDate = lastMonthDate.plusDays(1);
			DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			String formattedDate = today.format(myFormatObj);
			String formattedPrevMonthDate = lastMonthNextDate.format(myFormatObj);
			
			sFinancialYear = strMonth +"("+strYear+")"+" Period: ("+formattedPrevMonthDate+" - "+formattedDate+")";
			Element Month_Financial_Year = document.createElement("Month_Financial_Year");
			Month_Financial_Year.appendChild(document.createTextNode(sFinancialYear));
		    root.appendChild(Month_Financial_Year);
			
			
			int iSize = mlReportDataList.size();
			Map mapObjectInfo = null;
			for(int i=0; i<iSize; i++) {
				mapObjectInfo = (Map)mlReportDataList.get(i);
				strSeqNo = String.valueOf(i+1);
			    sCodeHead = (String)mapObjectInfo.get("Name"); 
				sProjectName = (String)mapObjectInfo.get("ProjectName"); 
				sWorkName = (String)mapObjectInfo.get("WorkOrderName");
				sAAAmount = (String)mapObjectInfo.get("AdminApprovalAmount");
				sExpUptoPrevFinYr = (String)mapObjectInfo.get("ExpenditureUptoPrevFinancialYear");
				sAllCFY = (String)mapObjectInfo.get("AllotmentCFY");
				sExpPrecMCFY = (String)mapObjectInfo.get("ExpenditurePrevMonthCFY");
				sExpThisMCFY = (String)mapObjectInfo.get("ExpenditureThisMonthCFY");
				sTotalExpCFY  = (String)mapObjectInfo.get("TotalExpCFY");
				sTotalExp = (String)mapObjectInfo.get("TotalExp");
				sUnits = (String)mapObjectInfo.get("Units");
				sReamrks = (String)mapObjectInfo.get("Remarks");
			
				Element Merdetails = document.createElement("Merdetails");
				Element Sl_No = document.createElement("Sl_No");
				Element Code_Head = document.createElement("Code_Head");
				Element Project_Name = document.createElement("Project_Name");
				Element Work_Name = document.createElement("Work_Name");
				Element AA_Amount = document.createElement("AA_Amount");
				Element Exp_Upto_Prev_FY = document.createElement("Exp_Upto_Prev_FY");
				Element Allotment_CFY_SO = document.createElement("Allotment_CFY_SO");
				Element Exp_Upto_Prev_Mon_CFY = document.createElement("Exp_Upto_Prev_Mon_CFY");
				Element Total_Exp_Current_Month_CFY = document.createElement("Total_Exp_Current_Month_CFY");
				Element Total_Exp_CFY = document.createElement("Total_Exp_CFY");
				Element Total_Exp_Incl_prev_years_upto_current_month = document.createElement("Total_Exp_Incl_prev_years_upto_current_month");
				Element Unit_Name = document.createElement("Unit_Name");
				Element Remarks = document.createElement("Remarks");
				
				Sl_No.appendChild(document.createTextNode(strSeqNo));
				Code_Head.appendChild(document.createTextNode(sCodeHead));
				Project_Name.appendChild(document.createTextNode(sProjectName));
				Work_Name.appendChild(document.createTextNode(sWorkName));
				AA_Amount.appendChild(document.createTextNode(sAAAmount));
				Exp_Upto_Prev_FY.appendChild(document.createTextNode(sExpUptoPrevFinYr));
				Allotment_CFY_SO.appendChild(document.createTextNode(sAllCFY));
				Exp_Upto_Prev_Mon_CFY.appendChild(document.createTextNode(sExpPrecMCFY));
				Total_Exp_Current_Month_CFY.appendChild(document.createTextNode(sExpThisMCFY));
				Total_Exp_CFY.appendChild(document.createTextNode(sTotalExpCFY));
				Total_Exp_Incl_prev_years_upto_current_month.appendChild(document.createTextNode(sTotalExp));
				Unit_Name.appendChild(document.createTextNode(sUnits));
				Remarks.appendChild(document.createTextNode(sReamrks));
			    
				Merdetails.appendChild(Sl_No);
				Merdetails.appendChild(Code_Head);
				Merdetails.appendChild(Project_Name);
				Merdetails.appendChild(Work_Name);
				Merdetails.appendChild(AA_Amount);
				Merdetails.appendChild(Exp_Upto_Prev_FY);
				Merdetails.appendChild(Allotment_CFY_SO);
				Merdetails.appendChild(Exp_Upto_Prev_Mon_CFY);
				Merdetails.appendChild(Total_Exp_Current_Month_CFY);
				Merdetails.appendChild(Total_Exp_CFY);
				Merdetails.appendChild(Total_Exp_Incl_prev_years_upto_current_month);
				Merdetails.appendChild(Unit_Name);
				Merdetails.appendChild(Remarks);
				root.appendChild(Merdetails);
			
			}
			
			
			
			/*StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			MapList mlMER = DomainObject.findObjects(context, TYPE_WMS_MER, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					DomainConstants.EMPTY_STRING, // where clause
					strListBusSelects); // object selects
			
			Map mTemp = null;
			for(int k=0;k<mlMER.size();k++){
				mTemp = (Map)mlMER.get(k);
				String strID = (String)mTemp.get(DomainObject.SELECT_ID);
				DomainObject doMER = new DomainObject(strID);
				ContextUtil.pushContext(context);
				doMER.deleteObject(context);
				ContextUtil.popContext(context);
			}*/
			
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domSource = new DOMSource(document);	
			StreamResult streamResult = new StreamResult(new File(xmlFilePath));
			transformer.transform(domSource, streamResult);
			
			File xmlFile = new File(xmlFilePath);

			//Write XML - End
		
			//Write XSL - Start
			String strXSLFile = "WMSMonthlyExpenditureReportSource.xsl";
			File newTextFile = new File(strTransPath + File.separator+strXSLFile);

			MQLCommand mql = new MQLCommand();
			mql.open(context);
			mql.executeCommand(context, "print program WMSMonthlyExpenditureReport.xsl select code dump");
			mql.close(context);
			FileWriter fw = new FileWriter(newTextFile);
			fw.write(mql.getResult());
			fw.close();
			//Write XSL - End				
			
			File xsltFile = new File(strTransPath + File.separator+strXSLFile);
			// the XML file which provides the input
			StreamSource xmlSource = new StreamSource(new File(xmlFilePath));
			// create an instance of fop factory
			// Setup output
			String strName = "MER";
			String strFileName = strName+".pdf";
			OutputStream out;
			out = new java.io.FileOutputStream(strTransPath+File.separator+strFileName);
			try {
				FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
				// a user agent is needed for transformation
				FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
				// Construct fop with desired output format
				Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);

				// Setup XSLT
				TransformerFactory factory = TransformerFactory.newInstance();
				Transformer transformer1 = factory.newTransformer(new StreamSource(xsltFile));
				
				// Resulting SAX events (the generated FO) must be piped through to FOP
				Result res = new SAXResult(fop.getDefaultHandler());
				// Start XSLT transformation and FOP processing
				// That's where the XML is first transformed to XSL-FO and then 
				// PDF is created
				transformer1.transform(xmlSource, res);
			} finally {
				    File file1 = new File(strTransPath+File.separator+strFileName);	
					DomainObject domMER = DomainObject.newInstance(context);
					domMER.createObject(context, TYPE_WMS_MER, "MER", "", POLICY_WMS_MER, "eService Production");
					domMER.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strTransPath);
					//domMER.setOwner(context, context.getUser());	
					strMERId = domMER.getId(context);										
					
				if(file1.delete())
				{
					System.out.println("File deleted successfully");
				}
				else
				{
					System.out.println("Failed to delete the file");
				}
				if(newTextFile.delete())
				{
					System.out.println("File deleted successfully");
				}
				else
				{
					System.out.println("Failed to delete the file");
				}
				if(xmlFile.delete())
				{
					System.out.println("File deleted successfully");
				}
				else
				{
					System.out.println("Failed to delete the file");
				}
				out.close();
				
			}
				
			
		}
		
		catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return strMERId;
		
	}
		
		
	private String generateMERFile(Context context, MapList mlReportDataList)throws Exception{
		String strMERId = DomainConstants.EMPTY_STRING;
		try{
			FileOutputStream outputStream = null;
			XSSFWorkbook workbook = new XSSFWorkbook();
			XSSFSheet sheetData = workbook.createSheet("MER");
			String[] headerData = {"Sl No", "Code Head", "Project Name","Work Name", "AA Amount", "Exp. Upto Prev FY", "Allotment CFY SO(B)", "Exp. Upto Prev Mon CFY", "Total Exp Current Month CFY", "Total Exp CFY", "Total Exp. Incl. prev years upto current month", "Unit Name", "Remarks"};
			CellStyle styleHeading = workbook.createCellStyle();
			styleHeading.setBorderLeft(CellStyle.ALIGN_CENTER);
			
			XSSFFont font= workbook.createFont();
			font.setFontHeightInPoints((short)10);
			font.setFontName("Arial");
			font.setColor(IndexedColors.WHITE.getIndex());
			font.setBold(true);
			styleHeading.setFont(font);
			styleHeading.setFillForegroundColor((short)30);
			styleHeading.setFillPattern(CellStyle.SOLID_FOREGROUND); 
			styleHeading.setBorderLeft(CellStyle.BORDER_THIN);
			styleHeading.setBorderRight(CellStyle.BORDER_THIN);
			styleHeading.setBorderTop(CellStyle.BORDER_THIN);
			styleHeading.setBorderBottom(CellStyle.BORDER_THIN);
			styleHeading.setAlignment(CellStyle.ALIGN_CENTER);
			
			Row row1 = sheetData.createRow(0);
			Cell cell1 = row1.createCell(0);  
            cell1.setCellValue("Monthly Expenditure Report");  
            sheetData.addMergedRegion(new CellRangeAddress(0,0,0,12));
			cell1.setCellStyle(styleHeading);
			
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			String strYear = DomainConstants.EMPTY_STRING;
			String strMonth = DomainConstants.EMPTY_STRING;
			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			Calendar cal = Calendar.getInstance();
			strMonth = cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH);
			
			LocalDateTime myDateObj = LocalDateTime.now();
			DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy");

			String formattedDate = myDateObj.format(myFormatObj);
			
			Row row2 = sheetData.createRow(1);
			Cell cell2 = row2.createCell(0);  
            cell2.setCellValue("Month & Financial Year: "+strMonth+"("+strYear+")");  
            sheetData.addMergedRegion(new CellRangeAddress(1,1,0,12));
			cell2.setCellStyle(styleHeading);
			
			Row rowHeader = sheetData.createRow(2);
			for (int columnCount=0; columnCount < headerData.length; columnCount++) {
				Cell cell = rowHeader.createCell(columnCount);
				cell.setCellValue((String) headerData[columnCount]);
				cell.setCellStyle(styleHeading);
			}
			
			String[] cellData = new String[headerData.length];
			String[] cellDataWO = new String[headerData.length];
			int iRowCout=3;
			
			Row rowData = null;
			
			int iSize = mlReportDataList.size();
			Map mapObjectInfo = null;
			String strWorkOrderName = DomainConstants.EMPTY_STRING;
			int iCountRow = 3;
			
			String strExpenditureUptoPrevFinancialYear = DomainConstants.EMPTY_STRING;
			String strAllotmentCFY = DomainConstants.EMPTY_STRING;
			String strExpenditurePrevMonthCFY = DomainConstants.EMPTY_STRING;
			String strExpenditureThisMonthCFY = DomainConstants.EMPTY_STRING;
			String strTotalExpCFY = DomainConstants.EMPTY_STRING;
			String strTotalExp = DomainConstants.EMPTY_STRING;
			
			for(int i=0; i<iSize; i++) {
				double bExpenditureUptoPrevFinancialYear = 0.0;
				double bAllotmentCFY = 0.0;
				double bExpenditurePrevMonthCFY = 0.0;
				double bExpenditureThisMonthCFY = 0.0;
				double bTotalExpCFY = 0.0;
				double bTotalExp = 0.0;
								
				cellData = new String[headerData.length];
				mapObjectInfo = (Map)mlReportDataList.get(i);
				cellData[0] = String.valueOf(i+1);
				cellData[1] = (String)mapObjectInfo.get("Name"); 
				String strProjectName = (String)mapObjectInfo.get("ProjectName");
				cellData[2] = strProjectName;
				cellData[3] = DomainConstants.EMPTY_STRING;
				cellData[4] = (String)mapObjectInfo.get("AdminApprovalAmount");				
				Map mProjectMap = (Map)mapObjectInfo.get(strProjectName);
				String strWorkOrderList = (String)mapObjectInfo.get("WorkOrderList");
				StringList slWorkOrderList  = FrameworkUtil.split(strWorkOrderList,",");
				int iWorkOrderSize = slWorkOrderList.size();
				for(int k=0;k<slWorkOrderList.size();k++){
					strWorkOrderName = (String)slWorkOrderList.get(k);
					Map mWorkOrderMap = (Map)mProjectMap.get(strWorkOrderName);
					strExpenditureUptoPrevFinancialYear = (String)mWorkOrderMap.get("ExpenditureUptoPrevFinancialYear");
					strAllotmentCFY = (String)mWorkOrderMap.get("AllotmentCFY");
					strExpenditurePrevMonthCFY = (String)mWorkOrderMap.get("ExpenditurePrevMonthCFY");
					strExpenditureThisMonthCFY = (String)mWorkOrderMap.get("ExpenditureThisMonthCFY");
					strTotalExpCFY = (String)mWorkOrderMap.get("TotalExpCFY");
					strTotalExp = (String)mWorkOrderMap.get("TotalExp");		

					bExpenditureUptoPrevFinancialYear = bExpenditureUptoPrevFinancialYear+Double.valueOf(strExpenditureUptoPrevFinancialYear);
					bAllotmentCFY = bAllotmentCFY+Double.valueOf(strAllotmentCFY);					
					bExpenditurePrevMonthCFY = bExpenditurePrevMonthCFY+Double.valueOf(strExpenditurePrevMonthCFY);					
					bExpenditureThisMonthCFY = bExpenditureThisMonthCFY+Double.valueOf(strExpenditureThisMonthCFY);					
					bTotalExpCFY = bTotalExpCFY+Double.valueOf(strTotalExpCFY);					
					bTotalExp = bTotalExp+Double.valueOf(strTotalExp);				
					
					cellDataWO[0] = DomainConstants.EMPTY_STRING;
					cellDataWO[1] = DomainConstants.EMPTY_STRING;
					cellDataWO[2] = DomainConstants.EMPTY_STRING;;
					cellDataWO[3] = (String)mWorkOrderMap.get("WorkOrderName");					
					cellDataWO[4] = DomainConstants.EMPTY_STRING;	
					cellDataWO[5] = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strExpenditureUptoPrevFinancialYear));
					cellDataWO[6] = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strAllotmentCFY));
					cellDataWO[7] = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strExpenditurePrevMonthCFY));
					cellDataWO[8] = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strExpenditureThisMonthCFY));
					cellDataWO[9] = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strTotalExpCFY));
					cellDataWO[10] = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strTotalExp));
					cellDataWO[11] = (String)mWorkOrderMap.get("Units");
					cellDataWO[12] = (String)mWorkOrderMap.get("Remarks");					
					
					rowData = sheetData.createRow(iCountRow+k+1);
					for (int columnCount=0; columnCount < headerData.length; columnCount++) {
						Cell cellrow = rowData.createCell(columnCount);
						cellrow.setCellValue((String) cellDataWO[columnCount]);
					}
				}
						
				cellData[5] =  WMSUtil_mxJPO.converToIndianCurrency(context,bExpenditureUptoPrevFinancialYear);
				cellData[6] =  WMSUtil_mxJPO.converToIndianCurrency(context,bAllotmentCFY);
				cellData[7] =  WMSUtil_mxJPO.converToIndianCurrency(context,bExpenditurePrevMonthCFY);
				cellData[8] =  WMSUtil_mxJPO.converToIndianCurrency(context,bExpenditureThisMonthCFY);
				cellData[9] =  WMSUtil_mxJPO.converToIndianCurrency(context,bTotalExpCFY);
				cellData[10] = WMSUtil_mxJPO.converToIndianCurrency(context,bTotalExp);
				cellData[11] = DomainConstants.EMPTY_STRING;
				cellData[12] = DomainConstants.EMPTY_STRING;
				if(slWorkOrderList.size()==0){
					rowData = sheetData.createRow(iCountRow);
					for (int columnCount=0; columnCount < headerData.length; columnCount++) {
						Cell cellrow = rowData.createCell(columnCount);
						cellrow.setCellValue((String) cellData[columnCount]);
					}
				}else{
					rowData = sheetData.createRow(iCountRow);
					for (int columnCount=0; columnCount < headerData.length; columnCount++) {
						Cell cellrow = rowData.createCell(columnCount);
						cellrow.setCellValue((String) cellData[columnCount]);
					}
					
				}
				iCountRow = iCountRow+iWorkOrderSize+1;
				
			}
			String strFileName = "MER.xlsx";
			String strTempFolder = context.createWorkspace();
			outputStream = new FileOutputStream(new File(strTempFolder+"/"+strFileName));
			workbook.write(outputStream);
			
			
			/*StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			MapList mlMER = DomainObject.findObjects(context, TYPE_WMS_MER, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					DomainConstants.EMPTY_STRING, // where clause
					strListBusSelects); // object selects
			
			Map mTemp = null;
			for(int k=0;k<mlMER.size();k++){
				mTemp = (Map)mlMER.get(k);
				String strID = (String)mTemp.get(DomainObject.SELECT_ID);
				DomainObject doMER = new DomainObject(strID);
				ContextUtil.pushContext(context);
				doMER.deleteObject(context);
				ContextUtil.popContext(context);
			}*/
			String strMERName = DomainObject.getAutoGeneratedName(context, "type_WMSMER", DomainConstants.EMPTY_STRING);
			DomainObject domMER = DomainObject.newInstance(context);
			domMER.createObject(context, TYPE_WMS_MER, strMERName, "", POLICY_WMS_MER, "eService Production");
			domMER.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strTempFolder);
			strMERId = domMER.getId(context);
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return strMERId;
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getMonthlyMER(Context context, String[] args) throws Exception {
		MapList mlMERs = new MapList();
		try {
			String objectWhere = "attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value != '' && attribute["+ATTRIBUTE_WMS_MONTH+"].value != ''";
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MONTH+"].value");
			
			mlMERs = DomainObject.findObjects(context, TYPE_WMS_MER, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					objectWhere, // where clause
					strListBusSelects); // object selects
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		mlMERs.sort("originated", "descending", "date");
		return mlMERs;
	}
	
}
			
	
 