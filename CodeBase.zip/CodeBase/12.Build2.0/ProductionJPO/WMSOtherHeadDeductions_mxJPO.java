/** Name of the JPO    : WMSOtherHeadDeductions
 ** Developed by    : DSIS 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to create a Abstract Measurement Book Entry and its functionalities
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import com.matrixone.jdom.Element;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.domain.util.ContextUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
/**
 * The purpose of this JPO is to create a Abstract Measurement Book Entry and its functionalities
 * @author WMS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSOtherHeadDeductions_mxJPO extends WMSConstants_mxJPO
{
       
    /**
     * Constructor.
     * @param context - the eMatrix <code>Context</code> object
     * @param args - holds no arguments
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */

    public WMSOtherHeadDeductions_mxJPO(Context context, String[] args) throws Exception
    {
           super(context,args);
    }
    /** 
     * Method will connect default deductions to Abstract MBE
     * 
     * @param context the eMatrix <code>Context</code> object
     * @param args with program arguments
     *             args[0]- Abstract MBE ID
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418 //USED
     */
    public void connectHeadDeduction(Context context, String[] args) throws Exception {
        try {
            String strAbstractMBEOID = args[0];
            ArrayList<String>arrayListClonedTCIds = new ArrayList<String>();
			
			MapList mlDeductionList = new MapList();
            if(UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID))
            {
                StringList strListBusSelects = new StringList(DomainConstants.SELECT_NAME);
                strListBusSelects.add(DomainConstants.SELECT_ID);
                strListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
                strListBusSelects.add("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DEFAULT_VALUE+"]");
                DomainObject domAbstractMBE = DomainObject.newInstance(context,strAbstractMBEOID);
                MapList mapListObjects = DomainObject.findObjects(
                        context,
                        TYPE_WMS_OTER_HEAD_DEDUCTION,
                        DomainConstants.QUERY_WILDCARD,
                        DomainConstants.QUERY_WILDCARD,
                        DomainConstants.QUERY_WILDCARD,
                        DomainConstants.QUERY_WILDCARD,
                        "attribute["+ATTRIBUTE_WMS_IS_LIBRARY+"]==Yes",               // where expression
                        DomainConstants.EMPTY_STRING,
                        true,
                        strListBusSelects, // object selects
                        (short) 0);       // limit
                
                Map mapObj = new HashMap();
                String strObjId = "";
                String strParentDescription = "";
                String strParentDefaultValue = "";
                String strNewObject = "";
                for(int i=0;i<mapListObjects.size();i++)
                {
                    mapObj = (Map)mapListObjects.get(i);
                    if(mapObj != null && !mapObj.isEmpty())
                    {
						strObjId = (String)(String)mapObj.get(DomainConstants.SELECT_ID);
                        strParentDescription = (String)mapObj.get(DomainConstants.SELECT_DESCRIPTION);
                        strParentDefaultValue = (String)mapObj.get("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DEFAULT_VALUE+"]");
                        if(UIUtil.isNotNullAndNotEmpty(strObjId))
                        {
							strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
										"type_WMSOtherHeadDeduction",
										"",
										"policy_WMSOtherHeadDeduction",
										context.getVault().getName(),
										"-"
										);
										
										
							if(UIUtil.isNotNullAndNotEmpty(strNewObject)){
								DomainObject doNewBus = new DomainObject(strNewObject);
								if (strParentDescription != null && !"".equals(strParentDescription)) {
									doNewBus.setDescription(context,strParentDescription);
								}
								if (strParentDefaultValue != null && !"".equals(strParentDefaultValue)) {
									doNewBus.setAttributeValue(context,ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DEFAULT_VALUE,strParentDefaultValue);
								}
								arrayListClonedTCIds.add(strNewObject);
								
								Map mTemp = new HashMap();
								mTemp.put(DomainConstants.SELECT_ID,strNewObject);
								mTemp.put(DomainConstants.SELECT_DESCRIPTION,strParentDescription);
								mTemp.put("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DEFAULT_VALUE+"]",strParentDefaultValue);
								
								mlDeductionList.add(mTemp);
							}							
                        }
                    }
                }
				
				
				
                Map mRelIds = WMSUtil_mxJPO.connect(context, domAbstractMBE, RELATIONSHIP_WMS_ABSTRACT_MBE_HEAD_DEDUCTION, true, arrayListClonedTCIds);
                String strDefaultValue = "";
                String strDescription = "";
                String strRelId = "";
                Map mRelAttrMap = new HashMap();
                for(int j=0;j<mlDeductionList.size();j++)
                {
                    mapObj = (Map)mlDeductionList.get(j);
                    if(mapObj != null && !mapObj.isEmpty())
                    {
                        strObjId = (String)mapObj.get(DomainConstants.SELECT_ID);
                        strDescription = (String)mapObj.get(DomainConstants.SELECT_DESCRIPTION);
                        strDefaultValue = (String)mapObj.get("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DEFAULT_VALUE+"]");
                        strRelId = (String)mRelIds.get(strObjId);
                        mRelAttrMap.put(ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DESCRIPTION, strDescription);
                        
                        
                        if(UIUtil.isNotNullAndNotEmpty(strDefaultValue))
                        {
                            mRelAttrMap.put(ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_AMOUNT, strDefaultValue);
                        }
                        DomainRelationship.setAttributeValues(context, strRelId, mRelAttrMap);
                    }
                }
            }
        }
        catch(Exception exception)
        {
            System.out.println("exception   "+exception.getMessage());
            exception.printStackTrace();
            throw exception;            
        }
    }
    
    
    /**
     * Method to get the connected Tasks under the MBEs which are connected to Abtract MBE
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return mapListConnectedTasks MapList containing the Task IDs
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418 //USED
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getOtherHeadDeductions (Context context, String[] args) throws Exception 
    {
        try
        {
            MapList mapListOtherHeadDeductions = new MapList();
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainConstants.SELECT_ID);
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DESCRIPTION+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_PER_STATUS+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DEFAULT_VALUE+"]");
            strListBusSelects.add(DomainObject.SELECT_DESCRIPTION);
                        
            StringList strListRelSelects = new StringList();
            strListRelSelects.add(DomainRelationship.SELECT_ID);
            strListRelSelects.add("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_AMOUNT+"]");
            strListRelSelects.add("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DESCRIPTION+"]");
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
                DomainObject domObjAbstractMBE= DomainObject.newInstance(context, strObjectId);                
                mapListOtherHeadDeductions = domObjAbstractMBE.getRelatedObjects(context, // matrix context
                        RELATIONSHIP_WMS_ABSTRACT_MBE_HEAD_DEDUCTION, // relationship pattern
                        TYPE_WMS_OTER_HEAD_DEDUCTION, // type patternTYPE_WMS_OTER_HEAD_DEDUCTION
                        strListBusSelects, // object selects
                        strListRelSelects, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 0, // recursion level
                        DomainConstants.EMPTY_STRING, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);
            }
            return mapListOtherHeadDeductions;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }



  
    /**
     * It gives which row for percentage should be editable or not
     * 
     * @param context the eMatrix <code>Context</code> object 
     * @param args
     * @return Response values list
     * @throws Exception if operation fails
     * @author WMS
     * @since 418 //USED
     */
    
    public StringList makePercentageEditable(Context context, String[] args) throws Exception
    {
       StringList slReturnList   =    new StringList();
        try 
        {
            Map programMap              = (Map) JPO.unpackArgs(args);
            MapList objectList          = (MapList) programMap.get("objectList");
            
            int iObjectListSize         = objectList.size();
            Map dataMap                 = null;
            String strCalculationUsingPercentStatus = DomainConstants.EMPTY_STRING;
            for (int i = 0; i < iObjectListSize; i++) 
            {
                dataMap                = (Map) objectList.get(i);
                strCalculationUsingPercentStatus = (String) dataMap.get("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_PER_STATUS+"]");
                if("false".equalsIgnoreCase(strCalculationUsingPercentStatus))
                {
                    slReturnList.add("false");
                }
                else
                {
                    slReturnList.add("true");
                }
            }
        }
        catch (Exception e) {
           
            e.printStackTrace();
            throw e;
        }
        return slReturnList;
    }
    
 @com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public HashMap createBillOtherDeduction(Context context, String [] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Map paramMap = (Map) programMap.get("paramMap");
		String sObjectId=(String)paramMap.get("objectId");

		String sRowId = "" ;
		String strNewObject = "";

		HashMap columnsMap;
		HashMap changedRowMap;
		HashMap doc = new HashMap();
		HashMap retMap;
		DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
		DomainObject doAdvancObject = DomainObject.newInstance(context);

		Element elm = (Element) programMap.get("contextData");        
		MapList mlItems = new MapList();
		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		Map mapAttr = new HashMap();     

		for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
		{
			try
			{   
				retMap = new HashMap();
				changedRowMap = (HashMap) chgRowsMapList.get(i);
				columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");

				String strDescription = (String) columnsMap.get("Description");
				String strDefValue = (String) columnsMap.get("DefaultValue");
				String strRemark = (String) columnsMap.get("Remarks");

				strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
						"type_WMSOtherHeadDeduction",
						"",
						"policy_WMSOtherHeadDeduction",
						context.getVault().getName(),
						"-"
						);
				
				DomainRelationship domRel   = doAdvancObject.createAndConnect(context,
						TYPE_WMS_OTER_HEAD_DEDUCTION,
						strNewObject,
						"-",
					    POLICY_WMS_OTER_HEAD_DEDUCTION,
						null,
						RELATIONSHIP_WMS_ABSTRACT_MBE_HEAD_DEDUCTION,
						domAmbObject,
						true);

				mapAttr = new HashMap();
				if (strDescription != null && !"".equals(strDescription)) {
					mapAttr.put(ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DESCRIPTION, strDescription);
				}
				if (strDefValue != null && !"".equals(strDefValue)) {
					mapAttr.put(ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_AMOUNT, strDefValue);
				}
				if (strRemark != null && !"".equals(strRemark)) {
					mapAttr.put(ATTRIBUTE_WMS_HEAD_DEDUCTION_REMARKS, strRemark);
				}
				ContextUtil.pushContext(context);
				domRel.setAttributeValues(context,mapAttr);
				ContextUtil.popContext(context);
				retMap = new HashMap();
				retMap.put("oid", doAdvancObject.getObjectId(context));
				retMap.put("relid", domRel.toString());
				retMap.put("pid", "");
				retMap.put("rid", "");
				retMap.put("markup", "new");
				retMap.put("rowId", sRowId);
				columnsMap.putAll(retMap);
				retMap.put("columns", columnsMap);
				mlItems.add(retMap);
				doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
				doc.put("Action", "success"); // Here the action can be "Success" or "refresh"
			}
			catch(Exception Ex)
			{
				Ex.printStackTrace();
				throw Ex;
			}
		}
		return doc;
	}   
    
}