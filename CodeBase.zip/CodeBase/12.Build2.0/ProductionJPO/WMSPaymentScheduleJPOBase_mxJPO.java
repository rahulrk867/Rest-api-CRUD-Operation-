/*
 ** ${CLASS:WMSPaymentScheduleJPOBase}
 **
 */
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.matrixone.apps.common.Person;
import com.matrixone.apps.common.Route;
import com.matrixone.apps.common.util.ComponentsUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.program.Task;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringList;

/**
 * The <code>WMSPaymentScheduleJPOBase</code> class contains code for the "WMS Payment Schedule" functionality.
 *
 * @version EC 9.5.JCI.0 - Copyright (c) 2002, MatrixOne, Inc.
 */
  public class WMSPaymentScheduleJPOBase_mxJPO extends WMSConstants_mxJPO
  {
	 
	// public static final String RELATIONSHIP_WMS_PAYMENT_HEAD = PropertyUtil.getSchemaProperty(SYMBOLIC_relationship_WMSPaymentHead);
	// public static final String TYPE_WMS_PAYMENT_SCHEDULE = PropertyUtil.getSchemaProperty(SYMBOLIC_type_WMSPaymentSchedule);
	// public static final String RELATIONSHIP_WMS_PAYMENT_ITEM = PropertyUtil.getSchemaProperty(SYMBOLIC_relationship_WMSPaymentItem);
	// public static final String TYPE_WMS_PAYMENT_ITEM = PropertyUtil.getSchemaProperty(SYMBOLIC_type_WMSPaymentItem);
	 
	 public static final String RELATIONSHIP_WMS_PAYMENT_HEAD = PropertyUtil.getSchemaProperty("relationship_WMSPaymentHead");
	 public static final String TYPE_WMS_PAYMENT_SCHEDULE = PropertyUtil.getSchemaProperty("type_WMSPaymentSchedule");
	 public static final String RELATIONSHIP_WMS_PAYMENT_ITEM = PropertyUtil.getSchemaProperty("relationship_WMSPaymentItem");
	 public static final String TYPE_WMS_PAYMENT_ITEM = PropertyUtil.getSchemaProperty("type_WMSPaymentItem");
	 public static final String POLICY_WMS_PAYMENT_SCHEDULE = PropertyUtil.getSchemaProperty("policy_WMSPaymentSchedule");
	 public static final String ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE = PropertyUtil.getSchemaProperty("attribute_WMSPercentageOfWeightage");
	 public static final String ATTRIBUTE_IS_FROZEN_ITEM = PropertyUtil.getSchemaProperty("attribute_WMSCGRDCFrozenPaymentItem");
	 public static final String RELATIONSHIP_WORKORDER_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");
	 public static final String ATTRIBUTE_REDUCED_RATE = PropertyUtil.getSchemaProperty("attribute_WMSReducedSORRate");
	 
	 public static final String ATTRIBUTE_ITEM_ENTRY_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSMBEActivityQuantity");
	 public static final String ATTRIBUTE_ACTIVITY_ADJUSTED_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSEEAdgustedQuantity");
	 
	 public static final String ATTRIBUTE_ACTIVITY_TOTAL_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSTotalQuantity");
	 public static final String ATTRIBUTE_QUANTITY_PAID_TILL_DATE = PropertyUtil.getSchemaProperty("attribute_WMSQtyPaidTillDate");
	 public static final String RELATIONSHIP_MBE_TASKS = PropertyUtil.getSchemaProperty("relationship_WMSMBEActivities");
	 public static final String ATTRIBUTE_ACTIVITY_MBE_TOTAL_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSMBEQuantity");
	 public static final String ATTRIBUTE_WMS_PAYMENT_ITEM_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSPaymentItemAmount");
	 public static final String ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE = PropertyUtil.getSchemaProperty("attribute_WMSPercentageCompleteTillDate");
	 public static final String RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBEPaymentItems");
	 public static final String TYPE_WMS_WORK_ORDER = PropertyUtil.getSchemaProperty("type_WMSWorkOrder");
	 public static final String RELATIONSHIP_WORKORDER_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");
	 public static final String ATTRIBUTE_WMS_VALUE_OF_CONTRACT = PropertyUtil.getSchemaProperty("attribute_WMSValueOfContract");
	 public static final String ATTRIBUTE_WMSECVIBM_VALUE = PropertyUtil.getSchemaProperty("attribute_WMSECVIBM");
	 public static final String ATTRIBUTE_WMS_PAYMENT_SCHEDULE_SEQUENCE = PropertyUtil.getSchemaProperty("attribute_WMSPaymentScheduleSequence");
	 public static final String RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");
	 	 
	 public WMSPaymentScheduleJPOBase_mxJPO(Context context, String[] args) throws Exception {
	 
		 super(context,args);
	 } 
	 
	 
	 /**
     * This Method loads Work Order related Payment Schedule objects to table
     *
     * @param context
     * @param args contains a Map with the following entries:
     *    objectId - Work Order Object
     * @return MapList containing information of payment schedule
     * @throws Exception if the operation fails
     */
	 	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getRelatedPaymentSchedule(Context context, String[] args) throws Exception
    {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            // Parent Object Id
            String sObjectId = (String) programMap.get("objectId");
            DomainObject doWorkOrder = DomainObject.newInstance(context, sObjectId);
            // Get Root Payment Schedule Object 
            StringList slObjectSelects = new StringList(4);
            slObjectSelects.add(DomainConstants.SELECT_ID);
            slObjectSelects.add(DomainConstants.SELECT_CURRENT);
            slObjectSelects.add(DomainConstants.SELECT_TYPE);
            
            StringList slRelSelects = new StringList(1);
            slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
            MapList mlPaymentSchedule = doWorkOrder.getRelatedObjects(context,
                                                                        RELATIONSHIP_WMS_PAYMENT_HEAD,    // String relationshipPattern
                                                                        TYPE_WMS_PAYMENT_SCHEDULE,        // String typePattern
                                                                        slObjectSelects,                                        // StringList objectSelects
                                                                        slRelSelects,                                        // StringList relationshipSelects
                                                                        false,                                                  // boolean getTo
                                                                        true,                                                   // boolean getFrom
                                                                        (short) 1,                                              // short recurseToLevel
                                                                        "",                                                     // String objectWhere
                                                                        "",(short)0);                                                    // String relationshipWhere
            return mlPaymentSchedule;
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	/**
     * expand program to expand total payment schedule structure of a work order
     *
     * @param context
     * @param args holds map of changed row id date with keys
     *    0 - work order object
     * @ returns list will all levels of objects data
     * @throws Exception if the operation fails
     */
	 	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList expandPaymentScheduleStrucutre (Context context, String[] args) throws Exception
    {
		MapList mlPaymentStructure = new MapList();
		boolean isContextPushed = false;
        try {
			
			ContextUtil.pushContext(context);
			isContextPushed = true;
            Map programMap = (Map)JPO.unpackArgs(args);
            String sObjectId = (String) programMap.get("objectId");
            StringList slObjectSelects = new StringList(6);
            slObjectSelects.add(DomainConstants.SELECT_ID);
            slObjectSelects.add(DomainConstants.SELECT_CURRENT);
            slObjectSelects.add(DomainConstants.SELECT_TYPE);
            slObjectSelects.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
            StringList slRelSelects = new StringList(1);
            slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
            DomainObject doPaymentSchedule = DomainObject.newInstance(context, sObjectId);
            // expand all levels of payment schedule structure
            mlPaymentStructure = doPaymentSchedule.getRelatedObjects(context,
                                                                        RELATIONSHIP_WMS_PAYMENT_ITEM,// String relationshipPattern
                                                                        TYPE_WMS_PAYMENT_ITEM,        // String typePattern
                                                                        slObjectSelects,                                    // StringList objectSelects
                                                                        slRelSelects,                                       // StringList relationshipSelects
                                                                        false,                                              // boolean getTo
                                                                        true,                                               // boolean getFrom
                                                                        (short) 0,                                          // short recurseToLevel
                                                                        "",                                                 // String objectWhere
                                                                        "",(short) 0);                                                // String relationshipWhere
            
			
        }
        catch (Exception e) {
            throw e;
        }finally{
			if(isContextPushed){
				ContextUtil.popContext(context);
			}
		}
		return mlPaymentStructure;
			
    }
	
	/**
     * This method adds choosen number of payment items to the selected parent in payment schedule sructure
     *
     * @param context
     * @param args holds the following input arguments:
     *    0 - select parent objectId
     *
     * @return Map
     *     selected rowId
     *     new rowIds to add to parent
     *     message holds success or error
     */
    public Map<String,String> addPaymentItems (Context context, String[] args) throws Exception 
    {
        Map<String,String> mapObject = new HashMap<String, String>();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
            emxTableRowId = ProgramCentralUtil.parseTableRowId(context, emxTableRowId);
            // selected row object id
            String sParentOid = emxTableRowId[0];
            if(UIUtil.isNotNullAndNotEmpty(sParentOid))
            {
				String strUptoDatePercentage = DomainConstants.EMPTY_STRING;
				String strIsConnectedToAbsMBE = DomainConstants.EMPTY_STRING;
				String strIsParent = DomainConstants.EMPTY_STRING;
				DomainObject doParent = new DomainObject(sParentOid);
				StringList slObjectSelect = new StringList();
				slObjectSelect.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"].value");
				slObjectSelect.add("to["+RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS+"]");
				slObjectSelect.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
				Map mObjectInfo = null;
				mObjectInfo = (Map)doParent.getInfo(context,slObjectSelect);
				strUptoDatePercentage = (String)mObjectInfo.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"].value");
				strIsConnectedToAbsMBE = (String)mObjectInfo.get("to["+RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS+"]");
				strIsParent = (String)mObjectInfo.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
				if((UIUtil.isNotNullAndNotEmpty(strUptoDatePercentage) && Double.valueOf(strUptoDatePercentage) > 0) || (UIUtil.isNotNullAndNotEmpty(strIsConnectedToAbsMBE) && "true".equalsIgnoreCase(strIsConnectedToAbsMBE))){
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.PaymentItem.QuickAdd.Fail");
                    mapObject.put("selectedOID", sParentOid);
					mapObject.put("rows","");
                    mapObject.put("message",strMessage);
					return mapObject;					
				}
				
				
                String sPaymentItemOid = "";
                String sRelOID = "";
                String sPaymentItemName = "";
                Map objMap = null;
                DomainObject doPaymentItem = null;
                StringList slObjectSelects = new StringList ();
                slObjectSelects.add(DomainConstants.SELECT_NAME);
                slObjectSelects.add("relationship["+RELATIONSHIP_WMS_PAYMENT_ITEM+"].id");
                String sNumberOfPaymentItemsToAdd = (String)programMap.get("NumberOfPaymentItemsToAdd");
                int iNumberOfPaymentItemsToAdd = Integer.parseInt(sNumberOfPaymentItemsToAdd);
                // xml format to return to indented table
                StringBuffer strBuffer = new StringBuffer();
                strBuffer.append("<mxRoot>");
                strBuffer.append("<action><![CDATA[add]]></action>");

                for(int i=0;i<iNumberOfPaymentItemsToAdd;i++)
                {
                    // create payment item
					sPaymentItemOid = FrameworkUtil.autoName(context, "type_WMSPaymentItem", "policy_WMSPaymentItem");
                    // connect to parent item
                    DomainRelationship.connect(context, 
                                                sParentOid,                                         // fromObjectId
                                                RELATIONSHIP_WMS_PAYMENT_ITEM,// relationshipName
                                                sPaymentItemOid,                                    // toObjectId
                                                true);
                    doPaymentItem = DomainObject.newInstance(context, sPaymentItemOid);
                    objMap = doPaymentItem.getInfo(context, slObjectSelects);
                    sRelOID = (String) objMap.get("relationship["+RELATIONSHIP_WMS_PAYMENT_ITEM+"].id");
                    sPaymentItemName = (String) objMap.get(DomainConstants.SELECT_NAME);
                    doPaymentItem.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, sPaymentItemName);

                    strBuffer.append("<data status=\"committed\">");
                    strBuffer.append("<item oid=\""+sPaymentItemOid+"\" relId=\""+sRelOID+"\" pid=\""+sParentOid+"\"  direction=\"from\" />");
                    strBuffer.append("</data>");
                }
                String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", context.getLocale(), "emxProgramCentral.PaymentItem.QuickAdd");
                strBuffer.append("</mxRoot>");
                mapObject.put("selectedOID", sParentOid);
                mapObject.put("rows",strBuffer.toString());
                mapObject.put("message",strMessage);
            }
        }
        catch(Exception e)
        {
            mapObject.put("message","An Error Occured . Eror is "+e.getMessage());
        }
        return mapObject;
    }
	
	
	/**
     * This method called on Work Order Create Trigger Event
     * Auto creates Payment Schedule and connects to work order with rel payment head
     *
     * @param context
     * @param args holds the following input arguments:
     *    0 - objectId of the work order
     *
     * @throws Exception if the operation fails
     */
    public void createPaymentScheduleOnWorkOrder(Context context, String[] args) throws Exception
    {
		boolean bIsContextPushed = false;
        try {
            String sWorkOrderOid = args[0];
            String sAttribute = args[1];
            String sFormType = args[2];
			String sPaymentScheduleOid = FrameworkUtil.autoName(context, "type_WMSPaymentSchedule", "policy_WMSPaymentSchedule");
			// Update title with Payment Schedule Name
			DomainObject doPaymentSchedule = DomainObject.newInstance(context, sPaymentScheduleOid);
			String sPaymentScheduleNumber = doPaymentSchedule.getInfo(context, DomainConstants.SELECT_NAME);
			doPaymentSchedule.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, sPaymentScheduleNumber);
			doPaymentSchedule.setAttributeValue(context, ATTRIBUTE_WMS_PAYMENT_SCHEDULE_SEQUENCE, sPaymentScheduleNumber);
			// Conect Work Order to Payment Scedule
			DomainRelationship.connect(context, 
										sWorkOrderOid,                                          // fromObjectId
										RELATIONSHIP_WMS_PAYMENT_HEAD,    // relationshipName
										sPaymentScheduleOid,                                    // toObjectId
										true);
        }
        catch (Exception e) {
            throw new Exception("Failed to auto create payment schedule on work order:"+e.getMessage());
        }finally{
			//if(bIsContextPushed){
			//	ContextUtil.popContext(context);
			//}
		}
    }

	 /**
     * This Edit Function to allow edit access only for leaf node payment items in Payment schedule structure
     *
     * @param context
     * @param args contains a Map with the following entries:
     *    objectList - list of payment schedule and payment object ids
     *    objectId - work order object
     * @return StringList contain values true/false for each rows
     *     true - allow edit access
     *     true - block edit access
     * @throws Exception if the operation fails
     */
    public StringList isLeafNodePaymentItem(Context context, String[] args) throws Exception
    {
        try {
            StringList returnStringList = new StringList();
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap columnMap = (HashMap) programMap.get("columnMap");
            String strColumnName =  (String)columnMap.get("name");
            String sWorkOrderId = (String)requestMap.get("objectId");
            // get payment schedule structure details
            DomainObject doWorkOrder = DomainObject.newInstance(context,sWorkOrderId);
            StringList strListWOInfo = new StringList(3);
            strListWOInfo.add("project");
            strListWOInfo.add("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.current");
            strListWOInfo.add("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.id");
            Map<String,String> mapPaymentSchedule  = doWorkOrder.getInfo(context,strListWOInfo);
            String strCollabSpace = mapPaymentSchedule.get("project");
			String strPaymentScheduleOID = mapPaymentSchedule.get("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.id");
			String strPaymentScheduleState = mapPaymentSchedule.get("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.current");
            MapList routeMapList = getRoutes(context, strPaymentScheduleOID,strCollabSpace);
    		boolean booleanRoutePaused = false;
    		boolean booleanNoRoute = true;
    		//If Payment Schedule is new , there will be no routes
    		if(routeMapList!=null && routeMapList.size()==0)
    		{
    			booleanNoRoute = false;
    		}
    		//If Payment Schedule is promoted , and the route is rejected for a change 
    		else if(routeMapList!=null && routeMapList.size()>0)
    		{
    			MapList mapListStartedRoutes = WMSUtil_mxJPO.getSubMapList(routeMapList, ("attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"].value"), "Stopped");
    			if(mapListStartedRoutes.size()>0)
    			{
    				booleanRoutePaused =  true;
    			}
    		}
            Map<String,String> objMap;
            boolean allowEdit;
            Iterator<Map<String,String>> iterator = objectList.iterator();
            while(iterator.hasNext()) {
                allowEdit = false;
                objMap =iterator.next();
                String sPaymentStructureObjType = objMap.get(DomainConstants.SELECT_TYPE);
                String hasChildItem =  objMap.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
                if (TYPE_WMS_PAYMENT_ITEM.equals(sPaymentStructureObjType))
                {
                	//if Route size is zero , for first time
                	if(booleanNoRoute)
                	{
                		allowEdit = true;
                	}
                    if ("true".equalsIgnoreCase(hasChildItem)) // has child block edit access
                    {
                        allowEdit = false;
                    }
                    else // leaf node allow edit access
                    {
                    	objMap.put("PaymentScheduleState", strPaymentScheduleState);
                    	
                    	allowEdit = true;
                    	if("WMSReducedSORRate".equals(strColumnName))
                    	{
                    		allowEdit = getRateColumnEditAccess(strColumnName, objMap, booleanRoutePaused);
                    	}
                    	else if("Weightage".equals(strColumnName))
                    	{
                    		allowEdit = getWeightageColumnEditAccess(strColumnName, objMap, booleanRoutePaused);
                    	}
                    }
                }
                returnStringList.add(String.valueOf(allowEdit));
            }
            return returnStringList;
        }
        catch (Exception e) {
            throw e;
        }
	}
	
	private MapList getRoutes(Context context, String strPaymentScheduleOID,String strCollabSpace)
			throws FrameworkException, Exception {
		try
		{
			MapList routeMapList= new MapList();
			if("CGRDCCS".equals(strCollabSpace))
			{

				DomainObject domObjPaymentSchedule = DomainObject.newInstance(context,strPaymentScheduleOID);
				routeMapList = WMSUtil_mxJPO.checkForExistingRouteObject(context,domObjPaymentSchedule,DomainConstants.EMPTY_STRING);
				
			}
			return routeMapList;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	
	/**
     * This method gets % payment of weightage against each leaf node item in payment schedule structure
     *
     * @param context
     * @param args contains a Map with the following entries:
     *    objectList - list of payment items object data
     *
     * @return Vector contain column values for each row
     *
     * @throws Exception if the operation fails
     */
    public Vector getPercentageOfWeightage(Context context, String[] args) throws Exception 
    {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
            Map objMap = null;
            StringList slObjectSelects = new StringList();
            slObjectSelects.add(DomainConstants.SELECT_TYPE);
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
            slObjectSelects.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
            for (int i=0; i<intSize; i++)
            {
                objMap = (Map) objectList.get(i);
                String sObjectId = (String) objMap.get(DomainConstants.SELECT_ID);
                DomainObject doPaymentItem = DomainObject.newInstance(context, sObjectId);
                objMap = doPaymentItem.getInfo(context, slObjectSelects);
                if (TYPE_WMS_PAYMENT_SCHEDULE.equals((String) objMap.get(DomainConstants.SELECT_TYPE))) // if not payment item, show nothing
                {
                    vColumnValues.add("");
                }
                else
                {
                    if ("false".equalsIgnoreCase((String) objMap.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]"))) // if leaf node item show % payment of weightage
                    {
                        vColumnValues.add((String) objMap.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]"));;
                    }
                    else // has child items, show nothing
                    {
                        vColumnValues.add("");
                    }
                }
            }
            return vColumnValues;
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	/**
     * update function
     * updates percent % payment of weightage on leaf node payment item
     *
     * @param context
     * @param args holds map of changed row id date with keys
     *    objectId - Payment Item object
     *    New Value - % payment of weightage New value
     *
     * @throws Exception if the operation fails
     */
    public void updatePercentageOfWeightage (Context context, String[] args) throws Exception 
    {
        try {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            HashMap paramMap = (HashMap)programMap.get("paramMap");
            String sPaymentOid = (String)paramMap.get("objectId");
			String sPercentageOfWeightageOld = (String)paramMap.get("Old Value");
            String sPercentageOfWeightage = (String)paramMap.get("New Value");
            DomainObject doPaymentItem = DomainObject.newInstance(context, sPaymentOid);
			String strPercentageCompletedUptoDate = (String) doPaymentItem.getAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE);
			String strOldWeightage = (String) doPaymentItem.getAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE);
			if(Double.valueOf(strPercentageCompletedUptoDate)>Double.valueOf(sPercentageOfWeightage)){
				String strAlertMessage = "New weightage can not be less than "+strPercentageCompletedUptoDate+"%.";
				emxContextUtil_mxJPO.mqlNotice(context, strAlertMessage);
				doPaymentItem.setAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE, strOldWeightage);
			}else{
			   doPaymentItem.setAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE, sPercentageOfWeightage);
			}
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	private boolean getRateColumnEditAccess(String strColumnName, Map objMap, boolean booleanRoutePaused) {
		boolean allowEdit=false;
		String strFrozanItem = (String)objMap.get("attribute["+ATTRIBUTE_IS_FROZEN_ITEM+"].value");
		
		boolean bFrozenItem = Boolean.valueOf(strFrozanItem);
			//If Payment Item is Frozen and State is create , route is paused then edit access 
			if(bFrozenItem)
			{
				allowEdit = false;
			}
			//for new Rows created after route is created and Route is paused state no edit
			else 
			{
				if(booleanRoutePaused)
				{
					allowEdit = true;
				}
				else
				{
					allowEdit = false;
				}
			}
		return allowEdit;
	}
	
	private boolean getWeightageColumnEditAccess(String strColumnName, Map objMap, boolean booleanRoutePaused) {
		boolean allowEdit=false;
		//String strFrozanItem = (String)objMap.get("attribute["+ATTRIBUTE_IS_FROZEN_ITEM+"].value");
		String strPaumentScheduleState = (String)objMap.get("PaymentScheduleState");
		//boolean bFrozenItem = Boolean.valueOf(strFrozanItem);
			//If Payment Item is Frozen and State is create , route is paused then edit access 
			//if(bFrozenItem)
			//{
				//if("Create".equals(strPaumentScheduleState)&&booleanRoutePaused)
				if("Create".equals(strPaumentScheduleState))
				{
					allowEdit = true;
				}
				else
				{
					allowEdit = false;
				}
			//}
			//for new Rows created after route is created and Route is paused state no edit
			//else 
			//{
			//	if(booleanRoutePaused)
			//	{
			//		allowEdit = false;
			//	}
			//	else
			//	{
			//		allowEdit = true;
			//	}
			//}
		return allowEdit;
	}
	
	 /**
     * This method called on Payment Schedule Promote Trigger Event from Create to Submit
     * The total of % payment of weightage should be 100%
     *
     * @param context
     * @param args holds the following input arguments:
     *    0 - objectId of the work order
     * @return int 0 or 1
     *     0 - Allows promote
     *     1 - Blocks promote
     *
     * @throws Exception if the operation fails
     */
    public int checkTotalPercentOfWeightage(Context context, String[] args) throws Exception
    {
        try {
            int iReturn = 0;
            String sObjectId = args[0];
			//${CLASS:WMSMeasurementBookItem} jpoObj = new ${CLASS:WMSMeasurementBookItem}(context, args);            
            //boolean bCGRDC = jpoObj.checkContextUserDepartment(context, "CGRDC");
            StringList slObjectSelects = new StringList(2);
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
            slObjectSelects.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
            StringList slRelSelects = null;
            DomainObject doPaymentSchedule = DomainObject.newInstance(context, sObjectId);
            // get payment item details
            MapList mlPaymentItems = doPaymentSchedule.getRelatedObjects(context,
                                                                        RELATIONSHIP_WMS_PAYMENT_ITEM,// String relationshipPattern
                                                                        TYPE_WMS_PAYMENT_ITEM,        // String typePattern
                                                                        slObjectSelects,                                    // StringList objectSelects
                                                                        slRelSelects,                                       // StringList relationshipSelects
                                                                        false,                                              // boolean getTo
                                                                        true,                                               // boolean getFrom
                                                                        (short) 0,                                          // short recurseToLevel
                                                                        "",                                                 // String objectWhere
                                                                        "");                                                // String relationshipWhere
           
			Map objMap = null;
			String hasChildNode = "";
            String sPercentOfWeightage = "";
            double dPercentOfWeightage;
            double dTotalPercentOfWeightage = 0.0;
            if (mlPaymentItems.size() > 0) {
                // sum % payment of weightage
                for (int i=0,j=mlPaymentItems.size();i<j;i++)
                {
                    objMap = (Map)mlPaymentItems.get(i);
					hasChildNode = (String) objMap.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
					if ("true".equalsIgnoreCase(hasChildNode)) {
						continue;
					}
                    sPercentOfWeightage = (String)objMap.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
                    dPercentOfWeightage = Double.parseDouble(sPercentOfWeightage);
                    dTotalPercentOfWeightage = dTotalPercentOfWeightage + dPercentOfWeightage;
                }
                String strfinalPercentOfWeightageValue = Double.toString(dTotalPercentOfWeightage);
                String[] valArray = strfinalPercentOfWeightageValue.split("\\.");
        		String valuesAfterDecimal = valArray[1];
        		String strLastDigitValue = DomainConstants.EMPTY_STRING;
        		if(valuesAfterDecimal.length()>2)
        		{
        			strLastDigitValue = Character.toString(valuesAfterDecimal.charAt(2));
        			if(Integer.parseInt(strLastDigitValue)>=5)
        			{
                dTotalPercentOfWeightage = new BigDecimal(dTotalPercentOfWeightage).setScale(2, BigDecimal.ROUND_UP).doubleValue();
        			}
        		}
                //if ((bCGRDC && dTotalPercentOfWeightage < 100)||(!bCGRDC && dTotalPercentOfWeightage != 100)) // check total % payment of weightage is 100 or not
                if ((dTotalPercentOfWeightage < 100)||(dTotalPercentOfWeightage != 100)) // check total % payment of weightage is 100 or not
                {
                    iReturn = 1;
                    String strAlertMessage = "Total weightage is not 100";//EnoviaResourceBundle.getProperty(context, "emxProgramCentralStringResource", context.getLocale(), "emxProgramCentral.Alert.TotalPercentOfWeightage");
                    emxContextUtil_mxJPO.mqlNotice(context, strAlertMessage + " "+dTotalPercentOfWeightage);
                }
            }
            else { // no Payment items, block promote
                iReturn = 1;
                String strAlertMessage = "No payment items available";//EnoviaResourceBundle.getProperty(context, "emxProgramCentralStringResource", context.getLocale(), "emxProgramCentral.Alert.NoPaymentItems");
                emxContextUtil_mxJPO.mqlNotice(context, strAlertMessage);
            }
            return iReturn;
        }
        catch (Exception e)
        {
            throw e;
        }
    }
	
	/**
     * Check if the context user is from the department 
     *
     * @param context the eMatrix <code>Context</code> object
     * @param strDepartment String value containing the department name
     * @returns boolean value
     * @throws Exception if the operation fails
     * @author WMS
     * @since 417
     */
    public static boolean checkContextUserDepartment(Context context, String strDepartment) throws Exception {
    	boolean booleanNRDADepartment = false;
    	try
    	{
    		MapList mapListDepartment = WMSUtil_mxJPO.getContextUserDepartment(context);
    		Iterator<Map<String,String>> iterator = mapListDepartment.iterator();
    		Map<String,String> mapData;
    		while(iterator.hasNext())
    		{
    			mapData = iterator.next();
    			String strDepartmentName = mapData.get(DomainConstants.SELECT_NAME);
    			if(strDepartment.equals(strDepartmentName))
    			{
    				booleanNRDADepartment = true;
    				break;
    			}
    		}
    	}
    	catch(Exception  exception)
    	{
    		exception.printStackTrace();
    		throw exception;
    	}
    	return booleanNRDADepartment;
    }
	
	 /**
     * promote check trigger event on moving work order to Active
     * Payment schedule should be approved to active work order
     *
     * @param context
     * @param args holds map of changed row id date with keys
     *    0 - work order object
     *    1 - work order type
     *
     * @throws Exception if the operation fails
     */
    public int checkPaymentSchedueApproved (Context context, String[] args) throws Exception 
    {
        try {
            int iResult = 0;
            String sObjectId = args[0];
            String sType = args[1];
            if (sType.equals("WMSWorkOrder")) // check for work order object only
            {
                DomainObject doWorkOrder = DomainObject.newInstance(context, sObjectId);
				//Add and Modified by Ravi:02Spet-2018
                String sContractType = doWorkOrder.getAttributeValue(context, ATTRIBUTE_WMS_TYPE_OF_CONTRACT); 
                String sDepartment = doWorkOrder.getAttributeValue(context, ATTRIBUTE_WMSDEPARTMENT); 
				if("Equipment".equals(sDepartment)){
					return iResult;
				}
                if ("EPC".equals(sContractType)) // check for EPC  Type of Contract
                {
                    StringList slObjectSelects = null;
                    StringList slRelSelects = null;
                    // get related payment schedule not approved
                    MapList mlPaymentSchedule = doWorkOrder.getRelatedObjects(context,
                                                                                RELATIONSHIP_WMS_PAYMENT_HEAD,// String relationshipPattern
                                                                                TYPE_WMS_PAYMENT_SCHEDULE,    // String typePattern
                                                                                slObjectSelects,                                    // StringList objectSelects
                                                                                slRelSelects,                                       // StringList relationshipSelects
                                                                                false,                                              // boolean getTo
                                                                                true,                                               // boolean getFrom
                                                                                (short) 1,                                          // short recurseToLevel
                                                                                "current != Approved",                              // String objectWhere
                                                                                "");                                                // String relationshipWhere
                    if (mlPaymentSchedule.size() > 0) // block if payment schedule not approved
                    {
                        iResult = 1;
                        String strAlertMessage = EnoviaResourceBundle.getProperty(context, "wmsStringResource", context.getLocale(), "WMS.Alert.WorkOrder.PaymentScheduleNotApproved");
                        emxContextUtil_mxJPO.mqlNotice(context, strAlertMessage);
                    }
            }
            }
            return iResult;
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	 public String checkTotalPercentOfWeightageOnApproval(Context context, String[] args) throws Exception
    {
        try {
			 DecimalFormat df = new DecimalFormat ( "#.##" ) ;
            String strReturn = "Success";
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sObjectId = (String) programMap.get("objectId");
            StringList slObjectSelects = new StringList(2);
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
            slObjectSelects.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
            StringList slRelSelects = null;
            DomainObject doPaymentSchedule = DomainObject.newInstance(context, sObjectId);
            // get payment item details
            MapList mlPaymentItems = doPaymentSchedule.getRelatedObjects(context,
                                                                        RELATIONSHIP_WMS_PAYMENT_ITEM,// String relationshipPattern
                                                                        TYPE_WMS_PAYMENT_ITEM,        // String typePattern
                                                                        slObjectSelects,                                    // StringList objectSelects
                                                                        slRelSelects,                                       // StringList relationshipSelects
                                                                        false,                                              // boolean getTo
                                                                        true,                                               // boolean getFrom
                                                                        (short) 0,                                          // short recurseToLevel
                                                                        "",                                                 // String objectWhere
                                                                        "");                                                // String relationshipWhere
           
			Map objMap = null;
			String hasChildNode = "";
            String sPercentOfWeightage = "";
            double dPercentOfWeightage;
            double dTotalPercentOfWeightage = 0.0;
            if (mlPaymentItems.size() > 0) {
                // sum % payment of weightage
                for (int i=0,j=mlPaymentItems.size();i<j;i++)
                {
                    objMap = (Map)mlPaymentItems.get(i);
					hasChildNode = (String) objMap.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
					if ("true".equalsIgnoreCase(hasChildNode)) {
						continue;
					}
                    sPercentOfWeightage = (String)objMap.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
                    dPercentOfWeightage = Double.parseDouble(sPercentOfWeightage);
                    dTotalPercentOfWeightage = dTotalPercentOfWeightage + dPercentOfWeightage;
                }
                String strfinalPercentOfWeightageValue = Double.toString(dTotalPercentOfWeightage);
                String[] valArray = strfinalPercentOfWeightageValue.split("\\.");
        		String valuesAfterDecimal = valArray[1];
        		String strLastDigitValue = DomainConstants.EMPTY_STRING;
        		if(valuesAfterDecimal.length()>2)
        		{
        			//strLastDigitValue = Character.toString(valuesAfterDecimal.charAt(2));
        			//if(Integer.parseInt(strLastDigitValue)>=5)
        			//{
						//dTotalPercentOfWeightage = new BigDecimal(dTotalPercentOfWeightage).setScale(2, BigDecimal.ROUND_UP).doubleValue();
						dTotalPercentOfWeightage = Double.valueOf(df.format(dTotalPercentOfWeightage));
						 
        			//}
        		}
                //if ((bCGRDC && dTotalPercentOfWeightage < 100)||(!bCGRDC && dTotalPercentOfWeightage != 100)) // check total % payment of weightage is 100 or not
                if ((dTotalPercentOfWeightage < 100)||(dTotalPercentOfWeightage != 100)) // check total % payment of weightage is 100 or not
                {
                    strReturn = "Failure";
                    String strAlertMessage = "Total weightage is not 100";//EnoviaResourceBundle.getProperty(context, "emxProgramCentralStringResource", context.getLocale(), "emxProgramCentral.Alert.TotalPercentOfWeightage");
                    emxContextUtil_mxJPO.mqlNotice(context, strAlertMessage + " "+dTotalPercentOfWeightage);
                }
            }
            else { // no Payment items, block promote
                strReturn = "Failure";
                String strAlertMessage = "No payment items available";//EnoviaResourceBundle.getProperty(context, "emxProgramCentralStringResource", context.getLocale(), "emxProgramCentral.Alert.NoPaymentItems");
                emxContextUtil_mxJPO.mqlNotice(context, strAlertMessage);
            }
            return strReturn;
        }
        catch (Exception e)
        {
            throw e;
        }
    }

	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getPaidPaymentScheduleItems (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListConnectedPaymentItems = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
				mapListConnectedPaymentItems = getPaidPaymentScheduleItems(context, domObjMBE);
			}
			return mapListConnectedPaymentItems;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	
	/**
	 * Function to get the Tasks connected to the selected MBE
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjMBE DomainObject instance of selected Work Order 
	 * @return mapListTasks MapList containing the MBEs connected to Work Order with ID
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	public static MapList getPaidPaymentScheduleItems(Context context, DomainObject domObjMBE)
			throws FrameworkException {
		try
		{
		SelectList selListBusSelects     = new SelectList(7);
		selListBusSelects.add(DomainConstants.SELECT_ID);
		selListBusSelects.add(DomainConstants.SELECT_TYPE);
		selListBusSelects.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
		selListBusSelects.add("attribute["+ATTRIBUTE_ACTIVITY_TOTAL_QUANTITY+"].value");
		selListBusSelects.add("attribute["+ATTRIBUTE_ACTIVITY_MBE_TOTAL_QUANTITY+"].value");
		selListBusSelects.add("attribute["+ATTRIBUTE_REDUCED_RATE+"].value");
		selListBusSelects.add("attribute["+ATTRIBUTE_QUANTITY_PAID_TILL_DATE+"].value");
		SelectList selListRelSelects     = new SelectList(4);
		selListRelSelects.add(DomainRelationship.SELECT_ID);
		selListRelSelects.add("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"].value");
		selListRelSelects.add("attribute["+ATTRIBUTE_ITEM_ENTRY_QUANTITY+"].value");
		selListRelSelects.add("attribute["+ATTRIBUTE_ACTIVITY_ADJUSTED_QUANTITY+"].value"); 
		MapList mapListPaidPaymentScheduleItems = domObjMBE.getRelatedObjects(context, // matrix context
				RELATIONSHIP_MBE_TASKS, // relationship pattern
				TYPE_WMS_PAYMENT_ITEM, // type pattern
				selListBusSelects, // object selects
				selListRelSelects, // relationship selects
				false, // to direction
				true, // from direction
				(short) 1, // recursion level
				DomainConstants.EMPTY_STRING, // object where clause
				DomainConstants.EMPTY_STRING, // relationship where clause
				0);
		return mapListPaidPaymentScheduleItems;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
  }

  /**
     * program to get Payment Schedule structure to add to MBE
     * Block selection for Payment Schedule Item, as Payment Schedule dont related to Abstract MBE
     *
     * @param context
     * @param args holds map of changed row id date with keys
     *    0 - work order object
     * @ returns list of Payment Schedule Object
     * @throws Exception if the operation fails
     */
	 	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getPaymentScheduleStructureToAddItemsToMBE (Context context, String[] args) throws Exception
    {
    	try {
    		Map programMap = (Map) JPO.unpackArgs(args);
    		// Parent Object Id
    		String sObjectId = (String) programMap.get("objectId");
    		MapList mlPaymentSchedule = new MapList();
    		if(UIUtil.isNotNullAndNotEmpty(sObjectId))
    		{
    			DomainObject doAbstractMBE = DomainObject.newInstance(context, sObjectId);
    			// get work Order for Abstract MBE
    			String sWorkOrderId = doAbstractMBE.getInfo(context, "to["+RELATIONSHIP_WORKORDER_MBE+"].from.id");
    			if(UIUtil.isNotNullAndNotEmpty(sWorkOrderId))
    			{
    				DomainObject doWorkOrder = DomainObject.newInstance(context, sWorkOrderId);
    				// Get Root Payment Schedule Object 
    				StringList slObjectSelects = new StringList(1);
    				slObjectSelects.add(DomainConstants.SELECT_ID);
    				StringList slRelSelects = new StringList(1);
    				slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
    				mlPaymentSchedule = doWorkOrder.getRelatedObjects(context,
    						RELATIONSHIP_WMS_PAYMENT_HEAD,    // String relationshipPattern
    						TYPE_WMS_PAYMENT_SCHEDULE,        // String typePattern
    						slObjectSelects,                                        // StringList objectSelects
    						slRelSelects,                                           // StringList relationshipSelects
    						false,                                                  // boolean getTo
    						true,                                                   // boolean getFrom
    						(short) 1,                                              // short recurseToLevel
    						DomainConstants.EMPTY_STRING,                                                     // String objectWhere
    						DomainConstants.EMPTY_STRING,
    						0);                                                    // String relationshipWhere
    				Map objMap = null;
    				for (int i=0,j=mlPaymentSchedule.size(); i<j; i++)
    				{
    					objMap = (Map) mlPaymentSchedule.get(i);
    					objMap.put("disableSelection", "true");
    				}
    			}
    		}
    		return mlPaymentSchedule;
    	}
    	catch (Exception e) {
    		throw e;
    	}
    }
  
  /**
     * expand program to expand total payment schedule structure  to add to  MBE
     * Allow selection only for leaf node payment items and not connected to  MBE
     *
     * @param context
     * @param args holds map of changed row id date with keys
     *    0 - work order object
     * @ returns list will all levels of objects data
     * @throws Exception if the operation fails
     */
	 	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList expandPaymentScheduleStrucutreToAddItemsToMBE (Context context, String[] args) throws Exception
    {
        try {
            Map programMap = (Map)JPO.unpackArgs(args);
            String sParentOid = (String) programMap.get("parentOID");
            HashMap hmInput = new HashMap();
            hmInput.put("objectId", sParentOid);
            StringList slExcludeSelection = excludeConectedPaymentItemsFromMB (context, JPO.packArgs(hmInput));
            String sObjectId = (String) programMap.get("objectId");
            StringList slObjectSelects = new StringList(1);
            slObjectSelects.add(DomainConstants.SELECT_ID);
            slObjectSelects.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
            StringList slRelSelects = new StringList(1);
            slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			
            DomainObject doPaymentSchedule = DomainObject.newInstance(context, sObjectId);
            // expand all levels of payment schedule structure
            MapList mlPaymentStructure = doPaymentSchedule.getRelatedObjects(context,
                                                                        RELATIONSHIP_WMS_PAYMENT_ITEM,// String relationshipPattern
                                                                        TYPE_WMS_PAYMENT_ITEM,        // String typePattern
                                                                        slObjectSelects,                                    // StringList objectSelects
                                                                        slRelSelects,                                       // StringList relationshipSelects
                                                                        false,                                              // boolean getTo
                                                                        true,                                               // boolean getFrom
                                                                        (short) 0,                                          // short recurseToLevel
                                                                        "",                                                 // String objectWhere
                                                                        "");                                                // String relationshipWhere
            Map objMap = null;
            for (int i=0,j=mlPaymentStructure.size(); i<j; i++)
            {
                objMap = (Map) mlPaymentStructure.get(i);
                // Block Selection for Parent Items and Already connected Items
                if (slExcludeSelection.contains((String) objMap.get(DomainConstants.SELECT_ID)) || "True".equalsIgnoreCase((String) objMap.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]"))) {
                    objMap.put("disableSelection", "true");
                }
            }
            return mlPaymentStructure;
        }
        catch (Exception e) {
            throw e;
        }
    }
  
  /**
     * Exclude oid program
     * exclude payment item oids already releated to  MBE
     *
     * @param context
     * @param args contains a Map with the following entries:
     *    objectId - Abstract MBE Object
     * @return StringList containing information of payment items to not show for connection
     * @throws Exception if the operation fails
     */
    public StringList excludeConectedPaymentItemsFromMB (Context context, String[] args) throws Exception 
    {
        try {
            StringList slExcludePaymentItemsOid = new StringList();
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sObjectId = (String) programMap.get("objectId");
            StringList slObjectSelects = new StringList();
            slObjectSelects.add(DomainConstants.SELECT_ID);
            StringList slRelSelects = null;
            DomainObject doAbstractMeasurementBookEntry = DomainObject.newInstance(context, sObjectId);
            // get payment item oids related to Abstract MBE
            MapList mlPaymentItems = doAbstractMeasurementBookEntry.getRelatedObjects(context,
                                                                                        RELATIONSHIP_MBE_TASKS,  // String relationshipPattern
                                                                                        TYPE_WMS_PAYMENT_ITEM,                        // String typePattern
                                                                                        slObjectSelects,                                                    // StringList objectSelects
                                                                                        slRelSelects,                                                       // StringList relationshipSelects
                                                                                        false,                                                              // boolean getTo
                                                                                        true,                                                               // boolean getFrom
                                                                                        (short) 0,                                                          // short recurseToLevel
                                                                                        "",                                                                 // String objectWhere
                                                                                        "");                                                                // String relationshipWhere
            Map objMap = null;
            for (int i=0, j=mlPaymentItems.size(); i<j; i++)
            {
                objMap = (Map) mlPaymentItems.get(i);
                // add to exclude list
                slExcludePaymentItemsOid.add((String) objMap.get(DomainConstants.SELECT_ID));
            }
            return slExcludePaymentItemsOid;
        }
        catch (Exception e) {
            throw e;
        }
    }
  
  /**
 * This Edit Function to allow edit access only for MBE column in the MBE Payment Items
 *
 * @param context
 * @param args contains a Map with the following entries:
 *    objectList - list of payment schedule and payment object ids
 *    objectId - work order object
 * @return StringList contain values true/false for each rows
 *     true - allow edit access
 *     true - block edit access
 * @throws Exception if the operation fails
 */
public StringList setEditableForPaymentItems(Context context, String[] args) throws Exception
{
    try {
        StringList returnStringList = new StringList();
        Map programMap = (Map) JPO.unpackArgs(args);
        MapList objectList = (MapList) programMap.get("objectList");
        Iterator<Map<String,String>> iterator = objectList.iterator();
        Map<String,String> mapData ;
        while(iterator.hasNext())
        {
        	mapData = iterator.next();
        	String strType = mapData.get(DomainConstants.SELECT_TYPE);
        	if(UIUtil.isNotNullAndNotEmpty(strType))
        	{
        		if(TYPE_WMS_PAYMENT_ITEM.equals(strType))
        		{
        			returnStringList.add(String.valueOf(true));
        		}
        		else
        		{
        			returnStringList.add(String.valueOf(false));
        		}
        	}
        	else
        	{
        		returnStringList.add(String.valueOf(false));
        	}
        }
        return returnStringList;
    }
	catch (Exception exception) 
	{
		exception.printStackTrace();
		throw exception;
	}
}
  
    
   /**
     * expand program to expand total payment schedule structure  for Abstract MBE related Payment Items
     * Allow selection and edit only for Abstract MBE related Payment Items
     *
     * @param context
     * @param args contains a Map with the following entries:
     *    parentOID - Abstarct MBE Object id
     *    objectId - Object to expand
     * @ returns list with objects data
     * @throws Exception if the operation fails
     */
	 	 	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList expandAbstractMBERelatedPaymentItems (Context context, String[] args) throws Exception
    {
		MapList mlAbstractMBERelatedPaymentItems = new MapList();
		boolean isContextPushed = false;
        try {
			
			ContextUtil.pushContext(context);
			isContextPushed = true;
			
            Map programMap = (Map)JPO.unpackArgs(args);
            String sParentOid = (String) programMap.get("parentId");
			// Get Abstarct MBE related Payment Items along with their all level Parent Objects data
			Map mAbstractMBERelatedPaymentItemsStructure = getAbstractMBEPaymentItemsStructure (context, sParentOid);
			StringList slIncludePaymentScheduleStructure = (StringList) mAbstractMBERelatedPaymentItemsStructure.get("IncludeInPaymentScheduleStructure");
            String sObjectId = (String) programMap.get("objectId");
            StringList slObjectSelects = new StringList(1);
            slObjectSelects.add(DomainConstants.SELECT_ID);
            slObjectSelects.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
            StringList slRelSelects = new StringList(1);
            slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
            DomainObject doPaymentSchedule = DomainObject.newInstance(context, sObjectId);
            // expand all levels of payment schedule structure
            MapList mlPaymentStructure = doPaymentSchedule.getRelatedObjects(context,
                                                                        RELATIONSHIP_WMS_PAYMENT_ITEM,// String relationshipPattern
                                                                        TYPE_WMS_PAYMENT_ITEM,        // String typePattern
                                                                        slObjectSelects,                                    // StringList objectSelects
                                                                        slRelSelects,                                       // StringList relationshipSelects
                                                                        false,                                              // boolean getTo
                                                                        true,                                               // boolean getFrom
                                                                        (short) 0,                                          // short recurseToLevel
                                                                        "",                                                 // String objectWhere
                                                                        "");                                                // String relationshipWhere
            Map objMap = null;
            for (int i=0,j=mlPaymentStructure.size(); i<j; i++)
            {
                objMap = (Map) mlPaymentStructure.get(i);
				if (mAbstractMBERelatedPaymentItemsStructure.get((String) objMap.get(DomainConstants.SELECT_ID)) != null) {
					String sLevel = (String) objMap.get("level");
					objMap = (Map) mAbstractMBERelatedPaymentItemsStructure.get((String) objMap.get(DomainConstants.SELECT_ID));
					objMap.put("level", sLevel);
					objMap.put("Abstract MBE Payment Item", "True");
				}
                // Block Selection for Parent Items and Already connected Items
                if (slIncludePaymentScheduleStructure.contains((String) objMap.get(DomainConstants.SELECT_ID))) {
					if ("True".equalsIgnoreCase((String) objMap.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]"))) {
						objMap.put("disableSelection", "true");
						objMap.put("RowEditable", "readonly");
					}
					mlAbstractMBERelatedPaymentItems.add(objMap);					
                }
            }
            
        }
        catch (Exception e) {
            throw e;
        }finally{
			if(isContextPushed){
				ContextUtil.pushContext(context);
			}
		}
		return mlAbstractMBERelatedPaymentItems;
    }
  	 	@com.matrixone.apps.framework.ui.ProgramCallable
  public MapList getAbstractMBEPaymentItems (Context context, String[] args) throws Exception
    {
		MapList mlPaymentItems = new MapList();
		boolean isContextPushed = false;
        try {
			ContextUtil.pushContext(context);
			isContextPushed = true;
            Map programMap = (Map) JPO.unpackArgs(args);
            String sObjectId = (String)programMap.get("objectId");
            DomainObject doAbstractMeasurementBookEntry = DomainObject.newInstance(context, sObjectId);
			// Abstract MBE has Payment Items, get Payment Schedule(parent) of Payment Items
			String hasPaymnetItemsConnected = doAbstractMeasurementBookEntry.getInfo(context, "from["+RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS+"]");
			if("True".equalsIgnoreCase(hasPaymnetItemsConnected)) {
				// Get Payment Schedule(parent) of Payment Items
				mlPaymentItems = getPaymentScheduleStructureToAddItemsToAbstractMBE(context, args);
				for (int i=0,j=mlPaymentItems.size();i<j;i++)
				{
					Map objMap = (Map) mlPaymentItems.get(i);
					objMap.put("disableSelection", "true"); // Disable Selection for schedule
					objMap.put("RowEditable", "readonly"); // Disable edit foe Schedule
				}
			}
           
        }
        catch (Exception e) {
            throw e;
        }finally{
			if(isContextPushed){
					ContextUtil.popContext(context);
			}			
		}
		 return mlPaymentItems;
    }
  
  /**
     * program to get Payment Schedule structure to add to Abstract MBE
     * Block selection for Payment Schedule object, as Payment Schedule dont related to Abstract MBE
     *
     * @param context
     * @param args holds map of changed row id date with keys
     *    0 - work order object
     * @ returns list of Payment Schedule Object
     * @throws Exception if the operation fails
     */
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getPaymentScheduleStructureToAddItemsToAbstractMBE (Context context, String[] args) throws Exception
    {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            // Parent Object Id
            String sObjectId = (String) programMap.get("objectId");
            DomainObject doAbstractMBE = DomainObject.newInstance(context, sObjectId);
            // get work Order for Abstract MBE
            String sWorkOrderId = doAbstractMBE.getInfo(context, "to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
            DomainObject doWorkOrder = DomainObject.newInstance(context, sWorkOrderId);
            // Get Root Payment Schedule Object 
            StringList slObjectSelects = new StringList(1);
            slObjectSelects.add(DomainConstants.SELECT_ID);
            StringList slRelSelects = new StringList(1);
            slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
            MapList mlPaymentSchedule = doWorkOrder.getRelatedObjects(context,
                                                                        RELATIONSHIP_WMS_PAYMENT_HEAD,    // String relationshipPattern
                                                                        TYPE_WMS_PAYMENT_SCHEDULE,        // String typePattern
                                                                        slObjectSelects,                                        // StringList objectSelects
                                                                        slRelSelects,                                           // StringList relationshipSelects
                                                                        false,                                                  // boolean getTo
                                                                        true,                                                   // boolean getFrom
                                                                        (short) 1,                                              // short recurseToLevel
                                                                        "",                                                     // String objectWhere
                                                                        "");                                                    // String relationshipWhere
			Map objMap = null;
            for (int i=0,j=mlPaymentSchedule.size(); i<j; i++)
            {
                objMap = (Map) mlPaymentSchedule.get(i);
                objMap.put("disableSelection", "true");
            }
            return mlPaymentSchedule;
        }
        catch (Exception e) {
            throw e;
        }
    }
  
  
  
   /**
     * Get Abstarct MBE related Payment Items along with their all level Parent Objects data
     *
     * @param context
     * @param sAbstarctMBEOid holds Abstarct MBE Oid
	 *
     * @ returns Map holds 
	 *                  Abstratc MBE Related Payment Items Oid as Key and Its Data Map as Value
	 *           		IncludeInPaymentScheduleStructure as Key and List of Oids to show in structure as Value
     * @throws Exception if the operation fails
     */
	public Map getAbstractMBEPaymentItemsStructure (Context context, String sAbstarctMBEOid) throws Exception
    {
        try {
			Map mReturn = new HashMap();
			StringList slIncludePaymentScheduleStructure = new StringList();
			// Get Abstarct MBE Related Payment Items
            MapList mlPaymentItems = getAbstractMBEPaymentItems(context, sAbstarctMBEOid);
			String sTypePattern = TYPE_WMS_PAYMENT_ITEM + "," + TYPE_WMS_PAYMENT_SCHEDULE;
            StringList slObjectSelects = new StringList(1);
            slObjectSelects.add(DomainConstants.SELECT_ID);
            StringList slRelSelects = null;
			// Get Parent n level object data for each Payment Item related to Abstract MBE
			for (int i=0,j=mlPaymentItems.size(); i<j; i++)
			{
				Map objMap = (Map) mlPaymentItems.get(i);
				String sPaymentItemOid = (String) objMap.get(DomainConstants.SELECT_ID);
				mReturn.put(sPaymentItemOid, objMap);
				// Add to include list of Abstract MBE related Payment Items struture
				slIncludePaymentScheduleStructure.add(sPaymentItemOid);
				DomainObject doPaymentItem = DomainObject.newInstance(context, sPaymentItemOid);
				MapList mlPaymentItemStructure = doPaymentItem.getRelatedObjects(context,
																				RELATIONSHIP_WMS_PAYMENT_ITEM,// String relationshipPattern
																				sTypePattern,        								// String typePattern
																				slObjectSelects,                                    // StringList objectSelects
																				slRelSelects,                                       // StringList relationshipSelects
																				true,                                              // boolean getTo
																				false,                                               // boolean getFrom
																				(short) 0,                                          // short recurseToLevel
																				"",                                                 // String objectWhere
																				"");                                               	// String relationshipWhere
				for (int x=0,y=mlPaymentItemStructure.size(); x<y; x++)
				{
					objMap = (Map) mlPaymentItemStructure.get(x);
					slIncludePaymentScheduleStructure.add((String) objMap.get(DomainConstants.SELECT_ID));
				}
			}
			mReturn.put("IncludeInPaymentScheduleStructure", slIncludePaymentScheduleStructure);
            return mReturn;
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	
	/**
     * Get the Abstract MBE related Payment Item objects
     *
     * @param context
     * @param sObjectId holds Abstract MBE Object Id 
     *
     * @return MapList containing information of payment items
     * @throws Exception if the operation fails
     */
    public MapList getAbstractMBEPaymentItems (Context context, String sObjectId) throws Exception
    {
        try {
            DomainObject doAbstractMeasurementBookEntry = DomainObject.newInstance(context, sObjectId);
			String strWorkOrderValue = (String)doAbstractMeasurementBookEntry.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"].value");
			if(UIUtil.isNullOrEmpty(strWorkOrderValue)){
				strWorkOrderValue = "0";
			}		
			
            // data to return to table
            StringList slObjectSelects = new StringList(1);
            slObjectSelects.add(DomainConstants.SELECT_ID);
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_PAYMENT_ITEM_AMOUNT+"]");
            StringList slRelSelects = new StringList(1);
            slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
            slRelSelects.add("attribute["+ATTRIBUTE_ITEM_ENTRY_QUANTITY+"]");
            slRelSelects.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"]");
            // get Abstract MBE related payment item
            MapList mlPaymentItems = doAbstractMeasurementBookEntry.getRelatedObjects(context,
                                                                                        RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS,  // String relationshipPattern
                                                                                        TYPE_WMS_PAYMENT_ITEM,                        // String typePattern
                                                                                        slObjectSelects,                                                    // StringList objectSelects
                                                                                        slRelSelects,                                                       // StringList relationshipSelects
                                                                                        false,                                                              // boolean getTo
                                                                                        true,                                                               // boolean getFrom
                                                                                        (short) 0,                                                          // short recurseToLevel
                                                                                        "",                                                                 // String objectWhere
                                                                                        "");                                                                // String relationshipWhere
            
			Map mTemp = null;
			for(int i=0;i<mlPaymentItems.size();i++){
				mTemp = (Map)mlPaymentItems.get(i);
				mTemp.put("WorkOrderValue",strWorkOrderValue);
			}
			
			return mlPaymentItems;
        }
        catch (Exception e) {
            throw e;
        }
    }
  
  
    /**
     * expand program to expand total payment schedule structure  to add to Abstract MBE
     * Allow selection only for leaf node payment items and not connected to Abstract MBE
     *
     * @param context
     * @param args holds map of changed row id date with keys
     *    0 - work order object
     * @ returns list will all levels of objects data
     * @throws Exception if the operation fails
     */
	 @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList expandPaymentScheduleStrucutreToAddItemsToAbstractMBE (Context context, String[] args) throws Exception
    {
        try {
            Map programMap = (Map)JPO.unpackArgs(args);
            String sParentOid = (String) programMap.get("parentOID");
            HashMap hmInput = new HashMap();
            hmInput.put("objectId", sParentOid);
            StringList slExcludeSelection = excludeConectedPaymentItems (context, JPO.packArgs(hmInput));
            String sObjectId = (String) programMap.get("objectId");
            StringList slObjectSelects = new StringList(1);
            slObjectSelects.add(DomainConstants.SELECT_ID);
            slObjectSelects.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
            StringList slRelSelects = new StringList(1);
            slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
            DomainObject doPaymentSchedule = DomainObject.newInstance(context, sObjectId);
            // expand all levels of payment schedule structure
            MapList mlPaymentStructure = doPaymentSchedule.getRelatedObjects(context,
                                                                        RELATIONSHIP_WMS_PAYMENT_ITEM,// String relationshipPattern
                                                                        TYPE_WMS_PAYMENT_ITEM,        // String typePattern
                                                                        slObjectSelects,                                    // StringList objectSelects
                                                                        slRelSelects,                                       // StringList relationshipSelects
                                                                        false,                                              // boolean getTo
                                                                        true,                                               // boolean getFrom
                                                                        (short) 0,                                          // short recurseToLevel
                                                                        "",                                                 // String objectWhere
                                                                        "");                                                // String relationshipWhere
            Map objMap = null;
            for (int i=0,j=mlPaymentStructure.size(); i<j; i++)
            {
                objMap = (Map) mlPaymentStructure.get(i);
                // Block Selection for Parent Items and Already connected Items
                if (slExcludeSelection.contains((String) objMap.get(DomainConstants.SELECT_ID)) || "True".equalsIgnoreCase((String) objMap.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]"))) {
                    objMap.put("disableSelection", "true");
                }
            }
            return mlPaymentStructure;
        }
        catch (Exception e) {
            throw e;
        }
    }
  /**
     * Exclude oid program
     * exclude payment item oids already releated to Abstract MBE
     *
     * @param context
     * @param args contains a Map with the following entries:
     *    objectId - Abstract MBE Object
     * @return StringList containing information of payment items to not show for connection
     * @throws Exception if the operation fails
     */
    public StringList excludeConectedPaymentItems (Context context, String[] args) throws Exception 
    {
        try {
            StringList slExcludePaymentItemsOid = new StringList();
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sObjectId = (String) programMap.get("objectId");
            StringList slObjectSelects = new StringList();
            slObjectSelects.add(DomainConstants.SELECT_ID);
            StringList slRelSelects = null;
            DomainObject doAbstractMeasurementBookEntry = DomainObject.newInstance(context, sObjectId);
            // get payment item oids related to Abstract MBE
            MapList mlPaymentItems = doAbstractMeasurementBookEntry.getRelatedObjects(context,
                                                                                        RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS,  // String relationshipPattern
                                                                                        TYPE_WMS_PAYMENT_ITEM,                        // String typePattern
                                                                                        slObjectSelects,                                                    // StringList objectSelects
                                                                                        slRelSelects,                                                       // StringList relationshipSelects
                                                                                        false,                                                              // boolean getTo
                                                                                        true,                                                               // boolean getFrom
                                                                                        (short) 0,                                                          // short recurseToLevel
                                                                                        "",                                                                 // String objectWhere
                                                                                        "");                                                                // String relationshipWhere
            Map objMap = null;
            for (int i=0, j=mlPaymentItems.size(); i<j; i++)
            {
                objMap = (Map) mlPaymentItems.get(i);
                // add to exclude list
                slExcludePaymentItemsOid.add((String) objMap.get(DomainConstants.SELECT_ID));
            }
            return slExcludePaymentItemsOid;
        }
        catch (Exception e) {
            throw e;
        }
    }
  
   public void updateTotalTillDatePercentCompleted(Context context,String[] args) throws Exception
    {
        try {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            HashMap paramMap = (HashMap)programMap.get("paramMap");
            String sPaymentOid = (String)paramMap.get("objectId");
            String sAbstractMBEPaymentItemsRelId = (String)paramMap.get("relId");
            // get new value entered for percent completed
            String sTillDatePercentageCompleted = (String)paramMap.get("New Value");
            // updates percent completed till date on payment item
            DomainObject doPayment = DomainObject.newInstance(context, sPaymentOid);
            //doPayment.setAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE, sTillDatePercentageCompleted);
            // updates percent completed till date on entry
            DomainRelationship doRelWMSAbstractMBEPaymentItems = new DomainRelationship(sAbstractMBEPaymentItemsRelId);
			ContextUtil.pushContext(context);
            doRelWMSAbstractMBEPaymentItems.setAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE, sTillDatePercentageCompleted);
			ContextUtil.popContext(context);
        }
        catch (Exception e) {
            throw e;
        }
    }
  
  
    /**
     * This method gets % completed till date against each leaf node item in payment schedule structure
     *
     * @param context
     * @param args contains a Map with the following entries:
     *    objectList - list of payment items object data
     *
     * @return Vector contain column values for each row
     *
     * @throws Exception if the operation fails
     */
    public Vector getPercentageCompletedTillDate(Context context, String[] args) throws Exception 
    {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList"); // list of table row object data
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
            Map objMap = null;
            for (int i=0; i<intSize; i++)
            {
                objMap = (Map) objectList.get(i);
				// Get % Complete Till Date value for Abstract MBE Related Payment Item
				if ("True".equals((String)objMap.get("Abstract MBE Payment Item"))) {
					vColumnValues.add((String)objMap.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"]"));
				}
				else{
					vColumnValues.add("");
				}
            }
            return vColumnValues;
        }
        catch (Exception e) {
            throw new Exception("Error while getting since previous entry amount:"+e.getMessage());
        }
    }
  
   /**
     * This method gets payment for item amount till date against each item in table
     * till date amount = payment item * (till date % completed/100)
     *
     * @param context
     * @param args contains a Map with the following entries:
     *    objectList - list of payment items object data
     *
     * @return Vector contain column values for each row
     *
     * @throws Exception if the operation fails
     */
    public Vector getUpToDateAmount(Context context, String[] args) throws Exception 
    {
        try {
            DecimalFormat df = new DecimalFormat ( "#.##" ) ;
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList"); // list of table row object data
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
            Map objMap = null;
            double dPayItemAmount;
            double dPercentageCompleteTillDate;
            double dUpToDateAmount;
            for (int i=0; i<intSize; i++)
            {
                objMap = (Map) objectList.get(i);
				if ("True".equals((String)objMap.get("Abstract MBE Payment Item"))) {
                //dPayItemAmount = Double.parseDouble((String)objMap.get("attribute["+ATTRIBUTE_WMS_PAYMENT_ITEM_AMOUNT+"]"));
                dPayItemAmount = Double.parseDouble((String)objMap.get("WorkOrderValue"));
                dPercentageCompleteTillDate = Double.parseDouble((String)objMap.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"]"));
                // calculate percentage
                dPercentageCompleteTillDate = (dPercentageCompleteTillDate/100);
                // calculating amount
                dUpToDateAmount = (dPercentageCompleteTillDate * dPayItemAmount);
                //vColumnValues.add(String.valueOf(dUpToDateAmount));
                vColumnValues.add(String.valueOf(df.format(dUpToDateAmount)));
            }
				else{
					vColumnValues.add("");
				}
            }
            return vColumnValues;
        }
        catch (Exception e) {
            throw new Exception("Error while getting up to date amount:"+e.getMessage());
        }
    }

	 /**
     * This method gets payment for item amount since previous entry date against each item in table
     * till date amount = payment item * (since previous entry date % completed/100)
     *
     * @param context
     * @param args contains a Map with the following entries:
     *    objectList - list of payment items object data
     *
     * @return Vector contain column values for each row
     *
     * @throws Exception if the operation fails
     */
    public Vector getSincePreviousAmount(Context context, String[] args) throws Exception 
    {
        try {
            DecimalFormat df = new DecimalFormat ( "#.##" ) ;
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList"); // list of table row object data
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
            Map objMap = null;
            double dPayItemAmount;
            double dActivityQuantity;
            double dSincePreviousAmount;
            for (int i=0; i<intSize; i++)
            {
                objMap = (Map) objectList.get(i);
				if ("True".equals((String)objMap.get("Abstract MBE Payment Item"))) {
                //dPayItemAmount = Double.parseDouble((String)objMap.get("attribute["+ATTRIBUTE_WMS_PAYMENT_ITEM_AMOUNT+"]"));
                dPayItemAmount = Double.parseDouble((String)objMap.get("WorkOrderValue"));
                dActivityQuantity = Double.parseDouble((String)objMap.get("attribute["+ATTRIBUTE_ITEM_ENTRY_QUANTITY+"]"));
                // calculate percentage
                dActivityQuantity = (dActivityQuantity/100);
                // calculating amount
                dSincePreviousAmount = (dActivityQuantity * dPayItemAmount);
					//vColumnValues.add(String.valueOf(dSincePreviousAmount));
                vColumnValues.add(df.format(dSincePreviousAmount));
            }
				else{
					vColumnValues.add("");
				}
            }
            return vColumnValues;
        }
        catch (Exception e) {
            throw new Exception("Error while getting since previous entry amount:"+e.getMessage());
        }
    }
	
  /**
     * Dynamically called from ajax to get the till date and since previous amounts for entered till date % completed
     *
     * @param context
     * @param args holds map of changed row id date with keys
     *    objectId - Payment Item object
     *    TillDatePercentCompleted - % completed New value
     *    SincePreviousPercentCompleted - since prev new value
     *
     * @return String containing till date amount and since previous amount seperated by pipe
     * @throws Exception if the operation fails
     */
    public String getAmount(Context context, String[] args)throws Exception
    {
        try {
            HashMap requestMap = (HashMap)JPO.unpackArgs(args);
            String sPaymentOid = (String)requestMap.get("objectId");
            String sSincePreviousPercentCompleted = (String)requestMap.get("SincePreviousPercentCompleted");
            // calculate since prev %
            double dSincePreviousPercentCompleted = Double.parseDouble(sSincePreviousPercentCompleted);
            dSincePreviousPercentCompleted = (dSincePreviousPercentCompleted/100);
            // calculate till date %
            String sTillDatePercentCompleted = (String)requestMap.get("TillDatePercentCompleted");
            double dTillDatePercentCompleted = Double.parseDouble(sTillDatePercentCompleted);
            dTillDatePercentCompleted = (dTillDatePercentCompleted/100);
            // get payment item amount
            DomainObject doPaymentItem = DomainObject.newInstance(context, sPaymentOid);
            String sPaymentItemAmount = doPaymentItem.getInfo(context,"to["+RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS+"].from.to["+RELATIONSHIP_WORKORDER_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"].value");//doPaymentItem.getAttributeValue(context, ATTRIBUTE_WMS_PAYMENT_ITEM_AMOUNT);
            // calculate since prev amount
            double dPayItemAmount = Double.parseDouble(sPaymentItemAmount);
            double dSincePreviousAmount = (dSincePreviousPercentCompleted * dPayItemAmount);
            // calculate till date amount
            String sSincePreviousAmount = String.valueOf(dSincePreviousAmount);
            double dTillDateAmount = (dTillDatePercentCompleted * dPayItemAmount);
            String sTillDateAmount = String.valueOf(dTillDateAmount);
            return sTillDateAmount+"|"+sSincePreviousAmount;
        }
        catch (Exception e) {
            throw e;
        }
    }
  
  
  /**
     * This method called on work order Promote Trigger Event when promoted to Active
     * Calculate and update Amount againgst each payment item in the structure
     *
     * @param context
     * @param args holds the following input arguments:
     *    0 - objectId of the work order
     *    1 - type of the work order
     *
     * @throws Exception if the operation fails
     */
    public void updatePaymentItemAmount(Context context, String[] args) throws Exception
    {
        try {
            String sObjectId = args[0];
            String sType = args[1];
            if (sType.equals(TYPE_WMS_WORK_ORDER)) // do only for Work Order
            {
				if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
                DomainObject doWorkOrder = DomainObject.newInstance(context, sObjectId);
                String sValueOfContract = doWorkOrder.getAttributeValue(context, ATTRIBUTE_WMS_VALUE_OF_CONTRACT);
                double dValueOfContract = Double.parseDouble(sValueOfContract);
                StringList slObjectSelects = new StringList();
                slObjectSelects.add(DomainConstants.SELECT_ID);
                slObjectSelects.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
                // get leaf node payment items
                MapList mlLeafNodePaymentItems = getLeafNodePaymentItems(context, sObjectId, slObjectSelects, null);
                Map objMap = null;
                String sPaymentItemOid = "";
                String sPercentageOfWeightage = "";
                double dPercentageOfWeightage;
                double dPaymentItemAmount;
                DomainObject doPaymentItem = null;
                for (int i=0,j=mlLeafNodePaymentItems.size(); i<j; i++)
                {
                    objMap = (Map) mlLeafNodePaymentItems.get(i);
                    sPercentageOfWeightage = (String) objMap.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
                    dPercentageOfWeightage = ((Double.parseDouble(sPercentageOfWeightage))/100);
                    dPaymentItemAmount = (dValueOfContract * dPercentageOfWeightage);
                    sPaymentItemOid = (String) objMap.get(DomainConstants.SELECT_ID);
                    doPaymentItem = DomainObject.newInstance(context, sPaymentItemOid);
                    doPaymentItem.setAttributeValue(context, ATTRIBUTE_WMS_PAYMENT_ITEM_AMOUNT, String.valueOf(dPaymentItemAmount));
                }
            }
		}
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	 /**
     * utility method to get list of leaf node payment items related to work order payment schedule structure
     *
     * @param context
     * @param string holds work order oid
     * @param stringlist holds object selectables
     * @param stringlist holds rel selectables
     * @return MapList - list of leaf node payment items data
     * @throws Exception if the operation fails
     */
    public MapList getLeafNodePaymentItems(Context context, String sWorkOrderId, StringList slObjectSelects, StringList slRelationshipSelects) throws Exception 
    {
        try {
            String sRelPattern = RELATIONSHIP_WMS_PAYMENT_HEAD + "," + RELATIONSHIP_WMS_PAYMENT_ITEM;
            String sTypePattern = TYPE_WMS_PAYMENT_SCHEDULE + "," + TYPE_WMS_PAYMENT_ITEM;
            StringList slObjSelects = new StringList(1);
            slObjSelects.add(DomainConstants.SELECT_ID);
            slObjSelects.add(DomainConstants.SELECT_TYPE);
            slObjSelects.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
            if (slObjectSelects == null) {
                slObjectSelects = new StringList();
            }
            slObjectSelects.addAll(slObjSelects);
            DomainObject doWorkOrder = DomainObject.newInstance(context,sWorkOrderId);
            // get payment schedule strucutre
            MapList mlPaymentScheduleStrucutre = doWorkOrder.getRelatedObjects(context,
                                                                                sRelPattern,            // String relationshipPattern
                                                                                sTypePattern,           // String typePattern
                                                                                slObjectSelects,        // StringList objectSelects
                                                                                slRelationshipSelects,  // StringList relationshipSelects
                                                                                false,                  // boolean getTo
                                                                                true,                   // boolean getFrom
                                                                                (short) 0,              // short recurseToLevel
                                                                                "",                     // String objectWhere
                                                                                "");                    // String relationshipWhere
            Map objMap = null;
            String sObjectId = "";
            String hasChildItem = "";
            String sPaymentStructureObjType = "";
            MapList mlLeafNodePaymentItems = new MapList();
            for (int i=0,j=mlPaymentScheduleStrucutre.size(); i<j; i++)
            {
                objMap = (Map) mlPaymentScheduleStrucutre.get(i);
                sPaymentStructureObjType = (String) objMap.get(DomainConstants.SELECT_TYPE);
                hasChildItem = (String) objMap.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
                if (TYPE_WMS_PAYMENT_ITEM.equals(sPaymentStructureObjType))
                {
                    if ("false".equalsIgnoreCase(hasChildItem)) // add leaf node payment item to list
                    {
                        mlLeafNodePaymentItems.add(objMap);
                    }
                }
            }
            return mlLeafNodePaymentItems;
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	 
    /**
     * This method called on Abstract MBE Payment Items rel create Trigger Event
     * copies the current % completed to Entry
     *
     * @param context
     * @param args holds the following input arguments:
     *    0 - Abstract MBE Entry
     *    1 - payment item object
     *
     * @throws Exception if the operation fails
     */
    public void copyTillDatePercentCompleteToRel (Context context,String[] args) throws Exception
    {
        try {
            String sRelId = args[0];
            String sPaymentItemOid = args[1];
			
            DomainObject doPayment = DomainObject.newInstance(context, sPaymentItemOid);
            // get current % completed
            String sTillDatePercentageComplte = doPayment.getAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE);
            // copy to entry creation
            DomainRelationship doRelWMSAbstractMBEPaymentItems = new DomainRelationship(sRelId);
            doRelWMSAbstractMBEPaymentItems.setAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE, sTillDatePercentageComplte);
		}
        catch (Exception e) {
            throw e;
        }
    }

	
	/** 
     * Method AMBE AutoName as Title
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	@com.matrixone.apps.framework.ui.PostProcessCallable
    public HashMap postProcessEditPaymentSchedule(Context context, String[] args) throws Exception {
        HashMap mapReturnMap          = new HashMap();    
        mapReturnMap.put("Action","success");
        
        return mapReturnMap;
    }
	
	
	public void updateTotalSincePreviousPercentCompleted(Context context,String[] args) throws Exception
    {
        try {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            HashMap paramMap = (HashMap)programMap.get("paramMap");
            String sPaymentOid = (String)paramMap.get("objectId");
            String sAbstractMBEPaymentItemsRelId = (String)paramMap.get("relId");
            // get new value entered for percent completed
            String sTillDatePercentageCompleted = (String)paramMap.get("New Value");
            // updates percent completed till date on payment item
            DomainObject doPayment = DomainObject.newInstance(context, sPaymentOid);
            //doPayment.setAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE, sTillDatePercentageCompleted);
            // updates percent completed till date on entry
            DomainRelationship doRelWMSAbstractMBEPaymentItems = new DomainRelationship(sAbstractMBEPaymentItemsRelId);
			ContextUtil.pushContext(context);
            doRelWMSAbstractMBEPaymentItems.setAttributeValue(context, ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY, sTillDatePercentageCompleted);
			ContextUtil.popContext(context);
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	public void updateOtherDeductionAmount(Context context,String[] args) throws Exception
    {
        try {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            HashMap paramMap = (HashMap)programMap.get("paramMap");
            String sPaymentOid = (String)paramMap.get("objectId");
            String sAbstractMBEPaymentItemsRelId = (String)paramMap.get("relId");
            // get new value entered for percent completed
            String sTillDatePercentageCompleted = (String)paramMap.get("New Value");
            // updates percent completed till date on payment item
            DomainObject doPayment = DomainObject.newInstance(context, sPaymentOid);
            //doPayment.setAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE, sTillDatePercentageCompleted);
            // updates percent completed till date on entry
            DomainRelationship doRelWMSAbstractMBEPaymentItems = new DomainRelationship(sAbstractMBEPaymentItemsRelId);
			ContextUtil.pushContext(context);
            doRelWMSAbstractMBEPaymentItems.setAttributeValue(context, ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_AMOUNT, sTillDatePercentageCompleted);
			ContextUtil.popContext(context);
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	public Vector getTillDateAmount(Context context, String[] args) throws Exception 
    {
        try {
            DecimalFormat df = new DecimalFormat ( "#.##" ) ;
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList"); // list of table row object data
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
            Map objMap = null;
			String strId = DomainConstants.EMPTY_STRING;
			String strRelId = DomainConstants.EMPTY_STRING;
            double dPayItemAmount;
            double dActivityQuantity;
            double dTillDateAmount;
            double dSinceLast;
			DomainObject doObj = null;
			DomainRelationship drRel = null;
            for (int i=0; i<intSize; i++)
            {
                objMap = (Map) objectList.get(i);
				if ("True".equals((String)objMap.get("Abstract MBE Payment Item"))) {
                strId = (String)objMap.get(DomainObject.SELECT_ID);
                strRelId = (String)objMap.get(DomainRelationship.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strId) && UIUtil.isNotNullAndNotEmpty(strRelId)){
					doObj = new DomainObject(strId);
					drRel = new DomainRelationship(strRelId);
					dSinceLast = Double.parseDouble((String)drRel.getAttributeValue(context,ATTRIBUTE_ITEM_ENTRY_QUANTITY));
					
					dPayItemAmount = Double.parseDouble((String)objMap.get("WorkOrderValue"));
					dActivityQuantity = Double.parseDouble((String)drRel.getAttributeValue(context,ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE));
					// calculate percentage
					dActivityQuantity = ((dActivityQuantity-dSinceLast)/100);
					// calculating amount
					dTillDateAmount = (dActivityQuantity * dPayItemAmount);
					vColumnValues.add(df.format(dTillDateAmount));
				}else{
					vColumnValues.add("");
				}
            }
				else{
					vColumnValues.add("");
				}
            }
            return vColumnValues;
        }
        catch (Exception e) {
            throw new Exception("Error while getting since previous entry amount:"+e.getMessage());
        }
    }
	
	public Vector getTillDateQuantity(Context context, String[] args) throws Exception 
    {
        try {
            DecimalFormat df = new DecimalFormat ( "#.##" ) ;
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList"); // list of table row object data
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
            Map objMap = null;
			String strId = DomainConstants.EMPTY_STRING;
			String strRelId = DomainConstants.EMPTY_STRING;
            double dPayItemAmount;
            double dActivityQuantity;
            double dTillDateAmount;
			double dSinceLast;
			DomainObject doObj = null;
			DomainRelationship drRel = null;
            for (int i=0; i<intSize; i++)
            {
                objMap = (Map) objectList.get(i);
				if ("True".equals((String)objMap.get("Abstract MBE Payment Item"))) {
                strId = (String)objMap.get(DomainObject.SELECT_ID);
                strRelId = (String)objMap.get(DomainRelationship.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strId) && UIUtil.isNotNullAndNotEmpty(strRelId)){
					doObj = new DomainObject(strId);
					drRel = new DomainRelationship(strRelId);
					dSinceLast = Double.parseDouble((String)drRel.getAttributeValue(context,ATTRIBUTE_ITEM_ENTRY_QUANTITY));
					
					dActivityQuantity = Double.parseDouble((String)drRel.getAttributeValue(context,ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE));
					// calculate percentage
					dActivityQuantity = dActivityQuantity-dSinceLast;
					// calculating amount
					//vColumnValues.add(df.format(dActivityQuantity));
					vColumnValues.add(String.valueOf(dActivityQuantity));
				}else{
					vColumnValues.add("");
				}
            }
				else{
					vColumnValues.add("");
				}
            }
            return vColumnValues;
        }
        catch (Exception e) {
            throw new Exception("Error while getting since previous entry amount:"+e.getMessage());
        }
    }
	
	
	public void updateOtherDeductionDescription(Context context,String[] args) throws Exception
    {
        try {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            HashMap paramMap = (HashMap)programMap.get("paramMap");
            String sPaymentOid = (String)paramMap.get("objectId");
            String sAbstractMBEPaymentItemsRelId = (String)paramMap.get("relId");
            // get new value entered for percent completed
            String sTillDatePercentageCompleted = (String)paramMap.get("New Value");
            // updates percent completed till date on payment item
            DomainRelationship doRelWMSAbstractMBEPaymentItems = new DomainRelationship(sAbstractMBEPaymentItemsRelId);
			ContextUtil.pushContext(context);
            doRelWMSAbstractMBEPaymentItems.setAttributeValue(context, ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DESCRIPTION, sTillDatePercentageCompleted);
			ContextUtil.popContext(context);
        }
        catch (Exception e) {
            throw e;
        }
    }
	
	}