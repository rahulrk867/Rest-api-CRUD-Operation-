import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import matrix.db.JPO;
import java.util.HashMap;
import java.util.Map;
import matrix.util.StringList;
import matrix.db.Context;
import matrix.util.SelectList;
import com.matrixone.apps.domain.util.ContextUtil;
import java.io.File;
import java.io.FileOutputStream;
import org.joda.time.LocalDate;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import java.util.Calendar;

public class WMSPaymentSchedule_mxJPO extends WMSConstants_mxJPO {

	public WMSPaymentSchedule_mxJPO(Context context,String[] args) {
		
		super(context,args);
	}
	
	/**
	 * Method to get the connected Payment schedule items to the MBE
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedPaymentItems MapList containing the Payment schedule items
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getPaidPaymentScheduleItems (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListConnectedPaymentItems = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
				mapListConnectedPaymentItems = getPaidPaymentScheduleItems(context, domObjMBE);
			}
			return mapListConnectedPaymentItems;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/**
	 * Function to get the Tasks connected to the selected MBE
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjMBE DomainObject instance of selected Work Order 
	 * @return mapListTasks MapList containing the MBEs connected to Work Order with ID
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	public static MapList getPaidPaymentScheduleItems(Context context, DomainObject domObjMBE)
			throws FrameworkException {
		try
		{
		SelectList selListBusSelects     = new SelectList(7);
		selListBusSelects.add(DomainConstants.SELECT_ID);
		selListBusSelects.add(DomainConstants.SELECT_TYPE);
		selListBusSelects.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
		selListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
		selListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
		selListBusSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
		selListBusSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
		SelectList selListRelSelects     = new SelectList(4);
		selListRelSelects.add(DomainRelationship.SELECT_ID);
		selListRelSelects.add("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"]");
		selListRelSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
		//selListRelSelects.add("attribute["+ATTRIBUTE_WMS_EE_ADJUSTED_QUANTITY+"]"); 
		MapList mapListPaidPaymentScheduleItems = domObjMBE.getRelatedObjects(context, // matrix context
				RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship pattern
				TYPE_WMS_PAYMENT_ITEM, // type pattern
				selListBusSelects, // object selects
				selListRelSelects, // relationship selects
				false, // to direction
				true, // from direction
				(short) 1, // recursion level
				DomainConstants.EMPTY_STRING, // object where clause
				DomainConstants.EMPTY_STRING, // relationship where clause
				0);
		return mapListPaidPaymentScheduleItems;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
  }
	
	public boolean isPaymentScheduleApproved(Context context, String[] args) throws Exception 
    {
		boolean isApproved = false;
        try
        {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strUser = context.getUser();
			String strObjectId = (String)programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				DomainObject doObject = new DomainObject(strObjectId);
				StringList slObjectSelect = new StringList();
				slObjectSelect.add("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.id");
				slObjectSelect.add("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.current");
				slObjectSelect.add("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.owner");
				
				Map mObjectInfo = (Map)doObject.getInfo(context,slObjectSelect);
				if(mObjectInfo != null && mObjectInfo.isEmpty() == false){
					String strOwner = (String)mObjectInfo.get("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.owner");
					String strCurrent = (String)mObjectInfo.get("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.current");
					if(strOwner.equals(strUser) && strCurrent.equals("Approved")){
						isApproved = true;						
					}				
				}				
			}
            
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
		return isApproved;
    }
	
	public boolean isPaymentScheduleNotApproved(Context context, String[] args) throws Exception 
    {
        boolean isNotApproved = false;
        try
        {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strUser = context.getUser();
			String strObjectId = (String)programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				DomainObject doObject = new DomainObject(strObjectId);
				StringList slObjectSelect = new StringList();
				slObjectSelect.add("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.id");
				slObjectSelect.add("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.current");
				slObjectSelect.add("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.owner");
				
				Map mObjectInfo = (Map)doObject.getInfo(context,slObjectSelect);
				if(mObjectInfo != null && mObjectInfo.isEmpty() == false){
					String strOwner = (String)mObjectInfo.get("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.owner");
					String strCurrent = (String)mObjectInfo.get("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.current");
					if(strOwner.equals(strUser) && strCurrent.equals("Create")){
						isNotApproved = true;						
					}				
				}				
			}
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
		return isNotApproved;
    }
	
	
	public void revisePaymentSchedule(Context context, String[] args) throws Exception 
    {
        try
        {
			String fileName = DomainConstants.EMPTY_STRING;
			LocalDate ldToday=new LocalDate();
			String strTime = ldToday.toString();
			DomainObject doPaymentSchedule = null;
			
			FileOutputStream outputStream = null;
			String strTempFolder = EnoviaResourceBundle.getProperty(context,"WMS.PaymentSchedule.Revision.tempfolder");
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strObjId = (String)programMap.get("objectId");
			DomainObject doObject = new DomainObject(strObjId);
			StringList slPaymentScheduleSelect = new StringList("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.id");
			slPaymentScheduleSelect.add("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
		
			Map mPSInfo = (Map)doObject.getInfo(context,slPaymentScheduleSelect);
			
			String strPaymentScheduleTitle = (String)mPSInfo.get("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
			String strPaymentScheduleId = (String)mPSInfo.get("from["+RELATIONSHIP_WMS_PAYMENT_HEAD+"].to.id");
			
			StringList slAbsMBEStates = (StringList)doObject.getInfoList(context,"from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.current");
			
			if(slAbsMBEStates.isEmpty() == false && (slAbsMBEStates.contains("Create") || slAbsMBEStates.contains("Review"))){
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Revise.PaymentScheduleFail");
				emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				return;
			}
			
			if(UIUtil.isNotNullAndNotEmpty(strPaymentScheduleId)){
				doPaymentSchedule = new DomainObject(strPaymentScheduleId);
				StringList slObjectSelect = new StringList();
				slObjectSelect.add(DomainConstants.SELECT_ID);
				slObjectSelect.add("attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
				slObjectSelect.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"].value");
				slObjectSelect.add("attribute["+ATTRIBUTE_WMS_PAYMENT_SCHEDULE_SEQUENCE+"].value");
				slObjectSelect.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"].value");
				slObjectSelect.add("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
				StringList slRelSelect = new StringList();
				slRelSelect.add(DomainRelationship.SELECT_ID);				
				
				
				MapList mapListPaymentScheduleItems = doPaymentSchedule.getRelatedObjects(context, // matrix context
								RELATIONSHIP_WMS_PAYMENT_ITEM, // relationship pattern
								TYPE_WMS_PAYMENT_ITEM, // type pattern
								slObjectSelect, // object selects
								slRelSelect, // relationship selects
								false, // to direction
								true, // from direction
								(short) 0, // recursion level
								DomainConstants.EMPTY_STRING, // object where clause
								DomainConstants.EMPTY_STRING, // relationship where clause
								0);
								
				mapListPaymentScheduleItems.addSortKey("attribute["+ATTRIBUTE_WMS_PAYMENT_SCHEDULE_SEQUENCE+"].value","ascending", "integer");
				mapListPaymentScheduleItems.sort();	
				if(mapListPaymentScheduleItems != null && mapListPaymentScheduleItems.isEmpty()==false){
					XSSFWorkbook workbook = new XSSFWorkbook();
					XSSFSheet sheetData = workbook.createSheet("Data");
					String[] headerData = {"Sl No", "Level", "Sequence","Particular","Weightage", "% Completed Till Date"};
					CellStyle styleHeading = workbook.createCellStyle();
					styleHeading.setBorderLeft(CellStyle.ALIGN_CENTER);
					
					XSSFFont font= workbook.createFont();
					font.setFontHeightInPoints((short)10);
					font.setFontName("Arial");
					font.setColor(IndexedColors.WHITE.getIndex());
					font.setBold(true);
					styleHeading.setFont(font);
					styleHeading.setFillForegroundColor(IndexedColors.CORNFLOWER_BLUE.getIndex());
					styleHeading.setFillPattern(CellStyle.SOLID_FOREGROUND); 
					styleHeading.setBorderLeft(CellStyle.BORDER_THIN);
					styleHeading.setBorderRight(CellStyle.BORDER_THIN);
					styleHeading.setBorderTop(CellStyle.BORDER_THIN);
					styleHeading.setBorderBottom(CellStyle.BORDER_THIN);
					
					Row row = sheetData.createRow(0);
					for (int columnCount=0; columnCount < headerData.length; columnCount++) {
						Cell cell = row.createCell(columnCount);
						cell.setCellValue((String) headerData[columnCount]);
						cell.setCellStyle(styleHeading);
					}
					
					String[] cellData = new String[headerData.length];			
					Row rowData = null;
					int iSize = mapListPaymentScheduleItems.size();
					Map mapObjectInfo = null;
					int iCountRow = 1;
					for(int iCount=0; iCount<iSize; iCount++){
						mapObjectInfo = (Map)mapListPaymentScheduleItems.get(iCount);
						cellData[0] = iCountRow+""; 
						cellData[1] = (String)mapObjectInfo.get(DomainConstants.SELECT_LEVEL); 
						cellData[2] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMS_PAYMENT_SCHEDULE_SEQUENCE+"].value"); 
						cellData[3] = (String)mapObjectInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
						String strIsParent = 	(String)mapObjectInfo.get("from["+RELATIONSHIP_WMS_PAYMENT_ITEM+"]");
						if("".equals(strIsParent) || "null".equals(strIsParent) || strIsParent == null || "false".equalsIgnoreCase(strIsParent)){
							cellData[4] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"].value"); 
							cellData[5] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"].value"); 
						}else{
							cellData[4] = DomainConstants.EMPTY_STRING;
							cellData[5] = DomainConstants.EMPTY_STRING;
						}
						
						rowData = sheetData.createRow(iCountRow);
						for (int columnCount=0; columnCount < headerData.length; columnCount++) {
							Cell cell = rowData.createCell(columnCount);
							cell.setCellValue((String) cellData[columnCount]);
						}
						iCountRow = iCountRow + 1;
					}
					fileName = strPaymentScheduleTitle +"_"+Calendar.getInstance().getTimeInMillis();
					outputStream = new FileOutputStream(new File(strTempFolder+"/"+fileName+ ".xlsx"));
					workbook.write(outputStream);
				}

			}		

				DomainObject doNewDoc = DomainObject.newInstance(context, DomainConstants.TYPE_DOCUMENT);
				doNewDoc.createObject(context, "Document", fileName, "1", "Document Release", "eService Production");	
				doNewDoc.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, fileName);
				doNewDoc.checkinFile(context, true, true, "", DomainConstants.FORMAT_GENERIC, fileName+".xlsx", strTempFolder);	
				DomainRelationship.connect(context, doPaymentSchedule, "Reference Document", doNewDoc);
				doPaymentSchedule.demote(context);
				doPaymentSchedule.demote(context);

        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
	
}
