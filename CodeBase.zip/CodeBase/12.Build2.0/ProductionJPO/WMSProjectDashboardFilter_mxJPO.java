import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;
import java.util.Date;
import java.util.Locale;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.DateUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.mxType;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.framework.ui.ProgramCallable;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.Task;
import com.matrixone.apps.program.fiscal.Helper;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.Pattern;
import matrix.util.StringList;

/**
 * The following class is responsible for Project Status Dashboard
 * 
 * @author PSN12
 *
 */
public class WMSProjectDashboardFilter_mxJPO extends WMSConstants_mxJPO {

	SimpleDateFormat sdf;
	StringList slObjSelects = new StringList();

	private final static String SELECT_ATTRIBUTE_TASK_ESTIMATED_END_DATE = "attribute["
			+ DomainConstants.ATTRIBUTE_TASK_ESTIMATED_FINISH_DATE + "]";
	private final static String SELECT_FROM_SUBTASK = "from[" + DomainConstants.RELATIONSHIP_SUBTASK + "]";

	public WMSProjectDashboardFilter_mxJPO(Context context, String[] args) throws Exception {
		super(context, args);
		String dateTimeFormat = EnoviaResourceBundle.getProperty(context, "eServiceSuites.eMatrixDateFormat");
		if (ProgramCentralUtil.isNullString(dateTimeFormat)) {
			dateTimeFormat = "MM/dd/yyyy hh:mm:ss aaa";
		}
		sdf = new SimpleDateFormat(dateTimeFormat, Locale.US);

		slObjSelects.addElement(ProgramCentralConstants.SELECT_POLICY);
		slObjSelects.addElement(DomainObject.SELECT_OWNER);
		slObjSelects.addElement(Task.SELECT_TASK_ESTIMATED_FINISH_DATE);
		slObjSelects.addElement(SELECT_FROM_SUBTASK);
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Start Date]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("attribute[Task Actual Finish Date]");
		slObjSelects.addElement("attribute[Task Actual Start Date]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("to[Project Access Key].from.from[Project Access List].to.id");
		slObjSelects.addElement("to[Project Access Key].from.from[Project Access List].to.name");
		slObjSelects.addElement("to[Issue].from.name");
		slObjSelects.addElement("to[Issue].from.id");
	}
	
	public StringList getMasterGEs(Context context, String[] args) throws Exception 
	{
		StringList slReturnList = new StringList();
		slReturnList.addElement("All");
		slReturnList.addElement("All_id");
		
		StringList slObjSels = new StringList();
		slObjSels.addElement("from[Member].attribute[Project Role].value");
		slObjSels.addElement("from[Member].to.id");
		slObjSels.addElement("from[Member].to.attribute[First Name]");
		slObjSels.addElement("from[Member].to.attribute[Last Name]");
		MapList mlProjects = DomainObject.findObjects(context, "Project Space", DomainConstants.QUERY_WILDCARD, null, slObjSels);
		
		int iSize = mlProjects.size();
		Map mTemp;
		StringList slRoles;
		StringList slIds;
		StringList slFirstNames;
		StringList slLastNames;
		for(int i = 0 ; i < iSize ; i++)
		{
			
			mTemp = (Map)mlProjects.get(i);
			slRoles = ProgramCentralUtil.getAsStringList(mTemp.get("from[Member].attribute[Project Role].value"));
			slIds = ProgramCentralUtil.getAsStringList(mTemp.get("from[Member].to.id"));
			slFirstNames = ProgramCentralUtil.getAsStringList(mTemp.get("from[Member].to.attribute[First Name]"));
			slLastNames = ProgramCentralUtil.getAsStringList(mTemp.get("from[Member].to.attribute[Last Name]"));
			for (int j = 0 ; j < slRoles.size() ; j++)
			{
				if("Master GE".equals(slRoles.get(j)) && !slReturnList.contains(slIds.get(j)))
				{
					slReturnList.addElement(slFirstNames.get(j) + " " + slLastNames.get(j));
					slReturnList.addElement(slIds.get(j));
				}
			}
		}
		return slReturnList;
	}

	@ProgramCallable
	public MapList getProjectUnderExecution(Context context, String[] args) throws Exception 
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strprojectTypeFromURL = (String) programMap.get("ProjectType");
		String strprojectStateFromURL = (String) programMap.get("projectState");
		String strProjectStatus = (String) programMap.get("ProjectStatus");
		System.out.println("strProjectStatus-----------124"+strProjectStatus);
		String strprojectYearFromURL = (String) programMap.get("ProjectYear");
		String strMasterGE = (String) programMap.get("MasterGE");
		MapList mlRelatedProjectDetails = new MapList();
		MapList mlReturnMaplist = new MapList();
		MapList mlReturnMaplistFinal = new MapList();
		try {
			DomainObject doPerson = PersonUtil.getPersonObject(context);
			String strWhere = "";
			if (UIUtil.isNotNullAndNotEmpty(strprojectTypeFromURL) && "All".equals(strprojectTypeFromURL) == false) {
				if (UIUtil.isNotNullAndNotEmpty(strWhere)) {
					strWhere += " && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value=='"
							+ strprojectTypeFromURL + "'";
				} else {
					strWhere = "from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value=='" + strprojectTypeFromURL
							+ "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strprojectStateFromURL) && "All".equals(strprojectStateFromURL) == false) {
				if (UIUtil.isNotNullAndNotEmpty(strWhere)) {
					strWhere += " && from[WMSProjectSOC].to.current=='" + strprojectStateFromURL + "'";
				} else {
					strWhere = "from[WMSProjectSOC].to.current=='" + strprojectStateFromURL + "'";
				}
			}else if("All".equals(strprojectStateFromURL)){
				if(UIUtil.isNotNullAndNotEmpty(strWhere)){
					strWhere += " && (from[WMSProjectSOC].to.current=='Delegation' || from[WMSProjectSOC].to.current=='UnderExecution')";
				}else{
					strWhere = "(from[WMSProjectSOC].to.current=='Delegation' || from[WMSProjectSOC].to.current=='UnderExecution')";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strprojectYearFromURL) && "All".equals(strprojectYearFromURL) == false) {
				if (UIUtil.isNotNullAndNotEmpty(strWhere)) {
					strWhere += " && from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value=='"
							+ strprojectYearFromURL + "'";
				} else {
					strWhere = "from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value=='" + strprojectYearFromURL
							+ "'";
				}
			}
			String whereCondition = strWhere;
			StringList slObjSelects = new StringList();
			slObjSelects.addElement("id");
			slObjSelects.addElement("physicalid");
			slObjSelects.addElement("type");
			slObjSelects.addElement("current");
			slObjSelects.addElement("policy");
			slObjSelects.addElement("name");
			slObjSelects.addElement("description");
			slObjSelects.addElement("attribute[Task Estimated Duration]");
			slObjSelects.addElement("attribute[Percent Complete]");
			slObjSelects.addElement("attribute[Task Estimated Finish Date]");
			slObjSelects.addElement("from[WMSProjectSOC].to.current");
			slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
			slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
			slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
			slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
			slObjSelects.addElement("from[Member|attribute[Project Role].value=='Master GE'].to.id");
			
			StringList slTaskSelect = new StringList();
			slTaskSelect.add(DomainObject.SELECT_CURRENT);
			slTaskSelect.add(DomainObject.SELECT_NAME);	
			slTaskSelect.add(DomainObject.SELECT_ID);
			
			StringList slRelSelet = new StringList();
			slRelSelet.add(DomainRelationship.SELECT_ID);
			//slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
			//slObjSelects.addElement("from[Member].to.id");
			mlRelatedProjectDetails = doPerson.getRelatedObjects(context, "Member", // String relPattern
					"Project Space", // String typePattern
					slObjSelects, null, true, false, (short) 1, whereCondition, DomainConstants.EMPTY_STRING, null,
					null, null);
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
			String strCurrent = " ";
			String StrDateFormat = " ";
			String StrAdminApprovalDate = " ";
			String delayed = " ";
			String strProjectId = "";
			DomainObject doProject = DomainObject.newInstance(context);
			String strProjectTaskIdWorks = "";
			String strProjectTaskIdEquip = "";
			String strCurrentProject = "";
		
			
			
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) 
			{
				int count = i + 1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				
				if(!("All".equals(strMasterGE) || "All_id".equals(strMasterGE)) && !(ProgramCentralUtil.getAsStringList(mMap.get("from[Member].to.id")).contains(strMasterGE)))
					continue;
				
				mMap.put("DgnpCount", count + "");
				strProjectId = (String)mMap.get("id");
				String strProjectname = (String)mMap.get("name");				
				doProject.setId(strProjectId);
				MapList mlSubTasks = (MapList)doProject.getRelatedObjects(context, // matrix context
								"Subtask", // relationship pattern
								DomainConstants.QUERY_WILDCARD, // type pattern
								slTaskSelect, // object selects
								slRelSelet, // relationship selects
								false, // to direction
								true, // from direction
								(short) 0, // recursion level
								DomainConstants.EMPTY_STRING, // object where clause
								DomainConstants.EMPTY_STRING, // relationship where clause
								0);		
				strProjectTaskIdWorks = getTaskIdUsingName(context,mlSubTasks,"Civil Works Execution");
				DomainObject doWork = DomainObject.newInstance(context, strProjectTaskIdWorks);
				String sPPercentageCompleteTillDateWork = doWork.getAttributeValue(context,"Percent Complete");
				strProjectTaskIdEquip = getTaskIdUsingName(context,mlSubTasks,"Equipments Execution");
				DomainObject doEquip = DomainObject.newInstance(context, strProjectTaskIdEquip);
				String sPPercentageCompleteTillDateEquip = doEquip.getAttributeValue(context,"Percent Complete");
				mMap.put("WorkPercent",sPPercentageCompleteTillDateWork);
				mMap.put("EquipmentPercent",sPPercentageCompleteTillDateEquip);
				
			
				StrDateFormat = (String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date5 = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date5)) + "");
				StrAdminApprovalDate=(String) mMap.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt2 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt2.parse(StrAdminApprovalDate);
			SimpleDateFormat dt3 = new SimpleDateFormat("dd-MM-yyyy");
			mMap.put("AdminApprovalDate", (dt3.format(date1)) + "");
			Double TotalWeek= Double.parseDouble((String)mMap.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			int TotalIntWeek = (int) Math.round(TotalWeek);
			
			int TotalDays = TotalIntWeek*7;
			
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mMap.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
			Date dEstimatedFinishDate = new Date(ProjectCompletesDate);
			if(dEstimatedFinishDate.compareTo(todayDate) >0)
			{
				delayed="Ontime";
				mMap.put("Delayed",delayed);
			}
			else
			{
				delayed="Delayed";
				mMap.put("Delayed",delayed);
			}
			
				
				/*Double TotalDays= Double.parseDouble((String)mMap.get("attribute[Task Estimated Duration]"));
			//System.out.println ("TotalWeek "+TotalWeek);
			int TotalIntDays = (int) Math.round(TotalDays);
			//System.out.println("TotalIntWeek" + TotalIntWeek);
			int TotalWeek = TotalIntDays/7;
			mMap.put("totalWeek", TotalWeek+"");*/
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("Delegation")) {
					mMap.put("status", "Delegation");
				} else if (strCurrent.equalsIgnoreCase("UnderExecution")) {
					mMap.put("status", "UnderExecution");
				}
				mlReturnMaplist.add(mMap);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (int j = 0; j < mlReturnMaplist.size(); j++) 
			{
				Map mMap1 = (Map) mlReturnMaplist.get(j);
				String strProjectStatus1 = (String) mMap1.get("Delayed");
				if("Ontime".equals(strProjectStatus1))
				{
					if(strProjectStatus1.contains("Ontime"))
					{
						mlReturnMaplistFinal.add(mMap1);
						continue;
					}
				}
				
				 if(!("Delayed".equals(strProjectStatus1)))
				{
					if(strProjectStatus1.contains("Delayed"))
					{
						mlReturnMaplistFinal.add(mMap1);
						continue;
					}
				}
				if(!("Completed".equals(strProjectStatus1)))
				{
					if(strProjectStatus1.contains("Completed"))
					{
						mlReturnMaplistFinal.add(mMap1);
					}
				}
			}
			
			
				
		mlReturnMaplistFinal.sortStructure("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value","descending","string");
		return mlReturnMaplistFinal;
	}
	public static String getTaskIdUsingName(Context context, MapList mlSchedule, String strTaskName) throws Exception{
		String strTaskId = "";
		try{
			Map mTemp = null;
			String strName = "";
			String strCurrent = "";
			for(int i=0;i<mlSchedule.size();i++){
				mTemp = (Map)mlSchedule.get(i);
				strName = (String)mTemp.get(DomainObject.SELECT_NAME);
				strCurrent = (String)mTemp.get(DomainObject.SELECT_CURRENT);
				if(strTaskName.equals(strName)){
					strTaskId = (String)mTemp.get(DomainObject.SELECT_ID);
					break;
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return strTaskId;
	}


}