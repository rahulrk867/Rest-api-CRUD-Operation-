import com.matrixone.apps.framework.ui.ProgramCallable;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.DomainObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;

import java.util.Map;
import java.util.Iterator;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import com.matrixone.apps.domain.util.PersonUtil;


import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.common.Person;
import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;

	public class WMSProjectsDashboards_mxJPO extends WMSConstants_mxJPO {
	/**
	 * Constructor.
	 * 
	 * @param context - the eMatrix <code>Context</code> object
	 * @param args    - holds no arguments
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 419
	 */

	public WMSProjectsDashboards_mxJPO(Context context, String[] args) throws Exception {
		super(context, args);
	}
	
	
	@ProgramCallable
	public MapList getProjectUnderExecution(Context context, String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String strWhereCondition =("from[WMSProjectSOC].to.current==UnderExecution");

		DomainObject doPerson = PersonUtil.getPersonObject(context);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		String strCurrent = " ";

		for (int i = 0 ; i <mlRelatedProjectDetails.size(); i++)
		{
			Map mTemp = (Map)mlRelatedProjectDetails.get(i);

			strCurrent = (String)mTemp.get("from[WMSProjectSOC].to.current");
			if(!strCurrent.equalsIgnoreCase("UnderExecution"))
			{
				mTemp.put("disableSelection","true");
			}
		}
			return mlRelatedProjectDetails;
	
	}
}