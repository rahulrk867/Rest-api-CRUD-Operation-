/** Name of the JPO    : wmsSORLibrary
 ** Developed by    : DSIS 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to manage all code for SOr Libraries
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/

import java.util.HashMap;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.SelectList;


import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.common.util.ComponentsUtil;
import com.matrixone.apps.framework.ui.UIUtil;

import com.matrixone.apps.library.LibraryCentralConstants;

/**
 * The purpose of this JPO is to handle functionality of SOR
 * @author DSIS
 */
public class WMSSORLibrary_mxJPO extends WMSConstants_mxJPO
{
	 
    
 

    /**
     * Constructor.
     * @param context - the eMatrix <code>Context</code> object
     * @param args - holds no arguments
     * @throws Exception if the operation fails
     * @author DSIS
     */

    public WMSSORLibrary_mxJPO(Context context, String[] args) throws Exception
    {
       super(context,args);
    }
    /**
     * This Method returns the MapList of All SOR Libraries in all states.
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments.
     * @returns MapList of Object IDs.
     * @throws Exception if the operation fails
     */

    @com.matrixone.apps.framework.ui.ProgramCallable
    public static MapList getSORLibraries(Context context, String[] args) throws Exception
    {
        String strWhere = null;
        MapList result = new MapList();
        try{

            ComponentsUtil.checkLicenseReserved(context, LibraryCentralConstants.LIB_LBC_PRODUCT_TRIGRAM);
            result= (MapList)getResult(context, TYPE_WMS_SOR_LIBRARY, strWhere);
        }catch(Exception exp){
            throw new Exception(exp.toString());
        }
        return result;
    }
    /**
     * This Method is a generic Method which uses the findObjects method of Domain Object. This method is called in all the methods which performs the
     * find objects functionality. i.e. in all the above specified methods.
     *
     * @param context the eMatrix <code>Context</code> object
     * @param strType the Type of Object on which the find objects method is called.
     * @param strWhere the Object where condition to be used while performing the find objects.
     * @returns MapList of Object IDs.
     * @throws Exception if the operation fails
     */

    public static MapList getResult(Context context, String strType, String strWhere)throws Exception
    {
        MapList result = new MapList();
        try{
            DomainObject domObj = new DomainObject();
            SelectList selectStmts = new SelectList(2);
            selectStmts.addElement(DomainObject.SELECT_ID);
            selectStmts.addElement(DomainConstants.SELECT_CURRENT);
            result= (MapList)domObj.findObjects(context, strType, DomainConstants.QUERY_WILDCARD, strWhere, selectStmts);
        }catch(Exception exp){
            exp.printStackTrace();
            throw new Exception(exp.toString());
        }
        return result;
    }

    /** 
     * Method will connect the SOR to the General class
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.PostProcessCallable
    public void connectSOR(Context context, String[] args) throws Exception {
        try {
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
            HashMap paramMap               = (HashMap)programMap.get("paramMap");
            HashMap requestMap           = (HashMap)programMap.get("requestMap");
            String strSOROID             = (String) paramMap.get("objectId");
            String strGeneralClassOID     = (String) requestMap.get("parentOID");

            if(UIUtil.isNotNullAndNotEmpty(strGeneralClassOID) && UIUtil.isNotNullAndNotEmpty(strSOROID))
            {
                DomainRelationship.connect(context, strGeneralClassOID,DomainConstants.RELATIONSHIP_CLASSIFIED_ITEM, strSOROID, true);
                DomainObject domGeneralClass = DomainObject.newInstance(context,strGeneralClassOID);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


