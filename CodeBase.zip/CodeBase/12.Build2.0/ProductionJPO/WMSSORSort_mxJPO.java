/*
**
**
*/
import java.util.Map;
import matrix.db.Context;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import matrix.db.Context;
import java.text.ParseException;
import java.text.RuleBasedCollator;
import java.util.Arrays;
import java.util.Collections;


public class WMSSORSort_mxJPO extends emxCommonBaseComparator_mxJPO
{
    private Context context;
    

    public WMSSORSort_mxJPO (Context context, String[] args) 
        throws Exception
    {
        this.context = context;
    }

    /**
     * Default Constructor.
     */

    public WMSSORSort_mxJPO ()
    {
        try {
            this.context = ContextUtil.getAnonymousContext();
        } catch (Exception e) {}
    }

    /**
     * This method used for comparing objects.
     * @param object1 Map contains column Values
     * @param object2 Map contains column Values
     * @return integer representing the comparision value
     */
    public int compare (Object object1,Object object2) 
    {
        Map map1            = (Map)object1;
        Map map2            = (Map)object2;
        Map sortKeys        = getSortKeys();
        String keyName      = (String) sortKeys.get("name");
        String keyDir       = (String) sortKeys.get("dir");
        String strTask1     = "";
        String strTask2     = "";
        strTask1            = (String) map1.get("ItemCode");
        strTask2            = (String) map2.get("ItemCode");

        if(strTask2==null)
        {
            strTask1        = (String) map1.get("Title");
            strTask2        = (String) map2.get("Title");
        }
        if(strTask2==null)
        {
            strTask1        = (String) map1.get("SOR");
            strTask2        = (String) map2.get("SOR");
        }

        boolean istaskEmpty1 = UIUtil.isNullOrEmpty(strTask1);
        boolean istaskEmpty2 = UIUtil.isNullOrEmpty(strTask2);

        /*
         * If both values are null or empty diff =  0
         * If first string is null or empty diff = -1
         * If second string is null or empty diff = 1
         * If both the strings are not empty then compare the strings
        */
        String strRule = "< a, A < b, B < c, C < d, D < e, E < f, F < g, G < h, H < i, I" +
                    "< j, J < k, K < l, L < m, M < n, N < o, O < p, P < q, Q < r, R" +
                    "< s, S < t, T < u, U < v, V < w, W < x, X < y, Y < z, Z" +
                    "<1<2<3<4<5<6<7<8<9<10<11<12<13<14<15<16<17<18<19<20<21<22<23<24<25<26<27<28<29<30<31<32<33<34<35<36<37<38<39<40<41<42<43<44<45<46<47<48<49<50"
                    + "<I<II<III<IV<V<VI<VII<VIII<IX<X<XI<XII<XIII<XIV<XV<XVI<XVII<XVIII<XIX<XX<XXI<XXII<XXIII<XXIV<XXV<XXVI<XXVII<XXVIII<XXIX<XXX<XXXI<XXXII<XXXIII<XXXIV<XXXV<XXXVI<XXXVII<XXXVIII<XXXIX<XL<XLI<XLII<XLIII<XLIV<XLV<XLVI<XLVII<XLVIII<XLIX<L"
                    + "<i<ii<iii<iv<v<vi<vii<viii<ix<x<xi<xii<xiii<xiv<xv<xvi<xvii<xviii<xix<xx<xxi<xxii<xxiii<xxiv<xxv<xxvi<xxvii<xxviii<xxix<xxx<xxxi<xxxii<xxxiii<xxxiv<xxxv<xxxvi<xxxvii<xxxviii<xxxix<xl<xli<xlii<xliii<xliv<xlv<xlvi<xlvii<xlviii<xlix<l";
        int diff = 0;
        try {
                RuleBasedCollator myCollator = new RuleBasedCollator(strRule);
                diff = myCollator.compare(strTask1,strTask2);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        return ("ascending".equals(keyDir)? diff : -diff);
    }
}
