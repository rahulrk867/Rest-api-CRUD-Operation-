/** Name of the JPO    : WMSSOR
 ** Developed by    : Matrixone 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to create a Measurement Book Entry
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/

import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;

import matrix.db.Context;
import matrix.util.SelectList;
import matrix.util.StringList;
import matrix.util.Pattern;
import matrix.db.JPO;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.domain.util.FrameworkException;

/**
 * The purpose of this JPO is to handle functionality of SOR
 * @author WMS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSSOR_mxJPO extends WMSConstants_mxJPO
{
	
    /**
     * Constructor.
     * @param context - the eMatrix <code>Context</code> object
     * @param args - holds no arguments
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */

    public WMSSOR_mxJPO(Context context, String[] args) throws Exception
    {
         super(context,args);
    }
    /** 
     * Method will promote connected SOR Items to  Plant Frozen
     * 
     * @param context the eMatrix <code>Context</code> object
     * @param args with program arguments
     *             args[0]- MBE OID
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public void promoteConnectedSORItems(Context context, String[] args) throws Exception
	{
        try {
            String strObjectId = args[0];
            String strObjectType = args[1];
            //if(LibraryCentralConstants.TYPE_GENERAL_CLASS.equals(strObjectType) &&  UIUtil.isNotNullAndNotEmpty(strObjectId))
        	if((TYPE_WMS_SOR_LIBRARY.equals(strObjectType) || TYPE_WMS_SOR_CHAPTER.equals(strObjectType)) &&  UIUtil.isNotNullAndNotEmpty(strObjectId))
            {                
                DomainObject domObjSOR = DomainObject.newInstance(context, strObjectId);
    			SelectList selListBusSelects = WMSUtil_mxJPO.getSubClassBusSelect();
    			
                MapList mapListSubClass = domObjSOR.getRelatedObjects(context, // matrix context
    					LibraryCentralConstants.RELATIONSHIP_SUBCLASS, // relationship pattern
    					LibraryCentralConstants.QUERY_WILDCARD, // type pattern
    					selListBusSelects, // object selects
    					null, // relationship selects
    					false, // to direction
    					true, // from direction
    					(short) 1, // recursion level
    					DomainConstants.SELECT_CURRENT+"=='Inactive'", // object where clause
    					DomainConstants.EMPTY_STRING, // relationship where clause
    					0);
                MapList mapListSORItems = getClassifiedItemSOR(context,domObjSOR,DomainConstants.SELECT_CURRENT+"=='Inactive'");
                DomainObject domSORItems = DomainObject.newInstance(context);
                mapListSORItems.addAll(mapListSubClass);
                Iterator<Map<String,String>>  iterator = mapListSORItems.iterator();
                Map<String,String> map  =null;
                while(iterator.hasNext())
                {
                    map = (Map<String,String>)iterator.next();
                    domSORItems.setId(map.get(DomainConstants.SELECT_ID));
                    domSORItems.promote(context);
                }

            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }
    /** 
     * Method to get SOR objects connected by ClassifiedItem
     * @param context the eMatrix <code>Context</code> object
     * @param domObj context object
     * @param strRelWhere where condition to check on particular state
     * @throws Exception if the operation fails
     * @return MapList list of SOR objects
     * @author WMS
     * @since 418
     */
    public MapList getClassifiedItemSOR(Context context,DomainObject domObj,
            String strRelWhere) throws Exception {
        MapList mlRoutes=new MapList();

        try {
            StringList busSelects = new StringList(2);
            busSelects.add(DomainConstants.SELECT_ID);
            busSelects.add(DomainConstants.SELECT_NAME);
			/*
            mlRoutes = domObj.getRelatedObjects(context,
                LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,
                    WMSDomainConstant.TYPE_SOR_ITEM, busSelects, null, false, true,
                    (short) 1, DomainConstants.EMPTY_STRING, strRelWhere, 0);
					*/
            mlRoutes = domObj.getRelatedObjects(context,
                LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,
                    "WMSSOR", busSelects, null, false, true,
                    (short) 1, strRelWhere, DomainConstants.EMPTY_STRING, 1);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return mlRoutes;
    }

	public String deleteSOR(Context context, String[] args) throws Exception
	{
		String sMessage = "";
		String sNoDeletePrivilegeSORs = "";
		String sRelWhere = DomainConstants.SELECT_NAME + "!= \"" + DomainConstants.RELATIONSHIP_CLASSIFIED_ITEM + "\"";
		for(String sSelectedRowId: args)
		{
			Map mSelectedRowDetails = ProgramCentralUtil.parseTableRowId(context, sSelectedRowId);
			String sSelectedRowOId = (String)mSelectedRowDetails.get("objectId");
			DomainObject doSOR = DomainObject.newInstance(context, sSelectedRowOId);
			String sSORName = doSOR.getAttributeValue(context, ATTRIBUTE_WMS_SOR_ITEM_NUMBER);
			MapList mlSORRelatedObjects = doSOR.getRelatedObjects(context, "*", "*", null, null, true, true, (short) 1, "", sRelWhere, 0);
			if (mlSORRelatedObjects.size() > 0) {
				if ("".equals(sNoDeletePrivilegeSORs))
					sNoDeletePrivilegeSORs = sSORName;
				else
					sNoDeletePrivilegeSORs = sNoDeletePrivilegeSORs + "\n" +sSORName;
			}
			else {
				try {
					doSOR.deleteObject(context) ;
				}
				catch(Exception e)
				{
					if ("".equals(sNoDeletePrivilegeSORs))
						sNoDeletePrivilegeSORs = sSORName;
					else
						sNoDeletePrivilegeSORs = sNoDeletePrivilegeSORs + "\n" +sSORName;
				}
			}
		}
		if (!"".equals(sNoDeletePrivilegeSORs)) {
			sMessage = "Following selected objects could not be deleted, as these SOR's has references to other instances (or) may not have delete permissions."+"\n"+sNoDeletePrivilegeSORs;
		}
		return sMessage;
	}

	
	/**
     * Method to get the connected SOR Items under the Work order 
     *
     * @mxused used as includeOID on PMCProjectTaskCreateForm SOR field search
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return mapListSORItems MapList containing the SOR Item IDs
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.IncludeOIDProgramCallable
    public StringList getWorkOrderSpecificSORIncludeProgram (Context context, String[] args) throws Exception 
    {
        StringList strListIncludeOIDs =  new StringList();
        try
        {
            MapList mapListSORItems = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
                DomainObject domObjMBE= DomainObject.newInstance(context, strObjectId);
                mapListSORItems = getWorkOrderSpecificSOR(context, domObjMBE);
				strListIncludeOIDs = WMSUtil_mxJPO.convertToStringList(mapListSORItems, DomainConstants.SELECT_ID);
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListIncludeOIDs;
    }
	
	/**
     * Function to get the SOR Items connected to the selected MBE
     *
     * @param context the eMatrix <code>Context</code> object
     * @param domObject DomainObject instance of selected Object
     * @return mapListSORItems MapList containing the MBEs connected to Work Order with ID
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
    public MapList getWorkOrderSpecificSOR(Context context, DomainObject domObject)
            throws FrameworkException {
        try
        {
            MapList mapListSORItems = new MapList();    
            SelectList selListBusSelects     = new SelectList(1);
            selListBusSelects.add(DomainConstants.SELECT_ID);
            //TODO use symbolic constants
            //selListBusSelects.add("attribute[WMSCageCode]");

            SelectList selListRelSelects     = new SelectList(1);
            selListRelSelects.add(DomainRelationship.SELECT_ID);

            String strType = domObject.getInfo(context, DomainConstants.SELECT_TYPE);
            

            if(!TYPE_WMS_WORK_ORDER.equals(strType))
            {
                String strWOOID = getParentWorkOrder(context, domObject);
                if(UIUtil.isNotNullAndNotEmpty(strWOOID))
                {
                    domObject.setId(strWOOID);
                }
            }
                mapListSORItems = domObject.getRelatedObjects(context, // matrix context
                    RELATIONSHIP_WMS_WORK_ORDER_SOR, // relationship pattern
                    TYPE_WMS_SOR, // type pattern
                    selListBusSelects, // object selects
                    selListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 1, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
            return mapListSORItems;
        }
        catch(FrameworkException frameworkException)
        {
            throw frameworkException;
        }
    }
	
	
	public String getParentWorkOrder(Context context, DomainObject domObj)
            throws FrameworkException {
        String strWOOID = DomainConstants.EMPTY_STRING;
        Pattern patternType = new Pattern(TYPE_WMS_SEGMENT);
        patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK);
        patternType.addPattern(TYPE_WMS_WORK_ORDER);
        Pattern patternRel = new Pattern(RELATIONSHIP_BILL_OF_QUANTITY);


        MapList mapListWO = domObj.getRelatedObjects(context,
                patternRel.getPattern(),                                     // relationship pattern
                patternType.getPattern(),                                    // object pattern
                true, // to direction
                false, // from direction
                (short)0,                                                      // recursion level
                new StringList(),                                                 // object selects
                null,                                                         // relationship selects
                DomainConstants.EMPTY_STRING, // object where clause
                DomainConstants.EMPTY_STRING, // relationship where clause
                (short)0,                                                      // No expand limit
                DomainConstants.EMPTY_STRING,                                // postRelPattern
                (TYPE_WMS_WORK_ORDER),                                                // postTypePattern
                null);                         
        if(mapListWO!= null && mapListWO.size()>0)
        {
            Map<String , String> mapData = (Map<String , String>)mapListWO.get(0);
            strWOOID = mapData.get(DomainConstants.SELECT_ID);
        }
        return strWOOID;
    }

	
	 /**
     * Function to get the SOR Items which are not in plan state or connected to Inactive class
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the command
     * @return strListExcludeOIDs StringList containing the SOR Items OID
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.ExcludeOIDProgramCallable
    public StringList getInactiveGeneralClassSORItems(Context context,  String[] args)
            throws Exception {
        try
        {
        	 HashMap programMap = (HashMap) JPO.unpackArgs(args);
        	 String strWoOID = (String)programMap.get("objectId");
        	 DomainObject domWO = DomainObject.newInstance(context,strWoOID);
            SelectList strListSORInfoBusSelects     = new SelectList(2);
            strListSORInfoBusSelects.add(DomainConstants.SELECT_ID);
            strListSORInfoBusSelects.add(DomainConstants.SELECT_NAME);

            String strWhere = "("+DomainConstants.SELECT_CURRENT+"==Plan)||(to["+LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM+"].from.current==Inactive)";
            MapList mapListExcludeSORItems = DomainObject.findObjects(context, 
                    TYPE_WMS_SOR, 
                    context.getVault().getName(),
                    strWhere,
                    strListSORInfoBusSelects);
            MapList mlExcludeAlreadyAddedSORItem = domWO.getRelatedObjects(context,
											                    RELATIONSHIP_WMS_WORK_ORDER_SOR,
											                    TYPE_WMS_SOR, 
											                    strListSORInfoBusSelects,
											                    null,// relationshipSelects
											                    false,//toSide
											                    true,//Fromside
											                    (short)0,
											                    DomainConstants.EMPTY_STRING,// objectWhere
											                    null, 0);
            if(!mlExcludeAlreadyAddedSORItem.isEmpty()) {
            	mapListExcludeSORItems.addAll(mlExcludeAlreadyAddedSORItem);
            }
			StringList strListExcludeOIDs = WMSUtil_mxJPO.convertToStringList(mapListExcludeSORItems, DomainConstants.SELECT_ID);
            return strListExcludeOIDs;

        }
        catch(FrameworkException frameworkException)
        {
            throw frameworkException;
        }
    }

	/**
     * Method to get the connected SOR Items under the Work order 
     *
     * @mxused used as includeOID on PMCProjectTaskCreateForm SOR field search
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return mapListSORItems MapList containing the SOR Item IDs
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.IncludeOIDProgramCallable
    public StringList getWorkOrderSpecificSORIncludeProgramForMulti (Context context, String[] args) throws Exception 
    {
        StringList strListExcludeOIDs =  new StringList();
        try
        {
            HashMap programMap      = (HashMap) JPO.unpackArgs(args);
            
            String strObjectId = (String) programMap.get("objectId");
            MapList mapListSORItems = new MapList();
            String strWOOID = (String) programMap.get("parentOID");
            
            if(UIUtil.isNotNullAndNotEmpty(strWOOID))
            {
                DomainObject domObjMBE= DomainObject.newInstance(context, strWOOID);
                mapListSORItems = getWorkOrderSpecificSOR(context, domObjMBE);
                strListExcludeOIDs = WMSUtil_mxJPO.convertToStringList(mapListSORItems, DomainConstants.SELECT_ID);
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListExcludeOIDs;
    }

	 public HashMap isSelectedWOandSec (Context context, String[] args) throws Exception 
    {
        HashMap returnMap =  new HashMap();
        try
        {
            HashMap programMap      = (HashMap) JPO.unpackArgs(args);
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return returnMap;
    }
	
	
	 /** 
     * Method get all the SOR s connected too Work Order.
     * 
     * @param context the eMatrix <code>Context</code> object
     * @param strWOOID String value containing the Work Order OID
     * @return a Map<String,String> with Key is SOR ID and value is Awarded rate
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
    private Map<String,String> getSORsAwardedRate(Context context,
            String strWOOID) throws FrameworkException
    {
        try
        {
            Map<String,String> mapData = new HashMap<String,String>();
            if(UIUtil.isNotNullAndNotEmpty(strWOOID))
            {

                DomainObject domObjWO = DomainObject.newInstance(context,strWOOID);
                StringList selListBusSelects = new StringList(DomainConstants.SELECT_ID);
                selListBusSelects.add("attribute["+ATTRIBUTE_WMS_SOR_RATE+"]");
                StringList selListRelSelects = new StringList(DomainRelationship.SELECT_ID);
                MapList mapListSORRelInfo = domObjWO.getRelatedObjects(context, // matrix context
                        RELATIONSHIP_WMS_WORK_ORDER_SOR, // relationship pattern
                        TYPE_WMS_SOR, // type pattern
                        selListBusSelects, // object selects
                        selListRelSelects, // relationship selects
                        
                        false, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        DomainConstants.EMPTY_STRING, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);

                if(mapListSORRelInfo !=null)
                {
                    int intSize = mapListSORRelInfo.size();

                    if(intSize>0)
                    {
                        Iterator<Map<String,String>> iterator = mapListSORRelInfo.iterator();
                        Map<String,String> mapObjectData ;
                        String strOID       = "";
                        String strAgreedRate="";
                        while(iterator.hasNext())
                        {
                            mapObjectData = (Map<String,String>)iterator.next();
                            strOID = mapObjectData.get(DomainConstants.SELECT_ID);
                            strAgreedRate = mapObjectData.get("attribute["+ATTRIBUTE_WMS_SOR_RATE+"]");
							double dbAgreedRate = WMSUtil_mxJPO.convertToDouble(strAgreedRate);
                            mapData.put(strOID,String.valueOf(dbAgreedRate) );
                        }
                    }
                }
            }
            return mapData;
        }
        catch(FrameworkException frameworkException)
        {
            frameworkException.printStackTrace();
            throw frameworkException;
        }
    }
	
	
	 /** 
     * Method get all the SOR s connected too Work Order.
     * 
     * @param context the eMatrix <code>Context</code> object
     * @param args with program arguments
     * @param args[0]- Work Order id
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public Map<String,String> getSORsAwardedRate(Context context, String[] args) throws Exception
    {
        HashMap programMap              = (HashMap) JPO.unpackArgs(args);
        String strSelectedId = (String)programMap.get("objectId");
        String strWOId = DomainConstants.EMPTY_STRING;
        Map<String,String> mapData = new HashMap<String,String>();
        if(UIUtil.isNotNullAndNotEmpty(strSelectedId))
        {
            DomainObject dobParent = DomainObject.newInstance(context,strSelectedId);
            String strType = (String)dobParent.getInfo(context,DomainConstants.SELECT_TYPE);
            if(!TYPE_WMS_WORK_ORDER.equals(strType))
            {
                strWOId = getParentWorkOrder(context,dobParent);
            }
            else
            {
                strWOId = strSelectedId;
            }
            mapData = getSORsAwardedRate(context, strWOId);
        }
        return mapData;
    }
	
	
	}