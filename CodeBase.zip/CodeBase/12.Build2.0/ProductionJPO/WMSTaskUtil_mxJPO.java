/** Name of the JPO    : WMSTaskUtil
 ** Developed by    :  
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to use utilities created for code.
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/
import java.util.Map;
import matrix.util.StringList;
import matrix.db.Context;
import matrix.db.JPO;
import java.util.Vector;
import java.util.HashMap;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;


/**
 * The purpose of this JPO is to use utilities created
 * @author 
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSTaskUtil_mxJPO
{
	 


    /**
     * Constructor.
     * @param context the eMatrix Context object
     * @param strArguments holds the following input arguments[0]-id of the business object
     * @throws Exception if the operation fails    
     * @since 418
     */
    public WMSTaskUtil_mxJPO (Context context, String[] args) throws Exception
    {
         //super(context,args);
    }
    /**
     * Main entry point.
     *
     * @param context
     *            the eMatrix <code>Context</code> object
     * @param args
     *            holds no arguments
     * @return an integer status code (0 = success)
     * @throws Exception
     *             if the operation fails
     * @since 418
     */
    public int mxMain(Context context, String[] args) throws Exception {
        if (!context.isConnected())
            throw new Exception("Not supported on desktop client");
        return 0;
    }


   public Vector getContents(Context context, String[] args) throws Exception 
    {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
			Map mTemp = null;
			String strTaskId = DomainConstants.EMPTY_STRING;
			DomainObject doTask = null;
			for(int i=0; i<intSize;i++){
				mTemp = (Map)objectList.get(i);
				strTaskId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
					doTask = new DomainObject(strTaskId);
					
					StringList slContectList = (StringList)doTask.getInfoList(context,"from[Route Task].to.to[Object Route].from.id");
					
					StringBuilder strUrl = new StringBuilder();
					for(int j=0;j<slContectList.size();j++){
						String strContectId = (String)slContectList.get(j);
						doTask = new DomainObject(strContectId);
						String strName = doTask.getInfo(context,DomainObject.SELECT_NAME);						
						String strLink = "../common/emxTree.jsp?objectId="+strContectId;
						strUrl.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");            
						strUrl.append(strName);
						strUrl.append("</a>");
						strUrl.append("<br/>");
					}
					vColumnValues.add(strUrl.toString());
				}else{
					vColumnValues.add(DomainConstants.EMPTY_STRING);
				}
					
			}
			
		 return vColumnValues;
		}catch (Exception e) {
            throw e;
        }
           
        }

	public StringList getQuickTaskCompleteLink(Context context, String [] args) throws Exception{
		HashMap programMap        = (HashMap) JPO.unpackArgs(args);
	    MapList relBusObjPageList = (MapList)programMap.get("objectList");
		StringList slLinks = new StringList(relBusObjPageList.size());
		String sTaskLink = "";
	    for (int i=0; i < relBusObjPageList.size(); i++) {
	         Map collMap = (Map)relBusObjPageList.get(i);
	         String sTaskType  = (String)collMap.get(DomainObject.SELECT_TYPE);
	         String sTaskId  = (String)collMap.get(DomainObject.SELECT_ID);
			 
			 System.out.println("sTaskType----"+sTaskType);
			 
			 if(UIUtil.isNotNullAndNotEmpty(sTaskId)){
				 DomainObject doTask = new DomainObject(sTaskId);
				 
				 String strContentType = (String)doTask.getInfo(context,"from[Route Task].to.to[Object Route].from.type");
				 
				 if(UIUtil.isNotNullAndNotEmpty(strContentType)){
					 if(strContentType.startsWith("DMS")){
						String routeTaskAction  = (String)collMap.get("attribute["+ DomainConstants.ATTRIBUTE_ROUTE_ACTION +"]");
						 if(routeTaskAction.equalsIgnoreCase("Approve")){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/dms_emxTaskCompletePreProcess.jsp?action=Approve&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else if((routeTaskAction.equalsIgnoreCase("Comment") || routeTaskAction.equalsIgnoreCase("Notify Only"))){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/dms_emxTaskCompletePreProcess.jsp?action=Complete&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else{
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxUserTasksSummaryLinksProcess.jsp?fromPage=Complete&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;emxTableRowId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }
						 sTaskLink  = "<a href=\"" + sTaskLink + "\">" + "<img src=\"" + "../common/images/buttonDialogDone.gif" + "\" width=\"16px\" height=\"16px\"/>" + "</a>";
						 slLinks.add(sTaskLink); 
					 }else if(strContentType.startsWith("WMS")){
						String routeTaskAction  = (String)collMap.get("attribute["+ DomainConstants.ATTRIBUTE_ROUTE_ACTION +"]");
						 if(routeTaskAction.equalsIgnoreCase("Approve")){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/wms_emxTaskCompletePreProcess.jsp?action=Approve&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else if((routeTaskAction.equalsIgnoreCase("Comment") || routeTaskAction.equalsIgnoreCase("Notify Only"))){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/wms_emxTaskCompletePreProcess.jsp?action=Complete&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else{
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxUserTasksSummaryLinksProcess.jsp?fromPage=Complete&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;emxTableRowId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }
						 sTaskLink  = "<a href=\"" + sTaskLink + "\">" + "<img src=\"" + "../common/images/buttonDialogDone.gif" + "\" width=\"16px\" height=\"16px\"/>" + "</a>";
						 slLinks.add(sTaskLink); 
					 }else{
						 String routeTaskAction  = (String)collMap.get("attribute["+ DomainConstants.ATTRIBUTE_ROUTE_ACTION +"]");
						 if(routeTaskAction.equalsIgnoreCase("Approve")){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxTaskCompletePreProcess.jsp?action=Approve&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else if((routeTaskAction.equalsIgnoreCase("Comment") || routeTaskAction.equalsIgnoreCase("Notify Only"))){
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxTaskCompletePreProcess.jsp?action=Complete&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }else{
							 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxUserTasksSummaryLinksProcess.jsp?fromPage=Complete&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;emxTableRowId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
						 }
						 sTaskLink  = "<a href=\"" + sTaskLink + "\">" + "<img src=\"" + "../common/images/buttonDialogDone.gif" + "\" width=\"16px\" height=\"16px\"/>" + "</a>";
						 slLinks.add(sTaskLink); 
						 
					 }
					 
				 }
				 
				 
			 }
			 
	         
	    }
		return slLinks;
	}
        
}

