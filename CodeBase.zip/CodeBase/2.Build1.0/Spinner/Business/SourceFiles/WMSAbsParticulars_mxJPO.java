import matrix.db.Context;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
 

 
import matrix.db.JPO;
import matrix.util.SelectList;
import matrix.util.StringList;
public class WMSAbsParticulars_mxJPO extends WMSConstants_mxJPO {
	
	
	
	public WMSAbsParticulars_mxJPO(Context context,String[] args) {
		
		super(context,args);
		
	}
	  
	
	public Vector getPreviewBillSincePreviousBillAmount(Context context, String[] args) throws Exception {
		try {
			Map programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			
			Iterator<Map<String, String>> iteratorMap = objectList.iterator();
			Map<String, String> mapObjectData = new HashMap<String, String>();
			String strSubmittedMBEQty = DomainConstants.EMPTY_STRING;
			String strCurrentEntryQty = DomainConstants.EMPTY_STRING;
			String strReduceRate = DomainConstants.EMPTY_STRING;
			String strPaidTillDateQty= DomainConstants.EMPTY_STRING;
			String strUpToAmount= DomainConstants.EMPTY_STRING;
			String strMBCurrentState = DomainConstants.EMPTY_STRING;
			double doubleSubmittedMBEQty = 0d;
			double doubleCurrentEntryQty = 0d;
			double doubleUpToQty = 0d;
			double doublePaidQty = 0d;
			double fUpToAmount = 0d;
			double fReduceRate = 0d;
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			while (iteratorMap.hasNext()) {
				mapObjectData = iteratorMap.next();
				strSubmittedMBEQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
				strCurrentEntryQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
				strPaidTillDateQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
				strMBCurrentState  = mapObjectData.get("MBCurrent");
				doubleSubmittedMBEQty = WMSUtil_mxJPO.convertToDouble(strSubmittedMBEQty);
				doubleCurrentEntryQty = WMSUtil_mxJPO.convertToDouble(strCurrentEntryQty);
				doublePaidQty =  WMSUtil_mxJPO.convertToDouble(strPaidTillDateQty);
				
				if("Submitted".equals(strMBCurrentState))
                {
                 if(doublePaidQty>0){
                        doubleUpToQty = (doubleSubmittedMBEQty-doublePaidQty )+ doubleCurrentEntryQty;
                    }else{
                        doubleUpToQty = doubleCurrentEntryQty;
                    }
                }
                else
                {
                    doubleUpToQty = doubleCurrentEntryQty;
                }
				
				
				strReduceRate = mapObjectData.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				fReduceRate = WMSUtil_mxJPO.convertToDouble(strReduceRate);
				fUpToAmount = doubleUpToQty*fReduceRate;
				
				
				strUpToAmount  = new BigDecimal(fUpToAmount).toPlainString();
				vecResponse.add(strUpToAmount);
			}
			
			return vecResponse;
		} catch (Exception exception) {
			System.out.println("Exception in getSNOColumn method of JPO WMSBillReduction");
			exception.printStackTrace();
			throw exception;
		}
	}
	
	
	
	
	public Vector getPreviewBillUpToDateQty(Context context, String[] args) throws Exception {
		try {
			Map programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Iterator<Map<String, String>> iteratorMap = objectList.iterator();
			Map<String, String> mapObjectData = new HashMap<String, String>();
			String strSubmittedMBEQty = DomainConstants.EMPTY_STRING;
			String strCurrentEntryQty = DomainConstants.EMPTY_STRING;
			String strMBCurrentState = DomainConstants.EMPTY_STRING;
			double doubleSubmittedMBEQty = 0d;
			double doubleCurrentEntryQty = 0d;
			double doubleUpToQty = 0d;
			
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			while (iteratorMap.hasNext()) 
			{
				mapObjectData = iteratorMap.next();
				strSubmittedMBEQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
				strCurrentEntryQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
				strMBCurrentState = mapObjectData.get("MBCurrent");
				doubleSubmittedMBEQty = WMSUtil_mxJPO.convertToDouble(strSubmittedMBEQty);
				doubleCurrentEntryQty = WMSUtil_mxJPO.convertToDouble(strCurrentEntryQty);
				if("Submitted".equals(strMBCurrentState))
				{
					doubleUpToQty = doubleSubmittedMBEQty;
				}
				else
				{
				doubleUpToQty = (doubleSubmittedMBEQty )+ doubleCurrentEntryQty;
				}
				String strUpToQty  = new BigDecimal(doubleUpToQty).toPlainString();
				vecResponse.add(strUpToQty);
			}
			return vecResponse;
		} catch (Exception exception) {
			System.out.println("Exception in getSNOColumn method of JPO WMSBillReduction");
			exception.printStackTrace();
			throw exception;
		}
	}
	
	
	
	public Vector getPreviewBillUpToDateAmount(Context context, String[] args) throws Exception {
		try {
			Map programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			
			Iterator<Map<String, String>> iteratorMap = objectList.iterator();
			Map<String, String> mapObjectData = new HashMap<String, String>();
			String strSubmittedMBEQty = DomainConstants.EMPTY_STRING;
			String strCurrentEntryQty = DomainConstants.EMPTY_STRING;
			String strReduceRate = DomainConstants.EMPTY_STRING;
			String strUpToAmount = DomainConstants.EMPTY_STRING;
			String strMBCurrentState = DomainConstants.EMPTY_STRING;
			double doubleSubmittedMBEQty = 0d;
			double doubleCurrentEntryQty = 0d;
			double doubleUpToQty = 0d;
			double fUpToAmount = 0d;
			double fReduceRate = 0d;
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			while (iteratorMap.hasNext()) {
				mapObjectData = iteratorMap.next();
				strSubmittedMBEQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
				strCurrentEntryQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
				strMBCurrentState = mapObjectData.get("MBCurrent");
				doubleSubmittedMBEQty = WMSUtil_mxJPO.convertToDouble(strSubmittedMBEQty);
				doubleCurrentEntryQty = WMSUtil_mxJPO.convertToDouble(strCurrentEntryQty);
				if("Submitted".equals(strMBCurrentState))
				{
					doubleUpToQty = doubleSubmittedMBEQty;
				}
				else
				{
				doubleUpToQty = (doubleSubmittedMBEQty )+ doubleCurrentEntryQty;
				}
				strReduceRate = mapObjectData.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				fReduceRate = WMSUtil_mxJPO.convertToDouble(strReduceRate);
				fUpToAmount = doubleUpToQty*fReduceRate;
				strUpToAmount  = new BigDecimal(fUpToAmount).toPlainString();
				//strUpToAmount = Long.toString((long) fUpToAmount);
				vecResponse.add(strUpToAmount);
			}
			
			return vecResponse;
		} catch (Exception exception) {
			System.out.println("Exception in getSNOColumn method of JPO WMSBillReduction");
			exception.printStackTrace();
			throw exception;
		}
	}	
		
		public Vector getPreviewBillSincePreviousBillQuantity(Context context, String[] args) throws Exception {
			try {
				Map programMap = (Map) JPO.unpackArgs(args);
				MapList objectList = (MapList) programMap.get("objectList");
				
				Iterator<Map<String, String>> iteratorMap = objectList.iterator();
				Map<String, String> mapObjectData = new HashMap<String, String>();
				String strSubmittedMBEQty = DomainConstants.EMPTY_STRING;
				String strCurrentEntryQty = DomainConstants.EMPTY_STRING;
				String strPaidTillDateQty= DomainConstants.EMPTY_STRING;
				String strMBCurrentState = DomainConstants.EMPTY_STRING;
				String strSinceAmount = DomainConstants.EMPTY_STRING;
				double doubleSubmittedMBEQty = 0d;
				double doubleCurrentEntryQty = 0d;
				double doubleUpToQty = 0d;
				double doublePaidQty = 0d;
				
				int intSize = objectList.size();
				Vector vecResponse = new Vector(intSize);
				while (iteratorMap.hasNext()) {
					mapObjectData = iteratorMap.next();
					doubleSubmittedMBEQty = 0d;
		            doubleCurrentEntryQty = 0d;
		            doubleUpToQty = 0d;
		            doublePaidQty = 0d;
					strSubmittedMBEQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
					strCurrentEntryQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
					strPaidTillDateQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"].value");
					strMBCurrentState = mapObjectData.get("MBCurrent");
					doubleSubmittedMBEQty = WMSUtil_mxJPO.convertToDouble(strSubmittedMBEQty);
					doubleCurrentEntryQty = WMSUtil_mxJPO.convertToDouble(strCurrentEntryQty);
					doublePaidQty =  WMSUtil_mxJPO.convertToDouble(strPaidTillDateQty);
					if("Submitted".equals(strMBCurrentState))
					{
					 if(doublePaidQty>0){
					        doubleUpToQty = (doubleSubmittedMBEQty-doublePaidQty )+ doubleCurrentEntryQty;
					    }else{
					        doubleUpToQty = doubleCurrentEntryQty;
					    }
					}
					else
					{
						doubleUpToQty = doubleCurrentEntryQty;
					}
					
					strSinceAmount  = new BigDecimal(doubleUpToQty).toPlainString();
					
					vecResponse.add(strSinceAmount);
					
				}
				
				return vecResponse;
			} catch (Exception exception) {
				System.out.println("Exception in getSNOColumn method of JPO WMSBillReduction");
				exception.printStackTrace();
				throw exception;
			}
		}
		public Vector getUpToDateQty(Context context, String[] args) throws Exception {
			try {
				Map programMap = (Map) JPO.unpackArgs(args);
				MapList objectList = (MapList) programMap.get("objectList");
				
				Iterator<Map<String, String>> iteratorMap = objectList.iterator();
				Map<String, String> mapObjectData = new HashMap<String, String>();
				String strMBEQty = DomainConstants.EMPTY_STRING;
				String strTillDateQty = DomainConstants.EMPTY_STRING;
				double doubleUpToQty = 0d;
				double doubleMBEQty = 0d;
				double doubleTillDateQty = 0d;
				
				int intSize = objectList.size();
				Vector vecResponse = new Vector(intSize);
				while (iteratorMap.hasNext()) 
				{
					mapObjectData = iteratorMap.next();
					strMBEQty = mapObjectData.get("attribute[WMSMBEActivityQuantity].value");
					strTillDateQty = mapObjectData.get("attribute[WMSQtyPaidTillDate].value");
					doubleMBEQty = WMSUtil_mxJPO.convertToDouble(strMBEQty);
					doubleTillDateQty = WMSUtil_mxJPO.convertToDouble(strTillDateQty);
					doubleUpToQty = doubleMBEQty + doubleTillDateQty;
					String strUpToQty  = new BigDecimal(doubleUpToQty).toPlainString();
					vecResponse.add(strUpToQty);
				}
				return vecResponse;
			} catch (Exception exception) {
				System.out.println("Exception in getUpToDateQty method of JPO WMSAbsParticulars");
				exception.printStackTrace();
				throw exception;
			}
		}
		public Vector getUpToDateAmount(Context context, String[] args) throws Exception {
			try {
				Map programMap = (Map) JPO.unpackArgs(args);
				MapList objectList = (MapList) programMap.get("objectList");
				Iterator<Map<String, String>> iteratorMap = objectList.iterator();
				Map<String, String> mapObjectData = new HashMap<String, String>();
				String strMBEQty = DomainConstants.EMPTY_STRING;
				String strTillDateQty = DomainConstants.EMPTY_STRING;
				String strReduceRate = DomainConstants.EMPTY_STRING;
				String strUpToAmount = DomainConstants.EMPTY_STRING;
				
				double fUpToAmount = 0d;
				double fUpToQty = 0d;
				double fMBEQty = 0d;
				double fTillDateQty = 0d;
				double fReduceRate = 0d;
				int intSize = objectList.size();
				Vector vecResponse = new Vector(intSize);
				while (iteratorMap.hasNext()) {
					mapObjectData = iteratorMap.next();
					strMBEQty = mapObjectData.get("attribute[WMSMBEActivityQuantity].value");
					strTillDateQty = mapObjectData.get("attribute[WMSQtyPaidTillDate].value");
					strReduceRate = mapObjectData.get("attribute[WMSReducedSORRate].value");
					fReduceRate = WMSUtil_mxJPO.convertToDouble(strReduceRate);
					fMBEQty = WMSUtil_mxJPO.convertToDouble(strMBEQty);
					fTillDateQty = WMSUtil_mxJPO.convertToDouble(strTillDateQty);
					fUpToQty = fMBEQty + fTillDateQty;
					fUpToAmount = fUpToQty * fReduceRate;
					strUpToAmount = new BigDecimal(fUpToAmount).toPlainString();
					
					vecResponse.add(strUpToAmount);
					
				}
				
				return vecResponse;
			} catch (Exception exception) {
				System.out.println("Exception in getUpToDateAmount method of JPO WMSAbsParticulars");
				exception.printStackTrace();
				throw exception;
			}
		}
		
		public Vector getSincePreviousBillQuantity(Context context, String[] args) throws Exception {
			try {
				Map programMap = (Map) JPO.unpackArgs(args);
				MapList objectList = (MapList) programMap.get("objectList");
				
				Iterator<Map<String, String>> iteratorMap = objectList.iterator();
				Map<String, String> mapObjectData = new HashMap<String, String>();
				String strSinceQty = DomainConstants.EMPTY_STRING;
				int intSize = objectList.size();
				Vector vecResponse = new Vector(intSize);
				while (iteratorMap.hasNext()) {
					mapObjectData = iteratorMap.next();
					strSinceQty = mapObjectData.get("attribute[WMSMBEActivityQuantity].value");
					vecResponse.add(strSinceQty);
				}
				
				return vecResponse;
			} catch (Exception exception) {
				System.out.println("Exception in getSincePreviousBillQuantity method of JPO WMSAbsParticulars");
				exception.printStackTrace();
				throw exception;
			}
		}
		
		public Vector getSincePreviousBillAmount(Context context, String[] args) throws Exception {
			try {
				Map programMap = (Map) JPO.unpackArgs(args);
				MapList objectList = (MapList) programMap.get("objectList");
				
				Iterator<Map<String, String>> iteratorMap = objectList.iterator();
				Map<String, String> mapObjectData = new HashMap<String, String>();
				String strMBEQty = DomainConstants.EMPTY_STRING;
				String strReduceRate = DomainConstants.EMPTY_STRING;
				String strSinceAmount = DomainConstants.EMPTY_STRING;
				double fSinceAmount = 0d;
				double fMBEQty = 0d;
				double fReduceRate = 0d;
				
				int intSize = objectList.size();
				Vector vecResponse = new Vector(intSize);
				while (iteratorMap.hasNext()) {
					mapObjectData = iteratorMap.next();
					strMBEQty = mapObjectData.get("attribute[WMSMBEActivityQuantity].value");
					strReduceRate = mapObjectData.get("attribute[WMSReducedSORRate].value");
					fMBEQty = WMSUtil_mxJPO.convertToDouble(strMBEQty);
					fReduceRate = WMSUtil_mxJPO.convertToDouble(strReduceRate);
					fSinceAmount = fMBEQty * fReduceRate;
					
					//strSinceAmount = String.valueOf(fSinceAmount);
					//strSinceAmount = Long.toString((long) fSinceAmount);
					  strSinceAmount = new BigDecimal(fSinceAmount).toPlainString();
					vecResponse.add(strSinceAmount);
					
				}
				
				return vecResponse;
			} catch (Exception exception) {
				System.out.println("Exception in getSNOColumn method of JPO WMSBillReduction");
				exception.printStackTrace();
				throw exception;
			}
		}
		@com.matrixone.apps.framework.ui.ProgramCallable
		public MapList getObjOnSinceQty(Context context, String[] args) throws Exception{
			try 
			{
				MapList mapListDisplayMBE = new MapList();
				HashMap programMap = (HashMap)JPO.unpackArgs(args);
				String strAbstractMBEOID = (String) programMap.get("parentOID");
				String strItemOID = (String) programMap.get("objectId");
				String strRelID =(String) programMap.get("relId");
				if(strItemOID.equals(strAbstractMBEOID) && UIUtil.isNotNullAndNotEmpty(strRelID))
				{
					strAbstractMBEOID = getAbsMBEOIDFromRelOID(context,strRelID);
				}
				if(UIUtil.isNotNullAndNotEmpty(strItemOID)&& UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID)&&!strItemOID.equals(strAbstractMBEOID))
				{
					StringList strListAbsMBEInfo = new StringList(1);
					String strWoIdSelect = "relationship["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id";
					String strAttibuteSelect = "attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"]";
					strListAbsMBEInfo.add(strWoIdSelect);
					strListAbsMBEInfo.add(strAttibuteSelect);
					DomainObject domABSMbeObj = DomainObject.newInstance(context, strAbstractMBEOID);
					Map<String, String> mapAMB = domABSMbeObj.getInfo(context, strListAbsMBEInfo);
		 			String strWOId =  DomainConstants.EMPTY_STRING;   
					String strSequenceOrder =  DomainConstants.EMPTY_STRING;   
					strWOId = mapAMB.get(strWoIdSelect);
					strSequenceOrder = mapAMB.get(strAttibuteSelect);
					if(UIUtil.isNotNullAndNotEmpty(strWOId)&&UIUtil.isNotNullAndNotEmpty(strItemOID))
					{
						StringList strListAbsMBEIDs = getAbsMBEsBasedOnSequence(context, strWOId, strSequenceOrder);
			 			mapListDisplayMBE = getItemMBEsSinceQty(context, strItemOID, strListAbsMBEIDs);
						 
					}
				}
			 		return mapListDisplayMBE;
			} catch (Exception exception) {
				System.out.println("Exception in getObjOnSinceQty method of JPO WMSBillReduction");
				exception.printStackTrace();
				throw exception;
			}
		}
		private String getAbsMBEOIDFromRelOID(Context context,
				String strRelID)
						throws FrameworkException 
		{
			try
			{
				String[] strRelIDs = {strRelID};
				String strAbstractMBEOID = DomainConstants.EMPTY_STRING;
				SelectList selListRelInfo = new SelectList(2);
				selListRelInfo.add("to.id");
				selListRelInfo.add("from.id");
				MapList mapListRelInfo = DomainRelationship.getInfo(context, strRelIDs, selListRelInfo);
				Iterator<Map<String,String>> iteratorRelInfo = mapListRelInfo.iterator();
				while(iteratorRelInfo.hasNext())
				{
					Map<String,String> mapRelInfo = iteratorRelInfo.next();
					strAbstractMBEOID = mapRelInfo.get("from.id");
				}
				return strAbstractMBEOID;
			}
			catch(FrameworkException frameworkException)
			{
				frameworkException.printStackTrace();
				throw frameworkException;
			}
		}
		private StringList getAbsMBEsBasedOnSequence(Context context,
				String strWOId, String strSequenceOrder) throws FrameworkException {
			try
			{
				DomainObject domWOObj = DomainObject.newInstance(context, strWOId);
				String strBusWhere = "attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"] <="+strSequenceOrder;
				StringList strBusSelect = new StringList(1);
				strBusSelect.add(DomainConstants.SELECT_ID);
				StringList strRelSelect = new StringList(1);
				strRelSelect.add(DomainRelationship.SELECT_ID);
				MapList mapRelatedABs = domWOObj.getRelatedObjects(context, // matrix
						// context
						RELATIONSHIP_WORKORDER_ABSTRACT_MBE, // relationship pattern
						TYPE_ABSTRACT_MBE, // type pattern
						strBusSelect, // object selects
						strRelSelect, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						strBusWhere, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
				StringList strListAbsMBEIDs= WMSUtil_mxJPO.convertToStringList(mapRelatedABs, DomainConstants.SELECT_ID);
				return strListAbsMBEIDs;
					}
			catch(FrameworkException frameworkException)
			{
				frameworkException.printStackTrace();
				throw frameworkException;
			}
		}
		private MapList getItemMBEsSinceQty(Context context, String strItemOID,
				StringList strListAbsMBEIDs) throws FrameworkException {
			try
			{
				MapList mapListDisplayMBE = new MapList();
				DomainObject domItemObj = DomainObject.newInstance(context, strItemOID);
				StringList strBusSelect = new StringList(2);
				strBusSelect.add(DomainConstants.SELECT_ID);
				StringList strRelSelects = new StringList(2);
				strRelSelects.add(DomainRelationship.SELECT_ID);
						strRelSelects.add("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"]");
						strRelSelects.add("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
						MapList mapRelatedABSOfItem = domItemObj.getRelatedObjects(context, // matrix
						        // context
								RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship pattern
						        TYPE_WMS_MEASUREMENT_BOOK_ENTRY, // type pattern
								strBusSelect, // object selects
						        strRelSelects, // relationship selects
						        true, // to direction
						        false, // from direction
						        (short) 1, // recursion level
						        DomainConstants.EMPTY_STRING, // object where clause
						        DomainConstants.EMPTY_STRING, // relationship where clause
						        0);
						Map<String, String> mapData;
					 	Iterator<Map<String, String>> iterator = mapRelatedABSOfItem.iterator();
						String strAbsMBOID = DomainConstants.EMPTY_STRING;
						while(iterator.hasNext()){
							mapData = iterator.next();
							strAbsMBOID = mapData.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"]");
							
					if(UIUtil.isNotNullAndNotEmpty(strAbsMBOID)&&strListAbsMBEIDs.contains(strAbsMBOID)){
								mapListDisplayMBE.add(mapData);
							}
						}
					 
				return mapListDisplayMBE;
			}
			catch(FrameworkException frameworkException)
			{
				frameworkException.printStackTrace();
				throw frameworkException;
			}
		}
		
		
		public Vector getTillDateQty(Context context, String[] args) throws Exception {
			try {
				Map programMap = (Map) JPO.unpackArgs(args);
				MapList objectList = (MapList) programMap.get("objectList");
				
				Iterator<Map<String, String>> iteratorMap = objectList.iterator();
				Map<String, String> mapObjectData = new HashMap<String, String>();
				String strTillDateQty = DomainConstants.EMPTY_STRING;
				double doubleTillDateQty = 0d;
				
				int intSize = objectList.size();
				Vector vecResponse = new Vector(intSize);
				while (iteratorMap.hasNext()) 
				{
					mapObjectData = iteratorMap.next();
					strTillDateQty = mapObjectData.get("attribute[WMSQtyPaidTillDate].value");
					doubleTillDateQty = WMSUtil_mxJPO.convertToDouble(strTillDateQty);
					strTillDateQty  = new BigDecimal(doubleTillDateQty).toPlainString();
					vecResponse.add(strTillDateQty);
				}
				return vecResponse;
			} catch (Exception exception) {
				System.out.println("Exception in getUpToDateQty method of JPO WMSAbsParticulars");
				exception.printStackTrace();
				throw exception;
			}
		}
		public Vector getTillDateAmount(Context context, String[] args) throws Exception {
			try {
				Map programMap = (Map) JPO.unpackArgs(args);
				MapList objectList = (MapList) programMap.get("objectList");
				Iterator<Map<String, String>> iteratorMap = objectList.iterator();
				Map<String, String> mapObjectData = new HashMap<String, String>();
				String strTillDateQty = DomainConstants.EMPTY_STRING;
				String strReduceRate = DomainConstants.EMPTY_STRING;
				double fTillDateQty = 0d;
				double fReduceRate = 0d;
				int intSize = objectList.size();
				Vector vecResponse = new Vector(intSize);
				while (iteratorMap.hasNext()) {
					mapObjectData = iteratorMap.next();
					strTillDateQty = mapObjectData.get("attribute[WMSQtyPaidTillDate].value");
					strReduceRate = mapObjectData.get("attribute[WMSReducedSORRate].value");
					fReduceRate = WMSUtil_mxJPO.convertToDouble(strReduceRate);
					fTillDateQty = WMSUtil_mxJPO.convertToDouble(strTillDateQty);
					strTillDateQty = new BigDecimal(fTillDateQty * fReduceRate).toPlainString();
					vecResponse.add(strTillDateQty);					
				}
				
				return vecResponse;
			} catch (Exception exception) {
				System.out.println("Exception in getUpToDateAmount method of JPO WMSAbsParticulars");
				exception.printStackTrace();
				throw exception;
			}
		}

		@com.matrixone.apps.framework.ui.ProgramCallable
		public MapList getObjOnTillQty(Context context, String[] args) throws Exception{
			try 
			{
				MapList mapListDisplayMBE = new MapList();
				HashMap programMap = (HashMap)JPO.unpackArgs(args);
				String strAbstractMBEOID = (String) programMap.get("parentOID");
				String strItemOID = (String) programMap.get("objectId");
				String strRelID =(String) programMap.get("relId");
				if(strItemOID.equals(strAbstractMBEOID) && UIUtil.isNotNullAndNotEmpty(strRelID))
				{
					strAbstractMBEOID = getAbsMBEOIDFromRelOID(context,strRelID);
				}
				if(UIUtil.isNotNullAndNotEmpty(strItemOID)&& UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID)&&!strItemOID.equals(strAbstractMBEOID))
				{
					StringList strListAbsMBEInfo = new StringList(1);
					String strWoIdSelect = "relationship["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id";
					String strAttibuteSelect = "attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"]";
					strListAbsMBEInfo.add(strWoIdSelect);
					strListAbsMBEInfo.add(strAttibuteSelect);
					DomainObject domABSMbeObj = DomainObject.newInstance(context, strAbstractMBEOID);
					Map<String, String> mapAMB = domABSMbeObj.getInfo(context, strListAbsMBEInfo);
		 			String strWOId =  DomainConstants.EMPTY_STRING;   
					String strSequenceOrder =  DomainConstants.EMPTY_STRING;   
					strWOId = mapAMB.get(strWoIdSelect);
					strSequenceOrder = mapAMB.get(strAttibuteSelect);
					int iSeq = Integer.valueOf(strSequenceOrder);
					if(iSeq >=1){
						strSequenceOrder = String.valueOf(iSeq-1);
					}
					if(UIUtil.isNotNullAndNotEmpty(strWOId)&&UIUtil.isNotNullAndNotEmpty(strItemOID))
					{
						StringList strListAbsMBEIDs = getAbsMBEsBasedOnSequence(context, strWOId, strSequenceOrder);
			 			mapListDisplayMBE = getItemMBEsSinceQty(context, strItemOID, strListAbsMBEIDs);
						 
					}
				}
			 		return mapListDisplayMBE;
			} catch (Exception exception) {
				System.out.println("Exception in getObjOnSinceQty method of JPO WMSBillReduction");
				exception.printStackTrace();
				throw exception;
			}
		}
		
		}
