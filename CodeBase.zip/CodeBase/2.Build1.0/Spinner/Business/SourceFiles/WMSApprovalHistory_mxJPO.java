/**
 *  WMSApprovalHistory.java
 *
 * (c) Dassault Systemes, 1993 - 2017. All rights reserved.
 * This program contains proprietary and trade secret information of
 * ENOVIA MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
 import java.util.Map;
 import java.util.Iterator;
 import java.util.Vector;
 import java.util.HashMap;
 
 import matrix.db.Context;
 import matrix.db.JPO;
 import matrix.util.StringList;
 import matrix.util.Pattern;
 
 import com.matrixone.apps.domain.util.MapList;
 import com.matrixone.apps.domain.DomainRelationship;
 import com.matrixone.apps.domain.DomainConstants;
 import com.matrixone.apps.domain.DomainObject;
 import com.matrixone.apps.domain.util.PropertyUtil;
 import com.matrixone.apps.domain.util.EnoviaResourceBundle;
 import com.matrixone.apps.framework.ui.UIUtil;
 
 /**
 * This JPO includes the code related to the Approval History Functionality
 */
public class WMSApprovalHistory_mxJPO extends WMSConstants_mxJPO
{

 /**
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments
     * @throws Exception if the operation fails
     * @grade 0
     */
    public WMSApprovalHistory_mxJPO (Context context, String[] args) throws Exception
    {
		 super(context, args);
    }

	
	  /**
     * Method is used to populate the data for Approval History page
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args The packed argument for JPO, containing the program map.
     *             This program map will have request parameter information, objectId and information about the UI table object.
     * @return MapList of data
     * @throws Exception
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getAllApprovedTask(Context context, String[] args) throws Exception {
		MapList mlInboxTask = new MapList();
		MapList returnList = new MapList();
        try {
			Pattern includeType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
			// Get object list information from packed arguments
            Map programMap = (Map) JPO.unpackArgs(args);
            // Get object id
            String strObjectId = (String)programMap.get("objectId");
			
			StringList objectList = new StringList();
			objectList.addElement(DomainConstants.SELECT_ID);
			objectList.addElement(DomainConstants.SELECT_TYPE);
			objectList.addElement(DomainConstants.SELECT_CURRENT);
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_FIRST_NAME+"]");
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.id");
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_LAST_NAME+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ROUTE_TASK_USER+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_APPROVAL_STATUS+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
			//Added by ravi
			objectList.addElement("format.file.name");
			objectList.addElement("format.file.format");
			objectList.addElement("format.file.fileid");
			
			
			StringList relList = new StringList();
			relList.addElement(DomainRelationship.SELECT_ID);
			relList.addElement("attribute[Route Base State].value");

			DomainObject dObject = DomainObject.newInstance(context,strObjectId);

			MapList mlRoutes = dObject.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_OBJECT_ROUTE,  //String relPattern
					DomainConstants.TYPE_ROUTE, //String typePattern
					objectList,            //StringList objectSelects,
					relList,    		   //StringList relationshipSelects,
					false,                  //boolean getTo,
					true,                  //boolean getFrom,
					(short)1,              //short recurseToLevel,
					"",   				   //String objectWhere,
					//"attribute[Route Base State].value == state_Review",             //String relationshipWhere,
					"",             //String relationshipWhere,
					0);        
			Map mTemp = null;
			String strRouteId = DomainConstants.EMPTY_STRING;
			DomainObject doRoute = null;
			for(int i=0;i<mlRoutes.size();i++){
				mTemp = (Map)mlRoutes.get(i);
				strRouteId = (String)mTemp.get(DomainObject.SELECT_ID);
				doRoute = new DomainObject(strRouteId);
				MapList mlRouteTasks = doRoute.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_ROUTE_TASK,  //String relPattern
					DomainConstants.TYPE_INBOX_TASK, //String typePattern
					objectList,            //StringList objectSelects,
					relList,    		   //StringList relationshipSelects,
					true,                  //boolean getTo,
					false,                  //boolean getFrom,
					(short)1,              //short recurseToLevel,
					"",   				   //String objectWhere,
					"",             //String relationshipWhere,
					0); 
				mlInboxTask.addAll(mlRouteTasks);
			}
			
		Iterator itr = mlInboxTask.iterator();
		while(itr.hasNext()){
			Map returnMap = (Map)itr.next();
			String strState = (String)returnMap.get(DomainConstants.SELECT_CURRENT);
			if(strState != null && !"".equals(strState) && strState.equals("Complete")){
				returnList.add(returnMap);
			}
		}			
			
		} catch (Exception e){
		
		}
		returnList.sort("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]","ascending","date");
		return returnList;
	}
	
	 /**
     * Gets Task Or Signature For Approvals Table
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed arguments having table data
     * @return The vector containing values for this column
     * @throws Exception
     */
    public  Vector getPersonFirstAndLastName(Context context, String[] args) throws Exception {
		// Create result vector
		Vector vecResult = new Vector();
        try {
			// Get object list information from packed arguments
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList)programMap.get("objectList");
			
			Iterator itr = objectList.iterator();
			while(itr.hasNext()){
				Map objectMap = (Map)itr.next();
				String strFirstName = (String) objectMap.get("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_FIRST_NAME+"]");
				String strLastName = (String) objectMap.get("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_LAST_NAME+"]");
				String strName = strFirstName+" "+strLastName;
				vecResult.add(strName);
			}
	
		} catch (Exception e){
			e.printStackTrace();
		}
		return vecResult;
	}
	
	/**
     * Gets Task Or Signature For Approvals Table
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed arguments having table data
     * @return The vector containing values for this column
     * @throws Exception
     */
    public  Vector getSNo(Context context, String[] args) throws Exception {
		// Create result vector
		Vector vecResult = new Vector();
        try {
			// Get object list information from packed arguments
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList)programMap.get("objectList");
			int count = 0;
			for(int i=0; i< objectList.size(); i++){
				count++;
				String strCount = String.valueOf(count);
				vecResult.add(strCount);
			}
			
		} catch (Exception e){
			e.printStackTrace();
		}
		return vecResult;
	}
	
	/**
     * Gets Task Or Signature For Approvals Table
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed arguments having table data
     * @return The vector containing values for this column
     * @throws Exception
     */
    public  StringList getRole(Context context, String[] args) throws Exception {
		// Create result vector
		StringList vecResult = new StringList();
        try {
			// Get object list information from packed arguments
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList)programMap.get("objectList");
			Iterator itr = objectList.iterator();
			while(itr.hasNext()){
				Map objectMap = (Map)itr.next();
				String strPersonId = (String)objectMap.get("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.id");
				if(UIUtil.isNotNullAndNotEmpty(strPersonId)){
					DomainObject doPerson = new DomainObject(strPersonId);
					String strRole = (String)doPerson.getAttributeValue(context,ATTRIBUTE_HOST_ROLE);
					if(UIUtil.isNotNullAndNotEmpty(strRole)){
						vecResult.add(strRole);
					}else{
						vecResult.add(DomainConstants.EMPTY_STRING);
					}
				}
				
			}
		} catch (Exception e){
			e.printStackTrace();
		}
		return vecResult;
	}
	
	/**
     * Gets Task Or Signature For Approvals Table
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed arguments having table data
     * @return The vector containing values for this column
     * @throws Exception
     */
    public  Vector getApprovalStatus(Context context, String[] args) throws Exception {
		// Create result vector
		Vector vecResult = new Vector();
		String strApproved = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.AMB.Label.Approved");
		String strRejected = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.AMB.Label.Rejected");
        try {
			// Get object list information from packed arguments
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList)programMap.get("objectList");
			Iterator itr = objectList.iterator();
			while(itr.hasNext()){
				StringBuffer output = new StringBuffer();
				Map objectMap = (Map)itr.next();
				String strApprovalStatus = (String)objectMap.get("attribute["+DomainConstants.ATTRIBUTE_APPROVAL_STATUS+"]");
				if (strApprovalStatus != null && !"".equals(strApprovalStatus) && strApprovalStatus.equals("Approve")){
					strApprovalStatus = strApproved;
				} else if (strApprovalStatus != null && !"".equals(strApprovalStatus) && strApprovalStatus.equals("Reject")){
					strApprovalStatus = strRejected;
				}else {
					strApprovalStatus="Pending";
				}
				vecResult.add(strApprovalStatus);
			}
		} catch (Exception e){
			e.printStackTrace();
		}
		return vecResult;
	}
	
	public StringList showColorForRejected(Context context, String[] args)  throws Exception 
	{
		try 
		{
			StringList slOutput = new StringList();
			// Get object list information from packed arguments
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for (Iterator itrTableRows = objectList.iterator(); itrTableRows.hasNext();)
			{
				Map mapObjectInfo = (Map) itrTableRows.next();
				String strApprovalStatus = (String)mapObjectInfo.get("attribute["+DomainConstants.ATTRIBUTE_APPROVAL_STATUS+"]");
				if (strApprovalStatus != null && !"".equals(strApprovalStatus) && strApprovalStatus.equals("Reject")){
					slOutput.addElement("PaymentMilestoneRedBackGroundColor");
				}
				else {
					slOutput.addElement("");
				}
			}
			return slOutput;
		} catch (Exception exp) {
			exp.printStackTrace();
			throw exp;
		}
	}
	
}