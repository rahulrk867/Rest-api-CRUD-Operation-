/** Name of the JPO     : WMSBOQSubItems_mxJPO
 ** Developed by        : AurionPro Team 
 ** Client              : WMS
 ** Description         : The purpose of this JPO is to create a Measurement Book Entry
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------
 ** AurionPro                  28-Jul-2017                  Original Version
 ** -----------------------------------------------------------------
 **/

import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;

import matrix.db.JPO;
import matrix.db.Context;
import matrix.util.StringList;


/**
 * The purpose of this JPO is to create a Measurement Book Entry.
 * @author WMS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSBOQSubItems_mxJPO extends WMSConstants_mxJPO
{
	

	 
	/**
	 * Create a new ${CLASS:AdvanceRecovery} object from a given id.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds no arguments.
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since R418
	 */

	public WMSBOQSubItems_mxJPO(Context context, String[] args)
			throws Exception
	{
          super(context,args);
	}

	/**
	 * PENDING header and annotation
	 * Method called on the Portal to display the Advances 
	 * 
	 * to get the Advances
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getSubItems(Context context,String[] args) throws Exception
	{
		MapList mlSubItems = new MapList();
		try
		{
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				StringList slBusSelects     = new StringList(4);
				slBusSelects.add(DomainConstants.SELECT_ID);
				slBusSelects.add(DomainConstants.SELECT_TYPE);
				slBusSelects.add(DomainConstants.SELECT_CURRENT);
				slBusSelects.add("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
				
				StringList slRelSelects = new StringList();
				slRelSelects.add(DomainRelationship.SELECT_ID);
				DomainObject domObjTask= DomainObject.newInstance(context, strObjectId);
				mlSubItems = domObjTask.getRelatedObjects(context, // matrix context
						RELATIONSHIP_WMS_BOQ_SUB_ITEMS, // relationship pattern
						TYPE_WMS_MEASUREMENT_TASK, // type pattern
						slBusSelects, // object selects
						slRelSelects, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in getSubItems method of JPO WMSBOQSubItems_mxJPO");
			exception.printStackTrace();
			throw exception;
		}
		return mlSubItems;
	}
	
	
	 public void updateDescription (Context context, String[] args) throws Exception 
     {
		 boolean isContextPushed = false;
         try {
			 ContextUtil.pushContext(context);
			 isContextPushed = true;
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String sTitle = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
             doMeasurement.setDescription(context,sTitle);
         }
         catch (Exception e) {
             throw e;
         }finally{
			 if(isContextPushed)
				 ContextUtil.popContext(context);
		 }
     }
	 
	 
	  public void updateUOM (Context context, String[] args) throws Exception 
     {
         boolean isContextPushed = false;
         try {
			 ContextUtil.pushContext(context);
			 isContextPushed = true;
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String sTitle = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
             doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_UNIT_OF_MEASURE, sTitle);
         }
         catch (Exception e) {
             throw e;
         }finally{
			 if(isContextPushed)
				 ContextUtil.popContext(context);
		 }
     }
	
	
	
	 }