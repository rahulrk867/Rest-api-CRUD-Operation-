import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.LicenseUtil;
import matrix.util.StringList;
import matrix.db.MQLCommand;
import java.math.RoundingMode;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.util.Map;
import java.util.Iterator;
import java.util.Date;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.io.*;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.util.XMLResourceDescriptor;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.apache.poi.util.Units;
import java.math.BigDecimal;


public  class WMSDownloadForm26_mxJPO extends WMSConstants_mxJPO{
	//RELATIONSHIP
	public static final String RELATIONSHIP_WMSWO_ABSTRACTMBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");
	public static final String RELATIONSHIP_WMSWORKORDER_CONTRACTOR = PropertyUtil.getSchemaProperty("relationship_PRBWorkorderContractor");
	public static final String RELATIONSHIP_WMSABSTRACT_PAYMENTITEMS = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBEPaymentItems");
	//ATTRIBUTE
	public static final String ATTRIBUTE_WMS_PONUMBER = PropertyUtil.getSchemaProperty("attribute_WMSPONumber");
	public static final String ATTRIBUTE_WMSWORKORDER_DATE = PropertyUtil.getSchemaProperty("attribute_WMSWorkOrderDate");
	public static final String ATTRIBUTE_SEQUENCE_ORDER = PropertyUtil.getSchemaProperty("attribute_SequenceOrder");
	public static final String ATTRIBUTE_WMSPAYMENTSCHEDULE_SEQUENCE = PropertyUtil.getSchemaProperty("attribute_WMSPaymentScheduleSequence");
	public static final String ATTRIBUTE_TITLE = PropertyUtil.getSchemaProperty("attribute_Title");
	public static final String ATTRIBUTE_WMSPERCENTAGE_WEIGHTAGE = PropertyUtil.getSchemaProperty("attribute_WMSPercentageOfWeightage");
	public static final String ATTRIBUTE_WMSPAYMENTITEM_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSPaymentItemAmount");
	public static final String ATTRIBUTE_WMSPERCENTAGECOMPLETETILLDATE = PropertyUtil.getSchemaProperty("attribute_WMSPercentageCompleteTillDate");
	public static final String ATTRIBUTE_WMSMBEQUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSMBEActivityQuantity");
	public static final String ATTRIBUTE_WMSREMARKS = PropertyUtil.getSchemaProperty("attribute_WMSRemarks");
	//TYPE
	public static final String TYPE_WMSABSTRACTMEASURMENTBOOKENTRY = PropertyUtil.getSchemaProperty("type_WMSAbstractMeasurementBookEntry");
	public static final String TYPE_WMSPAYMENTITEM = PropertyUtil.getSchemaProperty("type_WMSPaymentItem");
	public static final String ATTRIBUTE_WMS_VALUE_OF_CONTRACT = PropertyUtil.getSchemaProperty("attribute_WMSValueOfContract");
	public static final String ATTRIBUTE_WMSECVIBM_VALUE = PropertyUtil.getSchemaProperty("attribute_WMSECVIBM");
	public static final String RELATIONSHIP_WORKORDER_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");
	public static final String ATTRIBUTE_WMS_WORK_ORDER_TITLE = PropertyUtil.getSchemaProperty("attribute_WMSWorkorderTitle");
	public static final String  ATTRIBUTE_WMS_GST_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSGSTNumber");
	public static final String  ATTRIBUTE_WMS_PAN_NUMBER = PropertyUtil.getSchemaProperty("attribute_WMSPANNumber");
	public static final String  ATTRIBUTE_WMS_ABS_START_DATE = PropertyUtil.getSchemaProperty("attribute_WMSAbsBillStartDate");
	public static final String  ATTRIBUTE_WMS_ABS_END_DATE = PropertyUtil.getSchemaProperty("attribute_WMSAbsBillEndDate");
	public static final String ATTRIBUTE_WMSRETENTION_PERCENTAGE = PropertyUtil.getSchemaProperty("attribute_WMSRetentionPercentage");
	public static final String ATTRIBUTE_WMS_BILL_REDUCTION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSBillReductionAmount");
	public static final String  ATTRIBUTE_WMS_CERTIFIED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSCertifiedAmount");
	public static final String  ATTRIBUTE_WMS_INVOICED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSInvoicedAmount");
	public static final String  ATTRIBUTE_WMS_TIME_ALLOWED = PropertyUtil.getSchemaProperty("attribute_WMSTimeAllowed");
	public static final String ATTRIBUTE_WMS_BILL_K_VALUE = PropertyUtil.getSchemaProperty("attribute_WMSBillKValue");
	String strMode=DomainConstants.EMPTY_STRING;
	String strInboxTaskId=DomainConstants.EMPTY_STRING;
	String strGenMode = DomainConstants.EMPTY_STRING;
	

	public WMSDownloadForm26_mxJPO(Context context, String[] args) throws Exception
	{
		super(context,args);
	}
	
   	public void writeFiles(Context context , String [] args) throws Exception
	{
	try {
			HashMap programMap      = (HashMap)JPO.unpackArgs(args);
			String strObjID         = (String) programMap.get("objectId");
			strGenMode         = (String) programMap.get("GenMode");
			if(programMap.containsKey("mode")) { 
				strMode=(String)programMap.get("mode");
				strInboxTaskId=(String)programMap.get("inboxTaskId");
			}
		 
			generateForm26(context ,strObjID );		
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public void generateForm26(Context context  , String strObjID) throws Exception
	{
		String strHeader = DomainConstants.EMPTY_STRING;
		Map packArgs=new HashMap();		
		packArgs.put("objectId", strObjID); 
		Map mBillDetails = (Map)JPO.invoke(context,"WMSAbstractMeasurementBookEntry",null,"getBillDetailsForBill",JPO.packArgs(packArgs),MapList.class);
		MapList mlCertificates = (MapList)JPO.invoke(context,"WMSBillCertificates",null,"getCertifiatesConntected",JPO.packArgs(packArgs),MapList.class);
		
		String strAdvance = DomainConstants.EMPTY_STRING;
		String strWithHeld = DomainConstants.EMPTY_STRING;
		String strWithHeldRelease = DomainConstants.EMPTY_STRING;
		String strRetentionRelease = DomainConstants.EMPTY_STRING;
		String strRecovery = DomainConstants.EMPTY_STRING;
		String strRecoveryInterest = DomainConstants.EMPTY_STRING;
		String strOtherDeductionAmount = DomainConstants.EMPTY_STRING;
		String strOtherReleaseAmount = DomainConstants.EMPTY_STRING;
		Map<String,String> mOtherDeduction = new HashMap<String,String>();		
		Map<String,String> mOtherRelease = new HashMap<String,String>();		
				
		if(mBillDetails != null){
			strAdvance = (String)mBillDetails.get("Advances");
			strWithHeld = (String)mBillDetails.get("WithHeld");			
			strWithHeldRelease = (String)mBillDetails.get("WithHeldRelease");			
			strRetentionRelease = (String)mBillDetails.get("RetentionRelease");			
			strRecovery = (String)mBillDetails.get("Recovery");			
			strRecoveryInterest = (String)mBillDetails.get("RecoveryInterest");	
			strOtherDeductionAmount = (String)mBillDetails.get("OtherDeductionAmount");	
			strOtherReleaseAmount = (String)mBillDetails.get("OtherReleaseAmount");	
			mOtherDeduction = (HashMap)mBillDetails.get("OtherDeduction");	
			mOtherRelease = (HashMap)mBillDetails.get("OtherRelease");	
		}

		if(UIUtil.isNotNullAndNotEmpty(strWithHeldRelease) && Double.valueOf(strWithHeldRelease)>0)
			mOtherRelease.put("Withheld Release",strWithHeldRelease);
		if(UIUtil.isNotNullAndNotEmpty(strWithHeld) && Double.valueOf(strWithHeld)>0)
			mOtherDeduction.put("Withheld",strWithHeld);
		if(UIUtil.isNotNullAndNotEmpty(strRecoveryInterest) && Double.valueOf(strRecoveryInterest)>0)
			mOtherDeduction.put("Recovery Interest",strRecoveryInterest);
		

		String strTransPath = context.createWorkspace();
		String xmlSourceFileName = "Form26EPCSource.xml";

		String xmlFilePath = strTransPath + File.separator+xmlSourceFileName;
		
		DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();

		DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();

		Document document = documentBuilder.newDocument();

		Element root = document.createElement("page");
		document.appendChild(root);

		Element heading2 = document.createElement("heading2");
				
		Element cashBookNo = document.createElement("cash-book-no");
		Element edate = document.createElement("date");
		Element docket = document.createElement("docket-no");
		Element projectname = document.createElement("project-name");
		Element description = document.createElement("description");
		Element contractorName = document.createElement("contractor-name");
		Element contrPan = document.createElement("pan-no");
		Element contrGST = document.createElement("gst-no");
		Element snoOfBill = document.createElement("sno-of-bill");
		Element agreement = document.createElement("agreement");
		Element agreementDate = document.createElement("agreement-date");
		Element contractValue = document.createElement("contract-value");
		Element ecvValue = document.createElement("ecv-value");
		Element tenderPremDiscount = document.createElement("discount-value");
		Element commencementWork = document.createElement("commencement-of-work");
		Element valueOfItems = document.createElement("value-of-items");
		Element valueOfMeasured = document.createElement("value-of-measured");
		Element approximateValue = document.createElement("approximate-value");
		Element deductAmount = document.createElement("deduct-amount");
		Element releaseRetetion = document.createElement("release-of-retention");
		Element balance = document.createElement("balance");
		Element detectIntermediate = document.createElement("detect-intermediate");
		Element modAdvance = document.createElement("mobilization-advance");
		Element modAdvanceRecovery = document.createElement("mobilization");
		Element intermediate = document.createElement("intermediate");
		Element gross = document.createElement("gross-amount");
		

		Element checkDetails = document.createElement("cheque-details");
		Element passOrder = document.createElement("rupees");
		Element retentionPercentage = document.createElement("retention-percentage");
		Element grossOriginal = document.createElement("gross-amount-p");
		Element grossOriginalPremium = document.createElement("premium");
			
		DomainObject aMObject = DomainObject.newInstance(context,strObjID);
		StringList companyDetails  = new StringList();
		companyDetails.addElement(DomainConstants.SELECT_NAME);
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.id");
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute[Address]");
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute["+ATTRIBUTE_WMS_GST_NUMBER+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute["+ATTRIBUTE_WMS_PAN_NUMBER+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.name");
		companyDetails.addElement(DomainConstants.SELECT_DESCRIPTION);
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMSRETENTION_PERCENTAGE+"]");		
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMS_PONUMBER+"]");		
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMSWORKORDER_DATE+"]");
		companyDetails.addElement("attribute["+ATTRIBUTE_SEQUENCE_ORDER+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSECVIBM_VALUE+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
		companyDetails.addElement("attribute["+ATTRIBUTE_WMS_ABS_START_DATE+"]");
		companyDetails.addElement("attribute["+ATTRIBUTE_WMS_ABS_END_DATE+"]");
		companyDetails.addElement(DomainObject.SELECT_OWNER);
		companyDetails.addElement(DomainObject.SELECT_CURRENT);
		companyDetails.addElement(DomainObject.SELECT_ORIGINATED);
		companyDetails.addElement("current[Review].actual");
		companyDetails.addElement("attribute["+ATTRIBUTE_WMS_ABS_MBE_TYPE+"].value");
		
		Map companyMap = aMObject.getInfo(context,companyDetails);
		
		//String strName = (String) companyMap.get(DomainConstants.SELECT_NAME);
		String strName = "BillForm";
		String strOwner = (String)companyMap.get(DomainObject.SELECT_OWNER);
		String strOriginated = (String)companyMap.get(DomainObject.SELECT_ORIGINATED);
		String strState = (String)companyMap.get(DomainObject.SELECT_CURRENT);
		if("Review".equals(strState)){
			strOriginated = (String)companyMap.get("current[Review].actual");
		}
		String strValueOfContract = (String)companyMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
		//String strECVValue = (String)companyMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSECVIBM_VALUE+"]");
		String strId = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.id");
		String strAMName = (String)companyMap.get(DomainConstants.SELECT_NAME);
		String strCompanyAddress = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute[Address]");
		if(UIUtil.isNullOrEmpty(strCompanyAddress))
			strCompanyAddress = "";
		String strCompanyName = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.name");
		if(UIUtil.isNullOrEmpty(strCompanyName))
			strCompanyName = "";
		String strCompanyDescription = (String)companyMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
		if(UIUtil.isNullOrEmpty(strCompanyDescription))
			strCompanyDescription = "";
		String strPONumber = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMS_PONUMBER+"]");
		String strWODate = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMSWORKORDER_DATE+"]");
		String strSequenceOrder = (String)companyMap.get("attribute["+ATTRIBUTE_SEQUENCE_ORDER+"]");
		String strGSTNumber = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute["+ATTRIBUTE_WMS_GST_NUMBER+"]");
		if(UIUtil.isNullOrEmpty(strGSTNumber))
			strGSTNumber = "";
		String strPANNumber = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute["+ATTRIBUTE_WMS_PAN_NUMBER+"]");
		if(UIUtil.isNullOrEmpty(strPANNumber))
			strPANNumber = "";
		String strStartDate = (String)companyMap.get("attribute["+ATTRIBUTE_WMS_ABS_START_DATE+"]");
		String strEndDate = (String)companyMap.get("attribute["+ATTRIBUTE_WMS_ABS_END_DATE+"]");
		String strRetention = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMSRETENTION_PERCENTAGE+"]");
		String strDuration = (String)companyMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"]");
		String strDesc = (String)companyMap.get(DomainObject.SELECT_DESCRIPTION);
		
		String strAbsMBEType = (String)companyMap.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_TYPE+"].value");
		String strTitle = "Running Account Bill";
		if("Final".equalsIgnoreCase(strAbsMBEType)){
			strTitle = "Final Bill form";
		}
		
		heading2.appendChild(document.createTextNode(strTitle));
		root.appendChild(heading2);
		
		description.appendChild(document.createTextNode(strDesc));
		root.appendChild(description);

		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
		
		double dTotalRetentionReleased = 0;
		double dTotalAmoutOfPrevBill = 0;
		
		String sActual = "";
		String sPrevBillAmount = "";
		String sName = "";
		String sDate = "";
		String strBillDate = "";
		if (strWODate != null && !"".equals(strWODate)){
			//Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(strWODate); 
			Date date1 = eMatrixDateFormat.getJavaDate(strWODate);
			sDate = df.format(date1);	
		}
		if (strOriginated != null && !"".equals(strOriginated)){
			//Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(strOriginated); 
			Date date1 = eMatrixDateFormat.getJavaDate(strOriginated);
			strBillDate = df.format(date1);	
		}

		
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		
		String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
		String strLogo = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Logo");
		String strWatermark = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Watermark");
		strWatermark = strWatermark.replace("\\", "/");
		strLogo = strLogo.replace("\\", "/");
		Element embLogo = document.createElement("logo1");
		embLogo.appendChild(document.createTextNode("file:"+strLogo));
		
		Element embHeader = document.createElement("header-footer");
		Element embWatermark = document.createElement("watermark");
		embWatermark.appendChild(document.createTextNode("file:"+strWatermark));
		strHeader = strAMName + "/"+strBillDate+"/DGNP";
		embHeader.appendChild(document.createTextNode(strHeader));
		root.appendChild(embHeader);
		root.appendChild(embWatermark);
		root.appendChild(embLogo);
		
		
		int iSequenceNo = Integer.parseInt(strSequenceOrder);
		if (iSequenceNo != 1){			
			int iPreviousNo = iSequenceNo - 1;
			String sPreviousSequenceNo = String.valueOf(iPreviousNo);
			DomainObject dObject = DomainObject.newInstance(context,strId);
			
			StringList objectList = new StringList();
			objectList.addElement(DomainConstants.SELECT_ID);
			objectList.addElement(DomainConstants.SELECT_NAME);
			objectList.addElement("current[Approved].actual");
			objectList.addElement("attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value");
			objectList.addElement("attribute["+ATTRIBUTE_WMS_INVOICED_AMOUNT+"].value");
			objectList.addElement("attribute["+ATTRIBUTE_WMS_BILL_K_VALUE+"].value");
			StringList relList = new StringList();
			relList.addElement(DomainRelationship.SELECT_ID);
			
			MapList maplist =  dObject.getRelatedObjects(context,
														  RELATIONSHIP_WMSWO_ABSTRACTMBE,
														  TYPE_WMSABSTRACTMEASURMENTBOOKENTRY, // object pattern
														  objectList, // object selects
														  relList, // relationship selects
														  false, // to direction
														  true, // from direction
														  (short) 1, // recursion level
														  "attribute["+ATTRIBUTE_SEQUENCE_ORDER+"]=='"+sPreviousSequenceNo+"' && (current == Approved || current == Paid)", // object where clause
														  null); // relationship where clause
			
			Iterator mlIterator = maplist.iterator();
			while(mlIterator.hasNext()){
				Map map = (Map)mlIterator.next();
				sName = (String)map.get(DomainConstants.SELECT_NAME);
				String sCurrentActual = (String)map.get("current[Approved].actual");
				//Date date=new SimpleDateFormat("dd/MM/yyyy").parse(sCurrentActual); 
				Date date = eMatrixDateFormat.getJavaDate(sCurrentActual);
				sActual = df.format(date);
				sPrevBillAmount = (String)map.get("attribute["+ATTRIBUTE_WMS_BILL_K_VALUE+"].value");
			  }	
			  if(UIUtil.isNullOrEmpty(sPrevBillAmount)){
				  
				  sPrevBillAmount = "0.0";
			  }
			Double dPrevAmount = Double.valueOf(sPrevBillAmount);
			String strPrev = WMSUtil_mxJPO.converToIndianCurrency(context,dPrevAmount);
			
			StringList slRetentionReleaseList = dObject.getInfoList(context,"from["+RELATIONSHIP_WMSWORKORDER_RETUNTIONRECOVERY+"].to.attribute["+ATTRIBUTE_WMS_RETENSION_AMOUNT_PAID_TILL_DATE+"].value");
			
			for(int i=0;i<slRetentionReleaseList.size();i++){
				String strRetentionReleaseValue = (String)slRetentionReleaseList.get(i);
				if(UIUtil.isNullOrEmpty(strRetentionReleaseValue))
					strRetentionReleaseValue = "0";
			
					dTotalRetentionReleased = dTotalRetentionReleased + Double.valueOf(strRetentionReleaseValue);
			}
			
			String strRetentionReleaseInCurrentBill = MqlUtil.mqlCommand(context,"print bus "+strObjID+" select from["+RELATIONSHIP_WMS_AMBPAYMENTS+"|to.type=="+TYPE_WMSRETENTION_RECOVERYITEM+"].attribute["+ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT+"].value dump |");
			
			StringList slRetentionReleaseCurrentBillList = FrameworkUtil.split(strRetentionReleaseInCurrentBill,"|");
			
			for(int i=0;i<slRetentionReleaseCurrentBillList.size();i++){
				String strRetentionReleaseValue = (String)slRetentionReleaseCurrentBillList.get(i);
				if(UIUtil.isNullOrEmpty(strRetentionReleaseValue))
					strRetentionReleaseValue = "0";
			
					dTotalRetentionReleased = dTotalRetentionReleased + Double.valueOf(strRetentionReleaseValue);
			}
														  
		
			StringList slItemSelect = new StringList();
			slItemSelect.add(DomainObject.SELECT_ID);
			slItemSelect.add(DomainObject.SELECT_TYPE);
			slItemSelect.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"].value");
			MapList mlPaymentItems =  dObject.getRelatedObjects(context,
													  RELATIONSHIP_WMS_PAYMENT_HEAD+","+RELATIONSHIP_WMS_PAYMENT_ITEM,
													  TYPE_WMS_PAYMENT_SCHEDULE+","+TYPE_WMS_PAYMENT_ITEM, // object pattern
													  slItemSelect, // object selects
													  relList, // relationship selects
													  false, // to direction
													  true, // from direction
													  (short) 0, // recursion level
													  DomainConstants.EMPTY_STRING, // object where clause
													  DomainConstants.EMPTY_STRING); // relationship where clause
			Map mTemp = null;
			String strType = DomainConstants.EMPTY_STRING;
			String strUptoDateComplete = DomainConstants.EMPTY_STRING;
			for(int i =0;i<mlPaymentItems.size();i++){
				mTemp = (Map)mlPaymentItems.get(i);
				strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
				strUptoDateComplete = (String)mTemp.get("attribute[WMSPercentageCompleteTillDate].value");
				if(TYPE_WMS_PAYMENT_ITEM.equals(strType)){
					if(UIUtil.isNullOrEmpty(strUptoDateComplete))
						strUptoDateComplete = "0";
					
					if(UIUtil.isNotNullAndNotEmpty(strUptoDateComplete) && Double.valueOf(strUptoDateComplete) > 0){
						//dTotalAmoutOfPrevBill = dTotalAmoutOfPrevBill + (Double.valueOf(strUptoDateComplete)*Double.valueOf(strECVValue)/100);
						dTotalAmoutOfPrevBill = dTotalAmoutOfPrevBill;// + (Double.valueOf(strUptoDateComplete)*Double.valueOf(strECVValue)/100);
					}
					
				}
			}
		
		} 
		
		cashBookNo.appendChild(document.createTextNode(""));
		root.appendChild(cashBookNo);
		
		edate.appendChild(document.createTextNode(""));
		root.appendChild(edate);
		
		contractorName.appendChild(document.createTextNode(strCompanyName+", "+strCompanyAddress));
		root.appendChild(contractorName);
		
		contrPan.appendChild(document.createTextNode(strPANNumber));
		root.appendChild(contrPan);
		
		contrGST.appendChild(document.createTextNode(strGSTNumber));
		root.appendChild(contrGST);
		
		projectname.appendChild(document.createTextNode(strCompanyDescription));
		root.appendChild(projectname);
		
		agreement.appendChild(document.createTextNode(strPONumber));
		root.appendChild(agreement);
		
		double dWMSWorkOrderAmount = Double.parseDouble(strValueOfContract);
		
		double dPremium = 0.0;//-1*(Double.parseDouble(strECVValue) - Double.parseDouble(strValueOfContract))/Double.parseDouble(strECVValue) *100;
		
		strValueOfContract = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strValueOfContract));
		contractValue.appendChild(document.createTextNode("Rs."+strValueOfContract));
		root.appendChild(contractValue);
				
		//strECVValue = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strECVValue));
		ecvValue.appendChild(document.createTextNode(""));
		root.appendChild(ecvValue);
		
		snoOfBill.appendChild(document.createTextNode(strAMName));
		root.appendChild(snoOfBill);		
		
		agreementDate.appendChild(document.createTextNode(sDate));
		root.appendChild(agreementDate);		
		
		commencementWork.appendChild(document.createTextNode(strDuration+" days"));
		root.appendChild(commencementWork);	
		
		packArgs.put("objectId", strId); 
		MapList mBGDetails = (MapList)JPO.invoke(context,"WMSWorkOrderBGs",null,"getAllBGsConnectedToWO",JPO.packArgs(packArgs),MapList.class);
		Map mBGMap = null;
		for(int i=0;i<mBGDetails.size();i++){
			mBGMap = (Map)mBGDetails.get(i);
			
			Element bankDetails = document.createElement("bank-details");
			Element bankSNo = document.createElement("bank-sno");
			Element bankName = document.createElement("bank-name");
			Element bankAddress = document.createElement("bank-address");
			Element bgValue = document.createElement("bank-value");
			Element bgDate = document.createElement("bank-bg-date");
			Element bgValidUpto = document.createElement("bank-validupto");
			Element bgType = document.createElement("bank-type-of-bg");
			
			String strBankName = (String)mBGMap.get("attribute[Title]");
			String strBankAddress = (String)mBGMap.get(DomainObject.SELECT_DESCRIPTION);
			String strBankValue = (String)mBGMap.get("attribute[Rate]");
			String strBankDate = (String)mBGMap.get("attribute["+ATTRIBUTE_WMS_WO_AGREEMENT_DATE+"]");
			String strBankValidUpto = (String)mBGMap.get("attribute["+ATTRIBUTE_WMS_SUPP_AGREEMENT_DATE+"]");
			String strBankType = (String)mBGMap.get("attribute["+ATTRIBUTE_WMS_REMARK+"]");
			
			//Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(strBankDate); 
			Date date1 = eMatrixDateFormat.getJavaDate(strBankDate);
			strBankDate = df.format(date1);	
			//Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(strBankValidUpto); 
			Date date2 = eMatrixDateFormat.getJavaDate(strBankValidUpto);
			strBankValidUpto = df.format(date2);	
			
			bankSNo.appendChild(document.createTextNode(String.valueOf(i+1)));
			bankName.appendChild(document.createTextNode(strBankName));
			bankAddress.appendChild(document.createTextNode(strBankAddress));
			bgValue.appendChild(document.createTextNode("Rs."+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strBankValue))));
			bgDate.appendChild(document.createTextNode(strBankValidUpto));
			bgValidUpto.appendChild(document.createTextNode(strBankDate));
			bgType.appendChild(document.createTextNode(strBankType));
			
			bankDetails.appendChild(bankSNo);
			bankDetails.appendChild(bankName);
			bankDetails.appendChild(bankAddress);
			bankDetails.appendChild(bgValue);
			bankDetails.appendChild(bgDate);
			bankDetails.appendChild(bgValidUpto);
			bankDetails.appendChild(bgType);
			root.appendChild(bankDetails);
		}
		
		if(mBGDetails.size()==0){
			Element bankDetails = document.createElement("bank-details");
			Element bankSNo = document.createElement("bank-sno");
			Element bankName = document.createElement("bank-name");
			Element bankAddress = document.createElement("bank-address");
			Element bgValue = document.createElement("bank-value");
			Element bgDate = document.createElement("bank-bg-date");
			Element bgValidUpto = document.createElement("bank-validupto");
			Element bgType = document.createElement("bank-type-of-bg");
			
			bankSNo.appendChild(document.createTextNode(""));
			bankName.appendChild(document.createTextNode(""));
			bankAddress.appendChild(document.createTextNode(""));
			bgValue.appendChild(document.createTextNode(""));
			bgDate.appendChild(document.createTextNode(""));
			bgValidUpto.appendChild(document.createTextNode(""));
			bgType.appendChild(document.createTextNode(""));
			
			bankDetails.appendChild(bankSNo);
			bankDetails.appendChild(bankName);
			bankDetails.appendChild(bankAddress);
			bankDetails.appendChild(bgValue);
			bankDetails.appendChild(bgDate);
			bankDetails.appendChild(bgValidUpto);
			bankDetails.appendChild(bgType);
			root.appendChild(bankDetails);
			
		}
		
		Map mCertificate = null;
		for(int i=0;i<mlCertificates.size();i++){
			mCertificate = (Map)mlCertificates.get(i);
			
			Element certificateDetails = document.createElement("certificates-details");
			Element certSlNo = document.createElement("certificates-sno");
			Element certDesc = document.createElement("certificates-description");
			Element certUser = document.createElement("certificates-user");
			
			String strCertDesc = (String)mCertificate.get(DomainObject.SELECT_DESCRIPTION);
			String strCertUser = (String)mCertificate.get("attribute["+ATTRIBUTE_WMS_ADDED_BY+"]");			
			String userContextUserID = PersonUtil.getPersonObjectID(context, strCertUser);
			DomainObject doPerson = new DomainObject(userContextUserID);
			
			StringList slPersonSelect = new StringList();
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			slPersonSelect.add("attribute["+ATTRIBUTE_HOST_ROLE+"].value");
			Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
			String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			String strRole = (String)mPersonInfo.get("attribute["+ATTRIBUTE_HOST_ROLE+"].value");
			
			if(UIUtil.isNullOrEmpty(strFirstName)){
				strFirstName = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strLastName)){
				strLastName = DomainConstants.EMPTY_STRING;
			}
			
			String strUser = strFirstName + " " +strLastName;
			
			if(UIUtil.isNotNullAndNotEmpty(strRole))
				strUser = strUser + " ("+strRole+")";
			certSlNo.appendChild(document.createTextNode(String.valueOf(i+1)));
			certDesc.appendChild(document.createTextNode(strCertDesc));
			certUser.appendChild(document.createTextNode(strUser));
			
			certificateDetails.appendChild(certSlNo);
			certificateDetails.appendChild(certDesc);
			certificateDetails.appendChild(certUser);
			root.appendChild(certificateDetails);
		}
		
		if(mlCertificates.size()==0){
			Element certificateDetails = document.createElement("certificates-details");
			Element certSlNo = document.createElement("certificates-sno");
			Element certDesc = document.createElement("certificates-description");
			Element certUser = document.createElement("certificates-user");
			certSlNo.appendChild(document.createTextNode(""));
			certDesc.appendChild(document.createTextNode(""));
			certUser.appendChild(document.createTextNode(""));
			
			certificateDetails.appendChild(certSlNo);
			certificateDetails.appendChild(certDesc);
			certificateDetails.appendChild(certUser);
			root.appendChild(certificateDetails);
			
		}
		
		
		MapList paymentSchedule = getPaymentSchedule(context, strObjID);
		paymentSchedule.addSortKey("attribute["+ATTRIBUTE_WMSPAYMENTSCHEDULE_SEQUENCE+"]","ascending", "real");
		paymentSchedule.sort();	
		
		DecimalFormat decFor = new DecimalFormat("#.###");
		double dUptoTotal=0.0;
		
		DecimalFormat df1 = new DecimalFormat("#.##");      
		dPremium = Double.valueOf(df1.format(dPremium));
		
		dPremium = Double.valueOf(df1.format(dPremium));
		String strTenderPrem = DomainConstants.EMPTY_STRING;
		if(dPremium > 0){
			strTenderPrem = "+"+String.valueOf(dPremium);
		}else{
			strTenderPrem = "-"+String.valueOf(dPremium);
		}
		tenderPremDiscount.appendChild(document.createTextNode(strTenderPrem+"%"));
		root.appendChild(tenderPremDiscount);	
		
		//dWMSWorkOrderAmount = dWMSWorkOrderAmount + (dWMSWorkOrderAmount * dPremium)/100;
		
		Iterator aMIterator1 = paymentSchedule.iterator();
		while(aMIterator1.hasNext()){
			Map amMap = (Map)aMIterator1.next();
			String strWMSPerCompleteTillDate = (String)amMap.get("attribute["+ATTRIBUTE_WMSPERCENTAGECOMPLETETILLDATE+"]");
			double dWMSCompleteTillDate = Double.parseDouble(strWMSPerCompleteTillDate);		
			double dTotalAmount = (dWMSWorkOrderAmount) * (dWMSCompleteTillDate) / 100;			
			dUptoTotal = dUptoTotal + dTotalAmount;		
		}

		String uptoDateAmount = new BigDecimal(dUptoTotal).setScale(2, RoundingMode.FLOOR).toPlainString();
		
		Iterator aMIterator = paymentSchedule.iterator();
		int count=0;
		
		double dUptoDateTotal = 0.0;
		double dSincePreviousTotal = 0.0;
		double dSincePreviousGross = 0.0;
		
		if(paymentSchedule.size()>0){
			while(aMIterator.hasNext()){
				Element Items = document.createElement("items");
				root.appendChild(Items);	
				Element sequence = document.createElement("sequence");
				Element particulars = document.createElement("particulars");
				Element payAgreement = document.createElement("percentage-agreement");
				Element perCompleted = document.createElement("upto-percentage-completed");
				Element amt = document.createElement("upto-amount");
				Element tillDateperCompleted = document.createElement("tilldate-percentage-completed");
				Element tillDateamt = document.createElement("tilldate-amount");
				Element perCompleted1 = document.createElement("previous-percentage-completed");
				Element amt1 = document.createElement("previous-amount");
				Element remarks = document.createElement("remarks");
				
				count++;
				Map amMap = (Map)aMIterator.next();
				String strWMSSequence = (String)amMap.get("attribute["+ATTRIBUTE_WMSPAYMENTSCHEDULE_SEQUENCE+"]");
				String strWMSTitle = (String)amMap.get("attribute["+ATTRIBUTE_TITLE+"]");
				String strWMSPercentageOfWeight = (String)amMap.get("attribute["+ATTRIBUTE_WMSPERCENTAGE_WEIGHTAGE+"]");
				String strWMSPerCompleteTillDate = (String)amMap.get("attribute["+ATTRIBUTE_WMSPERCENTAGECOMPLETETILLDATE+"]");
				String strWMSPaymentItemAmount = (String)amMap.get("attribute["+ATTRIBUTE_WMSPAYMENTITEM_AMOUNT+"]");			
				String strWMSMBEActivityQuantity = (String)amMap.get("attribute["+ATTRIBUTE_WMSMBEQUANTITY+"]");
				String strWMSRemarks = (String)amMap.get("attribute["+ATTRIBUTE_WMSREMARKS+"]");
				double dWMSCompleteTillDate = Double.parseDouble(strWMSPerCompleteTillDate);
				double dWMSMBEActivityQuantity = Double.parseDouble(strWMSMBEActivityQuantity);
				double dTotalAmount = (dWMSWorkOrderAmount * dWMSCompleteTillDate)/100;
				double dPreviousAmount = (dWMSWorkOrderAmount * dWMSMBEActivityQuantity)/100 ;	
				
				double dTillDateAmount = dTotalAmount - dPreviousAmount;
				double dTillDateQty = dWMSCompleteTillDate - dWMSMBEActivityQuantity;
				
				dUptoDateTotal = dUptoDateTotal + dTotalAmount;
				dSincePreviousTotal = dSincePreviousTotal + dPreviousAmount;			
				
				sequence.appendChild(document.createTextNode(strWMSSequence));
				Items.appendChild(sequence);
				
				particulars.appendChild(document.createTextNode(strWMSTitle));
				Items.appendChild(particulars);
							
				payAgreement.appendChild(document.createTextNode(strWMSPercentageOfWeight));
				Items.appendChild(payAgreement);
				
				perCompleted.appendChild(document.createTextNode(strWMSPerCompleteTillDate));
				Items.appendChild(perCompleted);
			
				amt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAmount)));
				Items.appendChild(amt);
				
				tillDateperCompleted.appendChild(document.createTextNode(String.valueOf(dTillDateQty)));
				Items.appendChild(tillDateperCompleted);
			
				tillDateamt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dTillDateAmount)));
				Items.appendChild(tillDateamt);
				
				perCompleted1.appendChild(document.createTextNode(strWMSMBEActivityQuantity));
				Items.appendChild(perCompleted1);

				amt1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dPreviousAmount)));
				Items.appendChild(amt1);
				dSincePreviousGross = dSincePreviousGross + dPreviousAmount;
				remarks.appendChild(document.createTextNode(strWMSRemarks));
				Items.appendChild(remarks);
				
			}
		}else{
			Element Items = document.createElement("items");
			root.appendChild(Items);
		}
		
		
		dPremium = dPremium/100;
		dTotalAmoutOfPrevBill = dTotalAmoutOfPrevBill + (dTotalAmoutOfPrevBill*dPremium);
		dTotalAmoutOfPrevBill = Double.valueOf(df1.format(dTotalAmoutOfPrevBill));
		dSincePreviousTotal = dSincePreviousTotal + (dSincePreviousTotal*dPremium);
		dSincePreviousTotal = Double.valueOf(df1.format(dSincePreviousTotal));

		dUptoTotal = dSincePreviousTotal + dTotalAmoutOfPrevBill;
	
		String strTotal = new BigDecimal(dUptoTotal).setScale(2, RoundingMode.FLOOR).toPlainString();	
		dUptoTotal = Double.valueOf(strTotal);		

		dSincePreviousTotal = dSincePreviousTotal + (dSincePreviousTotal*dPremium);
		dSincePreviousTotal = Double.valueOf(df1.format(dSincePreviousTotal));
		String strTotalSincePrev = df1.format(dSincePreviousTotal);		
		String strTillDate = df1.format(dUptoDateTotal-dSincePreviousTotal);		
		
		double dRetention = Double.valueOf(df1.format(Double.valueOf(strRetention)));
		
		double dRetentionAmount = dUptoTotal * dRetention/100;
		String strRetentionAmount = df1.format(dRetentionAmount);		
				
		String strBalance =	df1.format(Double.valueOf(dUptoTotal - dRetentionAmount + dTotalRetentionReleased));
				
		valueOfItems.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strTotal))));
		root.appendChild(valueOfItems);
		
		valueOfMeasured.appendChild(document.createTextNode("0.00"));
		root.appendChild(valueOfMeasured);
		
		approximateValue.appendChild(document.createTextNode("0.00"));
		root.appendChild(approximateValue);
		
		retentionPercentage.appendChild(document.createTextNode("["+strRetention+"%]"));
		root.appendChild(retentionPercentage);
		
		deductAmount.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strRetentionAmount))));
		root.appendChild(deductAmount);
		
		strRetentionRelease = df1.format(dTotalRetentionReleased);	
		
		releaseRetetion.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strRetentionRelease))));
		root.appendChild(releaseRetetion);

		balance.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strBalance))));
		root.appendChild(balance);
		
		if(UIUtil.isNullOrEmpty(sPrevBillAmount)){
			
			sPrevBillAmount = "0";
		}
		
		detectIntermediate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sPrevBillAmount))));
		root.appendChild(detectIntermediate);
				
		modAdvance.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strAdvance))));
		root.appendChild(modAdvance);
		
		modAdvanceRecovery.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strRecovery))));
		root.appendChild(modAdvanceRecovery);
				
		String strInterediatePayement = df1.format(dUptoTotal - dRetentionAmount + dTotalRetentionReleased-Double.valueOf(sPrevBillAmount) + Double.valueOf(strAdvance) - Double.valueOf(strRecovery));
		intermediate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strInterediatePayement))));
		root.appendChild(intermediate);

		String strDeductionValue = DomainConstants.EMPTY_STRING;
		double dDeductionAmount = 0.0;
		int iDedCtr = 0;
		for (Map.Entry<String,String> entry : mOtherDeduction.entrySet())  {
			iDedCtr++;
			Element deduction = document.createElement("deductions");
			Element otherDeduction = document.createElement("deduction");
			Element otherDeductionAmount = document.createElement("deduction-value");
			otherDeduction.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(iDedCtr)+". "+(String)entry.getKey()));
			deduction.appendChild(otherDeduction);
			strDeductionValue = (String)entry.getValue();
			dDeductionAmount = dDeductionAmount+ Double.valueOf(strDeductionValue);
			otherDeductionAmount.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strDeductionValue))));
			deduction.appendChild(otherDeductionAmount);
			root.appendChild(deduction);
		}
		
		Element deduction1 = document.createElement("deductions");
		Element otherDeduction1 = document.createElement("deduction");
		Element otherDeductionAmount1 = document.createElement("deduction-value");
		otherDeduction1.appendChild(document.createTextNode(""));
		deduction1.appendChild(otherDeduction1);
		otherDeductionAmount1.appendChild(document.createTextNode(""));
		deduction1.appendChild(otherDeductionAmount1);
		root.appendChild(deduction1);
		
		Element deduction2 = document.createElement("deductions");
		Element otherDeduction2 = document.createElement("deduction");
		Element otherDeductionAmount2 = document.createElement("deduction-value");
		otherDeduction2.appendChild(document.createTextNode("Subtotal of Other Deductions"));
		deduction2.appendChild(otherDeduction2);
		otherDeductionAmount2.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dDeductionAmount)));
		deduction2.appendChild(otherDeductionAmount2);
		root.appendChild(deduction2);
		
		String strReleaseValue = DomainConstants.EMPTY_STRING;
		double dAddtionAmount = 0.0;
		int iRelCtr = 0;
		for (Map.Entry<String,String> entry : mOtherRelease.entrySet())  {
			iRelCtr++;
			Element releases = document.createElement("additions");
			Element otherRelease = document.createElement("other-additions");
			Element otherReleaseAmount = document.createElement("other-additions-value");
			otherRelease.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(iRelCtr)+". "+(String)entry.getKey()));
			releases.appendChild(otherRelease);
			strReleaseValue = (String)entry.getValue();
			dAddtionAmount = dAddtionAmount+ Double.valueOf(strReleaseValue);
			otherReleaseAmount.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strReleaseValue))));
			releases.appendChild(otherReleaseAmount);
			root.appendChild(releases);
		}
		Element releases1 = document.createElement("additions");
		Element otherRelease1 = document.createElement("other-additions");
		otherRelease1.appendChild(document.createTextNode(""));
		releases1.appendChild(otherRelease1);
		Element otherReleaseAmount1 = document.createElement("other-additions-value");
		otherReleaseAmount1.appendChild(document.createTextNode(""));
		releases1.appendChild(otherReleaseAmount1);
		root.appendChild(releases1);
		
		Element releases2 = document.createElement("additions");
		Element otherRelease2 = document.createElement("other-additions");
		otherRelease2.appendChild(document.createTextNode("Subtotal of Additions"));
		releases2.appendChild(otherRelease2);
		Element otherReleaseAmount2 = document.createElement("other-additions-value");
		otherReleaseAmount2.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dAddtionAmount)));
		releases2.appendChild(otherReleaseAmount2);
		root.appendChild(releases2);
		
		double dTotalPayment = dUptoTotal - dRetentionAmount + dTotalRetentionReleased-Double.valueOf(sPrevBillAmount) + Double.valueOf(strAdvance) - Double.valueOf(strRecovery) + dAddtionAmount;
		
		String strTotalPayment  = new BigDecimal(Double.valueOf(dTotalPayment)).setScale(0, BigDecimal.ROUND_UP).toPlainString();
		
		gross.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strTotalPayment))));
		root.appendChild(gross);
		
		String strFinalPayment  = new BigDecimal(dTotalPayment - dDeductionAmount).setScale(0, BigDecimal.ROUND_UP).toPlainString();
		
		String strGrossInWords = WMSUtil_mxJPO.getValueInWords(strFinalPayment);
		checkDetails.appendChild(document.createTextNode("Rs."+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strFinalPayment))+" ("+strGrossInWords+")"));
		root.appendChild(checkDetails);

		String strFinalInWords = WMSUtil_mxJPO.getValueInWords(strTotalPayment);
		
		passOrder.appendChild(document.createTextNode("Passed for Rs."+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strTotalPayment))+" ("+strFinalInWords+") with the Other Deductions shown in the bill."));
		root.appendChild(passOrder);
		
		grossOriginal.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dSincePreviousGross))));
		root.appendChild(grossOriginal);
		grossOriginalPremium.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dSincePreviousGross + (dSincePreviousGross*dPremium)))));
		root.appendChild(grossOriginalPremium);
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource domSource = new DOMSource(document);
		StreamResult streamResult = new StreamResult(new File(xmlFilePath));

		transformer.transform(domSource, streamResult);
		String strContextUser = context.getUser();
		ContextUtil.pushContext(context);
		if("Create".equals(strState) || (UIUtil.isNotNullAndNotEmpty(strGenMode) && "Invoice".equals(strGenMode))){
			aMObject.setAttributeValue(context,ATTRIBUTE_WMS_INVOICED_AMOUNT,strFinalPayment);
			aMObject.setAttributeValue(context,ATTRIBUTE_WMS_BILL_K_VALUE,strBalance);
		}else {
			aMObject.setAttributeValue(context,ATTRIBUTE_WMS_CERTIFIED_AMOUNT,strFinalPayment);
			aMObject.setAttributeValue(context,ATTRIBUTE_WMS_BILL_K_VALUE,strBalance);
		}
		
		ContextUtil.popContext(context);

		File xmlFile = new File(xmlFilePath);

		//Write XML - End
		
		//Write XSL - Start
		String strXSLFile = "Form26EPCSource.xsl";
		File newTextFile = new File(strTransPath + File.separator+strXSLFile);

		MQLCommand mql = new MQLCommand();
		mql.open(context);
		mql.executeCommand(context, "print program WMSForm26EPC.xsl select code dump");
		mql.close(context);
		FileWriter fw = new FileWriter(newTextFile);
		fw.write(mql.getResult());
		fw.close();
		//Write XSL - End				
		
		File xsltFile = new File(strTransPath + File.separator+strXSLFile);
		// the XML file which provides the input
		StreamSource xmlSource = new StreamSource(new File(xmlFilePath));
		// create an instance of fop factory
		// Setup output
		
		
		String strFileName = strName+".pdf";
		OutputStream out;
		out = new java.io.FileOutputStream(strTransPath+File.separator+strFileName);
		try {
			FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
			// a user agent is needed for transformation
			FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
			// Construct fop with desired output format
			Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);

			// Setup XSLT
			TransformerFactory factory = TransformerFactory.newInstance();
			Transformer transformer1 = factory.newTransformer(new StreamSource(xsltFile));
			//xsltFile.delete();
			// Resulting SAX events (the generated FO) must be piped through to FOP
			Result res = new SAXResult(fop.getDefaultHandler());
			// Start XSLT transformation and FOP processing
			// That's where the XML is first transformed to XSL-FO and then 
			// PDF is created
			transformer1.transform(xmlSource, res);
		} finally {
			File file1 = new File(strTransPath+File.separator+strFileName);			
		
			if(UIUtil.isNotNullAndNotEmpty(strMode) && strMode.equalsIgnoreCase("Approval")){
				DomainObject domInBoxTask=DomainObject.newInstance(context,strInboxTaskId);
				WMSUtil_mxJPO wmsObj=new WMSUtil_mxJPO(context, new String[] {});
				//wmsObj.setSHA256HashOfFileContent(context, strTransPath+File.separator+strFileName,domInBoxTask);
			}else{
				DomainObject dObject = DomainObject.newInstance(context,strObjID);
				ContextUtil.pushContext(context);
				dObject.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strTransPath);
				ContextUtil.popContext(context);
			}		
			
			if(file1.delete())
			{
				System.out.println("File deleted successfully");
			}
			else
			{
				System.out.println("Failed to delete the file");
			}
			if(newTextFile.delete())
			{
				System.out.println("File deleted successfully");
			}
			else
			{
				System.out.println("Failed to delete the file");
			}
			if(xmlFile.delete())
			{
				System.out.println("File deleted successfully");
			}
			else
			{
				System.out.println("Failed to delete the file");
			}
			out.close();
		}
		
    }
	
	public MapList getPaymentSchedule(Context context  , String strObjID) throws Exception
	{
		StringList objectList = new StringList();
		objectList.addElement(DomainConstants.SELECT_ID);
		objectList.addElement(DomainConstants.SELECT_NAME);
		objectList.addElement("attribute["+ATTRIBUTE_WMSPAYMENTSCHEDULE_SEQUENCE+"]");
		objectList.addElement("attribute["+ATTRIBUTE_TITLE+"]");
		objectList.addElement("attribute["+ATTRIBUTE_WMSPERCENTAGE_WEIGHTAGE+"]");
		
		StringList relList = new StringList();
		relList.addElement(DomainRelationship.SELECT_ID);
		relList.addElement("attribute["+ATTRIBUTE_WMSPERCENTAGECOMPLETETILLDATE+"]");	
		relList.addElement("attribute["+ATTRIBUTE_WMSMBEQUANTITY+"]");
		relList.addElement("attribute["+ATTRIBUTE_WMSREMARKS+"]");
		
		DomainObject abstractMeasurementObject = DomainObject.newInstance(context,strObjID);
		MapList maplist =  abstractMeasurementObject.getRelatedObjects(context,
														   RELATIONSHIP_WMSABSTRACT_PAYMENTITEMS,
														  TYPE_WMSPAYMENTITEM, // object pattern
														  objectList, // object selects
														  relList, // relationship selects
														  false, // to direction
														  true, // from direction
														  (short) 1, // recursion level
														  null, // object where clause
														  null); // relationship where clause
		return maplist;	
	}
}