import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringBufferInputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.io.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Graphics2D;
import java.text.SimpleDateFormat;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;

import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.util.XMLResourceDescriptor;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.jdom.transform.JDOMResult;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;

import matrix.db.Context;
import matrix.db.FileList;
import matrix.db.MQLCommand;
import matrix.db.RelationshipType;
import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringList;

/** Name of the JPO    : ${CLASSNAME}
 ** Developed by    : Matrixone 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to export measurements
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/


public class WMSExportMeasurementItems_mxJPO extends WMSConstants_mxJPO
{     
    public static String ATTRIBUTE_TRAVERSE_ALTPATH = PropertyUtil.getSchemaProperty("attribute_TraverseAltPath");
	public static final String SELECT_ATTRIBUTE_TRAVERSE_ALTPATH = "attribute["+ATTRIBUTE_TRAVERSE_ALTPATH+"]";
	public static String PRIMARY_IMAGE_FROM_ALTPATH = PropertyUtil.getSchemaProperty("attribute_PrimaryImageFromAltPath");
	public static final String SELECT_ATTRIBUTE_PRIMARY_IMAGE_FROM_ALTPATH = "attribute["+PRIMARY_IMAGE_FROM_ALTPATH+"]";
	public static final String FORMAT_GENERIC = PropertyUtil.getSchemaProperty("format_generic");

	public static final String SELECT_GENERIC_FORMAT_FILES = "format[" + FORMAT_GENERIC + "].file.name";
	
	String  strGlobalWorkSpacePath = DomainConstants.EMPTY_STRING;
	String strHeader = "";

	/**
	 * Constructor.
	 * @param context - the eMatrix <code>Context</code> object
	 * @param args - holds no arguments
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */

	public WMSExportMeasurementItems_mxJPO(Context context, String[] args) throws Exception
	{
		super(context, args);
	}
	
	
	/**
     * Function to document object to write XML file
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
	private Document getXMLWriter() throws ParserConfigurationException {
		try
		{
		DocumentBuilderFactory docFactory 	= DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder 			= docFactory.newDocumentBuilder();
		Document docWrite 					= docBuilder.newDocument();
		return docWrite;
	}
		catch(ParserConfigurationException parserConfigurationException)
		{
			parserConfigurationException.printStackTrace();
			throw parserConfigurationException;
		}
	}
	/**
     * Function to get Work Order informations
     * @param context the eMatrix <code>Context</code> object
     * @param domOBjWO DomainObject instance of Work Order
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
	private Map<String, String> getWorkOrderInfo(Context context, DomainObject domOBjWO) throws FrameworkException {
		//TODO convert to Constants
		StringList strListWOInfoSelects = new StringList();
		strListWOInfoSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"]");
		strListWOInfoSelects.add("attribute["+ATTRIBUTE_WMS_PO_NUMBER+"]");
		strListWOInfoSelects.add("attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
		strListWOInfoSelects.add(DomainConstants.SELECT_DESCRIPTION);
		strListWOInfoSelects.add(DomainConstants.SELECT_NAME);
		strListWOInfoSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
		strListWOInfoSelects.add("to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.name");
		Map<String,String> mapData = domOBjWO.getInfo(context, strListWOInfoSelects);
		return mapData;
	}
	/**
     * Function to get the MBEs connected to the selected Work Order
     *
     * @param context the eMatrix <code>Context</code> object
     * @param domObj DomainObject instance of selected Object
     * @param strRelationship string value containing the relation with which the Object is connected
     * @return mapListMBEs MapList containing the MBEs connected to Work Order with ID
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
    private MapList getConnectedMBEs(Context context, DomainObject domObj,String strRelationship,String strWhere)
            throws FrameworkException {
        try
        {
		StringList strListBusSelects     = new StringList(7);
		strListBusSelects.add(DomainConstants.SELECT_ID);
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_TYPE+"].value");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_FINALIZED+"].value");
		//strListBusSelects.add("attribute["+ATTRIBUTE_WMS_DATE_OF_MEASUREMENT+"].value");
		strListBusSelects.add(DomainObject.SELECT_OWNER);
		strListBusSelects.add(DomainObject.SELECT_NAME);
		StringList strListRelSelects     = new StringList(2);
		strListRelSelects.add(DomainRelationship.SELECT_ID);
		MapList mapListMBEs = domObj.getRelatedObjects(context, // matrix context
				strRelationship, // relationship pattern
				TYPE_WMS_MEASUREMENT_BOOK_ENTRY, // type pattern
				strListBusSelects, // object selects
				strListRelSelects, // relationship selects
				false, // to direction
				true, // from direction
				(short) 1, // recursion level
				strWhere, // object where clause
				DomainConstants.EMPTY_STRING, // relationship where clause
				0);
		return mapListMBEs;
        }
        catch(FrameworkException frameworkException)
        {
            throw frameworkException;
        }
    }
    /**
     * Function to get Measurement selects
     * @return select list of Measurements
     * @author WMS
     * @since 418
     */
    private SelectList getMeasurementInfoRelSelects() {
		SelectList selListRelSelects     = new SelectList();
		selListRelSelects.add(DomainRelationship.SELECT_ID);
		selListRelSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_UWD+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_MANUALQUANTITY+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_ASSESSMENT_COMMENTS+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_1+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_2+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_3+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_4+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_IMAGE+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_MODIFIED+"].value");
		selListRelSelects.add("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_COMMENTED+"].value");
		
		return selListRelSelects;
	}
    /**
     * Function to get Item selects
     * @return select list of Item
     * @author WMS
     * @since 418
     */
	private SelectList getItemBusInfoSelects() {
		SelectList strListItemSelects     = new SelectList();
		strListItemSelects.add(DomainConstants.SELECT_ID);
		strListItemSelects.add(DomainConstants.SELECT_DESCRIPTION);
		strListItemSelects.add(DomainConstants.SELECT_TYPE);
		strListItemSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
		strListItemSelects.add("attribute["+ATTRIBUTE_WMS_BOQ_SERIAL_NUMBER+"]");
		strListItemSelects.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_OF_WEIGHTAGE+"]");
		strListItemSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
		strListItemSelects.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
		strListItemSelects.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]");

		
		return strListItemSelects;
	}
	
	/**
     * Function to get Item selects
     * @param context the eMatrix <code>Context</code> object
     * @args arguments for method includes work order id
     * @return generated file name
     * @author WMS
     * @since 418
     */
	public String createMeasurementBookExport(Context context, String[] args) throws Exception 
	{
		String strFileName = DomainConstants.EMPTY_STRING;
		String  strDocumentId = DomainConstants.EMPTY_STRING;
		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
		try
		{
			
			Document docWrite = getXMLWriter();	
			String strTransPath = context.createWorkspace();
			strGlobalWorkSpacePath = strTransPath;
			String strWOOID 	=	 args[0];
			String strParentId 	=	 args[1];
			String strSourceType 	=	 args[2];
			String strInboxTaskId 	=	 DomainConstants.EMPTY_STRING;
			String strMode 	=	 DomainConstants.EMPTY_STRING;
			
			if(args.length == 5){
				strInboxTaskId 	=	 args[3];
				strMode 	=	 args[4];
			}
			String strMBId = strWOOID;
			if(UIUtil.isNotNullAndNotEmpty(strSourceType) && TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strSourceType)){
				strWOOID = strParentId;
			}
			
			if(UIUtil.isNotNullAndNotEmpty(strWOOID))
			{
				DomainObject domObjWO = DomainObject.newInstance(context, strWOOID);
				Map<String, String> mapWOInfoData = getWorkOrderInfo(context, domObjWO);
				String strWorkOrderType = mapWOInfoData.get("attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
				String strWhere = "current==Submitted";

				if(UIUtil.isNotNullAndNotEmpty(strSourceType) && TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strSourceType)){
					strWhere = "id=="+strMBId;
				}

				MapList mapListConnectedMBEs = getConnectedMBEs(context, domObjWO,RELATIONSHIP_WMS_WORK_ORDER_MBE,strWhere);
				SelectList strListItemSelects = getItemBusInfoSelects();
				SelectList selListRelSelects = getMeasurementInfoRelSelects();
				
				Iterator<Map<String,String>> iterator = mapListConnectedMBEs.iterator();
				Map<String,String> mapMBEData ;
				DateFormat formatter = DateFormat.getDateInstance(DateFormat.MEDIUM, context.getLocale());
				//get Work Order details xml
				Element docWOWrite = getWorkOrderDetails(docWrite,mapWOInfoData,context);
				
				ArrayList<Element>arrListMBEDetails = new ArrayList<Element>();
				StringList strListMeasurementBusSelects = new StringList(2);
				strListMeasurementBusSelects.add(DomainObject.SELECT_IMAGE_HOLDER_ID);
				strListMeasurementBusSelects.add(DomainObject.SELECT_ID);					

				Pattern typePattern = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
				String strItemType = DomainConstants.EMPTY_STRING;
				
				if(UIUtil.isNotNullAndNotEmpty(strSourceType) && TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strSourceType)){
					while(iterator.hasNext())
					{
						mapMBEData = iterator.next();
						String strMBEOID = mapMBEData.get(DomainConstants.SELECT_ID);
						String strMBETitle = mapMBEData.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
						//String strMeasurementDate =  mapMBEData.get("attribute["+ATTRIBUTE_WMS_DATE_OF_MEASUREMENT+"].value");
						String strMBENumber =  mapMBEData.get(DomainObject.SELECT_NAME);
						String strAuthor =  mapMBEData.get(DomainObject.SELECT_OWNER);
						//Date dateMeasurementDate = eMatrixDateFormat.getJavaDate(strMeasurementDate);
						//strMeasurementDate = df.format(dateMeasurementDate);
						
						if(UIUtil.isNotNullAndNotEmpty(strMBEOID))
						{
							Element docMBEWrite;
							DomainObject domObjMBE = DomainObject.newInstance(context,strMBEOID);
							ContextUtil.pushContext(context);
							MapList mapListMeasurements = domObjMBE.getRelatedObjects(context, // matrix context
									RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship pattern
									typePattern.getPattern(), // type pattern
									strListItemSelects, // object selects
									selListRelSelects, // relationship selects
									false, // to direction
									true, // from direction
									(short) 1, // recursion level
									DomainConstants.EMPTY_STRING, // object where clause
									DomainConstants.EMPTY_STRING, // relationship where clause
									0);
							ContextUtil.popContext(context);
							if(mapListMeasurements.size()>0)
							{
								docMBEWrite = getMBEMeasurementDetails(context,docWrite,mapListMeasurements,strMBENumber,strAuthor,strMBETitle);
								arrListMBEDetails.add(docMBEWrite);
								//get MBE details xml
							}
						}
					}
				}else{
					MapList mlConsolidatedList = new MapList();
					Map<String,Map> hmConsolidatedMeasurementMap = new HashMap<String,Map>();
					Element docMBEWrite;
					
					String strMBETitles = DomainConstants.EMPTY_STRING;
					String strMBEDates = DomainConstants.EMPTY_STRING;
					String strMBEOwner = DomainConstants.EMPTY_STRING;
					String strMBENos = DomainConstants.EMPTY_STRING;
					while(iterator.hasNext())
					{
						mapMBEData = iterator.next();
						String strMBEOID = mapMBEData.get(DomainConstants.SELECT_ID);
						String strMBETitle = mapMBEData.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
						//String strMeasurementDate =  mapMBEData.get("attribute["+ATTRIBUTE_WMS_DATE_OF_MEASUREMENT+"].value");
						String strMBENumber =  mapMBEData.get(DomainObject.SELECT_NAME);
						String strAuthor =  mapMBEData.get(DomainObject.SELECT_OWNER);
						//Date dateMeasurementDate = eMatrixDateFormat.getJavaDate(strMeasurementDate);
						//strMeasurementDate = df.format(dateMeasurementDate);
						if(UIUtil.isNotNullAndNotEmpty(strMBETitles)){
							strMBETitles = strMBETitles + ", "+strMBETitle;
							//strMBEDates = strMBEDates + ", "+strMeasurementDate;
							strMBENos = strMBENos + ", "+strMBENumber;
							strMBEOwner = strMBEOwner + ", "+strAuthor;
						}else{
							strMBETitles = strMBETitle;
							//strMBEDates = strMeasurementDate;
							strMBENos = strMBENumber;
							strMBEOwner = strAuthor;
						}
						if(UIUtil.isNotNullAndNotEmpty(strMBEOID))
						{
							
							DomainObject domObjMBE = DomainObject.newInstance(context,strMBEOID);
							ContextUtil.pushContext(context);
							MapList mapListMeasurements = domObjMBE.getRelatedObjects(context, // matrix context
									RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship pattern
									typePattern.getPattern(), // type pattern
									strListItemSelects, // object selects
									selListRelSelects, // relationship selects
									false, // to direction
									true, // from direction
									(short) 1, // recursion level
									DomainConstants.EMPTY_STRING, // object where clause
									DomainConstants.EMPTY_STRING, // relationship where clause
									0);
							ContextUtil.popContext(context);
							
							hmConsolidatedMeasurementMap = consolidateMeasurement(context,mapListMeasurements,hmConsolidatedMeasurementMap);
							
							
						}
					}
					
					for (Map.Entry<String,Map> entry : hmConsolidatedMeasurementMap.entrySet()) { 
						Map hmTempMap = entry.getValue();
						if(hmTempMap != null && hmTempMap.isEmpty()==false){
							mlConsolidatedList.add(hmTempMap);
						}
					}

					if(mlConsolidatedList.size()>0)
					{
						docMBEWrite = getMBEMeasurementDetails(context,docWrite,mlConsolidatedList,strMBENos,strMBEOwner,strMBETitles);
						arrListMBEDetails.add(docMBEWrite);
						//get MBE details xml
					}					
				}
				
				//combine xml of MBE details and Work Order details and create single xml
				Document docXmlSource = generateXMLForMeasurements(docWrite,arrListMBEDetails,docWOWrite);
				//get xsl file to generate pdf using xml
				MQLCommand mql = new MQLCommand();
				mql.open(context);
				mql.executeCommand(context, "print program ExportMeasurements.xsl select code dump");
				mql.close(context);
				
				DOMSource domSource = new DOMSource(docXmlSource);
				StringWriter writer = new StringWriter();
				StreamResult result = new StreamResult(writer);
				TransformerFactory tf = TransformerFactory.newInstance();
				Transformer transformer1 = tf.newTransformer();
				transformer1.transform(domSource, result);
								
				strTransPath = EnoviaResourceBundle.getProperty(context,"WMS.ExportMeasurements.Image.FolderPath");
				//Write XML - Start
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer2 = transformerFactory.newTransformer();
				transformer2.setOutputProperty(OutputKeys.INDENT, "yes");
				DOMSource source = new DOMSource(docXmlSource);
				String strXMLFile = "Source.xml";
				File xmlFile = new File(strTransPath + File.separator+strXMLFile);
				StreamResult file = new StreamResult(xmlFile);
				transformer2.transform(source, file);
				//Write XML - End
				
				//Write XSL - Start
				String strXSLFile = "Source.xsl";
				File newTextFile = new File(strTransPath + File.separator+strXSLFile);

				FileWriter fw = new FileWriter(newTextFile);
				fw.write(mql.getResult());
				fw.close();
				//Write XSL - End				
				
				File xsltFile = new File(strTransPath + File.separator+strXSLFile);
				// the XML file which provides the input
				StreamSource xmlSource = new StreamSource(new File(strTransPath + File.separator+strXMLFile));
				// create an instance of fop factory
				// Setup output
				
				strFileName = "MBE_Export-"+Calendar.getInstance().getTimeInMillis()+".pdf";
				OutputStream out;
				out = new java.io.FileOutputStream(strGlobalWorkSpacePath+File.separator+strFileName);
				try {
					FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
					// a user agent is needed for transformation
					FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
					// Construct fop with desired output format
					Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);

					// Setup XSLT
					TransformerFactory factory = TransformerFactory.newInstance();
					Transformer transformer = factory.newTransformer(new StreamSource(xsltFile));
					//xsltFile.delete();
					// Resulting SAX events (the generated FO) must be piped through to FOP
					Result res = new SAXResult(fop.getDefaultHandler());

					// Start XSLT transformation and FOP processing
					// That's where the XML is first transformed to XSL-FO and then 
					// PDF is created
					transformer.transform(xmlSource, res);
				}catch(Exception exe){
					exe.printStackTrace();
					throw exe;
				}finally {
					out.close();
				}
						
				String strOwner = context.getUser();
				
				try
				{
					//ContextUtil.pushContext(context);
					
					 if(UIUtil.isNotNullAndNotEmpty(strMode) && strMode.equalsIgnoreCase("Approval")){
						 DomainObject domInBoxTask=DomainObject.newInstance(context,strInboxTaskId);
						//domInBoxTask.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strTransPath);
						WMSUtil_mxJPO wmsObj=new WMSUtil_mxJPO(context, new String[] {});
						// wmsObj.setSHA256HashOfFileContent(context, strGlobalWorkSpacePath+File.separator+strFileName,domInBoxTask);
					 }else{					
						strDocumentId = FrameworkUtil.autoName(context, CommonDocument.SYMBOLIC_type_Document, CommonDocument.SYMBOLIC_policy_Document);
						DomainObject domObj = DomainObject.newInstance(context, strDocumentId);
						domObj.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, strFileName);
						
						if(UIUtil.isNotNullAndNotEmpty(strSourceType) && TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strSourceType)){
							domObjWO.setId(strMBId);
						}
						domObjWO.connect(context,new RelationshipType(DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT),true, DomainObject.newInstance(context,strDocumentId));
						domObj.setOwner(context, strOwner);
						WMSImport_mxJPO.checkInFile(context, strDocumentId, strFileName, DomainConstants.EMPTY_STRING, context.getSession().getVault(),strGlobalWorkSpacePath);
					 }
				}
				catch(Exception exception)
				{
					exception.printStackTrace();
					throw exception;
				}
				finally
				{   
					// ContextUtil.popContext(context);
					//File delFile = new File(strGlobalWorkSpacePath+File.separator+strFileName);
					//delFile.delete();
					 
					 //Code to delete checkout images.
					//String strExportImagesFolder = EnoviaResourceBundle.getProperty(context,"WMS.ExportMeasurements.Image.FolderPath");
					//File dir = new File(strExportImagesFolder);
		
					//if(dir.isDirectory() == false) {
					//	System.out.println("Not a directory. Do nothing");
					//}
					//File[] listFiles = dir.listFiles();
					//for(File fileToDel : listFiles){
					//	fileToDel.delete();
					//} 
				 
				}
			}

		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		finally
		{
			DomainConstants.MULTI_VALUE_LIST.remove(SELECT_GENERIC_FORMAT_FILES);
			
			return strFileName;
		}
	}
	
	
	/**
     * Function to get xml element for Work Order details
     *
     * @param Document docWrite object to create xml elements
     * @param Map mapWODetails - Work Order details
     * @return XML element of Work Order details
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	public Element getWorkOrderDetails(Document docWrite,Map mapWODetails,Context context) throws Exception
	{
		
		Element ewoDetails= docWrite.createElement("wodetails");
		
		Element eDetails = docWrite.createElement("details");		
		Element ewolabel = docWrite.createElement("wolabel");
		Element ewovalue = docWrite.createElement("wovalue");


		Element eDetails1 = docWrite.createElement("details");		
		Element ewolabel1 = docWrite.createElement("wolabel");
		Element ewovalue1 = docWrite.createElement("wovalue");
		
		Element eDetails2 = docWrite.createElement("details");		
		Element ewolabel2 = docWrite.createElement("wolabel");
		Element ewovalue2 = docWrite.createElement("wovalue");
		
		
		Element eDetails3 = docWrite.createElement("details");		
		Element ewolabel3 = docWrite.createElement("wolabel");
		Element ewovalue3 = docWrite.createElement("wovalue");
		
		ewolabel.appendChild(docWrite.createTextNode("Name of Work"));
		ewovalue.appendChild(docWrite.createTextNode((String)mapWODetails.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]")));
		eDetails.appendChild(ewolabel);
		eDetails.appendChild(ewovalue);
		
		ewolabel1.appendChild(docWrite.createTextNode("Agreement Number"));
		ewovalue1.appendChild(docWrite.createTextNode((String)mapWODetails.get("attribute["+ATTRIBUTE_WMS_PO_NUMBER+"]")));
		eDetails1.appendChild(ewolabel1);
		eDetails1.appendChild(ewovalue1);
		
		ewolabel2.appendChild(docWrite.createTextNode("Agreement Date"));
		ewovalue2.appendChild(docWrite.createTextNode((String)mapWODetails.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"]")));
		eDetails2.appendChild(ewolabel2);
		eDetails2.appendChild(ewovalue2);
		
		ewolabel3.appendChild(docWrite.createTextNode("Name of Contractor"));
		String strContractor = (String)mapWODetails.get("to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.name");
		if(UIUtil.isNotNullAndNotEmpty(strContractor)){
			ewovalue3.appendChild(docWrite.createTextNode(strContractor));
		}else{
			ewovalue3.appendChild(docWrite.createTextNode(""));
		}
		
		eDetails3.appendChild(ewolabel3);
		eDetails3.appendChild(ewovalue3);
		
		ewoDetails.appendChild(eDetails);
		ewoDetails.appendChild(eDetails1);
		ewoDetails.appendChild(eDetails2);
		ewoDetails.appendChild(eDetails3);
		
		//System.out.println("mapWODetails1111---------"+mapWODetails);
		
		return ewoDetails;
	}
	
	/**
     * Function to get xml element for Measurements  details
     * @param context the eMatrix <code>Context</code> object
     * @param Document docWrite object to create xml elements
     * @param Map mapMBEDetails - MBE details
     * @param String strMBETitle - MBE title
     * @param String strMeasurementDate - MBE Measurement date
     * @return XML element of MBE details
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	//public Element getMBEMeasurementDetails(Context context,Document docWrite,MapList mapMBEDetails,String strMBENumber,String strAuthor,String strMBETitle,String strMeasurementDate) throws Exception
	public Element getMBEMeasurementDetails(Context context,Document docWrite,MapList mapMBEDetails,String strMBENumber,String strAuthor,String strMBETitle) throws Exception
	{		
	
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		
		String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
		String strLogo = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Logo");
		String strWatermark = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Watermark");
		strWatermark = strWatermark.replace("\\", "/");
		strLogo = strLogo.replace("\\", "/");
		Element embedetails = docWrite.createElement("mbedetails");
		Element embLogo = docWrite.createElement("logo1");
		Element embHeader = docWrite.createElement("header-footer");
		Element embWatermark = docWrite.createElement("watermark");
		Element embename = docWrite.createElement("mbename");
		//Element embedate = docWrite.createElement("mbedate");	
		Element embenumber = docWrite.createElement("mbenumber");	
		Element embeauthor = docWrite.createElement("owner");	
		embLogo.appendChild(docWrite.createTextNode("file:"+strLogo));
		embWatermark.appendChild(docWrite.createTextNode("file:"+strWatermark));
		strHeader = strMBENumber+"/DGNP";
		embHeader.appendChild(docWrite.createTextNode(strHeader));
		
		embename.appendChild(docWrite.createTextNode(strMBETitle));
		//embedate.appendChild(docWrite.createTextNode(strMeasurementDate));
		embenumber.appendChild(docWrite.createTextNode(strMBENumber));
		embeauthor.appendChild(docWrite.createTextNode(strAuthor));
		embedetails.appendChild(embLogo);
		embedetails.appendChild(embHeader);
		embedetails.appendChild(embWatermark);		
		embedetails.appendChild(embename);
		//embedetails.appendChild(embedate);
		embedetails.appendChild(embenumber);
		embedetails.appendChild(embeauthor);

		StringList strListMeasurementBusSelects = new StringList(2);
		strListMeasurementBusSelects.add(DomainObject.SELECT_IMAGE_HOLDER_ID);		
		strListMeasurementBusSelects.add(DomainObject.SELECT_ID);		
		SelectList selListRelSelects = getMeasurementInfoRelSelects();
		
		for(int i=0;i<mapMBEDetails.size();i++)
		{
			Map map = (Map)mapMBEDetails.get(i);
			if(map!=null&&!map.isEmpty())
			{
	
				Element eSOR = docWrite.createElement("SOR");
				Element eSerialNumber = docWrite.createElement("SOR_sno");
				Element eSOR_NAME = docWrite.createElement("SOR_NAME");
				Element eSOR_DES = docWrite.createElement("SOR_DES");
				Element eSOR_QUANTITY = docWrite.createElement("SOR_QUANTITY");
				eSerialNumber.appendChild(docWrite.createTextNode(String.valueOf(i+1)));
				eSOR_NAME.appendChild(docWrite.createTextNode((String)map.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]")));
				//System.out.println("a------");
				eSOR_DES.appendChild(docWrite.createTextNode((String)map.get("description")));
					//System.out.println("b------");
				double dSORQty = Double.parseDouble((String)map.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value"));	
					//System.out.println("c------");
				eSOR_QUANTITY.appendChild(docWrite.createTextNode(new BigDecimal(dSORQty).setScale(2, BigDecimal.ROUND_UP).toPlainString()));
					//System.out.println("d------");

				eSOR.appendChild(eSerialNumber);
				eSOR.appendChild(eSOR_NAME);
				eSOR.appendChild(eSOR_DES);
				eSOR.appendChild(eSOR_QUANTITY);
				
				StringList slRad = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"].value"));
				//System.out.println("slRad------"+slRad);
				StringList slRem = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_ASSESSMENT_COMMENTS+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_ASSESSMENT_COMMENTS+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_ASSESSMENT_COMMENTS+"].value"));
				//System.out.println("slRem------"+slRem);
				StringList sldep = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"].value"));
				//System.out.println("sldep------"+sldep);
				StringList slQty = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value"));
				//System.out.println("slQty------"+slQty);
				StringList slper = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+DomainObject.ATTRIBUTE_TITLE+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+DomainObject.ATTRIBUTE_TITLE+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+DomainObject.ATTRIBUTE_TITLE+"].value"));
				//System.out.println("slper------"+slper);
				StringList slcff = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"].value"));
				//System.out.println("slcff------"+slcff);
				StringList sluwd = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_UWD+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_UWD+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_UWD+"].value"));
				//System.out.println("sluwd------"+sluwd);
				StringList slded = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"].value"));
				//System.out.println("slded------"+slded);
				StringList slnum = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"].value"));
				//System.out.println("slnum------"+slnum);
				StringList sllen = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"].value"));
				//System.out.println("sllen------"+sllen);
				StringList slbre = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"].value"));
				//System.out.println("slbre------"+slbre);
				StringList slDim1 = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_1+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_1+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_1+"].value"));
				//System.out.println("slDim1------"+slDim1);
				StringList slDim2 = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_2+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_2+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_2+"].value"));
				//System.out.println("slDim2------"+slDim2);
				StringList slDim3 = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_3+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_3+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_3+"].value"));
				//System.out.println("slDim3------"+slDim3);
				StringList slDim4 = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_4+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_4+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_4+"].value"));
				//System.out.println("slDim4------"+slDim4);
				StringList slShapeImage = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_IMAGE+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_IMAGE+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_IMAGE+"].value"));
				//System.out.println("slShapeImage------"+slShapeImage);
				StringList slShapeName = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value"));
				//System.out.println("slShapeName------"+slShapeName);
				StringList slScope = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"].value"));
				//System.out.println("slScope------"+slScope);
				StringList slEEVal = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"].value"));
				//System.out.println("slEEVal------"+slEEVal);
				StringList slSEVal = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"].value"));
				//System.out.println("slSEVal------"+slSEVal);
				StringList slMod = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_MODIFIED+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_MODIFIED+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_MODIFIED+"].value"));
				//System.out.println("slMod------"+slMod);
				StringList slCommented = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_COMMENTED+"].value") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_COMMENTED+"].value") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_COMMENTED+"].value"));
				//System.out.println("slCommented------"+slCommented);
				StringList strListMeasurementOIDs = map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id") instanceof StringList ? (StringList) map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id") : new StringList((String)map.get("tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id"));
				//System.out.println("strListMeasurementOIDs------"+strListMeasurementOIDs);
				Map<String, String> mapMeasurementImageHolder = getMeasurementImageHolderOIDs(context,strListMeasurementBusSelects, strListMeasurementOIDs);
				for(int ii=0;ii<strListMeasurementOIDs.size();ii++)
				{
					Element eparticular1 = docWrite.createElement("particular1");
					Element eper1 = docWrite.createElement("per1");
					eper1.appendChild(docWrite.createTextNode((String)slper.get(ii)));
					Element en1 = docWrite.createElement("n1");
					en1.appendChild(docWrite.createTextNode((String)slnum.get(ii)));	

					Element itemtype = docWrite.createElement("item-type");
					String strBOQType = (String)map.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]");
					if("Tender Items".equals(strBOQType)){
						strBOQType = "Original";
					}
					if("Non-Tender Items".equals(strBOQType) || "Deviation".equals(strBOQType)){
						strBOQType = "Supple mental";
					}
					
					itemtype.appendChild(docWrite.createTextNode(strBOQType));	
					Element uom = docWrite.createElement("uom");
					uom.appendChild(docWrite.createTextNode((String)map.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]")));	
					
					Element scope1 = docWrite.createElement("scope");
					scope1.appendChild(docWrite.createTextNode((String)slScope.get(ii)));	
					Element eeVal = docWrite.createElement("ee");
					eeVal.appendChild(docWrite.createTextNode((String)slEEVal.get(ii)));
					Element seVal = docWrite.createElement("se");
					seVal.appendChild(docWrite.createTextNode((String)slSEVal.get(ii)));
					Element mod = docWrite.createElement("modified");
					mod.appendChild(docWrite.createTextNode((String)slMod.get(ii)));
					Element commented = docWrite.createElement("isCommented");
					commented.appendChild(docWrite.createTextNode((String)slCommented.get(ii)));
					/*Element er1 = docWrite.createElement("r1");
					if(UIUtil.isNotNullAndNotEmpty((String)slDim1.get(ii))){
					er1.appendChild(docWrite.createTextNode((String)slDim1.get(ii)));
					}
					else
					{
						er1.appendChild(docWrite.createTextNode((String)slRad.get(ii)));
					}*/
					Element el1 = docWrite.createElement("l1");
					if(UIUtil.isNotNullAndNotEmpty((String)slDim2.get(ii)))
					{
						el1.appendChild(docWrite.createTextNode((String)slDim2.get(ii)));
					}
					else if(UIUtil.isNotNullAndNotEmpty((String)slDim1.get(ii)))
					{
						el1.appendChild(docWrite.createTextNode((String)slDim1.get(ii)));
					}
					else
					{
						el1.appendChild(docWrite.createTextNode((String)sllen.get(ii)));
					}
					Element eb1 = docWrite.createElement("b1");
					if(UIUtil.isNotNullAndNotEmpty((String)slDim3.get(ii))){
						eb1.appendChild(docWrite.createTextNode((String)slDim3.get(ii)));
						}
						else
						{
							eb1.appendChild(docWrite.createTextNode((String)slbre.get(ii)));
						}
					Element ed1 = docWrite.createElement("d1");
					if(UIUtil.isNotNullAndNotEmpty((String)slDim4.get(ii))){
						ed1.appendChild(docWrite.createTextNode((String)slDim4.get(ii)));
						}
						else
						{
							ed1.appendChild(docWrite.createTextNode((String)sldep.get(ii)));
						}
					Element ece1 = docWrite.createElement("ce1");
					ece1.appendChild(docWrite.createTextNode((String)slcff.get(ii)));
					Element eq1 = docWrite.createElement("q1");
					String strQtry = "";
					if(slQty!= null && (slQty.size()>0&&slQty.get(0)!=null)){
					strQtry = (String)slQty.get(ii);
					if(UIUtil.isNotNullAndNotEmpty(strQtry)){
					double dQty = Double.parseDouble(strQtry);					
					eq1.appendChild(docWrite.createTextNode(new BigDecimal(dQty).setScale(2, BigDecimal.ROUND_UP).toPlainString()));
					}
					}
					Element erm1 = docWrite.createElement("rm1");
					erm1.appendChild(docWrite.createTextNode((String)slRem.get(ii)));
					Element deduction = docWrite.createElement("deduction");
					deduction.appendChild(docWrite.createTextNode((String)slded.get(ii)));
					Element eded1 = docWrite.createElement("ded1");
					eded1.appendChild(docWrite.createTextNode((String)slded.get(ii)));
					Element euwd1 = docWrite.createElement("uwt");
					euwd1.appendChild(docWrite.createTextNode((String)sluwd.get(ii)));
					StringList slimg = getGenericFormatImageNames(context,mapMeasurementImageHolder,(String)strListMeasurementOIDs.get(ii));
					Element eimgholder = docWrite.createElement("imgholder");
					
					for(int p=0;p<slimg.size();p++)
					{
						Element eimg = docWrite.createElement("img");
						if(UIUtil.isNotNullAndNotEmpty((String)slShapeImage.get(ii)))
						{
							String strSVGContent = getFileForShape(context,(String)slShapeImage.get(ii),(String)slDim1.get(ii),(String)slDim2.get(ii),(String)slDim3.get(ii),(String)slDim4.get(ii));
							Element eshapeimg = docWrite.createElement("imgShape");
							eshapeimg.appendChild(docWrite.createTextNode(strSVGContent));
							eimg.appendChild(eshapeimg);
							eimgholder.appendChild(eimg);
						}						
						Element eimgsrc = docWrite.createElement("imgsrc");
						eimgsrc.appendChild(docWrite.createTextNode((String)slimg.get(p)));
						eimg.appendChild(eimgsrc);
						eimgholder.appendChild(eimg);						
					}
					if(UIUtil.isNotNullAndNotEmpty((String)slShapeImage.get(ii))&&slimg.size()==0)
					{
						Element eimg = docWrite.createElement("img");
						String strSVGContent = getFileForShape(context,(String)slShapeImage.get(ii),(String)slDim1.get(ii),(String)slDim2.get(ii),(String)slDim3.get(ii),(String)slDim4.get(ii));
						Element eshapeimg = docWrite.createElement("imgShape");
						eshapeimg.appendChild(docWrite.createTextNode(strSVGContent));
						eimg.appendChild(eshapeimg);
						eimgholder.appendChild(eimg);
					}
					
					eparticular1.appendChild(eimgholder);
					eparticular1.appendChild(eper1);
					eparticular1.appendChild(en1);
					eparticular1.appendChild(el1);
					eparticular1.appendChild(eb1);
					eparticular1.appendChild(ed1);
					//eparticular1.appendChild(er1);
					eparticular1.appendChild(ece1);
					eparticular1.appendChild(eq1);
					eparticular1.appendChild(erm1);
					eparticular1.appendChild(eded1);
					eparticular1.appendChild(euwd1);
					eparticular1.appendChild(itemtype);
					eparticular1.appendChild(uom);
					eparticular1.appendChild(scope1);
					eparticular1.appendChild(eeVal);
					eparticular1.appendChild(seVal);
					eparticular1.appendChild(mod);
					eparticular1.appendChild(commented);
					eparticular1.appendChild(deduction);
					eSOR.appendChild(eparticular1);
					
				}
				embedetails.appendChild(eSOR);
			}


		}
		
		return embedetails;
	}
	
	/**
     * Function to get xml to generate pdf
     * @param Document docWrite object to create xml elements
     * @param ArrayList<Element>arrMBEElement - MBE detail element
     * @param Element woElement - Work Order element
     * @return Document object for xml
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	public Document generateXMLForMeasurements(Document docWrite,ArrayList<Element>arrMBEElement,Element woElement) throws Exception
	{		
		Element ePage = docWrite.createElement("page");
		ePage.appendChild(woElement);
		
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		
		String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
		String strLogo = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Logo");
		String strWatermark = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Watermark");
		strWatermark = strWatermark.replace("\\", "/");
		strLogo = strLogo.replace("\\", "/");
		Element embLogo = docWrite.createElement("logo1");
		embLogo.appendChild(docWrite.createTextNode("file:"+strLogo));
		
		Element embHeader = docWrite.createElement("header-footer");
		Element embWatermark = docWrite.createElement("watermark");
		embWatermark.appendChild(docWrite.createTextNode("file:"+strWatermark));
		
		embHeader.appendChild(docWrite.createTextNode(strHeader));
		
		ePage.appendChild(embHeader);
		ePage.appendChild(embWatermark);
		ePage.appendChild(embLogo);
		
		for(int i=0;i<arrMBEElement.size();i++)
		{
			ePage.appendChild(arrMBEElement.get(i));
		}
		
		docWrite.appendChild(ePage);
		return docWrite;
	}
	
	/**
     * Function to Measurements images(location of images with name)
     * @param Context context
     * @param Map<String,String> mapMeasurementImageHolder - Image Holder object details
     * @param String strMeasurementOID - Measurement object id
     * @return StringList measurement file names 
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	private StringList getGenericFormatImageNames(Context context,
			Map<String,String> mapMeasurementImageHolder,String strMeasurementOID) throws Exception {
		StringList genericFormatImageNames = new StringList();
		StringList slFileNames = new StringList();
		String strWorkSpacePath = context.getWorkspacePath();
		StringList strListImageHolderBusSelects = new StringList(6);
		strListImageHolderBusSelects.add(SELECT_ATTRIBUTE_PRIMARY_IMAGE_FROM_ALTPATH);
		strListImageHolderBusSelects.add(SELECT_ATTRIBUTE_TRAVERSE_ALTPATH);
		strListImageHolderBusSelects.add(DomainObject.SELECT_MX_SMALL_IMAGE_FILE_NAMES);
		strListImageHolderBusSelects.add(SELECT_GENERIC_FORMAT_FILES);
		DomainConstants.MULTI_VALUE_LIST.add(SELECT_GENERIC_FORMAT_FILES);
		
		String strImageHolderOID = mapMeasurementImageHolder.get(strMeasurementOID);
		if(UIUtil.isNotNullAndNotEmpty(strImageHolderOID)){
		DomainObject domObjImageHolder = DomainObject.newInstance(context,strImageHolderOID);
		Map<String,Object> imgHolderObjMaplist = domObjImageHolder.getInfo(context, strListImageHolderBusSelects);
		
		Object obj = imgHolderObjMaplist.get(DomainObject.SELECT_MX_SMALL_IMAGE_FILE_NAMES);
		if(obj instanceof String) {
		    genericFormatImageNames = new StringList((String)imgHolderObjMaplist.get(SELECT_GENERIC_FORMAT_FILES));
		} else if(obj instanceof StringList) {
		    genericFormatImageNames =new StringList((StringList)imgHolderObjMaplist.get(SELECT_GENERIC_FORMAT_FILES));
		} else {
		    genericFormatImageNames = new StringList();
		}
		slFileNames = getFileName(context, genericFormatImageNames, domObjImageHolder, strGlobalWorkSpacePath,strMeasurementOID);
		}
		return slFileNames;
	}
	
	/**
     * Function to get image holder id of specific measurement object
     * @param Context context
     * @param StringList strListImageHolderBusSelects - select for image holder
     * @param String strMeasurementOID - Measurement object id
     * @return StringList strListMeasurementOIDs - measurement ids
     * @return Map image holder id for specific measurement
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
	private Map<String, String> getMeasurementImageHolderOIDs(Context context, StringList strListImageHolderBusSelects,
			StringList strListMeasurementOIDs) throws FrameworkException {
		String oidsArray[] = new String[strListMeasurementOIDs.size()];
		strListMeasurementOIDs.toArray(oidsArray);

		MapList mapListImageHolder = DomainObject.getInfo(context, oidsArray, strListImageHolderBusSelects);
		Map<String,String> mapMeasurementImageHolder = new HashMap<String,String>(mapListImageHolder.size());
		Map<String,String> mapImageHolderData;
		Iterator<Map<String,String>> iteratorImageHolder = mapListImageHolder.iterator();
		while(iteratorImageHolder.hasNext())
		{
			mapImageHolderData =iteratorImageHolder.next();
			mapMeasurementImageHolder.put(mapImageHolderData.get(DomainObject.SELECT_ID), mapImageHolderData.get(DomainObject.SELECT_IMAGE_HOLDER_ID));
		}
		return mapMeasurementImageHolder;
	}
	
	/**
     * Function to get file name and location as per image holder object
     * @param Context context
     * @param StringList genericFormatImageNames - image names
     * @param DomainObject domObjImageHolder - image holder object
     * @return String strWorkSpacePath - Work space path
     * @return file name
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	private StringList getFileName(Context context,StringList genericFormatImageNames,DomainObject domObjImageHolder,String strWorkSpacePath,String strMeasurementOID) throws Exception
	{
		String strExportImagesFolder = EnoviaResourceBundle.getProperty(context,"WMS.ExportMeasurements.Image.FolderPath");
		StringList slFileName = new StringList();
		FileList files = getGenericFormatFiles(genericFormatImageNames);
		domObjImageHolder.checkoutFiles(context, false, FORMAT_GENERIC, files, strExportImagesFolder);
		Iterator<String> iteratorImage = genericFormatImageNames.iterator();
		while(iteratorImage.hasNext())
		{
			String strImageName = iteratorImage.next();
			//slFileName.add(strExportImagesFolder+ File.separator + strImageName);			
			slFileName.add(strImageName);			
		}
		slFileName = getFinalImageList(context,slFileName,strExportImagesFolder,strMeasurementOID);
		return slFileName;
	}
	
	/**
     * Function to get file name 
     * @param StringList genericFormatImageNames - image name
     * @return FileList
     * @author WMS
     * @since 418
     */
	private FileList getGenericFormatFiles(StringList genericFormatImageNames) {
		FileList files = new FileList();
		Iterator<String> iteratorImageFielNames = genericFormatImageNames.iterator();
		while(iteratorImageFielNames.hasNext())
		{
			String strFileName = iteratorImageFielNames.next();
			matrix.db.File file = new matrix.db.File(strFileName, FORMAT_GENERIC);
			files.addElement(file);
		}
		return files;
	}
	/**
     * Function to get file name to show shape on pdf  file 
     * @param Context
     * @param String filename
     * @param String dimensions
     * @return String full path of file
     * @author WMS
     * @since 418
     */
	public String getFileForShape(Context context,String sSVGFile,String sDim1,String sDim2,String sDim3,String sDim4) throws Exception
	{
		String sSVGContent=DomainConstants.EMPTY_STRING;
		
		String dim1="";
		String dim2="";
		String dim3="";
		String dim4="";
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		
		String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
		
		strpath = newFile.getCanonicalPath()+strImageFolder+sSVGFile;
		newFile = new File(strpath);
		String parser = XMLResourceDescriptor.getXMLParserClassName();
		SAXSVGDocumentFactory f = new SAXSVGDocumentFactory(parser);
		java.net.URI localFileAsUri = newFile.toURI(); 
		String uri = localFileAsUri.toASCIIString();
		Document svgDoc = f.createDocument(uri);
		NodeList nodes = svgDoc.getChildNodes();
		Element elmD1 = (Element)svgDoc.getElementById("D1");
		Element elmD2 = (Element)svgDoc.getElementById("D2");
		Element elmD3 = (Element)svgDoc.getElementById("D3");
		Element elmD4 = (Element)svgDoc.getElementById("D4");
		NodeList nodeList = svgDoc.getElementsByTagName("svg");
		Node rootNode = (Node)nodeList.item(0);
		Element rootElement = (Element)rootNode;
		rootElement.setAttribute("width", "250");
		rootElement.setAttribute("height", "250");
		if(elmD1!=null)
		{
			dim1 = elmD1.getTextContent();
			elmD1.setTextContent(sDim1);
		}
		if(elmD2!=null)
		{
			dim2 = elmD2.getTextContent();
			elmD2.setTextContent(sDim2);
		}
		if(elmD3!=null)
		{
			dim3 = elmD3.getTextContent();
			elmD3.setTextContent(sDim3);
		}	
		if(elmD4!=null)
		{
			dim4 = elmD4.getTextContent();
			elmD4.setTextContent(sDim4);
		}	
		
		DOMSource domSource = new DOMSource(svgDoc);
		StringWriter writer = new StringWriter();
		String strWS = EnoviaResourceBundle.getProperty(context,"WMS.ExportMeasurements.Image.FolderPath");
		//String strWS = context.createWorkspace();
		String strFileName = "MBE_Export-"+Calendar.getInstance().getTimeInMillis()+".svg";
		FileOutputStream outputStream = new FileOutputStream(strWS+File.separator+strFileName);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		StreamResult result = new StreamResult(outputStream);
		transformer.transform(domSource, result);
		String svg_URI_input = new File(strWS+File.separator+strFileName).toURI().toURL().toString();
		InputStream svg_istream = new FileInputStream(strWS+File.separator+strFileName);		 
		TranscoderInput input_svg_image = new TranscoderInput(svg_URI_input);        
        //Step-2: Define OutputStream to JPG file and attach to TranscoderOutput
        String strOutputFileName = "MBE_Export-"+Calendar.getInstance().getTimeInMillis()+".jpg";
        //OutputStream jpg_ostream = new FileOutputStream(strWS+File.separator+strOutputFileName);
        //TranscoderOutput output_jpg_image = new TranscoderOutput(jpg_ostream);              
        OutputStream png_ostream = new FileOutputStream(strWS+File.separator+strOutputFileName);
        TranscoderOutput output_png_image = new TranscoderOutput(png_ostream);              
        // Step-3: Create PNGTranscoder and define hints if required
        JPEGTranscoder my_converter = new JPEGTranscoder();        
        // Step-4: Convert and Write output
        my_converter.addTranscodingHint(JPEGTranscoder.KEY_QUALITY,new Float(.9));
        my_converter.transcode(input_svg_image, output_png_image);
        // Step 5- close / flush Output Stream
        png_ostream.flush();
        png_ostream.close();    
		outputStream.flush();
		outputStream.close();		
		sSVGContent=strWS+File.separator+strOutputFileName;		
		sSVGContent = sSVGContent.replace("\\", "/");
		sSVGContent = "file:"+sSVGContent;
		return sSVGContent;
	}
	
	private StringList getFinalImageList(Context context, StringList slImageList,String strExportImagesFolder,String strMeasurementOID) throws Exception
	{
		DomainObject doMeas = new DomainObject(strMeasurementOID);
		String strName = (String)doMeas.getInfo(context,DomainObject.SELECT_NAME);
		StringList slFinalImageList = new StringList();
		
		int iTotalWidth = 0;
		int iTotalHeight = 0;
		
		
		
		int iSize = slImageList.size();
		
		int iMaxWidth = 0; 
		int iMaxHeight = 0; 
		for(int i=0;i<slImageList.size();i++){
			File file1 = new File(strExportImagesFolder+File.separator+(String)slImageList.get(i));
			BufferedImage img1 = ImageIO.read(file1);
			
			int widthImg1 = img1.getWidth();
			int heightImg1 = img1.getHeight();
			
			if(widthImg1 > iMaxWidth)
				iMaxWidth = widthImg1;
			
			if(heightImg1 > iMaxHeight)
				iMaxHeight = widthImg1;
			
		}
		BufferedImage img = new BufferedImage(
				iMaxWidth*iSize, // Final image will have width and height as
				iMaxHeight, // addition of widths and heights of the images we already have
				BufferedImage.TYPE_INT_RGB);
				
		for(int i=0;i<slImageList.size();i++){
			File file1 = new File(strExportImagesFolder+File.separator+(String)slImageList.get(i));
			BufferedImage img1 = ImageIO.read(file1);
			
			int widthImg1 = img1.getWidth();
			int heightImg1 = img1.getHeight();
			
			if(i==0){
				iTotalWidth = 0;
			}else{
				iTotalWidth = iTotalWidth+widthImg1;
			}
			iTotalHeight = heightImg1;
			
			if(i==0){
				Graphics2D g2d = img.createGraphics();
				g2d.setColor(Color.WHITE);
				g2d.fillRect(0, 0, iMaxWidth*iSize, iMaxHeight);
				boolean image1Drawn = g2d.drawImage(img1, 0, 0, null); // 0, 0 are the x and y positions
				if(!image1Drawn) System.out.println("Problems drawing first image");
			}else{
				Graphics2D g2d = img.createGraphics();
				g2d.setColor(Color.WHITE);
				boolean image1Drawn = g2d.drawImage(img1, iTotalWidth, 0, null); // 0, 0 are the x and y positions
				if(!image1Drawn) System.out.println("Problems drawing first image");
			}
		}
		
		File final_image = new File(strExportImagesFolder+File.separator+strName+".jpg"); // â€œpng can also be used hereâ€�
		boolean final_Image_drawing = ImageIO.write(img, "jpeg", final_image); //if png is used, write â€œpngâ€� instead â€œjpegâ€�
		if(!final_Image_drawing) System.out.println("Problems drawing final image");
		
		String strFinalImagePath = strExportImagesFolder+File.separator+strName+".jpg";
		strFinalImagePath = strFinalImagePath.replace("\\", "/");
		strFinalImagePath = "file:"+strFinalImagePath;
		slFinalImageList.add(strFinalImagePath);
		return slFinalImageList;
	}
	
	
	private Map consolidateMeasurement(Context context, MapList mbMeasurementList,Map hmConsolidatedMeasurementMap)throws Exception{
		
		String strQtySelect = "attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"].value";
		String strUWDSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_UWD+"].value";
		String strTitleSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+DomainObject.ATTRIBUTE_TITLE+"].value";
		String strActivitySelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.id";
		String strDeductionSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_DEDUCTION+"].value";
		String strCoeffSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_ITEM_CO_EFFICIENT_FACTOR+"].value";
		String strBreadthSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_BREADTH+"].value";
		String strManualQtySelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_MANUALQUANTITY+"].value";
		String strRadiusSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_RADIUS+"].value";
		String strLengthSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_LENGTH+"].value";
		String strFreqSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_FREQUENCY+"].value";
		String strDepthSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MBE_DEPTH+"].value";
		String strItemEntrySelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value";
		String strAssCommSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_ASSESSMENT_COMMENTS+"].value";
		String strDim1Select = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_1+"].value";
		String strDim2Select = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_2+"].value";
		String strDim3Select = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_3+"].value";
		String strDim4Select = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_DIMENSION_4+"].value";
		String strShapeImageSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_IMAGE+"].value";
		String strShapeNameSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SHAPE_NAME+"].value";
		String strScopeSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_MEASUREMENT_SCOPE+"].value";
		String strEESelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"].value";
		String strSESelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"].value";
		String strModSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_MODIFIED+"].value";
		String strCommentedSelect = "tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"].from.attribute["+ATTRIBUTE_WMS_IS_COMMENTED+"].value";
		
		Map map = null;
		for(int i=0;i<mbMeasurementList.size();i++){	
			map = (Map)	mbMeasurementList.get(i);	
			
			//System.out.println("map----Test------"+map);
			
			String strTitle = (String)map.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"]");
			String strDescription = (String)map.get("description");
			
			String strUOM = (String)map.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
			String strTypeOfBOQ = (String)map.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]");
						
			StringList slRad = map.get(strRadiusSelect) instanceof StringList ? (StringList) map.get(strRadiusSelect) : new StringList((String)map.get(strRadiusSelect));
			
			StringList slRem = map.get(strAssCommSelect) instanceof StringList ? (StringList) map.get(strAssCommSelect) : new StringList((String)map.get(strAssCommSelect));
			
			StringList sldep = map.get(strDepthSelect) instanceof StringList ? (StringList) map.get(strDepthSelect) : new StringList((String)map.get(strDepthSelect));
			
			StringList slQty = map.get(strItemEntrySelect) instanceof StringList ? (StringList) map.get(strItemEntrySelect) : new StringList((String)map.get(strItemEntrySelect));
			
			StringList slper = map.get(strTitleSelect) instanceof StringList ? (StringList) map.get(strTitleSelect) : new StringList((String)map.get(strTitleSelect));
			
			StringList slcff = map.get(strCoeffSelect) instanceof StringList ? (StringList) map.get(strCoeffSelect) : new StringList((String)map.get(strCoeffSelect));
			
			StringList sluwd = map.get(strUWDSelect) instanceof StringList ? (StringList) map.get(strUWDSelect) : new StringList((String)map.get(strUWDSelect));
			
			StringList slded = map.get(strDeductionSelect) instanceof StringList ? (StringList) map.get(strDeductionSelect) : new StringList((String)map.get(strDeductionSelect));
			
			StringList slnum = map.get(strFreqSelect) instanceof StringList ? (StringList) map.get(strFreqSelect) : new StringList((String)map.get(strFreqSelect));
			
			StringList sllen = map.get(strLengthSelect) instanceof StringList ? (StringList) map.get(strLengthSelect) : new StringList((String)map.get(strLengthSelect));
			
			StringList slbre = map.get(strBreadthSelect) instanceof StringList ? (StringList) map.get(strBreadthSelect) : new StringList((String)map.get(strBreadthSelect));
			
			StringList slDim1 = map.get(strDim1Select) instanceof StringList ? (StringList) map.get(strDim1Select) : new StringList((String)map.get(strDim1Select));
			
			StringList slDim2 = map.get(strDim2Select) instanceof StringList ? (StringList) map.get(strDim2Select) : new StringList((String)map.get(strDim2Select));
			
			StringList slDim3 = map.get(strDim3Select) instanceof StringList ? (StringList) map.get(strDim3Select) : new StringList((String)map.get(strDim3Select));
			
			StringList slDim4 = map.get(strDim4Select) instanceof StringList ? (StringList) map.get(strDim4Select) : new StringList((String)map.get(strDim4Select));
			
			StringList slShapeImage = map.get(strShapeImageSelect) instanceof StringList ? (StringList) map.get(strShapeImageSelect) : new StringList((String)map.get(strShapeImageSelect));
			
			StringList slShapeName = map.get(strShapeNameSelect) instanceof StringList ? (StringList) map.get(strShapeNameSelect) : new StringList((String)map.get(strShapeNameSelect));
			
			StringList strListMeasurementOIDs = map.get(strActivitySelect) instanceof StringList ? (StringList) map.get(strActivitySelect) : new StringList((String)map.get(strActivitySelect));
			
			StringList slScope = map.get(strScopeSelect) instanceof StringList ? (StringList) map.get(strScopeSelect) : new StringList((String)map.get(strScopeSelect));
			
			StringList slEEVal = map.get(strEESelect) instanceof StringList ? (StringList) map.get(strEESelect) : new StringList((String)map.get(strEESelect));
			
			StringList slSEVal = map.get(strSESelect) instanceof StringList ? (StringList) map.get(strSESelect) : new StringList((String)map.get(strSESelect));
			
			StringList slMod = map.get(strModSelect) instanceof StringList ? (StringList) map.get(strModSelect) : new StringList((String)map.get(strModSelect));
			
			StringList slCommented = map.get(strCommentedSelect) instanceof StringList ? (StringList) map.get(strCommentedSelect) : new StringList((String)map.get(strCommentedSelect));
			
			
		
			if(hmConsolidatedMeasurementMap.containsKey(strTitle)){
				Map mTempMap = (Map)hmConsolidatedMeasurementMap.get(strTitle);
				
				StringList slRadPrev = mTempMap.get(strRadiusSelect) instanceof StringList ? (StringList) mTempMap.get(strRadiusSelect) : new StringList((String)mTempMap.get(strRadiusSelect));
				slRadPrev.addAll(slRad);
			
				StringList slRemPrev = mTempMap.get(strAssCommSelect) instanceof StringList ? (StringList) mTempMap.get(strAssCommSelect) : new StringList((String)mTempMap.get(strAssCommSelect));
				slRemPrev.addAll(slRem);
				
				StringList sldepPrev = mTempMap.get(strDepthSelect) instanceof StringList ? (StringList) mTempMap.get(strDepthSelect) : new StringList((String)mTempMap.get(strDepthSelect));
				sldepPrev.addAll(sldep);
				
				StringList slQtyPrev = mTempMap.get(strItemEntrySelect) instanceof StringList ? (StringList) mTempMap.get(strItemEntrySelect) : new StringList((String)mTempMap.get(strItemEntrySelect));
				slQtyPrev.addAll(slQty);
				
				StringList slperPrev = mTempMap.get(strTitleSelect) instanceof StringList ? (StringList) mTempMap.get(strTitleSelect) : new StringList((String)mTempMap.get(strTitleSelect));
				slperPrev.addAll(slper);
				
				StringList slcffPrev = mTempMap.get(strCoeffSelect) instanceof StringList ? (StringList) mTempMap.get(strCoeffSelect) : new StringList((String)mTempMap.get(strCoeffSelect));
				slcffPrev.addAll(slcff);
				
				StringList sluwdPrev = mTempMap.get(strUWDSelect) instanceof StringList ? (StringList) mTempMap.get(strUWDSelect) : new StringList((String)mTempMap.get(strUWDSelect));
				sluwdPrev.addAll(sluwd);
				
				StringList sldedPrev = mTempMap.get(strDeductionSelect) instanceof StringList ? (StringList) mTempMap.get(strDeductionSelect) : new StringList((String)mTempMap.get(strDeductionSelect));
				sldedPrev.addAll(slded);

				StringList slnumPrev = mTempMap.get(strFreqSelect) instanceof StringList ? (StringList) mTempMap.get(strFreqSelect) : new StringList((String)mTempMap.get(strFreqSelect));
				slnumPrev.addAll(slnum);
				
				StringList sllenPrev = mTempMap.get(strLengthSelect) instanceof StringList ? (StringList) mTempMap.get(strLengthSelect) : new StringList((String)mTempMap.get(strLengthSelect));
				sllenPrev.addAll(sllen);

				StringList slbrePrev = mTempMap.get(strBreadthSelect) instanceof StringList ? (StringList) mTempMap.get(strBreadthSelect) : new StringList((String)mTempMap.get(strBreadthSelect));
				slbrePrev.addAll(slbre);
				
				StringList slDim1Prev = mTempMap.get(strDim1Select) instanceof StringList ? (StringList) mTempMap.get(strDim1Select) : new StringList((String)mTempMap.get(strDim1Select));
				slDim1Prev.addAll(slDim1);
				
				StringList slDim2Prev = mTempMap.get(strDim2Select) instanceof StringList ? (StringList) mTempMap.get(strDim2Select) : new StringList((String)mTempMap.get(strDim2Select));
				slDim2Prev.addAll(slDim2);
				
				StringList slDim3Prev = mTempMap.get(strDim3Select) instanceof StringList ? (StringList) mTempMap.get(strDim3Select) : new StringList((String)mTempMap.get(strDim3Select));
				slDim3Prev.addAll(slDim3);
				
				StringList slDim4Prev = mTempMap.get(strDim4Select) instanceof StringList ? (StringList) mTempMap.get(strDim4Select) : new StringList((String)mTempMap.get(strDim4Select));
				slDim4Prev.addAll(slDim4);
				
				StringList slShapeImagePrev = mTempMap.get(strShapeImageSelect) instanceof StringList ? (StringList) mTempMap.get(strShapeImageSelect) : new StringList((String)mTempMap.get(strShapeImageSelect));
				slShapeImagePrev.addAll(slShapeImage);
				
				StringList slShapeNamePrev = mTempMap.get(strShapeNameSelect) instanceof StringList ? (StringList) mTempMap.get(strShapeNameSelect) : new StringList((String)mTempMap.get(strShapeNameSelect));
				slShapeNamePrev.addAll(slShapeName);
				
				StringList strListMeasurementOIDsPrev = mTempMap.get(strActivitySelect) instanceof StringList ? (StringList) mTempMap.get(strActivitySelect) : new StringList((String)mTempMap.get(strActivitySelect));
				strListMeasurementOIDsPrev.addAll(strListMeasurementOIDs);
				
				StringList slScopePrev = mTempMap.get(strScopeSelect) instanceof StringList ? (StringList) mTempMap.get(strScopeSelect) : new StringList((String)mTempMap.get(strScopeSelect));
				slScopePrev.addAll(slScope);
				
				StringList slEEValPrev = mTempMap.get(strEESelect) instanceof StringList ? (StringList) mTempMap.get(strEESelect) : new StringList((String)mTempMap.get(strEESelect));
				slEEValPrev.addAll(slEEVal);
				
				StringList slSEValPrev = mTempMap.get(strSESelect) instanceof StringList ? (StringList) mTempMap.get(strSESelect) : new StringList((String)mTempMap.get(strSESelect));
				slSEValPrev.addAll(slSEVal);
				
				StringList slModPrev = mTempMap.get(strModSelect) instanceof StringList ? (StringList) mTempMap.get(strModSelect) : new StringList((String)mTempMap.get(strModSelect));
				slModPrev.addAll(slMod);
				
				StringList slCommentedPrev = mTempMap.get(strCommentedSelect) instanceof StringList ? (StringList) mTempMap.get(strCommentedSelect) : new StringList((String)mTempMap.get(strCommentedSelect));
				slCommentedPrev.addAll(slCommented);
				
				double dTotalQty = 0;
				for(int k=0;k<slQtyPrev.size();k++){
					dTotalQty = dTotalQty + Double.valueOf((String)slQtyPrev.get(k));					
				}
				String strEnterQty = new BigDecimal(dTotalQty).setScale(2, BigDecimal.ROUND_UP).toPlainString();
				mTempMap.put("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value",strEnterQty);
				mTempMap.put(strRadiusSelect,slRadPrev);
				mTempMap.put(strAssCommSelect,slRemPrev);
				mTempMap.put(strDepthSelect,sldepPrev);
				mTempMap.put(strItemEntrySelect,slQtyPrev);
				mTempMap.put(strTitleSelect,slperPrev);
				mTempMap.put(strCoeffSelect,slcffPrev);
				mTempMap.put(strUWDSelect,sluwdPrev);
				mTempMap.put(strDeductionSelect,sldedPrev);
				mTempMap.put(strFreqSelect,slnumPrev);
				mTempMap.put(strLengthSelect,sllenPrev);
				mTempMap.put(strBreadthSelect,slbrePrev);
				mTempMap.put(strDim1Select,slDim1Prev);
				mTempMap.put(strDim2Select,slDim2Prev);
				mTempMap.put(strDim3Select,slDim3Prev);
				mTempMap.put(strDim4Select,slDim4Prev);
				mTempMap.put(strShapeImageSelect,slShapeImagePrev);
				mTempMap.put(strShapeNameSelect,slShapeNamePrev);
				mTempMap.put(strActivitySelect,strListMeasurementOIDsPrev);
				mTempMap.put(strScopeSelect,slScopePrev);
				mTempMap.put(strEESelect,slEEValPrev);
				mTempMap.put(strSESelect,slSEValPrev);
				mTempMap.put(strModSelect,slModPrev);
				mTempMap.put(strCommentedSelect,slCommentedPrev);
				
				hmConsolidatedMeasurementMap.put(strTitle,mTempMap);
			}else{
				Map mTempMap = new HashMap();
				mTempMap.put("attribute["+DomainObject.ATTRIBUTE_TITLE+"]",strTitle);
				mTempMap.put("description",strDescription);
				mTempMap.put("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]",strUOM);
				mTempMap.put("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]",strTypeOfBOQ);
				
				double dTotalQty = 0;
				for(int k=0;k<slQty.size();k++){
					dTotalQty = dTotalQty + Double.valueOf((String)slQty.get(k));					
				}
				String strEnterQty = new BigDecimal(dTotalQty).setScale(2, BigDecimal.ROUND_UP).toPlainString();
				
				mTempMap.put("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value",strEnterQty);
				mTempMap.put(strRadiusSelect,slRad);
				mTempMap.put(strAssCommSelect,slRem);
				mTempMap.put(strDepthSelect,sldep);
				mTempMap.put(strItemEntrySelect,slQty);
				mTempMap.put(strTitleSelect,slper);
				mTempMap.put(strCoeffSelect,slcff);
				mTempMap.put(strUWDSelect,sluwd);
				mTempMap.put(strDeductionSelect,slded);
				mTempMap.put(strFreqSelect,slnum);
				mTempMap.put(strLengthSelect,sllen);
				mTempMap.put(strBreadthSelect,slbre);
				mTempMap.put(strDim1Select,slDim1);
				mTempMap.put(strDim2Select,slDim2);
				mTempMap.put(strDim3Select,slDim3);
				mTempMap.put(strDim4Select,slDim4);
				mTempMap.put(strShapeImageSelect,slShapeImage);
				mTempMap.put(strShapeNameSelect,slShapeName);
				mTempMap.put(strActivitySelect,strListMeasurementOIDs);
				mTempMap.put(strScopeSelect,slScope);
				mTempMap.put(strEESelect,slEEVal);
				mTempMap.put(strSESelect,slSEVal);
				mTempMap.put(strModSelect,slMod);
				mTempMap.put(strCommentedSelect,slCommented);
				
				hmConsolidatedMeasurementMap.put(strTitle,mTempMap);
			}
		
		
		}
		return hmConsolidatedMeasurementMap;
	}
	
}
