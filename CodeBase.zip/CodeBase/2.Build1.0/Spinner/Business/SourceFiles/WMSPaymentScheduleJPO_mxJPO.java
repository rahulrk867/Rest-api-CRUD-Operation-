/** Name of the JPO     : WMSPaymentScheduleJPO_mxJPO
 ** Developed by        : DS 
 ** Client              : WMS
 ** Description         : 
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/


import matrix.db.Context;

import com.matrixone.apps.domain.util.EnoviaResourceBundle;

/**
 * The purpose of this JPO is to create a Range for attributes.
 * @author WMS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSPaymentScheduleJPO_mxJPO extends WMSPaymentScheduleJPOBase_mxJPO
{
    /**
     * Create a new ${CLASS:MarketingFeature} object from a given id.
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments.
     * @throws Exception if the operation fails
     * @author WMS
     * @since R418
     */

    public WMSPaymentScheduleJPO_mxJPO (Context context, String[] args)
        throws Exception
    {
      super(context, args);
    }

}
