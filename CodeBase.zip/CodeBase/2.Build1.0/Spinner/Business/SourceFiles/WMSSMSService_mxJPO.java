/**
 *  WMSSMSService_mxJPO.java
 *
 * (c) Dassault Systemes, 1993 - 2017. All rights reserved.
 * This program contains proprietary and trade secret information of
 * ENOVIA MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.Map;

import matrix.util.StringList;
import matrix.db.Context;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;

 /**
 * This JPO includes the code related to the Approval History Functionality
 */
public class WMSSMSService_mxJPO extends WMSConstants_mxJPO
{

 /**
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments
     * @throws Exception if the operation fails
     * @grade 0
     */
    public WMSSMSService_mxJPO (Context context, String[] args) throws Exception
    {
		super(context,args);
    }
	
	
	public void sendSMSOnTaskAssignment(Context context, String[] args)throws Exception{
		try{
			String strPersonId = (String)args[1];
			String strInboxId = (String)args[0];
			String strEnableSMS =  EnoviaResourceBundle.getProperty(context,"WMS.SMSService.Enable");
			if(UIUtil.isNotNullAndNotEmpty(strEnableSMS) && "true".equalsIgnoreCase(strEnableSMS)){
				String strObjType = DomainConstants.EMPTY_STRING;
				String strObjNumber = DomainConstants.EMPTY_STRING;
				if(UIUtil.isNotNullAndNotEmpty(strInboxId)){
					String strMqlQuery = "print bus "+strInboxId+" select from["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"].from.id dump";
					String strAMBObjectId = MqlUtil.mqlCommand(context,strMqlQuery);
					
					if(UIUtil.isNotNullAndNotEmpty(strAMBObjectId)){
						DomainObject doAMBE = new DomainObject(strAMBObjectId);
						StringList slAMBESelect = new StringList();
						slAMBESelect.add(DomainObject.SELECT_TYPE);
						slAMBESelect.add(DomainObject.SELECT_NAME);
						Map mAMBEInfo = (Map)doAMBE.getInfo(context,slAMBESelect);
						strObjType = (String)mAMBEInfo.get(DomainObject.SELECT_TYPE);
						strObjNumber = (String)mAMBEInfo.get(DomainObject.SELECT_NAME);
					}
				}
				
				if(UIUtil.isNotNullAndNotEmpty(strPersonId)){
					DomainObject doPerson = new DomainObject(strPersonId);
					StringList slPersonSelect = new StringList();
					slPersonSelect.add(DomainObject.SELECT_TYPE);
					slPersonSelect.add("attribute[Work Phone Number].value");
					Map mPersonInfo = (Map)doPerson.getInfo(context,slPersonSelect);
					
					String strType = (String)mPersonInfo.get(DomainObject.SELECT_TYPE);
					
					if(UIUtil.isNotNullAndNotEmpty(strType) && "Person".equals(strType)){
						String strPhoneNumber = (String)mPersonInfo.get("attribute[Work Phone Number].value");
						if(UIUtil.isNotNullAndNotEmpty(strPhoneNumber)){
							
							String username =  EnoviaResourceBundle.getProperty(context,"WMS.SMSService.UserName");
							String password =  EnoviaResourceBundle.getProperty(context,"WMS.SMSService.Password");
							String senderId =  EnoviaResourceBundle.getProperty(context,"WMS.SMSService.SendId");
							
							String strMesaage = DomainConstants.EMPTY_STRING;
							if(TYPE_ABSTRACT_MBE.equals(strObjType)){
								strMesaage = "A task to review/approve Bill no. "+strObjNumber+" has been assigned to you in EPMDS";
							}else if(TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strObjType)){
								strMesaage = "A task to review/approve Measurements no. "+strObjNumber+" has been assigned to you in EPMDS";
							}else{
								strMesaage = "A task to review/approve has been assigned to you in EPMDS";
							}
							
							String secureKey = "";
							sendSingleSMS(context,username,password,strMesaage,senderId,strPhoneNumber,secureKey);
						}					
					}
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	
 
	 public static void sendSingleSMS(Context context,String username, String password , String message , String senderId, String mobileNumber,String secureKey)throws Exception{
			String responseString = "";
			SSLSocketFactory sf=null;
			SSLContext sslcontext=null;
			String encryptedPassword;

			try {
				//context=SSLContext.getInstance("TLSv1.1"); // Use this line for Java version 6
				sslcontext=SSLContext.getInstance("TLSv1.2"); // Use this line for Java version 7 and above
				sslcontext.init(null, null, null);
				sf=new SSLSocketFactory(sslcontext, SSLSocketFactory.STRICT_HOSTNAME_VERIFIER);
				Scheme scheme=new Scheme("https",443,sf);
				HttpClient client=new DefaultHttpClient();
				encryptedPassword  = MD5(password);
				String genratedhashKey = hashGenerator(username, senderId, message, secureKey);
				client.getConnectionManager().getSchemeRegistry().register(scheme);
				String strURL =  EnoviaResourceBundle.getProperty(context,"WMS.SMSService.URL");
				HttpPost post=new HttpPost(strURL);
				
				List<NameValuePair> nameValuePairs=new ArrayList<NameValuePair>(1);
				nameValuePairs.add(new BasicNameValuePair("mobileno", mobileNumber));
				nameValuePairs.add(new BasicNameValuePair("senderid", senderId));
				nameValuePairs.add(new BasicNameValuePair("content", message));
				nameValuePairs.add(new BasicNameValuePair("smsservicetype", "singlemsg"));
				nameValuePairs.add(new BasicNameValuePair("username", username));
				nameValuePairs.add(new BasicNameValuePair("password", password));
				nameValuePairs.add(new BasicNameValuePair("key", secureKey));
				post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response=client.execute(post);
				BufferedReader bf=new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
				String line="";
				while((line=bf.readLine())!=null){
					responseString = responseString+line;
					
				}
				System.out.println(responseString);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	private static String MD5(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException  
	{ 
		MessageDigest md;
		md = MessageDigest.getInstance("SHA-1");
		byte[] md5 = new byte[64];
		md.update(text.getBytes("iso-8859-1"), 0, text.length());
		md5 = md.digest();
		return convertedToHex(md5);
	}

	private static String convertedToHex(byte[] data) 
	{ 
		StringBuffer buf = new StringBuffer();

		for (int i = 0; i < data.length; i++) 
		{ 
			int halfOfByte = (data[i] >>> 4) & 0x0F;
			int twoHalfBytes = 0;

			do 
			{ 
				if ((0 <= halfOfByte) && (halfOfByte <= 9)) 
				{
					buf.append( (char) ('0' + halfOfByte) );
				}

				else 
				{
					buf.append( (char) ('a' + (halfOfByte - 10)) );
				}

				halfOfByte = data[i] & 0x0F;

			} while(twoHalfBytes++ < 1);
		} 
		return buf.toString();
	}
	private static String hashGenerator(String userName, String senderId, String content, String secureKey) {
		// TODO Auto-generated method stub
		StringBuffer finalString=new StringBuffer();
		finalString.append(userName.trim()).append(senderId.trim()).append(content.trim()).append(secureKey.trim());
		//		logger.info("Parameters for SHA-512 : "+finalString);
		String hashGen=finalString.toString();
		StringBuffer sb = null;
		MessageDigest md;
		try {
			md = MessageDigest.getInstance("SHA-512");
			md.update(hashGen.getBytes());
			byte byteData[] = md.digest();
			//convert the byte to hex format method 1
			sb = new StringBuffer();
			for (int i = 0; i < byteData.length; i++) {
				sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
			}

		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sb.toString();
	}
 
 
	
}