/** Name of the JPO    : WMSUtil
 ** Developed by    :  
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to use utilities created for code.
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/

 
 
import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import java.util.ListIterator;
import java.io.BufferedInputStream;
import java.util.Properties;
import java.io.ByteArrayInputStream;
import java.text.DecimalFormat;
import java.math.RoundingMode;
import java.util.Locale;
import java.text.NumberFormat;
import java.text.Format;

import com.matrixone.apps.common.Person;
import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.framework.ui.UICache;
import com.matrixone.apps.common.MemberRelationship;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.mxAttr;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.CacheUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.SelectList;
import matrix.util.StringList;
import matrix.db.BusinessObject;
import matrix.util.MatrixException;
import matrix.db.RelationshipType;
//Added for eSign
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.security.DigestInputStream;
import java.security.MessageDigest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;


/**
 * The purpose of this JPO is to use utilities created
 * @author 
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSUtil_mxJPO extends WMSConstants_mxJPO 
{
	 


    /**
     * Constructor.
     * @param context the eMatrix Context object
     * @param strArguments holds the following input arguments[0]-id of the business object
     * @throws Exception if the operation fails    
     * @since 418
     */
    public WMSUtil_mxJPO (Context context, String[] args) throws Exception
    {
         super(context,args);
    }
    /**
     * Main entry point.
     *
     * @param context
     *            the eMatrix <code>Context</code> object
     * @param args
     *            holds no arguments
     * @return an integer status code (0 = success)
     * @throws Exception
     *             if the operation fails
     * @since 418
     */
    public int mxMain(Context context, String[] args) throws Exception {
        if (!context.isConnected())
            throw new Exception("Not supported on desktop client");
        return 0;
    }


    /**
     * Method to get Map  based on Key and Value
     * 
     * @param mapListObjects Maplist containing the Object data  
     * @param strKey String value containing the Key to identify the data
     * @param strValue String value to filter data
     * @return mapListSubSet MapList containing the Data based on Key and Value
     * @author WMS
     * @since R418 ///////////////USED
     */
    public static Map<String,String> getMap(MapList mapListObjects, String strKey,
            String strValue) {
        Iterator<Map<String,String>> iteratorMBEs = mapListObjects.iterator();
        Map<String,String> mapData;
        while(iteratorMBEs.hasNext())
        {
        	mapData = iteratorMBEs.next();
            String strKeyValue = mapData.get(strKey);
            if(strValue.equalsIgnoreCase(strKeyValue))
            {
            	return mapData;
            }
        }
        return new HashMap<String,String>();
    }

        /**
     * Method to get the context object OID from the args.
     *
     * @param args Packed program and request maps from the command or form or table
     * @return a string containing the object ID
     * @author WMS
     * @throws Exception if the operation fails 
     * @since 418
     */
    public static String getContextObjectOIDFromArgs(String[] args) throws Exception {
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String strObjectId = (String) programMap.get("objectId");
            if(UIUtil.isNullOrEmpty(strObjectId)) {
                strObjectId = (String) programMap.get("mbeOID");
            }
            return strObjectId;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

    /**
     * method get the basic bus info for the general class
     *
     * @return selListBusSelects SelectList containing the bus selects : type name revision policy vault
     * @author WMS
     * @since 418
     */
    public static SelectList getSubClassBusSelect() {
        SelectList selListBusSelects     = new SelectList(6);
        selListBusSelects.add(DomainConstants.SELECT_ID);
        selListBusSelects.add(DomainConstants.SELECT_POLICY);
        selListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
        selListBusSelects.add(DomainConstants.SELECT_VAULT);
        selListBusSelects.add(DomainConstants.SELECT_TYPE);
        selListBusSelects.add(DomainConstants.SELECT_NAME);
        return selListBusSelects;
    }

    /**
     * This method checks whether the given value is numeric or not
     *
     * @param String holds value to validate for numeric
     *
     * @return boolean holds true if value is numeric
     *                       false if value is not numeric
     * @throws Exception if the operation fails.
     */
    public static boolean isNumeric(String sValue)
    {
        try
        {
            Double.parseDouble(sValue);
        }
        catch(NumberFormatException nfe)
        {
            return false;
        }
        return true;
    }


/**
     * Access function for formType of Work Order to make it editable
     * @param context The Matrix Context object
     * @param args holds the arguments:     
     * @throws Exception if the operation fails
     */ 
    public boolean isCreateModeFormType(Context context, String[] args) throws Exception 
    {
        try
        {
            boolean bAccess	= false;
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strMode = (String) programMap.get("mode");
            if(UIUtil.isNotNullAndNotEmpty(strMode))
            {
                if("create".equals(strMode)){ 
                    bAccess= false;
                }
                else
                {
                    bAccess= true;
                }
            }
            return bAccess;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }


    public boolean isCreateModeHideField(Context context, String[] args) throws Exception 
    {
        try
        {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strMode = (String) programMap.get("mode");
            if(UIUtil.isNotNullAndNotEmpty(strMode))
            {
                if("create".equals(strMode)|| "edit".equals(strMode)){ 
                    return false;
                }
                else
                {
                    return true;
                }
                
            }
            return false;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

    /**
     * Access function for formType of Work Order to make it editable
     * @param context The Matrix Context object
     * @param args holds the arguments:     
     * @throws Exception if the operation fails
     */ 
    public boolean isCreateModeShowField(Context context, String[] args) throws Exception 
    {
        try
        {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strMode = (String) programMap.get("mode");
                       
            if(UIUtil.isNotNullAndNotEmpty(strMode))
            {
                if("create".equals(strMode)){ 
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

    /**
    * Access function for Project Description on Work Order Properties
    * @param context The Matrix Context object
    * @param args holds the arguments:     
    * @throws Exception if the operation fails
    */ 
   public boolean isCreateModeForProjectNameFields(Context context, String[] args) throws Exception 
   {
       try
       {
           HashMap programMap = (HashMap) JPO.unpackArgs(args);
           String strMode = (String) programMap.get("mode");
           if(UIUtil.isNotNullAndNotEmpty(strMode))
           {
               if("view".equals(strMode)){ 
                   return true;
               }
               else
               {
                   return false;
               }
               
           }
           return false;
       }
       catch(Exception exception)
       {
           exception.printStackTrace();
           throw exception;
       }
   }


    /**
     * Method will convert a string to Integer
     *
     * @param strValue String containing the real value
     * @return doubleValue double value of String
     * @author WMS
     * @since 418
     */
    public static int convertToInteger(String strValue) {
        int intValue = 0;
        try
        {

            if(UIUtil.isNullOrEmpty(strValue))
            {
                strValue = "-1";
            }
            intValue=  Integer.parseInt(strValue);
        }
        catch(Exception exception)
        {
            intValue = -1;
        }
        return intValue;
    }


    /**
     * Returns ematrix Date display format for Forms
     * @author WMS
     * @throws Exception 
     * @since 418
     **/
    public String getEmatrixDateFormat(Context context, String[] args) throws Exception
    {
        String strFormattedDate = "";
        try{                
                HashMap programMap          = (HashMap)JPO.unpackArgs(args);
                String strDateForFormat = (String)programMap.get("Date");
                
                Calendar calendarDate = Calendar.getInstance();
                long lDateForFormat=Long.parseLong(strDateForFormat);
                calendarDate.setTimeInMillis(lDateForFormat);
                SimpleDateFormat simpleDateFormatMatrix  = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(),context.getLocale());
                strFormattedDate = simpleDateFormatMatrix.format(calendarDate.getTime());
                
                Date dStartDate=simpleDateFormatMatrix.parse(strFormattedDate);				
                DateFormat dateFormat = DateFormat.getDateInstance(eMatrixDateFormat.getEMatrixDisplayDateFormat(),context.getLocale());
                strFormattedDate = dateFormat.format(dStartDate);
                
        }
        catch(Exception exception) 
        {
            exception.printStackTrace();
            throw exception;
        }
        return strFormattedDate;
    }

    public boolean isEditModeShowField(Context context, String[] args) throws Exception 
    {
        try
        {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strMode = (String) programMap.get("mode");
            if(UIUtil.isNotNullAndNotEmpty(strMode))
            {
                if("edit".equals(strMode)){ 
                    return true;
                }
                else
                {
                    return false;
                }
                
            }
            return false;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
    
    
    /**
     * Gets the Departments for the context user
     * @param context The Matrix Context.
     * @param args
     * @return maplist of Departments
     * @throws Exception If the operation fails.
     * @author WMS
     * @since 418
     */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public static MapList getContextUserDepartment (Context context) throws Exception
     {
    	 MapList mapListDepartment = new MapList();
    	 StringList strListBusSelects = new StringList(2);
    	 strListBusSelects.addElement(DomainConstants.SELECT_ID);
    	 strListBusSelects.addElement(DomainConstants.SELECT_NAME);
    	 StringList strListRelSelects = new StringList(1);
    	 strListRelSelects.addElement(DomainConstants.SELECT_RELATIONSHIP_ID);
    	 try 
    	 {
    		 String strPersonId = PersonUtil.getPersonObjectID(context);
    		 Person person =(Person)DomainObject.newInstance(context,DomainConstants.TYPE_PERSON);
    		 person.setId(strPersonId);
    		 mapListDepartment = person.getRelatedObjects(context, // matrix context
    				 DomainConstants.RELATIONSHIP_MEMBER, // relationship pattern
    				 DomainConstants.TYPE_DEPARTMENT, // type pattern
    				 strListBusSelects, // object selects
    				 strListRelSelects, // relationship selects
    				 true, // to direction
    				 false, // from direction
    				 (short) 1, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
    	 }
    	 catch (Exception exception) 
    	 {
    		 exception.printStackTrace();
    		 throw exception;
    	 }
    	 return mapListDepartment;
     }

     /**
     * Connects an object with many others using the given relationship type. 
     * 
     * @param context the eMatrix <code>Context</code> object 
     * @param givenObject the object to connect to the list passed in
     * @param relationshipType The relationship type used for the connection
     * @param isFrom this is a from connection of the given object (true) or to the given object (false)
     * @param arrayListClonedTCIds is array list containing the businessobject ids to connect to given object
     * @return a map of related ids as keys and connection ids as values
     * @throws FrameworkException - if the operation fails
     * @author WMS
     * @since R418
     */
     public static Map connect(Context context, DomainObject givenObject,
	     String relationshipType, boolean isFrom,
	     ArrayList<String> arrayListClonedTCIds) throws FrameworkException {
	     try
		     {
		     if(arrayListClonedTCIds.size()>0)
		     {
		     int intSize = arrayListClonedTCIds.size();
		     String [] strTCIds = arrayListClonedTCIds.toArray(new String[intSize]);
		     return DomainRelationship.connect(context, givenObject,relationshipType, isFrom, strTCIds);
		     }
		     }
		     catch(FrameworkException frameworkException)
		     {
		     frameworkException.printStackTrace();
		     throw frameworkException;
		     }
	     return new HashMap();
     }
    
     /** 
      * Method will generates a StringList of value for a particular key from each map of MapList 
      * @param mapListObject holds the MapList of Objects
      * @param strKey holds the Key value
      * @return strListValues list of value from MapList for the given Key 
      * @author WMS
      * @since 418
      */
     public static StringList convertToStringList(MapList mapListObject, String strKey) {
         StringList strListValues = new StringList(mapListObject.size());
         Iterator iterator = mapListObject.iterator();
         while(iterator.hasNext())
         {
             Map<String,String> mapObject = (Map<String,String>)iterator.next();
             strListValues.add(mapObject.get(strKey));
         }
         return strListValues;
     }
	/** 
     * Method to check the User Company
     * @
     * @author WMS
     * @since 418
     */
	public boolean isEmployee(Context context, String[] args)throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Boolean isSupplierRepresentative = context.isAssigned(DomainConstants.ROLE_SUPPLIER_REPRESENTATIVE );
		boolean bAccess = false;
		try
		{       
				if(isSupplierRepresentative){
					bAccess=false;
				}
				else
				{
					bAccess=true ;
				}
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return bAccess;
	}
	
	
	/** 
     * Method to check the if context user is supplier representative
     * @
     * @author WMS
     * @since 418
     */
	public boolean isSupplierRepresentative(Context context,String[] args) throws Exception{
		return !(isEmployee(context,args));
	
	}
	
	
	/**
	   * Display drop Icon.
	   * @param context - The eMatrix <code>Context</code> object.
	   * @param args - The args holds information about object.
	   * @return list of drop icon.
	   * @throws Exception if operation fails.
	   */
	  public StringList columnDropZone(Context context, String[] args) throws Exception 
	  {
	    StringList dropIconList = new StringList();
	    emxGenericColumns_mxJPO genericColumn = new emxGenericColumns_mxJPO(context,args);
	    Vector columnIconList = genericColumn.columnDropZone(context, args);
	    
	    Map programMap         = (HashMap) JPO.unpackArgs(args);
	    MapList objectList  = (MapList)programMap.get("objectList");
	    
	    if(objectList != null && objectList.size()>0){
	        
	    String[] objectIdArray = new String[objectList.size()];
	    for (int i=0; i<objectList.size(); i++) {
	            Map objectMap = (Map) objectList.get(i);
	            String objectId = (String)objectMap.get(DomainObject.SELECT_ID);
	            objectIdArray[i] = objectId;
	        }
	    
	        StringList dropAccesList = new StringList(3);
	        dropAccesList.addElement("modify");
	        dropAccesList.addElement("fromconnect");
	        dropAccesList.addElement("toconnect");
	        
	        StringList busSelect = new StringList(3);
	        busSelect.addElement("current.access");
	        busSelect.addElement(DomainObject.SELECT_TYPE);
	    
	    MapList objectInfoList = DomainObject.getInfo(context, objectIdArray, busSelect);
	    Iterator itrObj = objectInfoList.iterator();
	    Iterator itrIcon = columnIconList.iterator();
	    while(itrObj.hasNext()&&itrIcon.hasNext()){
	            Map objectMap = (Map)itrObj.next();
	            String dropIcon = (String)itrIcon.next();
	        
	            String access = (String)objectMap.get("current.access");
	            String strObjeType = (String)objectMap.get(DomainObject.SELECT_TYPE);
	            
	            boolean showDropIcon = false;
	            StringList currentAccessList = new StringList();
	            if(ProgramCentralUtil.isNotNullString(access)&& !access.equalsIgnoreCase("all") && TYPE_WMS_MEASUREMENTS.equals(strObjeType)){
	                currentAccessList = FrameworkUtil.split(access, ProgramCentralConstants.COMMA);
	                
	                if(currentAccessList.containsAll(dropAccesList)){
	                    showDropIcon = true;
	                }
	            }else if(access.equalsIgnoreCase("all") && TYPE_WMS_MEASUREMENTS.equals(strObjeType)){
	                showDropIcon = true;
	            }
	        
	            if(showDropIcon){
	                dropIconList.addElement(dropIcon);
	              }else{
	                  dropIconList.addElement(DomainObject.EMPTY_STRING);
	              }
	    }
	    }
	    return dropIconList;
	    
	  }
	 
	  /**
	     * disconnects an arraylist of relationship IDs
	     * 
	     * @param context the eMatrix <code>Context</code> object 
	     * @param arrayListClonedTCIds is array list containing Classified Item relationship IDs
	     * @throws FrameworkException - if the operation fails
	     * @author WMS
	     * @since R418
	     */
	    public static void disconnect(Context context,
	            ArrayList<String> arrayListRelationshipIDs)
	                    throws FrameworkException {
	        try
	        {
	            int intSize = arrayListRelationshipIDs.size();
	            if(intSize>0)
	            {
	                String [] strReqRelIds = arrayListRelationshipIDs.toArray(new String[intSize]);

	                DomainRelationship.disconnect(context,strReqRelIds);
	            }
	        }
	        catch(FrameworkException frameworkException)
	        {
	            frameworkException.printStackTrace();
	            throw frameworkException;
	        }
	    }
	    
	    
	    
	    /**
	     * Method will convert a string to double
	     *
	     * @param strValue String containing the real value
	     * @return doubleValue double value of String
	     * @author WMS
	     * @since 418
	     */
	    public static double convertToDouble(String strValue) {
	        double doubleValue = 0d;
	        try
	        {
	        	 if(UIUtil.isNullOrEmpty(strValue))
	             {
	                 strValue = "0.0";
	             }
	            
	             int iLangthAfterdecimal     =     0;
	             try
	             {
	                   iLangthAfterdecimal    =     strValue.substring(strValue.indexOf(".")+1, strValue.length()).length();
	             }
	             catch(Exception ex)
	             {
	                
	             }

	             doubleValue=  Double.parseDouble(strValue);
	             BigDecimal bigdecimal = new BigDecimal(doubleValue);
	             if(iLangthAfterdecimal == 2 || iLangthAfterdecimal == 3)
	             {
	                  bigdecimal = bigdecimal.setScale(iLangthAfterdecimal , BigDecimal.ROUND_HALF_EVEN);
	                  String strbigdecimal = bigdecimal.toPlainString();
	                  doubleValue=  Double.parseDouble(strbigdecimal);
	             }
	             else
	             {
	                 if(iLangthAfterdecimal > 3)
	                 {
	                     bigdecimal = bigdecimal.setScale(3 , BigDecimal.ROUND_HALF_EVEN);
	                     String strbigdecimal = bigdecimal.toPlainString();
	                     doubleValue=  Double.parseDouble(strbigdecimal);
	                 }                 
	             }            
	        	
	        }
	        catch(Exception exception)
	        {
	            doubleValue = 0d;
	        }
	        return doubleValue;
	    }
	    
	    
	    
	    /** 
	     * Method to check route exist on particular state
	     * @param context the eMatrix <code>Context</code> object
	     * @param domObj context object
	     * @param strRelWhere where condition to check on particular state
	     * @throws Exception if the operation fails
	     * @return MapList list of route objects exists
	     * @author WMS
	     * @since 418
	     */
	    public static MapList checkForExistingRouteObject(Context context,DomainObject domObj,
	            String strRelWhere) throws Exception {
	        MapList mlRoutes=new MapList();

	        try {
	            StringList busSelects = new StringList(4);
	            busSelects.add(DomainConstants.SELECT_ID);
	            busSelects.add(DomainConstants.SELECT_OWNER);
	            busSelects.add(DomainConstants.SELECT_CURRENT);
	            busSelects.add("attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]");
	            mlRoutes = domObj.getRelatedObjects(context,
	                    DomainConstants.RELATIONSHIP_OBJECT_ROUTE,
	                    DomainConstants.TYPE_ROUTE, busSelects, null, false, true,
	                    (short) 1,strRelWhere, DomainConstants.EMPTY_STRING, 0);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return mlRoutes;
	    }
	    
	    /** 
	     * Method to restart the existing route 
	     * @param context the eMatrix <code>Context</code> object
	     * @param routeMapList list of existing route objects
	     * @throws Exception if the operation fails
	     * @author WMS
	     * @since 418
	     */
	    public static void restartExistingRoute(Context context, MapList routeMapList) throws Exception {
	        try {
	            Iterator iterator = routeMapList.iterator();
	            Route objRoute = (Route) DomainObject.newInstance(context,
	                    Route.TYPE_ROUTE);
	            while (iterator.hasNext()) {

	                Map<String, String> mRoute = (Map<String, String>) iterator
	                        .next();
	                String sOIDRoute = (String) mRoute
	                        .get(DomainConstants.SELECT_ID);
	                objRoute.setId(sOIDRoute);
	                objRoute.resume(context);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	    
	    
	    /** 
	     * Method will generates a StringList from object 
	     * @param mapListObject holds the MapList of Objects
	     * @param strKey holds the Key value
	     * @return strListValues list of value from MapList for the given Key 
	     * @author WMS
	     * @since 418
	     */
	    public static StringList convertToStringList(Object obj) {
	        StringList strListValues = new StringList();
	        if(obj instanceof StringList)
	        {
	      	  strListValues = (StringList)obj;
	        }
	        else
	        {
	      	  if(UIUtil.isNotNullAndNotEmpty((String)obj))
	      	  {
	      		  strListValues.add((String)obj);
	      	  }
	        }
	        
	        return strListValues;
	    }
	    /**
	     * Method to get Map List based on Key and Value
	     * 
	     * @param mapListObjects Maplist containing the Object data  
	     * @param strKey String value containing the Key to identify the data
	     * @param strValue String value to filter data
	     * @return mapListSubSet MapList containing the Data based on Key and Value
	     * @author WMS
	     * @since R418
	     */
	    public static MapList getSubMapList(MapList mapListObjects, String strKey,
	            String strValue) {
	        MapList mapListSubSet = new MapList(mapListObjects.size());
	        Iterator<Map<String,String>> iteratorMBEs = mapListObjects.iterator();
	        Map<String,String> mapData;
	        while(iteratorMBEs.hasNext())
	        {
	        	mapData = iteratorMBEs.next();
	            String strKeyValue = mapData.get(strKey);
	            if(strValue.equalsIgnoreCase(strKeyValue))
	            {
	                mapListSubSet.add(mapData);
	            }
	        }
	        return mapListSubSet;
	    }
	    
	    /**
	     * Method will set rate value to two decimal points 
	     *
	     * @param strRelId String containing relationship id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     */
	    public static int convertToDoubleRateForRel(Context context ,  String [] args) {
	        double doubleValue = 0.00d;
	        try
	        {
	        	String strRelId 	 = args[0];
	        	String strAttributeNewVlaue = args[1];
	        	String strAttributeName  = args[2];
	        	if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	            {
	        		strAttributeNewVlaue = "0.00";
	            }
	        	int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	        	if(iLangthAfterdecimal > 2){ 
	            doubleValue=  Double.parseDouble(strAttributeNewVlaue);
	            BigDecimal bigdecimal = new BigDecimal(doubleValue);
	            bigdecimal = bigdecimal.setScale(2  , BigDecimal.ROUND_HALF_EVEN);
	            String strbigdecimal = bigdecimal.toPlainString();
	            doubleValue=  Double.parseDouble(strbigdecimal);
	            strAttributeNewVlaue = String.valueOf(doubleValue);
	        	}
	        	if(UIUtil.isNotNullAndNotEmpty(strRelId)){
	            DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	        	}
	        }
	        catch(Exception exception)
	        {
	            exception.printStackTrace();
	        }
	         return 0;
	    }
	    
	    
	    /**
	     * Method will set Quantity value to three decimal points 
	     *
	     * @param strObjId String containing object id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     */
	    public static int convertToDoubleQuantity(Context context ,  String [] args) {
	        double doubleValue = 0.000d;
	        try
	        {
	        	String strObjectIds 	 = args[0];
	        	String strAttributeNewVlaue = args[1];
	        	String strAttributeName  = args[2];
	        	if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	            {
	        		strAttributeNewVlaue = "0.000";
	            }
	        	int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	        	if(iLangthAfterdecimal > 3){
	            doubleValue=  Double.parseDouble(strAttributeNewVlaue);
	            BigDecimal bigdecimal = new BigDecimal(doubleValue);
	            bigdecimal = bigdecimal.setScale(3  , BigDecimal.ROUND_HALF_EVEN);
	            String strbigdecimal = bigdecimal.toPlainString();
	            doubleValue=  Double.parseDouble(strbigdecimal);
	            strAttributeNewVlaue = String.valueOf(doubleValue);
	        	}
	        	if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	        		DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	        		domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	        	}
	        }
	        catch(Exception exception)
	        {
	        	exception.printStackTrace();
	        }
	         return 0;
	    }
	    
	    /**
	     * Method will set Rate value to two decimal points 
	     *
	     * @param strObjId String containing object id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     */
	    public static int convertToDoubleRate(Context context ,  String [] args) {
	        double doubleValue = 0.00d;
	        try
	        {
	        	String strObjectIds 	 	= args[0];
	        	String strAttributeNewVlaue = args[1];
	        	String strAttributeName  	= args[2];
	        	if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	            {
	        		strAttributeNewVlaue = "0.00";
	            }
	        	int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	        	if(iLangthAfterdecimal > 2){            
	            doubleValue			  = Double.parseDouble(strAttributeNewVlaue);
	            BigDecimal bigdecimal = new BigDecimal(doubleValue);
	            bigdecimal 			  = bigdecimal.setScale(2,BigDecimal.ROUND_HALF_EVEN);
	            String strbigdecimal  = bigdecimal.toPlainString();
	            doubleValue			  = Double.parseDouble(strbigdecimal);
	            strAttributeNewVlaue = String.valueOf(doubleValue);
	        	}
	        	if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	        		DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	        		domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	        	}
	        }
	        catch(Exception exception)
	        {
	            doubleValue = 0d;
	        }
	         return 0;
	    }
	    
	    
	    /**
	     * Method will set Quantity value to three decimal points 
	     *
	     * @param strObjId String containing object id/Rel id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     * */
	    public static int convertToDoubleObjRelQty(Context context ,  String [] args) {
	    	double doubleValue = 0.000d;
	    	try
	    	{/*
	    		String strObjectIds 	 = args[0];
	    		String strAttributeNewVlaue = args[1];
	    		String strAttributeName  = args[2];
	    		String strRelId  = args[3];
	    		if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	    		{
	    			strAttributeNewVlaue = "0.000";
	    		}
	    		int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	    		if(iLangthAfterdecimal > 3){
	    			doubleValue=  Double.parseDouble(strAttributeNewVlaue);
	    			BigDecimal bigdecimal = new BigDecimal(doubleValue);
	    			bigdecimal = bigdecimal.setScale(3  , BigDecimal.ROUND_HALF_EVEN);
	    			String strbigdecimal = bigdecimal.toPlainString();
	    			doubleValue=  Double.parseDouble(strbigdecimal);
	    			strAttributeNewVlaue = String.valueOf(doubleValue);
	    			if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	    				DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	    				//domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	    			}
	    			else
	    			{
	    				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
	    					DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	    				}

	    			}
	    		}
	    		else{
	    			if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	    				DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	    				domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	    			}
	    			else
	    			{
	    				if(UIUtil.isNotNullAndNotEmpty(args[3])){
	    					DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	    				}

	    			}
	    		}

	    	*/}
	    	catch(Exception exception)
	    	{
	    		exception.printStackTrace();
	    	}
	    	return 0;
	    }
	  
	    
	    /**
	     * Method will set Rate value to two decimal points 
	     *
	     * @param strObjId String containing object id/Rel id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     */
	    public static int convertToDoubleObjRelRate(Context context ,  String [] args) {
	        
	        double doubleValue = 0.00d;
	    	try
	    	{
	    		String strObjectIds 	 	= args[0];
	    		String strAttributeNewVlaue = args[1];
	    		String strAttributeName  	= args[2];
	    		String strRelId = args[3];
	    		if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	    		{
	    			strAttributeNewVlaue = "0.00";
	    		}
	    		int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	    		if(iLangthAfterdecimal > 2){

	    			doubleValue			  = Double.parseDouble(strAttributeNewVlaue);
	    			BigDecimal bigdecimal = new BigDecimal(doubleValue);
	    			bigdecimal 			  = bigdecimal.setScale(2  , BigDecimal.ROUND_HALF_EVEN);
	    			String strbigdecimal  = bigdecimal.toPlainString();
	    			doubleValue			  = Double.parseDouble(strbigdecimal);
	    			strAttributeNewVlaue = String.valueOf(doubleValue);
	    			if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	    				DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	    				domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	    			}
	    			else
	    			{
	    				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
	    					DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	    				}

	    			}
	    		}
	    		else
	    		{
	    			if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	    				DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	    				domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	    			}
	    			else
	    			{
	    				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
	    					DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	    				}

	    			}
	    		}
	    	}
	    	catch(Exception exception)
	    	{
	    		exception.printStackTrace();
	    	}
	    	return 0;
	    }
	    
/**

      * Gets the Departments for the context user
      * @param context The Matrix Context.
      * @param args
      * @return maplist of Departments
      * @throws Exception If the operation fails.
      * @author WMS
      * @since 418
      */
      @com.matrixone.apps.framework.ui.ProgramCallable
      public static MapList getContextUserDepartmentCGRDC (Context context, String[] args) throws Exception
      {
     	 MapList mapListDepartment = new MapList();
     	 StringList strListBusSelects = new StringList(2);
     	 strListBusSelects.addElement(DomainConstants.SELECT_ID);
     	 strListBusSelects.addElement(DomainConstants.SELECT_NAME);
     	 StringList strListRelSelects = new StringList(1);
     	 strListRelSelects.addElement(DomainConstants.SELECT_RELATIONSHIP_ID);
     	 try 
     	 {
     		 String strPersonId = PersonUtil.getPersonObjectID(context);
     		 Person person =(Person)DomainObject.newInstance(context,DomainConstants.TYPE_PERSON);
     		 person.setId(strPersonId);
     		 mapListDepartment = person.getRelatedObjects(context, // matrix context
     				 DomainConstants.RELATIONSHIP_MEMBER, // relationship pattern
     				 DomainConstants.TYPE_COMPANY, // type pattern
     				 strListBusSelects, // object selects
     				 strListRelSelects, // relationship selects
     				 true, // to direction
     				 false, // from direction
     				 (short) 1, // recursion level
     				 DomainConstants.EMPTY_STRING, // object where clause
     				 DomainConstants.EMPTY_STRING, // relationship where clause
     				 0);
     	 }
     	 catch (Exception exception) 
     	 {
     		 exception.printStackTrace();
     		 throw exception;
     	 }
     	 return mapListDepartment;
      }


/** 
     * Method will create new route object and connect route Object to User
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @throws FrameworkException if the operation fails
     * @return objRoute route object
     * @author WMS 
     * @since 418
     */

    public static Route createAndConnectRoute(Context context, String[] args, String strRouteBasePurpose)
            throws FrameworkException {
        try
        {
            Route objRoute = (Route) DomainObject.newInstance(context,
                    Route.TYPE_ROUTE);
            String strRouteId = createRoute(context);
            objRoute.setId(strRouteId);
            connectRouteToContextObject(context, args, objRoute, strRouteBasePurpose);
            setRouteAttributes(context, objRoute, strRouteBasePurpose);
            return objRoute;
        }
        catch(FrameworkException exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }	 

	
	 public static String createRoute(Context context) throws FrameworkException {
        String strRouteId = FrameworkUtil.autoName(context,
                "type_Route",
                "policy_Route");
        return strRouteId;
    }
 /** 
     * Method to connect route object to Context object
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @param strRouteBasePurpose route object purpose
     * @throws FrameworkException if the operation fails
     * @author WMS 
     * @since 418
     */
    public static void connectRouteToContextObject(Context context, String[] args,
            Route objRoute, String strRouteBasePurpose) throws FrameworkException {
        String strGenralCalssID = args[0];

        String strSymbolicPolicyName = UICache.getSymbolicName(context, args[1], "policy");
        String strSymbolicStateName = args[2];
        HashMap<String, String> attrMap = new HashMap<String, String>();
        attrMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,
                strSymbolicStateName);
        attrMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,
                strSymbolicPolicyName);
        attrMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE, strRouteBasePurpose);
        RelationshipType relationshipType = new RelationshipType(
                DomainConstants.RELATIONSHIP_OBJECT_ROUTE);
        DomainRelationship domainRelationship = objRoute.addFromObject(context,
                relationshipType, strGenralCalssID);

        domainRelationship.setAttributeValues(context, attrMap);
    }	
	
	 public static void setRouteAttributes(Context context, Route objRoute, String strRouteBasePurpose)
            throws FrameworkException {
        try {
            Map<String, String> mpRouteAttributeMap = new HashMap<String, String>();
            mpRouteAttributeMap.put(
                    DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,
                    strRouteBasePurpose);
            mpRouteAttributeMap.put(
                    ATTRIBUTE_ROUTE_COMPLETION_ACTION, "Promote Connected Object");
            objRoute.setAttributeValues(
                    context, mpRouteAttributeMap);

        } catch (FrameworkException e) {
            e.printStackTrace();
        }
    }

	 public static void connectProjectRoute(Context context, Route objRoute,BusinessObject personObject)
            throws FrameworkException, MatrixException {
        try{
            objRoute.connect(context,new RelationshipType(DomainObject.RELATIONSHIP_PROJECT_ROUTE),true, personObject);
        }catch(FrameworkException e){
            e.printStackTrace();
        }
        catch(MatrixException e){
            e.printStackTrace();
        }
    }
	
	
	 /** 
     * Method to restart the existing route 
     * @param context the eMatrix <code>Context</code> object
     * @param domObjTestExecution context domain object
     * @param strPersonName person name to crate route and assign task
     * @param strRouteBasePurpose Route base purpose
     * @param strRouteAction defining route action to the person
     * @throws FrameworkException if the operation fails
     * @return taskMapList list of tasks assigned to the particular person
     * @author WMS
     * @since 418
     */
    public static MapList getRouteTaskMapListForObject(Context context, DomainObject domObjTestExecution, String strPersonName, String strRouteBasePurpose, String strRouteAction)
            throws FrameworkException {
        MapList taskMapList= new MapList();
        try{
            String strPersonId = PersonUtil.getPersonObjectID(context,strPersonName);

            String strTitle = domObjTestExecution.getInfo(context,"attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
            HashMap<String, String> taskMap=new HashMap<String, String>();
            taskMap.put("PersonId", strPersonId);
            taskMap.put("PersonName", strPersonName);
            taskMap.put(Route.ATTRIBUTE_TITLE, strTitle);
            taskMap.put(Route.ATTRIBUTE_ROUTE_ACTION, strRouteAction);
            taskMap.put(Route.ATTRIBUTE_ROUTE_INSTRUCTIONS, "Please Review and Approve");
            taskMap.put(Route.ATTRIBUTE_ROUTE_SEQUENCE, "1");
            taskMap.put(Route.ATTRIBUTE_ROUTE_BASE_PURPOSE, strRouteBasePurpose);
            if(strRouteBasePurpose.equals("Standard")){
                taskMap.put(Route.ATTRIBUTE_ALLOW_DELEGATION, "True");
            }else{
            taskMap.put(Route.ATTRIBUTE_ALLOW_DELEGATION, "false");
            }
            taskMap.put(Route.SELECT_NAME, strPersonName);

            taskMap.put(DomainObject.ATTRIBUTE_REVIEW_TASK, "No");
            taskMap.put(DomainObject.ATTRIBUTE_DUEDATE_OFFSET, "3");
            taskMap.put(DomainObject.ATTRIBUTE_DATE_OFFSET_FROM, "Task Create Date");
            taskMap.put(DomainObject.RELATIONSHIP_ROUTE_NODE, strPersonId);
            taskMap.put("access", "Add Remove");
            taskMap.put(DomainConstants.SELECT_ID, strPersonId);
            taskMapList.add(taskMap);
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return taskMapList;
    }

	 /**
     * Returns a filter Project Members list By the role mentioned in the argument
     * @param strRoleName StringList containing value roles (Schema Name)
     * @param membersList MapList containing list of Project Member
     * @return strListMembers String containing filter Project Members names assigned with the role
     * @author WMS
     * @since 418
     **/
    public static StringList filterMembersByRoles(StringList slRoleName,MapList membersList) {
        StringList strListMembers = new StringList();
        ListIterator<String> listIteratorRoles = slRoleName.listIterator();
        while(listIteratorRoles.hasNext())
        {
        	String strRole = listIteratorRoles.next();
        if(membersList!=null && membersList.size()>0)
        {
            ListIterator<Map<String,String>> membersItr = membersList.listIterator();
            Map<String,String> memberMap;
            while(membersItr.hasNext())
            {
            	memberMap = membersItr.next();
        			String strProjectRole = (String)memberMap.get(MemberRelationship.SELECT_PROJECT_ROLE);
                String strRoleUser = (String)memberMap.get(Person.SELECT_NAME);

        			if (strRole.equalsIgnoreCase(strProjectRole))
                {
                    strListMembers.add(strRoleUser);
        				break;
        			}
                }
            }
        }
        return strListMembers;
    }
	
	
	public static void createRouteFromTemplate(Context context, String strObjectId, String strTemplateId, String strPolicy, String strTargetStateName, String strSourceState)throws Exception{
		try {
		
			
			Route newRouteObj = null;
			String strMessage =  DomainObject.EMPTY_STRING;
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)) {
				DomainObject doObject = new DomainObject(strObjectId);
				StringList slObjectSelect = new StringList(DomainObject.SELECT_ID);
				slObjectSelect.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelect.add(DomainObject.SELECT_CURRENT);
				slObjectSelect.add(DomainObject.SELECT_POLICY);

				Map mObjInfo = doObject.getInfo(context,slObjectSelect);

				if(UIUtil.isNotNullAndNotEmpty(strTemplateId)){
					DomainObject doRouteTemplate = new DomainObject(strTemplateId);

					String strAttributeRouteCompletionAction = PropertyUtil.getSchemaProperty(context, "attribute_RouteCompletionAction");

					String strAttributeRouteBasePurpose = PropertyUtil.getSchemaProperty(context, "attribute_RouteBasePurpose");
					String SELECT_ATTR_ROUTE_BASE_PURPOSE = "attribute[" +  PropertyUtil.getSchemaProperty(context, "attribute_RouteBasePurpose")  + "]";

					String strAttributeRouteBasePolicy = PropertyUtil.getSchemaProperty(context, "attribute_RouteBasePolicy");
					String strAttributeRouteBaseState = PropertyUtil.getSchemaProperty(context, "attribute_RouteBaseState");
					String strAttributeAutoStopRejection = PropertyUtil.getSchemaProperty(context, "attribute_AutoStopOnRejection" );
					String SELECT_ATTR_AUTO_STOP_REJECTION = "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_AutoStopOnRejection" ) + "]";

					Map routeAttributeMap = new HashMap();		

					Map objectRouteAttributeMap = new HashMap();	

					slObjectSelect.add(SELECT_ATTR_AUTO_STOP_REJECTION);
					slObjectSelect.add(SELECT_ATTR_ROUTE_BASE_PURPOSE);
					Map mRouteTemplateInfo = doRouteTemplate.getInfo(context, slObjectSelect);


					routeAttributeMap.put(strAttributeRouteCompletionAction, "Promote Connected Object");
					routeAttributeMap.put(strAttributeAutoStopRejection, mRouteTemplateInfo.get(SELECT_ATTR_AUTO_STOP_REJECTION));
					routeAttributeMap.put(strAttributeRouteBasePurpose,mRouteTemplateInfo.get(SELECT_ATTR_ROUTE_BASE_PURPOSE));

					// attributes to be set on relationship Object Route
					objectRouteAttributeMap.put(strAttributeRouteBasePolicy,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy, false));
					objectRouteAttributeMap.put(strAttributeRouteBaseState, strSourceState);
					objectRouteAttributeMap.put(strAttributeRouteBasePurpose, "Review");
					String strRouteTemplateDescription = (String)mRouteTemplateInfo.get(DomainObject.SELECT_DESCRIPTION);
					String strStateName = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);

					newRouteObj = Route.createAndStartRouteFromTemplateAndReviewers(context, 
							strTemplateId, 
							strRouteTemplateDescription, 
							DomainConstants.EMPTY_STRING, 
							strObjectId,
							strPolicy, 
							strTargetStateName,
							routeAttributeMap, 
							objectRouteAttributeMap, 
							new HashMap(),
							true);
					newRouteObj.promote(context);
				}
			}

		}catch(Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}


		public void createRoute(Context context, String[] args) throws Exception
		{
			try {
				String sObjectId = args[0];
				DomainObject doObj = null;
				if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
					
					doObj = new DomainObject(sObjectId);
					String strPolicy = (String)doObj.getInfo(context,DomainConstants.SELECT_POLICY);
					String strProjectId = getProjectIDFromFolder(context,sObjectId);
					
					if(UIUtil.isNotNullAndNotEmpty(strProjectId)){
						doObj = new DomainObject(strProjectId);
						String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == Documents";
						MapList routeMapList= doObj.getRelatedObjects(context, RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
						if(routeMapList != null && routeMapList.isEmpty() == false){
							Map mRouteTemplateMap = (Map)routeMapList.get(0);
							String strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
							createRouteFromTemplate(context, sObjectId, strTemplateId, strPolicy, "RELEASED", "state_FROZEN");

						}
					}				
				}			
			}
			catch (Exception e) {
				throw e;
			}
		}
	
	
	private String getProjectIDFromFolder(Context context,String sObjectId)throws Exception{
		String strReturn = DomainConstants.EMPTY_STRING;
		try{	
			DomainObject doObj = new DomainObject(sObjectId); 
			
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainObject.SELECT_ID);
			slObjSelect.add(DomainObject.SELECT_TYPE);
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			
			String strRelPattern = "Vaulted Documents Rev2,Sub Vaults,Data Vaults";
			String strTypePattern = "Workspace Vault,Project Space";
			
			MapList mlFolderList = doObj.getRelatedObjects(context, // matrix context
    				 strRelPattern, // relationship pattern
    				 strTypePattern, // type pattern
    				 slObjSelect, // object selects
    				 slRelSelect, // relationship selects
    				 true, // to direction
    				 false, // from direction
    				 (short) 0, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
			Map mTemp = null;
			String strType = DomainConstants.EMPTY_STRING;
			for(int i=0;i<mlFolderList.size();i++){
				mTemp = (Map)mlFolderList.get(i);
				strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
				if("Project Space".equals(strType)){
					strReturn = (String)mTemp.get(DomainObject.SELECT_ID);
					break;
				}				
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return strReturn;
	}

		public String getParentForDocument(Context context,String[] args)throws Exception{
		String strReturn = DomainConstants.EMPTY_STRING;
		try{	
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId); 
			
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainObject.SELECT_ID);
			slObjSelect.add(DomainObject.SELECT_TYPE);
			slObjSelect.add(DomainObject.SELECT_NAME);
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			
			String strRelPattern = "Vaulted Documents Rev2,Sub Vaults,Data Vaults";
			String strTypePattern = "Workspace Vault,Project Space";
			
			MapList mlFolderList = doObj.getRelatedObjects(context, // matrix context
    				 strRelPattern, // relationship pattern
    				 strTypePattern, // type pattern
    				 slObjSelect, // object selects
    				 slRelSelect, // relationship selects
    				 true, // to direction
    				 false, // from direction
    				 (short) 0, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
			Map mTemp = null;
			String strType = DomainConstants.EMPTY_STRING;
			for(int i=0;i<mlFolderList.size();i++){
				mTemp = (Map)mlFolderList.get(i);
				strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
				if("Project Space".equals(strType)){
					strReturn = (String)mTemp.get(DomainObject.SELECT_NAME);
					break;
				}				
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return strReturn;
	}

	public Map getRangeForWorkOrderRole(Context context, String[] args) throws Exception{
		Map mRange = new HashMap();
		StringList slRange = new StringList();
		slRange.add(DomainConstants.EMPTY_STRING);
		try{
			//StringList slRange = mxAttr.getChoices( context,ATTRIBUTE_WMS_WORK_ORDER_ROLE);	
			String strPMCRoles = EnoviaResourceBundle.getProperty(context, "WMS.Roles.PMC");
			StringList slPMCRoles = FrameworkUtil.split(strPMCRoles,",");
			
			String strContractorRoles = EnoviaResourceBundle.getProperty(context, "WMS.Roles.Contractor");
			StringList slContractorRoles = FrameworkUtil.split(strPMCRoles,",");
			
			String strRoleName = DomainConstants.EMPTY_STRING;
			for(int i=0;i<slPMCRoles.size();i++){
				strRoleName = (String)slPMCRoles.get(i);
				if(slRange.contains(strRoleName) == false){
					slRange.add(strRoleName);
				}
			}
			
			strRoleName = DomainConstants.EMPTY_STRING;
			for(int i=0;i<slContractorRoles.size();i++){
				strRoleName = (String)slContractorRoles.get(i);
				if(slRange.contains(strRoleName) == false){
					slRange.add(strRoleName);
				}
			}
			
            mRange.put("field_choices", slRange);
			mRange.put("field_display_choices", slRange);
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
		return mRange;

	}


	public boolean isSupplier(Context context, String[] args)throws Exception{
		boolean isSupplier = false;
		try{
			Map programMap         = (HashMap) JPO.unpackArgs(args);
			String strCompanyId = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strCompanyId)){
				String mqlQuery = "print bus "+strCompanyId+" select to["+DomainRelationship.RELATIONSHIP_SUPPLIER+"].id dump";
				String strResult = MqlUtil.mqlCommand(context,mqlQuery);
				if(UIUtil.isNotNullAndNotEmpty(strResult)){
					isSupplier = true;
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return isSupplier;
}
		
	
		/**
	 * Method generates hash value of file content and stores on IT attribute
	 * 
	 * @param context
	 * @param strFileName
	 * @return
	 */

	
	/*public void setSHA256HashOfFileContent(Context context,String  strFileName,DomainObject domInboTask) throws Exception{
		
			StringList slSelect=new StringList();
			slSelect.add(DomainConstants.SELECT_ID);
			slSelect.add("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
			slSelect.add(DomainConstants.SELECT_OWNER);
		    Map mTaskInfo = domInboTask.getInfo(context,slSelect);
		    
			
			String strEdongal = EnoviaResourceBundle.getProperty(context,"WMS.Edongal.Enable");
			if(UIUtil.isNotNullAndNotEmpty(strEdongal) && "true".equals(strEdongal)){
				String strTokenInputHash = generatePDFStamplerEDongle(context,strFileName,mTaskInfo);
				domInboTask.setAttributeValue(context, ATTRIBUTE_WMS_TOKEN_FILE_HASH, strTokenInputHash);
				String strInputHash = generatePDFStampler(context,strFileName,mTaskInfo);
				domInboTask.setAttributeValue(context, ATTRIBUTE_WMS_FILE_HASH_CODE, strInputHash);
			}else{
				String strInputHash = generatePDFStampler(context,strFileName,mTaskInfo);
				domInboTask.setAttributeValue(context, ATTRIBUTE_WMS_FILE_HASH_CODE, strInputHash);
			}
         
 	    
 	    
 	}*/
	
	
//	public String generatePDFStampler(Context context, String strFileName, Map mTaskInfo) {
//		String strDocHashCode = null;
//		try {
//			String strId = (String) mTaskInfo.get(DomainConstants.SELECT_ID);
//			String userName = (String) mTaskInfo.get(DomainConstants.SELECT_OWNER);
//			String userComments = (String) mTaskInfo.get("attribute[" + DomainConstants.ATTRIBUTE_COMMENTS + "]");
//			String destinationfile = null;
//			FileOutputStream fout;
//			PdfSignatureAppearance appearance;
//			PdfReader reader;
//			File file = new File(strFileName);
//			String sourcefile = file.getAbsolutePath();
//			destinationfile = sourcefile.replace(file.getName(), "/Signed_" + file.getName());
//			reader = new PdfReader(sourcefile, null, true);
//		  	Rectangle cropBox = reader.getCropBox(1);
//			Rectangle rectangle = null;
// 		    rectangle = new Rectangle(cropBox.getLeft(20), cropBox.getBottom(20), cropBox.getLeft(200),
//					cropBox.getBottom(180));
//			fout = new FileOutputStream(destinationfile);
//			PdfStamper stamper = PdfStamper.createSignature(reader, fout, '\0', null, true);
//
//			appearance = stamper.getSignatureAppearance();
//			appearance.setRenderingMode(RenderingMode.DESCRIPTION);
//			appearance.setAcro6Layers(false);
//			Font font = new Font();
//			font.setSize(6);
//			font.setFamily("Helvetica");
//			font.setStyle("italic");
//			appearance.setLayer2Font(font);
//			Calendar currentDat = Calendar.getInstance();
//			currentDat.add(currentDat.MINUTE, 5);
//			// currentDat.setTimeInMillis(ASPGUI.deltaTime + currentDat.getTimeInMillis());
//			appearance.setSignDate(currentDat);
//			//appearance.setLayer2Text("Document Signed by " + userName + "  " + "\n" + " Location : India");
// 	        //appearance.setCertificationLevel(PdfSignatureAppearance.NOT_CERTIFIED);
// 	        appearance.setCertificationLevel(PdfSignatureAppearance.CERTIFIED_NO_CHANGES_ALLOWED);
//			appearance.setImage(null);
//			appearance.setVisibleSignature(rectangle, reader.getNumberOfPages(), null);
//			int contentEstimated = 10000;
//			HashMap<PdfName, Integer> exc = new HashMap();
//			exc.put(PdfName.CONTENTS, contentEstimated * 2 + 2);
//			PdfSignature dic = new PdfSignature(PdfName.ADOBE_PPKLITE, PdfName.ADBE_PKCS7_DETACHED);
//			dic.setReason(appearance.getReason());
//			dic.setLocation(appearance.getLocation());
//			dic.setDate(new PdfDate(appearance.getSignDate()));
//			appearance.setCryptoDictionary(dic);
//			appearance.preClose(exc);
//		 	System.gc();
//			// getting bytes of file
//			InputStream is = appearance.getRangeStream();
//			strDocHashCode = DigestUtils.sha256Hex(is);
//
//			CacheUtil.setCacheObject(context, "appearance" + strId, appearance);
//			CacheUtil.setCacheObject(context, "filepath" + strId, strFileName); // store the file path as this file
//																				// needs to check in
//		} catch (IOException e) {
//			e.printStackTrace();
//		} catch (DocumentException e) {
//			e.printStackTrace();
//		} catch (FrameworkException e) {
//			e.printStackTrace();
//		}
//
//		return strDocHashCode;
//	}
	
//	public String generatePDFStamplerEDongle(Context context, String strFileName, Map mTaskInfo) {
//		String strDocHashCode = null;
//		try {
//			
//			String strPersonId = PersonUtil.getPersonObjectID(context);
//			StringList slPersonSelect = new StringList();
//			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
//			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
//			
//			DomainObject doPerson = new DomainObject(strPersonId);
//			Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
//			String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
//			String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
//			
//			if(UIUtil.isNullOrEmpty(strFirstName)){
//				strFirstName = DomainConstants.EMPTY_STRING;
//			}
//			if(UIUtil.isNullOrEmpty(strLastName)){
//				strLastName = DomainConstants.EMPTY_STRING;
//			}
//			
//			String strUser = strFirstName + " " +strLastName;
//			
//			String strId = (String) mTaskInfo.get(DomainConstants.SELECT_ID);
//			String userName = (String) mTaskInfo.get(DomainConstants.SELECT_OWNER);
//			String userComments = (String) mTaskInfo.get("attribute[" + DomainConstants.ATTRIBUTE_COMMENTS + "]");
//			String destinationfile = null;
//			FileOutputStream fout;
//			//PdfSignatureAppearance appearance;
//			//PdfReader reader;
//			File file = new File(strFileName);
//			String sourcefile = file.getAbsolutePath();
//			String filePath = sourcefile.substring(0, sourcefile.lastIndexOf(File.separator));
//			//destinationfile = sourcefile.replace(file.getName(), "TokenSinged_" + file.getName());
//			//reader = new PdfReader(sourcefile, null, true);
//		  	//Rectangle cropBox = reader.getCropBox(1);
//			//Rectangle rectangle = null;
// 		    //rectangle = new Rectangle(cropBox.getLeft(), cropBox.getBottom(), cropBox.getLeft(100),
//			//		cropBox.getBottom(90));
//			//fout = new FileOutputStream(destinationfile);
//			
//			String strEnvironmentURL = EnoviaResourceBundle.getProperty(context,"WMS.Environment.URL");
//			PdfReader reader = new PdfReader(strFileName);
//			int iPageNumbers = reader.getNumberOfPages();
//			Rectangle cropBox = reader.getCropBox(1);
//			
//			String strpath = System.getProperty("user.dir");
//			File newFile = new File(strpath+"/..");
//		
//			String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
//			SimpleDateFormat dt = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
//			Date date  = new Date();
//			
//			String strDate = dt.format(date);
//			Image qrImg = Image.getInstance(newFile.getCanonicalPath()+strImageFolder+"TickMark.png");
//			qrImg.setAbsolutePosition(0,0);
//			PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(filePath+File.separator+"TokenSinged_"+file.getName()));
//			Font fontSize = new Font(FontFamily.HELVETICA, 13);
//			for(int i=0;i<iPageNumbers;i++){
//				PdfContentByte canvas = stamper.getOverContent(i+1);
//				canvas.addImage(qrImg);
//				Font bold = new Font(FontFamily.HELVETICA, 13, Font.BOLD);
//				Chunk chunk = new Chunk("here", bold);
//				chunk.setAnchor(strEnvironmentURL+"/common/emxForm.jsp?form=type_InboxTask&objectId="+strId+"&toolbar=WMSeSignVerification");
//				Phrase p = new Phrase("This document is generated by "+strUser+" and is digitally signed on "+strDate+". For verification please click ",fontSize);
//				p.add(chunk);
//				ColumnText ct = new ColumnText(canvas);
//				ct.setSimpleColumn(cropBox.getLeft(80), cropBox.getBottom(30), cropBox.getLeft(1000), cropBox.getBottom(10));
//				ct.addText(p);
//				ct.go();
//			}
//			stamper.close();
//			reader.close();
//			System.gc();
//			InputStream is = new FileInputStream(filePath+File.separator+"TokenSinged_"+file.getName());
//			strDocHashCode = DigestUtils.sha256Hex(is);
//			
//			//PdfStamper stamper = PdfStamper.createSignature(reader, fout, '\0', null, true);
//
//			//appearance = stamper.getSignatureAppearance();
//			//appearance.setRenderingMode(RenderingMode.DESCRIPTION);
//			//appearance.setAcro6Layers(false);
//			//Font font = new Font();
//			//font.setSize(6);
//			//font.setFamily("Helvetica");
//			//font.setStyle("italic");
//			//appearance.setLayer2Font(font);
//			//Calendar currentDat = Calendar.getInstance();
//			//currentDat.add(currentDat.MINUTE, 5);
//			// currentDat.setTimeInMillis(ASPGUI.deltaTime + currentDat.getTimeInMillis());
//			//appearance.setSignDate(currentDat);
//			//appearance.setLayer2Text("Document Signed by " + userName + "  " + "\n" + " Location : India");
// 	        //appearance.setCertificationLevel(PdfSignatureAppearance.NOT_CERTIFIED);
// 	       // appearance.setCertificationLevel(PdfSignatureAppearance.CERTIFIED_NO_CHANGES_ALLOWED);
//			//appearance.setImage(null);
//			//appearance.setVisibleSignature(rectangle, reader.getNumberOfPages(), null);
//			//int contentEstimated = 10000;
//			//HashMap<PdfName, Integer> exc = new HashMap();
//			//exc.put(PdfName.CONTENTS, contentEstimated * 2 + 2);
//			//PdfSignature dic = new PdfSignature(PdfName.ADOBE_PPKLITE, PdfName.ADBE_PKCS7_DETACHED);
//			//dic.setReason(appearance.getReason());
//			//dic.setLocation(appearance.getLocation());
//			//dic.setDate(new PdfDate(appearance.getSignDate()));
//			//appearance.setCryptoDictionary(dic);
//			//appearance.preClose(exc);
//		 	
//			// getting bytes of file
//			//InputStream is = appearance.getRangeStream();
//			
//			
//			/*MessageDigest md = MessageDigest.getInstance("SHA-256");
//		      System.out.println("strFileName00000---"+strFileName);
//			try (DigestInputStream dis = new DigestInputStream(new FileInputStream(strFileName), md)) {
//				while (dis.read() != -1) ; //empty loop to clear the data
//					md = dis.getMessageDigest();
//				}
//
//			byte[] hashInBytes =  md.digest();
//			
//			StringBuilder sb = new StringBuilder();
//			for (byte b : hashInBytes) {
//				sb.append(String.format("%02x", b));
//			}
//			
//			
//			strDocHashCode =  sb.toString();
//			System.out.println("strDocHashCode---"+strDocHashCode);*/
//
//			//CacheUtil.setCacheObject(context, "appearance" + strId, appearance);
//			CacheUtil.setCacheObject(context, "filepath_token" + strId, filePath+File.separator+"TokenSinged_"+file.getName()); // store the file path as this file
//																				// needs to check in
//		} catch (Exception e) {
//			e.printStackTrace();
//		} 
//		/*catch (DocumentException e) {
//			e.printStackTrace();
//		} catch (FrameworkException e) {
//			e.printStackTrace();
//		}*/
//
//		return strDocHashCode;
//	}
	
	/**
     * To get the quick task complete link
     * @param context
     * @param args
     * @return StringList
     * @throws Exception
     * @since V6R2015x
     */
	public StringList getQuickTaskCompleteLink(Context context, String [] args) throws Exception{
		HashMap programMap        = (HashMap) JPO.unpackArgs(args);
	    MapList relBusObjPageList = (MapList)programMap.get("objectList");
		StringList slLinks = new StringList(relBusObjPageList.size());
		String sTaskLink = "";
	    for (int i=0; i < relBusObjPageList.size(); i++) {
	         Map collMap = (Map)relBusObjPageList.get(i);
	         String sTaskType  = (String)collMap.get(DomainObject.SELECT_TYPE);
	         String sTaskId  = (String)collMap.get(DomainObject.SELECT_ID);
	         String routeTaskAction  = (String)collMap.get("attribute["+ DomainConstants.ATTRIBUTE_ROUTE_ACTION +"]");
	         if(sTypeInboxTask.equals(sTaskType) && routeTaskAction.equalsIgnoreCase("Approve")){
	        	 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxTaskCompletePreProcess.jsp?action=Approve&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
	         }else if(sTypeInboxTask.equals(sTaskType) && (routeTaskAction.equalsIgnoreCase("Comment") || routeTaskAction.equalsIgnoreCase("Notify Only"))){
	        	 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxTaskCompletePreProcess.jsp?action=Complete&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
	         }else{
	        	 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxUserTasksSummaryLinksProcess.jsp?fromPage=Complete&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;emxTableRowId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
	         }
	         sTaskLink  = "<a href=\"" + sTaskLink + "\">" + "<img src=\"" + "../common/images/buttonDialogDone.gif" + "\" width=\"16px\" height=\"16px\"/>" + "</a>";
	         slLinks.add(sTaskLink);
	    }
		return slLinks;
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
   public MapList getAllRouteTasks(Context context, String[] args) throws Exception
   {
		MapList mlTaskList = JPO.invoke(context,"emxInboxTaskBase",args,"getAllRouteTasks",args,MapList.class);
		
		mlTaskList.sort("attribute[Route Sequence]", ProgramCentralConstants.ASCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
		
       return mlTaskList;

   }
   
   @com.matrixone.apps.framework.ui.ProgramCallable
   public MapList getDocuments(Context context, String[] args) throws Exception
   {
	   MapList mlFinalList = new MapList();
		HashMap programMap        = (HashMap) JPO.unpackArgs(args);
		String strObjectId = (String)programMap.get("objectId");
		if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
			DomainObject doObj = new DomainObject(strObjectId);
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainObject.SELECT_ID);
			slObjSelect.add(DomainObject.SELECT_NAME);
			slObjSelect.add(DomainObject.SELECT_ORIGINATED);
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			
			mlFinalList = doObj.getRelatedObjects(context, // matrix context
    				 DomainRelationship.RELATIONSHIP_REFERENCE_DOCUMENT, // relationship pattern
    				 "*", // type pattern
    				 slObjSelect, // object selects
    				 slRelSelect, // relationship selects
    				 false, // to direction
    				 true, // from direction
    				 (short) 1, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
			
			mlFinalList.sort(DomainObject.SELECT_ORIGINATED, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_DATE);
		}	
		
		return mlFinalList;
   }
	/**
	 * To show file drag/drop zone , object type must be eith MBE/AMB. this should not affect 
	 * other places
	 * 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	
	public static String isTypeAMBorMBE(Context context,String[] args) throws Exception{
		
		 HashMap programMap  = (HashMap) JPO.unpackArgs(args);
	     HashMap paramList   = (HashMap) programMap.get("paramList");
	     String strId=(String)paramList.get("objectId");
	     DomainObject dom=DomainObject.newInstance(context,strId);
	     String strType  = dom.getInfo(context, DomainConstants.SELECT_TYPE);
	     if(strType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY) || strType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY)){
	    	 return "true~"+strType+"~"+strId;
	     }
		 if(paramList.containsKey("parentOID")) {
			 strId= (String)paramList.get("parentOID");
			 dom.setId(strId);
			 strType = dom.getInfo(context, DomainConstants.SELECT_TYPE);
			 if(strType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY) || strType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY)){
		    	 return "true~"+strType+"~"+strId;
		     }
		 }
		
		 if(strType.equalsIgnoreCase(DomainConstants.TYPE_INBOX_TASK)) {
			 
			 strType=	 dom.getInfo(context, "from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.to["
						+ DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.type");
			 if(strType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY) || strType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY)){
		    	 return "true~"+strType+"~"+strId;
		     }
		 }
			return "false";
	}

	public static String getValueInWords(String strNumber)throws Exception{
		if(Double.valueOf(strNumber) == 0)
            return ZERO;
		DecimalFormat df1 = new DecimalFormat("#.##");   
		String strPrefix = DomainConstants.EMPTY_STRING;
		if(Double.valueOf(strNumber) <0){
			strPrefix = "-";
		}
		Double dValue = Math.abs(Double.valueOf(strNumber));
		dValue = Double.valueOf(df1.format(dValue));
		strNumber = new BigDecimal(dValue).setScale(2, RoundingMode.FLOOR).toPlainString();
		//strNumber = String.valueOf(dValue);
		
		StringList slNumbers = FrameworkUtil.split(strNumber,".");

		String strFirstValue = (String)slNumbers.get(0);
		String strSecondValue = (String)slNumbers.get(0);
		String strValue = DomainConstants.EMPTY_STRING;
		if(strFirstValue.length()>=10){
			strFirstValue = strFirstValue.substring(0,strFirstValue.length()-7);
			strSecondValue = strSecondValue.substring(strSecondValue.length()-7,strSecondValue.length());
			strValue = solution(Integer.valueOf(strFirstValue));	
		}
		String strValue2 = solution(Integer.valueOf(strSecondValue));		
		String strDecValue = solution(Integer.valueOf((String)slNumbers.get(1)));
		
		if(UIUtil.isNotNullAndNotEmpty(strValue))
			strValue = strValue + " Crore";
		
		String strFinalValue = strPrefix+ strValue +" "+strValue2 +" Rupees "+ strDecValue + " Paisa Only";
		
        return strFinalValue;
	}
	
	
	private static final String ZERO = "Zero";
    private static String[] oneToNine = {
            "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"
    };

    private static String[] tenToNinteen = {
            "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
    };

    private static String[] dozens = {
            "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    };

    public static String solution(int number) {
        if(number == 0)
            return ZERO;

        return generate(number).trim();
    }

    public static String generate(int number) {
		if(number >= 10000000) {
            return generate(number / 10000000) + " Crore " + generate(number % 10000000);
        }
        else if(number >= 100000) {
            return generate(number / 100000) + " Lakh " + generate(number % 100000);
        }
        else if(number >= 1000) {
            return generate(number / 1000) + " Thousand " + generate(number % 1000);
        }
        else if(number >= 100) {
            return generate(number / 100) + " Hundred " + generate(number % 100);
        }

        return generate1To99(number);
    }

    private static String generate1To99(int number) {
        if (number == 0)
            return "";

        if (number <= 9)
            return oneToNine[number - 1];
        else if (number <= 19)
            return tenToNinteen[number % 10];
        else {
            return dozens[number / 10 - 1] + " " + generate1To99(number % 10);
        }
    }

 @com.matrixone.apps.framework.ui.ProgramCallable
   public MapList getReferenceDocuments(Context context, String[] args) throws Exception
   {
	   MapList mlFinalList = new MapList();
		HashMap programMap        = (HashMap) JPO.unpackArgs(args);
		String strObjectId = (String)programMap.get("objectId");
		if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
			DomainObject doObj = new DomainObject(strObjectId);
			String strObjOwner = doObj.getInfo(context,DomainObject.SELECT_OWNER);
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainObject.SELECT_ID);
			slObjSelect.add(DomainObject.SELECT_NAME);
			slObjSelect.add(DomainObject.SELECT_ORIGINATED);
			slObjSelect.add(DomainObject.SELECT_OWNER);
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			
			mlFinalList = doObj.getRelatedObjects(context, // matrix context
    				 RELATIONSHIP_WMS_REFERENCE_DOCUMENTS, // relationship pattern
    				 "*", // type pattern
    				 slObjSelect, // object selects
    				 slRelSelect, // relationship selects
    				 false, // to direction
    				 true, // from direction
    				 (short) 1, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
			String strContextUser = context.getUser();
			for(int i=0;i<mlFinalList.size();i++){
				Map m = (Map) mlFinalList.get(i);
				String strOwner = (String)m.get(DomainObject.SELECT_OWNER);
				if(UIUtil.isNotNullAndNotEmpty(strOwner) && strContextUser.equals(strOwner) == false){
					m.put("disableSelection", "true");
				}
				if(strObjOwner.equals(strContextUser)){
					m.put("disableSelection", "false");
				}				
			}
			
			mlFinalList.sort(DomainObject.SELECT_ORIGINATED, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_DATE);
		}	
		
		return mlFinalList;
   }
	
	
	public static String converToIndianCurrency(Context context, Double dValue)throws Exception{
		try{
			String str = String.valueOf(dValue);
			BigDecimal amount = new BigDecimal(str);
			 Format format = com.ibm.icu.text.NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
			 String moneyString = format.format(amount);
			 String strReturn = moneyString.replace("Rs.","");
			 return strReturn;
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String conertToRoman(int input)throws Exception{
		if (input < 1 || input > 3999)
			return "Invalid Roman Number Value";
		String s = "";
		while (input >= 1000) {
			s += "M";
			input -= 1000;        }
		while (input >= 900) {
			s += "CM";
			input -= 900;
		}
		while (input >= 500) {
			s += "D";
			input -= 500;
		}
		while (input >= 400) {
			s += "CD";
			input -= 400;
		}
		while (input >= 100) {
			s += "C";
			input -= 100;
		}
		while (input >= 90) {
			s += "XC";
			input -= 90;
		}
		while (input >= 50) {
			s += "L";
			input -= 50;
		}
		while (input >= 40) {
			s += "XL";
			input -= 40;
		}
		while (input >= 10) {
			s += "X";
			input -= 10;
		}
		while (input >= 9) {
			s += "IX";
			input -= 9;
		}
		while (input >= 5) {
			s += "V";
			input -= 5;
		}
		while (input >= 4) {
			s += "IV";
			input -= 4;
		}
		while (input >= 1) {
			s += "I";
			input -= 1;
		}    
		return s;
		
	}
	
}

