import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.matrixone.apps.common.InboxTask;
import com.matrixone.apps.common.Person;
import com.matrixone.apps.common.Route;
import com.matrixone.apps.common.SubscriptionManager;
import com.matrixone.apps.common.util.DocumentUtil;
import com.matrixone.apps.common.util.JSPUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.CacheUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MailUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

//xml generation
import java.io.*;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.X509Certificate;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.openejb.jee.KeyExtractor;
import org.apache.xml.security.Init;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.ElementProxy;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMDecryptorProvider;
import org.bouncycastle.openssl.PEMEncryptedKeyPair;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.security.cert.CertificateFactory;
import java.nio.file.Files;
import java.nio.file.Paths;


import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Collection;
import java.util.List;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import sun.security.mscapi.SunMSCAPI;

public class WMSeSignIntegration_mxJPO extends WMSConstants_mxJPO {
	
	private  final String PRIVATE_KEY_ALIAS = "dgnp";
	private  final String PRIVATE_KEY_PASS = "dgnp";
	private  final String KEY_STORE_PASS = "dgnp";
	private  final String KEY_STORE_TYPE = "JKS";
	
	public WMSeSignIntegration_mxJPO(Context context, String[] args) {

		super(context, args);
	}

  public void triggerPerformESign(Context context,String[] args) throws Exception{
  try {
	  
 	     String strInboxTaskId = args[0];
		 String strType = args[1];
		 String strCurrentState = args[2];
		 if (strType.equalsIgnoreCase(DomainConstants.TYPE_INBOX_TASK)
				&& strCurrentState.equalsIgnoreCase("Complete")) {
		 	DomainObject domObject = DomainObject.newInstance(context, strInboxTaskId);
			StringList slSelect = new StringList(2);
			slSelect.add("attribute[" + DomainConstants.ATTRIBUTE_COMMENTS + "]");
			slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.id");
			slSelect.add("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_ROUTE_STATUS+"]");
			slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.to["
					+ DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.type");
			slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.to["
					+ DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.name");
			slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.to["
					+ DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.id");
			slSelect.add("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.id");
			slSelect.add("from[" + DomainConstants.RELATIONSHIP_PROJECT_TASK + "].to.name");
			Map mInboxData = domObject.getInfo(context, slSelect);
			String strConnectedType = (String) mInboxData.get("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK
					+ "].to.to[" + DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.type");
			String strRouteStatus= (String) mInboxData.get("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_ROUTE_STATUS+"]");
			if(!strRouteStatus.equalsIgnoreCase("STOPPED")) {	
				String strConnectedId = (String) mInboxData.get("from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK
						+ "].to.to[" + DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.id"); 
		         if (strConnectedType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY)) {
		        	 Map packArgs=new HashMap();		
		        	 packArgs.put("mode", "Approval"); 
		        	 packArgs.put("objectId", strConnectedId); 
		        	 packArgs.put("inboxTaskId", strInboxTaskId); 
		        	 DomainObject domAMB=DomainObject.newInstance(context, strConnectedId);
		        	 String strTypeOfContract = domAMB.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
		        	 String strJPOName= (strTypeOfContract.startsWith("EPC"))  ? "WMSDownloadForm26" : "WMSAMBDownloadItems";
		        	 JPO.invoke(context,strJPOName,null,"writeFiles",JPO.packArgs(packArgs),String.class);
		           }else if(strConnectedType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY)) {
					 String strWOId = MqlUtil.mqlCommand(context,"print bus "+strConnectedId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id dump");
					 String [] packArgs = new String[5];		
					 packArgs[0] = strConnectedId;
					 packArgs[1] = strWOId;
					 packArgs[2]=strConnectedType;
					 packArgs[3]=strInboxTaskId;
					 packArgs[4]= "Approval";
			 		 JPO.invoke(context,"WMSExportMeasurementItems",packArgs,"createMeasurementBookExport",packArgs,String.class);
	 	           }
		        }
		  
		}//end of fist if 
	  
     }catch(Exception e ) {
	  e.printStackTrace();
    }
  
  }
  /**
   * Column method added on Table WMSApporvalHistory 
   * 
   * @param context
   * @param args
   * @return
   * @throws Exception
   */
  
  
  
  public Vector getEsignDocumentLink(Context context, String[] args) throws Exception
  {
  	Vector colVector = new Vector();
    try { 
    	 
   	 //String strDownLoadTip="Download e-Signed document";
   	 String strDownLoadTip="Download";
   	 Object _fileId = "";
     Object _fileName ="";
     Object _fileFormat ="";
	 
	 String _strfileId = "";
     String _strfileName ="";
     String _strfileFormat ="";
	 
   	 HashMap programMap         = (HashMap) JPO.unpackArgs(args);
	 HashMap paramList = (HashMap) programMap.get("paramList");
     MapList objectList  = (MapList) programMap.get("objectList");
	 String sIsEsignEnable = EnoviaResourceBundle.getProperty(context, "WMS.Esign.Enable");
     Iterator<Map> itr = objectList.iterator();
     String strInboxTaskId=DomainConstants.EMPTY_STRING;
	String strObjectId = (String)paramList.get("objectId");
	boolean isESignEnabledForObject = true;
	if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
		DomainObject doObject = new DomainObject(strObjectId);
		String strESignEnabled = (String)doObject.getAttributeValue(context,ATTRIBUTE_WMS_ENABLE_ESIGN);
		if(UIUtil.isNotNullAndNotEmpty(strESignEnabled) && "No".equalsIgnoreCase(strESignEnabled))
			isESignEnabledForObject = false;
	}	

	while(itr.hasNext()) {
		 String downloadURL="../components/emxCommonDocumentPreCheckout.jsp?action=download";
   		 Map m = itr.next();
   		  strInboxTaskId=(String) m.get(DomainConstants.SELECT_ID);
   		  StringBuilder sb=new StringBuilder();
   		  if(Boolean.valueOf(sIsEsignEnable) && isESignEnabledForObject) {
   		     downloadURL=downloadURL+"&amp;objectId="+strInboxTaskId;
			sb.append("<a href=\"" + downloadURL + "\"  target=\"hiddenFrame\"   >");
	    	 sb.append("<img border=\"0\" src=\"../common/images/iconSmallCertification.gif\" alt=\""
			+ strDownLoadTip + "\" title=\"" + strDownLoadTip + "\"></img></a>&#160;");
   		  }else {
			  if(isESignEnabledForObject == false){
				  String strMessage = EnoviaResourceBundle.getProperty(context, "wmsStringResource", context.getLocale(),
						"WMS.Message.Specific.ESignDisabled");
				  sb.append(strMessage);
			  }else{
				 //String strMessage = EnoviaResourceBundle.getProperty(context, "wmsStringResource", context.getLocale(),		"WMS.Message.ESignDisabled");
						 //sb.append(strMessage);
					downloadURL=downloadURL+"&amp;objectId="+strObjectId;
					sb.append("<a href=\"" + downloadURL + "\"  target=\"hiddenFrame\"   >");
					 sb.append("<img border=\"0\" src=\"../common/images/iconSmallCertification.gif\" alt=\""
					+ strDownLoadTip + "\" title=\"" + strDownLoadTip + "\"></img></a>&#160;");
				
			  }
   		  }
   		 colVector.add(sb.toString());
   	 }
   	 
   }catch(Exception e) {
   	e.printStackTrace();
   } 
  
 return colVector;
}
/**
 * Method will generate xml data required for eSign process
 * 
 * @param context
 * @param args
 * @throws Exception
 */
  
  
  
public Map generateESignXMLRequest(Context context, String[] args) throws Exception{
  String strSignedXML=DomainConstants.EMPTY_STRING;
   Map<String,String> mReturnData=new HashMap<String,String>();
	try {
		String strAdded = MqlUtil.mqlCommand(context, "print bus $1 select interface dump", args[0]);
		if(strAdded.trim().isEmpty())
	       MqlUtil.mqlCommand(context, "modify bus $1 add interface $2", args[0],"WMSeSignAttributes");
	  // Check in file and store the hashvalue in WMSFileHashCode attribute
	 triggerPerformESign(context,args); // check in the file into Task
 	 Map<String,String> mAttribute=new HashMap<String,String>();
	 DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	 DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	 DomainObject domInbox=DomainObject.newInstance(context, args[0]);
	 String strFileHashValue = domInbox.getAttributeValue(context, ATTRIBUTE_WMS_FILE_HASH_CODE);
	 String strESignResponseURL = EnoviaResourceBundle.getProperty(context, "WMS.Esign.Response.URL");
	 Document doc = docBuilder.newDocument();
	 Element rootElement = doc.createElement("Esign");
	 doc.appendChild(rootElement);
     mAttribute.put("AuthMode", "1");
	 mAttribute.put("aspId", "NICS-001");
	 mAttribute.put("ekycIdType", "A");
	 mAttribute.put("responseSigType", "pkcs7");
	 mAttribute.put("responseUrl", strESignResponseURL);
	 mAttribute.put("sc", "Y");
	 long time = System.currentTimeMillis();
	 //String strFormatedDate = DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(Instant.ofEpochMilli(time).atZone(ZoneOffset.UTC));
	 String strFormatedDate = DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(Instant.ofEpochMilli(time).atZone(ZoneOffset.systemDefault()));
	 mAttribute.put("ts", strFormatedDate);
	 String strTxnId= randomAlphaNumeric(32);
	 mAttribute.put("txn", strTxnId);
	 mReturnData.put("aspTxnID", strTxnId);
	 mAttribute.put("ver", "2.1");
	 setAttributNodes(rootElement,mAttribute);
	 mAttribute.clear();
	 Element docsElement = doc.createElement("Docs");
		 Element inputHashElement = doc.createElement("InputHash");
		 mAttribute.put("docInfo", "ESigning"); // format this
		 mAttribute.put("hashAlgorithm", "SHA256");
		 mAttribute.put("id", "1");
		 setAttributNodes(inputHashElement,mAttribute);
		 inputHashElement.setTextContent(strFileHashValue); // hash value goes here
		 docsElement.appendChild(inputHashElement);
		 rootElement.appendChild(docsElement);
		 strSignedXML = StringEscapeUtils.escapeXml(doSignXMLContent(context,doc));
		 mReturnData.put("signedXML", strSignedXML);
	    }catch(Exception e) {
	e.printStackTrace();
	throw e;
    }
return mReturnData;
} 	


public Map generateESignXMLRequestForEDongle(Context context, String[] args) throws Exception{
  String strSignedXML=DomainConstants.EMPTY_STRING;
   Map<String,String> mReturnData=new HashMap<String,String>();
	try {
		String strAdded = MqlUtil.mqlCommand(context, "print bus $1 select interface dump", args[0]);
		if(strAdded.trim().isEmpty())
	       MqlUtil.mqlCommand(context, "modify bus $1 add interface $2", args[0],"WMSeSignAttributes");
	  // Check in file and store the hashvalue in WMSFileHashCode attribute
		 triggerPerformESign(context,args); // check in the file into Task
		 Map<String,String> mAttribute=new HashMap<String,String>();
		 DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		 DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		 DomainObject domInbox=DomainObject.newInstance(context, args[0]);
		 String strFileHashValue = domInbox.getAttributeValue(context, ATTRIBUTE_WMS_TOKEN_FILE_HASH);
		 String strTxnId= randomAlphaNumeric(32);
		 mReturnData.put("aspTxnID", strTxnId);
		 mReturnData.put("signedXML", strFileHashValue);
	    
	}catch(Exception e) {
	e.printStackTrace();
	throw e;
    }
return mReturnData;
} 


  private void setAttributNodes(Element element,Map<String,String> attributeMap ) {
	  
	  Set<String> setKeys= attributeMap.keySet();
	  Iterator<String> itrsetKeys = setKeys.iterator();
	  String strKey=DomainConstants.EMPTY_STRING;
	  while(itrsetKeys.hasNext()) {
		  strKey=itrsetKeys.next();
		  element.setAttribute(strKey, attributeMap.get(strKey));  
		  
	  }
	  
	  
  }	

  /**
   * // Below method generates signature info and dumps into XML (enveloped XML) 
   * 
   * 
   * @param context
   * @param xmlDoument
   * @throws Exception
   */
  public String doSignXMLContent(Context context,Document xmlDoument) throws Exception
  {
 	try {
		 String strEsignJKSPath = EnoviaResourceBundle.getProperty(context, "WMS.Esign.JKS.Path");
 	        return signFile(xmlDoument, new File(strEsignJKSPath));
	    }catch(Exception e) {
	   	  e.printStackTrace();
	   	  throw e;
	  }
  }
	
	
  private String signFile(Document doc, File privateKeyFile) throws Exception {
      //  final Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xmlFile);
        Init.init();
        ElementProxy.setDefaultPrefix(Constants.SignatureSpecNS, "");
        //final KeyStore keyStore = loadKeyStore(privateKeyFile);
        final XMLSignature sig = new XMLSignature(doc, null, XMLSignature.ALGO_ID_SIGNATURE_RSA);
        final Transforms transforms = new Transforms(doc);
        transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);
        sig.addDocument("", transforms, Constants.ALGO_ID_DIGEST_SHA1);
       // final Key privateKey = keyStore.getKey(PRIVATE_KEY_ALIAS, PRIVATE_KEY_PASS.toCharArray());
       // final X509Certificate cert = (X509Certificate)keyStore.getCertificate(PRIVATE_KEY_ALIAS);
	    
		String strCertificateFilePath = EnoviaResourceBundle.getProperty(context, "WMS.Esign.Certificate.Path");
		String strKeyFilePath = EnoviaResourceBundle.getProperty(context, "WMS.Esign.PrivateKey.Path");
		CertificateFactory cf = CertificateFactory.getInstance("X.509");
		InputStream fileInputStream = new FileInputStream(strCertificateFilePath);
		final X509Certificate cert = (X509Certificate) cf.generateCertificate(fileInputStream);
		
		KeyPair keyPair = extractKeysFromStream(strKeyFilePath);
	   
        //sig.addKeyInfo(cert);
        //sig.addKeyInfo(cert.getPublicKey());
        sig.sign(keyPair.getPrivate());
        doc.getDocumentElement().appendChild(sig.getElement());
        //to remove extra tag if required 
       /* Element element = (Element) doc.getElementsByTagName("KeyInfo").item(0);
        Node parent = element.getParentNode();
        parent.removeChild(element);
        parent.normalize();*/	
        
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer trans = tf.newTransformer();
        StringWriter sw = new StringWriter();
        trans.transform(new DOMSource(doc), new StreamResult(sw));
         final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        outputStream.write(Canonicalizer.getInstance(Canonicalizer.ALGO_ID_C14N_WITH_COMMENTS).canonicalizeSubtree(doc));
        return outputStream.toString();
    }

    private  KeyStore loadKeyStore(File privateKeyFile) throws Exception {
        final InputStream fileInputStream = new FileInputStream(privateKeyFile);
        try {
            final KeyStore keyStore = KeyStore.getInstance(KEY_STORE_TYPE);
            keyStore.load(fileInputStream, KEY_STORE_PASS.toCharArray());
            return keyStore;
        }
        finally {
            IOUtils.closeQuietly(fileInputStream);
        }
    }
 /**Method will process the coming from eSign process
  * Will approve the task 
  *  
  * @param context
  * @param args
  * @return
  * @throws Exception
  */
   
	/*public Map<String, String> processESignResponce(Context context, String[] args) throws Exception {
		Map<String,String> mResponce = new HashMap<String,String>();
		String strXMLResponce = args[0];
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		String strTaskId=DomainConstants.EMPTY_STRING;
		try {
 		    builder = factory.newDocumentBuilder();
			Document document = builder.parse(new InputSource(new StringReader(strXMLResponce)));
			Node node = ((NodeList) document.getElementsByTagName("EsignResp")).item(0);
			String strAnyError = node.getAttributes().getNamedItem("errMsg").getNodeValue();

			if (strAnyError.equalsIgnoreCase("NA")) {
				Node docSignature = ((NodeList) document.getElementsByTagName("DocSignature")).item(0);
				String strSha256Value = docSignature.getTextContent();
				strTaskId = args[1];
				String strRouteId = args[2];
				String strTimeZone = args[3];
				Locale localeObject = new Locale(context.getSession().getLanguage());
				emxInboxTask_mxJPO emxInboxTask = new emxInboxTask_mxJPO(context, args);
			  	PdfSignatureAppearance appearance = (PdfSignatureAppearance) CacheUtil.getCacheObject(context,
						"appearance" + strTaskId);
				int contentEstimated = 10000;
				byte[] sigbytes = Base64.decodeBase64(strSha256Value);
				byte[] paddedSig = new byte[contentEstimated];
				System.arraycopy(sigbytes, 0, paddedSig, 0, sigbytes.length);
				PdfDictionary dic2 = new PdfDictionary();
				dic2.put(PdfName.CONTENTS, new PdfString(paddedSig).setHexWriting(true));
		 		try {
			 		appearance.close(dic2);
		 		} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
		 			e.printStackTrace();
				}

				DomainObject domInBoxTask = DomainObject.newInstance(context, strTaskId);
				domInBoxTask.setAttributeValue(context, ATTRIBUTE_WMS_RESPONSE_HASHCODE, strSha256Value);
				Map requestMap = new HashMap();
				requestMap.put("objectId", strTaskId);
				requestMap.put("localeObj", localeObject);
				requestMap.put("Comments", domInBoxTask.getAttributeValue(context, DomainConstants.ATTRIBUTE_COMMENTS));
				Map mProgramMap = new HashMap();
				mProgramMap.put("requestMap", requestMap);
				performApprovalPostProcess(context, strTaskId, strRouteId, strTimeZone);
				emxInboxTask.updateTaskDetails(context, JPO.packArgs(mProgramMap));
				String strSignedFilePath = (String) CacheUtil.getCacheObject(context, "filepath" + strTaskId);
				File signedfile = new File(strSignedFilePath);
				String absolutePath = signedfile.getAbsolutePath();
				String filePath = absolutePath.substring(0, absolutePath.lastIndexOf(File.separator));
				domInBoxTask.checkinFile(context, true, true, "", DomainConstants.FORMAT_GENERIC,
						"Signed_" + signedfile.getName(), filePath);

				String strMessage = EnoviaResourceBundle.getProperty(context, "wmsStringResource", context.getLocale(),
						"WMS.Alert.Message.EsignSuccess");
				mResponce.put("Msg", strMessage);
			} else {
				strTaskId = args[1];
				DomainObject domInBoxTask = DomainObject.newInstance(context, strTaskId);
				domInBoxTask.setAttributeValue(context, DomainConstants.ATTRIBUTE_COMMENTS, DomainConstants.EMPTY_STRING);
				mResponce.put("Msg", strAnyError);
			}
		} catch (Exception e) {
			strTaskId = args[1];
			DomainObject domInBoxTask = DomainObject.newInstance(context, strTaskId);
			domInBoxTask.setAttributeValue(context, DomainConstants.ATTRIBUTE_COMMENTS, DomainConstants.EMPTY_STRING);
	 		e.printStackTrace();
		}finally {
			CacheUtil.removeCacheObject(context, "appearance" + strTaskId); //remove appearance object 
			CacheUtil.removeCacheObject(context, "filepath" + strTaskId); ////remove appearance object 
		}

		return mResponce;

	}*/
	
	public Map<String, String> processESignResponceEDongle(Context context, String[] args) throws Exception {
		Map<String,String> mResponce = new HashMap<String,String>();
		String strSignData = args[0];
		String strSignHash = args[1];
		String strSerialNumber = args[2];
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		String strTaskId=DomainConstants.EMPTY_STRING;
		try {
 		    
			if (UIUtil.isNotNullAndNotEmpty(strSignData)) {
				//String strSha256Value = strSignData.replaceAll(" ","+");
				//String strSingHashData = strSignHash.replaceAll(" ","+");
				//String strETokenNumber = strSerialNumber.replaceAll(" ","+");
				
				strTaskId = args[3];
				String strRouteId = args[4];
				String strTimeZone = args[5];
				Locale localeObject = new Locale(context.getSession().getLanguage());
				emxInboxTask_mxJPO emxInboxTask = new emxInboxTask_mxJPO(context, args);
				
				/*System.out.println("processESignResponceEDongle strSignData------"+strSha256Value);
				System.out.println("processESignResponceEDongle strSha256Value------"+strSha256Value);
				strTaskId = args[2];
				
			  	PdfSignatureAppearance appearance = (PdfSignatureAppearance) CacheUtil.getCacheObject(context,
					"appearance" + strTaskId);
				
				int contentEstimated = 10000;
				byte[] sigbytes = Base64.decodeBase64(strSha256Value);
				byte[] paddedSig = new byte[contentEstimated];
				System.arraycopy(sigbytes, 0, paddedSig, 0, sigbytes.length);
				PdfDictionary dic2 = new PdfDictionary();
				dic2.put(PdfName.CONTENTS, new PdfString(paddedSig).setHexWriting(true));
		 		try {
			 		appearance.close(dic2);
		 		} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DocumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
		 			e.printStackTrace();
				}
				*/
				DomainObject domInBoxTask = DomainObject.newInstance(context, strTaskId);
				//domInBoxTask.setAttributeValue(context, ATTRIBUTE_WMS_TOKEN_SIGNED_FILE_HASH, strSha256Value);
				//domInBoxTask.setAttributeValue(context, ATTRIBUTE_WMS_TOKEN_RESPONCE_HASH, strSingHashData);
				//domInBoxTask.setAttributeValue(context, ATTRIBUTE_WMS_E_TOKEN_NUMBER, strETokenNumber);
				
				domInBoxTask.setAttributeValue(context, ATTRIBUTE_WMS_TOKEN_SIGNED_FILE_HASH, strSignData);
				domInBoxTask.setAttributeValue(context, ATTRIBUTE_WMS_TOKEN_RESPONCE_HASH, strSignHash);
				domInBoxTask.setAttributeValue(context, ATTRIBUTE_WMS_E_TOKEN_NUMBER, strSerialNumber);
				
				Map requestMap = new HashMap();
				requestMap.put("objectId", strTaskId);
				requestMap.put("localeObj", localeObject);
				requestMap.put("Comments", domInBoxTask.getAttributeValue(context, DomainConstants.ATTRIBUTE_COMMENTS));
				Map mProgramMap = new HashMap();
				mProgramMap.put("requestMap", requestMap);
				performApprovalPostProcess(context, strTaskId, strRouteId, strTimeZone);
				emxInboxTask.updateTaskDetails(context, JPO.packArgs(mProgramMap));
				String strSignedFilePath = (String) CacheUtil.getCacheObject(context, "filepath_token" + strTaskId);
				
				File signedfile = new File(strSignedFilePath);
				String absolutePath = signedfile.getAbsolutePath();
				String filePath = absolutePath.substring(0, absolutePath.lastIndexOf(File.separator));
				domInBoxTask.checkinFile(context, true, true, "", DomainConstants.FORMAT_GENERIC,
						signedfile.getName(), filePath);

				String strMessage = EnoviaResourceBundle.getProperty(context, "wmsStringResource", context.getLocale(),
						"WMS.Alert.Message.EsignSuccess");
				mResponce.put("Msg", strMessage);
			} else {
				strTaskId = args[1];
				DomainObject domInBoxTask = DomainObject.newInstance(context, strTaskId);
				domInBoxTask.setAttributeValue(context, DomainConstants.ATTRIBUTE_COMMENTS, DomainConstants.EMPTY_STRING);
				mResponce.put("Msg", "eSign Unsuccessful.");
			}
		} catch (Exception e) {
			strTaskId = args[1];
			DomainObject domInBoxTask = DomainObject.newInstance(context, strTaskId);
			domInBoxTask.setAttributeValue(context, DomainConstants.ATTRIBUTE_COMMENTS, DomainConstants.EMPTY_STRING);
	 		e.printStackTrace();
		}finally {
			CacheUtil.removeCacheObject(context, "appearance" + strTaskId); //remove appearance object 
			CacheUtil.removeCacheObject(context, "filepath_token" + strTaskId); ////remove appearance object 
		}

		return mResponce;

	}
	
	
  /** To generate 32 digit unique transaction id 
   * 
   */
	
     private static final String ALPHA_NUMERIC_STRING = "abcdefghijklmnopqrstuvwxyz0123456789";
	 private  String randomAlphaNumeric(int count) {
	 StringBuilder builder = new StringBuilder();
	 while (count-- != 0) {
	 int character = (int)(Math.random()*ALPHA_NUMERIC_STRING.length());
	 builder.append(ALPHA_NUMERIC_STRING.charAt(character));
	 }
	 return builder.toString();
	 }
	
	 /**Below method completes the inbox task  (code of emxTaskCompleteProcess.jsp) ...
	  * 
	  * @param context
	  * @param taskId
	  * @param routeId
	  * @param strTimeZone
	  */
	 
		private void performApprovalPostProcess(Context context,String taskId,String routeId,String strTimeZone) {
	 try {	
		 String strCommentsAttr       = PropertyUtil.getSchemaProperty(context,"attribute_Comments" );
		 String strApprovalStatusAttr = PropertyUtil.getSchemaProperty(context, "attribute_ApprovalStatus" );
		 Route route = (Route)DomainObject.newInstance(context,  routeId);
		    com.matrixone.apps.common.Person person = new com.matrixone.apps.common.Person();
		    com.matrixone.apps.domain.DomainObject task = new com.matrixone.apps.domain.DomainObject();
		    task.setId(taskId);
		    String comments = task.getInfo(context, "attribute[" + DomainConstants.ATTRIBUTE_COMMENTS + "]");
		    String attributeBracket = "attribute[";
		    String closeBracket = "]";
		    DomainRelationship domainRel            = null;
		    String attrReviewCommentsNeeded         = PropertyUtil.getSchemaProperty(context, "attribute_ReviewCommentsNeeded");
		    String sAttParallelNodeProcessonRule    = PropertyUtil.getSchemaProperty(context, "attribute_ParallelNodeProcessionRule");
		    String attrTaskCommentsNeeded   = PropertyUtil.getSchemaProperty(context, "attribute_TaskCommentsNeeded");
		    String strRouteActionAttr         = PropertyUtil.getSchemaProperty(context, "attribute_RouteAction" );
		    String SELECT_ROUTE_ACTION          = "attribute[" + strRouteActionAttr + "]";

		    double clientTZOffset                   = new Double(strTimeZone).doubleValue();
		    boolean bTaskCommentGiven               = false;
		    boolean returnBack                      = false;
		    boolean isProjectSpace                  = false;
		    String OFFSET_FROM_TASK_CREATE_DATE     = "Task Create Date";
		    String routeTime                        = "";
		    String taskCommNeeded     = "";
		    String strWorkspaceId   = "";
		    String taskScheduledDate  = "";

		    StringBuffer sAttrComments =new StringBuffer(attributeBracket);
		    sAttrComments.append(DomainConstants.ATTRIBUTE_COMMENTS);
		    sAttrComments.append(closeBracket);
		    StringBuffer sAttrReviewTask =new StringBuffer(attributeBracket);
		    sAttrReviewTask.append(DomainConstants.ATTRIBUTE_REVIEW_TASK);
		    sAttrReviewTask.append(closeBracket);
		    StringBuffer sAttrRouteNodeId =new StringBuffer(attributeBracket);
		    sAttrRouteNodeId.append(DomainConstants.ATTRIBUTE_ROUTE_NODE_ID);
		    sAttrRouteNodeId.append(closeBracket);
		    StringBuffer sAttrApprovalStatus =new StringBuffer(attributeBracket);
		    sAttrApprovalStatus.append(DomainObject.ATTRIBUTE_APPROVAL_STATUS);
		    sAttrApprovalStatus.append(closeBracket);
		    StringBuffer sAttrScheduledCompletionDate =new StringBuffer(attributeBracket);
		    sAttrScheduledCompletionDate.append(DomainObject.ATTRIBUTE_SCHEDULED_COMPLETION_DATE );
		    sAttrScheduledCompletionDate.append(closeBracket);

		    StringList selectStmt = new StringList();
		    selectStmt.addElement(sAttrComments.toString());
		    selectStmt.addElement(sAttrReviewTask.toString());
		    selectStmt.addElement(sAttrRouteNodeId.toString());
		    selectStmt.addElement(sAttrApprovalStatus.toString());
		    selectStmt.addElement(sAttrScheduledCompletionDate.toString());
		    selectStmt.addElement("from["+DomainObject.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainObject.RELATIONSHIP_ROUTE_SCOPE+"].from.id");
		    selectStmt.addElement(SELECT_ROUTE_ACTION);

		    person=Person.getPerson(context);
		    
		    String personName = (String)person.getInfo(context,person.SELECT_NAME);
            
		  
 	        AttributeList attrList                  = new AttributeList();
		    Map taskInfoMap           = task.getInfo(context, selectStmt);
            taskCommNeeded            = task.getAttributeValue(context , attrTaskCommentsNeeded);
		    strWorkspaceId                     = (String)taskInfoMap.get("from["+DomainObject.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainObject.RELATIONSHIP_ROUTE_SCOPE+"].from.id");
		    taskScheduledDate                = (String)taskInfoMap.get(sAttrScheduledCompletionDate.toString());
		    
		    //Check the property where the comments are needed for an approval task.
		  
		    String taskStatus="Approve";
	    	try{
				ContextUtil.startTransaction(context, true);
	            String strDateTime              = "";

	            if(taskScheduledDate != null && !"null".equals(taskScheduledDate) && !"".equals(taskScheduledDate)){
	                    strDateTime                     = taskScheduledDate;//eMatrixDateFormat.getFormattedInputDateTime(context,taskScheduledDate,routeTime,clientTZOffset,request.getLocale());
	            }
	            String routeNodeId        = (String)taskInfoMap.get(sAttrRouteNodeId.toString());
	            //Get the correct relId for the RouteNodeRel given the attr routeNodeId from the InboxTask.
	            routeNodeId = route.getRouteNodeRelId(context, routeNodeId);
	            String reviewTask         = (String)taskInfoMap.get(sAttrReviewTask.toString());
	            if(bTaskCommentGiven){
	                    task.setAttributeValue(context,attrTaskCommentsNeeded, "No");
	            } else {
	                    task.setAttributeValue(context,attrTaskCommentsNeeded, "Yes");
	            }

	            // Setting the attributes to the task object
	            if (!"".equals(taskStatus)){
	                    attrList.addElement(new Attribute(new AttributeType(strApprovalStatusAttr), taskStatus));
	            }
	            if(!"".equals(strDateTime)){
	                    attrList.addElement(new Attribute(new AttributeType(DomainConstants.ATTRIBUTE_SCHEDULED_COMPLETION_DATE), strDateTime));
	            }
	            attrList.addElement(new Attribute(new AttributeType(DomainConstants.ATTRIBUTE_COMMENTS), comments));
				task.setAttributes(context,attrList);
	            MailUtil.setTreeMenuName(context, "type_InboxTask" );
	       	  try {
                  StringBuffer sAttrDueDateOffset =new StringBuffer(attributeBracket);
                  sAttrDueDateOffset.append(DomainConstants.ATTRIBUTE_DUEDATE_OFFSET);
                  sAttrDueDateOffset.append(closeBracket);
                  StringBuffer sAttrDueDateOffsetFrom =new StringBuffer(attributeBracket);
                  sAttrDueDateOffsetFrom.append(DomainConstants.ATTRIBUTE_DATE_OFFSET_FROM);
                  sAttrDueDateOffsetFrom.append(closeBracket);
                  StringBuffer sAttrSequence =new StringBuffer(attributeBracket);
                  sAttrSequence.append(DomainConstants.ATTRIBUTE_ROUTE_SEQUENCE);
                  sAttrSequence.append(closeBracket);
                  String selState               = DomainObject.SELECT_CURRENT;  // get state

                  StringList relSelects            = new StringList();

                  StringBuffer sWhereExp           = new StringBuffer();
                  int nextTaskSeq                  = 0;
                  int currTaskSeq                  = 0;
                  domainRel                     = DomainRelationship.newInstance(context ,routeNodeId);
                  String currTaskSeqStr         = domainRel.getAttributeValue(context, DomainObject.ATTRIBUTE_ROUTE_SEQUENCE);
                  String parallelType                  = domainRel.getAttributeValue(context, sAttParallelNodeProcessonRule);

                  // get current / next task sequence
                  if(currTaskSeqStr != null && !"".equals(currTaskSeqStr) && !"null".equals(currTaskSeqStr)){
                          currTaskSeq = Integer.parseInt(currTaskSeqStr);
                          nextTaskSeq = currTaskSeq+1;
                  }
                  relSelects.addElement(sAttrDueDateOffset.toString());
                  relSelects.addElement(sAttrDueDateOffsetFrom.toString());
                  relSelects.addElement(DomainObject.SELECT_RELATIONSHIP_ID);
                  sWhereExp.append("(");
                  sWhereExp.append(selState);
                  sWhereExp.append(" != \"");
                  sWhereExp.append(DomainObject.STATE_INBOX_TASK_COMPLETE);
                  sWhereExp.append("\")");
                  sWhereExp.append(" && (");
                  sWhereExp.append(sAttrSequence.toString());
                  sWhereExp.append(" == \"");
                  sWhereExp.append(String.valueOf(currTaskSeq));
                  sWhereExp.append("\")");
                  // finds all same order tasks which are not yet complete; if any such exists, next offset task due-date is not set till all complete
                  boolean shouldSetNextTaskDueDate = shouldSetNextTaskDueDate(context, route,currTaskSeq+"");
                  boolean completeAny              = true;
                  if("All".equals(parallelType)){
                          completeAny = false;
                  }
                  // can proceed to set offset due-date for next task
                  // only if Parallel node rule is 'Any' or corresponding flag got is true
                  if(completeAny || shouldSetNextTaskDueDate){
                          // where clause filters to next order tasks offset from this task complete
                          sWhereExp = new StringBuffer();
                          sWhereExp.append("(");
                          sWhereExp.append(sAttrDueDateOffset.toString());
                          sWhereExp.append(" !~~ \"\")");
                          sWhereExp.append(" && (");
                          sWhereExp.append(sAttrDueDateOffsetFrom.toString());
                          sWhereExp.append(" ~~ \"");
                          sWhereExp.append(OFFSET_FROM_TASK_CREATE_DATE);
                          sWhereExp.append("\")");
                          sWhereExp.append(" && (");
                          sWhereExp.append(sAttrSequence.toString());
                          sWhereExp.append(" == \"");
                          sWhereExp.append(String.valueOf(nextTaskSeq));
                          sWhereExp.append("\")");
                          // get all next order tasks with offset from this task promotion / next task creation
                          MapList nextOrderOffsetList = getNextOrderOffsetTasks(context, route, relSelects, sWhereExp.toString());

                          // set Scheduled Due Date attribute for all delta offset Route Nodes
                          Route.setDueDatesFromOffset(context, nextOrderOffsetList);
                  }
          
 	 }catch(Exception e) {
		 e.printStackTrace();
	 }	
	 
              MapList subRouteList=route.getAllSubRoutes(context);
              String i18NReadAndUnderstand =EnoviaResourceBundle.getProperty(context, "emxFrameworkStringResource", context.getLocale(),
            			"emxFramework.UserAuthentication.ReadAndUnderstand");
            	   
              try {
              task.promote(context);
              {
					String isFDAEnabled = EnoviaResourceBundle.getProperty(context,"emxFramework.Routes.EnableFDA");
              	if(UIUtil.isNotNullAndNotEmpty(isFDAEnabled) && isFDAEnabled.equals("true")) {
              	String strRouteTaskUser = task.getAttributeValue(context,DomainConstants.ATTRIBUTE_ROUTE_TASK_USER);
              	String isResponsibleRoleEnabled = DomainConstants.EMPTY_STRING;
	                	try {
              		isResponsibleRoleEnabled = EnoviaResourceBundle.getProperty(context,"emxFramework.Routes.ResponsibleRoleForSignatureMeaning.Preserve");
	                	} catch(Exception e) {
              		isResponsibleRoleEnabled = "false";
              	}
	                	if(UIUtil.isNotNullAndNotEmpty(isResponsibleRoleEnabled) && isResponsibleRoleEnabled.equalsIgnoreCase("true") && UIUtil.isNotNullAndNotEmpty(strRouteTaskUser) && strRouteTaskUser.startsWith("role_")) {
              		  i18NReadAndUnderstand = MessageUtil.getMessage(context, null, "emxFramework.UserAuthentication.ReadAndUnderstandRole", new String[] {
              				  PropertyUtil.getSchemaProperty(context, strRouteTaskUser)}, null, context.getLocale(),
              				  "emxFrameworkStringResource");
	                		if (taskStatus.equalsIgnoreCase("Approve")){
	                			MqlUtil.mqlCommand(context, "Modify bus $1 add history $2 comment $3",false, taskId,"approve",i18NReadAndUnderstand);
	                		} else {
              				MqlUtil.mqlCommand(context, "Modify bus $1 add history $2 comment $3",false, taskId,taskStatus,i18NReadAndUnderstand);
              			}
	                	} else {
	                		if (taskStatus.equalsIgnoreCase("Approve")) {
	                			MqlUtil.mqlCommand(context, "Modify bus $1 add history $2 comment $3",false, taskId,"approve",i18NReadAndUnderstand);
	                		} else {
             					MqlUtil.mqlCommand(context, "Modify bus $1 add history $2 comment $3",false, taskId,taskStatus,i18NReadAndUnderstand);
              			}
              		}
              	}
              }


              // Added to notify to the subscribed person, if Task completion event is subscribed -start
           	String taskState = task.getInfo(context, DomainConstants.SELECT_CURRENT);

           	if(Route.STATE_ROUTE_COMPLETE.equals(taskState)) {
	        		try {
		              	SubscriptionManager subscriptionMgr = route.getSubscriptionManager();
		              	subscriptionMgr.publishEvent(context, route.EVENT_TASK_COMPLETED, task.getId(context));
		             } catch(Exception e) {
		             	System.out.println(e.getMessage());
		             }
           	}
	          	// Added to notify to the subscribed person, if Task completion event is subscribed -end

              String  sLanguage="en-US,en;q=0.9";
              String sSubject =i18nNow.getI18nString("emxComponents.common.TaskDeletionNotice", "emxComponentsStringResource" ,sLanguage);
              String sMessage1=i18nNow.getI18nString("emxComponents.common.TaskDeletionMessage3", "emxComponentsStringResource" ,sLanguage);
              String sMessage2=i18nNow.getI18nString("emxComponents.common.TaskDeletionMessage2", "emxComponentsStringResource" ,sLanguage);
              String sMessage=sMessage1+" "+task.getName()+" "+sMessage2;
              route.deleteOrphanSubRoutes(context,subRouteList,sMessage,sSubject);
              // set Inbox Task title for auto-namer tasks
              try{
                      ContextUtil.pushContext(context);
                      InboxTask.setTaskTitle(context, routeId);
                      ContextUtil.popContext(context);
                  }catch(Exception ex){
                     // session.putValue("error.message",ex);
                  }
              // publish subscription events
              if (!"".equals(routeId)) {
                     MailUtil.setTreeMenuName(context, "type_Route" );
                      StringList stringlist = new StringList(10);
                      stringlist.clear();
                      stringlist.add("id");
                      stringlist.add("type");
                      stringlist.add("grantor");
                      stringlist.add("grantee");
                      stringlist.add("granteeaccess");

                      DomainObject domainobject1 = new DomainObject();
                      domainobject1.setId(routeId);

                      MapList maplist = domainobject1.getRelatedObjects(context, DomainConstants.RELATIONSHIP_OBJECT_ROUTE, "*", stringlist, DomainConstants.EMPTY_STRINGLIST, true, false, (short)1, DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
                      Map map1 = domainobject1.getInfo(context, stringlist);
                      maplist.add(0, map1);
                      Iterator iterator = maplist.iterator();
                      while(iterator.hasNext()){
                              Map map2 = (Map)iterator.next();
                              Object obj1 = null;
                              Object obj2 = null;
                              Object obj3 = null;
                              Object obj4 = map2.get("grantor");
                              if((obj4 instanceof String) || obj4 == null){
                                      if(obj4 == null || "".equals(obj4))
                                              continue;
                                      obj1 = new ArrayList(1);
                                      obj2 = new ArrayList(1);
                                      obj3 = new ArrayList(1);
                                      ((java.util.List) (obj1)).add(obj4);
                                      ((java.util.List) (obj2)).add(map2.get("grantee"));
                                      ((java.util.List) (obj3)).add(map2.get("granteeaccess"));
                              }else{
                                      obj1 = (java.util.List)map2.get("grantor");
                                      obj2 = (java.util.List)map2.get("grantee");
                                      obj3 = (java.util.List)map2.get("granteeaccess");
                              }

                              String objId = (String)map2.get("id");
                              BusinessObject doc=new BusinessObject(objId);
                              doc.open(context);
                              if (doc.getTypeName().equals("Document")){

                                      for(int i = 0; i < ((java.util.List) (obj1)).size(); i++) {
                                              String strGrantee = (String)((java.util.List) (obj2)).get(i);

                                              if(strGrantee.equals(personName)) {
                                                      String strGrantor = (String)((java.util.List) (obj1)).get(i);

                                                      if(strGrantor.equals(DomainConstants.PERSON_ROUTE_DELEGATION_GRANTOR)) {
                                                      try {

                                                              ContextUtil.pushContext(context, DomainConstants.PERSON_ROUTE_DELEGATION_GRANTOR, null, context.getVault().getName());
                                                              String MQLstmt = "modify bus " + objId + " revoke grantor '" + strGrantor + "' grantee '" + personName + "';";
                                                              String MQLret = MqlUtil.mqlCommand(context, MQLstmt, false);

                                                              } catch(Exception exception4){
                                                                      throw new FrameworkException(exception4);
                                                              }
                                                              finally{
                                                                      ContextUtil.popContext(context);
                                                              }
                                                      }
                                              }
                                      }
                              }
                              doc.close(context);
                      }
              }
              } catch(Exception ex)
              {
                 
                  ex.printStackTrace();
                     
              }
	
	 ContextUtil.commitTransaction(context);
	}catch(Exception e) {
		 e.printStackTrace();
		 ContextUtil.abortTransaction(context);
	     }
	 }catch(Exception e) {
		 e.printStackTrace();
	 }
	 
	}
 /**
  * 
  * @param context
  * @param route
  * @param currTaskSeq
  * @return
  * @throws Exception
  */
	 public boolean shouldSetNextTaskDueDate(Context context, Route route, String currTaskSeq) throws Exception{
 	     boolean retVal =false;
		 StringList objSelect=new StringList();
		 objSelect.add(DomainObject.SELECT_ID);
		 objSelect.add("attribute["+DomainObject.ATTRIBUTE_ROUTE_NODE_ID+"]");
		 objSelect.add(DomainObject.SELECT_CURRENT);
		 // get all Inbox Tasks
		 MapList taskMapList = route.getRelatedObjects(context,
		                                Route.RELATIONSHIP_ROUTE_TASK, //String relPattern
		                                Route.TYPE_INBOX_TASK,         //String typePattern
		                                objSelect,                     //StringList objectSelects,
		                                null,                          //StringList relationshipSelects,
		                                true,                          //boolean getTo,
		                                false,                         //boolean getFrom,
		                                (short)1,                      //short recurseToLevel,
		                                "",                           //String objectWhere,
		                                "",                           //String relationshipWhere,
		                                null,                        //Pattern includeType,
		                                null,                        //Pattern includeRelationship,
		                                null);                       //Map includeMap

		 // for getting all Same sequence tasks which are incomplete
		  MapList incompleteSameSeqMapList=new MapList();
		  Iterator it=taskMapList.iterator();
		  String state = "";
		  String relId = "";
		  String currTaskSeqStr = "";
		  DomainRelationship domRel = null;
		  Hashtable hashTable = new Hashtable();
		  while(it.hasNext()){
		   hashTable=(Hashtable)it.next();
		   state=(String)hashTable.get(DomainObject.SELECT_CURRENT);
		   relId=(String)hashTable.get("attribute["+DomainObject.ATTRIBUTE_ROUTE_NODE_ID+"]");

		         //Get the correct relId for the RouteNodeRel given the attr routeNodeId from the InboxTask.
		         relId = route.getRouteNodeRelId(context, relId);
           domRel=DomainRelationship.newInstance(context,relId);
		   currTaskSeqStr    = domRel.getAttributeValue(context, DomainObject.ATTRIBUTE_ROUTE_SEQUENCE);
		   if(currTaskSeq.equals(currTaskSeqStr) && !state.equalsIgnoreCase(DomainObject.STATE_INBOX_TASK_COMPLETE)){
		     incompleteSameSeqMapList.add(hashTable);
		   }
		  }

		  if(incompleteSameSeqMapList.size()==1 ){
		   retVal=true;
		  }
		  return retVal;
		 }
	
	 
	 public MapList getNextOrderOffsetTasks(Context context, DomainObject route, StringList relSelects, String sWhereExp) throws Exception{

		 MapList taskMapList = route.getRelatedObjects(context,
		                                Route.RELATIONSHIP_ROUTE_NODE, //String relPattern
		                                 "*",                          //String typePattern
		                                null,                         //StringList objectSelects,
		                                relSelects,                     //StringList relationshipSelects,
		                                false,                     //boolean getTo,
		                                true,                     //boolean getFrom,
		                                (short)1,                 //short recurseToLevel,
		                                "",                       //String objectWhere,
		                                sWhereExp,           //String relationshipWhere,
		                                null,                     //Pattern includeType,
		                                null,                     //Pattern includeRelationship,
		                                null);                    //Map includeMap


		 return taskMapList;

		 }
	 
	 
	 public KeyPair extractKeysFromStream(String certificateName) throws Exception{
		Security.addProvider(new BouncyCastleProvider());
		KeyPair keyPair = null;
		InputStream encryptionCertificate = new FileInputStream(certificateName);
		InputStreamReader reader = new InputStreamReader(encryptionCertificate);

		PEMParser pemParser = new PEMParser(reader);

		Object object = null;

		try {
			object = pemParser.readObject();
            PEMDecryptorProvider decProv = new JcePEMDecryptorProviderBuilder().build("".toCharArray());
             
			JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");

			if ((object instanceof PEMEncryptedKeyPair)) {
				keyPair = converter.getKeyPair(((PEMEncryptedKeyPair) object).decryptKeyPair(decProv));
			} else {
				keyPair = converter.getKeyPair((PEMKeyPair) object);
			}

		} catch (Exception e) {

			e.printStackTrace();

			try {
				pemParser.close();
			} catch (Exception ex) {
				Logger.getLogger(KeyExtractor.class.getName()).log(Level.SEVERE, null, ex);
			}
		} finally {
			try {
				pemParser.close();
			} catch (Exception ex) {
				Logger.getLogger(KeyExtractor.class.getName()).log(Level.SEVERE, null, ex);
			}
		}

		return keyPair;
	}
}
