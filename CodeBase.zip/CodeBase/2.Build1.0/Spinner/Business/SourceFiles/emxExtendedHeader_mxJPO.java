/*
 * * Copyright (c) 1992-2018 Dassault Systemes.
 * All Rights Reserved.
 */
import matrix.db.*;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.XSSUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.framework.ui.UICache;
import com.matrixone.apps.framework.ui.UIComponent;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UIUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;
import matrix.db.Access;
import matrix.db.BusinessObject;
import matrix.db.Command;
import matrix.db.Context;
import matrix.db.IconMail;
import matrix.db.IconMailItr;
import matrix.db.IconMailList;

import matrix.db.JPO;
import matrix.db.MenuObject;
import matrix.db.Policy;
import matrix.db.State;
import matrix.db.StateList;
import matrix.dbutil.SelectSetting;
import matrix.util.Pattern;
import matrix.util.StringList;

import com.matrixone.apps.cache.CacheManager;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainSymbolicConstants;

/**
 * This jpo is used to show the content of extended page header
 * in object details page
 * @author g1f
 *
 */
public class emxExtendedHeader_mxJPO extends emxExtendedHeaderBase_mxJPO{
    
        
    /**
     * @param context <code>matrix.db.Context</code>
     * @param args
     * @throws Exception
     */
    public emxExtendedHeader_mxJPO(Context context, String[] args) throws Exception {
    	super(context, args);
    }       
	
	public StringBuilder getHeaderContents(Context context, String[] args) throws Exception {

        StringBuilder sbResults = new StringBuilder();
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
        String sLanguage = (String)programMap.get("language");
        String sOID = (String) programMap.get("objectId");
        String documentDropRelationship	= (String) programMap.get("documentDropRelationship");
        String documentCommand		= (String) programMap.get("documentCommand");
        String showStatesInHeader	= (String) programMap.get("showStatesInHeader");
        String imageDropRelationship	= (String) programMap.get("imageDropRelationship");
        String timeZone=(String)programMap.get("timeZone");
        String imageManagerToolbar = (String)programMap.get("imageManagerToolbar");
        String imageUploadCommand = (String)programMap.get("imageUploadCommand");

		String strNoImages = EnoviaResourceBundle.getProperty(context, "emxFramework.DnD.NoImages");	
        String strNoUploadKind = EnoviaResourceBundle.getProperty(context, "emxFramework.DnD.NoUploadKind");	
        String strNoUploadType = EnoviaResourceBundle.getProperty(context, "emxFramework.DnD.NoUploadType");
        
        List<String> lNoImages=Arrays.asList(strNoImages.split(","));                
        List<String> lNoUploadKind =Arrays.asList(strNoUploadKind.split(","));       
        List<String> lNoUploadType = Arrays.asList(strNoUploadType.split(","));

        if(UIUtil.isNullOrEmpty(documentDropRelationship)){
        	documentDropRelationship = "Reference Document";
        }
        if( UIUtil.isNullOrEmpty(documentCommand)){
        	documentCommand = "APPReferenceDocumentsTreeCategory";
        }

        String sMCSURL              = (String) programMap.get("MCSURL");
        DomainObject dObject        = new DomainObject(sOID);
        StringList selBUS           = new StringList();

        StringBuilder sbContentImage        = new StringBuilder();
        StringBuilder sbContentName         = new StringBuilder();
        StringBuilder sbContentDescription  = new StringBuilder();
        StringBuilder sbContentDetails      = new StringBuilder();
        StringBuilder sbContentDocuments    = new StringBuilder();
        StringBuilder sbIcon                = new StringBuilder();
        StringBuilder sbRevision            = new StringBuilder();
        StringBuilder sbRevisionTitle       = new StringBuilder();
		StringBuilder sbHigherRevisionExists = new StringBuilder();
        StringBuilder sbContentLifeCycle    = new StringBuilder();

        String sLinkPrefix          = "onClick=\"showNonModalDialog('../common/emxTree.jsp?mode=insert";
        String sLinkSuffix          = "', '950', '680', true, 'Large');\"";

        String sLabelHigherRevision = EnoviaResourceBundle.getProperty(context, "Components", "emxComponents.EngineeringChange.HigherRevisionExists", sLanguage);
        String sLabelOwner          = EnoviaResourceBundle.getProperty(context, "Framework", "emxFramework.Basic.Owner", sLanguage);
        String sLabelModified       = EnoviaResourceBundle.getProperty(context, "Framework", "emxFramework.Basic.Modified", sLanguage);

        selBUS.add(DomainConstants.SELECT_TYPE);
        selBUS.add("type.kindof");
        selBUS.add("type.kindof["+DomainConstants.TYPE_TASK_MANAGEMENT+"]");
        selBUS.add(DomainConstants.SELECT_NAME);
        selBUS.add(DomainConstants.SELECT_REVISION);
        selBUS.add(DomainConstants.SELECT_CURRENT);
        selBUS.add(DomainConstants.SELECT_DESCRIPTION);
        selBUS.add(DomainConstants.SELECT_MODIFIED);
        selBUS.add(DomainConstants.SELECT_OWNER);
        selBUS.add("last");
        selBUS.add("attribute["+PropertyUtil.getSchemaProperty(context,DomainSymbolicConstants.SYMBOLIC_attribute_MarketingName)+"]");
        selBUS.add("attribute["+PropertyUtil.getSchemaProperty(context,DomainSymbolicConstants.SYMBOLIC_attribute_DisplayName)+"]");
        selBUS.add("attribute[" + DomainConstants.ATTRIBUTE_TITLE + "]");
        selBUS.add(DomainConstants.SELECT_HAS_FROMCONNECT_ACCESS);
        selBUS.add(DomainConstants.SELECT_HAS_CHECKIN_ACCESS);
        selBUS.add(DomainConstants.SELECT_HAS_MODIFY_ACCESS);
	 	selBUS.add("project");
        Map mData 		= dObject.getInfo(context, selBUS);
        String sType 		= (String)mData.get(DomainConstants.SELECT_TYPE);
        String sKind 		= (String)mData.get("type.kindof");
        String sKindTask	= (String)mData.get("type.kindof["+DomainConstants.TYPE_TASK_MANAGEMENT+"]");
        String sName 		= (String)mData.get(DomainConstants.SELECT_NAME);
        String sRevision 	= (String)mData.get(DomainConstants.SELECT_REVISION);
        String sDescription     = (String)mData.get(DomainConstants.SELECT_DESCRIPTION);
        String sModified        = (String)mData.get(DomainConstants.SELECT_MODIFIED);
        String sOwner = PersonUtil.getFullName(context, (String)mData.get(DomainConstants.SELECT_OWNER));
        String sLast 		= (String)mData.get("last");
        String fromConnect 		= (String)mData.get(DomainConstants.SELECT_HAS_FROMCONNECT_ACCESS);
        String checkInAccess	= (String)mData.get(DomainConstants.SELECT_HAS_CHECKIN_ACCESS);
        String modifyAccess  = (String)mData.get(DomainConstants.SELECT_HAS_MODIFY_ACCESS);
		
       // IR-511566: we show any one of these attribute "Title", "Display Name" or "Marketing Name", which will not be null in the sequence.
		String sMarketingName 	= (String)mData.get("attribute[" + DomainConstants.ATTRIBUTE_TITLE + "]");
        if(UIUtil.isNullOrEmpty(sMarketingName)) {
        	sMarketingName	= (String)mData.get("attribute["+PropertyUtil.getSchemaProperty(context,DomainSymbolicConstants.SYMBOLIC_attribute_DisplayName)+"]");
        	if(UIUtil.isNullOrEmpty(sMarketingName)){
				sMarketingName  = (String)mData.get("attribute["+PropertyUtil.getSchemaProperty(context,DomainSymbolicConstants.SYMBOLIC_attribute_MarketingName)+"]");
        	}
        }

        //adding additional params required for genHeaderImage()
        programMap.put("bFromJSP", false);
        
        if((lNoImages.indexOf(sKind) == -1)) {
                sbContentImage.append("<div class=\"headerImage\" id=\"divExtendedHeaderImage\">");
                sbContentImage.append("<span id=\"extendedHeaderImage\">").append(genHeaderImage(context, programMap)).append("</span>");
                sbContentImage.append("</div>");
        }

        // REVISION details
            if(!sRevision.equals("-")) {
                if(!sRevision.equals(" ")) {
                    if(!sRevision.equals("")) {
                        sbRevision.append(" (").append(sRevision);
                        sbRevisionTitle.append(" (").append(sRevision);
                        if(!sLast.equalsIgnoreCase(sRevision)) {
                            BusinessObject boLast   = dObject.getLastRevision(context);
                            String sOIDLast         = boLast.getObjectId();
                            sbHigherRevisionExists.append(" <img style='vertical-align:middle;height:16px;cursor:pointer;' src='../common/images/iconSmallStatusAlert.gif' ");
                            sbHigherRevisionExists.append(sLinkPrefix);
                            sbHigherRevisionExists.append("&objectId=").append(XSSUtil.encodeForURL(context, sOIDLast));
                            sbHigherRevisionExists.append(sLinkSuffix);
                            sbHigherRevisionExists.append(" title='").append(sLabelHigherRevision).append(" : ").append(XSSUtil.encodeForHTMLAttribute(context,sLast)).append("'> ");
                        }
                        sbRevision.append(")");
                        sbRevisionTitle.append(")");
                    }
                }
            }

        // NAME
        sbIcon.append("  <img class='typeIcon' ");
        sbIcon.append(" src='../common/images/").append(UINavigatorUtil.getTypeIconProperty(context, sType)).append("' />");
        
        if(DomainConstants.TYPE_CONTROLLED_FOLDER.equalsIgnoreCase(sType)){
        	
        	sName = sMarketingName;
        	sMarketingName = DomainConstants.EMPTY_STRING;
        }
        sbContentName.append("<span title='"+ XSSUtil.encodeForHTMLAttribute(context,sName)+"' class=\"extendedHeader name\">").append(XSSUtil.encodeForHTML(context,sName)).append("</span>");
        if(UIUtil.isNotNullAndNotEmpty(sMarketingName)) {
            sbContentName.append("<span title='"+XSSUtil.encodeForHTMLAttribute(context,sMarketingName)+"' class=\"extendedHeader marketing-name\">");
            sbContentName.append(XSSUtil.encodeForHTML(context,sMarketingName));
            sbContentName.append("</span>");

        }
        if(UINavigatorUtil.isMobile(context)){
        	sbContentName.append("<br>");
        }
        String typeName = EnoviaResourceBundle.getTypeI18NString(context, sType, sLanguage);
        String typeRevisionTooltip = typeName+ sbRevisionTitle.toString();
        //sbContentName.append("<span class=\"extendedHeader\">").append(sbIcon);
        //sbContentName.append("<span class=\"extendedHeader type-name\" title='"+XSSUtil.encodeForHTMLAttribute(context,typeRevisionTooltip) +"'>").append(typeName).append(sbRevision.toString());
        //sbContentName.append("</span>");
		if(sbHigherRevisionExists.length() != 0) {
            sbContentName.append("<span class=\"extendedHeader higher-revision-exists\">").append(sbHigherRevisionExists.toString()).append("</span>");
		}
        sbContentName.append(genHeaderAlerts(context, sOID, sLanguage, false));
		// to not show the lifecycle in header on the basis of setting
        if(!"hide".equalsIgnoreCase(showStatesInHeader)){
        sbContentLifeCycle.append("<span id=\"extendedHeaderStatus\" class=\"extendedHeader state\">");

        if(!UINavigatorUtil.isMobile(context)){
        	sbContentLifeCycle.append(genHeaderStatus(context, sOID, sLanguage, false)).append("</span>");
        }else{
        	sbContentLifeCycle.append(genHeaderStatus(context, sOID, sLanguage, false)).append("</span>");
        }
        }
        // DESCRIPTION
        if(null != sDescription) { if(!"".equals(sDescription)) {
            sbContentDescription.append("<div class=\"headerContent\" id=\"divExtendedHeaderDescription\" ");
            String sText = sDescription.replaceAll("\n", "<br/>");

            if(sText.length() > 106) {
                sbContentDescription.append(" title='").append(XSSUtil.encodeForHTMLAttribute(context,sDescription)).append("'");
            }

            sbContentDescription.append("><span class=\"extendedHeader content\">");
            sbContentDescription.append(XSSUtil.encodeForHTML(context,sText,false));
            sbContentDescription.append("</span></div>");
        }}

	if(!UINavigatorUtil.isMobile(context)){
        sbContentDetails.append(sbContentLifeCycle.toString());
        sbContentDetails.append("<span class=\"extendedHeader\">").append(sLabelOwner).append(" : " ).append(XSSUtil.encodeForHTML(context,sOwner)).append("</span>");
        sbContentDetails.append("<span id=\"extendedHeaderModified\" class=\"extendedHeader\">").append(sLabelModified).append(" : " );
        sbContentDetails.append("<a onclick=\"javascript:showPageHeaderContent('");

        // when user click on last modified link, it will open OOTB history page by executing any one of below available command in
        // category menu.
        String historyCommands = "'AEFHistory','APPDocumentHistory','APPRouteHistory'";
        String strUrl = "../common/emxHistory.jsp?HistoryMode=CurrentRevision&Header=emxFramework.Common.History&objectId=" + sOID;
        sbContentDetails.append(strUrl +"','',new Array("+ historyCommands +"));\"");
        sbContentDetails.append(" >");
        double iClientTimeOffset = (new Double(timeZone)).doubleValue();
        int iDateFormat = PersonUtil.getPreferenceDateFormatValue(context);
        boolean bDisplayTime = true; //PersonUtil.getPreferenceDisplayTimeValue(context);
        sModified = eMatrixDateFormat.getFormattedDisplayDateTime(context,sModified, bDisplayTime, iDateFormat, iClientTimeOffset, new Locale(context.getSession().getLanguage()));
        sbContentDetails.append(XSSUtil.encodeForHTML(context,sModified));
        sbContentDetails.append("</a></span>");
        }

        if(lNoUploadKind.indexOf(sKind) == -1) {
            if(lNoUploadType.indexOf(sType) == -1) {
		        if("true".equalsIgnoreCase(fromConnect) && "true".equalsIgnoreCase(checkInAccess) && canAttachDocument(context, sOID, sType, documentDropRelationship, sKind, sKindTask)){
		        		sbContentDocuments.append(genHeaderDocuments(context, sOID, documentDropRelationship, documentCommand, sLanguage, false, timeZone));
		        }
            }
        }

        // FINAL TABLE
        if(!UINavigatorUtil.isMobile(context)){
        sbResults.append("<div id=\"divExtendedHeaderContent\" o=\"").append(sOID).append("\" dr=\"").append(XSSUtil.encodeForHTML(context,documentDropRelationship)).append("\" dc=\"")
		.append(XSSUtil.encodeForHTML(context,documentCommand)).append("\" showStates=\"").append(XSSUtil.encodeForHTML(context, showStatesInHeader)).append("\" idr=\"").append(XSSUtil.encodeForHTML(context,imageDropRelationship)).append("\" mcs=\"").append(XSSUtil.encodeForHTML(context,sMCSURL)).append("\">");

        sbResults.append(sbContentImage.toString());
        sbResults.append("<div class=\"headerContent\" id=\"divExtendedHeaderName\">").append(sbContentName.toString()).append("</div>");
        sbResults.append(sbContentDescription.toString());
        sbResults.append("<div class=\"headerContent\" id=\"divExtendedHeaderDetails\">").append(sbContentDetails.toString()).append("</div>");
        if(sbContentDocuments.length() > 0) {
            sbResults.append("<div class=\"headerContent\" id=\"divExtendedHeaderDocuments\" >").append(sbContentDocuments.toString()).append("</div>");
        }
        }else{
        	sbResults.append("<div id=\"divExtendedHeaderContent\" o=\"").append(sOID).append("\" dr=\"").append(XSSUtil.encodeForHTML(context,documentDropRelationship)).append("\" dc=\"")
        					.append(XSSUtil.encodeForHTML(context,documentCommand)).append("\" showStates=\"").append(XSSUtil.encodeForHTML(context,showStatesInHeader)).append("\" idr=\"").append(XSSUtil.encodeForHTML(context,imageDropRelationship)).append("\" mcs=\"").append(XSSUtil.encodeForHTML(context,sMCSURL)).append("\">");
            sbResults.append(sbContentImage.toString());
            if(sbContentDocuments.length() > 0) {
            	sbResults.append("<div class=\"headerContent\" id=\"divExtendedHeaderName\">").append(sbContentName.toString()).append(sbContentDocuments.toString()).append(sbContentLifeCycle.toString()).append("</div>");
            }else{
            	sbResults.append("<div class=\"headerContent\" id=\"divExtendedHeaderName\">").append(sbContentName.toString()).append(sbContentLifeCycle.toString()).append("</div>");
            }
        }

        sbResults.append("</div>");
	 String personCollabSpaceName = PersonUtil.getActiveProject(context);
	 String collabspace = (String)mData.get("project");
	 
	 String personCollabSpaceTitle = "";
	 if(!UIUtil.isNullOrEmpty(collabspace) && !personCollabSpaceName.equals(collabspace)){
		 personCollabSpaceTitle = PersonUtil.getProjectTitle(context, collabspace);
		 personCollabSpaceTitle = UIUtil.isNotNullAndNotEmpty(personCollabSpaceTitle) ? personCollabSpaceTitle : collabspace;

		 sbResults.append("<div id='collab-space-id' class='header full'>");
		 sbResults.append(personCollabSpaceTitle);
		 sbResults.append("</div>");
	 }
     sbResults.append(genHeaderNavigationImage(context, sLanguage, sOID, documentDropRelationship,documentCommand, showStatesInHeader, imageDropRelationship, sMCSURL, collabspace, imageManagerToolbar, imageUploadCommand, personCollabSpaceName,personCollabSpaceTitle));
     return sbResults;

    }
	
	private String genHeaderAlerts(Context context, String sOID, String sLanguage, Boolean bFromJSP) throws Exception {

        StringBuilder sbResult      = new StringBuilder();
        StringList selAlerts        = new StringList();
        DomainObject dObject        = new DomainObject(sOID);

        String sStyleHighlightIcon  = UINavigatorUtil.isMobile(context) ? "style='height:16px;'" : "style='height:11px;'";

        selAlerts.add(DomainConstants.SELECT_ID);

        String relIssue = PropertyUtil.getSchemaProperty(context,DomainSymbolicConstants.SYMBOLIC_relationship_Issue);
        String typeIssue = PropertyUtil.getSchemaProperty(context,DomainSymbolicConstants.SYMBOLIC_type_Issue);
        // Route can be connected to object with multiple relationships.
        Pattern relPattern         = null;
        relPattern  = new Pattern(DomainConstants.RELATIONSHIP_ROUTE_SCOPE);
        relPattern.addPattern(DomainObject.RELATIONSHIP_OBJECT_ROUTE);
        relPattern.addPattern(DomainObject.RELATIONSHIP_ROUTE_TASK);

        String mlPendingRoutesWhere = "";
        String  activeFilter = EnoviaResourceBundle.getProperty(context,"emxComponentsRoutes.Filter.Active");
        
        
        if(UIUtil.isNotNullAndNotEmpty(activeFilter))
        {
            StringTokenizer tokenizer=new StringTokenizer(activeFilter,",");
            while(tokenizer.hasMoreTokens())
            {
                String nextFilter=tokenizer.nextToken();
                if(!"".equals(mlPendingRoutesWhere))
                {
                	mlPendingRoutesWhere += "||";
                }
                mlPendingRoutesWhere += "attribute[Route Status] == \"" + nextFilter + "\"";
            }
        }
        
        MapList mlPendingIssues     = dObject.getRelatedObjects(context, relIssue, typeIssue, selAlerts, null, true,  false, (short)1, "current != 'Closed'", "", 0);
        MapList mlPendingChanges    = dObject.getRelatedObjects(context, DomainConstants.RELATIONSHIP_EC_AFFECTED_ITEM, "Change", selAlerts, null, true,  false, (short)1, "(current != 'Complete') && (current != 'Close') && (current != 'Reject')", "", 0);
        MapList mlPendingRoutes     = dObject.getRelatedObjects(context, relPattern.getPattern(), DomainConstants.TYPE_ROUTE,  selAlerts, null, false, true,  (short)1, mlPendingRoutesWhere, "", 0);

        // this string will contain OOTB categories command for Issues,Changes,Routes
        String categoryCommands = "";

            if(mlPendingIssues.size() > 0) {
            	categoryCommands = "'ContextIssueListPage'";
            	sbResult.append("<span id='spanExtendedHeaderAlerts' class='extendedHeader counter'>");
                String sAlertIssues = EnoviaResourceBundle.getProperty(context, "Framework", "emxFramework.String.ExistingIssue", sLanguage);
                sbResult.append("<a ").append("title='").append(sAlertIssues).append("'");

                String sOIDIssue = "";
                if(mlPendingIssues.size() == 1) {
                    Map mIssue = (Map)mlPendingIssues.get(0);
                    sOIDIssue = (String)mIssue.get("id");
                }
                String strUrl = "../common/emxIndentedTable.jsp?selection=multiple&freezePane=Name&table=IssueList&toolbar=ContextIssueToolBar&program=emxCommonIssue:getActiveIssues&objectId="+ XSSUtil.encodeForURL(context,sOID);
                sbResult.append(" onclick=\"javascript:showPageHeaderContent('");
                sbResult.append(strUrl +"', '");
                sbResult.append(XSSUtil.encodeForJavaScript(context,sOIDIssue) +"',new Array("+categoryCommands+"));\"");
                sbResult.append(">").append(mlPendingIssues.size());
                sbResult.append("<img ").append(sStyleHighlightIcon).append(" src='../common/images/iconSmallIssue.gif'/></a>");
                sbResult.append("</span>");
            }

            if(mlPendingChanges.size() > 0) {
            	categoryCommands = "'CommonEngineeringChangeTreeCategory'";
            	sbResult.append("<span id='spanExtendedHeaderAlerts' class='extendedHeader counter'>");
                String sAlertChanges = EnoviaResourceBundle.getProperty(context, "Framework", "emxFramework.String.ExistingChange", sLanguage);
                sbResult.append(" <a ").append("title='").append(sAlertChanges).append("'");
                String sOIDChange = "";
                if(mlPendingChanges.size() == 1) {
                    Map mIssue = (Map)mlPendingChanges.get(0);
                    sOIDChange = (String)mIssue.get("id");
                }
                String strUrl = "../common/emxIndentedTable.jsp?table=APPDashboardEC&toolbar=APPObjectECListToolBar&program=emxCommonEngineeringChange:getObjectECList&objectId="+ XSSUtil.encodeForURL(context,sOID);
                sbResult.append(" onclick=\"javascript:showPageHeaderContent('");
                sbResult.append(strUrl +"', '");
                sbResult.append(XSSUtil.encodeForJavaScript(context,sOIDChange) +"',new Array("+categoryCommands+"));\"");

                sbResult.append(">").append(mlPendingChanges.size());
                sbResult.append("<img ").append(sStyleHighlightIcon).append(" src='../common/images/iconSmallECR.gif'/></a>");
                sbResult.append("</span>");
            }

            if(mlPendingRoutes.size() > 0) {
            	categoryCommands = "'APPRoutes','TMCRoute'";
            	sbResult.append("<span id='spanExtendedHeaderAlerts' class='extendedHeader counter'>");
                String sAlertRoutes = EnoviaResourceBundle.getProperty(context, "Framework", "emxFramework.String.ExistingRoute", sLanguage);
                sbResult.append(" <a ").append("title='").append(sAlertRoutes).append("'");
                String sOIDRoute = "";
                if(mlPendingRoutes.size() == 1) {
                    Map mRoute = (Map)mlPendingRoutes.get(0);
                    sOIDRoute = (String)mRoute.get("id");
                }
                String strUrl = "../common/emxIndentedTable.jsp?table=APPRouteSummary&toolbar=APPRouteSummaryToolBar&program=emxRoute:getActiveRoutes" +
                		"&suiteKey=Components&StringResourceFileId=emxComponentsStringResource&SuiteDirectory=components&selection=multiple&freezePane=Name&objectId="+XSSUtil.encodeForURL(context, sOID);
                sbResult.append(" onclick=\"javascript:showPageHeaderContent('");
                sbResult.append(strUrl +"', '");
                sbResult.append(XSSUtil.encodeForJavaScript(context, sOIDRoute) +"',new Array("+categoryCommands+"));\"");

                sbResult.append(">").append(mlPendingRoutes.size());
                sbResult.append("<img ").append(sStyleHighlightIcon).append(" src='../common/images/iconSmallRoute.png'/></a>");
                sbResult.append("</span>");
            }

        return sbResult.toString();

    }
	
	private boolean canAttachDocument(Context context, String sOID, String sType, String sRelationship, String sKind, String sKindTask) throws Exception {

    	String command = "print relationship $1 select fromtype dump $2";
    	String fromTypes = MqlUtil.mqlCommand(context, command, true, sRelationship,",");
        StringList relFromTypes = FrameworkUtil.split(fromTypes, ",");

        if (relFromTypes.size() == 0){
            return false;
        }
        if( relFromTypes.indexOf(sType) > -1 || relFromTypes.indexOf(sKind) > -1 || "true".equalsIgnoreCase(sKindTask)){
        	return true;
        }
	    return false;
    }
	
	private static String genHeaderNavigationImage(Context context, String sLanguage, String sOID, String documentDropRelationship,
    		String documentCommand, String showStatesInHeader, String imageRelationship, String sMCSURL, String collabspace, String imageManagerToolbar, String imageUploadCommand, String personCollabSpaceName, String personCollabSpaceTitle) throws Exception {

    	StringBuffer strNavImages = new StringBuffer();
    	String sPrevious = EnoviaResourceBundle.getProperty(context, "Framework", "emxFramework.BackToolbarMenu.label",sLanguage);
    	String sNext = EnoviaResourceBundle.getProperty(context, "Framework", "emxFramework.ForwardToolbarMenu.label",sLanguage);
    	String sRefresh = EnoviaResourceBundle.getProperty(context, "Framework", "emxFramework.History.Refresh",sLanguage);
		String resizeHeader = EnoviaResourceBundle.getProperty(context, "Framework", "emxFramework.ResizeHeader.label",sLanguage);
		String appMenuLabel = EnoviaResourceBundle.getProperty(context, "Framework", "emxNavigator.UIMenu.ApplicationMenu",sLanguage);
		String notificationCountLabel = EnoviaResourceBundle.getProperty(context, "Framework", "emxNavigator.UIMenu.IconMailNotify",sLanguage);
    	String sShowNotificationIcon = EnoviaResourceBundle.getProperty(context, "emxFramework.IconMail.ShowNotificationIcon");
    	strNavImages.append("<div id=\"divExtendedHeaderNavigation\" style='margin-right: 0px; right: 1px; position: absolute;'>");
    	strNavImages.append("<table><tr>");
		if(!UIUtil.isNullOrEmpty(collabspace) && !personCollabSpaceName.equals(collabspace)){
			strNavImages.append("<td><div id='collab-space-id' class='header mini'>");
			strNavImages.append(personCollabSpaceTitle);
			strNavImages.append("</div> </td>");
		}
		if(UIUtil.isNotNullAndNotEmpty(sShowNotificationIcon) && sShowNotificationIcon.equalsIgnoreCase("True")  && !UINavigatorUtil.isCloud(context)){
		
        int numberofunreadmessages  = 0;
        String tableheadername = "<td>";
        IconMailList iconMailList = IconMail.getMail(context);
        IconMailItr iconItr      = new IconMailItr(iconMailList);
        while (iconItr.next()) {
        	IconMail iconMailObjItem  = iconItr.obj();
        	if (( iconMailObjItem.isUnRead())) {
        		tableheadername = "<td class = 'notifications-unread-yes'>";
        		numberofunreadmessages++;
           }
        }
		
		strNavImages.append(tableheadername+"<div id='iconMailNotification' class='field notifications button'><button id='buttonnotification' onclick='showIconMailDialog();' class='notifications' title='"+notificationCountLabel+"'></button></div>");
		strNavImages.append("<div id='iconMailNotification' class='field notifications-unread button'><button id='buttonnotification' onclick='showIconMailDialog();' class='notifications-unread' title='"+notificationCountLabel+"'><div class='notifications-counter'>"+numberofunreadmessages+"</div></button></div></td>");
		}
        
    	
    	strNavImages.append("<td><div class='field previous button'><a title='"+sPrevious+"' href='javascript:getTopWindow().bclist.goBack();' >");
    	strNavImages.append("<button class='previous'></button></a></div></td><td><div class='field next button'><a title='"+sNext+"' href='javascript:getTopWindow().bclist.goForward();'><button class='next'></button></a></div></td>");
    	strNavImages.append("<td><div class='field refresh button'><a title='"+sRefresh+"' onclick='javascript:refreshWholeTree(event,\""+XSSUtil.encodeForJavaScript(context, sOID)+"\",\""+XSSUtil.encodeForJavaScript(context, documentDropRelationship)+"\",\""+XSSUtil.encodeForJavaScript(context, documentCommand)+"\",\""+XSSUtil.encodeForJavaScript(context, showStatesInHeader)+"\",\""+sMCSURL +"\",\""+XSSUtil.encodeForJavaScript(context, imageRelationship)+"\",\"\",\""+XSSUtil.encodeForJavaScript(context, imageManagerToolbar)+"\",\""+XSSUtil.encodeForJavaScript(context, imageUploadCommand)+"\");'>");
    	strNavImages.append("<button class='refresh'></button></a></div></td>");
		strNavImages.append("<td><div class='field resize-Xheader button'><a id='resize-Xheader-Link' title='"+resizeHeader+"' onclick='toggleExtendedPageHeader();'><button class='resize-Xheader'></button></a></div></td>");
    	strNavImages.append("</tr></table>");
    	strNavImages.append("</div>");
    	return strNavImages.toString();
    }
    
}
