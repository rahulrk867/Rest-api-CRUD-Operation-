import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.LicenseUtil;
import matrix.util.StringList;
import matrix.db.MQLCommand;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.util.Map;
import java.util.Iterator;
import java.util.Date;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.io.*;
import java.util.LinkedHashMap;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.util.XMLResourceDescriptor;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.apache.poi.util.Units;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.math.BigDecimal;

public  class WMSAMBDownloadItems_mxJPO extends WMSConstants_mxJPO{
	//RELATIONSHIP
	public static final String RELATIONSHIP_WMSWO_ABSTRACTMBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");
	public static final String RELATIONSHIP_WMSWORKORDER_CONTRACTOR = PropertyUtil.getSchemaProperty("relationship_PRBWorkorderContractor");
	public static final String RELATIONSHIP_WMSABSTRACT_PAYMENTITEMS = PropertyUtil.getSchemaProperty("relationship_WMSAbstractMBEPaymentItems");
	//ATTRIBUTE
	public static final String ATTRIBUTE_WMS_PONUMBER = PropertyUtil.getSchemaProperty("attribute_WMSPONumber");
	public static final String ATTRIBUTE_WMSWORKORDER_DATE = PropertyUtil.getSchemaProperty("attribute_WMSWorkOrderDate");
	public static final String ATTRIBUTE_SEQUENCE_ORDER = PropertyUtil.getSchemaProperty("attribute_SequenceOrder");
	public static final String ATTRIBUTE_WMSPAYMENTSCHEDULE_SEQUENCE = PropertyUtil.getSchemaProperty("attribute_WMSPaymentScheduleSequence");
	public static final String ATTRIBUTE_TITLE = PropertyUtil.getSchemaProperty("attribute_Title");
	public static final String ATTRIBUTE_WMSPERCENTAGE_WEIGHTAGE = PropertyUtil.getSchemaProperty("attribute_WMSPercentageOfWeightage");
	public static final String ATTRIBUTE_WMSPAYMENTITEM_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSPaymentItemAmount");
	public static final String ATTRIBUTE_WMSPERCENTAGECOMPLETETILLDATE = PropertyUtil.getSchemaProperty("attribute_WMSPercentageCompleteTillDate");
	public static final String ATTRIBUTE_WMSMBEQUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSMBEActivityQuantity");
	public static final String ATTRIBUTE_WMSREMARKS = PropertyUtil.getSchemaProperty("attribute_WMSRemarks");
	//TYPE
	public static final String TYPE_WMSABSTRACTMEASURMENTBOOKENTRY = PropertyUtil.getSchemaProperty("type_WMSAbstractMeasurementBookEntry");
	public static final String TYPE_WMSPAYMENTITEM = PropertyUtil.getSchemaProperty("type_WMSPaymentItem");
	public static final String ATTRIBUTE_WMS_VALUE_OF_CONTRACT = PropertyUtil.getSchemaProperty("attribute_WMSValueOfContract");
	public static final String ATTRIBUTE_WMSECVIBM_VALUE = PropertyUtil.getSchemaProperty("attribute_WMSECVIBM");
	public static final String RELATIONSHIP_WORKORDER_ABSTRACT_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOAbstractMBE");
	public static final String ATTRIBUTE_WMS_WORK_ORDER_TITLE = PropertyUtil.getSchemaProperty("attribute_WMSWorkorderTitle");
	public static final String  ATTRIBUTE_WMS_TIME_ALLOWED = PropertyUtil.getSchemaProperty("attribute_WMSTimeAllowed");
	public static final String  ATTRIBUTE_WMS_DEVIATION_QUANTITY = PropertyUtil.getSchemaProperty("attribute_WMSDeviationQuantity");
	public static final String ATTRIBUTE_WMS_TOTAL_QUANTITY =  PropertyUtil.getSchemaProperty("attribute_WMSTotalQuantity");
	public static final String RELATIONSHIP_BILL_OF_QUANTITY = PropertyUtil.getSchemaProperty("relationship_WMSMeasurementBookItems");
	public static final String TYPE_WMS_SEGMENT = PropertyUtil.getSchemaProperty("type_WMSSegment");
	public static final String TYPE_WMS_MEASUREMENT_TASK = PropertyUtil.getSchemaProperty("type_WMSMeasurementTask");
	public static final String ATTRIBUTE_WMS_BILL_K_VALUE = PropertyUtil.getSchemaProperty("attribute_WMSBillKValue");
	public static final String TYPE_WMS_MEASUREMENT_BOOK = PropertyUtil.getSchemaProperty("type_WMSMeasurementBook"); 
	//Added by Ravi
	String strMode=DomainConstants.EMPTY_STRING;
	String strInboxTaskId=DomainConstants.EMPTY_STRING;
	
	Map<String, String> mapPayable = new HashMap<>();
	Map<String, String> mapTechDeduction = new HashMap<>();
	Map<String, String> mapTechRelease = new HashMap<>();
	
	String strGenMode = DomainConstants.EMPTY_STRING;
	
	
	public WMSAMBDownloadItems_mxJPO(Context context, String[] args) throws Exception
	{
		super(context,args);
	}

	
   	public void writeFiles(Context context , String [] args) throws Exception
	{
	try {
			HashMap programMap      = (HashMap)JPO.unpackArgs(args);
			String strObjID         = (String) programMap.get("objectId");
			strGenMode         = (String) programMap.get("GenMode");
			if(programMap.containsKey("mode")) {
				strMode=(String)programMap.get("mode");
				strInboxTaskId=(String)programMap.get("inboxTaskId");
			}
			generateForm26(context ,strObjID );		
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
		
	public void generateForm26(Context context  , String strObjID) throws Exception
	{
		String[] args1 = {strObjID};
		String initargs[] = {};
		
		String strHeader = DomainConstants.EMPTY_STRING;
		Map packArgs=new HashMap();		
		packArgs.put("objectId", strObjID); 
		Map mBillDetails = (Map)JPO.invoke(context,"WMSAbstractMeasurementBookEntry",null,"getBillDetailsForBill",JPO.packArgs(packArgs),MapList.class);
		MapList mlCertificates = (MapList)JPO.invoke(context,"WMSBillCertificates",null,"getCertifiatesConntected",JPO.packArgs(packArgs),MapList.class);
		
		String strAdvance = DomainConstants.EMPTY_STRING;
		String strWithHeld = DomainConstants.EMPTY_STRING;
		String strWithHeldRelease = DomainConstants.EMPTY_STRING;
		String strRetentionRelease = DomainConstants.EMPTY_STRING;
		String strRecovery = DomainConstants.EMPTY_STRING;
		String strRecoveryInterest = DomainConstants.EMPTY_STRING;
		String strOtherDeductionAmount = DomainConstants.EMPTY_STRING;
		String strOtherReleaseAmount = DomainConstants.EMPTY_STRING;
		Map<String,String> mOtherDeduction = new HashMap<String,String>();		
		Map<String,String> mOtherRelease = new HashMap<String,String>();			
		if(mBillDetails != null){
			strAdvance = (String)mBillDetails.get("Advances");
			strWithHeld = (String)mBillDetails.get("WithHeld");			
			strWithHeldRelease = (String)mBillDetails.get("WithHeldRelease");			
			strRetentionRelease = (String)mBillDetails.get("RetentionRelease");			
			strRecovery = (String)mBillDetails.get("Recovery");			
			strRecoveryInterest = (String)mBillDetails.get("RecoveryInterest");	
			strOtherDeductionAmount = (String)mBillDetails.get("OtherDeductionAmount");	
			strOtherReleaseAmount = (String)mBillDetails.get("OtherReleaseAmount");	
			mOtherDeduction = (HashMap)mBillDetails.get("OtherDeduction");	
			mOtherRelease = (HashMap)mBillDetails.get("OtherRelease");	
		}
		
		if(UIUtil.isNotNullAndNotEmpty(strWithHeldRelease) && Double.valueOf(strWithHeldRelease)>0)
			mOtherRelease.put("Withheld Release",strWithHeldRelease);
		if(UIUtil.isNotNullAndNotEmpty(strWithHeld) && Double.valueOf(strWithHeld)>0)
			mOtherDeduction.put("Withheld",strWithHeld);
		if(UIUtil.isNotNullAndNotEmpty(strRecoveryInterest) && Double.valueOf(strRecoveryInterest)>0)
			mOtherDeduction.put("Recovery Interest",strRecoveryInterest);
		getPayableInCurrentBill(context,strObjID);
		getTDInCurrentBill(context,strObjID);
		getTDReleaseInCurrentBill(context,strObjID);
		String strTransPath = context.createWorkspace();
		String xmlSourceFileName = "Form26ItemRateSource.xml";

		String xmlFilePath = strTransPath + File.separator+xmlSourceFileName;
		DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();

		DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();

		Document document = documentBuilder.newDocument();
		DecimalFormat decFor = new DecimalFormat("#.###");
		Element root = document.createElement("page");
		
		document.appendChild(root);
		
		Element heading2 = document.createElement("heading2");
		Element cashBookNo = document.createElement("cash-book-no");
		Element edate = document.createElement("date");
		Element docket = document.createElement("docket-no");
		Element projectname = document.createElement("project-name");
		Element description = document.createElement("description");
		Element contractorName = document.createElement("contractor-name");
		Element contrPan = document.createElement("pan-no");
		Element contrGST = document.createElement("gst-no");
		Element snoOfBill = document.createElement("sno-of-bill");
		Element agreement = document.createElement("agreement");
		Element agreementDate = document.createElement("agreement-date");
		Element contractValue = document.createElement("contract-value");
		Element ecvValue = document.createElement("ecv-value");
		Element tenderPremDiscount = document.createElement("discount-value");
		Element commencementWork = document.createElement("commencement-of-work");
		Element valueOfItems = document.createElement("value-of-items");
		Element valueOfMeasured = document.createElement("value-of-measured");
		Element approximateValue = document.createElement("approximate-value");
		Element deductAmount = document.createElement("deduct-amount");
		Element releaseRetetion = document.createElement("release-of-retention");
		Element balance = document.createElement("balance");
		Element detectIntermediate = document.createElement("detect-intermediate");
		Element modAdvance = document.createElement("mobilization-advance");
		Element modAdvanceRecovery = document.createElement("mobilization");
		Element intermediate = document.createElement("intermediate");
		Element gross = document.createElement("gross-amount");
		Element totalvalue = document.createElement("total-value");
		Element withHeld = document.createElement("withheld-amount");
		Element withHeldRelease = document.createElement("release-of-withheld");
		Element penalty = document.createElement("penalties-recovered");
		Element netAmount = document.createElement("net-amount");
		
		Element orgGrossUptoDate = document.createElement("gross-amount-upto-date-o");
		Element orgGrossTillDate = document.createElement("gross-amount-previous-o");
		Element orgGrossSincePrev = document.createElement("gross-amount-last-o");
		
		Element orgGrossUptoDateWithPrem = document.createElement("premium-upto-date-o");
		Element orgGrossTillDateWithPrem = document.createElement("premium-previous-o");
		Element orgGrossSincePrevWithPrem = document.createElement("premium-last-o");
				
		Element supGrossUptoDate = document.createElement("gross-amount-upto-date-s");
		Element supGrossTillDate = document.createElement("gross-amount-previous-s");
		Element supGrossSincePrev = document.createElement("gross-amount-last-s");
		
		Element supGrossUptoDateWithPrem = document.createElement("premium-upto-date-s");
		Element supGrossTillDateWithPrem = document.createElement("premium-previous-s");
		Element supGrossSincePrevWithPrem = document.createElement("premium-last-s");

		Element checkDetails = document.createElement("cheque-details");
		Element passOrder = document.createElement("rupees");
		Element retentionPercentage = document.createElement("retention-percentage");
		Element grossOriginal = document.createElement("gross-amount-o");
		Element grossOriginalPremium = document.createElement("premium-o");
		
		Element grossSupp = document.createElement("gross-amount-s");
		Element grossSuppPremium = document.createElement("premium-s");
		
		DomainObject aMObject = DomainObject.newInstance(context,strObjID);
		StringList companyDetails  = new StringList();
		companyDetails.addElement(DomainConstants.SELECT_NAME);
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.id");
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute[Address]");
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute["+ATTRIBUTE_WMS_GST_NUMBER+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute["+ATTRIBUTE_WMS_PAN_NUMBER+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.name");
		companyDetails.addElement(DomainConstants.SELECT_DESCRIPTION);
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMSRETENTION_PERCENTAGE+"]");		
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMS_PONUMBER+"]");		
		companyDetails.addElement("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMSWORKORDER_DATE+"]");
		companyDetails.addElement("attribute["+ATTRIBUTE_SEQUENCE_ORDER+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSECVIBM_VALUE+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"]");
		companyDetails.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
		companyDetails.addElement("attribute["+ATTRIBUTE_WMS_ABS_START_DATE+"]");
		companyDetails.addElement("attribute["+ATTRIBUTE_WMS_ABS_END_DATE+"]");
		companyDetails.addElement(DomainObject.SELECT_OWNER);
		companyDetails.addElement(DomainObject.SELECT_CURRENT);
		companyDetails.addElement(DomainObject.SELECT_ORIGINATED);
		companyDetails.addElement("current[Review].actual");
		companyDetails.addElement("attribute["+ATTRIBUTE_WMS_ABS_MBE_TYPE+"].value");
		
		Map companyMap = aMObject.getInfo(context,companyDetails);
		
		double dTenderTechDeduction= 0;
		double dNonTenderTechDeduction= 0;
		
		double dTenderTechDeductionRelease= 0;
		double dNonTenderTechDeductionRelease= 0;
		
		//String strName = (String) companyMap.get(DomainConstants.SELECT_NAME);
		String strName = "BillForm";
		String strOwner = (String)companyMap.get(DomainObject.SELECT_OWNER);
		String strOriginated = (String)companyMap.get(DomainObject.SELECT_ORIGINATED);
		String strState = (String)companyMap.get(DomainObject.SELECT_CURRENT);
		if("Review".equals(strState)){
			strOriginated = (String)companyMap.get("current[Review].actual");
		}
		String strValueOfContract = (String)companyMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
		//String strECVValue = (String)companyMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSECVIBM_VALUE+"]");
		String strId = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.id");
		String strAMName = (String)companyMap.get(DomainConstants.SELECT_NAME);
		String strCompanyAddress = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute[Address]");
		if(UIUtil.isNullOrEmpty(strCompanyAddress))
			strCompanyAddress = "";
		String strCompanyName = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.name");
		if(UIUtil.isNullOrEmpty(strCompanyName))
			strCompanyName = "";
		
		String strCompanyDescription = (String)companyMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
		if(UIUtil.isNullOrEmpty(strCompanyDescription))
			strCompanyDescription = "";
		String strPONumber = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMS_PONUMBER+"]");
		String strWODate = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMSWORKORDER_DATE+"]");
		String strSequenceOrder = (String)companyMap.get("attribute["+ATTRIBUTE_SEQUENCE_ORDER+"]");
		String strGSTNumber = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute["+ATTRIBUTE_WMS_GST_NUMBER+"]");
		if(UIUtil.isNullOrEmpty(strGSTNumber))
			strGSTNumber = "";
		String strPANNumber = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.to["+RELATIONSHIP_WMSWORKORDER_CONTRACTOR+"].from.attribute["+ATTRIBUTE_WMS_PAN_NUMBER+"]");
		if(UIUtil.isNullOrEmpty(strPANNumber))
			strPANNumber = "";
		String strStartDate = (String)companyMap.get("attribute["+ATTRIBUTE_WMS_ABS_START_DATE+"]");
		String strEndDate = (String)companyMap.get("attribute["+ATTRIBUTE_WMS_ABS_END_DATE+"]");
		String strRetention = (String)companyMap.get("to["+RELATIONSHIP_WMSWO_ABSTRACTMBE+"].from.attribute["+ATTRIBUTE_WMSRETENTION_PERCENTAGE+"]");
		String strDuration = (String)companyMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"]");
		
		String strDesc = (String)companyMap.get(DomainObject.SELECT_DESCRIPTION);
		String strAbsMBEType = (String)companyMap.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_TYPE+"].value");
		String strTitle = "Running Account Bill";
		if("Final".equalsIgnoreCase(strAbsMBEType)){
			strTitle = "Final Bill form";
		}
		packArgs.put("objectId", strId); 
		MapList mBGDetails = (MapList)JPO.invoke(context,"WMSWorkOrderBGs",null,"getAllBGsConnectedToWO",JPO.packArgs(packArgs),MapList.class);
		
		
		heading2.appendChild(document.createTextNode(strTitle));
		root.appendChild(heading2);
		
		description.appendChild(document.createTextNode(strDesc));
		root.appendChild(description);
		
		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
		
		String sActual = "";
		String sPrevBillAmount = "";
		String sName = "";
		String sDate = "";
		String strBillDate = "";
		if (strWODate != null && !"".equals(strWODate)){
			Date date1 = eMatrixDateFormat.getJavaDate(strWODate);
			sDate = df.format(date1);	
		}
		if (strOriginated != null && !"".equals(strOriginated)){
			Date date1 = eMatrixDateFormat.getJavaDate(strOriginated);
			strBillDate = df.format(date1);	
		}
		int iSequenceNo = Integer.parseInt(strSequenceOrder);
		
		double sTotalTenderPaid = 0;
		double sTotalNonTenderPaid = 0;
		double sTotalDeviationPaid = 0;
		
		StringList slTenderBOQList = new StringList();
		StringList slNonTenderBOQList = new StringList();
		
		double dTotalRetentionReleased = 0;
		DomainObject dObject = DomainObject.newInstance(context,strId);
		
		StringList billobjectList = new StringList();
		billobjectList.addElement(DomainConstants.SELECT_ID);
		billobjectList.addElement(DomainConstants.SELECT_NAME);
		billobjectList.addElement("current[Approved].actual");
		billobjectList.addElement("attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value");
		billobjectList.addElement("attribute["+ATTRIBUTE_SEQUENCE_ORDER+"]");
		billobjectList.addElement("attribute["+ATTRIBUTE_WMS_INVOICED_AMOUNT+"].value");
		billobjectList.addElement("attribute["+ATTRIBUTE_WMS_BILL_K_VALUE+"].value");
		StringList relList1 = new StringList();
		relList1.addElement(DomainRelationship.SELECT_ID);
			
		MapList mlPrevBillsList =  dObject.getRelatedObjects(context,
														  RELATIONSHIP_WMSWO_ABSTRACTMBE,
														  TYPE_WMSABSTRACTMEASURMENTBOOKENTRY, // object pattern
														  billobjectList, // object selects
														  relList1, // relationship selects
														  false, // to direction
														  true, // from direction
														  (short) 1, // recursion level
														  null, // object where clause
														  null); // relationship where clause
														  
		mlPrevBillsList.sort("attribute["+ATTRIBUTE_SEQUENCE_ORDER+"]", ProgramCentralConstants.ASCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
		
		if (iSequenceNo != 1){			
			int iPreviousNo = iSequenceNo - 1;
			String sPreviousSequenceNo = String.valueOf(iPreviousNo);
			MapList maplist =  dObject.getRelatedObjects(context,
														  RELATIONSHIP_WMSWO_ABSTRACTMBE,
														  TYPE_WMSABSTRACTMEASURMENTBOOKENTRY, // object pattern
														  billobjectList, // object selects
														  relList1, // relationship selects
														  false, // to direction
														  true, // from direction
														  (short) 1, // recursion level
														  "attribute["+ATTRIBUTE_SEQUENCE_ORDER+"]=='"+sPreviousSequenceNo+"' && (current == Approved || current == Paid)", // object where clause
														  null); // relationship where clause
														  
			
														  
			  Iterator mlIterator = maplist.iterator();
			  while(mlIterator.hasNext()){
				Map map = (Map)mlIterator.next();
				sName = (String)map.get(DomainConstants.SELECT_NAME);
				String sCurrentActual = (String)map.get("current[Approved].actual");
				Date date = eMatrixDateFormat.getJavaDate(sCurrentActual);
				//Date date=new SimpleDateFormat("dd/MM/yyyy").parse(sCurrentActual); 
				sActual = df.format(date);
				sPrevBillAmount = (String)map.get("attribute["+ATTRIBUTE_WMS_BILL_K_VALUE+"].value");
			  }	
			  if(UIUtil.isNullOrEmpty(sPrevBillAmount)){
					  sPrevBillAmount = "0.0";
			  }
				Double dPrevAmount = Double.valueOf(sPrevBillAmount);
				String strPrev = WMSUtil_mxJPO.converToIndianCurrency(context,dPrevAmount);
			
		} 		
		if(UIUtil.isNotNullAndNotEmpty(strId)){
			StringList slBOQSelect = new StringList();
			slBOQSelect.add(DomainObject.SELECT_ID);
			slBOQSelect.add(DomainObject.SELECT_TYPE);
			slBOQSelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"].value");
			slBOQSelect.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"].value");
			slBOQSelect.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
			slBOQSelect.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
			slBOQSelect.add("attribute["+ATTRIBUTE_WMS_DEVIATION_QUANTITY+"].value");
			MapList mlBOQList = dObject.getRelatedObjects(context,
														  RELATIONSHIP_BILL_OF_QUANTITY,
														  TYPE_WMS_MEASUREMENT_BOOK+","+TYPE_WMS_SEGMENT+","+TYPE_WMS_MEASUREMENT_TASK, // object pattern
														  slBOQSelect, // object selects
														  relList1, // relationship selects
														  false, // to direction
														  true, // from direction
														  (short) 0, // recursion level
														  DomainConstants.EMPTY_STRING, // object where clause
														  DomainConstants.EMPTY_STRING); // relationship where clause
			StringList slRetentionReleaseList = dObject.getInfoList(context,"from["+RELATIONSHIP_WMSWORKORDER_RETUNTIONRECOVERY+"].to.attribute["+ATTRIBUTE_WMS_RETENSION_AMOUNT_PAID_TILL_DATE+"].value");
			
			for(int i=0;i<slRetentionReleaseList.size();i++){
				String strRetentionReleaseValue = (String)slRetentionReleaseList.get(i);
				if(UIUtil.isNullOrEmpty(strRetentionReleaseValue))
					strRetentionReleaseValue = "0";
			
					dTotalRetentionReleased = dTotalRetentionReleased + Double.valueOf(strRetentionReleaseValue);
			}
			
			//if(UIUtil.isNotNullAndNotEmpty(strState) && ("Create".equals(strState) || "Review".equals(strState))){
				String strRetentionReleaseInCurrentBill = MqlUtil.mqlCommand(context,"print bus "+strObjID+" select from["+RELATIONSHIP_WMS_AMBPAYMENTS+"|to.type=="+TYPE_WMSRETENTION_RECOVERYITEM+"].attribute["+ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT+"].value dump |");
				
				StringList slRetentionReleaseCurrentBillList = FrameworkUtil.split(strRetentionReleaseInCurrentBill,"|");
				
				for(int i=0;i<slRetentionReleaseCurrentBillList.size();i++){
					String strRetentionReleaseValue = (String)slRetentionReleaseCurrentBillList.get(i);
					if(UIUtil.isNullOrEmpty(strRetentionReleaseValue))
						strRetentionReleaseValue = "0";
				
						dTotalRetentionReleased = dTotalRetentionReleased + Double.valueOf(strRetentionReleaseValue);
				}
			//}

			Map mTemp = null;
			String strSORRate = DomainConstants.EMPTY_STRING;
			String strQtyPaidTillDate = DomainConstants.EMPTY_STRING;
			String strBOQType = DomainConstants.EMPTY_STRING;
			String strTotalQty = DomainConstants.EMPTY_STRING;
			String strDeviationQty = DomainConstants.EMPTY_STRING;
			String strType = DomainConstants.EMPTY_STRING;
			String strWOBOQId = DomainConstants.EMPTY_STRING;

			for(int i=0;i<mlBOQList.size();i++){
				mTemp = (Map)mlBOQList.get(i);
				
				strWOBOQId = (String)mTemp.get(DomainObject.SELECT_ID);
				strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
				strQtyPaidTillDate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"].value");
				strBOQType = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"].value");
				strTotalQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
				strDeviationQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_DEVIATION_QUANTITY+"].value");
				strSORRate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
				
				if(UIUtil.isNullOrEmpty(strSORRate)){
					strSORRate = "1";					
				}
				
				if(UIUtil.isNullOrEmpty(strQtyPaidTillDate)){
					strQtyPaidTillDate = "0";					
				}
				if(TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
					DomainObject doBOQ = new DomainObject(strWOBOQId);
					StringList slTechDeductionList = doBOQ.getInfoList(context,"from["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].to.attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT+"].value");
					StringList slTechDeductionReleaseList = doBOQ.getInfoList(context,"from["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].to.to["+RELATIONSHIP_WMS_ABSMBE_TECHNICAL_DEDUCTION_RELEASE+"].attribute["+ATTRIBUTE_WMS_CURRENT_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"].value");
					if("Tender Items".equals(strBOQType)){
						slTenderBOQList.add(strWOBOQId);
						sTotalTenderPaid = sTotalTenderPaid + (Double.valueOf(strQtyPaidTillDate)*Double.valueOf(strSORRate));
						for(int j=0;j<slTechDeductionList.size();j++){
							String strDeductAmount = (String)slTechDeductionList.get(j);
							if(UIUtil.isNotNullAndNotEmpty(strDeductAmount)){
								dTenderTechDeduction = dTenderTechDeduction + Double.valueOf(strDeductAmount);
							}
						}	

						for(int j=0;j<slTechDeductionReleaseList.size();j++){
							String strDeductReleaseAmount = (String)slTechDeductionReleaseList.get(j);
							if(UIUtil.isNotNullAndNotEmpty(strDeductReleaseAmount)){
								dTenderTechDeductionRelease = dTenderTechDeductionRelease + Double.valueOf(strDeductReleaseAmount);
							}
						}	
					}
					
					if("Non-Tender Items".equals(strBOQType)){
						slNonTenderBOQList.add(strWOBOQId);
						sTotalNonTenderPaid = sTotalNonTenderPaid + (Double.valueOf(strQtyPaidTillDate)*Double.valueOf(strSORRate));
						for(int j=0;j<slTechDeductionList.size();j++){
							String strDeductAmount = (String)slTechDeductionList.get(j);
							if(UIUtil.isNotNullAndNotEmpty(strDeductAmount)){
								dNonTenderTechDeduction = dNonTenderTechDeduction + Double.valueOf(strDeductAmount);
							}
						}
						
						for(int j=0;j<slTechDeductionReleaseList.size();j++){
							String strDeductReleaseAmount = (String)slTechDeductionReleaseList.get(j);
							if(UIUtil.isNotNullAndNotEmpty(strDeductReleaseAmount)){
								dNonTenderTechDeductionRelease = dNonTenderTechDeductionRelease + Double.valueOf(strDeductReleaseAmount);
							}
						}
					}
					
					if("Deviation".equals(strBOQType)){
						slTenderBOQList.add(strWOBOQId);
						double dTotalBOQQty = Double.valueOf(strTotalQty);
						double dPaidBOQQty = Double.valueOf(strQtyPaidTillDate);
						double dDeviationBOQQty = Double.valueOf(strDeviationQty);
						double OriginalQty = dTotalBOQQty - dDeviationBOQQty;
						if(dPaidBOQQty > OriginalQty){							
							sTotalDeviationPaid = sTotalDeviationPaid + ((dPaidBOQQty - OriginalQty)*Double.valueOf(strSORRate));
							sTotalTenderPaid = sTotalTenderPaid + (Double.valueOf(OriginalQty)*Double.valueOf(strSORRate));	
						}else{
							sTotalTenderPaid = sTotalTenderPaid + (Double.valueOf(strQtyPaidTillDate)*Double.valueOf(strSORRate));							
						}
					}
					
				}
			}
		}
		
		if(UIUtil.isNullOrEmpty(sPrevBillAmount)){
			
			sPrevBillAmount = "0";
		}
		
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		
		String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
		String strLogo = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Logo");
		String strWatermark = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Watermark");
		strWatermark = strWatermark.replace("\\", "/");
		strLogo = strLogo.replace("\\", "/");
		Element embLogo = document.createElement("logo1");
		embLogo.appendChild(document.createTextNode("file:"+strLogo));
		
		Element embHeader = document.createElement("header-footer");
		Element embWatermark = document.createElement("watermark");
		embWatermark.appendChild(document.createTextNode("file:"+strWatermark));
		strHeader = strAMName + "/"+strBillDate+"/DGNP";
		embHeader.appendChild(document.createTextNode(strHeader));
		root.appendChild(embHeader);
		root.appendChild(embWatermark);
		root.appendChild(embLogo);
		
		sPrevBillAmount = new BigDecimal(Double.valueOf(sPrevBillAmount)).setScale(2, BigDecimal.ROUND_UP).toPlainString();
		
		cashBookNo.appendChild(document.createTextNode(""));
		root.appendChild(cashBookNo);
		
		docket.appendChild(document.createTextNode(""));
		root.appendChild(docket);
		edate.appendChild(document.createTextNode(""));
		root.appendChild(edate);
		
		contractorName.appendChild(document.createTextNode(strCompanyName+"\n "+strCompanyAddress));
		root.appendChild(contractorName);
		
		contrPan.appendChild(document.createTextNode(strPANNumber));
		root.appendChild(contrPan);
		
		contrGST.appendChild(document.createTextNode(strGSTNumber));
		root.appendChild(contrGST);
		
		projectname.appendChild(document.createTextNode(strCompanyDescription));
		root.appendChild(projectname);
		
		snoOfBill.appendChild(document.createTextNode(strAMName));
		root.appendChild(snoOfBill);
		
		agreement.appendChild(document.createTextNode(strPONumber));
		root.appendChild(agreement);
		//double dPremium = -1*(Double.parseDouble(strECVValue) - Double.parseDouble(strValueOfContract))/Double.parseDouble(strECVValue) *100;
		double dPremium = 0;
		strValueOfContract = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strValueOfContract));
		contractValue.appendChild(document.createTextNode("Rs."+strValueOfContract));
		root.appendChild(contractValue);
		
		//strECVValue = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strECVValue));
		ecvValue.appendChild(document.createTextNode(""));
		root.appendChild(ecvValue);
		
		agreementDate.appendChild(document.createTextNode(sDate));
		root.appendChild(agreementDate);		
		
		DecimalFormat df1 = new DecimalFormat("#.##");      
		dPremium = Double.valueOf(df1.format(dPremium));
		String strTenderPrem = DomainConstants.EMPTY_STRING;
		if(dPremium > 0){
			strTenderPrem = "+"+String.valueOf(dPremium);
		}else{
			strTenderPrem = "-"+String.valueOf(dPremium);
		}
		tenderPremDiscount.appendChild(document.createTextNode(strTenderPrem+"%"));
		root.appendChild(tenderPremDiscount);	
		
		dPremium = dPremium/100;
		
		commencementWork.appendChild(document.createTextNode(strDuration+" days"));
		root.appendChild(commencementWork);		
		
		Map mBGMap = null;
		for(int i=0;i<mBGDetails.size();i++){
			mBGMap = (Map)mBGDetails.get(i);
			
			Element bankDetails = document.createElement("bank-details");
			Element bankSNo = document.createElement("bank-sno");
			Element bankName = document.createElement("bank-name");
			Element bankAddress = document.createElement("bank-address");
			Element bgValue = document.createElement("bank-value");
			Element bgDate = document.createElement("bank-bg-date");
			Element bgValidUpto = document.createElement("bank-validupto");
			Element bgType = document.createElement("bank-type-of-bg");
			
			String strBankName = (String)mBGMap.get("attribute[Title]");
			String strBankAddress = (String)mBGMap.get(DomainObject.SELECT_DESCRIPTION);
			String strBankValue = (String)mBGMap.get("attribute[Rate]");
			String strBankDate = (String)mBGMap.get("attribute["+ATTRIBUTE_WMS_WO_AGREEMENT_DATE+"]");
			String strBankValidUpto = (String)mBGMap.get("attribute["+ATTRIBUTE_WMS_SUPP_AGREEMENT_DATE+"]");
			String strBankType = (String)mBGMap.get("attribute["+ATTRIBUTE_WMS_REMARK+"]");

			//Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(strBankDate); 
			Date date1 = eMatrixDateFormat.getJavaDate(strBankDate);
			strBankDate = df.format(date1);	
			Date date2 = eMatrixDateFormat.getJavaDate(strBankValidUpto);
			//Date date2=new SimpleDateFormat("dd/MM/yyyy").parse(strBankValidUpto); 
			strBankValidUpto = df.format(date2);	
			
			bankSNo.appendChild(document.createTextNode(String.valueOf(i+1)));
			bankName.appendChild(document.createTextNode(strBankName));
			bankAddress.appendChild(document.createTextNode(strBankAddress));
			bgValue.appendChild(document.createTextNode("Rs."+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strBankValue))));
			bgDate.appendChild(document.createTextNode(strBankValidUpto));
			bgValidUpto.appendChild(document.createTextNode(strBankDate));
			bgType.appendChild(document.createTextNode(strBankType));
			
			bankDetails.appendChild(bankSNo);
			bankDetails.appendChild(bankName);
			bankDetails.appendChild(bankAddress);
			bankDetails.appendChild(bgValue);
			bankDetails.appendChild(bgDate);
			bankDetails.appendChild(bgValidUpto);
			bankDetails.appendChild(bgType);
			root.appendChild(bankDetails);
		}
		
		if(mBGDetails.size()==0){
			Element bankDetails = document.createElement("bank-details");
			Element bankSNo = document.createElement("bank-sno");
			Element bankName = document.createElement("bank-name");
			Element bankAddress = document.createElement("bank-address");
			Element bgValue = document.createElement("bank-value");
			Element bgDate = document.createElement("bank-bg-date");
			Element bgValidUpto = document.createElement("bank-validupto");
			Element bgType = document.createElement("bank-type-of-bg");
			
			bankSNo.appendChild(document.createTextNode(""));
			bankName.appendChild(document.createTextNode(""));
			bankAddress.appendChild(document.createTextNode(""));
			bgValue.appendChild(document.createTextNode(""));
			bgDate.appendChild(document.createTextNode(""));
			bgValidUpto.appendChild(document.createTextNode(""));
			bgType.appendChild(document.createTextNode(""));
			
			bankDetails.appendChild(bankSNo);
			bankDetails.appendChild(bankName);
			bankDetails.appendChild(bankAddress);
			bankDetails.appendChild(bgValue);
			bankDetails.appendChild(bgDate);
			bankDetails.appendChild(bgValidUpto);
			bankDetails.appendChild(bgType);
			root.appendChild(bankDetails);
			
		}
		
		Map mCertificate = null;
		for(int i=0;i<mlCertificates.size();i++){
			mCertificate = (Map)mlCertificates.get(i);
			
			Element certificateDetails = document.createElement("certificates-details");
			Element certSlNo = document.createElement("certificates-sno");
			Element certDesc = document.createElement("certificates-description");
			Element certUser = document.createElement("certificates-user");
			
			String strCertDesc = (String)mCertificate.get(DomainObject.SELECT_DESCRIPTION);
			String strCertUser = (String)mCertificate.get("attribute["+ATTRIBUTE_WMS_ADDED_BY+"]");			
			String userContextUserID = PersonUtil.getPersonObjectID(context, strCertUser);
			DomainObject doPerson = new DomainObject(userContextUserID);
			
			StringList slPersonSelect = new StringList();
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			slPersonSelect.add("attribute["+ATTRIBUTE_HOST_ROLE+"].value");
			Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
			String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			String strRole = (String)mPersonInfo.get("attribute["+ATTRIBUTE_HOST_ROLE+"].value");
			
			if(UIUtil.isNullOrEmpty(strFirstName)){
				strFirstName = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strLastName)){
				strLastName = DomainConstants.EMPTY_STRING;
			}
			
			String strUser = strFirstName + " " +strLastName;
			
			if(UIUtil.isNotNullAndNotEmpty(strRole))
				strUser = strUser + " ("+strRole+")";
			certSlNo.appendChild(document.createTextNode(String.valueOf(i+1)));
			certDesc.appendChild(document.createTextNode(strCertDesc));
			certUser.appendChild(document.createTextNode(strUser));
			
			certificateDetails.appendChild(certSlNo);
			certificateDetails.appendChild(certDesc);
			certificateDetails.appendChild(certUser);
			root.appendChild(certificateDetails);
		}
		
		if(mlCertificates.size()==0){
			Element certificateDetails = document.createElement("certificates-details");
			Element certSlNo = document.createElement("certificates-sno");
			Element certDesc = document.createElement("certificates-description");
			Element certUser = document.createElement("certificates-user");
			certSlNo.appendChild(document.createTextNode(""));
			certDesc.appendChild(document.createTextNode(""));
			certUser.appendChild(document.createTextNode(""));
			
			certificateDetails.appendChild(certSlNo);
			certificateDetails.appendChild(certDesc);
			certificateDetails.appendChild(certUser);
			root.appendChild(certificateDetails);
			
		}
		
		double dUptoTotal=0;
		double dTillDateTotal=0;
		double dSincePreviousTotal=0;
		MapList tenderMl = new MapList();
		MapList nonTenderMl = new MapList();
		MapList deviationMl = new MapList();
		
		Map itemMap = new HashMap();		
		StringList objectList = new StringList();
		objectList.addElement(DomainConstants.SELECT_ID);
		objectList.addElement(DomainConstants.SELECT_NAME);
		objectList.addElement(DomainConstants.SELECT_DESCRIPTION);
		objectList.addElement("attribute["+ATTRIBUTE_WMS_BOQ_SERIAL_NUMBER+"]");
		objectList.addElement("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
		objectList.addElement("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
		objectList.addElement("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"]");
		objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
		objectList.addElement("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
		objectList.addElement("attribute["+ATTRIBUTE_WMS_DEVIATION_QUANTITY+"]");
		objectList.addElement("attribute["+ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE+"]");
		objectList.addElement("attribute[Remarks]");
		
		StringList relList = new StringList();
		relList.addElement(DomainRelationship.SELECT_ID);
		relList.addElement("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
		relList.addElement("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
		relList.addElement("attribute[Assessment Comments]");
		
		DomainObject abstractMeasurementObject = DomainObject.newInstance(context,strObjID);
		MapList maplist =  abstractMeasurementObject.getRelatedObjects(context,
														  RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS,
														  TYPE_WMS_MEASUREMENT_TASK, // object pattern
														  objectList, // object selects
														  relList, // relationship selects
														  false, // to direction
														  true, // from direction
														  (short) 1, // recursion level
														  null, // object where clause
														  null); // relationship where clause
		Iterator aMIterator = maplist.iterator();
		while(aMIterator.hasNext()){
			//count++;
			Map amMap = (Map)aMIterator.next();
			
			String strBOQId = (String)amMap.get(DomainConstants.SELECT_ID);
			String strItemType = (String) amMap.get("attribute[WMSMeasurementTaskType]");
			String strSequence = (String)amMap.get("attribute["+ATTRIBUTE_WMS_BOQ_SERIAL_NUMBER+"]");
			//strWMSTitle1 = (String)amMap.get("attribute["+ATTRIBUTE_TITLE+"]");
			String strReducedSORRate = (String)amMap.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
			String strActivityQuantity = (String)amMap.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"]");
			String strQtyPaidTillDate = (String)amMap.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
			String strDescription = (String)amMap.get("description");
			String strUnit = (String)amMap.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
			
			String strTotalQty = (String)amMap.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
            String strDeviation = (String)amMap.get("attribute["+ATTRIBUTE_WMS_DEVIATION_QUANTITY+"]");
						
			double dWMSReducedSORRate = Double.parseDouble(strReducedSORRate);
			double dWMSActivityQuantity = Double.parseDouble(strActivityQuantity);			
			double dWMSQtyPainTillDate = Double.parseDouble(strQtyPaidTillDate);
			double upToDateQuantity = dWMSActivityQuantity + dWMSQtyPainTillDate;
			double upToDateAmount = (dWMSActivityQuantity + dWMSQtyPainTillDate) * dWMSReducedSORRate;
			
			double dTotalQty = Double.valueOf(strTotalQty);
			double dDeviation = Double.valueOf(strDeviation);
			
			dSincePreviousTotal = dSincePreviousTotal + (dWMSActivityQuantity*dWMSReducedSORRate);
			dUptoTotal = dUptoTotal + upToDateAmount;			
			
			if(strItemType != null && !"".equals(strItemType) && strItemType.equals("Tender Items")){
				if (itemMap.containsKey("TenderItems")){
					tenderMl = (MapList)itemMap.get("TenderItems");
					tenderMl.add(amMap);
					itemMap.put("TenderItems",tenderMl);
				} else {
				    tenderMl.add(amMap);
					itemMap.put("TenderItems",tenderMl);
				}
			
			} else if(strItemType != null && !"".equals(strItemType) && strItemType.equals("Non-Tender Items")){
				if (itemMap.containsKey("NonTenderItems")){
					nonTenderMl = (MapList)itemMap.get("NonTenderItems");
					nonTenderMl.add(amMap);
					itemMap.put("NonTenderItems",nonTenderMl);
				} else {
				    nonTenderMl.add(amMap);
					itemMap.put("NonTenderItems",nonTenderMl);
				}
			} else {
				
				if(upToDateQuantity > (dTotalQty - dDeviation)){
					double dDeviationPaid = dWMSQtyPainTillDate -(dTotalQty - dDeviation);
					double dDeviationTillDate = upToDateQuantity - (dTotalQty - dDeviation);
					
					if(dDeviationTillDate < 0)
						dDeviationTillDate = 0;
					
					if(dDeviationPaid < 0)
						dDeviationPaid = 0;

					amMap.replace("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"]",String.valueOf(dDeviationTillDate));
					amMap.replace("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]",String.valueOf(dDeviationPaid));
					/*if (itemMap.containsKey("DeviationItems")){
						deviationMl = (MapList)itemMap.get("DeviationItems");
						deviationMl.add(amMap);
						itemMap.put("DeviationItems",deviationMl);
					} else {
						deviationMl.add(amMap);
						itemMap.put("DeviationItems",deviationMl);
					}*/
					
					if (itemMap.containsKey("NonTenderItems")){
						deviationMl = (MapList)itemMap.get("NonTenderItems");
						deviationMl.add(amMap);
						itemMap.put("NonTenderItems",deviationMl);
					} else {
						deviationMl.add(amMap);
						itemMap.put("NonTenderItems",deviationMl);
					}
					
					
					Iterator<Map.Entry<String, String>> itr = amMap.entrySet().iterator(); 
					Map<String,String> mTemp = new HashMap<String,String>();
					while(itr.hasNext()) 
					{ 
						 Map.Entry<String, String> entry = itr.next(); 
						 String strKey = (String)entry.getKey();
						if(strKey.equals("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"]") == false && strKey.equals("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]")==false){
							mTemp.put(strKey,entry.getValue());
						}
					} 
					
					if(dDeviationPaid>0){
						
						dDeviationPaid = dTotalQty - dDeviation;
					}
					mTemp.put("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"]",String.valueOf(dTotalQty - dDeviation));
					mTemp.put("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]",String.valueOf(dDeviationPaid));
					
					if (itemMap.containsKey("TenderItems")){
						tenderMl = (MapList)itemMap.get("TenderItems");
						tenderMl.add(mTemp);
						itemMap.put("TenderItems",tenderMl);
					} else {
						tenderMl.add(mTemp);
						itemMap.put("TenderItems",tenderMl);
					}
				}else{
					if (itemMap.containsKey("TenderItems")){
						tenderMl = (MapList)itemMap.get("TenderItems");
						tenderMl.add(amMap);
						itemMap.put("TenderItems",tenderMl);
					} else {
						tenderMl.add(amMap);
						itemMap.put("TenderItems",tenderMl);
					}
				}
			}
		}
		
		
		double dUpdateDateTenderAmount= 0;
		double dUpdateDateNonTenderAmount= 0;
		double dUpdateDateDeviationAmount= 0;
		
		double dOrgGrossUptoDate= 0;
		double dOrgGrossTillDate= 0;
		double dOrgGrossSincePrev= 0;
		
		double dTenderSincePrev= 0;
		double dNonTenderSincePrev= 0;
		int i=0;
		if(tenderMl.size()>0){
			
			Element tableName = document.createElement("table-name-o");
			tableName.appendChild(document.createTextNode("Original Items"));
			root.appendChild(tableName);
			Iterator aMIterator1 = tenderMl.iterator();
			
			while(aMIterator1.hasNext()){
				i++;
				Element Items = document.createElement("items-o");
				root.appendChild(Items);
				Element slNumber = document.createElement("item-slno-o");
				Element SNO = document.createElement("item-code-o");
				Element DESCRIPTION = document.createElement("description-o");
				Element uom = document.createElement("uom-o");
				Element rate = document.createElement("rate-o");
				Element quantity = document.createElement("upto-date-quantity-o");
				Element amt = document.createElement("upto-date-amount-o");
				Element tillDateQty = document.createElement("deduct-quantity-o");
				Element tillDateAmt = document.createElement("deduct-amount-o");
				Element quantity1 = document.createElement("previous-quantity-o");
				Element amt1 = document.createElement("previous-amount-o");
				Element payableAmt = document.createElement("payable-amount-o");
				Element deductionAmt = document.createElement("withheld-amount-o");
				Element deductionAmtRel = document.createElement("withheld-amount-release-o");
				Element remarks = document.createElement("remarks-o");
				
				Map amTenderMap = (Map)aMIterator1.next();
				String strTaskId = (String)amTenderMap.get(DomainObject.SELECT_ID);
				if(slTenderBOQList.contains(strTaskId)){
					slTenderBOQList.remove(strTaskId);
				}
				String strDescription = (String)amTenderMap.get("description");
				String strWMSTitle = (String)amTenderMap.get("attribute["+ATTRIBUTE_TITLE+"]");
				String strReducedSORRate = (String)amTenderMap.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				String strActivityQuantity = (String)amTenderMap.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"]");
				String strQtyPaidTillDate = (String)amTenderMap.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
				String sDeductPreviousAmout = (String)amTenderMap.get("attribute["+ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE+"]");
				String strUnit = (String)amTenderMap.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
				String strPayable = (String)mapPayable.get(strTaskId);
				String strDeductionAmount = (String)mapTechDeduction.get(strTaskId);
				String strDeductionCurrentAmount = (String) mapTechRelease.get(strTaskId);
				
				if(UIUtil.isNullOrEmpty(strDeductionAmount)){
					strDeductionAmount = "0";
				}
				
				if(UIUtil.isNullOrEmpty(strDeductionCurrentAmount)){
					strDeductionCurrentAmount = "0";
				}
				
				if(UIUtil.isNullOrEmpty(strPayable)){
					strPayable = "";
				}
		
				double dWMSReducedSORRate = Double.parseDouble(strReducedSORRate);
				double dWMSActivityQuantity = Double.parseDouble(strActivityQuantity);			
				double dWMSQtyPainTillDate = Double.parseDouble(strQtyPaidTillDate);	
				
				double upToDateQuantity = dWMSActivityQuantity + dWMSQtyPainTillDate;
				double upToDateAmount = (dWMSActivityQuantity + dWMSQtyPainTillDate) * dWMSReducedSORRate;
				dUpdateDateTenderAmount = dUpdateDateTenderAmount + (dWMSActivityQuantity * dWMSReducedSORRate);
				
				double sincePreviousQuantity = dWMSActivityQuantity;
				double sincePreviousAmount = dWMSActivityQuantity * dWMSReducedSORRate;
				
				String sSincePreviousQty = new BigDecimal(Double.valueOf(sincePreviousQuantity)).setScale(3, BigDecimal.ROUND_UP).toPlainString();
				String sSincePreviousAmt = new BigDecimal(Double.valueOf(sincePreviousAmount)-Double.valueOf(strDeductionAmount)).setScale(2, BigDecimal.ROUND_UP).toPlainString();	
				
				String sUpToDateQty =  new BigDecimal(Double.valueOf(upToDateQuantity)).setScale(3, BigDecimal.ROUND_UP).toPlainString();
				String sUpToDateAmt = new BigDecimal(Double.valueOf(sDeductPreviousAmout)+Double.valueOf(sSincePreviousAmt)).setScale(2, BigDecimal.ROUND_UP).toPlainString();

				String sDeductPreviousQty = new BigDecimal(Double.valueOf(upToDateQuantity-sincePreviousQuantity)).setScale(2, BigDecimal.ROUND_UP).toPlainString();
							
				slNumber.appendChild(document.createTextNode(String.valueOf(i)));
				Items.appendChild(slNumber);
				
				SNO.appendChild(document.createTextNode(strWMSTitle));
				Items.appendChild(SNO);

				DESCRIPTION.appendChild(document.createTextNode(strDescription));
				Items.appendChild(DESCRIPTION);
				
				uom.appendChild(document.createTextNode(strUnit));
				Items.appendChild(uom);
				
				rate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strReducedSORRate))));
				Items.appendChild(rate);
				
				quantity.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sUpToDateQty))));
				Items.appendChild(quantity);
				
				amt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sUpToDateAmt))));
				Items.appendChild(amt);
				
				dOrgGrossUptoDate = dOrgGrossUptoDate + Double.valueOf(sUpToDateAmt);
				
				tillDateQty.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sDeductPreviousQty))));
				Items.appendChild(tillDateQty);
				
				tillDateAmt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sDeductPreviousAmout))));
				Items.appendChild(tillDateAmt);
				
				dOrgGrossTillDate = dOrgGrossTillDate + Double.valueOf(sDeductPreviousAmout);
				
				quantity1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sSincePreviousQty))));
				Items.appendChild(quantity1);
				
				amt1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sSincePreviousAmt))));
				Items.appendChild(amt1);

				payableAmt.appendChild(document.createTextNode(strPayable));
				Items.appendChild(payableAmt);
				
				dOrgGrossSincePrev = dOrgGrossSincePrev + Double.valueOf(sSincePreviousAmt);
				
				dTenderSincePrev = dTenderSincePrev + Double.valueOf(sSincePreviousAmt)-Double.valueOf(strDeductionAmount)+Double.valueOf(strDeductionCurrentAmount);
				remarks.appendChild(document.createTextNode(""));
				Items.appendChild(remarks);
				
				if(UIUtil.isNotNullAndNotEmpty(strDeductionCurrentAmount) && Double.valueOf(strDeductionCurrentAmount) >0){
					Element Items1 = document.createElement("items-o");
					root.appendChild(Items1);
					Element slNumber1 = document.createElement("item-slno-o");
					Element SNO1 = document.createElement("item-code-o");
					Element DESCRIPTION1 = document.createElement("description-o");
					Element uom1 = document.createElement("uom-o");
					Element rate1 = document.createElement("rate-o");
					Element quantity12 = document.createElement("upto-date-quantity-o");
					Element amt12 = document.createElement("upto-date-amount-o");
					Element tillDateQty1 = document.createElement("deduct-quantity-o");
					Element tillDateAmt1 = document.createElement("deduct-amount-o");
					Element quantity11 = document.createElement("previous-quantity-o");
					Element amt11 = document.createElement("previous-amount-o");
					Element payableAmt1 = document.createElement("payable-amount-o");
					Element remarks1 = document.createElement("remarks-o");
					
					slNumber1.appendChild(document.createTextNode(String.valueOf(i)));
					Items1.appendChild(slNumber1);
					
					SNO1.appendChild(document.createTextNode(strWMSTitle));
					Items1.appendChild(SNO1);

					DESCRIPTION1.appendChild(document.createTextNode(strDescription));
					Items1.appendChild(DESCRIPTION1);
					
					uom1.appendChild(document.createTextNode(strUnit));
					Items1.appendChild(uom1);
					
					rate1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strReducedSORRate))));
					Items1.appendChild(rate1);
					
					quantity12.appendChild(document.createTextNode(""));
					Items1.appendChild(quantity12);
					
					amt12.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strDeductionCurrentAmount))));
					Items1.appendChild(amt12);
					
					dOrgGrossUptoDate = dOrgGrossUptoDate + Double.valueOf(strDeductionCurrentAmount);
					
					tillDateQty1.appendChild(document.createTextNode(""));
					Items1.appendChild(tillDateQty1);
					
					tillDateAmt1.appendChild(document.createTextNode(""));
					Items1.appendChild(tillDateAmt1);
					
					quantity11.appendChild(document.createTextNode(""));
					Items1.appendChild(quantity11);
					
					amt11.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strDeductionCurrentAmount))));
					Items1.appendChild(amt11);
					
					dOrgGrossSincePrev = dOrgGrossSincePrev + Double.valueOf(strDeductionCurrentAmount);
					
					payableAmt1.appendChild(document.createTextNode(""));
					Items1.appendChild(payableAmt1);
					
				}
				
			}
		}else{
			Element Items = document.createElement("items-o");
			root.appendChild(Items);
		}
		int intSizeTemp = slTenderBOQList.size();
		String[] strItemOIDs = new String[intSizeTemp];
		for (int j = 0; j < intSizeTemp; j++)
		{	
			String strItemOID = slTenderBOQList.get(j);
			if(UIUtil.isNotNullAndNotEmpty(strItemOID))
			{
				strItemOIDs[j] = strItemOID;
			}
		}
		
		StringList strListItemInfo = new StringList();
		strListItemInfo.add("description");
		strListItemInfo.add("attribute["+ATTRIBUTE_TITLE+"]");
		strListItemInfo.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
		strListItemInfo.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
		strListItemInfo.add("attribute["+ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE+"]");
		strListItemInfo.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
		strListItemInfo.add("attribute[Remarks]");
		
		MapList mapTenderItemInfo = DomainObject.getInfo(context, strItemOIDs, strListItemInfo);
		
		
		if(mapTenderItemInfo.size()>0){
			
			Iterator aMIterator1 = mapTenderItemInfo.iterator();			
			while(aMIterator1.hasNext()){
				
				Map amTenderMap = (Map)aMIterator1.next();
				
				String strDescription = (String)amTenderMap.get("description");
				String strWMSTitle = (String)amTenderMap.get("attribute["+ATTRIBUTE_TITLE+"]");
				String strReducedSORRate = (String)amTenderMap.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				String strQtyPaidTillDate = (String)amTenderMap.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
				String sDeductPreviousAmout = (String)amTenderMap.get("attribute["+ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE+"]");
				String strUnit = (String)amTenderMap.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
				
				if(UIUtil.isNotNullAndNotEmpty(strQtyPaidTillDate) && Double.valueOf(sDeductPreviousAmout) > 0){
					i++;
					Element Items = document.createElement("items-o");
					root.appendChild(Items);
					Element slNumber = document.createElement("item-slno-o");
					Element SNO = document.createElement("item-code-o");
					Element DESCRIPTION = document.createElement("description-o");
					Element uom = document.createElement("uom-o");
					Element rate = document.createElement("rate-o");
					Element quantity = document.createElement("upto-date-quantity-o");
					Element amt = document.createElement("upto-date-amount-o");
					Element tillDateQty = document.createElement("deduct-quantity-o");
					Element tillDateAmt = document.createElement("deduct-amount-o");
					Element quantity1 = document.createElement("previous-quantity-o");
					Element amt1 = document.createElement("previous-amount-o");
					Element payableAmt = document.createElement("payable-amount-o");
					Element remarks = document.createElement("remarks-o");
				
					slNumber.appendChild(document.createTextNode(String.valueOf(i)));
					Items.appendChild(slNumber);
					
					SNO.appendChild(document.createTextNode(strWMSTitle));
					Items.appendChild(SNO);

					DESCRIPTION.appendChild(document.createTextNode(strDescription));
					Items.appendChild(DESCRIPTION);
					
					uom.appendChild(document.createTextNode(strUnit));
					Items.appendChild(uom);
					
					rate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strReducedSORRate))));
					Items.appendChild(rate);
					
					quantity.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strQtyPaidTillDate))));
					Items.appendChild(quantity);
					
					amt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sDeductPreviousAmout))));
					Items.appendChild(amt);
					
					dOrgGrossUptoDate = dOrgGrossUptoDate + Double.valueOf(sDeductPreviousAmout);
					
					tillDateQty.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strQtyPaidTillDate))));
					Items.appendChild(tillDateQty);
					
					tillDateAmt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sDeductPreviousAmout))));
					Items.appendChild(tillDateAmt);
					
					dOrgGrossTillDate = dOrgGrossTillDate + Double.valueOf(sDeductPreviousAmout);
					
					quantity1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf("0"))));
					Items.appendChild(quantity1);
					
					amt1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf("0"))));
					Items.appendChild(amt1);
					
					dOrgGrossSincePrev = dOrgGrossSincePrev + Double.valueOf("0");
					
					payableAmt.appendChild(document.createTextNode(""));
					Items.appendChild(payableAmt);

					remarks.appendChild(document.createTextNode(""));
					Items.appendChild(remarks);
				
				}
			}
		}
		
		double dSupGrossUptoDate= 0;
		double dSupGrossTillDate= 0;
		double dSupGrossSincePrev= 0;
		
		//Tender Items
		int k=0;
		if(nonTenderMl.size()>0){
			
			Element tableName = document.createElement("table-name-s");
			tableName.appendChild(document.createTextNode("Deviation/Star Rates"));
			root.appendChild(tableName);
			//Non Tender Items		
			Iterator aMIterator2 = nonTenderMl.iterator();
			
			while(aMIterator2.hasNext()){
				k++;
				Element Items = document.createElement("items-s");
				root.appendChild(Items);
				Element slNumber = document.createElement("item-slno-s");
				Element SNO = document.createElement("item-code-s");
				Element DESCRIPTION = document.createElement("description-s");
				Element uom = document.createElement("uom-s");
				Element rate = document.createElement("rate-s");
				Element quantity = document.createElement("upto-date-quantity-s");
				Element amt = document.createElement("upto-date-amount-s");
				Element tillDateQty = document.createElement("deduct-quantity-s");
				Element tillDateAmt = document.createElement("deduct-amount-s");
				Element quantity12 = document.createElement("previous-quantity-s");
				Element amt12 = document.createElement("previous-amount-s");
				Element payableAmt = document.createElement("payable-amount-s");
				Element remarks = document.createElement("remarks-s");
				
				Map amNonTenderMap = (Map)aMIterator2.next();
				String strTaskId = (String)amNonTenderMap.get(DomainObject.SELECT_ID);
				
				if(slNonTenderBOQList.contains(strTaskId)){
					slNonTenderBOQList.remove(strTaskId);
				}
				
				String strDescription = (String)amNonTenderMap.get("description");
				String strWMSTitle = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_TITLE+"]");
				String strReducedSORRate = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				String strActivityQuantity = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"]");
				String strQtyPaidTillDate = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
				String sDeductPreviousAmout = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE+"]");
				String strUnit = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
				String strRemarks = (String)amNonTenderMap.get("attribute[Remarks]");
				String strPayable = (String)mapPayable.get(strTaskId);
				String strDeductionAmount = (String)mapTechDeduction.get(strTaskId);
				String strDeductionCurrentAmount = (String) mapTechRelease.get(strTaskId);
						
				if(UIUtil.isNullOrEmpty(strDeductionAmount)){
					strDeductionAmount = "0";
				}
				
				if(UIUtil.isNullOrEmpty(strDeductionCurrentAmount)){
					strDeductionCurrentAmount = "0";
				}
				
				if(UIUtil.isNullOrEmpty(strPayable)){
					strPayable = "";
				}		
				
				double dWMSReducedSORRate = Double.parseDouble(strReducedSORRate);
				double dWMSActivityQuantity = Double.parseDouble(strActivityQuantity);			
				double dWMSQtyPainTillDate = Double.parseDouble(strQtyPaidTillDate);	
				
				double upToDateQuantity = dWMSActivityQuantity + dWMSQtyPainTillDate;
				double upToDateAmount = (dWMSActivityQuantity + dWMSQtyPainTillDate) * dWMSReducedSORRate;
				dUpdateDateNonTenderAmount = dUpdateDateNonTenderAmount + (dWMSActivityQuantity * dWMSReducedSORRate);
				
				double sincePreviousQuantity = dWMSActivityQuantity;
				double sincePreviousAmount = dWMSActivityQuantity * dWMSReducedSORRate;
				
				String sSincePreviousQty = new BigDecimal(Double.valueOf(sincePreviousQuantity)).setScale(3, BigDecimal.ROUND_UP).toPlainString();
				String sSincePreviousAmt = new BigDecimal(Double.valueOf(sincePreviousAmount)-Double.valueOf(strDeductionAmount)).setScale(2, BigDecimal.ROUND_UP).toPlainString();	
				
				String sUpToDateQty =  new BigDecimal(Double.valueOf(upToDateQuantity)).setScale(3, BigDecimal.ROUND_UP).toPlainString();
				String sUpToDateAmt = new BigDecimal(Double.valueOf(sDeductPreviousAmout)+Double.valueOf(sSincePreviousAmt)).setScale(2, BigDecimal.ROUND_UP).toPlainString();

				String sDeductPreviousQty = new BigDecimal(Double.valueOf(upToDateQuantity-sincePreviousQuantity)).setScale(2, BigDecimal.ROUND_UP).toPlainString();
				
				slNumber.appendChild(document.createTextNode(String.valueOf(k)));
				Items.appendChild(slNumber);
				
				SNO.appendChild(document.createTextNode(strWMSTitle));
				Items.appendChild(SNO);

				DESCRIPTION.appendChild(document.createTextNode(strDescription));
				Items.appendChild(DESCRIPTION);
				
				uom.appendChild(document.createTextNode(strUnit));
				Items.appendChild(uom);
				
				rate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strReducedSORRate))));
				Items.appendChild(rate);
				
				quantity.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sUpToDateQty))));
				Items.appendChild(quantity);
				
				amt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sUpToDateAmt))));
				Items.appendChild(amt);
				
				dSupGrossUptoDate = dSupGrossUptoDate + Double.valueOf(sUpToDateAmt);
				
				tillDateQty.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sDeductPreviousQty))));
				Items.appendChild(tillDateQty);
				
				tillDateAmt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sDeductPreviousAmout))));
				Items.appendChild(tillDateAmt);
				
				dSupGrossTillDate = dSupGrossTillDate + Double.valueOf(sDeductPreviousAmout);
				
				quantity12.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sSincePreviousQty))));
				Items.appendChild(quantity12);
				
				amt12.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sSincePreviousAmt))));
				Items.appendChild(amt12);
				
				dSupGrossSincePrev = dSupGrossSincePrev + Double.valueOf(sSincePreviousAmt);
				
				payableAmt.appendChild(document.createTextNode(strPayable));
				Items.appendChild(payableAmt);
				
				remarks.appendChild(document.createTextNode(strRemarks));
				Items.appendChild(remarks);
				if(UIUtil.isNotNullAndNotEmpty(strDeductionCurrentAmount) && Double.valueOf(strDeductionCurrentAmount) >0){
					Element Items1 = document.createElement("items-s");
					root.appendChild(Items1);
					Element slNumber1 = document.createElement("item-slno-s");
					Element SNO1 = document.createElement("item-code-s");
					Element DESCRIPTION1 = document.createElement("description-s");
					Element uom1 = document.createElement("uom-s");
					Element rate1 = document.createElement("rate-s");
					Element quantity1 = document.createElement("upto-date-quantity-s");
					Element amt1 = document.createElement("upto-date-amount-s");
					Element tillDateQty1 = document.createElement("deduct-quantity-s");
					Element tillDateAmt1 = document.createElement("deduct-amount-s");
					Element quantity11 = document.createElement("previous-quantity-s");
					Element amt11 = document.createElement("previous-amount-s");
					Element payableAmt1 = document.createElement("payable-amount-s");
					Element remarks1 = document.createElement("remarks-s");
					
					slNumber1.appendChild(document.createTextNode(String.valueOf(k)));
					Items1.appendChild(slNumber1);
					
					SNO1.appendChild(document.createTextNode(strWMSTitle));
					Items1.appendChild(SNO1);

					DESCRIPTION1.appendChild(document.createTextNode(strDescription));
					Items1.appendChild(DESCRIPTION1);
					
					uom1.appendChild(document.createTextNode(strUnit));
					Items1.appendChild(uom1);
					
					rate1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strReducedSORRate))));
					Items1.appendChild(rate1);
					
					quantity1.appendChild(document.createTextNode(""));
					Items1.appendChild(quantity1);
					
					amt1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strDeductionCurrentAmount))));
					Items1.appendChild(amt1);
					
					dSupGrossUptoDate = dSupGrossUptoDate + Double.valueOf(strDeductionCurrentAmount);
					
					tillDateQty1.appendChild(document.createTextNode(""));
					Items1.appendChild(tillDateQty1);
					
					tillDateAmt1.appendChild(document.createTextNode(""));
					Items1.appendChild(tillDateAmt1);
					
					quantity11.appendChild(document.createTextNode(""));
					Items1.appendChild(quantity11);
					
					amt11.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strDeductionCurrentAmount))));
					Items1.appendChild(amt11);
					
					dSupGrossSincePrev = dSupGrossSincePrev + Double.valueOf(strDeductionCurrentAmount);
					
					payableAmt1.appendChild(document.createTextNode(""));
					Items1.appendChild(payableAmt1);
					
				}
				dNonTenderSincePrev = dNonTenderSincePrev + Double.valueOf(sSincePreviousAmt)-Double.valueOf(strDeductionAmount)+Double.valueOf(strDeductionCurrentAmount);
				
				
			}
		}else{
			Element Items = document.createElement("items-s");
			root.appendChild(Items);
		}
		
		int intNTSizeTemp = slNonTenderBOQList.size();
		String[] strNTItemOIDs = new String[intNTSizeTemp];
		for (int j = 0; j < intNTSizeTemp; j++)
		{	
			String strItemOID = slNonTenderBOQList.get(j);
			if(UIUtil.isNotNullAndNotEmpty(strItemOID))
			{
				strNTItemOIDs[j] = strItemOID;
			}
		}
		
		MapList mapNonTenderItemInfo = DomainObject.getInfo(context, strNTItemOIDs, strListItemInfo);
		if(mapNonTenderItemInfo.size()>0){
			Iterator aMIterator2 = mapNonTenderItemInfo.iterator();
			while(aMIterator2.hasNext()){
				
				
				Map amNonTenderMap = (Map)aMIterator2.next();
				String strTaskId = (String)amNonTenderMap.get(DomainObject.SELECT_ID);
				
				String strDescription = (String)amNonTenderMap.get("description");
				String strWMSTitle = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_TITLE+"]");
				String strReducedSORRate = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
				String strQtyPaidTillDate = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
				String sDeductPreviousAmout = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE+"]");
				String strUnit = (String)amNonTenderMap.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
				String strRemarks = (String)amNonTenderMap.get("attribute[Remarks]");

				if(UIUtil.isNotNullAndNotEmpty(sDeductPreviousAmout) && Double.valueOf(sDeductPreviousAmout) > 0){
				
					k++;
					Element Items = document.createElement("items-s");
					root.appendChild(Items);
					Element slNumber = document.createElement("item-slno-s");
					Element SNO = document.createElement("item-code-s");
					Element DESCRIPTION = document.createElement("description-s");
					Element uom = document.createElement("uom-s");
					Element rate = document.createElement("rate-s");
					Element quantity = document.createElement("upto-date-quantity-s");
					Element amt = document.createElement("upto-date-amount-s");
					Element tillDateQty = document.createElement("deduct-quantity-s");
					Element tillDateAmt = document.createElement("deduct-amount-s");
					Element quantity1 = document.createElement("previous-quantity-s");
					Element amt1 = document.createElement("previous-amount-s");
					Element payableAmt = document.createElement("payable-amount-s");
					Element remarks = document.createElement("remarks-s");
				
					slNumber.appendChild(document.createTextNode(String.valueOf(k)));
					Items.appendChild(slNumber);
					
					SNO.appendChild(document.createTextNode(strWMSTitle));
					Items.appendChild(SNO);

					DESCRIPTION.appendChild(document.createTextNode(strDescription));
					Items.appendChild(DESCRIPTION);
					
					uom.appendChild(document.createTextNode(strUnit));
					Items.appendChild(uom);
					
					rate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strReducedSORRate))));
					Items.appendChild(rate);
					
					quantity.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strQtyPaidTillDate))));
					Items.appendChild(quantity);
					
					amt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sDeductPreviousAmout))));
					Items.appendChild(amt);
					
					tillDateQty.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strQtyPaidTillDate))));
					Items.appendChild(tillDateQty);
					
					tillDateAmt.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sDeductPreviousAmout))));
					Items.appendChild(tillDateAmt);
					
					quantity1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf("0"))));
					Items.appendChild(quantity1);
					
					amt1.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf("0"))));
					Items.appendChild(amt1);
					
					payableAmt.appendChild(document.createTextNode(""));
					Items.appendChild(payableAmt);
					
					remarks.appendChild(document.createTextNode(strRemarks));
					Items.appendChild(remarks);
				
				}
			}
		}
		
		//dUpdateDateTenderAmount = dUpdateDateTenderAmount + sTotalTenderPaid - dTenderTechDeduction + dTenderTechDeductionRelease;
		//dUpdateDateNonTenderAmount =  dUpdateDateNonTenderAmount + sTotalNonTenderPaid - dNonTenderTechDeduction + dNonTenderTechDeductionRelease;
		
		dUpdateDateTenderAmount = dOrgGrossUptoDate;
		dUpdateDateNonTenderAmount = dSupGrossUptoDate;
		
		double dTenderGross = dUpdateDateTenderAmount;
		double dNonTenderGross = dUpdateDateNonTenderAmount;
		
		dUpdateDateTenderAmount = dUpdateDateTenderAmount + (dUpdateDateTenderAmount * dPremium);
		dUpdateDateNonTenderAmount = dUpdateDateNonTenderAmount + (dUpdateDateNonTenderAmount * dPremium);
		dUpdateDateDeviationAmount = dUpdateDateDeviationAmount + (dUpdateDateDeviationAmount * dPremium);

		String strUptoDateAmount = df1.format(Double.valueOf(dUpdateDateTenderAmount));
		String strMeasured = df1.format(Double.valueOf(dUpdateDateNonTenderAmount+dUpdateDateDeviationAmount));
		
		String strDeductionValue = DomainConstants.EMPTY_STRING;
		double dDeductionAmount = 0.0;
		int iDedCtr = 0;
		for (Map.Entry<String,String> entry : mOtherDeduction.entrySet())  {
			iDedCtr++;
			Element deduction = document.createElement("deductions");
			Element otherDeduction = document.createElement("deduction");
			Element otherDeductionAmount = document.createElement("deduction-value");
			otherDeduction.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(iDedCtr)+". "+(String)entry.getKey()));
			deduction.appendChild(otherDeduction);
			strDeductionValue = (String)entry.getValue();
			dDeductionAmount = dDeductionAmount+ Double.valueOf(strDeductionValue);
			otherDeductionAmount.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strDeductionValue))));
			deduction.appendChild(otherDeductionAmount);
			root.appendChild(deduction);
		}
		
		Element deduction1 = document.createElement("deductions");
		Element otherDeduction1 = document.createElement("deduction");
		Element otherDeductionAmount1 = document.createElement("deduction-value");
		otherDeduction1.appendChild(document.createTextNode(""));
		deduction1.appendChild(otherDeduction1);
		otherDeductionAmount1.appendChild(document.createTextNode(""));
		deduction1.appendChild(otherDeductionAmount1);
		root.appendChild(deduction1);
		
		Element deduction2 = document.createElement("deductions");
		Element otherDeduction2 = document.createElement("deduction");
		Element otherDeductionAmount2 = document.createElement("deduction-value");
		otherDeduction2.appendChild(document.createTextNode("Subtotal of Other Deductions"));
		deduction2.appendChild(otherDeduction2);
		otherDeductionAmount2.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dDeductionAmount)));
		deduction2.appendChild(otherDeductionAmount2);
		root.appendChild(deduction2);
		
		String strReleaseValue = DomainConstants.EMPTY_STRING;
		double dAddtionAmount = 0.0;
		int iRelCtr = 0;
		for (Map.Entry<String,String> entry : mOtherRelease.entrySet())  {
			iRelCtr++;
			Element releases = document.createElement("additions");
			Element otherRelease = document.createElement("other-additions");
			Element otherReleaseAmount = document.createElement("other-additions-value");
			otherRelease.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(iRelCtr)+". "+(String)entry.getKey()));
			releases.appendChild(otherRelease);
			strReleaseValue = (String)entry.getValue();
			dAddtionAmount = dAddtionAmount+ Double.valueOf(strReleaseValue);
			otherReleaseAmount.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strReleaseValue))));
			releases.appendChild(otherReleaseAmount);
			root.appendChild(releases);
		}
		Element releases1 = document.createElement("additions");
		Element otherRelease1 = document.createElement("other-additions");
		otherRelease1.appendChild(document.createTextNode(""));
		releases1.appendChild(otherRelease1);
		Element otherReleaseAmount1 = document.createElement("other-additions-value");
		otherReleaseAmount1.appendChild(document.createTextNode(""));
		releases1.appendChild(otherReleaseAmount1);
		root.appendChild(releases1);
		
		Element releases2 = document.createElement("additions");
		Element otherRelease2 = document.createElement("other-additions");
		otherRelease2.appendChild(document.createTextNode("Subtotal of Additions"));
		releases2.appendChild(otherRelease2);
		Element otherReleaseAmount2 = document.createElement("other-additions-value");
		otherReleaseAmount2.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dAddtionAmount)));
		releases2.appendChild(otherReleaseAmount2);
		root.appendChild(releases2);
		
		double dRetentionAmount = dUpdateDateTenderAmount + dUpdateDateNonTenderAmount + dUpdateDateDeviationAmount;
		dRetentionAmount = dRetentionAmount * Double.valueOf(strRetention) /100;
		
		String strRetentionAmount = df1.format(dRetentionAmount);
		deductAmount.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strRetentionAmount))));
		root.appendChild(deductAmount);
		
		valueOfItems.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dUpdateDateTenderAmount))));
		root.appendChild(valueOfItems);
		
		valueOfMeasured.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dUpdateDateNonTenderAmount + dUpdateDateDeviationAmount))));
		root.appendChild(valueOfMeasured);
		
		totalvalue.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dUpdateDateTenderAmount+dUpdateDateNonTenderAmount + dUpdateDateDeviationAmount+dAddtionAmount)));
		root.appendChild(totalvalue);
		
		dUptoTotal = dUpdateDateTenderAmount+dUpdateDateNonTenderAmount + dUpdateDateDeviationAmount;

		retentionPercentage.appendChild(document.createTextNode("["+strRetention+"%]"));
		root.appendChild(retentionPercentage);

		
		releaseRetetion.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dTotalRetentionReleased)));
		root.appendChild(releaseRetetion);
		
		withHeld.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strWithHeld))));
		root.appendChild(withHeld);
		
		withHeldRelease.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strWithHeldRelease))));
		root.appendChild(withHeldRelease);

		String strBalance = df1.format(dUptoTotal - dRetentionAmount + dTotalRetentionReleased);
		balance.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strBalance))));
		root.appendChild(balance);
		
		detectIntermediate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(sPrevBillAmount))));
		root.appendChild(detectIntermediate);
		
		modAdvance.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strAdvance))));
		root.appendChild(modAdvance);
		
		modAdvanceRecovery.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strRecovery))));
		root.appendChild(modAdvanceRecovery);
		
		penalty.appendChild(document.createTextNode(""));
		root.appendChild(penalty);
				
		String strInterediatePayement = df1.format(Double.valueOf(strBalance)- Double.valueOf(sPrevBillAmount)+Double.valueOf(strAdvance)-Double.valueOf(strRecovery));	
		intermediate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strInterediatePayement))));
		root.appendChild(intermediate);		
		
		String strTotalPayment  = new BigDecimal(Double.valueOf(strInterediatePayement)+dAddtionAmount-dDeductionAmount).setScale(0, BigDecimal.ROUND_UP).toPlainString();
		
		gross.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strInterediatePayement)+dAddtionAmount)));
		root.appendChild(gross);
		
		netAmount.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strTotalPayment))));
		root.appendChild(netAmount);
		
		String strGrossInWords = WMSUtil_mxJPO.getValueInWords(strTotalPayment);
		checkDetails.appendChild(document.createTextNode("Rs."+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strTotalPayment))+" ("+strGrossInWords+")"));
		root.appendChild(checkDetails);

		String strFinalInWords = WMSUtil_mxJPO.getValueInWords(strInterediatePayement);
		
		passOrder.appendChild(document.createTextNode("Passed for Rs."+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strInterediatePayement)+dAddtionAmount)+" ("+strFinalInWords+") with the Other Deductions shown in the bill."));
		root.appendChild(passOrder);
		
		grossOriginal.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dOrgGrossUptoDate)));
		root.appendChild(grossOriginal);
		
		grossOriginalPremium.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dOrgGrossUptoDate+(dOrgGrossUptoDate*dPremium))));
		root.appendChild(grossOriginalPremium);
		
		grossSupp.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dSupGrossUptoDate)));
		root.appendChild(grossSupp);
		
		grossSuppPremium.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dSupGrossUptoDate+(dSupGrossUptoDate*dPremium))));
		root.appendChild(grossSuppPremium);		
		
		orgGrossUptoDate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dOrgGrossUptoDate)));
		root.appendChild(orgGrossUptoDate);		
		orgGrossTillDate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dOrgGrossTillDate)));
		root.appendChild(orgGrossTillDate);		
		orgGrossSincePrev.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dOrgGrossSincePrev)));
		root.appendChild(orgGrossSincePrev);		
		
		orgGrossUptoDateWithPrem.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dOrgGrossUptoDate+(dOrgGrossUptoDate*dPremium))));
		root.appendChild(orgGrossUptoDateWithPrem);		
		orgGrossTillDateWithPrem.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dOrgGrossTillDate+(dOrgGrossTillDate*dPremium))));
		root.appendChild(orgGrossTillDateWithPrem);		
		orgGrossSincePrevWithPrem.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dOrgGrossSincePrev+(dOrgGrossSincePrev*dPremium))));
		root.appendChild(orgGrossSincePrevWithPrem);		
		
		supGrossUptoDate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dSupGrossUptoDate)));
		root.appendChild(supGrossUptoDate);	
		supGrossTillDate.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dSupGrossTillDate)));
		root.appendChild(supGrossTillDate);
		supGrossSincePrev.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dSupGrossSincePrev)));
		root.appendChild(supGrossSincePrev);
		
		supGrossUptoDateWithPrem.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dSupGrossUptoDate+(dSupGrossUptoDate*dPremium))));
		root.appendChild(supGrossUptoDateWithPrem);
		supGrossTillDateWithPrem.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dSupGrossTillDate+(dSupGrossTillDate*dPremium))));
		root.appendChild(supGrossTillDateWithPrem);
		supGrossSincePrevWithPrem.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dSupGrossSincePrev+(dSupGrossSincePrev*dPremium))));
		root.appendChild(supGrossSincePrevWithPrem);
		
		String strContextUser = context.getUser();
		ContextUtil.pushContext(context);
		if("Create".equals(strState) || (UIUtil.isNotNullAndNotEmpty(strGenMode) && "Invoice".equals(strGenMode))){
			aMObject.setAttributeValue(context,ATTRIBUTE_WMS_INVOICED_AMOUNT,strTotalPayment);
			aMObject.setAttributeValue(context,ATTRIBUTE_WMS_BILL_K_VALUE,strBalance);
		}else{
			aMObject.setAttributeValue(context,ATTRIBUTE_WMS_CERTIFIED_AMOUNT,strTotalPayment);
			aMObject.setAttributeValue(context,ATTRIBUTE_WMS_BILL_K_VALUE,strBalance);
		}
		
		ContextUtil.popContext(context);
		
		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource domSource = new DOMSource(document);
		StreamResult streamResult = new StreamResult(new File(xmlFilePath));
		transformer.transform(domSource, streamResult);
		
		File xmlFile = new File(xmlFilePath);

		//Write XML - End
		
		//Write XSL - Start
		String strXSLFile = "Form26ItemRateSource.xsl";
		File newTextFile = new File(strTransPath + File.separator+strXSLFile);

		MQLCommand mql = new MQLCommand();
		mql.open(context);
		mql.executeCommand(context, "print program WMSForm26ItemRate.xsl select code dump");
		mql.close(context);
		FileWriter fw = new FileWriter(newTextFile);
		
		fw.write(mql.getResult());
		fw.close();
		//Write XSL - End				
		
		File xsltFile = new File(strTransPath + File.separator+strXSLFile);
		// the XML file which provides the input
		StreamSource xmlSource = new StreamSource(new File(xmlFilePath));
		// create an instance of fop factory
		// Setup output
		String strFileName = strName+".pdf";
		OutputStream out;
		out = new java.io.FileOutputStream(strTransPath+File.separator+strFileName);
		try {
			FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
			// a user agent is needed for transformation
			FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
			// Construct fop with desired output format
			Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);

			// Setup XSLT
			TransformerFactory factory = TransformerFactory.newInstance();
			Transformer transformer1 = factory.newTransformer(new StreamSource(xsltFile));
			//xsltFile.delete();
			// Resulting SAX events (the generated FO) must be piped through to FOP
			Result res = new SAXResult(fop.getDefaultHandler());
			// Start XSLT transformation and FOP processing
			// That's where the XML is first transformed to XSL-FO and then 
			// PDF is created
			transformer1.transform(xmlSource, res);
		} finally {
			File file1 = new File(strTransPath+File.separator+strFileName);			
		
			if(UIUtil.isNotNullAndNotEmpty(strMode) && strMode.equalsIgnoreCase("Approval")){
				DomainObject domInBoxTask=DomainObject.newInstance(context,strInboxTaskId);
				WMSUtil_mxJPO wmsObj=new WMSUtil_mxJPO(context, new String[] {});
//				wmsObj.setSHA256HashOfFileContent(context, strTransPath+File.separator+strFileName,domInBoxTask);
			}else{
				DomainObject dObject1 = DomainObject.newInstance(context,strObjID);
				ContextUtil.pushContext(context);
				dObject1.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strTransPath);
				ContextUtil.popContext(context);
			}		
			
			if(file1.delete())
			{
				System.out.println("File deleted successfully");
			}
			else
			{
				System.out.println("Failed to delete the file");
			}
			if(newTextFile.delete())
			{
				System.out.println("File deleted successfully");
			}
			else
			{
				System.out.println("Failed to delete the file");
			}
			if(xmlFile.delete())
			{
				System.out.println("File deleted successfully");
			}
			else
			{
				System.out.println("Failed to delete the file");
			}
			out.close();
		}
		
		}
		
		
		public void getPayableInCurrentBill(Context context, String strAbsMBEId) throws Exception {
    	try {    		 

			StringList strListBusSelects = new StringList();
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_PERCENT_AMOUNT_PAYABLE+"].value");
			strListBusSelects.add("to["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id");

			if(UIUtil.isNotNullAndNotEmpty(strAbsMBEId)) {
				DomainObject domAbs = DomainObject.newInstance(context, strAbsMBEId);
				MapList mlTech = domAbs.getRelatedObjects(context, // matrix context
		                RELATIONSHIP_WMS_ABSMBE_TECHNICALDEDUCTION, // relationship pattern
		                TYPE_WMS_TECHNICAL_DEDUCTION, // type pattern
		                strListBusSelects, // object selects
		                new StringList(DomainRelationship.SELECT_ID), // relationship selects
		                false, // to direction
		                true, // from direction
		                (short) 1, // recursion level
		                DomainConstants.EMPTY_STRING, // object where clause
		                DomainConstants.EMPTY_STRING, // relationship where clause
		                0);
				if(mlTech.size()>0) {
					String strDeductionAmount="";
					float fstrQty=0.0F;
					float fstrTotal=0.0F;
					Iterator<Map<String, String>> iteratorMap = mlTech.iterator();
					Map<String, String> mapObjectData = new HashMap<String, String>();
					while (iteratorMap.hasNext()) {
						mapObjectData = iteratorMap.next();
						strDeductionAmount = mapObjectData.get("attribute["+ATTRIBUTE_WMS_PERCENT_AMOUNT_PAYABLE+"].value");
						fstrQty = Float.valueOf(strDeductionAmount);
						String strTaskId = mapObjectData.get("to["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id");
						if(UIUtil.isNotNullAndNotEmpty(strDeductionAmount)) {
					 		mapPayable.put(strTaskId, strDeductionAmount);
						}
					}
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    	
    }
		
		
	 public void getTDInCurrentBill(Context context, String strAbsMBEId) throws Exception {
    	try {    		 

			StringList strListBusSelects = new StringList();
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT+"].value");
			strListBusSelects.add("to["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id");

			if(UIUtil.isNotNullAndNotEmpty(strAbsMBEId)) {
				DomainObject domAbs = DomainObject.newInstance(context, strAbsMBEId);
				MapList mlTech = domAbs.getRelatedObjects(context, // matrix context
		                RELATIONSHIP_WMS_ABSMBE_TECHNICALDEDUCTION, // relationship pattern
		                TYPE_WMS_TECHNICAL_DEDUCTION, // type pattern
		                strListBusSelects, // object selects
		                new StringList(DomainRelationship.SELECT_ID), // relationship selects
		                false, // to direction
		                true, // from direction
		                (short) 1, // recursion level
		                DomainConstants.EMPTY_STRING, // object where clause
		                DomainConstants.EMPTY_STRING, // relationship where clause
		                0);

				
				if(mlTech.size()>0) {
					String strDeductionAmount="";
					float fstrQty=0.0F;
					float fstrTotal=0.0F;
					Iterator<Map<String, String>> iteratorMap = mlTech.iterator();
					Map<String, String> mapObjectData = new HashMap<String, String>();
					while (iteratorMap.hasNext()) {
						mapObjectData = iteratorMap.next();
						strDeductionAmount = mapObjectData.get("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT+"].value");
						fstrQty = Float.valueOf(strDeductionAmount);
						String strTaskId = mapObjectData.get("to["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id");
						if(UIUtil.isNotNullAndNotEmpty(strDeductionAmount)) {
					 		mapTechDeduction.put(strTaskId, strDeductionAmount);
						}
					}
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    	
    }
	
	
	public void getTDReleaseInCurrentBill(Context context, String strAbsMBEId) throws Exception {
    	try {
   		 
			StringList strListBusSelects = new StringList();
			strListBusSelects.add("to["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add("attribute["+ATTRIBUTE_WMS_CURRENT_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"].value");
			if(UIUtil.isNotNullAndNotEmpty(strAbsMBEId)) {
				DomainObject domAbs = DomainObject.newInstance(context, strAbsMBEId);
				MapList mlTech = domAbs.getRelatedObjects(context, // matrix context
		                RELATIONSHIP_WMS_ABSMBE_TECHNICAL_DEDUCTION_RELEASE, // relationship pattern
		                TYPE_WMS_TECHNICAL_DEDUCTION, // type pattern
		                strListBusSelects, // object selects
		                strListRelSelects, // relationship selects
		                false, // to direction
		                true, // from direction
		                (short) 1, // recursion level
		                DomainConstants.EMPTY_STRING, // object where clause
		                DomainConstants.EMPTY_STRING, // relationship where clause
		                0);
				
				if(mlTech.size()>0) {
					Iterator<Map<String, String>> iteratorMap = mlTech.iterator();
					Map<String, String> mapObjectData = new HashMap<String, String>();
					while (iteratorMap.hasNext()) {
						mapObjectData = iteratorMap.next();
						String strDeductionReleaseAmount = mapObjectData.get("attribute["+ATTRIBUTE_WMS_CURRENT_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"].value");
						String strTaskId = mapObjectData.get("to["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id");
						if(UIUtil.isNotNullAndNotEmpty(strDeductionReleaseAmount)) {
							if(mapTechRelease.containsKey(strTaskId)){
								String strOldAmount = mapTechRelease.get(strTaskId);
								double dUpdatedAmount = Double.parseDouble(strDeductionReleaseAmount)+Double.parseDouble(strOldAmount);
								strDeductionReleaseAmount = String.valueOf(dUpdatedAmount);
							}
							mapTechRelease.put(strTaskId, strDeductionReleaseAmount);
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    }

}