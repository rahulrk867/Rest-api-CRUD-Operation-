/** Name of the JPO    : WMSAbstractMeasurementBookEntryBase
 ** Developed by    : Matrixone 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to create a Abstract Measurement Book Entry and its functionalities
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;
import java.time.LocalDateTime;

import com.matrixone.apps.common.MemberRelationship;
import com.matrixone.apps.common.Person;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MailUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.common.CommonDocument;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringList;
import java.util.Date;
import java.text.SimpleDateFormat;
/**
 * The purpose of this JPO is to create a Abstract Measurement Book Entry and its functionalities
 * @author WMS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSAbstractMeasurementBookEntry_mxJPO extends WMSConstants_mxJPO
{
	public WMSAbstractMeasurementBookEntry_mxJPO(Context context, String[] args) {
		super(context, args);
		// TODO Auto-generated constructor stub
	}

	

    /**
	 * Method to get the connected Tasks under the MBEs which are connected to Abtract MBE
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedTasks MapList containing the Task IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getUniqueMBEActivities (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mlAllConnectedTasks = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjAbstractMBE= DomainObject.newInstance(context, strObjectId);
				mlAllConnectedTasks = getUniqueMBEActivities(context, domObjAbstractMBE);
				WMSMeasurementBookEntry_mxJPO.insertKeyValue(mlAllConnectedTasks, "disableSelection", "false");
			}
			return mlAllConnectedTasks;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/** 
	 * Method will get all Unique Tasks which are connected to Abstract MBE connected MBEs
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjAbstractMBE DomainObject instance of Abstract MBE
	 * @return mapListUniqueTasks MapList containing the Activities connected to Abstract MBE through MBE
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private MapList getUniqueMBEActivities(Context context,
			DomainObject domObjAbstractMBE) throws FrameworkException {
		try
		{
			StringList strListBusSelects     = getUniqueMBEActivitiesBusSelects();
			StringList strListRelSelects     = getUniqueMBEActivitiesRelSelects();
			Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
			

			MapList mapListItems = domObjAbstractMBE.getRelatedObjects(context, // matrix context
					RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS, // relationship pattern
					patternType.getPattern(), // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					DomainConstants.EMPTY_STRING, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
			return mapListItems;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	
	/** 
	 * Method will get StringList
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjMBE DomainObject instance of selected Work Order 
	 * @return mapListTasks MapList containing the Activities connected to Abstract MBE through MBE
	 * @author WMS
	 * @since 418
	 */
	private SelectList getUniqueMBEActivitiesBusSelects() {
		SelectList strListBusSelects     = new SelectList(4);
		strListBusSelects.add(DomainConstants.SELECT_TYPE);
		strListBusSelects.add(DomainConstants.SELECT_ID);
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
		strListBusSelects.add("relationship["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].from.name");
		//strListBusSelects.add("relationship["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].attribute["+ATTRIBUTE_INCLUDE_IN_BILL+"].value");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
		 strListBusSelects.add("from["+RELATIONSHIP_WMS_TASK_SOR+"].to.to["+RELATIONSHIP_WMS_MATERIAL_TO_SOR+"].from.id");

		return strListBusSelects;
	}
	
	private StringList getUniqueMBEActivitiesRelSelects() {
		StringList strListRelSelects     = new StringList(8);
		strListRelSelects.add(DomainRelationship.SELECT_ID);
		//strListRelSelects.add("attribute["+ATTRIBUTE_ABSMBE_ITEM_RATE+"].value");
		//strListRelSelects.add("attribute["+ATTRIBUTE_ITEM_TOTAL_DEDUCTION+"].value");
		//strListRelSelects.add("attribute["+ATTRIBUTE_ITEM_WITHHELD_CAUSE+"].value");
		//strListRelSelects.add("attribute["+ATTRIBUTE_ABSMBE_ITEM_TOTAL_COST+"].value");
		strListRelSelects.add("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
		strListRelSelects.add("attribute["+ATTRIBUTE_WMS_PAYABLE_QUANTITY+"].value");
		strListRelSelects.add("attribute["+ATTRIBUTE_WMS_WITHHELD_CAUSE+"].value");
		strListRelSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"].value");
		strListRelSelects.add("attribute["+ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE+"].value");

		return strListRelSelects;
	}
	/** 
	 * It gives quanity of item that can be added to Abs MBE
	 * 
	 * @param context the eMatrix <code>Context</code> object 
	 * @param args
	 * @return Response values list
	 * @throws Exception if operation fails
	 * @author WMS
	 * @since 418
	 */
	public Vector<String> getAbsMBEAddParticularsItemQuantity(Context context, String[] args)
			throws Exception
	{
		try{
			Map<String,Object> programMap =   (Map<String,Object>)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector<String> vecResponse = new Vector<String>(intSize);
			Iterator<Map<String,String>> iterator  = objectList.iterator();
			Map<String,String> mapData ;
			while(iterator.hasNext())
			{
				mapData = iterator.next();
				String strReleasedQuantity = mapData.get("FinalQuanity");
				vecResponse.add(strReleasedQuantity);
			}
			return vecResponse;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/**
	 * This method is to get Measurement Task For Select AbstractMBE
	 * @param context - the eMatrix <code>Context</code> object
	 * @param String array args containing the programMap
	 * @return - MapList
	 * @throws Exception when problems occurred
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getMeasurementTask(Context context, String[] args) throws Exception
	{
		MapList mlreturnList = new MapList();
		try
		{
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strAbstractMBEId    = (String) programMap.get("mbeOID");
			if(UIUtil.isNotNullAndNotEmpty(strAbstractMBEId))
			{
				String sWMSMBEItemType = (String) programMap.get("MBEItemType");
				if(UIUtil.isNullOrEmpty(sWMSMBEItemType))
				{
					sWMSMBEItemType = "Normal";
				}
				DomainObject domObjAbsMBE = new DomainObject(strAbstractMBEId);
				StringList strListConnectedTasks = getAbsMBEConnectedActivities(context, domObjAbsMBE);
				String strWhere = "("+DomainConstants.SELECT_TYPE+"=="+TYPE_WMS_MEASUREMENT_BOOK+")||("+DomainConstants.SELECT_TYPE+"=="+TYPE_WMS_SEGMENT+")||(("+DomainConstants.SELECT_TYPE+"=="+TYPE_WMS_MEASUREMENT_TASK+")&&(attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"].value!=attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"].value))";
				MapList mapListItems =  getAbsMBEParticularsMBEs(context,domObjAbsMBE, strWhere); 
				Map<String,String> mapData;
				Iterator<Map<String,String>> iterator = mapListItems.iterator();
				while(iterator.hasNext())
				{
					mapData = iterator.next();
					String strOID = mapData.get(DomainConstants.SELECT_ID);
					if(!strListConnectedTasks.contains(strOID))
					{
						String strItemPaidQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
						String strItemSubmittedQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
						double doubleItemPaidQuantity =WMSUtil_mxJPO.convertToDouble(strItemPaidQuantity);
						double doubleItemSubmittedQuantity = WMSUtil_mxJPO.convertToDouble(strItemSubmittedQuantity);
						mapData.put("FinalQuanity", String.valueOf((doubleItemSubmittedQuantity-doubleItemPaidQuantity)));
						mlreturnList.add(mapData);
					}

				}
			}
		}catch(Exception ex)
		{
			ex.printStackTrace();
			throw ex;
		}
		return mlreturnList;
	}
	/** 
	 * Method will get all Unique Tasks which are connected to Abstract MBE connected MBEs
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjAbstractMBE DomainObject instance of Abstract MBE
	 * @return mapListUniqueTasks MapList containing the Activities connected to Abstract MBE through MBE
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private StringList getAbsMBEConnectedActivities(Context context,
			DomainObject domObjAbstractMBE) throws FrameworkException {
		try
		{
			SelectList strListBusSelects     = new SelectList(1);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			StringList strListRelSelects     = new StringList(1);
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
			MapList mapListItems = domObjAbstractMBE.getRelatedObjects(context, // matrix context
					RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS, // relationship pattern
					patternType.getPattern(), // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					DomainConstants.EMPTY_STRING, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
			StringList strListAbsMBEConnectedTasks = WMSUtil_mxJPO.convertToStringList(mapListItems, DomainConstants.SELECT_ID);
			return strListAbsMBEConnectedTasks;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	/** 
	 * Method will roll up the the respective attribute value on the Items connected to the item
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args with program arguments
	 *             args[0]- Activity OID
	 *          args[1]- Attribute Old value
	 *            args[2]- Attribute New value
	 *             args[3]- Rel OID between Abstract MBE and Activity
	 *          args[4]- Abstract MBE OID
	 *            args[5]- Attribute Name
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private MapList getAbsMBEParticularsMBEs(Context context,
			DomainObject domObjAbsMBE, String strWhere)
					throws FrameworkException {
		try
		{
			String strWOOID = domObjAbsMBE.getInfo(context, "relationship["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
			MapList mapListItems = new MapList();
			if(UIUtil.isNotNullAndNotEmpty(strWOOID))
			{
				DomainObject domObjWO = DomainObject.newInstance(context, strWOOID);
				domObjWO.setId(strWOOID);
				StringList strListBusSelects=new StringList(4);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_NAME);
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
				StringList strListRelSelects=new StringList(3);
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_BOOK);
				patternType.addPattern(TYPE_WMS_SEGMENT);
				patternType.addPattern(TYPE_WMS_MEASUREMENT_TASK);
				mapListItems = domObjWO.getRelatedObjects(context,
						RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
						patternType.getPattern(),                                    // object pattern
						true,                                                        // to direction
						true,                                                       // from direction
						(short)0,                                                      // recursion level
						strListBusSelects,                                                 // object selects
						strListRelSelects,                                                         // relationship selects
						strWhere,                                // object where clause
						DomainConstants.EMPTY_STRING,                                // relationship where clause
						(short)0,                                                      // No expand limit
						DomainConstants.EMPTY_STRING,                                // postRelPattern
						TYPE_WMS_MEASUREMENT_TASK,                                                // postTypePattern
						null);
				WMSMeasurementBookEntry_mxJPO.insertKeyValue(mapListItems, DomainConstants.SELECT_LEVEL,"1");

			}
			return mapListItems;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	/**
	 * Method add the Item to AbstractMBE
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedTasks MapList containing the Task IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public Map<String,String> addAbstractMBEItem(Context context, String[] args) throws Exception 
	{
		try
		{
			Map<String,String> mapResult = new HashMap<String,String>();
			mapResult.put(DomainConstants.SELECT_ID, DomainConstants.EMPTY_STRING);
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
			String strAbstractMBEOID = (String) programMap.get("objectId");
			int intSize = emxTableRowId.length;
			if(emxTableRowId !=null && intSize>0&& UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID))
			{
				DomainObject domObjAbstractMBE  = DomainObject.newInstance(context, strAbstractMBEOID);
				String strSequenceValue = domObjAbstractMBE.getAttributeValue(context, ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER);
				String strAbsTotalValue = domObjAbstractMBE.getAttributeValue(context, "WMSTotalCost");
				double doubleAbsMBETotalAmount = WMSUtil_mxJPO.convertToDouble(strAbsTotalValue);
				ArrayList<String> arrayListItemOIDs = new ArrayList<String>(intSize);
				ArrayList<String> arrayListMBEOIDs = new ArrayList<String>(intSize);
				StringList strListItemMBERelOIDs = new StringList();
				Map<String,String> mapQuanity = new HashMap<String,String>(intSize);
				Map<String,String> mapData ;
				MapList mapListItemInfo = getSelectedItemInfo(context, emxTableRowId);
				HashMap<String,String> hashMapAttributeMap = new HashMap<String,String>(2);
			//	hashMapAttributeMap.put(ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER,strSequenceValue);
				hashMapAttributeMap.put(ATTRIBUTE_WMS_ABS_MBE_OID,strAbstractMBEOID);
				for (int i = 0; i < intSize; i++)
				{
					String[] emxTableRowIdData = emxTableRowId[i].split("[|]");
					String strItemOID = emxTableRowIdData[1];
					if(UIUtil.isNotNullAndNotEmpty(strItemOID))
					{
						DomainObject domObjItem  = DomainObject.newInstance(context, strItemOID);
						Map<String,String> mapItemData = WMSUtil_mxJPO.getMap(mapListItemInfo, DomainConstants.SELECT_ID, strItemOID);
						String strItemPaidQuantity = mapItemData.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
						String strItemSubmittedQuantity = mapItemData.get("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
						double doubleItemPaidQuantity =WMSUtil_mxJPO.convertToDouble(strItemPaidQuantity);
						double doubleItemSubmittedQuantity = WMSUtil_mxJPO.convertToDouble(strItemSubmittedQuantity);
						double doubleCurrentBillQuantity = doubleItemSubmittedQuantity-doubleItemPaidQuantity;
						StringList strListCurrentItemMBERelOIDs = getItemConnectedMBERelOIDs(context,domObjItem);
						strListItemMBERelOIDs.addAll(strListCurrentItemMBERelOIDs);
						mapQuanity.put(strItemOID,String.valueOf(doubleCurrentBillQuantity));
						mapQuanity.put(strItemOID+"_Rate",mapItemData.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]"));
						double doubleItemCost = connectAbstractMBEItems(context, domObjAbstractMBE, strItemOID, mapQuanity);
						doubleAbsMBETotalAmount+=doubleItemCost;
					}
				}
				setAbsMBEOIDOnItemsMBE(context, hashMapAttributeMap,strListItemMBERelOIDs);
				
				domObjAbstractMBE.setAttributeValue(context, "WMSTotalCost", String.valueOf(doubleAbsMBETotalAmount));
				Locale strLocale = context.getLocale();
				String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.MBEs.CONNECTIONMBE.Alert");			
				mapResult.put("Message", strMessage);
			}
			return mapResult;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	private MapList getSelectedItemInfo(Context context, String[] emxTableRowId) throws FrameworkException {
		StringList strListItemInfo = new StringList(4);
		strListItemInfo.add(DomainConstants.SELECT_ID);
		strListItemInfo.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
		strListItemInfo.add("attribute["+ATTRIBUTE_WMS_MBE_QUANTITY+"]");
		strListItemInfo.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
		int intSizeTemp = emxTableRowId.length;
		String[] strItemOIDs = new String[intSizeTemp];
		for (int i = 0; i < intSizeTemp; i++)
		{
			String[] emxTableRowIdData = emxTableRowId[i].split("[|]");
			String strItemOID = emxTableRowIdData[1];
			if(UIUtil.isNotNullAndNotEmpty(strItemOID))
			{
				strItemOIDs[i] = strItemOID;
			}
		}
		MapList mapListItemInfo = DomainObject.getInfo(context, strItemOIDs, strListItemInfo);
		return mapListItemInfo;
	}
	private StringList getItemConnectedMBERelOIDs(Context context,
			DomainObject domObjItem) throws FrameworkException {
		try
		{
			String strBusWhere = "current==Submitted";
			String strRelWhere = "(attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value==\"\")";
			MapList mapListMBEs = getItemConnectedMBEs(context,domObjItem,strRelWhere,strBusWhere);
			MapList mapListFilteredMBEs = filterMBEByRevision(mapListMBEs);
			StringList strListRelOIDS = WMSUtil_mxJPO.convertToStringList(mapListFilteredMBEs, DomainRelationship.SELECT_ID);
			return strListRelOIDS;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	private MapList filterMBEByRevision(MapList mapListMBEs) 
	{
		MapList mapListFinalMBEs = new MapList();
		mapListMBEs.removeAll(mapListFinalMBEs);
		Map<String, String> mapLatestMBE = new HashMap<String, String>();
		Map<String, String> mapData;
		mapListMBEs.addSortKey(DomainConstants.SELECT_NAME, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_STRING);
		mapListMBEs.addSortKey(DomainObject.SELECT_REVISION, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
		mapListMBEs.sortStructure();
		double doublePreviousBilledQuantity = 0d;
		double doubleCurrentBilledQuantity = 0d;
		String strRunningMBEName = DomainConstants.EMPTY_STRING;
		while(mapListMBEs.size()>0)
		{
			ListIterator<Map<String,String>> iterator = mapListMBEs.listIterator();
			mapData = iterator.next();
			String strMBEName = mapData.get(DomainConstants.SELECT_NAME);
			MapList mapListTemp = WMSUtil_mxJPO.getSubMapList(mapListMBEs, DomainConstants.SELECT_NAME, strMBEName);
			if(mapListTemp.size()>0)
			{
				mapLatestMBE = (Map<String, String>) mapListTemp.get(0);
				String strCurrentQuanity = mapLatestMBE.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
				doubleCurrentBilledQuantity =  WMSUtil_mxJPO.convertToDouble(strCurrentQuanity);
				//Iterate through he above MapList and identify if any of the revision is connected to context AbsMBE
				ListIterator<Map<String,String>> iteratorTemp = mapListTemp.listIterator();
				MapList mapListRunningMBEs = new MapList();
				while(iteratorTemp.hasNext())
				{
					mapData= iteratorTemp.next();
					String strPreviousBilledMBE = mapData.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
					if(UIUtil.isNotNullAndNotEmpty(strPreviousBilledMBE))
					{
						String strQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
						doublePreviousBilledQuantity = WMSUtil_mxJPO.convertToDouble(strQuantity);
						break;
					}
				}
				mapLatestMBE.put("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value", String.valueOf((doubleCurrentBilledQuantity-doublePreviousBilledQuantity)));
				doubleCurrentBilledQuantity = 0d;
				doublePreviousBilledQuantity = 0d;
				mapListFinalMBEs.add(mapLatestMBE);
				mapListMBEs.removeAll(mapListTemp);
			}
		}
		return mapListFinalMBEs;
	}
	/**
	 * Method connects the Items and abstract MBE. Also It calculates cost as per the Quantity and rate provided in info map
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjAbstractMBE DomainObject instance of the new Abstract MBE
	 * @param strItemOID String value containing items OID
	 * @param mapItemInfo Map<String,String> contains the ItemOID , ItemOID_Rate as key
	 * @return doubleAbsMBEItemCost double value containing the Item cost
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private double connectAbstractMBEItems(Context context,
			DomainObject domObjAbstractMBE,
			String strItemOID,
			Map<String, String> mapItemInfo) throws FrameworkException {
		try
		{
			double doubleAbsMBEItemCost = 0d;
			DomainObject domObjItem = DomainObject.newInstance(context);
			Map<String,String> mapAttributesValue = new HashMap<String, String>(7);
			mapAttributesValue.put("WMSAbsMBEItemCost", "0");
			mapAttributesValue.put("WMSMBEActivityQuantity", "0");
			domObjItem.setId(strItemOID);
			DomainRelationship domRel = DomainRelationship.connect(context,domObjAbstractMBE , RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS,domObjItem );
			String strRate = mapItemInfo.get((strItemOID+"_Rate"));
			double doubleRate = WMSUtil_mxJPO.convertToDouble(strRate);
			double doubleCurrentBillQuantity = WMSUtil_mxJPO.convertToDouble(mapItemInfo.get(strItemOID));
			doubleAbsMBEItemCost = (doubleRate*doubleCurrentBillQuantity);
			mapAttributesValue.put("WMSAbsMBEItemCost", String.valueOf(doubleAbsMBEItemCost));
			mapAttributesValue.put("WMSAMBItemTotalCost",String.valueOf(doubleAbsMBEItemCost));
			mapAttributesValue.put("WMSMBEActivityQuantity", String.valueOf(doubleCurrentBillQuantity));
			mapAttributesValue.put("WMSAbstractMBEItemPayableQuantity", String.valueOf(doubleCurrentBillQuantity));
			mapAttributesValue.put("WMSDeductionRate", String.valueOf(doubleRate));
			//updateItemPaidQuanity(context,domObjItem, doubleCurrentBillQuantity,domObjAbstractMBE.getInfo(context, DomainConstants.SELECT_ID));
			domRel.setAttributeValues(context, mapAttributesValue);
			return doubleAbsMBEItemCost;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	private void setAbsMBEOIDOnItemsMBE(Context context, HashMap attributeMap,
			StringList strListItemMBERelOIDs)
					throws FrameworkException {
		boolean isContextPushed = true;
		try
		{
			//ContextUtil.pushContext(context, "person_UserAgent",DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
			ContextUtil.pushContext(context);
			Iterator<String> iterator = strListItemMBERelOIDs.iterator();
			String strRelOID = DomainConstants.EMPTY_STRING;
			while(iterator.hasNext())
			{
				strRelOID = iterator.next();
				DomainRelationship.setAttributeValues(context, strRelOID, attributeMap);
			}
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
	}
	
	private MapList getItemConnectedMBEs(Context context,
			DomainObject domObjItem,String strRelWhere,String strBusWhere) throws FrameworkException {
		try
		{
			if(UIUtil.isNullOrEmpty(strBusWhere))
			{
				strBusWhere = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strRelWhere))
			{
				strRelWhere = DomainConstants.EMPTY_STRING;
			}
			StringList strListBusSelects = getItemConnectedMBEBusSelects();
			StringList strListRelSelects = getItemConnectedMBERelSelects();
			MapList mapListMBEs = domObjItem.getRelatedObjects(context, // matrix context
					RELATIONSHIP_WMS_MBE_ACTIVITIES, // relationship pattern
					TYPE_WMS_MEASUREMENT_BOOK_ENTRY, // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
					true, // to direction
					false, // from direction
					(short) 1, // recursion level
					strBusWhere, // object where clause
					strRelWhere, // relationship where clause
					0);
			return mapListMBEs;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	private StringList getItemConnectedMBEBusSelects() {
		StringList strListBusSelects = new StringList(5);
		strListBusSelects.add(DomainConstants.SELECT_ID);
		strListBusSelects.add(DomainConstants.SELECT_REVISION);
		strListBusSelects.add(DomainConstants.SELECT_NAME);
		strListBusSelects.add("previous.id");
		
		return strListBusSelects;
	}
	private StringList getItemConnectedMBERelSelects() {
		StringList strListRelSelects = new StringList(3);
		strListRelSelects.add(DomainRelationship.SELECT_ID);
		strListRelSelects.add("attribute[WMSMBEActivityQuantity].value");
		strListRelSelects.add("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
		return strListRelSelects;
	}
	/**
	 * Method to remove  the Item to AbstractMBE
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedTasks MapList containing the Task IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public Map<String,String> removeAbstractMBEItem(Context context, String[] args) throws Exception 
	{
		try
		{
			Map<String,String> mapResult = new HashMap<String,String>();
			mapResult.put(DomainConstants.SELECT_ID, DomainConstants.EMPTY_STRING);
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
			String strAbstractMBEOID = (String) programMap.get("objectId");
			int intSize = emxTableRowId.length;
			if(emxTableRowId !=null && intSize>0&& UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID))
			{
				ArrayList<String> arrayListRelIDs 		= new ArrayList<String>(intSize);
				DomainObject domObjAbstractMBE  		= DomainObject.newInstance(context, strAbstractMBEOID);
				String strAbsTotalValue = domObjAbstractMBE.getAttributeValue(context, "WMSTotalCost");
				double doubleAbsMBETotalAmount = WMSUtil_mxJPO.convertToDouble(strAbsTotalValue);
				Map<String,String> mapQuanity = new HashMap<String,String>(intSize);
				Map<String,String> mapData ;

				MapList mapListAbsMBEConnectedObjects 	= getAbsMBEConnectedObjects(context, domObjAbstractMBE);
				Map<String, String> mapAbsMBERelData 	= getAbsMBERelData(mapListAbsMBEConnectedObjects);
				for (int i = 0; i < intSize; i++)
				{
					String[] emxTableRowIdData = emxTableRowId[i].split("[|]");
					String strItemOID = emxTableRowIdData[1];
					if(UIUtil.isNotNullAndNotEmpty(strItemOID))
					{
						//deleteTechnicalDeductions(context, strItemOID, strAbstractMBEOID);
						
                        Map<String,String> mapItemData = WMSUtil_mxJPO.getMap(mapListAbsMBEConnectedObjects, DomainConstants.SELECT_ID, strItemOID);
						StringList stsrListItemMBERelOIDs = getAbsMBESingleMBEOID(context,mapListAbsMBEConnectedObjects, strAbstractMBEOID, strItemOID);
						//DomainRelationship.setAttributeValue(context, strRelOID, ATTRIBUTE_ABS_MBE_OID, DomainConstants.EMPTY_STRING);
						HashMap<String,String> hashMapAttributeMap = new HashMap<String,String>(2);
						hashMapAttributeMap.put(ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER,"0");
						hashMapAttributeMap.put(ATTRIBUTE_WMS_ABS_MBE_OID,DomainConstants.EMPTY_STRING);
						setAbsMBEOIDOnItemsMBE(context, hashMapAttributeMap, stsrListItemMBERelOIDs);
						String strItemRelOID = mapAbsMBERelData.get(strItemOID);
						arrayListRelIDs.add(strItemRelOID);
						String strCurrentBillQuantity = mapItemData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"]");
						double doubleCurrentBillQuantity =WMSUtil_mxJPO.convertToDouble(strCurrentBillQuantity);
						//updateItemPaidQuanity(context, domObjItem, (doubleCurrentBillQuantity*-1), strAbstractMBEOID);
						mapQuanity.put(strItemOID,String.valueOf(doubleCurrentBillQuantity));
						mapQuanity.put(strItemOID+"_Rate",mapItemData.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]"));
						double doubleItemCost = updateTotalCostOfMBEItems(context,  strItemOID, mapQuanity);
						doubleAbsMBETotalAmount-=doubleItemCost;
					}

				}
				WMSUtil_mxJPO.disconnect(context, arrayListRelIDs);
				domObjAbstractMBE.setAttributeValue(context, "WMSTotalCost", String.valueOf(doubleAbsMBETotalAmount));
			}
			return mapResult;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	private MapList getAbsMBEConnectedObjects(Context context,
			DomainObject domObjAbstractMBE) throws FrameworkException {
		try
		{
			StringList strListBusSelects=new StringList(4);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_SOR_RATE+"]");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_COST+"]");
			
			StringList strListRelSelects=new StringList(5);
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			strListRelSelects.add("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
			strListRelSelects.add("attribute[MBEActivityQuantity]");
			strListRelSelects.add("from.id");
			strListRelSelects.add("attribute[MBEActivityQuantity]");

			Pattern patternRel = new Pattern(RELATIONSHIP_WORKORDER_ABSTRACT_MBE);;
			patternRel.addPattern(RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS);
			Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
			patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK_ENTRY);

			MapList mapListAbsMBEConnectedObjects = domObjAbstractMBE.getRelatedObjects(context, // matrix context
					patternRel.getPattern(), // relationship pattern
					patternType.getPattern(), // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					DomainConstants.EMPTY_STRING, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);

			return mapListAbsMBEConnectedObjects;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	private Map<String, String> getAbsMBERelData(
			MapList mapListAbsMBEConnectedObjects) {
		Map<String,String> mapAbsMBERelData = new HashMap<String, String>(mapListAbsMBEConnectedObjects.size());
		Map<String,String> mapData;
		Iterator<Map<String,String>> iterator = mapListAbsMBEConnectedObjects.iterator();
		while(iterator.hasNext())
		{
			mapData = iterator.next();
			mapAbsMBERelData.put(mapData.get(DomainConstants.SELECT_ID), mapData.get(DomainRelationship.SELECT_ID));
		}
		return mapAbsMBERelData;
	}
	private StringList getAbsMBESingleMBEOID(Context context,
			MapList mapListItemsData, String strAbstractMBEOID,
			String strItemOID) throws FrameworkException {
		StringList strListItemConnectedMBEs = new StringList();
		String strMBEOID = DomainConstants.EMPTY_STRING;
		Map<String,String> mapData ;
		Map<String,StringList> mapItemRelInfo = new HashMap<String, StringList>();
		Iterator<Map<String,String>> iterator = mapListItemsData.iterator();
		while(iterator.hasNext())
		{
			mapData = iterator.next();
			String strAbsMBEOIDValue = mapData.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
			String strItemOIDTemp =  mapData.get(DomainConstants.SELECT_ID);
			strMBEOID =  mapData.get("from.id");
			if(strAbstractMBEOID.equals(strAbsMBEOIDValue)&&strItemOIDTemp.equals(strItemOID))
			{
				String strRelOID = mapData.get(DomainRelationship.SELECT_ID);
				strListItemConnectedMBEs.add(strRelOID);
			}
		}
		return strListItemConnectedMBEs;
	}
	/**
	 * Method used to substract cost of removed items from Abs MBE
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjAbstractMBE DomainObject instance of the new Abstract MBE
	 * @param strItemOID String value containing items OID
	 * @param mapItemInfo Map<String,String> contains the ItemOID , ItemOID_Rate as key
	 * @return doubleAbsMBEItemCost double value containing the Item cost
	 * @author WMS
	 * @since 418
	 */
	private double updateTotalCostOfMBEItems(Context context,String strItemOID,Map<String, String> mapItemInfo) 
		{
			double doubleAbsMBEItemCost = 0d;
			String strRate = mapItemInfo.get((strItemOID+"_Rate"));
			double doubleRate = WMSUtil_mxJPO.convertToDouble(strRate);
			double doubleQuatity = WMSUtil_mxJPO.convertToDouble(mapItemInfo.get(strItemOID));
			doubleAbsMBEItemCost = (doubleRate*doubleQuatity);
			return doubleAbsMBEItemCost;
		}
	/**
	 * It gives quantity of MBE
	 * 
	 * @param context the eMatrix <code>Context</code> object 
	 * @param args
	 * @return Response values list
	 * @throws Exception if operation fails
	 * @author WMS
	 * @since 418
	 */
	public Vector<String> displayQuantity(Context context, String[] args)throws Exception
	{
		try
		{
			Map<String,Object> programMap =   (Map<String,Object>)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector<String> vecResponse = new Vector<String>(intSize);
			Iterator<Map<String,String>> iterator  = objectList.iterator();
			Map<String,String> mapData;
			while(iterator.hasNext())
			{
				mapData = iterator.next();
				String strAbsMBEQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
				vecResponse.add(strAbsMBEQuantity);
			}
			return vecResponse;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/**
	 * It selects the checkbox if there is a abstract MBE already connected
	 * 
	 * @param context the eMatrix <code>Context</code> object 
	 * @param args
	 * @return Response values list with true or false
	 * @throws Exception if operation fails
	 * @author WMS
	 * @since 418
	 */
	public Vector<String> autoSelect(Context context, String[] args)
			throws Exception
	{
		try{
			Map<String,Object> programMap =   (Map<String,Object>)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector<String> vecResponse = new Vector<String>(intSize);
			Iterator<Map<String,String>> iterator  = objectList.iterator();
			Map<String,String> mapData ;
			while(iterator.hasNext())
			{
				mapData = iterator.next();
				String strAbsMBEOID = mapData.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
				if(UIUtil.isNullOrEmpty(strAbsMBEOID))
				{
					vecResponse.add(String.valueOf(true));
				}
				else
				{
					vecResponse.add(String.valueOf(false));
				}
			}
			return vecResponse;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/**
	 * Method to get the Item connected MBEs WRT to Abstract MBE
	 * @mx_used On Abstract MBE paticular table
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListMBEs MapList containing the MBE IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAbsMBEItemConnectedMBEs(Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListFilterMBEs = new MapList();
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strAbstractMBEOID = (String) programMap.get("parentOID");
			String strItemOID = (String) programMap.get("objectId");
			String strRelID =(String) programMap.get("relId");

			if(strItemOID.equals(strAbstractMBEOID) && UIUtil.isNotNullAndNotEmpty(strRelID))
			{
				strAbstractMBEOID = getAbsMBEOIDFromRelOID(context,
						strRelID);
			}
			if(UIUtil.isNotNullAndNotEmpty(strItemOID)&& UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID)&&!strItemOID.equals(strAbstractMBEOID))
			{
				DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
				String strBusWhere = "current==Submitted";
				String strRelWhere = "(attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value==\""+strAbstractMBEOID+"\")";
				MapList mapListAbstractMBEConnectedMBEs =  getItemConnectedMBEs(context,domObjItem,strRelWhere,strBusWhere);
				mapListFilterMBEs = getAbsMBEItemConnectedMBEs(context,strAbstractMBEOID, mapListAbstractMBEConnectedMBEs);
				//mapListFilterMBEs = filterMBEs(mapListMBEs);
				if(mapListFilterMBEs.size()>0)
				{
					WMSMeasurementBookEntry_mxJPO.insertKeyValue(mapListFilterMBEs, DomainRelationship.SELECT_ID, strAbstractMBEOID);
				}
			}
			return mapListFilterMBEs;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	private String getAbsMBEOIDFromRelOID(Context context,
			String strRelID)
					throws FrameworkException 
	{
		try
		{
			String[] strRelIDs = {strRelID};
			String strAbstractMBEOID = DomainConstants.EMPTY_STRING;
			SelectList selListRelInfo = new SelectList(2);
			selListRelInfo.add("to.id");
			selListRelInfo.add("from.id");
			MapList mapListRelInfo = DomainRelationship.getInfo(context, strRelIDs, selListRelInfo);
			Iterator<Map<String,String>> iteratorRelInfo = mapListRelInfo.iterator();
			while(iteratorRelInfo.hasNext())
			{
				Map<String,String> mapRelInfo = iteratorRelInfo.next();
				strAbstractMBEOID = mapRelInfo.get("from.id");
			}
			return strAbstractMBEOID;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	private MapList getAbsMBEItemConnectedMBEs(Context context,
			String strAbstractMBEOID,MapList mapListAbstractMBEConnectedMBEs)
	{
		MapList mapListFilterMBEs;

		mapListFilterMBEs =  getItemFinalMBEs( strAbstractMBEOID,mapListAbstractMBEConnectedMBEs);
		mapListAbstractMBEConnectedMBEs.removeAll(mapListFilterMBEs);
		if(mapListAbstractMBEConnectedMBEs!=null && mapListAbstractMBEConnectedMBEs.size()>0)
		{
			mapListAbstractMBEConnectedMBEs.addSortKey(DomainObject.SELECT_REVISION, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
			mapListAbstractMBEConnectedMBEs.sort();

			Map<String,String> mapData;
			while(mapListAbstractMBEConnectedMBEs.size()>0)
			{
				Map<String,String> mapPivotMap = new HashMap<String, String>();
				Iterator<Map<String,String>> iterator = mapListAbstractMBEConnectedMBEs.iterator();
				mapData= iterator.next();
				String strName = mapData.get(DomainConstants.SELECT_NAME);
				MapList mapListTemp = WMSUtil_mxJPO.getSubMapList(mapListAbstractMBEConnectedMBEs, DomainConstants.SELECT_NAME, strName);
				ListIterator<Map<String,String>> iteratorTemp = mapListTemp.listIterator();
				boolean booleanPivotElement = false;
				String strAbsMBEOID = DomainConstants.EMPTY_STRING;
				String strQuantity = DomainConstants.EMPTY_STRING;
				double doubleQuantity = 0d;
				double doublePivotQuantity = 0d;
				while(iteratorTemp.hasNext())
				{
					mapData= iteratorTemp.next();
					strAbsMBEOID = mapData.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
					if(UIUtil.isNotNullAndNotEmpty(strAbsMBEOID)&& strAbstractMBEOID.equals(strAbsMBEOID))
					{
						mapPivotMap.putAll(mapData);
						booleanPivotElement = true;
						strQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
						doublePivotQuantity = WMSUtil_mxJPO.convertToDouble(strQuantity);
						strAbsMBEOID = DomainConstants.EMPTY_STRING;
					}
					if(booleanPivotElement)
					{
						if(UIUtil.isNotNullAndNotEmpty(strAbsMBEOID))
						{
							strQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
							doubleQuantity = WMSUtil_mxJPO.convertToDouble(strQuantity);
						}
					}
				}
				booleanPivotElement = false;
				mapListAbstractMBEConnectedMBEs.removeAll(mapListTemp);
				if(mapPivotMap!=null && mapPivotMap.size()>0)
				{
					mapPivotMap.put("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value",String.valueOf(doublePivotQuantity-doubleQuantity));
					mapListFilterMBEs.add(mapPivotMap);
					doubleQuantity = 0d;
					doublePivotQuantity = 0d;
				}
			}
		}
		return mapListFilterMBEs;
	}
	private MapList getItemFinalMBEs( String strAbstractMBEOID,
			MapList mapListItemConnectedMBEs) {
		MapList mapListFilterMBEs = new MapList();
		Iterator<Map<String,String>> iteratorMBEs = mapListItemConnectedMBEs.iterator();
		Map<String,String> mapData;
		while(iteratorMBEs.hasNext())
		{
			mapData = iteratorMBEs.next();
			String strAbsMBEOID = mapData.get( "attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
			if(strAbstractMBEOID.equals(strAbsMBEOID))
			{
				mapListFilterMBEs.add(mapData);
			}
		}
		return mapListFilterMBEs;
	}
	/**
	 * Method to get the MBEs connected to Item which are also not connected to any Abstract MBE
	 * @mx_used On Abstract MBE particular table
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListMBEs MapList containing the MBE IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAbsMBEItemNotConnectedMBEs(Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListFilterMBEs = new MapList();
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strAbstractMBEOID = (String) programMap.get("parentOID");
			String strItemOID = (String) programMap.get("objectId");
			String strRelID =(String) programMap.get("relId");
			if(strItemOID.equals(strAbstractMBEOID) && UIUtil.isNotNullAndNotEmpty(strRelID))
			{
				strAbstractMBEOID = getAbsMBEOIDFromRelOID(context,
						strRelID);
			}
			if(UIUtil.isNotNullAndNotEmpty(strItemOID)&& UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID)&&!strItemOID.equals(strAbstractMBEOID))
			{
				DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
				String strBusWhere = "current==Submitted";
				MapList mapListMBEs =  getItemConnectedMBEs(context,domObjItem,DomainConstants.EMPTY_STRING,strBusWhere);
				mapListFilterMBEs = getMBEWithDisableSelectionFlag(mapListMBEs,strAbstractMBEOID);
				WMSMeasurementBookEntry_mxJPO.insertKeyValue(mapListFilterMBEs, DomainRelationship.SELECT_ID, strAbstractMBEOID);
			}
			return mapListFilterMBEs;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	private MapList getMBEWithDisableSelectionFlag(MapList mapListMBEs,String strAbstractMBEOID) 
	{
		Map<String,String> mapData ;
		MapList mapListFinalMBEs = getItemFinalMBEs(mapListMBEs);
		mapListMBEs.removeAll(mapListFinalMBEs);
		WMSMeasurementBookEntry_mxJPO.insertKeyValue(mapListFinalMBEs,  "disableSelection", "false");
		
		mapListMBEs.addSortKey(DomainConstants.SELECT_NAME, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_STRING);
		mapListMBEs.addSortKey(DomainObject.SELECT_REVISION, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
		mapListMBEs.sort();
		while(mapListMBEs.size()>0)
		{
			ListIterator<Map<String,String>> iterator = mapListMBEs.listIterator();
			mapData= iterator.next();
			String strName = mapData.get(DomainConstants.SELECT_NAME);
			//Get a separate MapList based on Running MBE name.MapList size can be from 1 to N
			MapList mapListTemp = WMSUtil_mxJPO.getSubMapList(mapListMBEs, DomainConstants.SELECT_NAME, strName);
			//Iterate through he above MapList and identify if any of the revision is connected to context AbsMBE
			ListIterator<Map<String,String>> iteratorTemp = mapListTemp.listIterator();
			MapList mapListRunningMBEs = new MapList();
			boolean bConsiderEntries = true;
			while(iteratorTemp.hasNext())
			{
				mapData= iteratorTemp.next();
				String strAbsMBEOIDTemp = mapData.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
				if(UIUtil.isNotNullAndNotEmpty(strAbsMBEOIDTemp)&& strAbstractMBEOID.equals(strAbsMBEOIDTemp))
				{
					bConsiderEntries = false;
					break;
				}
				else
				{
					mapListRunningMBEs.add(mapData);
				}
			}
			//If No MBE is connected to context AbsMBE , no disable selection
			if(bConsiderEntries)
			{
				//if any of these MBEs is connected to a different Abstract MBE or not connected to any , display only latest versions with delta separated
				double doublePreviousBilledQuantity = 0d;
				iteratorTemp = mapListTemp.listIterator();
				MapList mapListLatestRunningMBEs = new MapList();
				while(iteratorTemp.hasNext())
				{
					mapData= iteratorTemp.next();
					String strPreviousBilledMBE = mapData.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
					if(UIUtil.isNotNullAndNotEmpty(strPreviousBilledMBE))
					{
						String strQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
						doublePreviousBilledQuantity = WMSUtil_mxJPO.convertToDouble(strQuantity);
						break;
					}
					else
					{
						mapListLatestRunningMBEs.add(mapData);
					}
				}
				iteratorTemp = mapListLatestRunningMBEs.listIterator();
				while(iteratorTemp.hasNext())
				{
					mapData= iteratorTemp.next();
					String strCurrentQuanity = mapData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
					double doubleCurrentBilledQuantity =  WMSUtil_mxJPO.convertToDouble(strCurrentQuanity);
					mapData.put("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value",String.valueOf((doubleCurrentBilledQuantity-doublePreviousBilledQuantity)));
				}
				mapListFinalMBEs.addAll(mapListLatestRunningMBEs);
			}
			else
			{
				WMSMeasurementBookEntry_mxJPO.insertKeyValue(mapListRunningMBEs,   "disableSelection", "true");
				mapListFinalMBEs.addAll(mapListRunningMBEs);
			}
			mapListMBEs.removeAll(mapListTemp);
		}
		return mapListFinalMBEs;
	}
	private MapList getItemFinalMBEs(MapList mapListMBEs) {
		Map<String, String> mapData;
		MapList mapListFinalMBEs =new MapList();
		ListIterator<Map<String,String>> iteratorFinal = mapListMBEs.listIterator();
		while(iteratorFinal.hasNext())
		{
			mapData= iteratorFinal.next();
			String strAbsMBEOIDTemp = mapData.get("attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value");
			if(UIUtil.isNotNullAndNotEmpty(strAbsMBEOIDTemp)==false)
			{
				mapListFinalMBEs.add(mapData);
			}
		}
		return mapListFinalMBEs;
	}
	/**
	 * Method remove the MBE's from AbstractMBE and deduce the Quantity
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedTasks MapList containing the Task IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public Map<String,String> removeExistingMBE(Context context, String[] args) throws Exception 
	{
		try
		{
			Map<String,String> mapResult = new HashMap<String,String>();
			mapResult.put(DomainConstants.SELECT_ID, DomainConstants.EMPTY_STRING);
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
			String strItemOID = (String) programMap.get("objectId");
			String strAbstractMBEOID = (String) programMap.get("parentOID");
			int intSize = emxTableRowId.length;
			if(emxTableRowId !=null && emxTableRowId.length>0)
			{
				ArrayList<String> arrayListMBEOIDs = new ArrayList<String>();
				for (int i = 0; i < intSize; i++)
				{
					String[] emxTableRowIdData = emxTableRowId[i].split("[|]");
					arrayListMBEOIDs.add(emxTableRowIdData[1]);
				}
				if(UIUtil.isNotNullAndNotEmpty(strItemOID)&& UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID)&&!strItemOID.equals(strAbstractMBEOID))
				{
					//Get the Item Rate
					DomainObject domObjAbstractMBE         = DomainObject.newInstance(context, strAbstractMBEOID);
					DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
					String strBusWhere = "current==Submitted";

					MapList mapListAbstractMBEConnectedMBEs =  getItemConnectedMBEs(context,domObjItem,DomainConstants.EMPTY_STRING,strBusWhere);
					MapList mapListFilterMBEs = getAbsMBEItemConnectedMBEs(context,strAbstractMBEOID, mapListAbstractMBEConnectedMBEs);

					if(intSize == mapListFilterMBEs.size())
					{
						Locale strLocale = context.getLocale();
						String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.MBEs.CannotRemoveMBE.Alert");			
						mapResult.put("Message", strMessage);
						return mapResult;
					}
					else
					{
						double doubleRemovalQuantity = getRemovalQuantity(context, arrayListMBEOIDs, mapListFilterMBEs);
						if(doubleRemovalQuantity!=0)
						{
							 deleteTechnicalDeductions(context, strItemOID, strAbstractMBEOID);
							
							String strItemRate = domObjItem.getAttributeValue(context, ATTRIBUTE_WMS_SOR_RATE);
							double doubleRate = WMSUtil_mxJPO.convertToDouble(strItemRate);
							//double doubleRate = updateItemPaidQuanity(context,domObjItem, (doubleRemovalQuantity*-1),strAbstractMBEOID);

							String strAbsTotalValue = domObjAbstractMBE.getAttributeValue(context, ATTRIBUTE_WMS_TOTAL_COST);
							double doubleAbsMBETotalAmount = WMSUtil_mxJPO.convertToDouble(strAbsTotalValue);
							double doubleItemCost = doubleRemovalQuantity*doubleRate;
							doubleAbsMBETotalAmount-=doubleItemCost;
							domObjAbstractMBE.setAttributeValue(context, ATTRIBUTE_WMS_TOTAL_COST, String.valueOf(doubleAbsMBETotalAmount));
		                    
							updateAbsMBEItemRelationshipAttributes(context,strItemOID, domObjAbstractMBE,(doubleRemovalQuantity*-1), doubleRate);
							Locale strLocale = context.getLocale();
							//String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.MBEs.CONNECTIONMBE.Alert");			
							mapResult.put("Message", "Selected MBEs have been removed successfully");
							return mapResult;
						}
						else
						{
							Locale strLocale = context.getLocale();
							//String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.MBEs.NoChangeinQunatity.Alert");			
							mapResult.put("Message", "No change in Quantity");
							
							return mapResult;
						}

					}
				}
				else
				{
					Locale strLocale = context.getLocale();
					String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.MBEs.NOTCONNECTIONMBE.Alert");			
					mapResult.put("Message", strMessage);
					
					return mapResult;
				}
			}
			else
			{
				Locale strLocale = context.getLocale();
				String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.MBEs.NOTCONNECTIONMBE.Alert");			
				mapResult.put("Message", strMessage);
				
				return mapResult;
			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	
	
	/**
	 * Method to get the Item connected technical reductions WRT to Abstract MBE and delete the technical deductions
	 * @param context the eMatrix <code>Context</code> object
	 * @param strAbstractMBEOID String value containing the Abstract MBE OID
	 * @param strItemOID String value containing the Item OID
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private void deleteTechnicalDeductions(Context context, String strItemOID, String strAbstractMBEOID)
			throws  Exception {
		try
		{
			MapList mapListTechnicalDeductions = getItemConnectedTechnicalReductions(context, strAbstractMBEOID, strItemOID);
			StringList strListTechnicalDeductionsOIDs =WMSUtil_mxJPO.convertToStringList(mapListTechnicalDeductions, DomainConstants.SELECT_ID);
			ArrayList<String> arrayListOIDs = new ArrayList<String>(strListTechnicalDeductionsOIDs.size());
			arrayListOIDs.addAll(strListTechnicalDeductionsOIDs);
		   DomainObject.deleteObjects(context, arrayListOIDs.toArray(new String[arrayListOIDs.size()]));
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	
	
	private double getRemovalQuantity(Context context,
			ArrayList<String> arrayListMBEOIDs, MapList mapListFilterMBEs)
					throws FrameworkException {
		try
		{
			Map<String, String> mapData;
			Iterator<Map<String,String>> iterator = mapListFilterMBEs.iterator();
			double doubleRemovalQuantity =0d;
			while(iterator.hasNext())
			{
				mapData = iterator.next();
				String strMBEID = mapData.get(DomainConstants.SELECT_ID);
				if(arrayListMBEOIDs.contains(strMBEID))
				{
					String strMBEItemRelID= mapData.get(DomainRelationship.SELECT_ID);
					String strQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
					doubleRemovalQuantity+= WMSUtil_mxJPO.convertToDouble(strQuantity);
					HashMap<String,String> hashMapAttributes     = new HashMap<String, String>();
					hashMapAttributes.put(ATTRIBUTE_WMS_ABS_MBE_OID, DomainConstants.EMPTY_STRING);
					//hashMapAttributes.put(ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER,DomainConstants.EMPTY_STRING);
		            ContextUtil.pushContext(context, "User Agent",DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
					try
					{
					DomainRelationship.setAttributeValues(context, strMBEItemRelID, hashMapAttributes);
				}
					catch(Exception exception)
					
					{
						
					}
					finally
					{
						ContextUtil.popContext(context);
					}
				}
			}
			return doubleRemovalQuantity;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	private void updateAbsMBEItemRelationshipAttributes(Context context,
			String strItemOID, DomainObject domObjAbstractMBE,
			double doubleRemovalQuantity, double doubleRate)
					throws FrameworkException {
		try
		{
			MapList mapListAbsMBEConnectedObjects 	= getAbsMBEConnectedObjects(context, domObjAbstractMBE);
			Map<String, String> mapAbsMBERelData 	= getAbsMBEItemRelData(mapListAbsMBEConnectedObjects,strItemOID);
			String strAbsMBEItemRelID = mapAbsMBERelData.get(DomainRelationship.SELECT_ID);
			String strBillQuanity = mapAbsMBERelData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"]");
			double doubleBillQuantity = WMSUtil_mxJPO.convertToDouble(strBillQuanity);
			double doubleFinalQunaity = doubleBillQuantity+doubleRemovalQuantity;
			HashMap<String,String> hashMapAttributes     = new HashMap<String, String>();
			hashMapAttributes.put(ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY, String.valueOf(doubleFinalQunaity));
			hashMapAttributes.put(ATTRIBUTE_WMS_ABS_MBE_ITEM_COST,String.valueOf(doubleFinalQunaity*doubleRate));
			DomainRelationship.setAttributeValues(context, strAbsMBEItemRelID, hashMapAttributes);
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	private Map<String, String> getAbsMBEItemRelData(
			MapList mapListAbsMBEConnectedObjects,String strItemOID) {
		Map<String,String> mapAbsMBERelData = new HashMap<String, String>();
		Map<String,String> mapData;
		Iterator<Map<String,String>> iterator = mapListAbsMBEConnectedObjects.iterator();
		while(iterator.hasNext())
		{
			mapData = iterator.next();
			String strId= mapData.get(DomainConstants.SELECT_ID);
			if(strItemOID.equals(strId))
			{
				mapAbsMBERelData.putAll(mapData);
				break;
			}

		}
		return mapAbsMBERelData;
	}
	private int getUniqueMBECount(Context context,
			ArrayList<String> arrayListMBEOIDs) throws FrameworkException {
		StringList strListUnique = new StringList();
		StringList strListInfo = new StringList(DomainConstants.SELECT_NAME);
		String [] strMBEIds = arrayListMBEOIDs.toArray(new String[arrayListMBEOIDs.size()]);
		MapList mapListMBEInfo = DomainObject.getInfo(context, strMBEIds, strListInfo);
		Iterator<Map<String,String>> iterator = mapListMBEInfo.iterator();
		Map<String,String> mapData ;
		while(iterator.hasNext())
		{
			mapData = iterator.next();
			String strName = mapData.get(DomainConstants.SELECT_NAME);
			if(!strListUnique.contains(strName))
			{
				strListUnique.add(strName);
			}
		}
		int intSelectedObjectSize = strListUnique.size();
		return intSelectedObjectSize;
	}
	/**
	 * Method add the MBE's and to AbstractMBE
	 * @mxUsed Used as toolbar command from the link on the since previous bill column under Bill->Partiiculars
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedTasks MapList containing the Task IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public Map<String,String> addExistingMBE(Context context, String[] args) throws Exception 
	{
		try
		{
			Map<String,String> mapResult = new HashMap<String,String>();
			mapResult.put(DomainConstants.SELECT_ID, DomainConstants.EMPTY_STRING);
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
			String strItemOID = (String) programMap.get("objectId");
			String strAbstractMBEOID = (String) programMap.get("parentOID");
			int intSize = emxTableRowId.length;
			if(emxTableRowId !=null && emxTableRowId.length>0)
			{
				ArrayList<String> arrayListMBEOIDs = new ArrayList<String>();

				for (int i = 0; i < intSize; i++)
				{
					String[] emxTableRowIdData = emxTableRowId[i].split("[|]");
					arrayListMBEOIDs.add(emxTableRowIdData[1]);
				}
				int intSelectedObjectSize = getUniqueMBECount(context,arrayListMBEOIDs);
				if(intSelectedObjectSize!=intSize)
				{
					Locale strLocale = context.getLocale();
					String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.alert.AddingMBE.SameRunningMBE");			
					mapResult.put("Message", strMessage);
					
					return mapResult;
				}
				else if(arrayListMBEOIDs.size()>0)
				{
					DomainObject domObjAbstractMBE 			= DomainObject.newInstance(context, strAbstractMBEOID);
					DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
					String strBusWhere = "current==Submitted";
					String strRelWhere = "(attribute["+ATTRIBUTE_WMS_ABS_MBE_OID+"].value==\"\")";
					String strItemRate = domObjItem.getAttributeValue(context, ATTRIBUTE_WMS_SOR_RATE);
					double doubleRate = WMSUtil_mxJPO.convertToDouble(strItemRate);
					MapList mapListMBEs 					= getItemConnectedMBEs(context,domObjItem,strRelWhere,strBusWhere);
					MapList mapListFilterMBEs 				= getMBEWithDisableSelectionFlag(mapListMBEs,strAbstractMBEOID);
					double doubleAdditionalQuantity = getAdditionalQuantity(context, arrayListMBEOIDs, mapListFilterMBEs,domObjAbstractMBE);
					if(doubleAdditionalQuantity!=0)
					{
						String strAbsTotalValue = domObjAbstractMBE.getAttributeValue(context, ATTRIBUTE_WMS_TOTAL_COST);
						double doubleAbsMBETotalAmount = WMSUtil_mxJPO.convertToDouble(strAbsTotalValue);
						double doubleItemCost = doubleAdditionalQuantity*doubleRate;
						doubleAbsMBETotalAmount+=doubleItemCost;
						domObjAbstractMBE.setAttributeValue(context, ATTRIBUTE_WMS_TOTAL_COST, String.valueOf(doubleAbsMBETotalAmount));
						
						updateAbsMBEItemRelationshipAttributes(context,strItemOID, domObjAbstractMBE,doubleAdditionalQuantity, doubleRate);
						Locale strLocale = context.getLocale();
						String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.MBEs.CONNECTIONMBE.CheckAlert");			
						mapResult.put("Message", strMessage);
						
						return mapResult;
					}
					else
					{
						Locale strLocale = context.getLocale();
						String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.MBEs.NoChangeinQunatity.Alert");			
						mapResult.put("Message", strMessage);
						return mapResult;
					}
				}
				else
				{
					Locale strLocale = context.getLocale();
					String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.MBEs.NOTCONNECTIONMBE.CheckAlert");			
					mapResult.put("Message", strMessage);
					return mapResult;
				}
			}
			else
			{
				Locale strLocale = context.getLocale();
				String strMessage = EnoviaResourceBundle.getProperty(context,"emxProgramCentralStringResource", strLocale, "emxProgramCentral.MBEs.NOTCONNECTIONMBE.CheckAlert");			
				mapResult.put("Message", strMessage);
				return mapResult;
			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	private double getAdditionalQuantity(Context context,
			ArrayList<String> arrayListMBEOIDs, MapList mapListFilterMBEs,DomainObject domOBjAbsMBE)
					throws FrameworkException {
		try
		{
			StringList strListAbsMBEInfo = new StringList(2);
			strListAbsMBEInfo.add(DomainConstants.SELECT_ID);
			strListAbsMBEInfo.add("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"]");
			Map<String,String> mapAbsMBEData = domOBjAbsMBE.getInfo(context, strListAbsMBEInfo);
			String strAbsMBEOID = mapAbsMBEData.get(DomainConstants.SELECT_ID);
			String strSequenceOrder = mapAbsMBEData.get("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"]");
			Map<String, String> mapData;
			Iterator<Map<String,String>> iterator = mapListFilterMBEs.iterator();
			double doubleRemovalQuantity =0d;
			while(iterator.hasNext())
			{
				mapData = iterator.next();
				String strMBEID = mapData.get(DomainConstants.SELECT_ID);
				if(arrayListMBEOIDs.contains(strMBEID))
				{
					String strMBEItemRelID= mapData.get(DomainRelationship.SELECT_ID);
					String strQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY+"].value");
					doubleRemovalQuantity+= WMSUtil_mxJPO.convertToDouble(strQuantity);
					HashMap<String,String> hashMapAttributes     = new HashMap<String, String>();
					hashMapAttributes.put(ATTRIBUTE_WMS_ABS_MBE_OID, strAbsMBEOID);
					hashMapAttributes.put(ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER,strSequenceOrder);
					
	            ContextUtil.pushContext(context, "User Agent",DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
					try
					{
					DomainRelationship.setAttributeValues(context, strMBEItemRelID, hashMapAttributes);
				}
					catch(Exception exception)
					
					{
						
					}
					finally
					{
						ContextUtil.popContext(context);
					}
				}
			}
			return doubleRemovalQuantity;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	/**
     * This method is used to show Technical Deduction in current Bill on particulars
     * @param context the eMatrix <code>Context</code> object
     * @param args
     * @returns Vector containing column data.
     * @throws Exception if the operation fails
     */
    public Vector getTDInCurrentBill(Context context, String[] args) throws Exception {
    	try {
    		 
			// Get object list information from packed arguments
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			
		 	Map paramList      = (HashMap) programMap.get("paramList");
		 	Map columnMap =  (Map) programMap.get("columnMap");
		  	String strColumnName =  (String) columnMap.get("name");
		  	String strAttribute=ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT;
		     if(strColumnName!=null && strColumnName.equalsIgnoreCase("PayableAmount"))
		     {
		    	 strAttribute=ATTRIBUTE_WMS_TOTAL_PAYABLE_AMOUNT;
		     }
			MapList objectList = (MapList) programMap.get("objectList");
			String strAbsId = (String)paramList.get("parentOID");
			StringList strListBusSelects = new StringList();
			strListBusSelects.add("attribute["+strAttribute+"].value");
			strListBusSelects.add("to[WMSItemTechnicalDeduction].from.id");
			Map<String, String> mapTechTask = new HashMap<>();
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			if(UIUtil.isNotNullAndNotEmpty(strAbsId)) {
				DomainObject domAbs = DomainObject.newInstance(context, strAbsId);
				MapList mlTech = domAbs.getRelatedObjects(context, // matrix context
		                "WMSAbstractMBETechnicalDeduction", // relationship pattern
		                "WMSTechnicalDeduction", // type pattern
		                strListBusSelects, // object selects
		                new StringList(DomainRelationship.SELECT_ID), // relationship selects
		                false, // to direction
		                true, // from direction
		                (short) 1, // recursion level
		                DomainConstants.EMPTY_STRING, // object where clause
		                DomainConstants.EMPTY_STRING, // relationship where clause
		                0);
				if(mlTech.size()>0) {
					String strDeductionAmount="";
					float fstrQty=0.0F;
					float fstrTotal=0.0F;
					Iterator<Map<String, String>> iteratorMap = mlTech.iterator();
					Map<String, String> mapObjectData = new HashMap<String, String>();
					while (iteratorMap.hasNext()) {
						mapObjectData = iteratorMap.next();
						strDeductionAmount = mapObjectData.get("attribute["+strAttribute+"].value");
						fstrQty = Float.valueOf(strDeductionAmount);
						String strTaskId = mapObjectData.get("to[WMSItemTechnicalDeduction].from.id");
						if(UIUtil.isNotNullAndNotEmpty(strDeductionAmount)) {
					 		mapTechTask.put(strTaskId, strDeductionAmount);
						}
					}
				}
			}
			
			Iterator<Map<String, String>> objectListIterator = objectList.iterator();
			Map<String, String> mapObjecListData = new HashMap<String, String>();
			String strSORRate = DomainConstants.EMPTY_STRING;
			String strPayableQty = DomainConstants.EMPTY_STRING;
			double fMBEQty = 0d;
			double fReduceRate = 0d;
			double fSinceAmount = 0d;
			DecimalFormat df1 = new DecimalFormat("#.##"); 
			while(objectListIterator.hasNext()) {
				mapObjecListData = objectListIterator.next();
				String strTaskId = mapObjecListData.get("id");
				String strMapDeductionAmount = mapTechTask.get(strTaskId);
				if(UIUtil.isNotNullAndNotEmpty(strMapDeductionAmount)) {
					
					vecResponse.add(new BigDecimal(Double.valueOf(strMapDeductionAmount)).setScale(2, BigDecimal.ROUND_UP).toPlainString());
				}else {
					strSORRate = (String)mapObjecListData.get("attribute[WMSReducedSORRate].value");
					strPayableQty = (String)mapObjecListData.get("attribute[WMSAbstractMBEItemPayableQuantity].value");
					if(UIUtil.isNotNullAndNotEmpty(strSORRate) && UIUtil.isNotNullAndNotEmpty(strPayableQty) && UIUtil.isNotNullAndNotEmpty(strColumnName) && strColumnName.equalsIgnoreCase("PayableAmount")){
		    
						fMBEQty = WMSUtil_mxJPO.convertToDouble(strPayableQty);
						fReduceRate = WMSUtil_mxJPO.convertToDouble(strSORRate);
						fSinceAmount = fMBEQty * fReduceRate;
						vecResponse.add(new BigDecimal(fSinceAmount).setScale(2, BigDecimal.ROUND_UP).toPlainString());
					}else{
						vecResponse.add("0.00");
					}
				}
			}
			 return vecResponse;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    	
    }
    /**
     * This method is used to show Technical Deduction Release in current Bill on particulars
     * @param context the eMatrix <code>Context</code> object
     * @param args
     * @returns Vector containing column data.
     * @throws Exception if the operation fails
     */
    public Vector getTDReleaseInCurrentBill(Context context, String[] args) throws Exception {
    	try {
   		 
			// Get object list information from packed arguments
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			Map paramList      = (HashMap) programMap.get("paramList");
			
			MapList objectList = (MapList) programMap.get("objectList");
			String strAbsId = (String)paramList.get("parentOID");
			StringList strListBusSelects = new StringList();
			strListBusSelects.add("to[WMSItemTechnicalDeduction].from.id");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add("attribute[WMSTechnicalDeductionReleaseCurrentBill].value");
			Map<String, String> mapTechTask = new HashMap<>();
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			if(UIUtil.isNotNullAndNotEmpty(strAbsId)) {
				DomainObject domAbs = DomainObject.newInstance(context, strAbsId);
				MapList mlTech = domAbs.getRelatedObjects(context, // matrix context
		                "WMSAbstractMBETechnicalDeductionRelease", // relationship pattern
		                "WMSTechnicalDeduction", // type pattern
		                strListBusSelects, // object selects
		                strListRelSelects, // relationship selects
		                false, // to direction
		                true, // from direction
		                (short) 1, // recursion level
		                DomainConstants.EMPTY_STRING, // object where clause
		                DomainConstants.EMPTY_STRING, // relationship where clause
		                0);
				if(mlTech.size()>0) {
					Iterator<Map<String, String>> iteratorMap = mlTech.iterator();
					Map<String, String> mapObjectData = new HashMap<String, String>();
					while (iteratorMap.hasNext()) {
						mapObjectData = iteratorMap.next();
						String strDeductionReleaseAmount = mapObjectData.get("attribute[WMSTechnicalDeductionReleaseCurrentBill].value");
						String strTaskId = mapObjectData.get("to[WMSItemTechnicalDeduction].from.id");
						if(UIUtil.isNotNullAndNotEmpty(strDeductionReleaseAmount)) {
							if(mapTechTask.containsKey(strTaskId)){
								String strOldAmount = mapTechTask.get(strTaskId);
								double dUpdatedAmount = Double.parseDouble(strDeductionReleaseAmount)+Double.parseDouble(strOldAmount);
								strDeductionReleaseAmount = String.valueOf(dUpdatedAmount);
							}
							mapTechTask.put(strTaskId, strDeductionReleaseAmount);
						}
					}
				}
			}
			
			Iterator<Map<String, String>> objectListIterator = objectList.iterator();
			Map<String, String> mapObjecListData = new HashMap<String, String>();
			while(objectListIterator.hasNext()) {
				mapObjecListData = objectListIterator.next();
				String strTaskId = mapObjecListData.get("id");
				String strMapDeductionReleaseAmount = mapTechTask.get(strTaskId);
				if(UIUtil.isNotNullAndNotEmpty(strMapDeductionReleaseAmount)) {					
					vecResponse.add(strMapDeductionReleaseAmount);
				}else {
					vecResponse.add("0.0");
				}
			}
			 return vecResponse;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    }
    /**
	 * Method to get the Item connected technical reductions WRT to Abstract MBE
	 * @param context the eMatrix <code>Context</code> object
	 * @param strAbstractMBEOID String value containing the Abstract MBE OID
	 * @param strItemOID String value containing the Item OID
	 * @return mapListMBEs MapList containing the MBE IDs
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private MapList getItemConnectedTechnicalReductions(Context context, String strAbstractMBEOID, String strItemOID)
			throws FrameworkException {
		try
		{
			MapList mapListFilterMBEs;
			String strBusWhere = "relationship["+RELATIONSHIP_WMS_ABSMBE_TECHNICALDEDUCTION+"].from.id=="+strAbstractMBEOID;
			DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
			StringList strListBusSelects=new StringList(1);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_QUANTITY+"]");
			StringList strListRelSelects=new StringList(1);
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mapListFilterMBEs = domObjItem.getRelatedObjects(context, // matrix context
					RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION, // relationship pattern
					TYPE_WMS_TECHNICAL_DEDUCTION, // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					strBusWhere, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
			return mapListFilterMBEs;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	/**
	 * Method to get the check if the context user has access for the Reductions
	 * @mx_used On WMSTechnicalDeductionToolbar under technical reductions table toolbar
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return booleanAccess boolean containing if access is there or not
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public boolean isAbstractMBEEditable(Context context, String[] args) throws Exception 
	{
		try
		{
			boolean booleanAccess =false;
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strAbstractMBEOID = (String) programMap.get("parentOID");
			String strItemOID = (String) programMap.get("objectId");
			String strRelID =(String) programMap.get("relId");
			if(strItemOID.equals(strAbstractMBEOID) && UIUtil.isNotNullAndNotEmpty(strRelID))
			{
				strAbstractMBEOID = getAbsMBEOIDFromRelOID(context,
						strRelID);
			}
			if(UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID))
			{
				DomainObject domObjAbsMBE = DomainObject.newInstance(context, strAbstractMBEOID);
				StringList strListSelects = new StringList(2);
				strListSelects.add(DomainConstants.SELECT_CURRENT);
				strListSelects.add("relationship["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				Map<String,String> mapAbsMBEInfo = domObjAbsMBE.getInfo(context, strListSelects);
				String strWorkOrderID =  mapAbsMBEInfo.get("relationship["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				String strAbsMBEState = mapAbsMBEInfo.get(DomainConstants.SELECT_CURRENT);
				boolean booleanRelatedUser = checkContextUserWOVisibility(context, strWorkOrderID);
				if(booleanRelatedUser && !(STATE_APPROVED.equals(strAbsMBEState)|| STATE_PLAN.equals(strAbsMBEState)))
				{
					booleanAccess = true;
				}
			}
			return booleanAccess;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/**
	 * checks if the context user is member of the W/O
	 * @param context the eMatrix <code>Context</code> object
	 * @param strWorkOrderID String containing the WO OID
	 * @return booleanRelatedUser boolean value false if context user is not member of W/O
	 * @author WMS
	 * @since 418
	 **/
	private boolean checkContextUserWOVisibility(Context context, String strWorkOrderID) throws FrameworkException {
		boolean booleanRelatedUser = false;
		try
		{
			String strContextUser = context.getUser();
			ContextUtil.pushContext(context);
			MapList mapListMembers = WMSMeasurementBookItem_mxJPO.getWorkOrderAssignees(context, strWorkOrderID);
			ListIterator<Map<String,String>> membersItr = mapListMembers.listIterator();
			Map<String,String> memberMap;
			while(membersItr.hasNext())
			{
				memberMap = membersItr.next();
				String strRoleUser = (String)memberMap.get(Person.SELECT_NAME);
				if(strContextUser.equals(strRoleUser))
				{
					booleanRelatedUser = true;
					break;
				}
			}
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
		}
		finally
		{
			ContextUtil.popContext(context);
		}
		return booleanRelatedUser;
	}
	/**
	 * Method to restrict the visibility of add/edit/remove buttons of technical deduction if ABS MBE is not in create state when context user is Sub-Engineer 
	 * @mx_used On WMSTechnicalDeductionToolbar under technical reductions table toolbar
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return booleanAccess boolean containing if access is there or not
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public boolean toMakeTechnicalDeductionToolbarActionsVisible(Context context, String[] args) throws Exception 
	{
		try
		{
			boolean booleanAccess =false;
			String strContextUser = context.getUser();
			String userContextUserID           = PersonUtil.getPersonObjectID(context, strContextUser);
            
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strAbstractMBEOID = (String) programMap.get("parentOID");
			
			/*DomainObject domObjContextUser = DomainObject.newInstance(context, userContextUserID);
			DomainObject domObjAbsMBE = DomainObject.newInstance(context, strAbstractMBEOID);
			*/
			StringList strListSelects = new StringList(2);
			strListSelects.add(DomainConstants.SELECT_CURRENT);
			//strListSelects.add("attribute["+DomainConstants.ATTRIBUTE_PROJECT_ROLE+"]");
			
			
			String[] objectIds = {userContextUserID,strAbstractMBEOID};
			MapList membersList = DomainObject.getInfo(context, objectIds,strListSelects);
			
			String strAbsMBEStateMap = DomainConstants.EMPTY_STRING;
			String strAbsMBEState = DomainConstants.EMPTY_STRING;
			String strContextUserRoleMap = DomainConstants.EMPTY_STRING;
			String strContextUserRole = DomainConstants.EMPTY_STRING;
			
			if(membersList.size()>0)
			{
				Iterator<Map<String,String>> iterator  = membersList.iterator();
				Map<String,String> mapData;
			
				while(iterator.hasNext())
				{
					mapData =  iterator.next();
					strAbsMBEStateMap = mapData.get(DomainConstants.SELECT_CURRENT);
					//strContextUserRoleMap = mapData.get("attribute["+DomainConstants.ATTRIBUTE_PROJECT_ROLE+"]");
					
					//if("Sub Engineer".equals(strContextUserRoleMap)){
					//	strContextUserRole = strContextUserRoleMap;
					//}
					if("Create".equals(strAbsMBEStateMap)){
						strAbsMBEState = strAbsMBEStateMap;
					}
					
				}
			}
			if("Create".equals(strAbsMBEState))//&&"Sub Engineer".equals(strContextUserRole))
			{
				booleanAccess = true;
			}
			else
			{
				booleanAccess = false;
			}
			return booleanAccess;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/** 
	 * Method will create technical deduction
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps for the table
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */

	public Map<String,String> createTechnicalDeduction(Context context, String[] args) throws Exception 
	{
		Map<String,String> mapResult = new HashMap(2);
		mapResult.put("Result", DomainConstants.EMPTY_STRING);
		mapResult.put("Message", DomainConstants.EMPTY_STRING);
		try 
		{
			HashMap programMap      = (HashMap) JPO.unpackArgs(args);
			String strItemOID = (String)programMap.get("objectId");
			String strAbsMBEOID = (String)programMap.get("parentOID");
			String strRelOID = (String)programMap.get("relId");
			if(UIUtil.isNotNullAndNotEmpty(strItemOID)&& UIUtil.isNotNullAndNotEmpty(strAbsMBEOID)&&UIUtil.isNotNullAndNotEmpty(strRelOID))
			{
				MapList mapListTechnicalDeductions = getItemConnectedTechnicalReductions(context, strAbsMBEOID, strItemOID, strRelOID);
				String strTechnicalDeductionOID  = FrameworkUtil.autoName(context,
						"type_WMSTechnicalDeduction",
						"policy_WMSTechnicalDeduction");
				if(UIUtil.isNotNullAndNotEmpty(strTechnicalDeductionOID))
				{
					DomainObject domObjTechnicalDeduction = DomainObject.newInstance(context, strTechnicalDeductionOID);
					DomainObject domObjAbsMBE = DomainObject.newInstance(context, strAbsMBEOID);
					DomainObject domObjItem = DomainObject.newInstance(context, strItemOID);
					String strBilledQuanity = DomainRelationship.getAttributeValue(context, strRelOID, ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY);
					if(UIUtil.isNullOrEmpty(strBilledQuanity))
					{
						strBilledQuanity="0.00";
					}
					double doubleRemainigQty = getTechnicalDeductionsQuantity(context, strBilledQuanity,
							mapListTechnicalDeductions);
					if(doubleRemainigQty>0)
					{
						setTechnicalDeductionAttribute(context, domObjTechnicalDeduction, domObjItem, doubleRemainigQty,strBilledQuanity);
						try
						{
						ContextUtil.pushContext(context);
						DomainRelationship.connect(context, domObjAbsMBE, RELATIONSHIP_WMS_ABSMBE_TECHNICALDEDUCTION, domObjTechnicalDeduction);
						}
						finally
						{
							ContextUtil.popContext(context);
						}
						String strNewRelOID = connectItemAndTechnicalDeduction(context, domObjItem, domObjTechnicalDeduction);
						if(UIUtil.isNotNullAndNotEmpty(strNewRelOID))
						{
							StringBuffer strBuffer = new StringBuffer();
							strBuffer.append("<mxRoot>");
							strBuffer.append("<action><![CDATA[add]]></action>");
							strBuffer.append("<data status=\"committed\">");
							strBuffer.append("<item oid=\""+strTechnicalDeductionOID+"\" relId=\""+strNewRelOID+"\"   direction=\"\" />");
							strBuffer.append("</data>");
							strBuffer.append("</mxRoot>");
							mapResult.put("Result",strBuffer.toString());
						}
						else
						{
							mapResult.put("Message", "An error occured while connecting technical deduction and Item");;
						}
					}
					else
					{
						String strTechnicalDeductionQuantityWarning = EnoviaResourceBundle.getProperty(context, "wmsStringResource", context.getLocale(),"WMS.WarningMessage.ExecedingBillQuantity");
						mapResult.put("Message", strTechnicalDeductionQuantityWarning);
					}
				}
				else
				{
					mapResult.put("Message",  "An error occured while creating technical deduction");
				}
			}
			else
			{
				mapResult.put("Message",  "Couldn't process data");
			}

		} catch (Exception exception) {
			exception.printStackTrace();
			mapResult.put("Message", "An error occured while creating technical deduction");;
		}
		return mapResult;
	}
	/**
	 * Method to get the Item connected technical reductions WRT to Abstract MBE
	 * @mx_used On Abstract MBE particular technical reduction table table
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListMBEs MapList containing the MBE IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getItemConnectedTechnicalReductions(Context context, String[] args) throws Exception 
	{
		try
		{
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strAbstractMBEOID = (String) programMap.get("parentOID");
			String strItemOID = (String) programMap.get("objectId");
			String strRelID =(String) programMap.get("relId");
			if(strItemOID.equals(strAbstractMBEOID) && UIUtil.isNotNullAndNotEmpty(strRelID))
			{
				strAbstractMBEOID = getAbsMBEOIDFromRelOID(context,
						strRelID);
			}
			MapList mapListFilterMBEs = getItemConnectedTechnicalReductions(context, strAbstractMBEOID, strItemOID,
					strRelID);
			return mapListFilterMBEs;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/**
	 * Method to get the Item connected technical reductions WRT to Abstract MBE
	 * @param context the eMatrix <code>Context</code> object
	 * @param strAbstractMBEOID String value containing the Abstract MBE OID
	 * @param strItemOID String value containing the Item OID
	 * @param strRelID String value containing the relationship ID between Item and Abstract MBE
	 * @return mapListMBEs MapList containing the MBE IDs
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private MapList getItemConnectedTechnicalReductions(Context context, String strAbstractMBEOID, String strItemOID,
			String strRelID) throws FrameworkException {
		try
		{
			MapList mapListFilterMBEs = new MapList();
			if(UIUtil.isNotNullAndNotEmpty(strItemOID)&& UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID)&&!strItemOID.equals(strAbstractMBEOID))
			{
				String strBilledQuanity = DomainRelationship.getAttributeValue(context, strRelID, ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY);

				mapListFilterMBEs = getItemConnectedTechnicalReductions(context, strAbstractMBEOID, strItemOID);
				WMSMeasurementBookEntry_mxJPO.insertKeyValue(mapListFilterMBEs, ATTRIBUTE_WMS_ITEM_ENTRY_QUANTITY, strBilledQuanity);
			}
			return mapListFilterMBEs;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	/** 
	 * Method will overallDeduction quantity
	 * @param context the eMatrix <code>Context</code> object
	 * @param strBilledQuanity String value containing the Quantity billed against the item
	 * @param mapListTechnicalDeductions MapList containing Technical Deductions
	 * @return doubleTDQuantity double value containing the overallDeduction quantity
	 * @author WMS
	 * @since 418
	 */
	private double getTechnicalDeductionsQuantity(Context context, String strBilledQuanity, MapList mapListTechnicalDeductions)
	{
		double doubleBilledQuantity = WMSUtil_mxJPO.convertToDouble(strBilledQuanity);
		double doubleTDQuantity = 0d;
		Map<String,String> mapData ;
		Iterator<Map<String,String>> iterator = mapListTechnicalDeductions.iterator();
		while(iterator.hasNext())
		{
			mapData = iterator.next();
			String strTechnicalDeductionQuantity = mapData.get("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_QUANTITY+"]");

			doubleTDQuantity+=WMSUtil_mxJPO.convertToDouble(strTechnicalDeductionQuantity);
		}
		double doubleRemainigQty =  doubleBilledQuantity-doubleTDQuantity;
		return doubleRemainigQty;
	}
	/** 
	 * Method set the attributes on technical deduction
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjItem String DomainObject instance of Item
	 * @param domObjTechnicalDeduction DomainObject instance of newly created technical deduction
	 * @param doubleRemainigQty double value containing the Quantity
	 * @param strBilledQuanity String value containing the billed quantity
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private void setTechnicalDeductionAttribute(Context context, DomainObject domObjTechnicalDeduction,
			DomainObject domObjItem, double doubleRemainigQty,String strBilledQuanity) throws FrameworkException {
		try
		{
			Map<String,String> hashMapAttributes = new HashMap<String,String>(5);
			hashMapAttributes.put(ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_TYPE,"PayableLater");
			hashMapAttributes.put(ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_BILL_AMOUNT,strBilledQuanity);
			if(doubleRemainigQty>0)
			{
				String strRate = domObjItem.getAttributeValue(context, ATTRIBUTE_WMS_SOR_RATE);
				double doubleRate = WMSUtil_mxJPO.convertToDouble(strRate);
				double doubleAmount = doubleRate*doubleRemainigQty;
				//hashMapAttributes.put(ATTRIBUTE_TECHNICAL_DEDUCTION_AMOUNT, new BigDecimal(doubleAmount).toPlainString());
				hashMapAttributes.put(ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_QUANTITY,Double.toString(doubleRemainigQty));
				hashMapAttributes.put(ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RATE,Double.toString(doubleRate));
			}
			domObjTechnicalDeduction.setAttributeValues(context, hashMapAttributes);
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	/** 
	 * Method will connect Item and Technical Deduction
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjItem DomainObject instance of Item
	 * @param domObjTechnicalDeduction DomainObject instance of newly created technical deduction
	 * @return strRelOID String value containing the rel ID between Item and Transaction
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private String connectItemAndTechnicalDeduction(Context context, DomainObject domObjItem, DomainObject domObjTechnicalDeduction)
			throws  Exception {
		try
		{
			String strRelOID = DomainConstants.EMPTY_STRING;

			DomainRelationship domObjRel = DomainRelationship.connect(context, domObjItem, RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION, domObjTechnicalDeduction);
			StringList strListRelSelects=new StringList(1);
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			Map<String,Object> mapRelData = domObjRel.getRelationshipData(context, strListRelSelects);
			if(mapRelData!=null && !mapRelData.isEmpty())
			{
				StringList strListRelID = (StringList)mapRelData.get(DomainRelationship.SELECT_ID);
				if(strListRelID!=null && strListRelID.size() > 0)
				{
					strRelOID = (String)strListRelID.get(0);
				}
			}
			return strRelOID;
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/***************** Technical Deduduction starts *****************************************************************************************************/
	
	
	/**
	 * Method to get the connected technical deduction under the items which are connected to Abstract MBE
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedTDs MapList containing the connected technical deductions
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAbstractMBETechnicalDeductions (Context context, String[] args) throws Exception 
	{

		try
		{
			MapList mapListConnectedTDs = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjAbsMBE = DomainObject.newInstance(context, strObjectId);
				//Map<String, String> mapBillAmount = getAbsMBEConnectedItemsBillAmount(context, domObjAbsMBE);
				mapListConnectedTDs = getAbstractMBETechnicalDeductions(context, domObjAbsMBE);
				//putTDConnectedItemsBillAmount(mapListConnectedTDs, mapBillAmount);
			}
			return mapListConnectedTDs;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}

	}
	
	
	/**
	 * Method to get the Technical Deduction connected to Items WRT to abstract
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjAbsMBE DomainObject instance of context Abstract MBE
	 * @return mapListTDs MapList containing the Technical Deduction
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private MapList getAbstractMBETechnicalDeductions(Context context, DomainObject domObjAbsMBE)
			throws FrameworkException {
		try
		{
			StringList strListBusSelects     = new StringList(2);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add("relationship["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id");
			StringList strListRelSelects     = new StringList(1);
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			MapList mapListTDs = domObjAbsMBE.getRelatedObjects(context, // matrix context
					RELATIONSHIP_WMS_ABSMBE_TECHNICALDEDUCTION, // relationship pattern
					TYPE_WMS_TECHNICAL_DEDUCTION, // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					DomainConstants.EMPTY_STRING, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
			return mapListTDs;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	
	
	/**
	 * Method to get the Technical Deduction released against the context bill
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedReleasedTDs MapList containing the released technical deductions against the bill
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAbstractMBEReleasedTechnicalDeductions (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListConnectedReleasedTDs = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjAbsMBE = DomainObject.newInstance(context, strObjectId);
				mapListConnectedReleasedTDs = getAbstractMBEReleasedTechnicalDeductions(context, domObjAbsMBE);
			}
			return mapListConnectedReleasedTDs;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	
	/**
	 * Method to get the Technical Deduction released against the context bill
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjAbsMBE DomainObject instance of context Abstract MBE
	 * @return mapListReleasedTDs MapList containing the released Technical Deduction
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	private MapList getAbstractMBEReleasedTechnicalDeductions(Context context, DomainObject domObjAbsMBE)
			throws FrameworkException {
		try
		{
			StringList strListBusSelects     = new StringList(2);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add("to["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT+"]");
			
			StringList strListRelSelects     = new StringList(2);
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			strListRelSelects.add("attribute["+ATTRIBUTE_WMS_CURRENT_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
			strListRelSelects.add("attribute["+ATTRIBUTE_WMS_PREVIOUS_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
			MapList mapListReleasedTDs = domObjAbsMBE.getRelatedObjects(context, // matrix context
					RELATIONSHIP_WMS_ABSMBE_TECHNICAL_DEDUCTION_RELEASE, // relationship pattern
					TYPE_WMS_TECHNICAL_DEDUCTION, // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					DomainConstants.EMPTY_STRING, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
		
			return mapListReleasedTDs;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	
	/**
	 * Method to get the technical deduction which are eligible for release in the current bill
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command
	 * @return mapListConnectedTDs MapList containing the connected technical deductions
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getEligibleTechnicalDeductions (Context context, String[] args) throws Exception 
	{

		try
		{
			MapList mapListConnectedTDs = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjAbstractMBE = DomainObject.newInstance(context, strObjectId);

				String strWorkOrderOID	 	= domObjAbstractMBE.getInfo(context, "relationship["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id"); 
				if(UIUtil.isNotNullAndNotEmpty(strWorkOrderOID))
				{
					//MapList mapListCUrrentBuillTDs = getAbstractMBETechnicalDeductions(context, domObjAbstractMBE);
					//StringList strListCurrentBillTDs = ${CLASS:WMSUtil}.convertToStringList(mapListCUrrentBuillTDs, DomainConstants.SELECT_ID);
					StringList strListCurrentBillTDs = domObjAbstractMBE.getInfoList(context, "from["+RELATIONSHIP_WMS_ABSMBE_TECHNICAL_DEDUCTION_RELEASE+"].to.id");

					//String strWhere = "(attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_TYPE+"].value==\"PayableLater\")&&(attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT+"] > attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"])";
					String strWhere = "";
					MapList mapListTDs = getWorkOrderConnectedTechnicalDeductions(context, strWorkOrderOID, strWhere);

					MapList mlRefinedList = new MapList();
					Map mTemp = null;
					String strDeductAmount = DomainConstants.EMPTY_STRING;
					String strDeductReleasedAmount = DomainConstants.EMPTY_STRING;
					for(int i=0;i<mapListTDs.size();i++){
						mTemp = (Map)mapListTDs.get(i);
						strDeductAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT+"]");
						strDeductReleasedAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
						
						if(Double.parseDouble(strDeductAmount) > Double.parseDouble(strDeductReleasedAmount)){
							mlRefinedList.add(mTemp);
						}
					}
					
					mapListConnectedTDs = getEligibleTechnicalDeductions(strListCurrentBillTDs, mlRefinedList);

				}
			}
			return mapListConnectedTDs;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
 



/** 
 * Method will get all deductions connected to the WO
 * @param context the eMatrix <code>Context</code> object
 * @param strWorkOrderOID String value containing the work order connected to the Abstract MBE
 * @param strWhere String value containing the BUS filter for technical deductions
 * @return mapListTDs MapList containing the Technical deductions connected to Abstract MBE through MBE
 * @throws FrameworkException if the operation fails
 * @author WMS
 * @since 418
 */
private MapList getWorkOrderConnectedTechnicalDeductions(Context context, String strWorkOrderOID, String strWhere)
		throws FrameworkException {
	try
	{
		DomainObject domObjWO = DomainObject.newInstance(context, strWorkOrderOID);
		StringList strListBusSelects     = new StringList();
		strListBusSelects.add(DomainConstants.SELECT_ID);
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT+"]");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
		StringList strListRelSelects     = new StringList();
		strListRelSelects.add(DomainRelationship.SELECT_ID);
		MapList mapListTDs = domObjWO.getRelatedObjects(context, // matrix context
				RELATIONSHIP_WMS_WO_TECHNICAL_DEDUCTION, // relationship pattern
				TYPE_WMS_TECHNICAL_DEDUCTION, // type pattern
				strListBusSelects, // object selects
				strListRelSelects, // relationship selects
				false, // to direction
				true, // from direction
				(short) 1, // recursion level
				strWhere, // object where clause
				DomainConstants.EMPTY_STRING, // relationship where clause
				0);
		return mapListTDs;
	}
	catch(FrameworkException frameworkException)
	{
		frameworkException.printStackTrace();
		throw frameworkException;
	}
}

/** 
 * Method will get all technical deductions eligible for release
 * @param strListCurrentBillTDs StringList containing the current bill technical deductions.These shouldn't be displayed
 * @param mapListWOTDs MapList<Map<String,String>> containing the technical deduction which are connected to the WO of current bill
 * @return mapListTDs MapList containing the Technical deductions eligible for release
 * @throws FrameworkException if the operation fails
 * @author WMS
 * @since 418
 */
private MapList getEligibleTechnicalDeductions(StringList strListCurrentBillTDs, MapList mapListWOTDs) {
	MapList mapListConnectedTDs = new MapList();
	Iterator<Map<String,String>> iterator = mapListWOTDs.iterator();
	Map<String,String> mapData;
	while(iterator.hasNext())
	{
		mapData = (Map<String,String>)iterator.next();
		String strOID = mapData.get(DomainConstants.SELECT_ID);
		if(!strListCurrentBillTDs.contains(strOID))
		{
			mapListConnectedTDs.add(mapData);
		}
	}
	return mapListConnectedTDs;
}


/** 
 * Method will sets the release amount on technical deduction as till date reduction on relationship
 * 
 * @param context the eMatrix <code>Context</code> object    
 * @throws Exception if the operation fails
 * @author WMS
 * @since 418
 */
public void setTillDateTechnicalDeductionReleaseAmount(Context context, String[] args) throws Exception 
{
    try 
    {
        String strTDOID = args[0];
        String srrRELOID = args[1];
        String strAbsMBEId = args[2];
        if(UIUtil.isNotNullAndNotEmpty(strTDOID)&&UIUtil.isNotNullAndNotEmpty(srrRELOID))
        {
        	DomainObject domObjTD = DomainObject.newInstance(context, strTDOID);
        	String strValue = domObjTD.getAttributeValue(context, ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RELEASE_AMOUNT);
        	String strTotalDeductionValue = domObjTD.getAttributeValue(context, ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT);
        	if(UIUtil.isNullOrEmpty(strValue))
        	{
        		strValue = "0.0";
        	}
			if(UIUtil.isNullOrEmpty(strTotalDeductionValue))
        	{
        		strTotalDeductionValue = "0.0";
        	}
			
			Double dDeductionRelease = Double.parseDouble(strValue);
			Double dTechnicalDeduction = Double.parseDouble(strTotalDeductionValue);
			Double dBalanceRelease = dTechnicalDeduction - dDeductionRelease;
			
        	Map<String,String> mapAttributeMap = new HashMap<String,String>(2);
        	mapAttributeMap.put(ATTRIBUTE_WMS_PREVIOUS_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT, strValue);
        	mapAttributeMap.put(ATTRIBUTE_WMS_CURRENT_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT, String.valueOf(dBalanceRelease));
        	DomainRelationship.setAttributeValues(context, srrRELOID, mapAttributeMap);
			
			if(UIUtil.isNotNullAndNotEmpty(strAbsMBEId)){
				DomainObject doAbsMBE = new DomainObject(strAbsMBEId);
				StringList slBOQList = doAbsMBE.getInfoList(context,"from["+RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS+"].to.id");
				String strItemId = (String)domObjTD.getInfo(context,"to["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id");
				if(slBOQList.contains(strItemId) == false)
					DomainRelationship.connect(context,doAbsMBE, RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS,new DomainObject(strItemId));
			}
        }
    }
    catch(Exception exception)
    {
    	System.out.println("An Exception while connected Technical deduction to Current Bill as release");
        exception.printStackTrace();
        throw exception;            
    }
}

/**  Trigger on ABSMBE Policy state Create Action , send notification to Sector Manager/Project in Charged 
 * 
 * @param context
 * @param args
 * @throws Exception
 */

public void sendAMBApprovalNotification(Context context,String[] args) throws Exception
{
	try {
			String strABSMBDOid = args[0];
			 MailUtil.setTreeMenuName(context, "type_WMSAbstractMeasurementBookEntry");
			DomainObject domABSMBE= DomainObject.newInstance(context, strABSMBDOid);
			StringList slInfo=new StringList();
			slInfo.add("to["+RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.to["+RELATIONSHIP_WMS_PROJECT_WORK_ORDER+"].from.id");
			slInfo.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
		 	Map mInfo = domABSMBE.getInfo(context, slInfo);
			String strProjectId  =(String) mInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.to["+RELATIONSHIP_WMS_PROJECT_WORK_ORDER+"].from.id");
			String strABSMBETitle=(String) mInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
			
			ProjectSpace project = (ProjectSpace) DomainObject.newInstance(context,
			DomainConstants.TYPE_PROJECT_SPACE, DomainConstants.PROGRAM);
			project.setId(strProjectId);
			StringList busSelects = new StringList(2);
			busSelects.add(DomainConstants.SELECT_NAME);
			StringList relSelects = new StringList(2);
			relSelects.add(MemberRelationship.SELECT_PROJECT_ROLE);
			 
		    StringBuilder sbRelWhere = new StringBuilder();
		    sbRelWhere.append( "attribute[").append(DomainConstants.ATTRIBUTE_PROJECT_ROLE).append("]=='ProjectInCharge'").append(" || ");
		    sbRelWhere.append( "attribute[").append(DomainConstants.ATTRIBUTE_PROJECT_ROLE).append("]=='SectionManager'");
		  	MapList membersList = project.getMembers(context, busSelects, relSelects, null, sbRelWhere.toString());
			StringList slToPersonList = new StringList();
			Iterator<Map> itr = membersList.iterator();
			while(itr.hasNext()) {
				slToPersonList.add((String)((Map) itr.next()).get(DomainConstants.SELECT_NAME));
		 	}
			
			if(slToPersonList.size()>0) {
				  StringBuilder sbSubject = new StringBuilder();
		          sbSubject.append("Measurement Bill Book : ").append(strABSMBETitle).append(" has been submitted");
				  StringBuilder sbMessage = new StringBuilder();
			      sbMessage.append(" Measurement Bill Book  ");
		          sbMessage.append(strABSMBETitle);
				  sbMessage.append( "has been submitted :-  ");
				  StringList slObjectIdList = new StringList(1);
		          slObjectIdList.addElement(strABSMBDOid);
		          MailUtil.sendMessage(context,slToPersonList,null,null,sbSubject.toString(),sbMessage.toString(),slObjectIdList);
				
			}
		 
	}catch(Exception e) {
		e.printStackTrace();
	}






 }
/** 
 * Method will connect technical deduction to Work Order
 * @param context the eMatrix <code>Context</code> object
 * @param args Packed program and request maps for the table
 * @throws Exception if the operation fails
 * @author WMS
 * @since 418
 */
public void connectTechnicalDeduction(Context context, String[] args) throws Exception 
{
	try
	{
		String strAbsMBEOID = args[0];
		if(UIUtil.isNotNullAndNotEmpty(strAbsMBEOID))
		{
			DomainObject domObjAbsMBE = DomainObject.newInstance(context, strAbsMBEOID);
			MapList mapListMBEs = getAbstractMBETechnicalDeductions(context, domObjAbsMBE);
			StringList strListTechnicalDeductionsOIDs = WMSUtil_mxJPO.convertToStringList(mapListMBEs, DomainConstants.SELECT_ID);
			String sWorkOrderOid = domObjAbsMBE.getInfo(context, "to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
			DomainObject domObjWO = DomainObject.newInstance(context, sWorkOrderOid);
			ArrayList<String> arrayListOIDs = new ArrayList<String>(strListTechnicalDeductionsOIDs.size());
			arrayListOIDs.addAll(strListTechnicalDeductionsOIDs);
			try
			{
				//ContextUtil.pushContext(context);
				WMSUtil_mxJPO.connect(context, domObjWO, RELATIONSHIP_WMS_WO_TECHNICAL_DEDUCTION, true, arrayListOIDs);
			}
			finally
			{
				//ContextUtil.popContext(context);
			}
		}
	}
	catch(Exception exception)
	{
		exception.printStackTrace();
		throw exception;
	}
}
/**
 * Method add the Item to AbstractMBE
 * @param context the eMatrix <code>Context</code> object
 * @param args Packed program and request maps from the command
 * @return mapListConnectedTasks MapList containing the Task IDs
 * @throws Exception if the operation fails
 * @author WMS
 * @since 418
 */
@com.matrixone.apps.framework.ui.ProgramCallable
public Map<String, String> addTechnicalReductionRelease(Context context, String[] args) throws Exception {
	Map<String, String> mapResult = new HashMap<String, String>();
	try 
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
		String strAbstractMBEOID = (String) programMap.get("parentOID");
		if( UIUtil.isNotNullAndNotEmpty(strAbstractMBEOID))
		{
			Map<String,String> mParsedRowId ;
			ArrayList<String> arrayListOIDs = new ArrayList();
			int intLength = emxTableRowId.length;
			for (int i = 0; i < intLength; i++) 
			{
				mParsedRowId = ProgramCentralUtil.parseTableRowId(context,emxTableRowId[i]);
				String strSelectedOid = (String) mParsedRowId.get("objectId");
				arrayListOIDs.add(strSelectedOid);
			}
			DomainObject domObjAbsMBE = DomainObject.newInstance(context, strAbstractMBEOID);
			WMSUtil_mxJPO.connect(context, domObjAbsMBE, RELATIONSHIP_WMS_ABSMBE_TECHNICAL_DEDUCTION_RELEASE, true, arrayListOIDs);
		}
		return mapResult;
	} catch (Exception exception) {
		System.out.println("Exception in adding a technical deduction as a release in particulars under Abstract MBE");
		exception.printStackTrace();
		throw exception;
	}
}
/** 
 * Method will update the technical release amount on the released technical deductions in the current bill
 * @param context the eMatrix <code>Context</code> object
 * @param args Packed program and request maps for the table
 * @throws Exception if the operation fails
 * @author WMS
 * @since 418
 */
public void updateTechnicalDeductionReleaseAmount(Context context, String[] args) throws Exception 
{
	try
	{
		String strAbsMBEOID = args[0];
		if(UIUtil.isNotNullAndNotEmpty(strAbsMBEOID))
		{
			DomainObject domObjAbsMBE = DomainObject.newInstance(context, strAbsMBEOID);
			MapList mapListMBEs = getAbstractMBEReleasedTechnicalDeductions(context, domObjAbsMBE);
			Iterator<Map<String,String>> iterator = mapListMBEs.iterator();
			Map<String,String> mapData ;
			while(iterator.hasNext())
			{
				mapData = iterator.next();
				String strTDOID = mapData.get(DomainConstants.SELECT_ID);
				String strReleasedAmount = mapData.get("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
				String strCurrentBillReleasedAmount = mapData.get("attribute["+ATTRIBUTE_WMS_CURRENT_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
				double doubleReleasedAmount = WMSUtil_mxJPO.convertToDouble(strReleasedAmount);
				double doubleCurrentBillReleasedAmount = WMSUtil_mxJPO.convertToDouble(strCurrentBillReleasedAmount);
				doubleReleasedAmount=doubleReleasedAmount + doubleCurrentBillReleasedAmount;
				DomainObject domObjTD = DomainObject.newInstance(context, strTDOID);
				//TO HANDLE BIG CALCULATION : EXPONENTIAL ISSUE
				domObjTD.setAttributeValue(context, ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_RELEASE_AMOUNT, new BigDecimal(doubleReleasedAmount).toPlainString());
			}
		}
	}
	catch(Exception exception)
	{
		exception.printStackTrace();
		throw exception;
	}
}
/**
 * Function to get Items Abstract MBE(Submitted)
 *
 * @param context the eMatrix <code>Context</code> object
 * @param domObjItem DomainObject instance of selected Item
 * @return mapListTasks MapList containing the MBEs connected to Work Order with ID
 * @author WMS
 * @throws Exception 
 * @since 418
 */
@com.matrixone.apps.framework.ui.ProgramCallable
public MapList getSubmittedOnAbstractMBEs(Context context, String args[]) throws Exception {    		
	MapList mapListMBEs = new MapList();
	try
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String strItemID             = (String) programMap.get("objectID");

		if(strItemID==null ||  "".equals(strItemID)|| "null".equals(strItemID))
		{
			strItemID             = (String) programMap.get("objectId");
		}

		if(strItemID !=null &&  !"".equals(strItemID) && !"null".equals(strItemID))
		{
			String strwhere = "("+DomainConstants.SELECT_CURRENT+"==Approved"+")||("+DomainConstants.SELECT_CURRENT+"==Paid)";
			SelectList selListBusSelects     = new SelectList(1);
			selListBusSelects.add(DomainConstants.SELECT_ID);
			SelectList selListRelSelects     = new SelectList(1);
			selListRelSelects.add(DomainRelationship.SELECT_ID);				
			DomainObject domObjItem 		= DomainObject.newInstance(context,strItemID);
			mapListMBEs 					= domObjItem.getRelatedObjects(context, // matrix context
					RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS, // relationship pattern
					TYPE_ABSTRACT_MBE, // type pattern
					selListBusSelects, // object selects
					selListRelSelects, // relationship selects
					true, // to direction
					false, // from direction
					(short) 1, // recursion level
					strwhere, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
		}			
	}
	catch(Exception exception)
	{
		exception.printStackTrace();
		throw exception;
	}		
	return mapListMBEs;
}


public Boolean isAMBEditable (Context context, String[] args) throws Exception 
	{
		Boolean bReturn = false ;
		try 
		{
			HashMap programMap 			= (HashMap)JPO.unpackArgs(args);
			String sParentOid 		= (String)programMap.get("objectId");
			if(sParentOid==null)
			  sParentOid 		= (String)programMap.get("parentOID");
			if(UIUtil.isNotNullAndNotEmpty(sParentOid))
			{ 
			String strContextUser = context.getUser();
			String strABSEditAllowedRoles = EnoviaResourceBundle.getProperty(context,"WMS.AbsMBE.EditRoles");
 			 	DomainObject doMBE = new DomainObject(sParentOid);
				String strType = doMBE.getInfo(context, DomainConstants.SELECT_TYPE);
				if(!strType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY))
					if(strType.equalsIgnoreCase(DomainConstants.TYPE_INBOX_TASK)) {
						sParentOid=	 doMBE.getInfo(context, "from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.to["
									+ DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.id");
					}
					
					if(strType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_TASK)) {
						sParentOid 	= (String)programMap.get("parentOID");
					}
					
					doMBE.setId(sParentOid);
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_OWNER);
				slSelect.add(DomainObject.SELECT_CURRENT);
				slSelect.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				Map mObjInfo = doMBE.getInfo(context,slSelect);
				String strOwner = (String)mObjInfo.get(DomainObject.SELECT_OWNER);
				String strState = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);
				if(UIUtil.isNotNullAndNotEmpty(strOwner) && strContextUser.equals(strOwner) && "Create".equals(strState)){
					bReturn = true;					
				}else{
				 
					if("Review".equals(strState)) {
					String mqlQuery = "print bus "+sParentOid+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
					String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
					if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
						mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name dump";
						String strUser = MqlUtil.mqlCommand(context, mqlQuery);
						if(UIUtil.isNotNullAndNotEmpty(strUser) && strUser.contains(strContextUser)){
							String strWOId = (String)mObjInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");

							if(UIUtil.isNotNullAndNotEmpty(strWOId)){
								String strRole = MqlUtil.mqlCommand(context,"print bus "+strWOId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+strContextUser+"'].attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value dump");
								String command ="print bus "+strWOId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+strContextUser+"'].attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value dump";

								if(UIUtil.isNotNullAndNotEmpty(strRole) && strABSEditAllowedRoles.contains(strRole)){
									bReturn = true;
								}
							}
						}
					}
				  }
				}				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return bReturn;
	}	
	
public String getExecutionIntervalHeader(Context context, String[] args) throws Exception {
	StringBuilder sb = new StringBuilder();
	sb.append("<table>");
	sb.append("<th><b>");
	sb.append("Execution Interval");
	sb.append("</b></th>");
	sb.append("</table>");
	return sb.toString();
	}
	
public int updateTotalBill(Context context,String[] args) throws Exception
	{
	try {	  
		String strContectUser =  context.getUser();
		String strAbsMBEId = args[0];
		MapList paymentItemMaplist = new MapList();	
		if(UIUtil.isNotNullAndNotEmpty(strAbsMBEId)){
			DomainObject doAbsMBE = DomainObject.newInstance(context,strAbsMBEId);
			StringList sList = new StringList();
			sList.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
			sList.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
			Map valueMap = doAbsMBE.getInfo(context,sList);
			
			String strTypeOfContract = (String)valueMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
			String strValueOfContract = (String)valueMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
			double dWMSPreviousAmount = 0.0;
			double dTotalAmount = 0.0;
			if (strValueOfContract != null && !"".equals(strValueOfContract)){
				dWMSPreviousAmount = Double.parseDouble(strValueOfContract);
			}
			String strTypeName = "";
			String strRelName = "";
			if(strTypeOfContract != null && !"".equals(strTypeOfContract) && strTypeOfContract.equals("EPC")){
				strTypeName = TYPE_WMS_PAYMENT_ITEM;
				strRelName = RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS;
			}else{
				return 0;
			}
			
			StringList objList = new StringList();
			objList.addElement(DomainConstants.SELECT_ID);
			objList.addElement(DomainConstants.SELECT_NAME);
			objList.addElement("attribute["+ATTRIBUTE_WMSPAYMENTITEM_AMOUNT+"]");
			objList.addElement("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
			
			StringList relList = new StringList();
			relList.addElement(DomainRelationship.SELECT_ID);
			relList.addElement("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
			
			paymentItemMaplist = doAbsMBE.getRelatedObjects(context, // matrix context
						strRelName, // relationship pattern
						strTypeName, // type pattern
						objList, // object selects
						relList, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
			Iterator itr = paymentItemMaplist.iterator();
			while(itr.hasNext()){
				Map paymentMap = (Map)itr.next();
				String strPreviousQuantity = (String)paymentMap.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
				double dWMSPreviousQuantity = Double.parseDouble(strPreviousQuantity);
				if(strTypeOfContract != null && !"".equals(strTypeOfContract) && strTypeOfContract.equals("EPC")){	
				double dPreviousAmount = dWMSPreviousAmount * dWMSPreviousQuantity / 100;
					dTotalAmount = dTotalAmount + dPreviousAmount;
				}			
			}
			
			doAbsMBE.setAttributeValue(context, "WMSTotalCost", String.valueOf(dTotalAmount));
		
		}
		
	}catch(Exception e){
		e.printStackTrace();
	} 
	return 0;
}

@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getQualityCertificates (Context context, String[] args) throws Exception 
	{
		try
		{
			String strUser = context.getUser();
			MapList mlAllConnectedTasks = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjAbstractMBE= DomainObject.newInstance(context, strObjectId);
				
				StringList slObjectSelect = new StringList();
				slObjectSelect.add(DomainObject.SELECT_ID);
				slObjectSelect.add(DomainObject.SELECT_NAME);
				slObjectSelect.add(DomainObject.SELECT_OWNER);
				
				StringList slRelSelect = new StringList();
				slRelSelect.add(DomainRelationship.SELECT_ID);
				
				
				mlAllConnectedTasks = domObjAbstractMBE.getRelatedObjects(context, // matrix context
						RELATIONSHIP_WMS_BILL_QUALITY_CERTIFICATES, // relationship pattern
						CommonDocument.TYPE_DOCUMENT, // type pattern
						slObjectSelect, // object selects
						slRelSelect, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
						
				Map mTemp = null;
				String strOwner = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlAllConnectedTasks.size();i++){
					mTemp = (Map)mlAllConnectedTasks.get(i);
					strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
					if(UIUtil.isNotNullAndNotEmpty(strOwner) && strOwner.equals(strUser)==false){
						mTemp.put("disableSelection", "true");	
					}
				}
				
			}
			return mlAllConnectedTasks;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}


public Boolean hasQualityCertificateAccess (Context context, String[] args) throws Exception 
	{
		Boolean bReturn = false ;
		try 
		{
			DomainObject doMBE = null;
			HashMap programMap 			= (HashMap)JPO.unpackArgs(args);
			String sParentOid 		= (String)programMap.get("parentOID");
			String strType = DomainConstants.EMPTY_STRING;
			if(sParentOid==null){
			  sParentOid 		= (String)programMap.get("objectId");
			}
			else{
			  doMBE = new DomainObject(sParentOid);
			  strType = doMBE.getInfo(context, DomainConstants.SELECT_TYPE);
			  if(!strType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY) && !strType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY)){
				  sParentOid 		= (String)programMap.get("objectId");
			  }
			}
			if(UIUtil.isNotNullAndNotEmpty(sParentOid))
			{ 
			String strContextUser = context.getUser();
			String strABSEditAllowedRoles = EnoviaResourceBundle.getProperty(context,"WMS.WorkOrder.QualityCertificates.Role");
 			 	doMBE = new DomainObject(sParentOid);
				strType = doMBE.getInfo(context, DomainConstants.SELECT_TYPE);
				String strCurrent = doMBE.getInfo(context, DomainConstants.SELECT_CURRENT);
				if(!strType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY))
					doMBE.setId(sParentOid);
				
				if(strType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY)){
					Map packArgs=new HashMap();		
					packArgs.put("objectId", sParentOid); 
					Boolean isEditable = (Boolean)JPO.invoke(context,"WMSMeasurementBookEntry",null,"isMBEditable",JPO.packArgs(packArgs),Boolean.class);	
					return isEditable;
				}
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_OWNER);
				slSelect.add(DomainObject.SELECT_CURRENT);
				slSelect.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				Map mObjInfo = doMBE.getInfo(context,slSelect);
				
				String strOwner = (String)mObjInfo.get(DomainObject.SELECT_OWNER);
				String strState = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);
				if("Review".equals(strState)) {
					String mqlQuery = "print bus "+sParentOid+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
					String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
					if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
						mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name dump";
						String strUser = MqlUtil.mqlCommand(context, mqlQuery);
						if(UIUtil.isNotNullAndNotEmpty(strUser) && strUser.equals(strContextUser)){
							String strWOId = (String)mObjInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
							if(UIUtil.isNotNullAndNotEmpty(strWOId)){
								String strCommand = "print bus "+strWOId+" select to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+strContextUser+"'].attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"].value dump";
								String strRole = MqlUtil.mqlCommand(context,strCommand);
								if(UIUtil.isNotNullAndNotEmpty(strRole) && strABSEditAllowedRoles.contains(strRole)){
									bReturn = true;
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return bReturn;
	}	

	/**
      * update function
      * updates Measurement Title
      * @param context
      * @param args new title for Measurement and object id of measurement
      *    objectId - Measurement id
      *    New Value -Title
      * @throws Exception if the operation fails
      */
     public void updateRemarkOnParticular (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_ASSESSMENT_COMMENTS, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	
/** 
 * Table column program to show Current bill release amount 
 * 
 * @param context
 * @param args
 * @return
 * @throws Exception
 */

public Vector<String> getTechDeductionInCurrentBillDefaultValue(Context context, String[] args) throws Exception {
	Vector vecResponse  = new Vector();
	try{
		Map<String,Object> programMap =   (Map<String,Object>)JPO.unpackArgs(args);
		MapList objectList = (MapList)programMap.get("objectList");
		int intSize = objectList.size();
		Iterator<Map<String,String>> iterator  = objectList.iterator();
		Map<String,String> mapData ;
		String strCurrentBill=DomainConstants.EMPTY_STRING;
		String strDedAmount=DomainConstants.EMPTY_STRING;
		String strDedAmountInLastBill=DomainConstants.EMPTY_STRING;
		double dInCurrentBill=0.00;
		DecimalFormat decFor = new DecimalFormat("#.##");
		while(iterator.hasNext())
		{
			mapData = iterator.next();
			strCurrentBill = (String) mapData.get("attribute["+ATTRIBUTE_WMS_CURRENT_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
			if(Double.parseDouble(strCurrentBill)==0) {
				strDedAmount = (String) mapData.get("attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT+"]");
				strDedAmountInLastBill = (String) mapData.get("attribute["+ATTRIBUTE_WMS_PREVIOUS_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"]");
				vecResponse.add(decFor.format(Double.parseDouble(strDedAmount)-Double.parseDouble(strDedAmountInLastBill)));
				
			}else {
				vecResponse.add(strCurrentBill);
			}
		}
		return vecResponse;
	}
	catch(Exception exception)
	{
		exception.printStackTrace();
		throw exception;
	}
}	

 public void updateRemarkOnParticularEPC (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_REMARK, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 public void updateRemarkOnOtherDeduction (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_HEAD_DEDUCTION_REMARKS, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 
	 public void updateRemarkOnRecovery (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_RECOVERY_REMARKS, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 
	 
	 public void updateRemarkOnAdvance (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_ADVANCE_REMARKS, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 public void updateRemarkOnBillReduction (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_BILL_REDUCTION_REMARK, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 
	  public void updateRemarkOnBillReductionRelease (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_BILL_REDUCTION_RELEASE_REMARK, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	  public void updateRemarkReduction (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_BILL_REDUCTION_REMARK, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }

 public String checkQualityCertificateAdded(Context context,String[] args) throws Exception
	{
	try {	  
		String strContectUser =  context.getUser();
		String strTaskId = args[0];
		String strAMBObjectId = DomainConstants.EMPTY_STRING;	
		if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
			String strMqlQuery = "print bus "+strTaskId+" select from["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|from.type=='"+TYPE_ABSTRACT_MBE+"'].from.id dump";
			strAMBObjectId = MqlUtil.mqlCommand(context,strMqlQuery);
			if(UIUtil.isNotNullAndNotEmpty(strAMBObjectId)){
				DomainObject doAbsMBE = new DomainObject(strAMBObjectId);

				String strTypeOfContract = (String)doAbsMBE.getInfo(context,"attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value");
				
				String strBillItems = DomainConstants.EMPTY_STRING;
				if("EPC".equals(strTypeOfContract)){
					strBillItems = (String)MqlUtil.mqlCommand(context,"print bus "+strAMBObjectId+" select from["+RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS+"].to.id dump");
				}else{
					strBillItems = (String)MqlUtil.mqlCommand(context,"print bus "+strAMBObjectId+" select from["+RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS+"].to.id dump");		
				}
				
				if(UIUtil.isNullOrEmpty(strBillItems)){
					return DomainConstants.EMPTY_STRING;					
				}
				
				strMqlQuery = "print bus "+strAMBObjectId+" select to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|from.name=='"+context.getUser()+"'].attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"].value dump";
				String strWorkOrderRole = MqlUtil.mqlCommand(context,strMqlQuery);
				if(UIUtil.isNotNullAndNotEmpty(strWorkOrderRole) && "TPQA".equals(strWorkOrderRole)){
					strMqlQuery = "print bus "+strAMBObjectId+" select from["+RELATIONSHIP_WMS_BILL_QUALITY_CERTIFICATES+"].to.id dump";
					String strQCids = MqlUtil.mqlCommand(context,strMqlQuery);
					if(UIUtil.isNullOrEmpty(strQCids)){
						String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.QualityCertificate.NA");	
						return strMessage;
					}
				}					
			}
		}
	}catch(Exception e){
		e.printStackTrace();
	} 
	return DomainConstants.EMPTY_STRING;
} 
	 
	 @com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getMeasurementAbstractForValidated(Context context, String[] args) throws Exception 
	{
		MapList mapListFilterMBEs = new MapList();
		try
		{
			
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strAbstractMBEOID = (String) programMap.get("parentOID");
			String strItemOID = (String) programMap.get("objectId");
			String strRelID =(String) programMap.get("relId");
			
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainObject.SELECT_ID);
			slObjSelect.add(DomainObject.SELECT_TYPE);
			slObjSelect.add(DomainObject.SELECT_CURRENT);
			slObjSelect.add("attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"]");
			slObjSelect.add("attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"]");
			DomainObject doMeas = null;
			if(UIUtil.isNotNullAndNotEmpty(strItemOID)){
				String strWhere = "from.attribute["+ATTRIBUTE_WMS_SE_VALIDATED+"].value == Yes || from.attribute["+ATTRIBUTE_WMS_EE_VALIDATED+"].value == Yes";
				String strMqlCommand = "print bus "+strItemOID+" select to["+RELATIONSHIP_WMS_MBE_ACTIVITIES+"].tomid["+RELATIONSHIP_WMS_ACTIVITY_MEASUREMENTS+"|"+strWhere+"].from.id dump |";
				String strResult = MqlUtil.mqlCommand(context,strMqlCommand);
				if(UIUtil.isNotNullAndNotEmpty(strResult)){
					StringList slMeasurementList = FrameworkUtil.split(strResult, "|");
					Map mTemp = null;
					for(int i=0;i<slMeasurementList.size();i++){
						doMeas = new DomainObject((String)slMeasurementList.get(i));
						mTemp = (Map)doMeas.getInfo(context,slObjSelect);
						mapListFilterMBEs.add(mTemp);
					}
				}				
			}	
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
		return mapListFilterMBEs;
	}
	
	public Map getBillDetailsForBill(Context context, String[] args)throws Exception{
		Map mReturn = new HashMap();	

		String strBillId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);

		Map packArgs=new HashMap();		
		packArgs.put("objectId", strBillId); 
		MapList mlAdvances = (MapList)JPO.invoke(context,"WMSAdvanceRecovery",null,"getAdvances",JPO.packArgs(packArgs),MapList.class);		
		MapList mlSecuredAdvances = (MapList)JPO.invoke(context,"WMSMaterial",null,"getSecuredRecoveryStock",JPO.packArgs(packArgs),MapList.class);		
		MapList mlRecovery = (MapList)JPO.invoke(context,"WMSAdvanceRecovery",null,"getRecoveries",JPO.packArgs(packArgs),MapList.class);		
		MapList mlWithHeld = (MapList)JPO.invoke(context,"WMSBillReduction",null,"getReduction",JPO.packArgs(packArgs),MapList.class);
		MapList mlWithHeldRelease = (MapList)JPO.invoke(context,"WMSBillReduction",null,"getReductionRelease",JPO.packArgs(packArgs),MapList.class);
		MapList mlRetentionRelease = (MapList)JPO.invoke(context,"WMSAdvanceRecovery",null,"getPayments",JPO.packArgs(packArgs),MapList.class);
		MapList mlOtherDeductions = (MapList)JPO.invoke(context,"WMSOtherHeadDeductions",null,"getOtherHeadDeductions",JPO.packArgs(packArgs),MapList.class);
		MapList mlLDs = (MapList)JPO.invoke(context,"WMSBillReduction",null,"getLDs",JPO.packArgs(packArgs),MapList.class);
		MapList mlLDRelease = (MapList)JPO.invoke(context,"WMSBillReduction",null,"getLDRelease",JPO.packArgs(packArgs),MapList.class);
		MapList mlRoyaltyCharges = (MapList)JPO.invoke(context,"WMSRoyaltyCharges",null,"getAllRoyaltyCharges",JPO.packArgs(packArgs),MapList.class);
		MapList mlRateEscaltions = (MapList)JPO.invoke(context,"WMSRoyaltyCharges",null,"getAllRateEscalations",JPO.packArgs(packArgs),MapList.class);
		MapList mlOtherAdditions = (MapList)JPO.invoke(context,"WMSBillOtherAdditions",null,"getAllBillOtherAdditions",JPO.packArgs(packArgs),MapList.class);
		double dAdvance = 0;
		double dWithHeld = 0;
		double dWithHeldRelease = 0;
		double dRetention = 0;
		double dRecovery = 0;
		double dRecoveryInterest = 0;
		double dOtherDeduction = 0;
		double dLiquidatedDamage = 0;
		double dLiquidatedDamageRelease = 0;
		double dRoyalty = 0;
		double dRateEscaltion = 0;
		double dOtherAddition = 0;
		Map mTemp = null;
		String strAmount = DomainConstants.EMPTY_STRING;
		String strDescription = DomainConstants.EMPTY_STRING;
		String strAmountInterest = DomainConstants.EMPTY_STRING;
		for(int i=0;i<mlAdvances.size();i++){
			mTemp = (Map)mlAdvances.get(i);
			strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
			if(UIUtil.isNotNullAndNotEmpty(strAmount)){
				dAdvance = dAdvance + Double.valueOf(strAmount);				
			}			
		}
		mReturn.put("Advances",new BigDecimal(dAdvance).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		for(int i=0;i<mlWithHeld.size();i++){
			mTemp = (Map)mlWithHeld.get(i);
			strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_BILL_REDUCTION_AMOUNT+"].value");
			if(UIUtil.isNotNullAndNotEmpty(strAmount)){
				dWithHeld = dWithHeld + Double.valueOf(strAmount);				
			}			
		}
		mReturn.put("WithHeld",new BigDecimal(dWithHeld).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		
		for(int i=0;i<mlRetentionRelease.size();i++){
			mTemp = (Map)mlRetentionRelease.get(i);
			strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT+"].value");
			if(UIUtil.isNotNullAndNotEmpty(strAmount)){
				dRetention = dRetention + Double.valueOf(strAmount);				
			}			
		}
		mReturn.put("RetentionRelease",new BigDecimal(dRetention).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		
		for(int i=0;i<mlWithHeldRelease.size();i++){
			mTemp = (Map)mlWithHeldRelease.get(i);
			strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_REDUCTION_RELEASE_AMOUNT+"].value");
			if(UIUtil.isNotNullAndNotEmpty(strAmount)){
				dWithHeldRelease = dWithHeldRelease + Double.valueOf(strAmount);				
			}			
		}
		mReturn.put("WithHeldRelease",new BigDecimal(dWithHeldRelease).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		
		for(int i=0;i<mlRecovery.size();i++){
			mTemp = (Map)mlRecovery.get(i);
			strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT+"].value");
			strAmountInterest = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_RECOVERY_INTEREST+"].value");
			if(UIUtil.isNotNullAndNotEmpty(strAmount)){
				dRecovery = dRecovery + Double.valueOf(strAmount);				
				dRecoveryInterest = dRecoveryInterest + Double.valueOf(strAmountInterest);				
			}			
		}
		
		
		for(int i=0;i<mlSecuredAdvances.size();i++){
			mTemp = (Map)mlSecuredAdvances.get(i);
			strAmount = (String)mTemp.get("Recovery");
			if(UIUtil.isNotNullAndNotEmpty(strAmount)){
				dRecovery = dRecovery + Double.valueOf(strAmount);				
	
			}			
		}
		mReturn.put("Recovery",new BigDecimal(dRecovery).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		mReturn.put("RecoveryInterest",new BigDecimal(dRecoveryInterest).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		
		Map mOtherDeduction = new HashMap();
		for(int i=0;i<mlOtherDeductions.size();i++){
			mTemp = (Map)mlOtherDeductions.get(i);
			strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_AMOUNT+"]");
			strDescription = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DESCRIPTION+"]");
			if(UIUtil.isNotNullAndNotEmpty(strAmount) && Double.valueOf(strAmount) != 0){
				dOtherDeduction = dOtherDeduction + Double.valueOf(strAmount);
				mOtherDeduction.put(strDescription,strAmount);
			}			
		}
		
		for(int i=0;i<mlLDs.size();i++){
			mTemp = (Map)mlLDs.get(i);
			strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_BILL_REDUCTION_AMOUNT+"].value");
			if(UIUtil.isNotNullAndNotEmpty(strAmount)){
				dLiquidatedDamage = dLiquidatedDamage + Double.valueOf(strAmount);				
			}			
		}
		
		if(dLiquidatedDamage != 0){
			mOtherDeduction.put("Liquidated Damages",new BigDecimal(dLiquidatedDamage).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		}
		mReturn.put("OtherDeduction",mOtherDeduction);

		Map mOtherReleases = new HashMap();
		
		for(int i=0;i<mlLDRelease.size();i++){
			mTemp = (Map)mlLDRelease.get(i);
			strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_REDUCTION_RELEASE_AMOUNT+"].value");
			if(UIUtil.isNotNullAndNotEmpty(strAmount)){
				dLiquidatedDamageRelease = dLiquidatedDamageRelease + Double.valueOf(strAmount);				
			}			
		}
		
		if(dLiquidatedDamageRelease != 0){
			mOtherReleases.put("Liquidated Damage Release",new BigDecimal(dLiquidatedDamageRelease).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		}
		
		
		String strQty = DomainConstants.EMPTY_STRING;
		String strRate = DomainConstants.EMPTY_STRING;
		for(int i=0;i<mlRoyaltyCharges.size();i++){
			mTemp = (Map)mlRoyaltyCharges.get(i);
			strQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_PAYABLE_QUANTITY+"]");
			strRate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_BASE_RATE+"]");
			if(UIUtil.isNotNullAndNotEmpty(strQty) && UIUtil.isNotNullAndNotEmpty(strRate)){
				dRoyalty = dRoyalty + (Double.valueOf(strQty) * Double.valueOf(strRate));				
			}			
		}
		
		if(dRoyalty != 0){
			mOtherReleases.put("Royalty Charges",new BigDecimal(dRoyalty).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		}
		
		for(int i=0;i<mlRateEscaltions.size();i++){
			mTemp = (Map)mlRateEscaltions.get(i);
			strQty = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_PAYABLE_QUANTITY+"]");
			strRate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_BASE_RATE+"]");
			if(UIUtil.isNotNullAndNotEmpty(strQty) && UIUtil.isNotNullAndNotEmpty(strRate)){
				dRateEscaltion = dRateEscaltion + (Double.valueOf(strQty) * Double.valueOf(strRate));				
			}			
		}
		
		if(dRateEscaltion != 0){
			mOtherReleases.put("Rate Escalations",new BigDecimal(dRateEscaltion).setScale(2, BigDecimal.ROUND_UP).toPlainString());
		}
		
		for(int i=0;i<mlOtherAdditions.size();i++){
			mTemp = (Map)mlOtherAdditions.get(i);
			strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_BASE_RATE+"]");
			strDescription = (String)mTemp.get(DomainObject.SELECT_DESCRIPTION);
			if(UIUtil.isNotNullAndNotEmpty(strAmount) && Double.valueOf(strAmount) != 0){
				dOtherAddition = dOtherAddition + Double.valueOf(strAmount);
				mOtherReleases.put(strDescription,strAmount);
			}			
		}
		
		
		String strOtherDeductionAmount = new BigDecimal(dOtherDeduction+dLiquidatedDamage).setScale(2, BigDecimal.ROUND_UP).toPlainString();
		String strOtherReleaseAmount = new BigDecimal(dLiquidatedDamageRelease+dRoyalty+dRateEscaltion+dOtherAddition).setScale(2, BigDecimal.ROUND_UP).toPlainString();
		
		mReturn.put("OtherRelease",mOtherReleases);
		mReturn.put("OtherDeductionAmount",strOtherDeductionAmount);
		mReturn.put("OtherReleaseAmount",strOtherReleaseAmount);
		
		return mReturn;		
	}
	

	public void generateForm26(Context context, String[] args)throws Exception{
		
		String strObjId = args[0];
		if(UIUtil.isNotNullAndNotEmpty(strObjId)){
			String strMode = args[1];
			String initargs[]    = {};
			HashMap params      = new HashMap();
			params.put("objectId", strObjId);
			params.put("GenMode",strMode);
			DomainObject doAbsMBE = new DomainObject(strObjId);
			String strTypeOfContract = (String)doAbsMBE.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value");
			
			String strDepartment = (String)doAbsMBE.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute[WMSDepartment]");
			if(strDepartment != null && !"".equals(strDepartment) && !strDepartment.equals("Equipments")){
				if(UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && strTypeOfContract.equals("EPC")){
					JPO.invoke(context, "WMSDownloadForm26",initargs,"writeFiles",JPO.packArgs (params),null);
				} else {
					if (UIUtil.isNotNullAndNotEmpty(strTypeOfContract)){
						JPO.invoke(context, "WMSAMBDownloadItems",initargs,"writeFiles",JPO.packArgs (params),null);
					}
				}
			}else{
				JPO.invoke(context, "WMSDownloadEquipmentsBill",initargs,"writeFiles",JPO.packArgs (params),null);
			}
		}
		
	}

	
	public String updateCertifiedAmount(Context context,String[] args) throws Exception
	{
	try {	  
		String strContectUser =  context.getUser();
		String strTaskId = args[0];
		String strAMBObjectId = DomainConstants.EMPTY_STRING;	
		if(UIUtil.isNotNullAndNotEmpty(strTaskId)){
			String strMqlQuery = "print bus "+strTaskId+" select from["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|from.type=='"+TYPE_ABSTRACT_MBE+"'].from.id dump";
			strAMBObjectId = MqlUtil.mqlCommand(context,strMqlQuery);
			if(UIUtil.isNotNullAndNotEmpty(strAMBObjectId)){
				String [] args1 = new String[5];		
				args1[0] = strAMBObjectId;	
				args1[1] = "Certified";	
				generateForm26(context,args1);
			}
		}
	}catch(Exception e){
		e.printStackTrace();
	} 
	return DomainConstants.EMPTY_STRING;
} 
	

public String getPendingDays(Context context, String[] args)throws Exception{
	String strReturn = DomainConstants.EMPTY_STRING;
	try { 
	boolean isNegative = false;
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);

		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strBillId = (String) paramMap.get("objectId");
		DomainObject doBus = new DomainObject(strBillId);
			
		StringList slObjSelect = new StringList();
		slObjSelect.add(DomainObject.SELECT_ID);
		slObjSelect.add(DomainObject.SELECT_TYPE);
		slObjSelect.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"].value");
		slObjSelect.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"].value");
	
		Map mTemp = (Map)doBus.getInfo(context,slObjSelect);


		String strNoOfDays = (String)mTemp.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"].value");
		String strWODate = (String)mTemp.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"].value");

		SimpleDateFormat simpleDateFormatMatrix  = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(),context.getLocale());
		Date dWODate=simpleDateFormatMatrix.parse(strWODate);	

		Date dToday = new Date();

		long lDifference = dToday.getTime() - dWODate.getTime();
		
		long lDiffDays = lDifference/(60*60*1000*24);
		
		long lDuration = Long.valueOf(strNoOfDays);
		
		long lDiff = lDuration - lDiffDays;
		
		if(lDiff < 0){
			isNegative = true;
			lDiff  = lDiff * -1;
		}
		strReturn = String.valueOf(lDiff);
		
		if(isNegative)
			strReturn = "-"+strReturn;
    
	}catch(Exception e) {
		e.printStackTrace();
	} 
	return strReturn;
	
	
}


public void updateLDRelease (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_REDUCTION_RELEASE_AMOUNT, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 public void updateWithheldRelease(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_REDUCTION_RELEASE_AMOUNT, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 
	public void updateInterest(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_RECOVERY_INTEREST, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 public void updateRecoveryAmount(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 
	 public MapList getMBEActivitiesWithRoyalty(Context context,
			DomainObject domObjAbstractMBE) throws FrameworkException {
		try
		{
			StringList strListBusSelects     = getUniqueMBEActivitiesBusSelects();
			StringList strListRelSelects     = getUniqueMBEActivitiesRelSelects();
			Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
			

			MapList mapListItems = domObjAbstractMBE.getRelatedObjects(context, // matrix context
					RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS, // relationship pattern
					patternType.getPattern(), // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					DomainConstants.EMPTY_STRING, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
			return mapListItems;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getMBEActivitiesWithRoyalty(Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mlAllConnectedTasks = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjAbstractMBE= DomainObject.newInstance(context, strObjectId);
				StringList strListBusSelects     = getUniqueMBEActivitiesBusSelects();
				StringList strListRelSelects     = getUniqueMBEActivitiesRelSelects();
				Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);			

				mlAllConnectedTasks = domObjAbstractMBE.getRelatedObjects(context, // matrix context
									RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS, // relationship pattern
									patternType.getPattern(), // type pattern
									strListBusSelects, // object selects
									strListRelSelects, // relationship selects
									false, // to direction
									true, // from direction
									(short) 1, // recursion level
									"attribute["+ATTRIBUTE_WMS_RC_APPLICABLE+"].value == Yes", // object where clause
									DomainConstants.EMPTY_STRING, // relationship where clause
									0);
				WMSMeasurementBookEntry_mxJPO.insertKeyValue(mlAllConnectedTasks, "disableSelection", "false");
			}
			return mlAllConnectedTasks;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}

public Boolean isAcitveTaskAvailable (Context context, String[] args) throws Exception 
	{
		Boolean bReturn = false ;
		try 
		{
			HashMap programMap 			= (HashMap)JPO.unpackArgs(args);
			String sMeasurementOid 		= (String)programMap.get("objectId");
			String strContextUser = context.getUser();
			String strPersonId = PersonUtil.getPersonObjectID(context);

			if(UIUtil.isNotNullAndNotEmpty(sMeasurementOid))
			{
				DomainObject doMBE = new DomainObject(sMeasurementOid);
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_OWNER);
				slSelect.add(DomainObject.SELECT_CURRENT);
				Map mObjInfo = doMBE.getInfo(context,slSelect);
				
				String strOwner = (String)mObjInfo.get(DomainObject.SELECT_OWNER);
				String strState = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);
				if(UIUtil.isNotNullAndNotEmpty(strOwner) && strContextUser.equals(strOwner) && "Create".equals(strState)){
					bReturn = true;					
				}else {
					String mqlQuery = "print bus "+sMeasurementOid+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
					String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
					if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
						mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name dump";
						String strUser = MqlUtil.mqlCommand(context, mqlQuery);
						if(UIUtil.isNotNullAndNotEmpty(strUser) && strUser.contains(strContextUser)){
							bReturn = true;
						}
					}
				}				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return bReturn;
	}

	
	public void updateDescriptionOnOtherDeductiom (Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("relId");
             String sTitle = (String)paramMap.get("New Value");
             DomainRelationship doRel = new DomainRelationship(sMeasurementOid);
			 ContextUtil.pushContext(context);
			 doRel.setAttributeValue(context, ATTRIBUTE_WMS_HEAD_OTHER_DEDUCTION_DESCRIPTION, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }
	public int checkForSincePrevious(Context context,String[] args) throws Exception
		{
		try {	  
			String strBillId = (String)args[0];
			String strRelId = (String)args[2];
			
			if(UIUtil.isNotNullAndNotEmpty(strBillId)){
					DomainObject doBill = new DomainObject(strBillId);
					String strTypeOfContract = (String)doBill.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"].value");
				if(UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && "EPC".equals(strTypeOfContract)){
					if(UIUtil.isNotNullAndNotEmpty(strRelId)){
						String strSincePrevValue =DomainRelationship.getAttributeValue(context, strRelId, ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY);
						if(UIUtil.isNotNullAndNotEmpty(strSincePrevValue)){
							double dSincePrev = Double.valueOf(strSincePrevValue);
							if(dSincePrev != 0){
								String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Bill.NotZero");
								emxContextUtil_mxJPO.mqlNotice(context,strMessage);
								return 1;
							}
						}
					}
				}
			}		
						
		}catch(Exception e){
			e.printStackTrace();
		} 
		return 0;
	}	

	public String showDownloadIcon(Context context,String[] args) throws Exception{
	  StringBuilder sb=new StringBuilder();
	 try { 
	    Map mInputMap = (Map) JPO.unpackArgs(args);
	   Map requestMap = (Map) mInputMap.get("requestMap");
	   String strObjectId = (String) requestMap.get("objectId");
	   String downloadURL = "../components/emxCommonDocumentPreCheckout.jsp?objectAction=download&objectId="+strObjectId; 
	   String strDownLoadTip="Download Bill Form";
	 
		 sb.append("<a href=\"" + downloadURL + "\"  target=\"formViewHidden\"   >");
   	     sb.append("<img border=\"0\" src=\"../common/images/iconActionDownload.gif\" alt=\""
		+ strDownLoadTip + "\" title=\"" + strDownLoadTip + "\"></img></a>&#160;");
	
	 }catch(Exception e) {
		 e.printStackTrace();
	 } 
 	return  sb.toString();
 }
 
 
 public void updateYearAndMonth(Context context, String[] args)throws Exception{
		boolean isContextPushed = false;
		try{
			ContextUtil.pushContext(context);
			isContextPushed = true;
			String strBillId = (String)args[0];
			if(UIUtil.isNotNullAndNotEmpty(strBillId)){
				DomainObject doBill = new DomainObject(strBillId);
				String strYear = DomainConstants.EMPTY_STRING;
				String strMonth = DomainConstants.EMPTY_STRING;
				LocalDateTime now = LocalDateTime.now();
				int year = now.getYear();
				int month = now.getMonthValue();
				
				if(month>3){
					strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
				}else{
					strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
				}
				strMonth = String.valueOf(month);
				
				HashMap mapAttr = new HashMap();
				if (strYear != null && !"".equals(strYear)) {
					mapAttr.put(ATTRIBUTE_WMS_FINANCIAL_YEAR, strYear);
				}
				if (strMonth != null && !"".equals(strMonth)) {
					mapAttr.put(ATTRIBUTE_WMS_MONTH, strMonth);
				}
				
				doBill.setAttributeValues(context,mapAttr);
			}

		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(isContextPushed)
				ContextUtil.popContext(context);

		}
		 
	 }

	 public void updateUptoDatePaidAmountOnBOQ(Context context,String[] args)throws Exception{
		boolean isContextPushed = false;
		try{
			String strObjectId = args[0];
			ContextUtil.pushContext(context);
			isContextPushed = true;
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				MapList mlAllConnectedTasks = new MapList();
				if(UIUtil.isNotNullAndNotEmpty(strObjectId))
				{
					DomainObject domObjAbstractMBE= DomainObject.newInstance(context, strObjectId);
					
					String strTypeOfContract = domObjAbstractMBE.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
					
					if(UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && "EPC".equals(strTypeOfContract) == false){
						mlAllConnectedTasks = getUniqueMBEActivities(context, domObjAbstractMBE);
						
						Iterator<Map<String, String>> iteratorMap = mlAllConnectedTasks.iterator();
						Map<String, String> mapObjectData = new HashMap<String, String>();
						String strMBEQty = DomainConstants.EMPTY_STRING;
						String strTillDateQty = DomainConstants.EMPTY_STRING;
						String strReduceRate = DomainConstants.EMPTY_STRING;
						String strUpToAmount = DomainConstants.EMPTY_STRING;
						String BOQId = DomainConstants.EMPTY_STRING;
						
						double fUpToAmount = 0d;
						double fUpToQty = 0d;
						double fMBEQty = 0d;
						double fTillDateQty = 0d;
						double fReduceRate = 0d;
						int intSize = mlAllConnectedTasks.size();
						while (iteratorMap.hasNext()) {
							double fTechDeductionAmount = 0d;
							double fTechDeductionReleaseAmount = 0d;
							mapObjectData = iteratorMap.next();
							strMBEQty = mapObjectData.get("attribute[WMSMBEActivityQuantity].value");
							strTillDateQty = mapObjectData.get("attribute["+ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE+"].value");
							strReduceRate = mapObjectData.get("attribute[WMSReducedSORRate].value");
							fReduceRate = WMSUtil_mxJPO.convertToDouble(strReduceRate);
							fMBEQty = WMSUtil_mxJPO.convertToDouble(strMBEQty);
							fTillDateQty = WMSUtil_mxJPO.convertToDouble(strTillDateQty);
							
							fUpToAmount = fTillDateQty + (fMBEQty * fReduceRate);
							
							BOQId = mapObjectData.get("id");
							String strDeductionAmount = MqlUtil.mqlCommand(context,"print bus "+strObjectId+" select from["+RELATIONSHIP_WMS_ABSMBE_TECHNICALDEDUCTION+"|to.to["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].from.id=="+BOQId+"].to.attribute["+ATTRIBUTE_WMS_TECHNICAL_DEDUCTION_AMOUNT+"].value dump");
							
							
							if(UIUtil.isNotNullAndNotEmpty(strDeductionAmount)){
								fTechDeductionAmount = WMSUtil_mxJPO.convertToDouble(strDeductionAmount);
							}
							
							String strCurrentBillReleaseAmount = MqlUtil.mqlCommand(context,"print bus "+BOQId+" select from["+RELATIONSHIP_WMS_ITEM_TECHNICAL_DEDUCTION+"].to.to["+RELATIONSHIP_WMS_ABSMBE_TECHNICAL_DEDUCTION_RELEASE+"|from.id=="+strObjectId+"].attribute["+ATTRIBUTE_WMS_CURRENT_BILL_TECHNICAL_DEDUCTION_RELEASE_AMOUNT+"].value dump |");
							
							if(UIUtil.isNotNullAndNotEmpty(strCurrentBillReleaseAmount)){
								StringList slTechReleaseList = FrameworkUtil.split(strCurrentBillReleaseAmount,"|");
								for(int k=0;k<slTechReleaseList.size();k++){
									String strValue = (String)slTechReleaseList.get(k);
									if(UIUtil.isNullOrEmpty(strValue)){
										strValue = "0";
									}
									fTechDeductionReleaseAmount = fTechDeductionReleaseAmount + WMSUtil_mxJPO.convertToDouble(strValue);
									
								}
							}
							
							fUpToAmount = fUpToAmount-fTechDeductionAmount + fTechDeductionReleaseAmount;
							strUpToAmount = new BigDecimal(fUpToAmount).toPlainString();
							
							DomainObject doBOQ = new DomainObject(BOQId);
							doBOQ.setAttributeValue(context,ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE,strUpToAmount);
							
						}
					}
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(isContextPushed)
				ContextUtil.popContext(context);
		}
	}
	 
}