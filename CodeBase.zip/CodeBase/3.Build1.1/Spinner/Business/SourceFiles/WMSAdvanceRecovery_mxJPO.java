/** Name of the JPO     : WMSAdvanceRecovery
 ** Developed by        : AurionPro Team 
 ** Client              : WMS
 ** Description         : The purpose of this JPO is to create a Measurement Book Entry
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------
 ** AurionPro                  28-Jul-2017                  Original Version
 ** -----------------------------------------------------------------
 **/


import matrix.db.AttributeItr;
import matrix.db.AttributeList;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.RelationshipType;

import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringItr;
import matrix.util.StringList;

import java.util.Vector;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;
import java.util.Locale;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.jdom.Element;
import java.math.BigDecimal;

/**
 * The purpose of this JPO is to create a Measurement Book Entry.
 * @author WMS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSAdvanceRecovery_mxJPO extends WMSConstants_mxJPO
{
	

	 
	/**
	 * Create a new ${CLASS:AdvanceRecovery} object from a given id.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds no arguments.
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since R418
	 */

	public WMSAdvanceRecovery_mxJPO(Context context, String[] args)
			throws Exception
	{
          super(context,args);
	}

	/**
	 * PENDING header and annotation
	 * Method called on the Portal to display the Advances 
	 * 
	 * to get the Advances
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAdvances(Context context,String[]args) throws Exception
	{
		MapList mapListAMBAdvances = new MapList();
		try
		{
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				StringList strListBusSelects     = new StringList(3);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_TYPE);
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
				DomainObject domObjTask= DomainObject.newInstance(context, strObjectId);
				mapListAMBAdvances = domObjTask.getRelatedObjects(context, // matrix context
						RELATIONSHIP_WMS_ADVANCE_RECOVERY, // relationship pattern
						TYPE_WMS_ADVANCE_RECOVERY_ITEM, // type pattern
						strListBusSelects, // object selects
						null, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in getAdvances method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB Tree command Advance Recovery, WMSAdvanceDetails");
			exception.printStackTrace();
			throw exception;
		}
		return mapListAMBAdvances;
	}
	/**
	 * PENDING header and annotation
	 * Method called to get the Recoveries 
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRecoveries(Context context,String[]args) throws Exception
	{
		MapList mapListAMBRecoveries = new MapList();
		try
		{
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				StringList strListBusSelects     = new StringList(2);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_TYPE);
				StringList strListRelSelects     = new StringList(3);
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				strListRelSelects.add("attribute["+ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT+"].value");
				strListRelSelects.add("attribute["+ATTRIBUTE_WMS_RECOVERY_INTEREST+"].value");
				DomainObject domObjTask= DomainObject.newInstance(context, strObjectId);
				mapListAMBRecoveries = domObjTask.getRelatedObjects(context, // matrix context
						RELATIONSHIP_WMS_RECOVERY, // relationship pattern
						TYPE_WMS_ADVANCE_RECOVERY_ITEM, // type pattern
						strListBusSelects, // object selects
						strListRelSelects, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in getRecoveries method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB Tree command Recovery, WMSRecoveryDetails");
			exception.printStackTrace();
			throw exception;
		}
		return mapListAMBRecoveries;
	}

	/**
	 * PENDING header and annotation
	 * to add recovery
	 * Trigger method to connect the New Recovery Object to the 
	 * Work Orders of the Abstract MBE
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public void connectAMBObjectsToWorkOrder(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			//ContextUtil.pushContext(context);
			//isContextPushed = true;
			String strAMBEOID = args[0];

			if(UIUtil.isNotNullAndNotEmpty(strAMBEOID))
			{
				DomainObject domObjAbstractMBE = DomainObject.newInstance(context, strAMBEOID);
				StringList strListAdvcRecoverOBJIds =  new StringList();

				String strWorkOrder	 	= domObjAbstractMBE.getInfo(context, "to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id"); 
				DomainObject domObjAbstractMBEWO = DomainObject.newInstance(context, strWorkOrder);

				String strAMBRelSymbName = args[1];
				String strAMBRelName = PropertyUtil.getSchemaProperty(strAMBRelSymbName);
				strListAdvcRecoverOBJIds = domObjAbstractMBE.getInfoList(context,"from["+strAMBRelName+"].to.id");

				ArrayList<String> arrayListOIDS = new ArrayList<String>(strListAdvcRecoverOBJIds);

				String strWorkOrderRelSymbName = args[2];
				String strWorkOrderRelName = PropertyUtil.getSchemaProperty(strWorkOrderRelSymbName);
				WMSUtil_mxJPO.connect(context, domObjAbstractMBEWO, strWorkOrderRelName, true, arrayListOIDS);
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in connectAMBObjectsToWorkOrder method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB action trigger on Approve State");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			//if (isContextPushed)
			//{
			//	ContextUtil.popContext(context);
			//}
		}
	} 

	/**
	 * PENDING header and annotation
	 * Trigger Program To update the Values after approving the MBE
	 * to add recovery
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public void updateTillDateAmount(Context context,String[]args) throws Exception
	{

		boolean isContextPushed = false;
		try {
			//ContextUtil.pushContext(context);
			//isContextPushed = true;
			String strAMBEOID = args[0];
			String strAMBRelSymbName = args[1];
			if(UIUtil.isNotNullAndNotEmpty(strAMBEOID))
			{
				DomainObject domObjAbstractMBE = DomainObject.newInstance(context, strAMBEOID);
				String temp = domObjAbstractMBE.getInfo(context, strAMBEOID);
				String strAMBRelName = PropertyUtil.getSchemaProperty(strAMBRelSymbName);
				StringList strListBusSelects = new StringList(1);
				strListBusSelects.add(DomainConstants.SELECT_ID);

				StringList strListRelSelects = new StringList(1);
				//strListRelSelects.add("attribute[" + ATTRIBUTE_WMS_RECOVERY_AMOUNT + "]");
				strListRelSelects.add("attribute[" + ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT + "]");
				strListRelSelects.add("attribute[" + ATTRIBUTE_WMS_RECOVERY_AMOUNT_TILL_PREVIOUS + "]");

				MapList mapListConnectedObj = domObjAbstractMBE.getRelatedObjects(context, // matrix
						// context
						strAMBRelName, // relationship pattern
						TYPE_WMS_ADVANCE_RECOVERY_ITEM, // type pattern
						strListBusSelects, // object selects
						strListRelSelects, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where
						// clause
						0);

				Iterator<Map<String,String>> iteratorMap = mapListConnectedObj.iterator();

				Map<String,String> mapAdvanceData = new HashMap<String, String>();
				String strOID 	= DomainConstants.EMPTY_STRING;
				String strRedRelPrev = "";
				String strRedRelCurrent = "";
				DomainObject doRedObj = DomainObject.newInstance(context);

				while(iteratorMap.hasNext())
				{
					mapAdvanceData = iteratorMap.next();
					strOID = (String)mapAdvanceData.get(DomainConstants.SELECT_ID);
					strRedRelPrev = (String)mapAdvanceData.get("attribute[" + ATTRIBUTE_WMS_RECOVERY_AMOUNT_TILL_PREVIOUS + "]");
					strRedRelCurrent = (String)mapAdvanceData.get("attribute[" + ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT + "]");
					float fRedRelPrev = Float.valueOf(strRedRelPrev);
					float fRedRelCurrent = Float.valueOf(strRedRelCurrent);
					float fFinalValue = fRedRelPrev + fRedRelCurrent;
					doRedObj.setId(strOID);
					doRedObj.setAttributeValue(context, ATTRIBUTE_WMS_RECOVERY_AMOUNT, String.valueOf(fFinalValue));          	  
				}
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception inupdateTillDateAmount  method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB action trigger on Approve State");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			//if (isContextPushed)
			//{
			//	ContextUtil.popContext(context);
			//}
		}
	}


	/**
	 * PENDING header and annotation
	 * Trigger Program To update the values of Advances and Recoveries On relationship connection
	 * to add recovery
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public void updateRelAttrsForAdvAndWithheld(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			ContextUtil.pushContext(context);
			isContextPushed = true;
			String strToObjectID = args[0];
			String strRELID = args[1];

			if(UIUtil.isNotNullAndNotEmpty(strToObjectID))
			{
				DomainObject domObjToObject = DomainObject.newInstance(context, strToObjectID);
				StringList slObjSelects = new StringList(2);

				slObjSelects.add(ATTRIBUTE_WMS_ADVANCE_AMOUNT);
				slObjSelects.add(ATTRIBUTE_WMS_RECOVERY_AMOUNT);

				AttributeList alAttrValues = domObjToObject.getAttributeValues(context, slObjSelects);
				AttributeItr atItrAttrVals = new AttributeItr(alAttrValues);
				atItrAttrVals.next();
				String strAdvanceAmount = atItrAttrVals.obj().getValue();
				atItrAttrVals.next();
				String strRecAmount = atItrAttrVals.obj().getValue();

				float fAdvAmount = Float.valueOf(strAdvanceAmount);
				float fRecAmount = Float.valueOf(strRecAmount);
				float fToRecAmount = fAdvAmount - fRecAmount;

				String strToRecoverAmount = String.valueOf(fToRecAmount);
				Map mAttrMap = new HashMap();
				mAttrMap.put(ATTRIBUTE_WMS_RECOVERY_AMOUNT, strToRecoverAmount);
				mAttrMap.put(ATTRIBUTE_WMS_RECOVERY_AMOUNT_TILL_PREVIOUS, strRecAmount);
				DomainRelationship drRecRel = new DomainRelationship(strRELID);
				drRecRel.setAttributeValues(context, mAttrMap);
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in adding Object to amb method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB action trigger on Approve State");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
	}

	/**
	 * PENDING header and annotation
	 * addRecoveries Method to pop out the object connected to the Work Order
	 * with the Wher clause
	 * to add recovery
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList addRecoveries(Context context,String[]args) throws Exception
	{
		MapList mapListAMBAdvances = new MapList();
		try
		{	
			HashMap programMap 	= (HashMap)JPO.unpackArgs(args);
			String strObjectId		=	(String) programMap.get("objectId"); 
			DomainObject domABSMB 	= DomainObject.newInstance(context , strObjectId);
			StringList slExistingObjs = domABSMB.getInfoList(context, "from["+RELATIONSHIP_WMS_RECOVERY+"].to.id");
			String strWorkOrder	= domABSMB.getInfo(context, "relationship["+RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.id");
			DomainObject domObj 	= DomainObject.newInstance(context , strWorkOrder);

			StringList strListBusSelects     = new StringList(4);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_TYPE);
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_RECOVERY_AMOUNT+"].value");
			StringList strListRelSelects     = new StringList(1);
			strListRelSelects.add(DomainRelationship.SELECT_ID);

			String strWhere = "attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"] > attribute["+ATTRIBUTE_WMS_RECOVERY_AMOUNT+"]";

			MapList  mapListObjects = domObj.getRelatedObjects(context,
					RELATIONSHIP_WMS_WORK_ORDER_ADVANCES,               // relationship pattern
					TYPE_WMS_ADVANCE_RECOVERY_ITEM,                     // object pattern
					false,                                            // to direction
					true,                                            // from direction
					(short)1,                                     // recursion level
					strListBusSelects,                          // object selects
					strListRelSelects,                             // relationship selects
					strWhere,                                // object where clause
					DomainConstants.EMPTY_STRING,             // relationship where clause
					(short)0,                                  // No expand limit
					DomainConstants.EMPTY_STRING,             // postRelPattern
					DomainConstants.EMPTY_STRING,
					null);                                   // postPatterns

			Iterator<Map<String,String>> iteratorMap = mapListObjects.iterator();
			Map<String,String> mapAdvanceData = new HashMap<String, String>();
			String strItemOID 	= DomainConstants.EMPTY_STRING;

			while(iteratorMap.hasNext())
			{
				mapAdvanceData = iteratorMap.next();
				strItemOID = mapAdvanceData.get(DomainConstants.SELECT_ID);

				if(slExistingObjs.contains(strItemOID))
				{
					continue;
				}
				else
				{
					mapListAMBAdvances.add(mapAdvanceData);
				}
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in addRecoveries method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB Tree command Add Recovery, WMSRecoveryDetails");
			exception.printStackTrace();
			throw exception;
		}
		return mapListAMBAdvances;
	}    

	/**
	 * PENDING header and annotation
	 * Method to add Recoveries In to the new Abstract MBE after selecting the Objects
	 * Method to add recovery on submit click
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public Map<String, String> addExistingRecovery(Context context,String[] args) throws Exception
	{
		Map<String,String> mapResult = new HashMap<String,String>();
		try	
		{
			mapResult.put(DomainConstants.SELECT_ID, DomainConstants.EMPTY_STRING);
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
			String strAbstractMBEOID = (String) programMap.get("objectId");
			String strSymbRelName = (String) programMap.get("strRelName");
			String strRelName = PropertyUtil.getSchemaProperty(strSymbRelName);
			StringList slCompleteList;
			StringList slIds;
			StringList slAdvanceIds = new StringList();
			for (int i = 0; i < emxTableRowId.length; i++) {
				slCompleteList = FrameworkUtil.split(emxTableRowId[i], ",");
				slIds = FrameworkUtil.split((String) slCompleteList.get(0), "|");
				slAdvanceIds.addElement((String) slIds.get(1));
			}
			connectRecToAbs(context, DomainObject.newInstance(context, strAbstractMBEOID), slAdvanceIds, strRelName);
			return mapResult;
		}
		catch(Exception exception)
		{
			System.out.println("Exception in addExistingRecoveries method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB Tree command Add Recovery, WMSRecoveryDetails");
			exception.printStackTrace();
			throw exception;
		}
	}

	/**
	 * PENDING header and annotation
	 * 
	 * Method to connect the object to the Abstract Mbe
	 * with the New Relationship  
	 * on submit click
	 * 
	 */
	private void connectRecToAbs(Context context, DomainObject domObjAbstractMBE, StringList arrayListRecOIDs, String strRelName) 
			throws Exception {
		try {

			int intSizeTemp = arrayListRecOIDs.size();
			String[] redRelObjIds = (String[]) arrayListRecOIDs.toArray(new String[intSizeTemp]);
			Map mObjAndRelIds = domObjAbstractMBE.addRelatedObjects(context,new RelationshipType(strRelName), true, redRelObjIds);

		}catch(Exception exception)
		{
			System.out.println("Exception in addExistingRecoveries method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB Tree command Add Recovery, WMSRecoveryDetails");
			exception.printStackTrace();
			throw exception;
		}

	}

	/**
	 * PENDING header and annotation
	 * Method to Generate the Sirial Numbers after the Object Creation
	 */
	public Vector getSNOColumn(Context context, String[] args)
			throws Exception
	{
		try{
			Map programMap =   (Map)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			Iterator iterator  = objectList.iterator();
			for(int i=1; i < intSize+1; i++)
			{
				vecResponse.add(String.valueOf(i));
			}           

			return vecResponse;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}


	/**
	 * PENDING header and
	 * Method to Add advances into the Table 
	 * On Save Action
	 * annotation
	 */
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public HashMap createAdvanceItem(Context context, String [] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Map paramMap = (Map) programMap.get("paramMap");
		String sObjectId=(String)paramMap.get("objectId");

		String sRowId = "" ;
		String strAdvanceObjectParticulars = "" ;
		String strAdvanceObjectType = "" ;
		String strAdvanceObjectRemarks = "" ;
		String strAdvanceObjectAmount = "" ;
		String strNewAdvanceObject = "";

		HashMap columnsMap;
		HashMap changedRowMap;
		HashMap doc = new HashMap();
		HashMap retMap;
		//ContextUtil.pushContext(context);
		DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
		DomainObject doAdvancObject = DomainObject.newInstance(context);

		Element elm = (Element) programMap.get("contextData");        
		MapList mlItems = new MapList();
		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		Map mapAttr = new HashMap();     

		for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
		{
			try
			{   
				retMap = new HashMap();
				changedRowMap = (HashMap) chgRowsMapList.get(i);
				columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");
				strAdvanceObjectParticulars = (String) columnsMap.get("Particulars");
				strAdvanceObjectType = (String) columnsMap.get("TypeOfAdvance");
				strAdvanceObjectRemarks = (String) columnsMap.get("Remarks");
				strAdvanceObjectAmount = (String) columnsMap.get("AdvanceAmount");

				strNewAdvanceObject = FrameworkUtil.autoName(context,
						"type_WMSAdvanceRecoveryItem",
						"",
						"policy_WMSAdvanceRecoveryItem",
						context.getVault().getName(),
						"-"
						);
				DomainRelationship domRel   = doAdvancObject.createAndConnect(context,
						TYPE_WMS_ADVANCE_RECOVERY_ITEM,
						strNewAdvanceObject,
						"-",
						POLICY_WMS_ADVANCE_RECOVERY_ITEM,
						null,
						RELATIONSHIP_WMS_ADVANCE_RECOVERY,
						domAmbObject,
						true);

				mapAttr = new HashMap();

				mapAttr.put(ATTRIBUTE_WMS_ADVANCE_PARTICULARS, strAdvanceObjectParticulars);

				if (strAdvanceObjectAmount != null && !"".equals(strAdvanceObjectAmount)) {
					mapAttr.put(ATTRIBUTE_WMS_ADVANCE_AMOUNT, strAdvanceObjectAmount);
				}
				if (strAdvanceObjectType != null && !"".equals(strAdvanceObjectType)) {
					mapAttr.put(ATTRIBUTE_WMS_TYPE_OF_ADVANCE, strAdvanceObjectType);
				}
				if (strAdvanceObjectRemarks != null && !"".equals(strAdvanceObjectRemarks)) {
					mapAttr.put(ATTRIBUTE_WMS_ADVANCE_REMARKS, strAdvanceObjectRemarks);
				}
				doAdvancObject.setAttributeValues(context,mapAttr);
				//ContextUtil.popContext(context);
				retMap = new HashMap();
				retMap.put("oid", doAdvancObject.getObjectId(context));
				retMap.put("relid", domRel.toString());
				retMap.put("pid", "");
				retMap.put("rid", "");
				retMap.put("markup", "new");
				retMap.put("rowId", sRowId);
				columnsMap.putAll(retMap);
				retMap.put("columns", columnsMap);
				mlItems.add(retMap);
				doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
				doc.put("Action", "success"); // Here the action can be "Success" or "refresh"
			}
			catch(Exception Ex)
			{
				Ex.printStackTrace();
				throw Ex;
			}
		}
		return doc;
	}

	/**
	 * PENDING header and
	 * Method to Show advances into the Table On work order
	 * On Save Action
	 * annotation
	 */
	 @com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAdvancesRecoveriesConnectedToWO(Context context, String[] args) throws Exception 
	{

		MapList mapListWOAdvances = new MapList();
		try {
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
				StringList strListBusSelects = new StringList(3);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_TYPE);
				DomainObject domObjTask = DomainObject.newInstance(context, strObjectId);
				mapListWOAdvances = domObjTask.getRelatedObjects(context, // matrix
						// context
						RELATIONSHIP_WMS_WORK_ORDER_ADVANCES, // relationship pattern
						TYPE_WMS_ADVANCE_RECOVERY_ITEM, // type pattern
						strListBusSelects, // object selects
						null, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where
						// clause
						0);
			}

			return mapListWOAdvances;
		} catch (Exception exception) {
			System.out.println("Exception getAdvancesRecoveriesConnectedToWO method of JPO WMSAdvanceReduction");
			System.out.println("Called from WMSShowWorkOrderAdvance command");
			exception.printStackTrace();
			throw exception;
		}
	}


	/**
	 * PENDING header and annotation
	 * Method to pop Up the details Regarding the Recoveries
	 * to add recovery
	 *  3-Aug-2017
	 */

	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAdvancesConnectedToABS(Context context, String[] args) throws Exception {
		MapList mapListABSReduction = new MapList();
		try {
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if (UIUtil.isNotNullAndNotEmpty(strObjectId)) {
				DomainObject domObjToObject = DomainObject.newInstance(context, strObjectId);
				StringList strListBusSelects = new StringList(1);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				StringList strListRelSelects = new StringList(2);
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				String strWhere = "current==Approved";
				mapListABSReduction = domObjToObject.getRelatedObjects(context, // matrix
						// context
						RELATIONSHIP_WMS_RECOVERY, // relationship pattern
						WMSConstants_mxJPO.TYPE_ABSTRACT_MBE, // type pattern
						strListBusSelects, // object selects
						strListRelSelects, // relationship selects
						true, // to direction
						false, // from direction
						(short) 1, // recursion level
						strWhere, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where
						// clause
						0);
			}

			return mapListABSReduction;
		} catch (Exception exception) {
			System.out.println("Exception getAdvancesConnectedToABS method of JPO WMSAdvanceRecovery");
			exception.printStackTrace();
			throw exception;
		}
	}		



	/**
	 * PENDING header and annotation
	 * Trigger    updatePaidQuantityTillDate On relationship connection
	 * to add recovery
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public void updatePaidQuantityTillDate(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			ContextUtil.pushContext(context);
			isContextPushed = true;
			String strToObjectID = args[0];
			String strRELID = args[1];
			if(UIUtil.isNotNullAndNotEmpty(strToObjectID))
			{
				DomainObject domObjToObject = DomainObject.newInstance(context, strToObjectID);
				String strObjAttrQtyValue = domObjToObject.getAttributeValue(context, ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE);
				String strObjAttrAmountValue = domObjToObject.getAttributeValue(context, ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE);
				DomainRelationship.setAttributeValue(context, strRELID, ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE, strObjAttrQtyValue);
				DomainRelationship.setAttributeValue(context, strRELID, ATTRIBUTE_WMS_AMOUNT_PAID_TILL_DATE, strObjAttrAmountValue);
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception updateAttributeValue method of JPO WMSAdvanceRecovery");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
	}

	/**
	 * PENDING header and annotation
	 * Trigger    updateTillDateAdvanceAndRecovery On relationship connection
	 * to add recovery
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public void updateTillDateAdvanceAndRecovery(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			//ContextUtil.pushContext(context);
		//	isContextPushed = true;
			String strObjectID = args[0];

			if(UIUtil.isNotNullAndNotEmpty(strObjectID))
			{
				DomainObject domAmbObject = DomainObject.newInstance(context, strObjectID);

				//Get the recoveries on current AMB
				MapList mapListAMBRecoveries = new MapList();
				StringList strListBusSelects = new StringList(1);
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TYPE_OF_ADVANCE+"].value");
				StringList strListRelSelects = new StringList(1);
				strListRelSelects.add("attribute["+ATTRIBUTE_WMS_RECOVERY_AMOUNT+"].value");
				mapListAMBRecoveries = domAmbObject.getRelatedObjects(context, // matrix
						// context
						RELATIONSHIP_WMS_RECOVERY, // relationship pattern
						TYPE_WMS_ADVANCE_RECOVERY_ITEM, // type pattern
						strListBusSelects, // object selects
						strListRelSelects, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						//strWhere, // object where clause
						DomainConstants.EMPTY_STRING,
						DomainConstants.EMPTY_STRING, // relationship where
						// clause
						0);
				Iterator<Map<String,String>> iteratorMap = mapListAMBRecoveries.iterator();
				Map<String,String> mapRecoveryData = new HashMap<String, String>();
				String strAdvanceType = "";
				String strRecoveryAmt = "";

				Map mRecoveryMap = new HashMap();
				mRecoveryMap.put("MiscellaneousRecovery", "0");
				mRecoveryMap.put("MobilizationRecovery", "0");
				mRecoveryMap.put("PlantAndMachineRecovery", "0");
				String strRecValue = "";
				float fTempRecValue = 0f;
				float fRecAttrValue = 0f;

				while(iteratorMap.hasNext())
				{
					mapRecoveryData = iteratorMap.next();
					strAdvanceType = mapRecoveryData.get("attribute["+ATTRIBUTE_WMS_TYPE_OF_ADVANCE+"].value");
					strRecoveryAmt = mapRecoveryData.get("attribute["+ATTRIBUTE_WMS_RECOVERY_AMOUNT+"].value");
					fRecAttrValue = Float.parseFloat(strRecoveryAmt);

					if (strAdvanceType.equals("Plant and Machinary")) {
						strRecValue = (String)mRecoveryMap.get("PlantAndMachineRecovery");
						if(UIUtil.isNotNullAndNotEmpty(strRecValue)){
							fTempRecValue = Float.parseFloat(strRecValue);
							mRecoveryMap.put("PlantAndMachineRecovery", String.valueOf(fRecAttrValue + fTempRecValue));
						}

					} else if (strAdvanceType.equals("Mobilization")) {

						strRecValue = (String)mRecoveryMap.get("MobilizationRecovery");
						if(UIUtil.isNotNullAndNotEmpty(strRecValue)){
							fTempRecValue = Float.parseFloat(strRecValue);
							mRecoveryMap.put("MobilizationRecovery", String.valueOf(fRecAttrValue + fTempRecValue));
						}
					} else {
						strRecValue = (String)mRecoveryMap.get("MiscellaneousRecovery");	
						if(UIUtil.isNotNullAndNotEmpty(strRecValue)){
							fTempRecValue = Float.parseFloat(strRecValue);						
							mRecoveryMap.put("MiscellaneousRecovery", String.valueOf(fRecAttrValue + fTempRecValue));
						}
					}
				}
				//Get the Advances on current AMB
				MapList mapListAMBAdvances = new MapList();
				StringList strListBusSelectsAdvances = new StringList(1);
				strListBusSelectsAdvances.add("attribute["+ATTRIBUTE_WMS_TYPE_OF_ADVANCE+"].value");
				strListBusSelectsAdvances.add("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
				mapListAMBAdvances = domAmbObject.getRelatedObjects(context, // matrix
						// context
						RELATIONSHIP_WMS_ADVANCE_RECOVERY, // relationship pattern
						TYPE_WMS_ADVANCE_RECOVERY_ITEM, // type pattern
						strListBusSelectsAdvances, // object selects
						null, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						//strWhere, // object where clause
						DomainConstants.EMPTY_STRING,
						DomainConstants.EMPTY_STRING, // relationship where
						// clause
						0);
				Iterator<Map<String,String>> iteratorAdvMap = mapListAMBAdvances.iterator();
				Map<String,String> mapAdvanceData = new HashMap<String, String>();
				String strAdvanceAmt = "";
				Map mAdvanceMap = new HashMap();
				mAdvanceMap.put("MiscellaneousAdvance", "0");
				mAdvanceMap.put("MobilizationAdvance", "0");
				mAdvanceMap.put("PlantAndMachineAdvance", "0");
				String strAdvValue = "";
				float fTempAdvValue = 0f;
				float fAdvAttrValue = 0f;

				while(iteratorAdvMap.hasNext())
				{
					mapAdvanceData = iteratorAdvMap.next();
					strAdvanceType = mapAdvanceData.get("attribute["+ATTRIBUTE_WMS_TYPE_OF_ADVANCE+"].value");
					strAdvanceAmt = mapAdvanceData.get("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
					fAdvAttrValue = Float.parseFloat(strAdvanceAmt);
					if (strAdvanceType.equals("Plant and Machinary")) {
						strAdvValue = (String)mAdvanceMap.get("PlantAndMachineAdvance");
						if(UIUtil.isNotNullAndNotEmpty(strAdvValue)){
							fTempAdvValue = Float.parseFloat(strAdvValue);
							mAdvanceMap.put("PlantAndMachineAdvance", String.valueOf(fAdvAttrValue + fTempAdvValue));
						}
					} else if (strAdvanceType.equals("Mobilization")) {
						strAdvValue = (String)mAdvanceMap.get("MobilizationAdvance");
						if(UIUtil.isNotNullAndNotEmpty(strAdvValue)){
							fTempAdvValue = Float.parseFloat(strAdvValue);
							mAdvanceMap.put("MobilizationAdvance", String.valueOf(fAdvAttrValue + fTempAdvValue));
						}
					} else {
						strAdvValue = (String)mAdvanceMap.get("MiscellaneousAdvance");
						if(UIUtil.isNotNullAndNotEmpty(strAdvValue)){
							fTempAdvValue = Float.parseFloat(strAdvValue);
							mAdvanceMap.put("MiscellaneousAdvance", String.valueOf(fAdvAttrValue + fTempAdvValue));
						}
					}
				}
				Map<String,String> mapAttribute=new HashMap<String,String>();  
				mapAttribute.putAll(mAdvanceMap);
				mapAttribute.putAll(mRecoveryMap);				
				Map MapAttributes = new HashMap<>();

				//Get attribute from Previous Sequence AMB.
				//Get Previous Sequence AMB.
				StringList strListAmbSelects = new StringList(2);
				strListAmbSelects.add("to["+WMSConstants_mxJPO.RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.id"); //Workorder relationship
				strListAmbSelects.add("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"]");//Sequence atribute
				Map mAMBInfo = domAmbObject.getInfo(context, strListAmbSelects);
				String strWorkOrderId = (String)mAMBInfo.get("to["+WMSConstants_mxJPO.RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.id");
				String strSequenceOrder = (String)mAMBInfo.get("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"]");
				if (!strSequenceOrder.equals("1")) {
					DomainObject doWorkOrder = DomainObject.newInstance(context, strWorkOrderId);
					//Get Previous Sequence
					int iCurrentSeq = Integer.parseInt(strSequenceOrder);
					int iPrevSeq = iCurrentSeq - 1;
					String strWhere = "attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"] == "+String.valueOf(iPrevSeq);

					StringList strListPrevAmbSelects = new StringList(6);
					strListPrevAmbSelects.add(DomainConstants.SELECT_ID);
					strListPrevAmbSelects.add("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_PLANT_MACHINARY_ADVANCE_RECOVERED+"]");
					strListPrevAmbSelects.add("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_MOBILISATION_ADVANCE_RECOVERED+"]");
					strListPrevAmbSelects.add("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_SECURED_ADVANCE_RECOVERED+"]");
					strListPrevAmbSelects.add("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_PLANT_MACHINARY_ADVANCE_PAID+"]");
					strListPrevAmbSelects.add("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_MOBILISATION_ADVANCE_PAID+"]");
					strListPrevAmbSelects.add("attribute["+ATTRIBUTE_WMS_MBE_SECURED_ADVANCE_PAID+"]");

					MapList mlPreAMB = doWorkOrder.getRelatedObjects(context, // matrix
							// context
							RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE, // relationship pattern
							TYPE_ABSTRACT_MBE, // type pattern
							strListPrevAmbSelects, // object selects
							null, // relationship selects
							false, // to direction
							true, // from direction
							(short) 1, // recursion level
							strWhere, // object where clause
							null, // relationship where
							// clause
							1);
					Map mPrevAMBInfo = (Map)mlPreAMB.get(0);

					String strSecAdvance = (String)mPrevAMBInfo.get("attribute["+ATTRIBUTE_WMS_MBE_SECURED_ADVANCE_PAID+"]");
					String strPAndMAdvance = (String)mPrevAMBInfo.get("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_PLANT_MACHINARY_ADVANCE_PAID+"]");
					String strMobAdvance = (String)mPrevAMBInfo.get("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_MOBILISATION_ADVANCE_PAID+"]");
					String strSecRec = (String)mPrevAMBInfo.get("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_SECURED_ADVANCE_RECOVERED+"]");
					String strPAndMRec = (String)mPrevAMBInfo.get("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_PLANT_MACHINARY_ADVANCE_RECOVERED+"]");
					String strMobRec = (String)mPrevAMBInfo.get("attribute["+ATTRIBUTE_WMS_ABSTRACT_MBE_MOBILISATION_ADVANCE_RECOVERED+"]");

					float fSecAdvance = Float.parseFloat(strSecAdvance) + Float.parseFloat(mapAttribute.get("MiscellaneousAdvance"));
					float fPAndMAdvance = Float.parseFloat(strSecAdvance) + Float.parseFloat(mapAttribute.get("PlantAndMachineAdvance"));
					float fMobAdvance = Float.parseFloat(strSecAdvance) + Float.parseFloat(mapAttribute.get("MobilizationAdvance"));
					float fSecRec = Float.parseFloat(strSecAdvance) + Float.parseFloat(mapAttribute.get("MiscellaneousRecovery"));
					float fPAndMRec = Float.parseFloat(strSecAdvance) + Float.parseFloat(mapAttribute.get("PlantAndMachineRecovery"));
					float fMobRec = Float.parseFloat(strSecAdvance) + Float.parseFloat(mapAttribute.get("MobilizationRecovery"));

					mapAttribute.put("MiscellaneousAdvance", String.valueOf(fSecAdvance));
					mapAttribute.put("MobilizationAdvance", String.valueOf(fMobAdvance));
					mapAttribute.put("PlantAndMachineAdvance",String.valueOf(fPAndMAdvance));
					mapAttribute.put("MiscellaneousRecovery",  String.valueOf(fSecRec));
					mapAttribute.put("MobilizationRecovery",  String.valueOf(fMobRec));
					mapAttribute.put("PlantAndMachineRecovery",  String.valueOf(fPAndMRec));
				}

				MapAttributes.put(ATTRIBUTE_WMS_ABSTRACT_MBE_PLANT_MACHINARY_ADVANCE_RECOVERED,mapAttribute.get("PlantAndMachineRecovery"));
				MapAttributes.put(ATTRIBUTE_WMS_ABSTRACT_MBE_MOBILISATION_ADVANCE_RECOVERED, mapAttribute.get("MobilizationRecovery"));
				MapAttributes.put(ATTRIBUTE_WMS_ABSTRACT_MBE_SECURED_ADVANCE_RECOVERED,mapAttribute.get("MiscellaneousRecovery"));
				MapAttributes.put(ATTRIBUTE_WMS_ABSTRACT_MBE_PLANT_MACHINARY_ADVANCE_PAID,mapAttribute.get("PlantAndMachineAdvance"));
				MapAttributes.put(ATTRIBUTE_WMS_ABSTRACT_MBE_MOBILISATION_ADVANCE_PAID,mapAttribute.get("MobilizationAdvance"));
				MapAttributes.put(ATTRIBUTE_WMS_MBE_SECURED_ADVANCE_PAID,mapAttribute.get("MiscellaneousAdvance"));
				domAmbObject.setAttributeValues(context, MapAttributes);
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception updateTillDateAdvanceAndRecovery method of JPO WMSAdvanceRecovery");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			//if (isContextPushed)
			//{
			//	ContextUtil.popContext(context);
			//}
		}
	}
	/**
	 * PENDING header and annotation
	 * to add recovery
	 * Trigger method to calculate sum of Mobilization Advance and should be less than Mobilization Advance Contract Value.
	 * Work Orders of the Abstract MBE
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public int checkMobilizationAdvanceContractValue(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			ContextUtil.pushContext(context);
			isContextPushed = true;
			String strAMBEOID = args[0];

			if(UIUtil.isNotNullAndNotEmpty(strAMBEOID))
			{
				DomainObject domObjAbstractMBE = DomainObject.newInstance(context);
				domObjAbstractMBE.setId(strAMBEOID);
				StringList strListWOInfo =  new StringList();
				strListWOInfo.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute[WMSValueOfContract].value");
				strListWOInfo.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute[WMSMobilizationAdvance].value");
				strListWOInfo.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				MapList mapListAdvcRecoverOBJIds =  new MapList();
				Map workOrderInfo	= domObjAbstractMBE.getInfo(context, strListWOInfo); 
				String workOrderId =(String) workOrderInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				String valueOfContract=(String) workOrderInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute[WMSValueOfContract].value");
				String mobilizationAdvance=(String) workOrderInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute[WMSMobilizationAdvance].value");
				//DomainObject domObjAbstractMBEWO = DomainObject.newInstance(context, strWorkOrder);

				String strAMBRelSymbName = args[1];
				String strAMBRelName = PropertyUtil.getSchemaProperty(strAMBRelSymbName);
				//strListAdvcRecoverOBJIds = domObjAbstractMBE.getInfoList(context,"from["+strAMBRelName+"|to.attribute["+ATTRIBUTE_WMS_TYPE_OF_ADVANCE+"]=='Mobilization'].to.attribute[WMSAdvanceAmount].value");

				//String strWorkOrderOBJIds = domObjAbstractMBE.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				DomainObject domObjWO = DomainObject.newInstance(context, workOrderId);
				StringList strListAMBE = domObjWO.getInfoList(context, "from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.id");
				StringList strListBusSelects     = new StringList(3);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_TYPE);
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
				String strwhere="attribute["+ATTRIBUTE_WMS_TYPE_OF_ADVANCE+"] ==Mobilization";

				if(strListAMBE!=null) {
					String strRedRelCurrent = "";
					float fFinalValue = 0L;
					for(Object id:strListAMBE){
						domObjAbstractMBE.setId((String)id);
						mapListAdvcRecoverOBJIds = domObjAbstractMBE.getRelatedObjects(context, // matrix context
								RELATIONSHIP_WMS_ADVANCE_RECOVERY, // relationship pattern
								TYPE_WMS_ADVANCE_RECOVERY_ITEM, // type pattern
								strListBusSelects, // object selects
								null, // relationship selects
								false, // to direction
								true, // from direction
								(short) 1, // recursion level
								strwhere, // object where clause
								DomainConstants.EMPTY_STRING, // relationship where clause
								0);
						Iterator<Map<String,String>> iteratorMap = mapListAdvcRecoverOBJIds.iterator();
						Map<String,String> mapAdvanceData = new HashMap<String, String>();


						while(iteratorMap.hasNext())
						{
							mapAdvanceData = iteratorMap.next();
							strRedRelCurrent = (String)mapAdvanceData.get("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
							float fRedRelPrev = Float.valueOf(strRedRelCurrent);
							fFinalValue += fRedRelPrev;
						}

					}
					DecimalFormat df2 = new DecimalFormat(".##");
					float fPercent=fFinalValue/Float.parseFloat(valueOfContract)*100;
					if(fPercent>Float.parseFloat(mobilizationAdvance)) {
						 String strAlert = 	MessageUtil.getMessage(context, null, "WMS.alert.MobilazationAdvanceError",
		        					new String[] {df2.format(fPercent),String.valueOf(mobilizationAdvance)}, null, context.getLocale(),
		        					"wmsStringResource");	
		        		 emxContextUtil_mxJPO.mqlNotice(context,strAlert);
						
						return 1;
					}
				}
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in connectAMBObjectsToWorkOrder method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB action trigger on Approve State");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
		return 0;
	} 
	
	/**
	 * PENDING header and annotation
	 * to add recovery
	 * Trigger method to calculate sum of Mobilization Advance and should be less than Mobilization Advance Contract Value.
	 * Work Orders of the Abstract MBE
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public int checkAdvanceRecovery(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			ContextUtil.pushContext(context);
			isContextPushed = true;
			String strAMBEOID = args[0];

			if(UIUtil.isNotNullAndNotEmpty(strAMBEOID))
			{
				
				DomainObject domObjAbstractMBE = DomainObject.newInstance(context);
				domObjAbstractMBE.setId(strAMBEOID);
				
				StringList slRecoveryList = domObjAbstractMBE.getInfoList(context,"from["+RELATIONSHIP_WMS_RECOVERY+"].id");
				boolean isValidationFailed = false;
				String strRelId = DomainConstants.EMPTY_STRING;
				String strAdvanceId = DomainConstants.EMPTY_STRING;
				for(int i=0;i<slRecoveryList.size();i++){
					strRelId = (String)slRecoveryList.get(i);
					DomainRelationship doRel = new DomainRelationship(strRelId);
					String strRecoveryAmount = doRel.getAttributeValue(context,ATTRIBUTE_WMS_RECOVERY_AMOUNT);
					String strRecoveryEntryAmount = doRel.getAttributeValue(context,ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT);
					
					if(UIUtil.isNullOrEmpty(strRecoveryAmount))
						strRecoveryAmount = "0";
					if(UIUtil.isNullOrEmpty(strRecoveryEntryAmount))
						strRecoveryEntryAmount = "0";
					
					double dRecoveryAmount = Double.parseDouble(strRecoveryAmount);
					double dRecoveryEntryAmount = Double.parseDouble(strRecoveryEntryAmount);
					if(dRecoveryEntryAmount>dRecoveryAmount) {
						isValidationFailed  =true;
						break;
					}
				}
				
				if(isValidationFailed) {
					Locale strLocale = context.getLocale();
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.alert.RecoveryAmountisMore");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
				
				/*DomainObject domObjAbstractMBE = DomainObject.newInstance(context);
				domObjAbstractMBE.setId(strAMBEOID);
				StringList strListWOInfo =  new StringList();
				strListWOInfo.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute[WMSValueOfContract].value");
				//strListWOInfo.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute[WMSMobilizationAdvance].value");
				strListWOInfo.add("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				MapList mapListAdvcRecoverOBJIds =  new MapList();
				Map workOrderInfo	= domObjAbstractMBE.getInfo(context, strListWOInfo); 
				String workOrderId =(String) workOrderInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				String valueOfContract=(String) workOrderInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute[WMSValueOfContract].value");
				//String mobilizationAdvance=(String) workOrderInfo.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute[WMSMobilizationAdvance].value");
				//DomainObject domObjAbstractMBEWO = DomainObject.newInstance(context, strWorkOrder);

				String strAMBRelSymbName = args[1];
				String strAMBRelName = PropertyUtil.getSchemaProperty(strAMBRelSymbName);
				//strListAdvcRecoverOBJIds = domObjAbstractMBE.getInfoList(context,"from["+strAMBRelName+"|to.attribute["+ATTRIBUTE_WMS_TYPE_OF_ADVANCE+"]=='Mobilization'].to.attribute[WMSAdvanceAmount].value");

				//String strWorkOrderOBJIds = domObjAbstractMBE.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				DomainObject domObjWO = DomainObject.newInstance(context, workOrderId);
				StringList strListAMBE = domObjWO.getInfoList(context, "from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].to.id");
				StringList strListBusSelects     = new StringList(3);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_TYPE);
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
				StringList strListRelSelects     = new StringList(1);
				strListRelSelects.add("attribute["+ATTRIBUTE_WMS_RECOVERY_AMOUNT+"].value");
				strListRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_NAME);
				String strRel=RELATIONSHIP_WMS_RECOVERY+","+RELATIONSHIP_WMS_ADVANCE_RECOVERY;

				if(strListAMBE!=null) {
					String strRedRelCurrent = "";
					String strRecoveryAmnt="";
					float fFinalValue = 0L;
					float fFinalRecoveryValue = 0L;
					for(Object id:strListAMBE){
						domObjAbstractMBE.setId((String)id);
						mapListAdvcRecoverOBJIds = domObjAbstractMBE.getRelatedObjects(context, // matrix context
								strRel, // relationship pattern
								TYPE_WMS_ADVANCE_RECOVERY_ITEM, // type pattern
								strListBusSelects, // object selects
								strListRelSelects, // relationship selects
								false, // to direction
								true, // from direction
								(short) 1, // recursion level
								DomainConstants.EMPTY_STRING, // object where clause
								DomainConstants.EMPTY_STRING, // relationship where clause
								0);
						Iterator<Map<String,String>> iteratorMap = mapListAdvcRecoverOBJIds.iterator();
						Map<String,String> mapAdvanceData = new HashMap<String, String>();
						String relName="";

						while(iteratorMap.hasNext())
						{
							mapAdvanceData = iteratorMap.next();
							strRedRelCurrent = (String)mapAdvanceData.get("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
							strRecoveryAmnt = (String)mapAdvanceData.get("attribute["+ATTRIBUTE_WMS_RECOVERY_AMOUNT+"].value");
							relName=(String)mapAdvanceData.get(DomainConstants.SELECT_RELATIONSHIP_NAME);
							if(RELATIONSHIP_WMS_ADVANCE_RECOVERY.equals(relName)) {
								float fRedRelPrev = Float.valueOf(strRedRelCurrent);
								fFinalValue += fRedRelPrev;
							}else {
								float fRecoveryAmnt = Float.valueOf(strRecoveryAmnt);
								fFinalRecoveryValue += fRecoveryAmnt;
							}
						
						}

					}
					if(fFinalRecoveryValue>fFinalValue) {
						Locale strLocale = context.getLocale();
		                  String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", strLocale, "WMS.alert.RecoveryAmountisMore");
		                  emxContextUtil_mxJPO.mqlNotice(context,strMessage);
						return 1;
					}
				}*/
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in connectAMBObjectsToWorkOrder method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB action trigger on Approve State");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
		return 0;
	} 
	/**
	 * PENDING header and annotation
	 * Trigger Program To update the Values after approving the MBE
	 * to add recovery
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public void updateQuantityPaidTillDate(Context context,String[]args) throws Exception
	{
		
		//ContextUtil.pushContext(context);
		try {
			String strAMBEOID = args[0];
			if(UIUtil.isNotNullAndNotEmpty(strAMBEOID))
			{
				DomainObject domObjAbstractMBE = DomainObject.newInstance(context, strAMBEOID);
				String strTypeOfContract = domObjAbstractMBE.getInfo(context, "relationship["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
				if(UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && "EPC".equalsIgnoreCase(strTypeOfContract)==false) {
					updateQuantityPaidTillDateNonEPC(context,domObjAbstractMBE); // updated by Ravi 4th Sept18
				}
				else {
				StringList strListBusSelects = new StringList(2);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				//strListBusSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"]");
				
				StringList strListRelSelects = new StringList(1);
				strListRelSelects.add("attribute[" + WMSConstants_mxJPO.ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY + "]");
				
				Pattern typePattern = new Pattern(WMSConstants_mxJPO.TYPE_WMS_MEASUREMENT_TASK);
				MapList mapListConnectedObj1 = domObjAbstractMBE.getRelatedObjects(context, // matrix
				        // context
						WMSConstants_mxJPO.RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS, // relationship pattern
						RELATIONSHIP_WMS_PAYMENT_ITEM,// type pattern
			 	        strListBusSelects, // object selects
				        strListRelSelects, // relationship selects
				        false, // to direction
				        true, // from direction
				        (short) 1, // recursion level
				        DomainConstants.EMPTY_STRING, // object where clause
				        DomainConstants.EMPTY_STRING, // relationship where
				        // clause
				        0);
						
				
				//Iterator<Map<String,String>> iteratorMap = mapListConnectedObj.iterator();
				Iterator<Map<String,String>> iteratorMap = mapListConnectedObj1.iterator();

				Map<String,String> mapItemData = new HashMap<String, String>();
	            String strOID 	= DomainConstants.EMPTY_STRING;
	            String strQty = "";
	            String strQtyPaidRelCurrent = "";
	            DomainObject doRedObj = DomainObject.newInstance(context);
				
	            while(iteratorMap.hasNext())
	            {
					mapItemData = iteratorMap.next();
	          	  strOID = (String)mapItemData.get(DomainConstants.SELECT_ID);
	          	  strQty = (String)mapItemData.get("attribute[" + ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY  + "]");
	          	  //strQtyPaidRelCurrent = (String)mapItemData.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
	          	  strQtyPaidRelCurrent = (String)mapItemData.get("attribute["+ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE+"]");
	          	  float fstrQty = Float.valueOf(strQty);
	          	  float fstrQtyPaidRelCurrent = Float.valueOf(strQtyPaidRelCurrent);
	          	  float strQtyPaidTillDate = fstrQty + fstrQtyPaidRelCurrent;
	          	  doRedObj.setId(strOID);
	          	  //doRedObj.setAttributeValue(context, ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE, String.valueOf(strQtyPaidTillDate));  
	          	  doRedObj.setAttributeValue(context, ATTRIBUTE_WMS_PERCENTAGE_COMPLETE_TILL_DATE, String.valueOf(strQtyPaidTillDate));  
	            }
			}
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception inupdateTillDateAmount  method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB action trigger on Approve State");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			//ContextUtil.popContext(context);
			 
		}
	}
	
	
	/**
	 * Sets qty paid till date
	 * 
	 * 
	 * @param context
	 * @param domObjAbstractMBE
	 * @throws Exception
	 */
	 
	 
		public void updateQuantityPaidTillDateNonEPC(Context context,DomainObject domObjAbstractMBE) throws Exception
		{
			try {
					StringList strListBusSelects = new StringList(2);
					strListBusSelects.add(DomainConstants.SELECT_ID);
						strListBusSelects.add("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
					
					StringList strListRelSelects = new StringList(1);
					strListRelSelects.add("attribute[" + WMSConstants_mxJPO.ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY + "]");
					
					Pattern typePattern = new Pattern(WMSConstants_mxJPO.TYPE_WMS_MEASUREMENT_TASK);
					
					MapList mapListConnectedObj = domObjAbstractMBE.getRelatedObjects(context, // matrix
					        // context
							WMSConstants_mxJPO.RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS, // relationship pattern
							typePattern.getPattern(),// type pattern
					        strListBusSelects, // object selects
					        strListRelSelects, // relationship selects
					        false, // to direction
					        true, // from direction
					        (short) 1, // recursion level
					        DomainConstants.EMPTY_STRING, // object where clause
					        DomainConstants.EMPTY_STRING, // relationship where
					        // clause
					        0);
					Iterator<Map<String,String>> iteratorMap = mapListConnectedObj.iterator();

					Map<String,String> mapItemData = new HashMap<String, String>();
		            String strOID 	= DomainConstants.EMPTY_STRING;
		            String strQty = "";
		            String strQtyPaidRelCurrent = "";
		            DomainObject doRedObj = DomainObject.newInstance(context);
					
		            while(iteratorMap.hasNext())
		            {
		            	mapItemData = iteratorMap.next();
		          	  strOID = (String)mapItemData.get(DomainConstants.SELECT_ID);
		          	  strQty = (String)mapItemData.get("attribute[" + ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY  + "]");
		          	  strQtyPaidRelCurrent = (String)mapItemData.get("attribute["+ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE+"]");
		          	  float fstrQty = Float.valueOf(strQty);
		          	  float fstrQtyPaidRelCurrent = Float.valueOf(strQtyPaidRelCurrent);
		          	  float strQtyPaidTillDate = fstrQty + fstrQtyPaidRelCurrent;
		          	  doRedObj.setId(strOID);
		          	  doRedObj.setAttributeValue(context, ATTRIBUTE_WMS_QUANTITY_PAID_TILL_DATE, String.valueOf(strQtyPaidTillDate));  
		            }
				 
			}
			catch(Exception exception)
			{
				System.out.println("Exception inupdateTillDateAmount  method of JPO WMSAdvanceRecovery");
				System.out.println("Called from AMB action trigger on Approve State");
				exception.printStackTrace();
				throw exception;
			}
			finally{
				//	ContextUtil.popContext(context);
			}
			 
		}

	
		/**
	 * PENDING header and annotation
	 * to add recovery
	 * Trigger method to connect the New Recovery Object to the 
	 * Work Orders of the Abstract MBE
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public void connectRetentionObjectsToWorkOrder(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			ContextUtil.pushContext(context);
			isContextPushed = true;
			String strAMBEOID = args[0];

			if(UIUtil.isNotNullAndNotEmpty(strAMBEOID))
			{
				DomainObject domObjAbstractMBE = DomainObject.newInstance(context, strAMBEOID);
				StringList strListAdvcRecoverOBJIds =  new StringList();
				String strWorkOrder	 	= domObjAbstractMBE.getInfo(context, "to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id"); 
				DomainObject domObjAbstractMBEWO = DomainObject.newInstance(context, strWorkOrder);

				String strAMBRelSymbName = args[1];
				String strAMBRelName = PropertyUtil.getSchemaProperty(strAMBRelSymbName);
				strListAdvcRecoverOBJIds = domObjAbstractMBE.getInfoList(context,"from["+strAMBRelName+"].to.id");
				ArrayList<String> arrayListOIDS = new ArrayList<String>(strListAdvcRecoverOBJIds);

				String strWorkOrderRelSymbName = args[2];
				String strWorkOrderRelName = PropertyUtil.getSchemaProperty(strWorkOrderRelSymbName);
			
				WMSUtil_mxJPO.connect(context, domObjAbstractMBEWO, strWorkOrderRelName, true, arrayListOIDS);
				
				DomainObject doRetentionObj = null;
				for(int i=0;i< strListAdvcRecoverOBJIds.size();i++){
					doRetentionObj = new DomainObject((String)strListAdvcRecoverOBJIds.get(i));
					//doRetentionObj.setAttributeValue(context,ATTRIBUTE_WMS_RETENTION_RECOVERED,"Yes");
					String strRetensionAmount = getRetentionAmount(context,strAMBEOID);
					if(UIUtil.isNotNullAndNotEmpty(strRetensionAmount)){
						doRetentionObj.setAttributeValue(context,ATTRIBUTE_WMS_RETENSION_AMOUNT,strRetensionAmount);
					}
				}
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in connectAMBObjectsToWorkOrder method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB action trigger on Approve State");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
	} 
	
	
	public String getRetentionAmount(Context context,String strAbsMBEId) throws Exception
	{
		DecimalFormat decFor = new DecimalFormat("#.##");
		double dRetentionAmount = 0.0;
		
		String strRetensionAmount = DomainConstants.EMPTY_STRING;
		try
		{
			DomainObject domainObject = DomainObject.newInstance(context,strAbsMBEId);
			StringList sList = new StringList();
			sList.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
			sList.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSECVIBM_VALUE+"]");
			sList.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
			sList.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSRETENTION_PERCENTAGE+"].value");
			sList.addElement("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSDEPARTMENT+"]");
			Map valueMap = domainObject.getInfo(context,sList);
			String strValueOfContract = (String)valueMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
			//String strECVValue = (String)valueMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSECVIBM_VALUE+"]");
			String strTypeOfContract = (String)valueMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
			String strDept = (String)valueMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSDEPARTMENT+"]");
			
			double dWMSPreviousAmount = 0.0;
			double dWMSValueOfContract = 0.0;
			if (strValueOfContract != null && !"".equals(strValueOfContract)){
				dWMSValueOfContract = Double.parseDouble(strValueOfContract);
				dWMSPreviousAmount = Double.parseDouble(strValueOfContract);
			}
			//if (strECVValue != null && !"".equals(strECVValue)){
			//	dWMSPreviousAmount = Double.parseDouble(strECVValue);
			//}
			
			//Double doRetentionsPercentage = (-1*(dWMSPreviousAmount - dWMSValueOfContract)/dWMSPreviousAmount)*100;
			
			//doRetentionsPercentage = Double.valueOf(decFor.format(doRetentionsPercentage));
			
			String strTypeName = "";
			String strRelName = "";
			if("Equipments".equals(strDept) == false){
				if(strTypeOfContract != null && !"".equals(strTypeOfContract) && strTypeOfContract.equals("EPC")){
					strTypeName = TYPE_WMS_PAYMENT_ITEM;
					strRelName = RELATIONSHIP_WMS_ABSTRACT_MBE_PAYMENT_ITEMS;
				} else {
					strTypeName = TYPE_WMS_MEASUREMENT_TASK;
					strRelName = RELATIONSHIP_WMS_ABSTRACT_MBE_ITEMS;
				}
			}else{
				strTypeName = TYPE_WMS_BILL_ITEM;
				strRelName = RELATIONSHIP_WMS_BILL_ITEM;
			}
			
			StringList objList = new StringList();
			objList.addElement(DomainConstants.SELECT_ID);
			objList.addElement(DomainConstants.SELECT_NAME);
			objList.addElement("attribute["+ATTRIBUTE_WMSPAYMENTITEM_AMOUNT+"]");
			objList.addElement("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
			objList.addElement("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
			
			StringList relList = new StringList();
			relList.addElement(DomainRelationship.SELECT_ID);
			relList.addElement("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
			
			double dTotalAmount = 0.0;
			double dPartDeduction = 0.0;
			double dPartPayement = 0.0;
			String strWOPercentage = "";
			String strDeductAmount = "";
			String strDeductReleaseAmount = "";
			strWOPercentage = (String)valueMap.get("to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMSRETENTION_PERCENTAGE+"].value");
			MapList paymentItemMaplist = domainObject.getRelatedObjects(context, // matrix context
					strRelName, // relationship pattern
					strTypeName, // type pattern
					objList, // object selects
					relList, // relationship selects
					false, // to direction
					true, // from direction
					(short) 1, // recursion level
					DomainConstants.EMPTY_STRING, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
				Iterator itr = paymentItemMaplist.iterator();
			while(itr.hasNext()){
				Map paymentMap = (Map)itr.next();
				if("Equipments".equals(strDept) == false){
					String strPreviousQuantity = (String)paymentMap.get("attribute["+ATTRIBUTE_WMS_MBE_ACTIVITY_QUANTITY+"]");
					double dWMSPreviousQuantity = Double.parseDouble(strPreviousQuantity);
					if(strTypeOfContract != null && !"".equals(strTypeOfContract) && strTypeOfContract.equals("EPC")){	
						double dPreviousAmount = dWMSPreviousAmount * dWMSPreviousQuantity / 100;
						dTotalAmount = dTotalAmount + dPreviousAmount;
					} else {
						String strSORRate = (String)paymentMap.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
						double dSORRate = Double.parseDouble(strSORRate);
						double dPreviousAmount = dWMSPreviousQuantity * dSORRate;
						dTotalAmount = dTotalAmount + dPreviousAmount;
					}	
				}else{
					String strAmount = (String)paymentMap.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
					if(UIUtil.isNullOrEmpty(strAmount))
						strAmount = "0";
					dTotalAmount = dTotalAmount + Double.parseDouble(strAmount);
				}					
			}
			
			StringList slDeductionAmount = domainObject.getInfoList(context,"from[WMSAbstractMBETechnicalDeduction].to.attribute[WMSTechnicalDeductionAmount].value");
			for(int ctr1=0;ctr1<slDeductionAmount.size();ctr1++){
				strDeductAmount = (String)slDeductionAmount.get(ctr1);
				if(UIUtil.isNullOrEmpty(strDeductAmount)){
					strDeductAmount = "0";
				}
				dPartDeduction = dPartDeduction + Double.parseDouble(strDeductAmount);
			}
				
			StringList slDeductionReleaseAmount = domainObject.getInfoList(context,"from[WMSAbstractMBETechnicalDeductionRelease].attribute[WMSTechnicalDeductionReleaseCurrentBill].value");
			for(int ctr1=0;ctr1<slDeductionReleaseAmount.size();ctr1++){
				strDeductReleaseAmount = (String)slDeductionReleaseAmount.get(ctr1);
				if(UIUtil.isNullOrEmpty(strDeductReleaseAmount)){
					strDeductReleaseAmount = "0";
				}
				dPartPayement = dPartPayement + Double.parseDouble(strDeductReleaseAmount);
			}
			dTotalAmount = dTotalAmount - dPartDeduction + dPartPayement;
			if (strWOPercentage != null && !"".equals(strWOPercentage)){
				double dWOPercentage = Double.parseDouble(strWOPercentage);
				dRetentionAmount = dTotalAmount * dWOPercentage / 100;
			}
			//dRetentionAmount = dRetentionAmount + (dRetentionAmount*doRetentionsPercentage/100);
			strRetensionAmount = new BigDecimal(dRetentionAmount).setScale(2, BigDecimal.ROUND_UP).toPlainString();
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
		return strRetensionAmount;
	}
	
		/**
	 * PENDING header and annotation
	 * Method called to get the Recoveries 
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getPayments(Context context,String[]args) throws Exception
	{
		MapList mapListAMBPayments = new MapList();
		try
		{
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				StringList strListBusSelects     = new StringList(2);
				strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_TYPE);
				strListBusSelects.add(DomainConstants.SELECT_NAME);
				StringList strListRelSelects     = new StringList(1);
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				strListRelSelects.add("attribute["+ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT+"].value");
				DomainObject domObjTask= DomainObject.newInstance(context, strObjectId);
				mapListAMBPayments = domObjTask.getRelatedObjects(context, // matrix context
						RELATIONSHIP_WMS_AMBPAYMENTS, // relationship pattern
						TYPE_WMSRETENTION_RECOVERYITEM, // type pattern
						strListBusSelects, // object selects
						strListRelSelects, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in getPayments method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB Tree command Recovery, WMSPaymentDetails");
			exception.printStackTrace();
			throw exception;
		}
		return mapListAMBPayments;
	}
	
		/**
	 * PENDING header and annotation
	 * addRecoveries Method to pop out the object connected to the Work Order
	 * with the Wher clause
	 * to add recovery
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList addPayments(Context context,String[]args) throws Exception
	{
		MapList mapListAMBAdvances = new MapList();
		try
		{	
			HashMap programMap 	= (HashMap)JPO.unpackArgs(args);
			String strObjectId		=	(String) programMap.get("objectId"); 
			DomainObject domABSMB 	= DomainObject.newInstance(context , strObjectId);
			String strConnectedRetentions = MqlUtil.mqlCommand(context, "print bus "+strObjectId+" select from["+RELATIONSHIP_WMS_AMBPAYMENTS+"|to.type=="+TYPE_WMSRETENTION_RECOVERYITEM+"].to.id dump |");
			StringList slExistingObjs = FrameworkUtil.split(strConnectedRetentions,"|");
			String strWorkOrder	= domABSMB.getInfo(context, "relationship["+RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.id");
			DomainObject domObj 	= DomainObject.newInstance(context , strWorkOrder);

			StringList strListBusSelects     = new StringList(4);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_TYPE);
			strListBusSelects.add("to["+RELATIONSHIP_WMS_AMBPAYMENTS+"]");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_ADVANCE_AMOUNT+"].value");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_RECOVERY_AMOUNT+"].value");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_RETENTION_RECOVERED+"].value");
			StringList strListRelSelects     = new StringList(1);
			strListRelSelects.add(DomainRelationship.SELECT_ID);

			String strWhere = "attribute["+ATTRIBUTE_WMS_RETENTION_RECOVERED+"].value == No || attribute["+ATTRIBUTE_WMS_RETENTION_RECOVERED+"].value == Partial";

			MapList mapListObjects = domObj.getRelatedObjects(context,
					RELATIONSHIP_WMSWORKORDER_RETUNTIONRECOVERY,               // relationship pattern
					TYPE_WMSRETENTION_RECOVERYITEM,                     // object pattern
					false,                                            // to direction
					true,                                            // from direction
					(short)1,                                     // recursion level
					strListBusSelects,                          // object selects
					strListRelSelects,                             // relationship selects
					strWhere,                                // object where clause
					DomainConstants.EMPTY_STRING,             // relationship where clause
					(short)0,                                  // No expand limit
					DomainConstants.EMPTY_STRING,             // postRelPattern
					DomainConstants.EMPTY_STRING,
					null); 

					// postPatterns
			Iterator<Map<String,String>> iteratorMap = mapListObjects.iterator();
			Map<String,String> mapAdvanceData = new HashMap<String, String>();
			String strItemOID 	= DomainConstants.EMPTY_STRING;

			while(iteratorMap.hasNext())
			{
				mapAdvanceData = iteratorMap.next();
				strItemOID = mapAdvanceData.get(DomainConstants.SELECT_ID);
				if(slExistingObjs.contains(strItemOID))
				{
					continue;
				}
				else
				{
					mapListAMBAdvances.add(mapAdvanceData);
				}
			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
		return mapListAMBAdvances;
	}  

		
		@com.matrixone.apps.framework.ui.ProgramCallable
	public void updateRetentionRecoveryPaid(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			ContextUtil.pushContext(context);
			isContextPushed = true;
			String strAMBEOID = args[0];

			if(UIUtil.isNotNullAndNotEmpty(strAMBEOID))
			{
				StringList strListBusSelects     = new StringList();
				strListBusSelects.add(DomainConstants.SELECT_ID);
				strListBusSelects.add(DomainConstants.SELECT_TYPE);
				strListBusSelects.add(DomainConstants.SELECT_NAME);
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_RETENSION_AMOUNT+"].value");
				strListBusSelects.add("attribute["+ATTRIBUTE_WMS_RETENSION_AMOUNT_PAID_TILL_DATE+"].value");
				StringList strListRelSelects     = new StringList();
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				strListRelSelects.add("attribute["+ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT+"].value");
				DomainObject domObjAbstractMBE = DomainObject.newInstance(context, strAMBEOID);
				MapList mapListAMBPayments = domObjAbstractMBE.getRelatedObjects(context, // matrix context
						RELATIONSHIP_WMS_AMBPAYMENTS, // relationship pattern
						TYPE_WMSRETENTION_RECOVERYITEM, // type pattern
						strListBusSelects, // object selects
						strListRelSelects, // relationship selects
						false, // to direction
						true, // from direction
						(short) 1, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
						
				Map mTemp = null;
				String strId = DomainConstants.EMPTY_STRING;
				String strPayement = DomainConstants.EMPTY_STRING;
				String strPaidTillDate = DomainConstants.EMPTY_STRING;
				String strRetensionAmount = DomainConstants.EMPTY_STRING;
				DomainObject doRetentionObj = null;
				
				double dPayment =0;
				double dPaidTillDate = 0;
				double dRetentionAmount = 0;
				
				for(int i=0;i<mapListAMBPayments.size();i++){
					mTemp = (Map)mapListAMBPayments.get(i);
					strId = (String)mTemp.get(DomainObject.SELECT_ID);
					if(UIUtil.isNotNullAndNotEmpty(strId)){
						strPayement = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT+"].value");
						strPaidTillDate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_RETENSION_AMOUNT_PAID_TILL_DATE+"].value");
						strRetensionAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_RETENSION_AMOUNT+"].value");
						
						dPayment = Double.valueOf(strPayement);
						dPaidTillDate = Double.valueOf(strPaidTillDate);
						dRetentionAmount = Double.valueOf(strRetensionAmount);
						
						Map mAttrMap = new HashMap();
						
						if(dRetentionAmount == (dPayment+dPaidTillDate)){
							mAttrMap.put(ATTRIBUTE_WMS_RETENTION_RECOVERED, "Yes");
						}else{
							mAttrMap.put(ATTRIBUTE_WMS_RETENTION_RECOVERED, "Partial");
						}
						
						mAttrMap.put(ATTRIBUTE_WMS_RETENSION_AMOUNT_PAID_TILL_DATE, String.valueOf(dPayment+dPaidTillDate));
						
						doRetentionObj = new DomainObject(strId);
						doRetentionObj.setAttributeValues(context,mAttrMap);
					}
				}
				
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in updateRetentionRecoveryPaid method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB action trigger on Approve State");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
	} 
	
public void updateRetentionReleaseAmount(Context context,String[] args) throws Exception{
	boolean isContextPushed = false;
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		HashMap hmRequestMap = (HashMap)programMap.get("paramMap");
		String strRelId = (String)hmRequestMap.get("relId");
		String strNewValue = (String)hmRequestMap.get("New Value");
		ContextUtil.pushContext(context);
		isContextPushed = true;
		if(UIUtil.isNotNullAndNotEmpty(strRelId)){
			DomainRelationship doRel = new DomainRelationship(strRelId);
			doRel.setAttributeValue(context, ATTRIBUTE_WMS_RECOVERY_ENTRY_AMOUNT, strNewValue);
		}
		 
		}catch(Exception e) {
			 e.printStackTrace();
		}finally{
			if(isContextPushed)
				ContextUtil.popContext(context);
		}
	}	

	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getBillsRelatedToRelease(Context context, String args[]) throws Exception {    		
		MapList mapListMBEs = new MapList();
		try
		{
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strItemID             = (String) programMap.get("objectID");

			if(strItemID==null ||  "".equals(strItemID)|| "null".equals(strItemID))
			{
				strItemID             = (String) programMap.get("objectId");
			}

			if(strItemID !=null &&  !"".equals(strItemID) && !"null".equals(strItemID))
			{
				String strwhere = DomainConstants.EMPTY_STRING;
				SelectList selListBusSelects     = new SelectList(1);
				selListBusSelects.add(DomainConstants.SELECT_ID);
				SelectList selListRelSelects     = new SelectList(1);
				selListRelSelects.add(DomainRelationship.SELECT_ID);				
				DomainObject domObjItem 		= DomainObject.newInstance(context,strItemID);
				mapListMBEs 					= domObjItem.getRelatedObjects(context, // matrix context
						RELATIONSHIP_WMS_AMBPAYMENTS, // relationship pattern
						TYPE_ABSTRACT_MBE, // type pattern
						selListBusSelects, // object selects
						selListRelSelects, // relationship selects
						true, // to direction
						false, // from direction
						(short) 1, // recursion level
						strwhere, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
			}			
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}		
		return mapListMBEs;
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public void updatePaidTillDateValue(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			ContextUtil.pushContext(context);
			isContextPushed = true;
			String strRetensionId = args[0];
			String strRelId = args[1];

			if(UIUtil.isNotNullAndNotEmpty(strRetensionId))
			{
				DomainObject doRetentionObj = new DomainObject(strRetensionId);
				String strPaidTillDate = (String)doRetentionObj.getAttributeValue(context,ATTRIBUTE_WMS_RETENSION_AMOUNT_PAID_TILL_DATE);
				DomainRelationship doRel = new DomainRelationship(strRelId);
				doRel.setAttributeValue(context,ATTRIBUTE_WMS_RECOVERY_AMOUNT_TILL_PREVIOUS,strPaidTillDate);
			}
		}
		catch(Exception exception)
		{
			System.out.println("Exception in updateRetentionRecoveryPaid method of JPO WMSAdvanceRecovery");
			System.out.println("Called from AMB action trigger on Approve State");
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
	} 

	
}