/*---------------------------------------------------------------------------------------------------------------
NAME		: WMSDelegation.java

DESCRIPTION	: Purpose of JPO is to Create Delegation/Admin Approvals update and perform the utility operations on it

CREATED		: August 13 2019

AUTHOR		: Divyashree B K

HISTORY		:

	Divyashree B K	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectConcept;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.ContextUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import matrix.db.Policy;

import matrix.util.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Calendar;
import matrix.db.MQLCommand;
import java.io.*;

public class WMSDelegation_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSDelegation_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	/**
	* Method to get Realated RICChapters information on ProjectSpace
	*
	* @param context - the eMatrix <code>Context</code> object
	* @param args - args contains a Map with the following entries
	*                      objectId - Object Id of the Context object
	* @return - Maplist
	* @throws Exception if the operation fails
	**/
		
	
	
	       
		public String getEquipmentlAmount(Context context,String args[]) throws Exception{
			String sEquipment = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
				MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);				
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sEquipment = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDEQUIPMENT);
				ContextUtil.popContext(context);
			}
			return sEquipment;
		}
		public String getEquipmentContingency(Context context,String args[]) throws Exception{
			String sEquipment = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
				MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);				
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sEquipment = objDelegate.getAttributeValue(context,ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY);
				ContextUtil.popContext(context);
			}
			return sEquipment;
		}
		public String  getEquipmentRemarks(Context context,String args[]) throws Exception{
			String sEquipmentRemarks = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sEquipmentRemarks = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDEQUIPMENTREMARKS);
				ContextUtil.popContext(context);
			}
			return sEquipmentRemarks;
		}
		public String getWorkAmount(Context context,String args[]) throws Exception{
			String sWork = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sWork = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDWORK);
				ContextUtil.popContext(context);
			}
			return sWork;
		}
		public String getWorkContingency(Context context,String args[]) throws Exception{
			String sWork = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sWork = objDelegate.getAttributeValue(context,ATTRIBUTE_WMS_WORKS_CONTINGENCY);
				ContextUtil.popContext(context);
			}
			return sWork;
		}
		public String getWorkRemarks(Context context,String args[]) throws Exception{
			String sWorkRemarks = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sWorkRemarks = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDWORKREMARKS);
				ContextUtil.popContext(context);
				
			}
			return sWorkRemarks;
		}
		public String getPlanningAmount(Context context,String args[]) throws Exception{
			String sPlanning = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sPlanning = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDPLANNING);
				ContextUtil.popContext(context);
			}
			return sPlanning;
		}
		public String getPlanningContingency(Context context,String args[]) throws Exception{
			String sPlanning = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, true, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sPlanning = objDelegate.getAttributeValue(context,ATTRIBUTE_WMS_PLANNING_CONTINGENCY);
				ContextUtil.popContext(context);
			}
			return sPlanning;
		}
		public String getPlanningRemarks(Context context,String args[]) throws Exception{
			String sPlanningRemarks = "";
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				sPlanningRemarks = objDelegate.getAttributeValue(context,ATTRIBUTE_WMSAPPROVEDPLANNINGREMARKS);
				ContextUtil.popContext(context);
			}
			return sPlanningRemarks;
		}
		
		public void updateDeligationAttribute (Context context,String args[]) throws Exception{
			String projectConceptId = args[0];
			String strPlanningRemarks = args[1];
			String sAttributeName = args[2];
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				DomainObject domSOC = DomainObject.newInstance(context, sSocId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mDelegate = (Map)delegationList.get(0);
				String sDelegated =(String)mDelegate.get("id");
				DomainObject objDelegate = DomainObject.newInstance(context, sDelegated);
				objDelegate.setAttributeValue(context, sAttributeName, strPlanningRemarks);		
			}
		}
		
		public void updateEquipmentlAmount(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDEQUIPMENT};			
			updateDeligationAttribute(context, args1);
		}
		public void updateEquipmentContingency(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY};			
			updateDeligationAttribute(context, args1);
		}
		public void updateWorkAmount(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDWORK};			
			updateDeligationAttribute(context, args1);
		}
		public void updateWorksContingency(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMS_WORKS_CONTINGENCY};			
			updateDeligationAttribute(context, args1);
		}
		public void updatePlanningAmount(Context context,String args[]) throws Exception{
             HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDPLANNING};
			updateDeligationAttribute(context, args1);
		}
		public void updatePlanningContingency(Context context,String args[]) throws Exception{
            HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMS_PLANNING_CONTINGENCY};			
			updateDeligationAttribute(context, args1);
		}
		public void updateEquipmentRemarks(Context context,String args[]) throws Exception{
			 HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDEQUIPMENTREMARKS};
			updateDeligationAttribute(context, args1);
		}
		public void updateWorkRemarks(Context context,String args[]) throws Exception{
			 HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDWORKREMARKS};
			updateDeligationAttribute(context, args1);
		}
		public void updatePlanningRemarks(Context context,String args[]) throws Exception{
			 HashMap programMap = (HashMap) JPO.unpackArgs(args);     
            HashMap paramMap = (HashMap) programMap.get("paramMap");		
			String projectConceptId = (String) paramMap.get("objectId");
			String strEquipmentAmount =(String)paramMap.get("New Value");
			String[] args1 = new String[] {projectConceptId, strEquipmentAmount, ATTRIBUTE_WMSAPPROVEDPLANNINGREMARKS};
			updateDeligationAttribute(context, args1);
		}
		
		public int createDelegation(Context context, String[] args)throws Exception 
		{			
			String sObjectId = args[0];			
			DomainObject socObj = new DomainObject(sObjectId);
			String revision = "";
			revision = new Policy(POLICY_WMSDELEGATION).getFirstInMinorSequence(context);		
            StringList relSelects = new StringList();
            relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				DomainObject domDelegation=DomainObject.newInstance(context);
				MapList mMap = socObj.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", null, relSelects, false, true, (short)0, null, null,0,null,null,null);				
				if(mMap.size()==0){
				String strDelegationName = DomainObject.getAutoGeneratedName(context, "type_WMSDelegation", "");			
				domDelegation.createObject(context, TYPE_WMSDELEGATION, strDelegationName,revision,POLICY_WMSDELEGATION, "eService Production");
				DomainRelationship domRel = DomainRelationship.connect(context, socObj, RELATIONSHIP_WMSSOCDELEGATION, domDelegation);
				}
				
			}
			return 0;
		}
		
	public boolean getDelegateOption(Context context, String[] args) throws Exception
    {
    	boolean showDelegation = false;  
    	try 
    	{
			Map programMap  = JPO.unpackArgs(args);
			String objectId = (String)programMap.get("objectId");		
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(2);
    		selects.add(DomainConstants.SELECT_ID);
			selects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(objectId))
            {
				domProject = DomainObject.newInstance(context, objectId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
				if (socList.size() == 1) {
					Map mSoc = (Map)socList.get(0);
					String sSocId =(String)mSoc.get("id");
					String sSOCState =(String)mSoc.get(DomainConstants.SELECT_CURRENT);
					if (UIUtil.isNullOrEmpty(sSOCState) || (!sSOCState.equalsIgnoreCase(STATE_WMSSOC_DELEGATION) && !sSOCState.equalsIgnoreCase(STATE_WMSSOC_UNDEREXECUTION))){
						return showDelegation;
					}
					DomainObject domSOC = DomainObject.newInstance(context, sSocId);
					MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
					if (delegationList.size() == 1) {
						Map mDelegate = (Map)delegationList.get(0);
						String sStste =(String)mDelegate.get(DomainConstants.SELECT_CURRENT);
						if(sStste.equalsIgnoreCase(STATE_DELEGATECREATE)) {
							showDelegation = true;
						}
					}
				}
			    
			
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		return showDelegation;
    }
	
	public boolean getReDelegateOption(Context context, String[] args) throws Exception
    {
    	boolean showDelegation = false;  
    	try 
    	{
			Map programMap  = JPO.unpackArgs(args);
			String objectId = (String)programMap.get("objectId");			
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(2);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(objectId))
            {
				domProject = DomainObject.newInstance(context, objectId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
				if (socList.size() == 1) {
					Map mSoc = (Map)socList.get(0);
					String sSocId =(String)mSoc.get("id");
					String sSOCState = (String)mSoc.get(DomainConstants.SELECT_CURRENT);
					if (UIUtil.isNullOrEmpty(sSOCState) || (!sSOCState.equalsIgnoreCase(STATE_WMSSOC_DELEGATION) && !sSOCState.equalsIgnoreCase(STATE_WMSSOC_UNDEREXECUTION))){
						return showDelegation;
					}
					DomainObject domSOC = DomainObject.newInstance(context, sSocId);
					MapList mlAdminApprovalList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCADMINAPPROVAL, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
					if (mlAdminApprovalList.size() == 1) {
						Map mAdminApproval = (Map)mlAdminApprovalList.get(0);
						String sStste =(String)mAdminApproval.get(DomainConstants.SELECT_CURRENT);
						if("Approved".equalsIgnoreCase(sStste)) {
							showDelegation = true;
						}
					}
					
					MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
					if (delegationList.size() == 1) {
						Map mDelegate = (Map)delegationList.get(0);
						String sStste =(String)mDelegate.get(DomainConstants.SELECT_CURRENT);
						if(sStste.equalsIgnoreCase(STATE_DELEGATE)) {
							showDelegation = true;
						}else{
							showDelegation = false;
						}
					}
				}				 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		return showDelegation;
    }
	public int checkdelegationdetails(Context context, String[] args) throws Exception
	{
		    String sObjectId = args[0];	
			Double Sum ;
			StringList objectSelects = new StringList();
			objectSelects.add("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
			objectSelects.add("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
			objectSelects.add("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");		
			if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				DomainObject domDelegation=DomainObject.newInstance(context,sObjectId);
				Map mAmp = domDelegation.getInfo(context,objectSelects);
				String sEquipAmount =(String)mAmp.get("attribute[WMSApprovedAmountEquipment]");
				String sPlanAmount = (String)mAmp.get("attribute[WMSApprovedAmountPlanning]");
				String sWorkAmount = (String)mAmp.get("attribute[WMSApprovedAmountWork]");
				Sum =Double.parseDouble(sEquipAmount) + Double.parseDouble(sPlanAmount) + Double.parseDouble(sWorkAmount);							
				if(Sum <= 0)		
			     {					
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "Please enter delegation Details");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
					
				}				
			}
		return 0;
    }
	public static int createApprovalRoute(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doDelObj = null;
			DomainObject dSOCObj = null;
			String strTemplateId ="";
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				doDelObj = new DomainObject(sObjectId);
				MapList socList = doDelObj.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, false, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				dSOCObj = new DomainObject(sSocId);
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doDelObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);					
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
				} else {
					
					String strPolicy = (String)doDelObj.getInfo(context,DomainConstants.SELECT_POLICY);
					String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"Delegation\"";
					MapList routeMapList= dSOCObj.getRelatedObjects(context, RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
					if(routeMapList != null && !routeMapList.isEmpty()){
						Map mRouteTemplateMap = (Map)routeMapList.get(0);
						strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
						String sRouteDescription = (String)doDelObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
						String sState = (String)doDelObj.getInfo(context, DomainConstants.SELECT_CURRENT);
						String strContectUser =  context.getUser();
						Map mRouteAttrib= new HashMap();
						mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
					   
						Map objectRouteAttributeMap=new HashMap();
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy,false ));
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Review");
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,"Review");
						Map reviewerInfo= new HashMap();
					   
						Route.createAndStartRouteFromTemplateAndReviewers(context,
										strTemplateId,
										sRouteDescription,
										strContectUser ,
										sObjectId,
										strPolicy,
										sState,
										mRouteAttrib,
										objectRouteAttributeMap,
										reviewerInfo,
										true);
						/*String strStatus = route.getAttributeValue(context, DomainConstants.ATTRIBUTE_ROUTE_STATUS);
						if(strStatus.equalsIgnoreCase("Not Started")) {
							route.promote(context);
						}*/
					}
					
					}
			}
			return 0;

		}  catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}	
	   public String showApprovalWorkflow(Context context,String [] args) throws Exception {
			StringBuilder sb=new StringBuilder();
			Map mInputMap = (Map) JPO.unpackArgs(args);
			Map requestMap = (Map) mInputMap.get("requestMap");
			String sProjectId = (String)requestMap.get("objectId");
			DomainObject domObject=new DomainObject(sProjectId);
			String sWhere = "revision == last";
			StringList selects = new StringList(1);
			selects.add(DomainConstants.SELECT_ID);
			
			String sSOCObjId = domObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)){
				DomainObject domSOC = DomainObject.newInstance(context, sSOCObjId);
				MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
				if(delegationList.size()>0){			
					Map mDelegate = (Map)delegationList.get(0);
					String sDelegated =(String)mDelegate.get("id");
					String shref = "../wms/wmsActiveTaskGraphicalForAdminApproval.jsp";
					sb.append("<a href=\"javascript:showModalDialog('"+shref+"?objectId="+sDelegated+"','600','400','false');\" >");            
					sb.append("<img border='0' title='Approval Workflow' src='../common/images/iconActionApprovalMass.png' height='15px' name='Approval Workflow' id='Approval Workflow'/>");
					sb.append("</a>");
				}
			}
			return sb.toString();
		}
		
		
	public String getDelegationRevisionHistory(Context context,String [] args) throws Exception {
		StringBuilder sb = new StringBuilder();
		Map mInputMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) mInputMap.get("requestMap");
		String sProjectId = (String)requestMap.get("objectId");
			
		if(UIUtil.isNotNullAndNotEmpty(sProjectId)){
			String shref = "../common/emxIndentedTable.jsp?table=WMSDelegationRevisions&program=WMSDelegation:getDelegationRevisions&header=Revisions of Delegation";
			sb.append("<a href=\"javascript:showModalDialog('"+shref+"&objectId="+sProjectId+"','600','400','false');\" >");            
			sb.append("<img border='0' title='Revision History' src='../common/images/iconActionHistory.png' height='15px' name='Revision History' id='Approval Workflow'/>");
			sb.append("</a>");
		}
			return sb.toString();
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getDelegationRevisions(Context context, String[] args) throws Exception{
		try{
			MapList mlRevisionList = new MapList();
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strObjectId = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				DomainObject doProject = new DomainObject(strObjectId);
				String strSOCId = (String)doProject.getInfo(context,"from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
				StringList relSelects = new StringList();
				relSelects.add(DomainRelationship.SELECT_ID);
				StringList objSelects = new StringList();
				objSelects.add(DomainObject.SELECT_ID);			
				objSelects.add(DomainObject.SELECT_REVISION);						
			
				if(UIUtil.isNotNullAndNotEmpty(strSOCId)){
					DomainObject doSOC = new DomainObject(strSOCId);
					mlRevisionList = (MapList)doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", objSelects, relSelects, false, true, (short)0, null, null,0,null,null,null);					
				}		
				if(mlRevisionList.size()>0){
					mlRevisionList.sort(DomainObject.SELECT_REVISION, ProgramCentralConstants.ASCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
				}
			}
			return mlRevisionList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public boolean getDelegationEditOption(Context context, String[] args) throws Exception {
    	boolean showDelegation = false;  
    	try 
    	{
			Map programMap  = JPO.unpackArgs(args);
			String objectId = (String)programMap.get("objectId");			
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(2);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(objectId))
            {
				domProject = DomainObject.newInstance(context, objectId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
				if (socList.size() == 1) {
					Map mSoc = (Map)socList.get(0);
					String sSocId =(String)mSoc.get(DomainConstants.SELECT_ID);
					String sSOCState =(String)mSoc.get(DomainConstants.SELECT_CURRENT);
					if (UIUtil.isNotNullAndNotEmpty(sSOCState) && (sSOCState.equalsIgnoreCase(STATE_WMSSOC_DELEGATION) || sSOCState.equalsIgnoreCase(STATE_WMSSOC_UNDEREXECUTION))) {
						DomainObject domSOC = DomainObject.newInstance(context, sSocId);
						MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
						if (delegationList.size() == 1) {
							Map mDelegate = (Map)delegationList.get(0);
							String sStste =(String)mDelegate.get(DomainConstants.SELECT_CURRENT);
							if(sStste.equalsIgnoreCase(STATE_DELEGATECREATE)) {
								showDelegation = true;
							}
						}
					}
				}				 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		return showDelegation;
    }
	public String getAssociatedProject(Context context,String args[]) throws Exception{
			String sTitle = "";
			try{
			
			Map programMap = (Map) JPO.unpackArgs(args);
			Map requestMap = (Map) programMap.get("requestMap");
				// Get object id
			String strObjectId = (String)requestMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject doAA = new DomainObject(strObjectId);
				String sSOCId = (String)doAA.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.id");
				if(UIUtil.isNotNullAndNotEmpty(sSOCId))
				{
				DomainObject doSOC = new DomainObject(sSOCId);
				sTitle = (String)doSOC.getInfo(context,"to["+RELATIONSHIP_WMSPROJECTSOC+"].from.name");
				}
			}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return sTitle;
		}
		public String getCurrentState(Context context,String args[]) throws Exception{
		String sState = "";
		try{
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String projectConceptId = (String) paramMap.get("objectId");
			String sWhere = "revision == last";
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			if(ProgramCentralUtil.isNotNullString(projectConceptId))
            {
				domProject = DomainObject.newInstance(context, projectConceptId);
				ContextUtil.pushContext(context);
				String sSOCObjId = domProject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");	
				if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)){
					DomainObject domSOC = DomainObject.newInstance(context, sSOCObjId);
					MapList AAList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, true, true, (short)0, sWhere, null,0,null,null,null);
					if(AAList.size()>0)
					{
						Map mAA = (Map)AAList.get(0);
						String sAA =(String)mAA.get("id");					
						sState = (String)mAA.get(DomainConstants.SELECT_CURRENT);
					}
				}
				
			}
		}
        catch(Exception e)
		{
			e.printStackTrace();
		}
	return sState;
	}
	public String showApprovalHistory(Context context,String [] args) throws Exception {
		StringBuilder sb = new StringBuilder();
		Map mInputMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) mInputMap.get("requestMap");
		String sProjectId = (String)requestMap.get("objectId");
			
		if(UIUtil.isNotNullAndNotEmpty(sProjectId)){
			String shref = "../common/emxIndentedTable.jsp?table=WMSApprovalHistory&program=WMSDelegation:getAllApprovedTask&header=Approval History of Admin Approval";
			sb.append("<a href=\"javascript:showModalDialog('"+shref+"&objectId="+sProjectId+"','600','400','false');\" >");            
			sb.append("<img border='0' title='Revision History' src='../common/images/iconActionHistory.png' height='15px' name='Approval History' id='Approval History'/>");
			sb.append("</a>");
		}
			return sb.toString();
	}	
	 @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getAllApprovedTask(Context context, String[] args) throws Exception {
		MapList mlInboxTask = new MapList();
		MapList returnList = new MapList();
        try {

			Pattern includeType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
			MapList mlDelegationList = new MapList();
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
           
			String sWhere = "revision == last";
			String strObjectId = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
			DomainObject doProject = new DomainObject(strObjectId);
			String strSOCId = (String)doProject.getInfo(context,"from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			StringList objSelects = new StringList();
			objSelects.add(DomainObject.SELECT_ID);	
			if(UIUtil.isNotNullAndNotEmpty(strSOCId)){
				DomainObject doSOC = new DomainObject(strSOCId);
				mlDelegationList = (MapList)doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", objSelects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				Map mAA = (Map)mlDelegationList.get(0);
			String strID = (String) mAA.get(DomainObject.SELECT_ID);
			
			StringList objectList = new StringList();
			objectList.addElement(DomainConstants.SELECT_ID);
			objectList.addElement(DomainConstants.SELECT_TYPE);
			objectList.addElement(DomainConstants.SELECT_CURRENT);
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_FIRST_NAME+"]");
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.id");
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_LAST_NAME+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ROUTE_TASK_USER+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_APPROVAL_STATUS+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
			objectList.addElement("format.file.name");
			objectList.addElement("format.file.format");
			objectList.addElement("format.file.fileid");
			objectList.addElement("from["+RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].attribute["+ATTRIBUTE_ROUTE_BASE_STATE+"].value");
			
			
			StringList relList = new StringList();
			relList.addElement(DomainRelationship.SELECT_ID);
			relList.addElement("attribute[Route Base State].value");

			DomainObject dObject = DomainObject.newInstance(context,strID);

			MapList mlRoutes = dObject.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_OBJECT_ROUTE,  //String relPattern
					DomainConstants.TYPE_ROUTE, //String typePattern
					objectList,            //StringList objectSelects,
					relList,    		   //StringList relationshipSelects,
					false,                  //boolean getTo,
					true,                  //boolean getFrom,
					(short)1,              //short recurseToLevel,
					"",   				   //String objectWhere,
					//"attribute[Route Base State].value == state_Review",             //String relationshipWhere,
					"",             //String relationshipWhere,
					0);        
			Map mTemp = null;
			String strRouteId = DomainConstants.EMPTY_STRING;
			DomainObject doRoute = null;
			for(int i=0;i<mlRoutes.size();i++){
				mTemp = (Map)mlRoutes.get(i);
				strRouteId = (String)mTemp.get(DomainObject.SELECT_ID);
				doRoute = new DomainObject(strRouteId);
				MapList mlRouteTasks = doRoute.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_ROUTE_TASK,  //String relPattern
					DomainConstants.TYPE_INBOX_TASK, //String typePattern
					objectList,            //StringList objectSelects,
					relList,    		   //StringList relationshipSelects,
					true,                  //boolean getTo,
					false,                  //boolean getFrom,
					(short)1,              //short recurseToLevel,
					"",   				   //String objectWhere,
					"",             //String relationshipWhere,
					0); 
				mlInboxTask.addAll(mlRouteTasks);
			}
			
		Iterator itr = mlInboxTask.iterator();
		while(itr.hasNext()){
			Map returnMap = (Map)itr.next();
			String strState = (String)returnMap.get(DomainConstants.SELECT_CURRENT);
			if(strState != null && !"".equals(strState) && strState.equals("Complete")){
				returnList.add(returnMap);
			}
		  }			
		 }
			}
	     }
		 catch (Exception e){
		
		 }
		 returnList.sort("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]","ascending","date");
		
		  return returnList;
	
	}
	
	public boolean getDownloadDelegationOption(Context context, String[] args) throws Exception
    {
    	boolean showDelegation = false;  
    	try 
    	{
			Map programMap  = JPO.unpackArgs(args);
			String objectId = (String)programMap.get("objectId");			
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(2);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision == last";
			if(ProgramCentralUtil.isNotNullString(objectId))
            {
				domProject = DomainObject.newInstance(context, objectId);
    			MapList socList = domProject.getRelatedObjects(context, RELATIONSHIP_WMSPROJECTSOC, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
				if (socList.size() == 1) {
					Map mSoc = (Map)socList.get(0);
					String sSocId =(String)mSoc.get("id");
					String sSOCState = (String)mSoc.get(DomainConstants.SELECT_CURRENT);
					if (UIUtil.isNullOrEmpty(sSOCState) || (!sSOCState.equalsIgnoreCase(STATE_WMSSOC_DELEGATION) && !sSOCState.equalsIgnoreCase(STATE_WMSSOC_UNDEREXECUTION))){
						return showDelegation;
					}
					DomainObject domSOC = DomainObject.newInstance(context, sSocId);
					MapList delegationList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
					if (delegationList.size() == 1) {
						showDelegation = true;
					}
				}				 
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		return showDelegation;
    }
	
	
	public void generateDelegationPDF(Context context, String[] args)throws Exception{
		try{
			HashMap params      = new HashMap();
			String strObjId = (String)args[0];
			DomainObject doDelegation = new DomainObject(strObjId);
			String strSOCId = (String)doDelegation.getInfo(context,"to["+RELATIONSHIP_WMSSOCDELEGATION+"].from.id");
			params.put("objectId", strSOCId);
			String strDelegationId = downloadDelegation(context,JPO.packArgs(params));
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;			
		}
	}
	
	public String downloadDelegation(Context context , String [] args) throws Exception
	{
		String strDelegationId = DomainConstants.EMPTY_STRING;
	try {
			HashMap programMap      = (HashMap)JPO.unpackArgs(args);
			String strObjID         = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strObjID)){
				DomainObject doSOC = new DomainObject(strObjID);
				StringList slObjSelect = new StringList();
				slObjSelect.add(DomainObject.SELECT_ID);
				slObjSelect.add(DomainObject.SELECT_TYPE);
				slObjSelect.add("attribute[Title]");
				slObjSelect.add("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
				slObjSelect.add("from["+TYPE_WMSAE+"]");
				
				StringList slSOCSelect = new StringList();
				slSOCSelect.add("attribute["+ATTRIBUTE_WMSSOC_EQUIPMENTS_INCLUDED+"]");
				slSOCSelect.add("attribute["+ATTRIBUTE_WMSSOC_WORKS_INCLUDED+"]");
				slSOCSelect.add("attribute["+ATTRIBUTE_WMSSOC_SERVICES_INCLUDED+"]");
				slSOCSelect.add("attribute[Title]");
				slSOCSelect.add("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
				
				Map mSOCInfo = doSOC.getInfo(context,slSOCSelect);
				String strEquipSelected = (String)mSOCInfo.get("attribute["+ATTRIBUTE_WMSSOC_EQUIPMENTS_INCLUDED+"]");
				String strWorksSelected = (String)mSOCInfo.get("attribute["+ATTRIBUTE_WMSSOC_WORKS_INCLUDED+"]");
				String strServicesSelected = (String)mSOCInfo.get("attribute["+ATTRIBUTE_WMSSOC_SERVICES_INCLUDED+"]");
				String strProjectTitle = (String)mSOCInfo.get("attribute[Title]");
				String strCodeHead = (String)mSOCInfo.get("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.id");
				
				MapList mlApprivedAEList =  doSOC.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSSOC_APPROVEDAEMASTER, // relationship pattern
														TYPE_WMSAEMASTER, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														null, // object where clause
														null); // relationship where clause
					
				Map mTemp = null;
				double dEquipmentAmount = 0.0;
				double dWorksAmount = 0.0;
				double dPlanningAmount = 0.0;
				
				double dEquipmentContAmount = 0.0;
				double dWorksContAmount = 0.0;
				double dPlanningContAmount = 0.0;
				
				String strTitle = DomainConstants.EMPTY_STRING;
				String strId = DomainConstants.EMPTY_STRING;
				String strEquipmentSeq = DomainConstants.EMPTY_STRING;
				String strWorksSeq = DomainConstants.EMPTY_STRING;
				String strServicesSeq = DomainConstants.EMPTY_STRING;
				
				String strAAAmount = DomainConstants.EMPTY_STRING;
				String strAADuration = DomainConstants.EMPTY_STRING;
				String strAALetterNo = DomainConstants.EMPTY_STRING;
				String strAADate = DomainConstants.EMPTY_STRING;		
				String strDelName = DomainConstants.EMPTY_STRING;
				String strDelRev = DomainConstants.EMPTY_STRING;
				String strDelDate = DomainConstants.EMPTY_STRING;
				String strDGName = DomainConstants.EMPTY_STRING;
				String strDGDesignation = DomainConstants.EMPTY_STRING;
				
				String strCodeHeadName = DomainConstants.EMPTY_STRING;
				String strMajorHead = DomainConstants.EMPTY_STRING;
				String strMinorHead = DomainConstants.EMPTY_STRING;
				
				if(UIUtil.isNotNullAndNotEmpty(strCodeHead)){
					DomainObject doCodeHead = new DomainObject(strCodeHead);
					StringList slCodeHeadSelect = new StringList();
					slCodeHeadSelect.add("attribute[Title]");
					slCodeHeadSelect.add("attribute["+ATTRIBUTE_WMS_MAJOR_HEAD+"]");
					slCodeHeadSelect.add("attribute["+ATTRIBUTE_WMS_MINOR_HEAD+"]");
					Map mCodeHeadInfo = doCodeHead.getInfo(context,slCodeHeadSelect);
					
					if(mCodeHeadInfo!=null){
						strCodeHeadName = (String)mCodeHeadInfo.get("attribute[Title]");
						strMajorHead = (String)mCodeHeadInfo.get("attribute["+ATTRIBUTE_WMS_MAJOR_HEAD+"]");
						strMinorHead = (String)mCodeHeadInfo.get("attribute["+ATTRIBUTE_WMS_MINOR_HEAD+"]");
					}
				}
				
				
				Map mTempAE = null;
				String strSeq = DomainConstants.EMPTY_STRING;
				String strHasChild = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlApprivedAEList.size();i++){
					mTemp = (Map)mlApprivedAEList.get(i);
					strTitle = (String)mTemp.get("attribute[Title]");
					strId = (String)mTemp.get(DomainObject.SELECT_ID);
					
					if("Services".equals(strTitle)){
						DomainObject doAEMastet = new DomainObject(strId);
						MapList mlAEList =  doAEMastet.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														null, // object where clause
														null); // relationship where clause
						for(int j=0;j<mlAEList.size();j++){
							mTempAE = (Map)mlAEList.get(j);
							strHasChild = (String)mTempAE.get("from["+TYPE_WMSAE+"]");
							if(UIUtil.isNullOrEmpty(strServicesSeq)){
								strServicesSeq = (String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
							}else{
								strServicesSeq = strServicesSeq+","+(String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
							}
						}
						
					}
					if("Equipments".equals(strTitle)){						
						DomainObject doAEMastet = new DomainObject(strId);
						MapList mlAEList =  doAEMastet.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														null, // object where clause
														null); // relationship where clause
						for(int j=0;j<mlAEList.size();j++){
							mTempAE = (Map)mlAEList.get(j);
							strHasChild = (String)mTempAE.get("from["+TYPE_WMSAE+"]");
							if(UIUtil.isNullOrEmpty(strEquipmentSeq)){
								strEquipmentSeq = (String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
							}else{
								strEquipmentSeq = strEquipmentSeq+","+(String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
							}
						}
					}
					if("Works".equals(strTitle)){
						DomainObject doAEMastet = new DomainObject(strId);
						MapList mlAEList =  doAEMastet.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														slObjSelect, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														null, // object where clause
														null); // relationship where clause
						for(int j=0;j<mlAEList.size();j++){
							mTempAE = (Map)mlAEList.get(j);
							strHasChild = (String)mTempAE.get("from["+TYPE_WMSAE+"]");
							if(UIUtil.isNotNullAndNotEmpty(strHasChild) && "false".equalsIgnoreCase(strHasChild)){
								if(UIUtil.isNullOrEmpty(strWorksSeq)){
									strWorksSeq = (String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
								}else{
									strWorksSeq = strWorksSeq+","+(String)mTempAE.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"]");
								}
							}
						}
					}
				}
				
				if(UIUtil.isNotNullAndNotEmpty(strWorksSelected) && "true".equalsIgnoreCase(strWorksSelected)){
					strWorksSelected = strWorksSelected +","+ strServicesSeq;
					
				}else if(UIUtil.isNotNullAndNotEmpty(strEquipSelected) && "true".equalsIgnoreCase(strEquipSelected)){
					strEquipSelected = strEquipSelected +","+ strServicesSeq;
				}else{
					if(UIUtil.isNullOrEmpty(strWorksSelected))
						strWorksSelected = strServicesSeq;
					else
						strWorksSelected = strWorksSelected +","+ strServicesSeq;
				}
								
				String sWhere = "revision == last";
				StringList slDelSelect = new StringList();
				slDelSelect.add(DomainObject.SELECT_ID);
				slDelSelect.add(DomainObject.SELECT_NAME);
				slDelSelect.add(DomainObject.SELECT_ORIGINATED);
				slDelSelect.add(DomainObject.SELECT_REVISION);
				slDelSelect.add("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
				slDelSelect.add("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
				MapList delegationList = doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", slDelSelect, null, true, true, (short)0, sWhere, null,0,null,null,null);
				if(delegationList.size()>0){
					Map mDelegate = (Map)delegationList.get(0);
					if(mDelegate != null){
						String strWorksAmount = (String)mDelegate.get("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
						String strEquipAmount = (String)mDelegate.get("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
						String strPlanAmount = (String)mDelegate.get("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
						String strWorksCont = (String)mDelegate.get("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
						String strEquipCont = (String)mDelegate.get("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
						String strPlanCont = (String)mDelegate.get("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
						strDelName = (String)mDelegate.get(DomainObject.SELECT_NAME);
						strDelRev = (String)mDelegate.get(DomainObject.SELECT_REVISION);
						strDelDate = (String)mDelegate.get(DomainObject.SELECT_ORIGINATED);
						strDelegationId = (String)mDelegate.get(DomainObject.SELECT_ID);
						if(UIUtil.isNullOrEmpty(strWorksAmount))
							strWorksAmount = "0";
						if(UIUtil.isNullOrEmpty(strEquipAmount))
							strEquipAmount = "0";
						if(UIUtil.isNullOrEmpty(strPlanAmount))
							strPlanAmount = "0";
						if(UIUtil.isNullOrEmpty(strWorksCont))
							strWorksCont = "0";
						if(UIUtil.isNullOrEmpty(strEquipCont))
							strEquipCont = "0";
						if(UIUtil.isNullOrEmpty(strPlanCont))
							strPlanCont = "0";
						
						dEquipmentAmount = Double.valueOf(strEquipAmount);
						dWorksAmount = Double.valueOf(strWorksAmount);
						dPlanningAmount = Double.valueOf(strPlanAmount);
						dEquipmentContAmount = Double.valueOf(strEquipCont);
						dWorksContAmount = Double.valueOf(strWorksCont);
						dPlanningContAmount = Double.valueOf(strPlanCont);
					}
				}
				
				double dWorksTotal = 0.0;
				double dEquipmentTotal = 0.0;
				
				dWorksTotal = dWorksAmount+dWorksContAmount;
				dEquipmentTotal = dEquipmentAmount+dEquipmentContAmount;
				String strWorksTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksTotal);
				String strEquipmentTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentTotal);
				strWorksTotal = "Rs. "+strWorksTotal;
				strEquipmentTotal = "Rs. "+strEquipmentTotal;
				
				StringList selects = new StringList();
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALDATE+"]");
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALDURATION+"]");
				selects.add("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
				MapList AAList = doSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOCADMINAPPROVAL, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
				if(AAList.size()>0){
					Map mAA = (Map)AAList.get(0);
					if(mAA != null){
						strAAAmount = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
						strAADuration = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALDURATION+"]");
						strAALetterNo = (String)mAA.get("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
						strAADate = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALDATE+"]");
					}
				}

				DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
				Date date1 = eMatrixDateFormat.getJavaDate(strAADate);
				strAADate = dateFormat.format(date1);
				
				Date date2 = eMatrixDateFormat.getJavaDate(strDelDate);
				strDelDate = dateFormat.format(date2);
				
				String strDelegationNumber = "DG/_____/_____/_____/_____/_____/Plg";
				String strHeader = strDelName+" Rev. "+strDelRev;
				
				String strAAInWords = WMSUtil_mxJPO.getValueInWords(strAAAmount);
				strAAAmount = WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strAAAmount));
				
				strAAAmount = "Rs. "+strAAAmount+" ("+strAAInWords+" ).";
				strDGName = EnoviaResourceBundle.getProperty(context,"WMS.DGNP.DGName");
				StringList slDG = FrameworkUtil.split(strDGName,"|");
				if(slDG.size()==2){
					strDGName = (String)slDG.get(0);
					strDGDesignation = (String)slDG.get(1);
				}
				
				
				//xml write stared
				
				String strTransPath = context.createWorkspace();
				String xmlSourceFileName = "DelegationFormSource.xml";
				String xmlFilePath = strTransPath + File.separator+xmlSourceFileName;
				DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
				Document document = documentBuilder.newDocument();
				Element root = document.createElement("page");
				document.appendChild(root);
				String strpath = System.getProperty("user.dir");
			    File newFile = new File(strpath+"/..");
				
				String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
				String strLogo = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Logo");
				String strWatermark = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Watermark");
				strWatermark = strWatermark.replace("\\", "/");
				strLogo = strLogo.replace("\\", "/");
				Element embLogo = document.createElement("logo1");
				embLogo.appendChild(document.createTextNode("file:"+strLogo));
				
				Element embHeader = document.createElement("header-footer");
				Element embWatermark = document.createElement("watermark");
				embWatermark.appendChild(document.createTextNode("file:"+strWatermark));
				embHeader.appendChild(document.createTextNode(strHeader));
				root.appendChild(embHeader);
				root.appendChild(embWatermark);
				root.appendChild(embLogo);
				
				Element elesWorkTotal =  document.createElement("work-total");
				elesWorkTotal.appendChild(document.createTextNode(strWorksTotal ));
				root.appendChild(elesWorkTotal);
				
				Element elesEquipmentTotal =  document.createElement("equipment-total");
				elesEquipmentTotal.appendChild(document.createTextNode(strEquipmentTotal));
				root.appendChild(elesEquipmentTotal);
				
				Element eleLetterNo =  document.createElement("letter-index-no");
				eleLetterNo.appendChild(document.createTextNode(strDelegationNumber));
				root.appendChild(eleLetterNo);
				
				Element elesDate =  document.createElement("letter-date");
				elesDate.appendChild(document.createTextNode(strDelDate));
				root.appendChild(elesDate);
				
				Element elesConstructionName =  document.createElement("construction-name");
				elesConstructionName.appendChild(document.createTextNode(strProjectTitle));
				root.appendChild(elesConstructionName);
				
				Element elesamount =  document.createElement("amount");
				elesamount.appendChild(document.createTextNode(strAAAmount));
				root.appendChild(elesamount);
				
				Element elesAADate =  document.createElement("date");
				elesAADate.appendChild(document.createTextNode(strAADate));
				root.appendChild(elesAADate);
					
				Element eleDelDDGCE =  document.createElement("delegation-ddg-ce");
					
				Element eleSequence = document.createElement("sequence");
				eleSequence.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(1)));
					
				Element elemItem = document.createElement("item-ddg-ce");
				elemItem.appendChild(document.createTextNode("Item No. " + strWorksSeq + " of AE Part-I"));
				
				Element elemItemValue = document.createElement("item-ddg-ce-value");
				elemItemValue.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dWorksAmount))));
				
				eleDelDDGCE.appendChild(eleSequence);
				eleDelDDGCE.appendChild(elemItem);
				eleDelDDGCE.appendChild(elemItemValue);
				
				root.appendChild(eleDelDDGCE);
				
				Element eleDelDDGCE1 =  document.createElement("delegation-ddg-ce");
				
				Element eleSequence1 = document.createElement("sequence");
				eleSequence1.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(2)));
				
				Element elemItem1 = document.createElement("item-ddg-ce");
				elemItem1.appendChild(document.createTextNode("Contingency of AE Part-I"));
				
				Element elemItemValue1 = document.createElement("item-ddg-ce-value");
				elemItemValue1.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dWorksContAmount))));
				
				eleDelDDGCE1.appendChild(eleSequence1);
				eleDelDDGCE1.appendChild(elemItem1);
				eleDelDDGCE1.appendChild(elemItemValue1);
				root.appendChild(eleDelDDGCE1);
				
				Element eleDelDDGE =  document.createElement("delegation-ddg-e");
					
				Element eleSequenceE = document.createElement("sequence-e");
				eleSequenceE.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(1)));
					
				Element elemItemE = document.createElement("item-ddg-e");
				elemItemE.appendChild(document.createTextNode("Item No. " + strEquipmentSeq + " of AE Part-I"));
				
				Element elemItemValueE = document.createElement("item-ddg-e-value");
				elemItemValueE.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dEquipmentAmount))));
				
				eleDelDDGE.appendChild(eleSequenceE);
				eleDelDDGE.appendChild(elemItemE);
				eleDelDDGE.appendChild(elemItemValueE);
				
				root.appendChild(eleDelDDGE);
				
				
				Element eleDelDDGE2 =  document.createElement("delegation-ddg-e");
					
				Element eleSequenceE2 = document.createElement("sequence-e");
				eleSequenceE2.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(2)));
					
				Element elemItemE2 = document.createElement("item-ddg-e");
				elemItemE2.appendChild(document.createTextNode("Contingency of AE Part-I"));
				
				Element elemItemValueE2 = document.createElement("item-ddg-e-value");
				elemItemValueE2.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dEquipmentContAmount))));
				
				eleDelDDGE2.appendChild(eleSequenceE2);
				eleDelDDGE2.appendChild(elemItemE2);
				eleDelDDGE2.appendChild(elemItemValueE2);
				
				root.appendChild(eleDelDDGE2);
				
				Element eleDelDDGP1 =  document.createElement("delegation-ddg-p");
					
				Element eleSequenceP1 = document.createElement("sequence-p");
				eleSequenceP1.appendChild(document.createTextNode(WMSUtil_mxJPO.conertToRoman(1)));
					
				Element elemItemP1 = document.createElement("item-ddg-p");
				elemItemP1.appendChild(document.createTextNode("Contingency of AE Part-I"));
				
				Element elemItemValueP1 = document.createElement("item-ddg-p-value");
				elemItemValueP1.appendChild(document.createTextNode("Rs. "+WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(dPlanningContAmount))));
				
				eleDelDDGP1.appendChild(eleSequenceP1);
				eleDelDDGP1.appendChild(elemItemP1);
				eleDelDDGP1.appendChild(elemItemValueP1);
				
				root.appendChild(eleDelDDGP1);
				
				//majo header
				Element elemMajorHead = document.createElement("major-head");
				elemMajorHead.appendChild(document.createTextNode(strMajorHead));
				Element elemMinorHead = document.createElement("minor-head");
				elemMinorHead.appendChild(document.createTextNode(strMinorHead));
				Element elemCodeHead = document.createElement("code-head");
				elemCodeHead.appendChild(document.createTextNode(strCodeHeadName));
				root.appendChild(elemMajorHead);
				root.appendChild(elemMinorHead);
				root.appendChild(elemCodeHead);
				
				
				//signature
				 Element elemDGName = document.createElement("dg-name");
                elemDGName.appendChild(document.createTextNode("("+strDGName+")"));
               
                Element elemDGRank = document.createElement("dg-rank");
                elemDGRank.appendChild(document.createTextNode(strDGDesignation));
               
                root.appendChild(elemDGName);
                root.appendChild(elemDGRank);
				
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource domSource = new DOMSource(document);
				StreamResult streamResult = new StreamResult(new File(xmlFilePath));
				transformer.transform(domSource, streamResult);
				File xmlFile = new File(xmlFilePath);
				
				//Write XML - End
				
				//Write XSL - Start
				String strXSLFile = "DelegationFormSource.xsl";
				File newTextFile = new File(strTransPath + File.separator+strXSLFile);

				MQLCommand mql = new MQLCommand();
				mql.open(context);
				mql.executeCommand(context, "print program WMSDelegation.xsl select code dump");
				mql.close(context);
				FileWriter fw = new FileWriter(newTextFile);
				fw.write(mql.getResult());
				fw.close();		
				
				File xsltFile = new File(strTransPath + File.separator+strXSLFile);
				StreamSource xmlSource = new StreamSource(new File(xmlFilePath));
				String strName = "Delegation";
				String strFileName = strName+".pdf";
				OutputStream out;
				String strDocumentId = DomainConstants.EMPTY_STRING;
				out = new java.io.FileOutputStream(strTransPath+File.separator+strFileName);
				try {
					FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());		
					FOUserAgent foUserAgent = fopFactory.newFOUserAgent();			
					Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);
					TransformerFactory factory = TransformerFactory.newInstance();
					Transformer transformer1 = factory.newTransformer(new StreamSource(xsltFile));
					Result res = new SAXResult(fop.getDefaultHandler());
					transformer1.transform(xmlSource, res);
					DomainObject doDel = new DomainObject(strDelegationId);
					ContextUtil.pushContext(context);
					doDel.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strTransPath);
					ContextUtil.popContext(context);
				  } 	
				  catch(Exception exception)
				  {
						exception.printStackTrace();
				  }	
				
				
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return strDelegationId;
	}
	
	public String showDownloadIcon(Context context,String[] args) throws Exception{
		StringBuilder sb=new StringBuilder();
		 try { 
			Map mInputMap = (Map) JPO.unpackArgs(args);
		   Map requestMap = (Map) mInputMap.get("requestMap");
		   String strObjectId = (String) requestMap.get("objectId");
		   String downloadURL = "../components/emxCommonDocumentPreCheckout.jsp?objectAction=download&objectId="+strObjectId; 
		   String strDownLoadTip="Download Bill Form";
		 
			 sb.append("<a href=\"" + downloadURL + "\"  target=\"formViewHidden\"   >");
			 sb.append("<img border=\"0\" src=\"../common/images/iconActionDownload.gif\" alt=\""
			+ strDownLoadTip + "\" title=\"" + strDownLoadTip + "\"></img></a>&#160;");
		
		 }catch(Exception e) {
			 e.printStackTrace();
		 } 
		return  sb.toString();
	 }

}  

 
