/** Name of the JPO	: WMSJob
 ** WMS program
 **/
import java.util.HashMap;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.RelationshipType;
import matrix.util.MatrixException;
import matrix.util.StringList;
import java.util.Map;

import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.Job;
import com.matrixone.apps.domain.Job.BackgroundJob;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MailUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;


/**
 * The purpose of this JPO is to create back ground jobs.
 * @version R417 
 */
public class WMSJob_mxJPO implements BackgroundJob
{
	protected Job _job = new Job();
	protected String _jobId = null;

	public static final String SYMBOLIC_attribute_NotifyOwner = "attribute_NotifyOwner";
    public static final String SYMBOLIC_attribute_ActionOnCompletion = "attribute_ActionOnCompletion";
    public static final String ATTRIBUTE_NOTIFY_OWNER = PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_NotifyOwner);
    public static final String ATTRIBUTE_ACTION_COMPLETE = PropertyUtil.getSchemaProperty(SYMBOLIC_attribute_ActionOnCompletion);
	public static final String RELATIONSHIP_WMS_WORK_ORDER_MBE = PropertyUtil.getSchemaProperty("relationship_WMSWOMBE");
	public static final String TYPE_WMS_MEASUREMENT_BOOK_ENTRY = PropertyUtil.getSchemaProperty("type_WMSMeasurementBookEntry");
    
	public void setJob(Job job)
	{
		_job = job;
	}

	public Job getJob()
	{
		return _job;
	}

	/**
	 * Constructor.
	 * @param context - the eMatrix <code>Context</code> object
	 * @param args - holds no arguments
	 * @throws Exception if the operation fails
	 * @author GVPP 
	 * @since 417
	 */

	public WMSJob_mxJPO(Context context, String[] args) throws Exception
	{
		if (args.length > 0 && args[0] != null && !"".equals(args[0]))
		{
			HashMap objectMap = (HashMap) JPO.unpackArgs(args);
			_jobId = (String) objectMap.get("Job ID");
			_job = Job.getInstance(context, _jobId, "EDM");
		}
	}
	/** 
	 * Method to create Job for the Import Items from file
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps for the table
	 * @throws Exception if the operation fails
	 * @since 417
	 */
	public void importItems(Context context, String args[]) throws Exception
	{
		Job jobObj = getJob();
		String strAction =  "";
		StringList strError = new StringList();
		if(args.length > 4)
		{
		    strAction = args[4];
		}
		setJobAttributes(context, jobObj, "No");
		boolean booleanError = false;
		String strMethodName = "";
		String packArgs[] = null;
		try
		{
		    if("SORItemImport".equals(strAction))
		    {
		        strMethodName = "importClassifiedItems";
		    	packArgs = new String[] {args[0],args[1],args[2],args[3],args[4],args[5],jobObj.getId(context)};
		    	args = packArgs;
		    }
		    if("MeasurementsImport".equals(strAction))
		    {
		        strMethodName = "importMeasurementItems";
		    }
		    if("SORImportForWO".equals(strAction))
		    {
		        strMethodName = "importSORItems";
		    }
		    if("BOQImport".equals(strAction))
		    {
		        strMethodName = "importBOQ";
		    }
			if("RICItemImport".equals(strAction) || "AEItemImport".equals(strAction) || "ApprovedAEItemImport".equals(strAction) || "DCSItemImport".equals(strAction))
		    {
		        strMethodName = "importItems";
		    }
			
		    strError = (StringList)JPO.invoke(context,"WMSImport",args,strMethodName,args,StringList.class);
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		if(strError.size() > 0)
		{
			String strErrorMessage = strError.get(0).toString();
			if(strErrorMessage.indexOf("Message")>=0)
			{
				StringList error = FrameworkUtil.split(strErrorMessage, ":");
				setJobFinishStatus(context, jobObj, true,error.get(1).toString());
				sendJobCompletionMail(context, jobObj, true,error.get(1).toString());
			
			}
		}
		else
		{
			setJobFinishStatus(context, jobObj, booleanError,DomainConstants.EMPTY_STRING);
			sendJobCompletionMail(context, jobObj, booleanError,strAction);
		}	
	    
	}
	
	/** 
	 * Method set the Job status based on error value
	 * @param context the eMatrix <code>Context</code> object
	 * @param jobObj Job on which status to be set
	 * @param booleanError if True sets status as Succeeded else as Failed 
	 * @throws MatrixException if the operation fails
	 * @throws FrameworkException if the operation fails
	 * @since 417
	 */
	public void setJobFinishStatus(Context context, Job jobObj,
			boolean booleanError,String strErrorMsg) throws MatrixException, FrameworkException {
		if (jobObj.exists(context))
		{
			if (!booleanError)
			{
				jobObj.finish(context, "Succeeded");
			}
			else
			{
				jobObj.finish(context, "Failed");
				jobObj.setAttributeValue(context, "Error Message", strErrorMsg);
			}
		}

	}
	/** 
	 * Method to send mail on Job completion
	 * @param context the eMatrix <code>Context</code> object
	 * @param jobObj Job on which status to be set	
	 * @param booleanError if True with set success body and subject message 
	 * @param strAction - Job details
	 * @throws FrameworkException if the operation fails
	 * @since 417
	 */
	public void sendJobCompletionMail(Context context, Job jobObj,
			boolean booleanError,String strAction) throws FrameworkException {
		String strSubject = DomainConstants.EMPTY_STRING;
		String strBody = DomainConstants.EMPTY_STRING;
		if(booleanError)
		{
			strSubject = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS."+strAction+".Import.FailedSubject");  
			strBody =  EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS."+strAction+".Import.FailedBody");
		}
		else
		{		    
			strSubject = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS."+strAction+".Import.SuccessSubject");
			strBody = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS."+strAction+".Import.SuccessBody");
		}
		sendJobCompletionMail(context, jobObj, strSubject, strBody);
	}
	/** 
	 * Method to send mail on Job completion
	 * @param context the eMatrix <code>Context</code> object
	 * @param jobObj Job on which status to be set
	 * @param strSubject Subject of mail 
	 * @param strBody body of mail 
	 * @throws FrameworkException if the operation fails
	 * @since 417
	 */
	public void sendJobCompletionMail(Context context, Job jobObj,
			String strSubject, String strBody) throws FrameworkException {
		StringList strListToMail = new StringList(1);
		strListToMail.add(jobObj.getInfo(context, DomainConstants.SELECT_OWNER));
		StringList strListJobId = new StringList(jobObj.getInfo(context, DomainConstants.SELECT_ID));
		MailUtil.sendMessage(context,
				strListToMail,
				null,
				null,
				strSubject,
				strBody,
				strListJobId);
	}
	/** 
     * Method to set attribute values on Job
     * @param context the eMatrix <code>Context</code> object
     * @param jobObj Job on which status to be set
     * @param strNotifyOwner attribute value for notfy owner
     * @throws MatrixException if the operation fails
     * @throws FrameworkException if the operation fails
     * @since 417
     */
    public void setJobAttributes(Context context, Job jobObj, String strNotifyOwner)
            throws MatrixException, FrameworkException {

        if (jobObj.exists(context))
        {
             
            jobObj.setAttributeValue(context,ATTRIBUTE_NOTIFY_OWNER, strNotifyOwner);
            jobObj.setAttributeValue(context,ATTRIBUTE_ACTION_COMPLETE, "None");
        }
    }

	/** 
	 * Method to create Job for the Import Items from file
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps for the table
	 * @throws Exception if the operation fails
	 * @since 417
	 */
	public void exportWOMBE(Context context, String args[]) throws Exception
	{

		Job jobObj = getJob();
		setJobAttributes(context, jobObj, "No");
		boolean booleanError = false;
		String strFileName = "";
		String strWOOID = args[0];
		String [] packArgs = new String[3];
		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strWOOID)){
				packArgs[0] = strWOOID;
				DomainObject doBus = new DomainObject(strWOOID);
				StringList slObjectSelect = new StringList();
				slObjectSelect.add(DomainObject.SELECT_TYPE);
				slObjectSelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
				Map mTemp = (Map)doBus.getInfo(context, slObjectSelect);
				if(mTemp != null && mTemp.isEmpty()==false){
					String strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
					if(TYPE_WMS_MEASUREMENT_BOOK_ENTRY.equals(strType)){						
						packArgs[1] = (String)mTemp.get("to["+RELATIONSHIP_WMS_WORK_ORDER_MBE+"].from.id");
						packArgs[2] = (String)mTemp.get(DomainObject.SELECT_TYPE);
					}
				}
				//strFileName = (String)JPO.invoke(context,"WMSExportMeasurementItems",packArgs,"writeFiles",packArgs,String.class);
				strFileName = (String)JPO.invoke(context,"WMSExportMeasurementItems",packArgs,"createMeasurementBookExport",packArgs,String.class);
				
				
			}
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		if(UIUtil.isNotNullAndNotEmpty(strFileName))
		{
			
			setJobFinishStatus(context, jobObj, false,DomainConstants.EMPTY_STRING);
			sendJobCompletionMail(context, jobObj, false,"ExportMeasurements");
		}
		else
		{

			
			setJobFinishStatus(context, jobObj, true,"An Error Occured while exporting MBE");				
			sendJobCompletionMail(context, jobObj, true,"An Error Occured while exporting MBE");
		}	
	    
	}
/** 
	 * Method to create Job for the Import Items from file
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps for the table
	 * @throws Exception if the operation fails
	 * @since 417
	 */
	public void exportRICS(Context context, String args[]) throws Exception
	{
		Job jobObj = getJob();
		setJobAttributes(context, jobObj, "No");		
		String strFileName = "";
		String strSOCID = args[0];
		String sAction = args[1];
		HashMap params      = new HashMap();
		params.put("objectId", strSOCID);
		params.put("action",sAction);
	    String initargs[]    = {};
		try
		{
			if(UIUtil.isNotNullAndNotEmpty(strSOCID)){		
		     strFileName = JPO.invoke(context, "WMSDownloadRICForm",initargs,"generateRICForm",JPO.packArgs(params),String.class);			
	     	}						
			
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		if("DownloadRICPDF".equals(sAction)){
			if(UIUtil.isNotNullAndNotEmpty(strFileName))
			{
				
				setJobFinishStatus(context, jobObj, false,DomainConstants.EMPTY_STRING);
				sendJobCompletionMail(context, jobObj, false,"ExportRICS");
			}
			else
			{	
				setJobFinishStatus(context, jobObj, true,"An Error Occured while exporting RIC");				
				sendJobCompletionMail(context, jobObj, true,"An Error Occured while exporting RIC");
			}	
		}
	    else if("DownloadAEPDF".equals(sAction)){
			if(UIUtil.isNotNullAndNotEmpty(strFileName))
			{
				
				setJobFinishStatus(context, jobObj, false,DomainConstants.EMPTY_STRING);
				sendJobCompletionMail(context, jobObj, false,"ExportAES");
			}
			else
			{	
				setJobFinishStatus(context, jobObj, true,"An Error Occured while exporting AE");				
				sendJobCompletionMail(context, jobObj, true,"An Error Occured while exporting AE");
			}	
		}
		 else if("DownloadApprovedAEPDF".equals(sAction)){
			 if(UIUtil.isNotNullAndNotEmpty(strFileName))
			{
				
				setJobFinishStatus(context, jobObj, false,DomainConstants.EMPTY_STRING);
				sendJobCompletionMail(context, jobObj, false,"ExportApprovedAES");
			}
			else
			{	
				setJobFinishStatus(context, jobObj, true,"An Error Occured while exporting Approved AE");				
				sendJobCompletionMail(context, jobObj, true,"An Error Occured while exporting Approved AE");
			}	
		 }
	}			
		
	/** 
	 * Method to create Job for the Import Items from file
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps for the table
	 * @throws Exception if the operation fails
	 * @since 417
	 */
	public void generateMER(Context context, String args[]) throws Exception
	{
		Job jobObj = getJob();
		setJobAttributes(context, jobObj, "No");		
		String strStatus = "";
		HashMap params      = new HashMap();
	    String initargs[]    = {};
		try
		{
		     strStatus = (String)JPO.invoke(context, "WMSMonthlyExpenditureReport",initargs,"generateMER",JPO.packArgs(params),String.class);	
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		if(UIUtil.isNotNullAndNotEmpty(strStatus) && "failed".equals(strStatus) == false)
		{
			DomainObject doMER = new DomainObject(strStatus);
			setJobFinishStatus(context, jobObj, false,DomainConstants.EMPTY_STRING);
			String strSuccessSub = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.GenerateMER.Import.SuccessSubject");
			String strSuccessBody = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.GenerateMER.Import.SuccessBody");
			
			strSuccessBody = strSuccessBody +"\n"+EnoviaResourceBundle.getProperty(context, "WMS.Environment.URL")+"/components/emxCommonDocumentPreCheckout.jsp?objectId="+strStatus+"&action=download";
			
			sendMailForMER(context, doMER, strSuccessSub,strSuccessBody);
			
		}
		else
		{		
			setJobFinishStatus(context, jobObj, true,"An Error Occurred while generating MER");				
			sendMailForMER(context, jobObj, "An Error Occurred while generating MER","An Error Occurred while generating MER");
		}	
	    
	}		

	public void sendMailForMER(Context context, DomainObject doMER,
			String strSubject, String strBody) throws Exception {
		StringList strListToMail = new StringList(1);
		try{
		strListToMail.add(doMER.getInfo(context, DomainConstants.SELECT_OWNER));
		StringList strListJobId = new StringList(doMER.getInfo(context, DomainConstants.SELECT_ID));
		MailUtil.sendMessage(context,
				strListToMail,
				null,
				null,
				strSubject,
				strBody,
				strListJobId);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
	
}