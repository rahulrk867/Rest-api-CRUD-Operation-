/** Name of the JPO    : WMSMeasurementBookItem
 ** Developed by    : Matrixone 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to create a Measurement book items like segment , work order , items , non project items and its functionalities 
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/
// WO Assignees - Start
import java.io.StringReader;
import java.util.ArrayList;
// WO Assignees - End
import java.util.Vector;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
// WO Assignees - Start
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.joda.time.Days;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
// WO Assignees - End

import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.RelationshipType;
import matrix.util.StringList;
import matrix.util.Pattern;

import com.matrixone.apps.domain.DomainObject;

import com.matrixone.apps.common.Company;
import com.matrixone.apps.common.MemberRelationship;
import com.matrixone.apps.common.Organization;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MailUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.common.Route;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.jdom.Element;
import java.math.BigDecimal;
import java.util.Calendar;
import java.text.SimpleDateFormat;

// MBE - Start
import com.matrixone.apps.common.Person;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
// MBE - End
/**
 * The purpose of this JPO is to create a Measurement book items like segment , work order , items , non project items and its functionalities 
 * @author  DS
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSMeasurementBookItem_mxJPO extends WMSConstants_mxJPO   
{
	
	public static final String ATTRIBUTE_WMS_MBE_ITEM_TYPE_DEFAULT_VALUE = "Normal";
	 
    /**
     * Create a new ${CLASS:MarketingFeature} object from a given id.
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments.
     * @throws Exception if the operation fails
     * @author WMS
     * @since R418
     */

    public WMSMeasurementBookItem_mxJPO (Context context, String[] args)
        throws Exception
    {
        super(context, args);
    }

	
    /**
     * get list of all BOQ items
     * Used for BOQ table
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args 
     * @returns MapList - all BOQ items
     * @throws Exception if the operation fails
     * @author WMS
     * @since 417
     */
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getBOQItems(Context context,String[] args) throws Exception
    {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String sWMSMBEItemType = (String) programMap.get("MBEItemType");
		if (sWMSMBEItemType == null || "".equals(sWMSMBEItemType)) {
			sWMSMBEItemType = "Normal";
		}
        MapList mapListObjects = new MapList();
        StringList strListBusSelects     = new StringList();
        strListBusSelects.add(DomainConstants.SELECT_ID);
        strListBusSelects.add(DomainConstants.SELECT_CURRENT);
		strListBusSelects.add("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");
        strListBusSelects.add("attribute["+"WMSItemRateEscalation"+"].value");
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");

		StringList strListRelSelects = new StringList(1);
        strListRelSelects.add(DomainRelationship.SELECT_ID);
        Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
        patternType.addPattern(TYPE_WMS_SEGMENT);
        patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK);
        Pattern patternRel = new Pattern(RELATIONSHIP_BILL_OF_QUANTITY);     
        String strObjId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
        if(UIUtil.isNotNullAndNotEmpty(strObjId)){
            DomainObject domObj = DomainObject.newInstance(context, strObjId);           
            mapListObjects = domObj.getRelatedObjects(context,
            	                     	                    RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
															patternType.getPattern(),                                    // object pattern
															false,                                                        // to direction
															true,                                                       // from direction
															(short)2,                                                      // recursion level
															strListBusSelects,                                                 // object selects
															null,                                                         // relationship selects
															DomainConstants.EMPTY_STRING,                                // object where clause
															DomainConstants.EMPTY_STRING,                                // relationship where clause
															(short)0,                                                      // No expand limit
															DomainConstants.EMPTY_STRING,                                // postRelPattern
															TYPE_WMS_MEASUREMENT_TASK+","+TYPE_WMS_SEGMENT, // postTypePattern
															null); 
        }
        return mapListObjects;
    }

	/**
	 * Check whether column is having Edit Access or not depending on sate of object, Checking For SOR State For NIT
	 * @param context The Matrix Context object
	 * @param  
	 * @param args holds the following input arguments:
	 *     1) ObjectList : List of objects in table
	 *     2) ProgramMap : Contains all info about table columns        
	 * @throws Exception if the operation fails
	 */   
	public StringList checkBOQNITEdit(Context context,String args[]) throws Exception
	{
		StringList strListAccess = new StringList();;
		try
		{
			Map programMap = (HashMap) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Iterator<Map<String,String>> objectListIterator = objectList.iterator();
			
			HashMap requestMap = (HashMap)programMap.get("requestMap");
            String strWorkOrderOID = (String)requestMap.get("objectId");
			DomainObject domWOObj = DomainObject.newInstance(context, strWorkOrderOID);
			String strContextUser = context.getUser();
            StringList strListInfo = new StringList(4);
			strListInfo.add(DomainConstants.SELECT_OWNER);
		    strListInfo.add(DomainConstants.SELECT_CURRENT);
			Map<String,String> mapInfo = domWOObj.getInfo(context, strListInfo);
		    String strWOOwner 	= mapInfo.get(DomainConstants.SELECT_OWNER);
		    String strWOCurrent = mapInfo.get(DomainConstants.SELECT_CURRENT);
			String strCommandName = (String)requestMap.get("portalCmdName");
			Map<String,String> mapData ;
			while (objectListIterator.hasNext()) 
			{
				mapData = objectListIterator.next();
				if(strWOOwner.equals(strContextUser))
				{
					if("Create".equals(strWOCurrent)||(("WMSPaymentMBE".equalsIgnoreCase(strCommandName) || "WMSRebateMBE".equalsIgnoreCase(strCommandName)) && "Active".equals(strWOCurrent)))
					{
						strListAccess.add(String.valueOf(true));
					}
					else
					{
						strListAccess.add(String.valueOf(false));
					}
			    }
				else{
					strListAccess.add(String.valueOf(false));
			    }
			}

		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
		return strListAccess;

	}
    /**
     * Method is used to show Rate Escalation on BOQ table
     * @param context The Matrix Context object
     * @param args holds the arguments:     
     * @throws Exception if the operation fails
     */ 
	@com.matrixone.apps.framework.ui.ColJPOCallable
    public Vector getRateEscalation(Context context, String[] args) throws Exception
    {
        try{
            Map programMap                  = (Map)JPO.unpackArgs(args);
            MapList objectList              = (MapList)programMap.get("objectList");
            Iterator iterator               = objectList.iterator();
            Vector returnList               = new Vector();
            Map<String,String> mapData      = null;
            String strValue                 = DomainConstants.EMPTY_STRING;
            String strItemRateEscalation    = DomainConstants.EMPTY_STRING;
            String strQuantity              = DomainConstants.EMPTY_STRING;
            String strObjectId              = DomainConstants.EMPTY_STRING;
			String strBOQType             = DomainConstants.EMPTY_STRING;
            DomainObject domObj = DomainObject.newInstance(context);

            while(iterator.hasNext())
            {
                mapData     = (Map<String,String>) iterator.next();
                
                strQuantity = (String) mapData.get("attribute["+ATTRIBUTE_WMS_ITEM_RATE_ESCALATION+"]");
                if(UIUtil.isNullOrEmpty(strQuantity))
                {
					if(TYPE_WMS_SEGMENT.equals(strBOQType))
					{
						returnList.add(DomainConstants.EMPTY_STRING);
					}
					else
					{
						strObjectId = (String)mapData.get("id");
						domObj.setId(strObjectId);
						strValue    = "true".equalsIgnoreCase(strValue)?"Yes" : "No";
						returnList.add(strValue);
					}
                }
                else if(DomainConstants.EMPTY_STRING.equals(strQuantity))
                {
                    returnList.add(DomainConstants.EMPTY_STRING);
                }
                else
                {
                    if("true".equalsIgnoreCase(strQuantity))
                    {
                        returnList.add("Yes");
                    }
                    else
                    {
                        returnList.add("No");
                    }
                }
            }
            return returnList;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

	/**
     * Method is used to update Rate Escalation on BOQ table
     * @param context The Matrix Context object
     * @param args holds the arguments:     
     * @throws Exception if the operation fails
	 */ 
	@com.matrixone.apps.framework.ui.CellUpdateJPOCallable
	public void updateRateEscalation(Context context, String[] args) throws Exception
	{
		HashMap inputMap = (HashMap)JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) inputMap.get("paramMap");
		String objectId = (String) paramMap.get("objectId");
		String newEscaltionValue = (String) paramMap.get("New Value");
		if(UIUtil.isNotNullAndNotEmpty(objectId) && UIUtil.isNotNullAndNotEmpty(newEscaltionValue))
		{
			DomainObject domObj = DomainObject.newInstance(context,objectId);
			domObj.setAttributeValue(context, ATTRIBUTE_WMS_ITEM_RATE_ESCALATION, newEscaltionValue);
		}
	}
	/**
	 * Check whether column is having Edit Access or not depending on sate of object, Checking For SOR State
	 * @param context The Matrix Context object
	 * @param  
	 * @param args holds the following input arguments:
	 *     1) ObjectList : List of objects in table
	 *     2) ProgramMap : Contains all info about table columns        
	 * @throws Exception if the operation fails
	 */    
	public StringList checkForSegmentType(Context context,String args[]) throws Exception
	{
		StringList strListAccess = new StringList();;
		try
		{
			Map programMap = (HashMap) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Iterator<Map<String,String>> objectListIterator = objectList.iterator();
            HashMap requestMap           = (HashMap)programMap.get("requestMap");
            String strWorkOrderOID     = (String)requestMap.get("objectId");
            
			DomainObject domWOObj = DomainObject.newInstance(context, strWorkOrderOID);
            String strContextUser = context.getUser();
			
			
		    StringList strListInfo = new StringList(4);
		    strListInfo.add(DomainConstants.SELECT_OWNER);
		    strListInfo.add(DomainConstants.SELECT_CURRENT);
			
			Map<String,String> mapInfo = domWOObj.getInfo(context, strListInfo);
		    String strWOOwner 	= mapInfo.get(DomainConstants.SELECT_OWNER);
		    String strWOCurrent = mapInfo.get(DomainConstants.SELECT_CURRENT);
			boolean booleanWOChecks = false;
			if( strWOOwner.equals(strContextUser) && "Create".equals(strWOCurrent) )
			{
				booleanWOChecks = true;
			}
			while (objectListIterator.hasNext()) {
               
				Map<String,String> mapData = objectListIterator.next();

				String strBOQType = mapData.get(DomainConstants.SELECT_TYPE);
				
				if(booleanWOChecks)
				{
      			   if(TYPE_WMS_SEGMENT.equals(strBOQType))
				   {
					strListAccess.add(String.valueOf(false));
				   }
				   else
				   {
					strListAccess.add(String.valueOf(true));
				   }   
				}
				else
				{
					strListAccess.add(String.valueOf(false));
				}
			}

		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
		return strListAccess;

	}
	/** RELATIONSHIP_BILL_OF_QUANTITY
	  * Method will add measurement book to the work order
	  * 
	  * @param context the eMatrix <code>Context</code> object
	  * @param args with program arguments
	  *             args[0]- Workorder OID
	  * @throws Exception if the operation fails
	  * @author WMS
	  * @since 418
	  */
	 public void addMeasurementBook(Context context, String[] args) throws Exception {
		 try {
			 String strWOOID = args[0];
			 if(UIUtil.isNotNullAndNotEmpty(strWOOID))
			 {
				 String strMBOID = FrameworkUtil.autoName(context,
						 "type_WMSMeasurementBook",
						 "policy_WMSMeasurementItem");
				 if(UIUtil.isNotNullAndNotEmpty(strMBOID))
				 {
					StringList strListInfoSelects = new StringList(3);
					strListInfoSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
					strListInfoSelects.add(DomainConstants.SELECT_DESCRIPTION);
					strListInfoSelects.add(DomainConstants.SELECT_NAME);
					DomainObject domObjWO = DomainObject.newInstance(context, strWOOID);
					DomainObject domObjMB = DomainObject.newInstance(context, strMBOID);
					Map<String,String> mapWOInfo =  domObjWO.getInfo(context,  strListInfoSelects);
					String strName = mapWOInfo.get(DomainConstants.SELECT_NAME);
					domObjWO.setName(context,strName);
					domObjMB.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, mapWOInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value"));
					domObjMB.setDescription(context, mapWOInfo.get(DomainConstants.SELECT_DESCRIPTION));
					DomainRelationship.connect(context, strWOOID, RELATIONSHIP_BILL_OF_QUANTITY, strMBOID, true);
				 }
			 }
		 }
		 catch(Exception exception)
		 {
			 exception.printStackTrace();
			 throw exception;
		 }
	 }

	// WO Assignees - Start
    /**
	 * Method to get the connected Assignees to the work order
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command or form or table
	 * @return mapListConnectedMBEs MapList containing the Person data
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getWorkOrderAssignees (Context context, String[] args) throws Exception 
	{
		try
		{
			MapList mapListAssignees = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjWO = DomainObject.newInstance(context, strObjectId);
                String strWorkOrderOwner = domObjWO.getInfo(context, DomainConstants.SELECT_OWNER);
                mapListAssignees = getWorkOrderAssignees(context, domObjWO);
                Iterator iterator   = mapListAssignees.iterator();
                while (iterator.hasNext()) {
                    Map mapAssigneInfo = (Map) iterator.next();
                    String strAssignee = (String) mapAssigneInfo.get(DomainConstants.SELECT_NAME);
                    String strRelAttr = (String) mapAssigneInfo.get("attribute["+ATTRIBUTE_HOST_ROLE+"]");
                    if (strWorkOrderOwner.equalsIgnoreCase(strAssignee)) {
                        mapAssigneInfo.put("disableSelection", "true");
                       // mapAssigneInfo.put("RowEditable", "readonly");
                    }
					//if(UIUtil.isNotNullAndNotEmpty(strRelAttr)){
					//	mapAssigneInfo.put("RowEditable", "readonly");
					//}
					//if(strRelAttr.equalsIgnoreCase(DomainConstants.ROLE_SUPPLIER_REPRESENTATIVE)){
                     //   mapAssigneInfo.put("disableSelection", "true");
                      //  mapAssigneInfo.put("RowEditable", "readonly");
                    //}
                }
			}
			return mapListAssignees;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	/**
	 * Method to get the connected Assignees to the work order
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjWO domain object instance of work order
	 * @return mapListConnectedMBEs MapList containing the Person data
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	public static MapList getWorkOrderAssignees(Context context, DomainObject domObjWO) throws FrameworkException
	{
		try
		{
			StringList strListBusSelects     = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_NAME);
			strListBusSelects.add("attribute[Project Role]");
			strListBusSelects.add("attribute["+ATTRIBUTE_HOST_ROLE+"]");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			strListRelSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"]");
			strListRelSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"]");
			
             MapList mapListAssignees = domObjWO.getRelatedObjects(context, // matrix context
            		                                                 RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE, // relationship pattern
																	DomainConstants.TYPE_PERSON, // type pattern
																	strListBusSelects, // object selects
																	strListRelSelects, // relationship selects
																	true, // to direction
																	false, // from direction
																	(short) 1, // recursion level
																	DomainConstants.EMPTY_STRING, // object where clause
																	DomainConstants.EMPTY_STRING, // relationship where clause
																	0);
			return mapListAssignees;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}

	/**
	 * Method to get the connected Assignees to the work order
	 *and show display role
	 * @param context the eMatrix <code>Context</code> object
	 * @param domObjWO domain object instance of work order
	 * @return mapListConnectedMBEs MapList containing the Person data
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public Vector getDisplayProjectRoleSearchPage (Context context, String[] args) throws Exception{
		Map projectRoleMap = new HashMap();
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		MapList objectList = (MapList) programMap.get("objectList");
		String strPersonId = DomainConstants.EMPTY_STRING;
		Map<String,String> mapDataObj;
		Iterator<Map<String,String>> iteratorObjList = objectList.iterator();
		String[] PersonIdArray = new String[objectList.size()];
		int i=0;
		while(iteratorObjList.hasNext())
		{
			
			mapDataObj = iteratorObjList.next();
			strPersonId = mapDataObj.get("id");
			PersonIdArray[i] = strPersonId;
			i++;
			
		}
		StringList slBusSelect = new StringList();
		slBusSelect.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"]");
		slBusSelect.add(DomainConstants.SELECT_NAME);
		MapList mlPersonRoleData = DomainObject.getInfo(context, PersonIdArray, slBusSelect);
		///////////Read Project role XML here/////
		String strDepartmentName = DomainConstants.EMPTY_STRING;
		MapList mapListDepartment = WMSUtil_mxJPO.getContextUserDepartment(context);
		Iterator<Map<String,String>> iterator = mapListDepartment.iterator();
		Map<String,String> mapData;
		while(iterator.hasNext())
		{
			mapData = iterator.next();
			strDepartmentName = mapData.get(DomainConstants.SELECT_NAME);
		}
		String MQLResult = MqlUtil.mqlCommand(context, "print page $1 select content dump", "ProjectDepartmentRole");
		DocumentBuilder db      = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		InputSource is          = new InputSource();
		is.setCharacterStream(new StringReader(MQLResult));
		org.w3c.dom.Document doc    = db.parse(is);
		NodeList department  = doc.getElementsByTagName("department");
		for (int ii = 0; ii < department.getLength(); ii++) {
			org.w3c.dom.Element element = (org.w3c.dom.Element) department.item(i);
			String strDeptName = element.getAttribute("id");
			if(strDeptName.equalsIgnoreCase(strDepartmentName)) {
				NodeList role = element.getElementsByTagName("Role");
				for(int j= 0;j<role.getLength();j++) {
					org.w3c.dom.Element roleElement = (org.w3c.dom.Element) role.item(j);
					String strSchemaRole = roleElement.getAttribute("schemaRole");
					Iterator projectInfoListIterator = mlPersonRoleData.iterator();
					while(projectInfoListIterator.hasNext()){
						Map<String,String> projectInfoMap = (Map)projectInfoListIterator.next();
						String strActualRole = projectInfoMap.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"]");
						if(strSchemaRole.equals(strActualRole)) {
							projectRoleMap.put(projectInfoMap.get(DomainConstants.SELECT_NAME),roleElement.getAttribute("displayRole"));
						}
					}
				}
			}
		}
		///////////////////////////////////
		Vector columnValues = new Vector(mlPersonRoleData.size());
		Iterator mlPersonRoleDataIterator = mlPersonRoleData.iterator();
		while(mlPersonRoleDataIterator.hasNext()){
			Map<String,String> objectMap = (Map)mlPersonRoleDataIterator.next();
        	String name = (String)objectMap.get(DomainConstants.SELECT_NAME);
        	columnValues.addElement(projectRoleMap.get(name));
		}
		return columnValues;
		
		
	}
    /** 
     * Method will copy Project Member to Work Order
     * 
     * @param context the eMatrix <code>Context</code> object    
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public void connectWOMembers(Context context, String args[]) throws Exception {
    	boolean isContextPushed = false;
		try {			
    		String strProjectId = args[0];
    		String  strWOId = args[1];
    		ArrayList<String>arrayListIds = new ArrayList<String>();
    		StringList strListBusSelects = new StringList(DomainConstants.SELECT_ID);
    		strListBusSelects.add("attribute["+ATTRIBUTE_HOST_ROLE+"].value");
    		if(UIUtil.isNotNullAndNotEmpty(strWOId)&& UIUtil.isNotNullAndNotEmpty(strProjectId)) {
				DomainObject domWO = DomainObject.newInstance(context,strWOId);
				DomainObject domProject = DomainObject.newInstance(context, strProjectId);
				StringList slRelSels = new StringList();
				slRelSels.add("attribute["+MemberRelationship.ATTRIBUTE_PROJECT_ROLE+"]");
				Map<String,String> mPeron=new HashMap<String,String>();
				MapList mapListObjects = domProject.getRelatedObjects(context, // matrix context
																		DomainConstants.RELATIONSHIP_MEMBER, // relationship pattern
																		DomainConstants.TYPE_PERSON, // type pattern
																		strListBusSelects, // object selects
																		slRelSels, // relationship selects
																		false, // to direction
																		true, // from direction
																		(short) 0, // recursion level
																		DomainConstants.EMPTY_STRING, // object where clause
																		DomainConstants.EMPTY_STRING, // relationship where clause
																		0);
				//WMS Code added to add Contractor Supplier Representative as WorkOrder Memeber
				 String strWOContractor = domWO.getInfo(context, "to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.id");
				 MapList personList = new MapList();
				 if(UIUtil.isNotNullAndNotEmpty(strWOContractor)){
					 Organization organizationObj = (Organization) DomainObject.newInstance(context,strWOContractor);
					 StringList orgObjSelects = new StringList(1);
					 orgObjSelects.add(DomainConstants.SELECT_NAME);
					 orgObjSelects.add(DomainConstants.SELECT_ID);
					 personList = (MapList)organizationObj.getMemberPersons(context,orgObjSelects,null, DomainConstants.RELATIONSHIP_MEMBER,DomainConstants.ROLE_SUPPLIER_REPRESENTATIVE);
				 }
	         	Map mapObj = new HashMap();
				String strObjId = "";
				String[] personId;
				int iPersinSize = personList.size();
				if(iPersinSize==1){
					personId =new String[mapListObjects.size()+1];
				}else{
					personId =new String[mapListObjects.size()];
				}
				
				String strProjectRole=DomainConstants.EMPTY_STRING;
				 int cnt=0;
				for(int i=0;i<mapListObjects.size();i++)
				{
					mapObj = (Map)mapListObjects.get(i);
				 
						strObjId = (String)mapObj.get(DomainConstants.SELECT_ID);
						strProjectRole= (String)mapObj.get("attribute["+ATTRIBUTE_HOST_ROLE+"].value");
						mPeron.put(strObjId, strProjectRole);
						personId[cnt]=strObjId;
					 	arrayListIds.add(strObjId);
					 	cnt++;
						 
					 
				}
			 
				//get contractor person dont know number of Supplier Representative ..
				 
				 if(personList.size()==1){
					 for(int i=0;i<personList.size();i++)
					 {
						 Map objectMap =  (Map)personList.get(i);
						 strObjId=(String)objectMap.get(DomainConstants.SELECT_ID);
						 arrayListIds.add(strObjId);
						 mPeron.put(strObjId, DomainConstants.EMPTY_STRING);
						 personId[cnt]=strObjId;
						 cnt++;
					  }
				 }
		     	 
		     	Map<String,String> mRelData = DomainRelationship.connect(context, domWO, new RelationshipType(RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE), false, personId);
		     	DomainRelationship domWOAssignee=null;
                for(int i=0;i<personId.length;i++) {
                	domWOAssignee=DomainRelationship.newInstance(context, (String) mRelData.get(personId[i]));
					ContextUtil.pushContext(context);
					isContextPushed = true;
                	domWOAssignee.setAttributeValue(context, ATTRIBUTE_WMS_WORK_ORDER_ROLE, (String) mPeron.get(personId[i]));
                	
                }
		     	 
				 
				// Map<String, String> mRelIds = ${CLASS:WMSUtil}.connect(context, domWO, RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE, false, arrayListIds);
    		}
    	}
    	catch(Exception exception)
    	{
    		System.out.println("exception   "+exception.getMessage());
    		exception.printStackTrace();
    		throw exception;            
    	}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
    }
    /**
	 * Trigger Program To update the values for Project Role on Relationship
	 * @ args - Method arguments 
	 * arg1 - To side object id
	 * @param args2 - Relationship id
	 * @return 
	 */

	@com.matrixone.apps.framework.ui.ProgramCallable
	public void updateProjectRoleAttributes(Context context,String[]args) throws Exception
	{
		boolean isContextPushed = false;
		try {
			String strObjectID = args[0];
			String strWOId = args[1];
			String strRELID = args[2];
			if(UIUtil.isNotNullAndNotEmpty(strWOId) && UIUtil.isNotNullAndNotEmpty(strObjectID))
			{
				/*DomainObject domObjToObject = DomainObject.newInstance(context, strObjectID);
				String strProjectRole = (String)domObjToObject.getInfo(context, "attribute["+ATTRIBUTE_WMS_DEFAULT_ROLE+"]");
				DomainObject domWO = DomainObject.newInstance(context,strWOId);
				String strProjectId = domWO.getInfo(context, "to["+RELATIONSHIP_WMS_PROJECT_WORK_ORDER+"].from.id");
				if(UIUtil.isNotNullAndNotEmpty(strProjectId)) {
					String sWhere = "id=="+strObjectID;
					StringList strListBusSelects = null;
					StringList slRelSels = new StringList(1);
					slRelSels.add("attribute["+MemberRelationship.ATTRIBUTE_PROJECT_ROLE+"]");
					DomainObject domProject = DomainObject.newInstance(context, strProjectId);
					MapList mapListObjects = domProject.getRelatedObjects(context, // matrix context
																			DomainConstants.RELATIONSHIP_MEMBER, // relationship pattern
																			DomainConstants.TYPE_PERSON, // type pattern
																			strListBusSelects, // object selects
																			slRelSels, // relationship selects
																			false, // to direction
																			true, // from direction
																			(short) 0, // recursion level
																			sWhere, // object where clause
																			DomainConstants.EMPTY_STRING, // relationship where clause
																			0);
					if (mapListObjects.size() > 0) {
						Map objMap = (Map)mapListObjects.get(0);
						strProjectRole = (String)objMap.get("attribute["+MemberRelationship.ATTRIBUTE_PROJECT_ROLE+"]");
					}
				}*/
				String strProjectRole = DomainConstants.EMPTY_STRING;
				DomainObject doPerson = DomainObject.newInstance(context, strObjectID);
				String strPersonName = (String)doPerson.getInfo(context, DomainObject.SELECT_NAME);
				matrix.db.Person pPerson = new matrix.db.Person(strPersonName);
				if(pPerson.isAssigned(context, DomainConstants.ROLE_SUPPLIER_REPRESENTATIVE)){
					strProjectRole = "Supplier Representative";
				}			
				
				DomainRelationship drRecRel = new DomainRelationship(strRELID);
				ContextUtil.pushContext(context);
				isContextPushed = true;
				drRecRel.setAttributeValue(context, ATTRIBUTE_WMS_WORK_ORDER_ROLE, strProjectRole);
			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}
		}
	}

    /**
     * Include oid program
     * shows only Subordinate of context user and Contractors of Work Order    
     * @param context
     * @return StringList containing information of payment items to show for connection
     * @throws Exception if the operation fails
     */
	@com.matrixone.apps.framework.ui.IncludeOIDProgramCallable
    public StringList getMemberForWO(Context context, String[] args) throws Exception 
    {
    	StringList slIncludeMemeber = new StringList();
        try {            
            StringList slObjectSelects = new StringList(1);
            slObjectSelects.add(DomainConstants.SELECT_ID);
            String  strOwnerId = PersonUtil.getPersonObjectID(context, context.getUser());
            DomainObject domWOOwner = DomainObject.newInstance(context,strOwnerId);
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
            DomainObject domWO = DomainObject.newInstance(context,strObjectId);
            
			StringList slSelect = new StringList();
			slSelect.add("to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.id");
			slSelect.add("to["+RELATIONSHIP_WMS_WORKORDER_PMC_CONSULTANT+"].from.id");
			
			Map mWOInfo = domWO.getInfo(context,slSelect);
			
			StringList slOrgList = new StringList();
			String strContractorId = (String)mWOInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.id");
			String strPMCId = (String)mWOInfo.get("to["+RELATIONSHIP_WMS_WORKORDER_PMC_CONSULTANT+"].from.id");
			if(UIUtil.isNotNullAndNotEmpty(strContractorId))
				slOrgList.add(strContractorId);
			if(UIUtil.isNotNullAndNotEmpty(strPMCId))
				slOrgList.add(strPMCId);
			
			String strContextOrgid = MqlUtil.mqlCommand(context,"print bus "+strOwnerId+" select to["+DomainRelationship.RELATIONSHIP_MEMBER+"|from.type=="+DomainConstants.TYPE_COMPANY+"].from.id dump");
			slOrgList.add(strContextOrgid);
			
			//add members of PgMC and QA companies
			 String strPgMCQAWhere = "attribute["+ATTRIBUTE_WMS_TYPE_OF_COMPANY+"] ~= *PgMC* || attribute["+ATTRIBUTE_WMS_TYPE_OF_COMPANY+"] ~= *QA*";
			 MapList mlPgMCQACompanies = DomainObject.findObjects(context, DomainConstants.TYPE_ORGANIZATION, DomainConstants.QUERY_WILDCARD, DomainConstants.QUERY_WILDCARD, null, null, strPgMCQAWhere, true, new StringList(DomainConstants.SELECT_ID));
			 for (int i = 0; i < mlPgMCQACompanies.size(); i++)
			 {
				slOrgList.addElement((String)((Map)mlPgMCQACompanies.get(i)).get(DomainConstants.SELECT_ID));
			 }
			
			DomainObject doOrg = null;
			for(int i=0;i<slOrgList.size();i++){
				doOrg = new DomainObject((String)slOrgList.get(i));
				StringList slPersonList = doOrg.getInfoList(context,"from["+DomainRelationship.RELATIONSHIP_MEMBER+"].to.id");
				for(int j=0;j<slPersonList.size();j++){
					if(slIncludeMemeber.contains((String)slPersonList.get(j))==false){
						slIncludeMemeber.add((String)slPersonList.get(j));
					}					
				}
			}
			
			/*MapList mapListObjects = domWOOwner.getRelatedObjects(context, // matrix context
																	RELATIONSHIP_REPORTING_MANAGER, // relationship pattern
																	DomainConstants.TYPE_PERSON, // type pattern
																	slObjectSelects, // object selects
																	DomainConstants.EMPTY_STRINGLIST, // relationship selects
																	false, // to direction
																	true, // from direction
																	(short) 0, // recursion level
																	DomainConstants.EMPTY_STRING, // object where clause
																	DomainConstants.EMPTY_STRING, // relationship where clause
																	0);
            Map mapObj = new HashMap();
            String strObjId = DomainConstants.EMPTY_STRING;
            for(int i=0;i<mapListObjects.size();i++)
            {
                mapObj = (Map)mapListObjects.get(i);
                if(mapObj != null && !mapObj.isEmpty())
                {
                    strObjId = (String)mapObj.get(DomainConstants.SELECT_ID);
                    if(UIUtil.isNotNullAndNotEmpty(strObjId))
                    {
                    	slIncludeMemeber.add(strObjId);
                    }
                }
            }
            StringList slContractor = domWO.getInfoList(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.id");
            String strMemberId = DomainConstants.EMPTY_STRING;
            if(slContractor!=null&&!slContractor.isEmpty())
            {
            	for(int i=0;i<slContractor.size();i++)
            	{
            		MapList mlOrgMember = getWorkOrderContractorMember(context,(String)slContractor.get(i));
					for(int k=0;k<mlOrgMember.size();k++){
						Map map = (Map)mlOrgMember.get(k);
						if(map != null && !map.isEmpty())
						{
							strMemberId = (String)map.get(DomainConstants.SELECT_ID);
							slIncludeMemeber.add(strMemberId);
						}                	
					}
            	}
            }
			String strProjectID 	= (String) domWO.getInfo(context, "to[" + RELATIONSHIP_WMS_PORJECT_WORK_ORDER + "].from.id");
			if (UIUtil.isNotNullAndNotEmpty(strProjectID)) {
				DomainObject domProject 		= DomainObject.newInstance(context, strProjectID);
				MapList mapProjectMemberList 	= getProjectConnectMembers(context, domProject);
				Iterator<Map<String, String>> iterator = mapProjectMemberList.iterator();
				String strProjectMemberId 		= DomainConstants.EMPTY_STRING;
				Map<String, String> mapMemberData;
				while (iterator.hasNext()) {
					mapMemberData 		= iterator.next();
					strProjectMemberId 	= mapMemberData.get(DomainConstants.SELECT_ID);
					if (!slIncludeMemeber.contains(strProjectMemberId)) {
						slIncludeMemeber.add(strProjectMemberId);
					}
				}
			}*/
        }
        catch (Exception e) {
            throw e;
        }
		
        return slIncludeMemeber;
    }    
    
	/**
	 * Method to get the connected Assignees to the work order
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args Packed program and request maps from the command or form or table
	 * @return strListAssignees StringList containing the Person IDs
	 * @throws Exception if the operation fails
	 * @author WMS
	 * @since 418
	 */
	@com.matrixone.apps.framework.ui.ExcludeOIDProgramCallable
	public StringList getExcludeWorkOrderAssignees (Context context, String[] args) throws Exception 
	{
		try
		{
			StringList strListAssignees = new StringList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				MapList mapListAssignees = new MapList();
				DomainObject domObjWO = DomainObject.newInstance(context, strObjectId);
				mapListAssignees = getWorkOrderAssignees(context, domObjWO);
				strListAssignees = WMSUtil_mxJPO.convertToStringList(mapListAssignees, DomainObject.SELECT_ID);
			}
			return strListAssignees;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}

    /** 
     * Method will search contractor organization memebers of Work Order
     * 
     * @param context the eMatrix <code>Context</code> object
     * @param strOrganization - Contractor id
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public MapList getWorkOrderContractorMember(Context context, String strOrganization) throws Exception {
    	MapList mlWOMember = new MapList();
        try {
           StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
                StringList slRelSelects = new StringList(1);
                slRelSelects.add(DomainRelationship.SELECT_ID);
                DomainObject domOrgnization = DomainObject.newInstance(context,strOrganization);
                mlWOMember = domOrgnization.getRelatedObjects(context, // matrix context
                		DomainConstants.RELATIONSHIP_MEMBER, // relationship pattern
                       DomainConstants.TYPE_PERSON, // type pattern
                       slObjectSelects, // object selects
                       slRelSelects, // relationship selects
                        false, // to direction
                        true, // from direction
                        (short) 0, // recursion level
                        DomainConstants.EMPTY_STRING, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);
        }
        catch(Exception exception)
        {
            System.out.println("exception   "+exception.getMessage());
            exception.printStackTrace();
            throw exception;            
        }
        
        return mlWOMember;
    }

	/**
	 * Method to get the connected members to Project Space
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param domProjectObj domain object instance of work order
	 * @return mapListConnectedMBEs MapList containing the Person data
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
	public static MapList getProjectConnectMembers(Context context, DomainObject domProjectObj) throws FrameworkException {
		try
		{
			StringList strListBusSelects     = new StringList(1);
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_NAME);
			strListBusSelects.add("attribute[Project Role]");
			StringList strListRelSelects     = new StringList(1);
			strListRelSelects.add(DomainRelationship.SELECT_ID);
            MapList mapListAssignees = domProjectObj.getRelatedObjects(context, // matrix context
            		DomainConstants.RELATIONSHIP_MEMBER, // relationship pattern
					DomainConstants.TYPE_PERSON, // type pattern
					strListBusSelects, // object selects
					strListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
					(short) 1, // recursion level
					DomainConstants.EMPTY_STRING, // object where clause
					DomainConstants.EMPTY_STRING, // relationship where clause
					0);
			return mapListAssignees;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}

	// WO Assignees - End
	
	// MBE - Start
	
	/**
	 * Used in Policy access filters to check if the context user is a contractor for respective work order
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args contains a Map with the ObjectId
	 *
	 * @return boolean - true (if function that is getting called provides access),
	 *                   false(if function that is getting called does not provide access)
	 *                   if function is not there return the  default value true
	 * @throws Exception if the operation fails
	 */
	public String isContextUserContractor (Context context, String[] args)throws Exception
	{
        if (args == null || args.length < 1)
        {
            throw (new IllegalArgumentException());
        }
		boolean isContextPushed = true;
		Boolean booleanReturnValue = new Boolean(false);
		try
		{
			String strObjectOID = (String) args[0];
			String strContextUser = context.getUser();
			ContextUtil.pushContext(context, "User Agent",DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
			if(UIUtil.isNotNullAndNotEmpty(strObjectOID))
			{
				MapList mapListAssignees = getWorkOrderAssignees(context, strObjectOID);
				booleanReturnValue = checkForProjectRole(context, mapListAssignees, strContextUser, "Contractor");
			}
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
		finally
		{
			if (isContextPushed)
			{
				ContextUtil.popContext(context);
			}

		}
		return booleanReturnValue.toString();
	}
	
    /**
	 * Method to get the connected Assignees to the work order from the context Abstract MBE OID
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param strAbsMBEOID String containing the context abstrac MBE OID
	 * @return mapListAssignees MapList containing the Person data
	 * @throws FrameworkException if the operation fails
	 * @author WMS
	 * @since 418
	 */
    public static MapList getWorkOrderAssignees(Context context, String strAbsMBEOID) throws FrameworkException {
		try
		{
			StringList strListBusInfo = new StringList(2);
			strListBusInfo.add(DomainConstants.SELECT_ID);
            strListBusInfo.add(Person.SELECT_NAME);
			StringList strListRelInfo = new StringList(2);
			strListRelInfo.add(DomainRelationship.SELECT_ID);
			strListRelInfo.add("attribute["+ProgramCentralConstants.ATTRIBUTE_PROJECT_ROLE+"].value");
			DomainObject domObjAbsMBE = DomainObject.newInstance(context, strAbsMBEOID);
			Pattern patternType = new Pattern(TYPE_WMS_WORK_ORDER);
			patternType.addPattern(DomainConstants.TYPE_PERSON);
			Pattern patternRel = new Pattern(RELATIONSHIP_WMS_WORK_ORDER_MBE);
			patternRel.addPattern(RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE);
			MapList mapListAssignees = domObjAbsMBE.getRelatedObjects(context,
																		patternRel.getPattern(),			 			// relationship pattern
																		patternType.getPattern(),									// object pattern
																		true,														// to direction
																		true,                               						// from direction
																		(short)2,								  					// recursion level
																		strListBusInfo,                         						// object selects
																		strListRelInfo,                         								// relationship selects
																		null,								// object where clause
																		DomainConstants.EMPTY_STRING,								// relationship where clause
																		(short)0,								  					// No expand limit
																		RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE,                        		// postRelPattern
																		(DomainConstants.TYPE_PERSON),												// postTypePattern
																		null);                              						// postPatterns
			return mapListAssignees;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
	/**
	 * Checks if the list of context user is a assignee of Work Order and assigned with contractor role
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param mapListAssignees MapList containing the Work Order assignees
	 * @param strContextUser String containing the context user
	 * @return boolean - true (context user is a assignee of Work Order and assigned with contractor role),
	 *                   false(context user is neither  a assignee of Work Order nor assigned with contractor role)
	 *                   if function is not there return the  default value false
	 */
	private Boolean checkForProjectRole(Context context,  MapList mapListAssignees,String strContextUser,String strProjectRole) {
		Boolean booleanReturnValue = new Boolean(false);
		StringList strListRoles = FrameworkUtil.split(strProjectRole, ",");
		Map<String,String> mapData;
		Iterator<Map<String,String>> iterator = mapListAssignees.iterator();
        String strUser = DomainConstants.EMPTY_STRING;
        String strRole = DomainConstants.EMPTY_STRING;
		while(iterator.hasNext())
		{
			mapData = iterator.next();
            strUser = mapData.get(Person.SELECT_NAME);
            strRole = mapData.get("attribute["+ProgramCentralConstants.ATTRIBUTE_PROJECT_ROLE+"].value");
            if(strUser.equals(strContextUser)&&strListRoles.contains(strRole))
			{
				booleanReturnValue = new Boolean(true);
				break;
			}
		}
		return booleanReturnValue;
	}
	// MBE - End
	
	
	
	/**
	 * Check whether column is having Edit Access or not depending on sate of object, Checking For SOR State
	 * @param context The Matrix Context object
	 * @param  
	 * @param args holds the following input arguments:
	 *     1) ObjectList : List of objects in table
	 *     2) ProgramMap : Contains all info about table columns        
	 * @throws Exception if the operation fails
	 */    
	public StringList checkBOQRateEdit(Context context,String args[]) throws Exception
	{
		StringList strListAccess = new StringList();;
		try
		{
			Map programMap = (HashMap) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Iterator<Map<String,String>> objectListIterator = objectList.iterator();
			
			HashMap requestMap           = (HashMap)programMap.get("requestMap");
            String strWorkOrderOID     = (String)requestMap.get("objectId");
			
			DomainObject domWOObj = DomainObject.newInstance(context, strWorkOrderOID);
            String strContextUser = context.getUser();
			
		    StringList strListInfo = new StringList(4);
		    strListInfo.add(DomainConstants.SELECT_OWNER);
		    strListInfo.add(DomainConstants.SELECT_CURRENT);

		    Map<String,String> mapInfo = domWOObj.getInfo(context, strListInfo);
		    String strWOOwner 	= mapInfo.get(DomainConstants.SELECT_OWNER);
		    String strWOCurrent = mapInfo.get(DomainConstants.SELECT_CURRENT);
			boolean booleanWOChecks = false;
			if( strWOOwner.equals(strContextUser) && "Create".equals(strWOCurrent) )
			{
				booleanWOChecks = true;
			}
			Map<String,String> mapData ;
			while (objectListIterator.hasNext()) 
			{
               	mapData = objectListIterator.next();				    				
				String strSORConnected =   mapData.get("relationship["+RELATIONSHIP_WMS_TASK_SOR+"]");   				
				if(booleanWOChecks)
				{
					 
						if("False".equalsIgnoreCase(strSORConnected))
						{
							strListAccess.add(String.valueOf(true));
						}
						else
						{
							strListAccess.add(String.valueOf(false));
						}
					}
				}
				 
			

		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
		return strListAccess;

	}
	
	
	public Vector getItemType(Context context, String[] args) throws Exception 
	{
        try {
            Vector vColumnValues = new Vector();
            Map programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			String[] strObjOIDs = getObjectOIDS(objectList);
			StringList slSels = new StringList("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"]");
			MapList mlInfo = DomainObject.getInfo(context, strObjOIDs, slSels);
			Iterator<Map<String,String>> iterator  = mlInfo.iterator();
			Map<String,String> objMap;
			while(iterator.hasNext())
			{
				objMap = (Map<String,String>) iterator.next();
				String sItemType = objMap.get("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"]");
				if("Payment".equals(sItemType) || "Rebate".equals(sItemType)){
					vColumnValues.add(sItemType);
				}
				else {
					vColumnValues.add("");
				}
			}
            return vColumnValues;
        }
        catch (Exception e) {
            throw new Exception("Error while getting up to date amount:"+e.getMessage());
        }
	}
	
	 /**
     * Method to get the object OIDs as array from the MapList
     *
     * @param objectList MapList containing the Object List info
     * @return strObjOIDs String[] containing the Object OIDs
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    private String[] getObjectOIDS(MapList objectList) {
        Iterator<Map<String,String>> iterator  = objectList.iterator();
        ArrayList<String> arrayListOIDs = new ArrayList<String>(objectList.size());
        Map<String,String> mapData;
        while(iterator.hasNext())
        {
            mapData =  iterator.next();
            String strObjOID = mapData.get(DomainConstants.SELECT_ID);
            arrayListOIDs.add(strObjOID);
        }
        int intSize = arrayListOIDs.size();
        String [] strObjOIDs = arrayListOIDs.toArray(new String[intSize]);
        return strObjOIDs;
    }
    
    
    public StringList showColorForPaymentAndRebateItems(Context context, String[] args)  throws Exception 
	{
		try 
		{
			StringList slOutput = new StringList();
			// Get object list information from packed arguments
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for (Iterator itrTableRows = objectList.iterator(); itrTableRows.hasNext();)
			{
				Map mapObjectInfo = (Map) itrTableRows.next();
				String sObjectid = (String)mapObjectInfo.get("id");
				DomainObject doItem = DomainObject.newInstance(context, sObjectid);
				String sItemType = doItem.getAttributeValue(context, ATTRIBUTE_WMS_MBE_ITEM_TYPE);
				if("Payment".equals(sItemType) || "Rebate".equals(sItemType)) {
					slOutput.addElement("RowBackGroundColor");
				}
				else {
					slOutput.addElement("");
				}
			}
			return slOutput;

		} catch (Exception exp) {
			exp.printStackTrace();
			throw exp;
		}
	}
	
    public boolean showItemType(Context context, String[] args) throws Exception 
    {
        try
        {
			boolean showItemTypeColumn = false;
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String sObjectId = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(sObjectId))
			{
			DomainObject doMeasurementBookItem = DomainObject.newInstance(context,sObjectId);
			StringList slObjectSelects = new StringList();
			slObjectSelects.add("to[WMSWOMBE].from.attribute[WMSFormType]");
			slObjectSelects.add("to[WMSWOMBE].from.id");
			Map mMBEObjData = doMeasurementBookItem.getInfo(context, slObjectSelects);
			String sWorkOrderFormType = (String) mMBEObjData.get("to[WMSWOMBE].from.attribute[WMSFormType]");
			if ("FormF".equals(sWorkOrderFormType)) {
				WMSMeasurementBookEntry_mxJPO jpo = new WMSMeasurementBookEntry_mxJPO(context, null);
				StringList slActivitiesToAdd = jpo.getRelatedActivities(context, args);
				for (int i=0,j=slActivitiesToAdd.size(); i<j; i++) {
					String sItemOid = (String)slActivitiesToAdd.get(i);
					DomainObject doItem = DomainObject.newInstance(context, sItemOid);
					//TODO call the DB in getRelatedActivities
					String sItemType = doItem.getAttributeValue(context, "WMSMBEItemType");
					if("Payment".equals(sItemType) || "Rebate".equals(sItemType)){
						showItemTypeColumn = true;
						break;
					}
				}
			}
			}
            return showItemTypeColumn;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }  

    }
  
    /**
     * Check whether column is having Edit Access or not depending on type of object, Checking For type WMSMeasurements
     * @param context The Matrix Context object
     * @param  
     * @param args holds the following input arguments:
     *     1) ObjectList : List of objects in table
     *     2) ProgramMap : Contains all info about table columns        
     * @throws Exception if the operation fails
     */    
    public StringList checkForMeasurementType(Context context,String args[]) throws Exception
    {
        StringList strListAccess = new StringList();;
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();

            while (objectListIterator.hasNext()) {

                Map<String,String> mapData = objectListIterator.next();
                String strType = mapData.get(DomainConstants.SELECT_TYPE);
                if(TYPE_WMS_MEASUREMENTS.equals(strType))
                    strListAccess.add(String.valueOf(true));
                else
                    strListAccess.add(String.valueOf(false));
            }

        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListAccess;

    }
	
	/**
     * method is used to create BOQ item
     * Used for BOQ page
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args 
     * @returns HashMap
     * @throws Exception if the operation fails
     * @author WMS
     * @since 417
     */
    @com.matrixone.apps.framework.ui.CreateProcessCallable
    public Map createBOQ(Context context, String[] args) throws Exception {
            Map retMap = new HashMap();
			boolean isContextPushed = false;
        try {
			String strPersonId = PersonUtil.getPersonObjectID(context);
			DomainObject doPerson = new DomainObject(strPersonId);
			StringList slPersonSelect = new StringList();
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
			String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			
			if(UIUtil.isNullOrEmpty(strFirstName)){
				strFirstName = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strLastName)){
				strLastName = DomainConstants.EMPTY_STRING;
			}
			
			String strUser = strFirstName + " " +strLastName;
			
			Calendar calendarDate = Calendar.getInstance();
			String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
			SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
			String strTime = formatter.format(calendarDate.getTime());
			String strHistory = DomainConstants.EMPTY_STRING;
			
			ContextUtil.pushContext(context);
            HashMap programMap      = (HashMap) JPO.unpackArgs(args);
            String strNewObjectBOQOID    = FrameworkUtil.autoName(context,
                    "type_WMSMeasurementTask",
                    "policy_WMSMeasurementItem");
            String strMBOID         = (String) programMap.get("mbOID");
            String strForm         		= (String) programMap.get("form");
            String strBOQOID         = (String) programMap.get("objectId");
            String strSOROID         = (String) programMap.get("SOROID");
            String strItemType       =(String) programMap.get("itemType");
            String strTypeOfItem     =(String) programMap.get("passedmode");
            String strTitle     =DomainConstants.EMPTY_STRING;
           
            String strParentId      =(String) programMap.get("parentId");
			StringList slTitleList = new StringList();
			if(UIUtil.isNotNullAndNotEmpty(strParentId)){
				DomainObject doWO = new DomainObject(strParentId);
				
				StringList slBOQSelect = new StringList();
				slBOQSelect.add(DomainObject.SELECT_ID);
				slBOQSelect.add(DomainObject.SELECT_TYPE);
				slBOQSelect.add("attribute[Title].value");
				StringList relList = new StringList();
				relList.add(DomainRelationship.SELECT_ID);
				MapList mlBOQList = doWO.getRelatedObjects(context,
															  RELATIONSHIP_BILL_OF_QUANTITY,
															  TYPE_WMS_MEASUREMENT_BOOK+","+TYPE_WMS_SEGMENT+","+TYPE_WMS_MEASUREMENT_TASK, // object pattern
															  slBOQSelect, // object selects
															  relList, // relationship selects
															  false, // to direction
															  true, // from direction
															  (short) 0, // recursion level
															  DomainConstants.EMPTY_STRING, // object where clause
															  DomainConstants.EMPTY_STRING); // relationship where clause
				
				
				String strType = DomainConstants.EMPTY_STRING;
				Map mTemp = null;
				for(int i=0;i<mlBOQList.size();i++){
					mTemp = (Map)mlBOQList.get(i);
					strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
					if(TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
						slTitleList.add((String)mTemp.get("attribute[Title].value"));
					}
				}
				
				if(slTitleList.contains(strTitle)){
					retMap.put("Action","Stop");
                    retMap.put("ErrorMessage","Title of the Item already Exist.");
                    return retMap;
				}

				/*try {
					Double num = Double.parseDouble(strTitle);
				} catch (Exception e) {
					retMap.put("Action","Stop");
                    retMap.put("ErrorMessage","Title can be numeric only");
                    return retMap;
				}	*/			
				
			}
            String strAgreementId = MqlUtil.mqlCommand(context,"print bus "+strBOQOID+" select to["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].from.id dump");
			if(UIUtil.isNotNullAndNotEmpty(strAgreementId)){
				DomainObject doAgreement = new DomainObject(strAgreementId);
				StringList slBOQSelect = new StringList();
				slBOQSelect.add(DomainObject.SELECT_ID);
				slBOQSelect.add(DomainObject.SELECT_TYPE);
				slBOQSelect.add("attribute[Title].value");
				StringList relList = new StringList();
				relList.add(DomainRelationship.SELECT_ID);
				MapList mlBOQList = doAgreement.getRelatedObjects(context,
															  RELATIONSHIP_BILL_OF_QUANTITY+","+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ,
															  TYPE_WMS_SEGMENT+","+TYPE_WMS_MEASUREMENT_TASK, // object pattern
															  slBOQSelect, // object selects
															  relList, // relationship selects
															  false, // to direction
															  true, // from direction
															  (short) 0, // recursion level
															  DomainConstants.EMPTY_STRING, // object where clause
															  DomainConstants.EMPTY_STRING); // relationship where clause
				Map mTemp = null;
				String strType = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlBOQList.size();i++){
					mTemp = (Map)mlBOQList.get(i);
					strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
					if(TYPE_WMS_MEASUREMENT_TASK.equals(strType)){
						slTitleList.add((String)mTemp.get("attribute[Title].value"));
					}
				}
				
				
			}
			double dTitle = 0;
			String strExTitle = DomainConstants.EMPTY_STRING;
			for(int i=0;i<slTitleList.size();i++){
				strExTitle = (String)slTitleList.get(i);
				try {
					Double num = Double.parseDouble(strExTitle);
					if(num > dTitle){
						dTitle = num;
					}
				} catch (Exception e) {
					continue;
				}
			}
			
			strTitle = new BigDecimal(dTitle+1).setScale(0, BigDecimal.ROUND_UP).toPlainString();
						
            DomainRelationship domItemRel = new DomainRelationship();
            String strSORUOM=DomainConstants.EMPTY_STRING;
            //Connecting first level Segment to Measurement book
            if(UIUtil.isNotNullAndNotEmpty(strMBOID))
            {
                strBOQOID = strMBOID;
            }
            DomainObject domSelParent= DomainObject.newInstance(context, strBOQOID);
            String strState = domSelParent.getInfo(context, DomainConstants.SELECT_CURRENT);
            String strTaskType= (strState.equalsIgnoreCase("Create")) ? "Tender Items" : "Non-Tender Items";
            if(UIUtil.isNotNullAndNotEmpty(strBOQOID) && UIUtil.isNotNullAndNotEmpty(strNewObjectBOQOID))
            {
                domItemRel = DomainRelationship.connect(context,domSelParent ,RELATIONSHIP_BILL_OF_QUANTITY, DomainObject.newInstance(context, strNewObjectBOQOID));
            }
            if(UIUtil.isNotNullAndNotEmpty(strSOROID) && UIUtil.isNotNullAndNotEmpty(strNewObjectBOQOID))
            {
                DomainRelationship.connect(context, strNewObjectBOQOID,RELATIONSHIP_WMS_TASK_SOR, strSOROID, true);
                DomainObject domSOR=DomainObject.newInstance(context,strSOROID);
                strSORUOM = domSOR.getAttributeValue(context, ATTRIBUTE_WMS_SOR_UOM);
                
            }
            StringList strListRelSelects=new StringList(1);
            strListRelSelects.add(DomainRelationship.SELECT_ID);
            String strRelID = DomainConstants.EMPTY_STRING;
            Map relMap = domItemRel.getRelationshipData(context, strListRelSelects);
            if(relMap!=null && !relMap.isEmpty())
            {
                StringList slRelID = (StringList)relMap.get(DomainRelationship.SELECT_ID);
                if(slRelID!=null && slRelID.size() > 0)
                {
                    strRelID = (String)slRelID.get(0);
                }
            }
            /// added and modified by Ravi 11 Sept -2018
            Map mAttribute=new HashMap();
			if(strItemType!=null && !strItemType.isEmpty()) {
				mAttribute.put(ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE, strTaskType);
			}
			String sWMSMBEItemType = (String) programMap.get("MBEItemType");
			String sTotalQuantity = (String) programMap.get("TotalQuantity");
			 String strRemarks     =(String) programMap.get("Remarks");
		 
            if(UIUtil.isNotNullAndNotEmpty(sWMSMBEItemType))
            {
			//DomainObject doBOQ = DomainObject.newInstance(context, strNewObjectBOQOID);
			//mAttribute.put(ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE, "Non-Tender Items");
			mAttribute.put(ATTRIBUTE_WMS_MBE_ITEM_TYPE, sWMSMBEItemType);
			mAttribute.put("Title", strTitle);
			mAttribute.put( ATTRIBUTE_WMS_TOTAL_QUANTITY, sTotalQuantity);
			mAttribute.put("Remarks", strRemarks);
            }
            if(UIUtil.isNotNullAndNotEmpty(strForm)&&"WMSProjectNonSORItemCreation".equals(strForm))
            {
            	//DomainObject doBOQ = DomainObject.newInstance(context, strNewObjectBOQOID);
            	mAttribute.put(ATTRIBUTE_WMS_ITEM_RATE_ESCALATION, "No");
            }
            if(UIUtil.isNotNullAndNotEmpty(strTypeOfItem) && strTypeOfItem.equalsIgnoreCase("SOR") && !strSORUOM.isEmpty())
            {
            	//DomainObject doBOQ = DomainObject.newInstance(context, strNewObjectBOQOID);
            	mAttribute.put(ATTRIBUTE_WMS_UNIT_OF_MEASURE, strSORUOM);
            } 
          
			DomainObject doBOQ = DomainObject.newInstance(context, strNewObjectBOQOID);
			
			isContextPushed = true;
            if(!mAttribute.isEmpty()) {
            	
            	doBOQ.setAttributeValues(context, mAttribute);
            }
			
			if(UIUtil.isNotNullAndNotEmpty(strTypeOfItem) && "ADDBOQ".equalsIgnoreCase(strTypeOfItem)){
				
				doBOQ.setState(context,"Active");
			}
			
			StringList slBOQValues = new StringList();
			slBOQValues.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
			slBOQValues.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
			slBOQValues.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
			Map mTemp = (Map)doBOQ.getInfo(context,slBOQValues);
			String strUnit = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"]");
			String strReducedRate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
			String strQuantityEntered = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
			
			if(UIUtil.isNullOrEmpty(strUnit)){
				strUnit  = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strReducedRate)){
				strReducedRate  = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strQuantityEntered)){
				strQuantityEntered  = DomainConstants.EMPTY_STRING;
			}
			
			strHistory = strUser+"|"+strTime+"|"+strUnit+"|"+strReducedRate+"|"+strQuantityEntered;
			
			doBOQ.setAttributeValue(context,ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY,strHistory);
			
            retMap.put(DomainConstants.SELECT_ID,strNewObjectBOQOID);
            retMap.put("parentId",strBOQOID);
            retMap.put(DomainRelationship.SELECT_ID,strRelID);

        } catch (Exception e) {
            e.printStackTrace();
        }finally{
			if(isContextPushed)
			ContextUtil.popContext(context);
		}
        return retMap;
    }
	
	 /**
     * Used to hide the field SOR on task create form
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return boolean value based on parent is a Measurement book task
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public boolean isChildForMB (Context context, String[] args) throws Exception 
    {
        try
        {
            HashMap programMap         = (HashMap) JPO.unpackArgs(args);
 			String strParentId = (String) programMap.get("parentId");
             DomainObject domWO=DomainObject.newInstance(context,strParentId);
            StringList slSelect=new StringList();
            slSelect.add(DomainConstants.SELECT_TYPE);
            slSelect.add("attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
            Map mInfo = domWO.getInfo(context, slSelect);
             if(((String)mInfo.get(DomainConstants.SELECT_TYPE)).equalsIgnoreCase(TYPE_WMS_WORK_ORDER))
            {
            	  String strTypeOfContract= (String) mInfo.get("attribute["+ATTRIBUTE_WMS_TYPE_OF_CONTRACT+"]");
            	  if(strTypeOfContract.equalsIgnoreCase("EPC")) return false;
            }
            
                    return true;
                }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
	
	 /**
     * Used to display the field on task create form
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return boolean value based on Object type
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public boolean toBeDisplayed (Context context, String[] args) throws Exception 
    {
		
        try
        {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strSelectedType = (String) programMap.get("type");
            if(UIUtil.isNullOrEmpty(strSelectedType))
            {
            	String strObjID = (String) programMap.get("objectId");
            	DomainObject domObj = DomainObject.newInstance(context, strObjID);
            	strSelectedType = domObj.getInfo(context, DomainConstants.SELECT_TYPE);
            }
            if(UIUtil.isNotNullAndNotEmpty(strSelectedType))
            {
				String strObjID = (String) programMap.get("objectId");
            	DomainObject domObj = DomainObject.newInstance(context, strObjID);
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_TYPE);
				slSelect.add("to["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].from.id");
				Map mInfo = (Map)domObj.getInfo(context,slSelect);
				String strType = (String)mInfo.get(DomainObject.SELECT_TYPE);
				String strSuppAgrId = (String)mInfo.get("to["+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+"].from.id");
				if(TYPE_WMS_SEGMENT.equals(strType) && UIUtil.isNotNullAndNotEmpty(strSuppAgrId)){
					 return false;					
				}
				
                if( strSelectedType.indexOf(TYPE_WMS_MEASUREMENT_TASK)>=0||strSelectedType.indexOf(TYPE_WMS_SEGMENT)>=0 ||strSelectedType.indexOf(TYPE_WMS_MEASUREMENT_BOOK_ENTRY)>=0 ||strSelectedType.indexOf(TYPE_WMS_MEASUREMENT_BOOK)>=0 ||strSelectedType.indexOf(TYPE_WMS_WORK_ORDER)>=0 )
                {
                    return true;
                }
            }
            return false;
        }
        catch(Exception exception)
        {

        }
        return false;
    }
	
	
	public boolean displayRemarks(Context context, String[] args) throws Exception 
    {	
        try
        {
           boolean bDisplayRemarks = toBeDisplayed(context,args);
		   return !bDisplayRemarks;
        }
        catch(Exception exception)
        {

        }
        return false;
    }

	 /**
     * Added new Method to create new change item
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return New object.
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
	     @com.matrixone.apps.framework.ui.PostProcessCallable
    public void createChangeItem(Context context,String[]args)throws Exception
    {
				
        Map programMap = JPO.unpackArgs(args);
		Map requestMap = (Map)programMap.get("requestMap");
        String strItemId = (String)requestMap.get("objectId");
        String selectedTaskId = (String)requestMap.get("parentId");
        String strType = (String)requestMap.get("type");
        String strPolicy = (String)requestMap.get("policy");
        String strPersonId= PersonUtil.getPersonObjectID(context);
        String strRate = (String)requestMap.get("WMSReducedRate");
        String strQty = (String)requestMap.get("WMSTotalQunatity");
        String strTitle = (String)requestMap.get("WMSTitle");
        String strTitle1 = (String)requestMap.get("WMSTitle1");       
        String strRate1 = (String)requestMap.get("WMSReducedRate1");
        String strQty1 = (String)requestMap.get("WMSTotalQunatity1");
        String strWO = (String)requestMap.get("WOId");
        String strMBEItemType = (String)requestMap.get("MBEItemType");
        if (strMBEItemType == null || "".equals(strMBEItemType)) 
        {
        	strMBEItemType = ATTRIBUTE_WMS_MBE_ITEM_TYPE_DEFAULT_VALUE;
        }
        WMSMeasurementBookEntry_mxJPO mbeJPO = new WMSMeasurementBookEntry_mxJPO(context, args);

        Map newTaskArgs = null;
        if(UIUtil.isNotNullAndNotEmpty(strItemId))
        {
            DomainObject dobItem = DomainObject.newInstance(context,strItemId);
            String itemParentId = (String)dobItem.getInfo(context,"to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.id");
            Map<String,String> mapItemInfo = getItemSORDetails(context, strItemId);
            String strItemOID = createChangeItem(context, strRate, strQty, strTitle, mapItemInfo, strMBEItemType);
            String strItemOID1 =createChangeItem(context, strRate1, strQty1, strTitle1, mapItemInfo, strMBEItemType);
            ArrayList<String> arrayListChangeItemsOIDs = convertToArrayList(strItemOID, strItemOID1);
            if(arrayListChangeItemsOIDs.size()>0)
            {
                String strParentBOQOID = mapItemInfo.get("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.id");
                String strSOROID = mapItemInfo.get("from["+RELATIONSHIP_WMS_TASK_SOR+"].to.id");
                if(UIUtil.isNotNullAndNotEmpty(itemParentId))
                {
                	WMSUtil_mxJPO.connect(context, DomainObject.newInstance(context, itemParentId), RELATIONSHIP_BILL_OF_QUANTITY, true, arrayListChangeItemsOIDs);
                }
                if(UIUtil.isNotNullAndNotEmpty(strSOROID))
                {
                    DomainObject domSORItem = DomainObject.newInstance(context,strSOROID);
                    WMSUtil_mxJPO.connect(context, domSORItem, RELATIONSHIP_WMS_TASK_SOR, false, arrayListChangeItemsOIDs);
                }
                
                createApprovalRouteForChangeItem(context,arrayListChangeItemsOIDs , args, strTitle1,strWO);
            }

        }
    }
	
/**
     * This method update the attribute of Change Item
     * @param context - the eMatrix <code>Context</code> object
     * @param Map with id of new change object
     * @param Map attribute values
     * @return - MapList
     * @throws Exception if the operation fails
     * @author WMS
     * @throws FrameworkException 
     * @since 418
     */
    Map<String,String> getItemSORDetails(Context context,String strItemId) throws FrameworkException
    {           
        try
        {
            Map<String,String> mapSORInfo = new HashMap<String,String>(2);
            if(UIUtil.isNotNullAndNotEmpty(strItemId))
            {
                DomainObject domObjItem = DomainObject.newInstance(context, strItemId);
                StringList slSelect = new StringList(4);
                slSelect.add("from["+RELATIONSHIP_WMS_TASK_SOR+"].to.id");
                slSelect.add(DomainConstants.SELECT_DESCRIPTION);
                slSelect.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
                slSelect.add("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.id");
                mapSORInfo = domObjItem.getInfo(context,slSelect);

            }
            return mapSORInfo;
        }
        catch(FrameworkException frameworkException)
        {
            frameworkException.printStackTrace();
            throw frameworkException;
        }     
    }	
	
	private String createChangeItem(Context context, String strNewRate, String strNewQty, String strNewTitle,
            Map<String, String> mapItemInfo, String strNewMBEItemType) throws Exception {
        if(UIUtil.isNotNullAndNotEmpty(strNewQty)&&UIUtil.isNotNullAndNotEmpty(strNewRate)&&UIUtil.isNotNullAndNotEmpty(strNewTitle))
        {
            Map<String,String> mapAttribute = new HashMap();    
            String strItemOID  = FrameworkUtil.autoName(context,
                    "type_WMSMeasurementTask",
                    "policy_WMSMeasurementItem");
            if(UIUtil.isNotNullAndNotEmpty(strItemOID))
            {
                
                DomainObject domObj = DomainObject.newInstance(context, strItemOID);
                mapAttribute.put(ATTRIBUTE_WMS_TOTAL_QUANTITY, strNewQty);
                mapAttribute.put(ATTRIBUTE_WMS_REDUCED_SOR_RATE, strNewRate);
                mapAttribute.put(DomainConstants.ATTRIBUTE_TITLE,strNewTitle);
                mapAttribute.put(ATTRIBUTE_WMS_UNIT_OF_MEASURE,mapItemInfo.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value"));
                mapAttribute.put(ATTRIBUTE_WMS_MBE_ITEM_TYPE,strNewMBEItemType);
                String strDescription = (String)mapItemInfo.get(DomainConstants.SELECT_DESCRIPTION);
                domObj.setDescription(context,strDescription);
                domObj.setAttributeValues(context, mapAttribute);
                domObj.promote(context);
                return strItemOID;
            }
        }
        return DomainConstants.EMPTY_STRING;
    }

	 private ArrayList<String> convertToArrayList(String strItemOID, String strItemOID1) {
        ArrayList<String> arrayListChangeItemsOIDs = new ArrayList<String>();
        if(UIUtil.isNotNullAndNotEmpty(strItemOID))
        {
        arrayListChangeItemsOIDs.add(strItemOID);
        }
        
        if(UIUtil.isNotNullAndNotEmpty(strItemOID1))
        {
        arrayListChangeItemsOIDs.add(strItemOID1);
        }
        return arrayListChangeItemsOIDs;
    }

	
	/** 
     * Method to create a Approval route for Change Item object
     * @param context the eMatrix <code>Context</code> object
     * @param args with program arguments       
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    public void createApprovalRouteForChangeItem(Context context, ArrayList<String> arrayListOID,String[] args,String strTitle,String strWorkOrderOID) throws Exception 
    {
        try
        {           
            {
                String strRel = DomainConstants.EMPTY_STRING;
                String strRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
                String strChangeItemFirst = arrayListOID.get(0);
                String[] arraySecondListOID = new String[1];
                arraySecondListOID[0] = (String)arrayListOID.get(1);
                String strContextUser = context.getUser();
                if(UIUtil.isNotNullAndNotEmpty(strChangeItemFirst))
                {
                    DomainObject domChangeItemObj= DomainObject.newInstance(context, strChangeItemFirst);
                    WMSUtil_mxJPO wmsUtilOBJ = new WMSUtil_mxJPO(context, args);
                   // {
                        MapList routeMapList=wmsUtilOBJ.checkForExistingRouteObject(context,domChangeItemObj,strRelWhere);                        
                        if(routeMapList.size()>0)
                        {
                            wmsUtilOBJ.restartExistingRoute(context,routeMapList);
                        }
                        else
                        {                           
                            String strRoles = "Sub Divisional Officer,Executive Engineer";
                            if(UIUtil.isNotNullAndNotEmpty(strRoles))
                            {                               
                                StringList slRoles = new StringList();
                                if(strRoles.contains(","))
                                {
                                    slRoles = FrameworkUtil.split(strRoles, ",");
                                }
                                else
                                {
                                    slRoles.add(strRoles);
                                }
                                emxChangeBase_mxJPO emxJPO =  new emxChangeBase_mxJPO(context,new String[]{});
                               StringList strListUsers = getWorkOrderUserFromRole(context,slRoles, strWorkOrderOID,strContextUser);
                                if(strListUsers.size()>0)
                                {
                                    String[] methodArgs = {strChangeItemFirst,POLICY_WMS_MEASUREMENT_ITEM,"state_Active"};                                 
                                    Route objRoute = wmsUtilOBJ.createAndConnectRoute(context, methodArgs,"Approval");
                                    BusinessObject personObject = PersonUtil.getPersonObject(context, context.getUser());
                                    wmsUtilOBJ.connectProjectRoute(context, objRoute ,personObject);
                                    for(int i=0; i<strListUsers.size(); i++)
                                    {
                                        String strUser = (String)strListUsers.get(i);
                                        MapList taskMapList = wmsUtilOBJ.getRouteTaskMapListForObject(context, domChangeItemObj,strUser,"Approval", "Approve");
                                        Iterator iterator = taskMapList.iterator();                                     
                                        objRoute.addRouteMembers(context,taskMapList,new HashMap());                                        
                                    }
                                        emxJPO.startRoute(context, objRoute.getObjectId());
                                    objRoute.AddContent(context, arraySecondListOID);
                                }
                            }
                        }
                   // }
                }
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }
	
	
	public static StringList getWorkOrderUserFromRole(Context context, StringList slRoleName, String strWorkOrderOID,String strUser)
            throws Exception {
        StringList strListMembers = new StringList();
        try
        {
            MapList mapListMembers = getWorkOrderAssignees(context, strWorkOrderOID);
            if(hasMultipleRoleUser(slRoleName,mapListMembers))
            {
            	 MapList reportingManagers = getReportingManagers(context, slRoleName,mapListMembers,strUser);
            	strListMembers = WMSUtil_mxJPO.filterMembersByRoles(slRoleName, reportingManagers);
            }
            else
            {
            strListMembers = WMSUtil_mxJPO.filterMembersByRoles(slRoleName, mapListMembers);
			}                    	
        }
        catch(Exception  exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListMembers;
    }

/**
     * Returns true if multiple people of same role found
     * @param strProjectRole - Role name
     * @param slWOMemebersRole - Work Order member roles
     * @return boolean value
     * @author WMS
     * @throws Exception 
     * @since 418
     **/
    public static boolean hasMultipleRoleUser(StringList slRoleName,MapList mapListMembers)
    {
    	boolean hasMultipleRole = false;
    	try {
    		int countAlreadyExist = 0;
    		StringList strListProjectRole = new StringList();
    		String  strWORole = DomainConstants.EMPTY_STRING;
    		if(mapListMembers!=null && mapListMembers.size()>0)
    		{
    			ListIterator<Map<String,String>> membersItr = mapListMembers.listIterator();
    			Map<String,String> memberMap;
    			while(membersItr.hasNext())
    			{
    				memberMap = membersItr.next();
    				if(memberMap!=null&&!memberMap.isEmpty())
    				{
    					strWORole = (String)memberMap.get(MemberRelationship.SELECT_PROJECT_ROLE);
    					if(!strListProjectRole.contains(strWORole))
    					{
    						if(slRoleName.contains(strWORole))
    						{
    							strListProjectRole.add(strWORole);
    						}
    					}
    					else
    					{
    						countAlreadyExist++;
    					}    					
    					}
    				}
    		} 
    		if(countAlreadyExist > 0)
    		{
    			hasMultipleRole = true;
    		}
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		throw e;
    	}
    	return hasMultipleRole;
    }

	
	/**
     * Returns users for route task, this method check the reporting managers of context user and compare it with Work Order member list
     * if the Work order has multiple people with same role then it will return person which is reporting manager of context user
     * @param strRoleName StringList containing value roles (Schema Name)
     * @param membersList MapList containing list of Project Member
     * @return strListMembers String containing filter Project Members names assigned with the role
     * @author WMS
     * @throws Exception 
     * @since 418
     **/
    public static MapList getReportingManagers(Context context,StringList slRoleName,MapList mapListMembers,String contextUser) throws Exception {
    	MapList mlMembers = new MapList();
    	try {
    		StringList slWOMemebers = new StringList();
    		StringList slWOMemebersRole = new StringList();
    		if(mapListMembers!=null && mapListMembers.size()>0)
    		{
    			ListIterator<Map<String,String>> membersItr = mapListMembers.listIterator();
    			Map<String,String> memberMap;
    			while(membersItr.hasNext())
    			{
    				memberMap = membersItr.next();
    				if(memberMap!=null&&!memberMap.isEmpty())
    				{
    					slWOMemebers.add((String)memberMap.get(Person.SELECT_NAME));
    					slWOMemebersRole.add((String)memberMap.get(MemberRelationship.SELECT_PROJECT_ROLE));
    				}
    			}
    		}
    		StringList strListBusSelects = new StringList(DomainConstants.SELECT_ID);
    		strListBusSelects.add(MemberRelationship.SELECT_PROJECT_ROLE);  
    		strListBusSelects.add(DomainConstants.SELECT_NAME);
    		String userID           = PersonUtil.getPersonObjectID(context, contextUser);
    		DomainObject domContextUser = DomainObject.newInstance(context,userID);
    		MapList membersList = domContextUser.getRelatedObjects(context, // matrix context
    				RELATIONSHIP_WMS_REPORTING_MANAGER, // relationship pattern
    				DomainConstants.TYPE_PERSON, // type pattern
    				strListBusSelects, // object selects
    				DomainConstants.EMPTY_STRINGLIST, // relationship selects
    				true, // to direction
    				false, // from direction
    				(short) 0, // recursion level
    				DomainConstants.EMPTY_STRING, // object where clause
    				DomainConstants.EMPTY_STRING, // relationship where clause
    				0);			


    		ListIterator<String> listIteratorRoles = slRoleName.listIterator();
    		while(listIteratorRoles.hasNext())
    		{
    			String strRole = listIteratorRoles.next();        	
    			if(membersList!=null && membersList.size()>0)
    			{
    				ListIterator<Map<String,String>> membersItr = membersList.listIterator();
    				Map<String,String> memberMap;
    				while(membersItr.hasNext())
    				{
    					memberMap = membersItr.next();
    					String strProjectRole = (String)memberMap.get(MemberRelationship.SELECT_PROJECT_ROLE);
    					String strRoleUser = (String)memberMap.get(Person.SELECT_NAME);

    					if(strRole.equalsIgnoreCase(strProjectRole))
    					{
    						if(slWOMemebers.contains(strRoleUser))
    						{
    							mlMembers.add(memberMap);
    							break;
    						}
    					}
    				}
    			}

    		}   
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		throw e;
    	}
    	    	return mlMembers;
    }



/**
     * method is used to create new segment 
     * Used for BOQ page
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args 
     * @returns HashMap
     * @throws Exception if the operation fails
     * @author WMS
     * @since 417
     */
    @com.matrixone.apps.framework.ui.ConnectionProgramCallable
    public HashMap createSegment(Context context, String [] args) throws Exception
    {		
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
        Map paramMap = (Map) programMap.get("paramMap");
        String strSelectedObjId =(String)programMap.get("objectId");
        String strWOObjId = (String)paramMap.get("objectId");
		String sWMSMBEItemType = (String) paramMap.get("MBEItemType");
		StringList slBusSelect = new StringList();
		slBusSelect.add(DomainObject.SELECT_CURRENT);
		slBusSelect.add("from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");
		Map<String, String>woData = new HashMap<>();
		if (sWMSMBEItemType == null || "".equals(sWMSMBEItemType)) {
			sWMSMBEItemType = ATTRIBUTE_WMS_MBE_ITEM_TYPE_DEFAULT_VALUE;
		}
        if(UIUtil.isNotNullAndNotEmpty(strWOObjId)&&UIUtil.isNullOrEmpty(strSelectedObjId))
        {
            DomainObject domWo = DomainObject.newInstance(context,strWOObjId);
            woData = domWo.getInfo(context,slBusSelect);
            strSelectedObjId = woData.get("from["+RELATIONSHIP_BILL_OF_QUANTITY+"].to.id");
            
        }
        
        String sRowId = DomainConstants.EMPTY_STRING ;
        
        HashMap objMap = new HashMap();
        HashMap retMap;

        DomainObject domSelectedObject =  DomainObject.newInstance(context,strSelectedObjId);
        DomainObject doNewObject = DomainObject.newInstance(context);

       MapList mlItems = new MapList();     

       Element elm = (Element) programMap.get("contextData");        
       MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
       Map mapAttr = new HashMap();  
       String strDescriptionKey="Description";
       for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
       {
           try
           {   
               retMap = new HashMap();
               Map changedRowMap = (HashMap) chgRowsMapList.get(i);
               Map columnsMap = (HashMap) changedRowMap.get("columns");
               sRowId = (String) changedRowMap.get("rowId");
               String strTitle = (String) columnsMap.get("Title");
               strTitle = strTitle.trim();
                if(columnsMap.containsKey("Description1")) {
            	   strDescriptionKey="Description1";
               }
               String strDescription = (String) columnsMap.get(strDescriptionKey);
               strDescription = strDescription.trim();
               String strNewObject = FrameworkUtil.autoName(context,
                        "type_WMSSegment",
                        null,
                        "policy_WMSMeasurementItem",
                        null,
                        null,
                        true,
                        true);
                DomainRelationship domRel   = doNewObject.createAndConnect(context,
                        TYPE_WMS_SEGMENT,
                        strNewObject,
                        "-",
                        POLICY_WMS_MEASUREMENT_ITEM,
                        null,
                        RELATIONSHIP_BILL_OF_QUANTITY,
                        domSelectedObject,
                        true);

                doNewObject.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, strTitle);
                doNewObject.setAttributeValue(context, ATTRIBUTE_WMS_MBE_ITEM_TYPE, sWMSMBEItemType);
                doNewObject.setDescription(context,strDescription);
                if("Active".equals(woData.get(DomainObject.SELECT_CURRENT))) {
                	 doNewObject.setState(context,"Active");
                }
               
                retMap = new HashMap();
                retMap.put("oid", doNewObject.getObjectId(context));
                retMap.put("relid", domRel.toString());
                retMap.put("pid",strSelectedObjId);
                retMap.put("rid", "");
                retMap.put("markup", "new");
                retMap.put("rowId", sRowId);                
                mlItems.add(retMap);
                objMap.put("changedRows", mlItems);// Adding the key "ChangedRows"
                objMap.put("Action", "refresh"); // Here the action can be "Success" or "refresh"
            }
            catch(Exception Ex)
            {
                Ex.printStackTrace();
                throw Ex;
            }
       }
        
        return objMap;
    }


	/**
     * Method to get the disconnected SOR Items from Work Order
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @return String containing the message
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public String removeWOSORItems (Context context, String[] args) throws Exception 
    {
        try
        {            
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String[] emxTableRowId = (String[]) programMap.get("emxTableRowId");
                      
            if(emxTableRowId !=null && emxTableRowId.length>0)
            {                
                ArrayList<String> arrayListRelOIDs = new ArrayList<String>();
                for(int i=0;i<emxTableRowId.length;i++)
                {
                  StringTokenizer st = new StringTokenizer(emxTableRowId[i], "|");
                  String sObjId = st.nextToken();
                  arrayListRelOIDs.add(sObjId);          
                 
					while (st.hasMoreTokens()) 
					{
					   sObjId = st.nextToken();
					}      
                }        
                 
				WMSUtil_mxJPO.disconnect(context, arrayListRelOIDs);
                return "Selected objects sucessfully removed";

            }                    
            return "Selected objects sucessfully removed";
        }catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
	
public boolean isHiddenForDepartment1(Context context, String[] args) throws Exception 
    {
		/*boolean bReturnStatus = true;
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		HashMap strSettings = (HashMap)programMap.get("SETTINGS");
		String strHiddenDepartmentList = (String)strSettings.get("HiddenForDepartment");
		String strDepartment = DomainConstants.EMPTY_STRING;
		String strHiddenDpt = DomainConstants.EMPTY_STRING;
		StringList slDptList = new StringList();
		
		try {
			MapList mapListDepartment = WMSUtil_mxJPO.getContextUserDepartment(context);
    		Iterator<Map<String,String>> iterator = mapListDepartment.iterator();
    		Map<String,String> mapData;
    		for(String w:strHiddenDepartmentList.split(",",0))
            {  
    			slDptList.add(w);
            }
    		while(iterator.hasNext())
    		{
    			mapData = iterator.next();
    			strDepartment = mapData.get(DomainConstants.SELECT_NAME);
    			
    		}
    		if(slDptList.contains(strDepartment)) {
    			bReturnStatus = false;
    		}else {
    			bReturnStatus = true;
    		}
    	
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}*/
		return true;
	
    }


public boolean showForDepartment(Context context, String[] args) throws Exception 
	    {
			/*boolean bReturnStatus = false;
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			HashMap strSettings = (HashMap)programMap.get("SETTINGS");
			String strAllowDepartmentList = (String)strSettings.get("AllowForDepartment");
			String strDepartment = DomainConstants.EMPTY_STRING;
			String strAllowDpt = DomainConstants.EMPTY_STRING;
			StringList slDptList = new StringList();
			
			try {
				MapList mapListDepartment = WMSUtil_mxJPO.getContextUserDepartment(context);
	    		Iterator<Map<String,String>> iterator = mapListDepartment.iterator();
	    		Map<String,String> mapData;
	    		for(String w:strAllowDepartmentList.split(",",0))
	            {  
	    			slDptList.add(w);
	            }
	    		while(iterator.hasNext())
	    		{
	    			mapData = iterator.next();
	    			strDepartment = mapData.get(DomainConstants.SELECT_NAME);
	    			
	    		}
	    		if(slDptList.contains(strDepartment)) {
	    			bReturnStatus = true;
	    		}else {
	    			bReturnStatus = false;
	    		}
	    		
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}*/
			return true;
	    }

	public StringList addDeviation(Context Context, String[] args) throws Exception {
		try {
	
			   Map mInputParams= JPO.unpackArgs(args);
			   AttributeList al=new AttributeList(3);
			   al.addElement(new Attribute(new AttributeType(ATTRIBUTE_WMS_REDUCED_SOR_RATE), "0.0"));
			   al.addElement(new Attribute(new AttributeType(ATTRIBUTE_WMS_TOTAL_QUANTITY), "0.0"));
			   al.addElement(new Attribute(new AttributeType(ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE), "Deviation"));
			   
			  String[] strSelectedItems =  (String[]) mInputParams.get("selectId");
			  String strParentID =(String) mInputParams.get("objectId");
			  String[] mParsedIds = ProgramCentralUtil.parseTableRowId(context, strSelectedItems);
		 	  DomainObject domNonTender= DomainObject.newInstance(context);
			  DomainObject domNonTenderCloned= DomainObject.newInstance(context);
			  String strNewName=DomainConstants.EMPTY_STRING;
			  StringList slRowIds=new StringList();
			  StringList slBusSelect=new StringList(2);
			  slBusSelect.add("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.id");
			  slBusSelect.add("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].id");
			  String strClonedId=DomainConstants.EMPTY_STRING;
			  String strClonedParentID=DomainConstants.EMPTY_STRING;
			  String strClonedRelID=DomainConstants.EMPTY_STRING;
			  for(String mParsedId : strSelectedItems) {
				/*strNewName = FrameworkUtil.autoName(context,"type_WMSMeasurementTask", DomainConstants.EMPTY_STRING,
							DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING, true,
							false);  */                  
				domNonTender.setId(mParsedId);
				/*BusinessObject  buscloneObject = domNonTender.cloneObject(context, strNewName);
				buscloneObject.open(context);
				buscloneObject.setAttributeValues(context, al);
				strClonedId=buscloneObject.getObjectId(context);
				buscloneObject.close(context);
		 		domNonTenderCloned.setId(strClonedId);*/
				/*Map mData= domNonTenderCloned.getInfo(context, slBusSelect);
				strClonedParentID=(String)mData.get("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.id");
				strClonedRelID=(String)mData.get("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].id");
				 slRowIds.add(strClonedId+"~"+strClonedRelID+"~"+strClonedParentID);*/
				String strRelId = (String)domNonTender.getInfo(context,"to["+RELATIONSHIP_BILL_OF_QUANTITY+"].id");
				String strNewRelId = MqlUtil.mqlCommand(context,"add connection "+RELATIONSHIP_WMS_SUPPLIMENTARY_AGREEMENT_BOQ+" from "+strParentID+" torel "+strRelId);
				slRowIds.add(mParsedId+"~"+strNewRelId+"~"+strParentID);
	}
			 
		return slRowIds;
		
	   }catch(Exception e) {
 			e.printStackTrace();
			throw e;
	    }
	}
	
	/* method called from BOQ Send for Approval command
	 * creates routes for all selected non tender items/deviation
	 * 
	 */
	
	public Map sendNonTenderBOQItemsForApproval(Context context, String[] args) throws Exception {

		String strMsg = "Failed to send for Approval";
		DomainObject domSelId = DomainObject.newInstance(context);
		Map m=new HashMap();
		m.put("Error", "No");
		try {
			// ContextUtil.startTransaction(context, true);
			Map mInputParams = (Map) JPO.unpackArgs(args);
			String strWorkOrderId = (String) mInputParams.get("WorkOrderId");
			String sTypeOfContract = (String) mInputParams.get("TypeOfContract");
			String[] selectedIds = (String[]) mInputParams.get("selectedIds");
			String selectedObjCurrent = (String) mInputParams.get("current");
			DomainObject domWOObj = new DomainObject(strWorkOrderId);
			String strExcludeId = DomainConstants.EMPTY_STRING;
			WMSUtil_mxJPO wmsUtilOBJ = new WMSUtil_mxJPO(context, args);
			StringList sl = new StringList();
			sl.add("from[" + RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE + "|.attribute["
					+ ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE + "]=='Item Approval'].to.id");
			DomainConstants.MULTI_VALUE_LIST.add("from[" + RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE
					+ "|.attribute[" + ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE + "]=='Item Approval'].to.id");
			DomainConstants.MULTI_VALUE_LIST.add("from[" + RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE + "].to.id");
			Map mTemplateId = domWOObj.getInfo(context, sl);
			if (mTemplateId.containsKey("from[" + RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE + "].to.id")) {

				Map mReturn = getAllBOQItemsForReview(context, domWOObj, sTypeOfContract);
				boolean bError = (boolean) mReturn.get("IsError");
				if (bError) {
					m.put("Error", "Yes");
					strMsg = (String) mReturn.get("Error");
					List errorList = (List) mReturn.get("ErrorList");
					if (errorList.isEmpty()) {
						strMsg = "No items are pending for approval ";
					} else {
						strMsg = strMsg + "  \\n" + errorList.toString();
					}
				} else {
					List approvalList = (List) mReturn.get("ApprovalList");
			 		selectedIds = (String[]) mReturn.get("ApplicableIds");
					String[] arrConnectIds = new String[selectedIds.length - 1];
					int i = 0;
					for (String selId : selectedIds) {
						domSelId.setId(selId);
				 			domSelId.promote(context);
						 if (i < selectedIds.length - 1)// skip last one ,use it while creating Route
							arrConnectIds[i] = selId;
						i++;
					}
				StringList slTempId = (StringList) mTemplateId
						.get("from[" + RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE + "].to.id");
				String strTemplateId = (String) slTempId.get(0);
				String strRelWhere = "attribute[" + Route.ATTRIBUTE_ROUTE_STATUS + "]==\"Stopped\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, domSelId, strRelWhere);
				if (mlExtRoutes.size() > 0) {
					WMSUtil_mxJPO.restartExistingRoute(context, mlExtRoutes);
				} else {
			 		Map mRouteAttrib = new HashMap();
					Map reviewerInfo = new HashMap();
					mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
					Map objectRouteAttributeMap = new HashMap();
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,
							FrameworkUtil.getAliasForAdmin(context, "Policy", POLICY_WMS_MEASUREMENT_ITEM, false));

					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE, "state_Review");
					objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE, "Review");
						Route route = Route.createAndStartRouteFromTemplateAndReviewers(context, strTemplateId,
								"Item Review", context.getUser(), selectedIds[selectedIds.length - 1],
								POLICY_WMS_MEASUREMENT_ITEM, "Review", mRouteAttrib, objectRouteAttributeMap,
								reviewerInfo, true);
					
				  		if (arrConnectIds.length > 0) {
							try {
								RelationshipType relType = new RelationshipType(DomainConstants.RELATIONSHIP_OBJECT_ROUTE);
								Map mData = DomainRelationship.connect(context, route, relType, false, arrConnectIds);
								Map mRelAttributes = new HashMap();
								mRelAttributes.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE, "Review");
								mRelAttributes.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE, "state_Review");
								mRelAttributes.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,
										"policy_WMSMeasurementItem");
								for (String id : arrConnectIds) {
									String strRelId = (String) mData.get(id);
									DomainRelationship domRelObjRoute = new DomainRelationship(strRelId);
									domRelObjRoute.setAttributeValues(context, mRelAttributes);
				}
							 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

						// ContextUtil.commitTransaction(context);
				}
					strMsg = "Below items have been sent for Approval; \\n " + approvalList.toString();
					String strParentsIds= getParentOfTask(context,selectedIds);
					m.put("Ids", strParentsIds);
				}
			 }
		} catch (Exception e) {
			// domSelId.demote(context);
			strMsg = "Failed to send for Approval";
			// ContextUtil.abortTransaction(context);
			e.printStackTrace();
	 		}
		m.put("Message", strMsg);
		return m;
	 }

	 /** Trigger method on Inbox Task review state
	    * checks if Route is stopped or not if yes,,then demotes the connected object
	    * and sends mail notification to Owner
	    * @param context
	    * @param args
	    * @return
	    * @throws Exception
	    */
			
	
	 public int triggerDemoteObjectOnRejection(Context context,String[] args) throws Exception
	 {
		 
		String strInboxTask= args[0]; 
	 	String strCurrentState=args[1];
		String strType=args[2];
  	   try {
	 	if(strType.equalsIgnoreCase(DomainConstants.TYPE_INBOX_TASK ) && strCurrentState.equalsIgnoreCase("Complete")) {
		    DomainObject domObject=DomainObject.newInstance(context, strInboxTask);
			StringList slSelect=new StringList(2);
			slSelect.add("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
			slSelect.add("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_ROUTE_STATUS+"]");
			slSelect.add("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.id");
			slSelect.add("to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].from.type");
			slSelect.add("to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].from.id");
			slSelect.add("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.name");
			slSelect.add("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].from.id");
			slSelect.add("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].from.type");
			slSelect.add("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].from.owner");
			slSelect.add("to["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].from.from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.name");
			Map mInfo = domObject.getInfo(context, slSelect);
			String strRouteStatus= (String) mInfo.get("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_ROUTE_STATUS+"]");
		    if(strRouteStatus!=null && strRouteStatus.equalsIgnoreCase("STOPPED")) {	
				String strFromType = (String) mInfo.get("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].from.type");
				String strOwner= (String) mInfo.get("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].from.owner");
				String strRejectedComment= (String) mInfo.get("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
				String strFromPerson= (String) mInfo.get("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.name");
				String notifyType = "IconMail";
				StringBuffer sbSubject = new StringBuffer();
				StringBuffer sbMessage = new StringBuffer();
				StringList slToPersonList = new StringList();
				slToPersonList.add(strOwner);
				StringList slObjectIdList = new StringList();
				String strRouteConnObjectId=  (String) mInfo.get("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.to["+DomainConstants.RELATIONSHIP_OBJECT_ROUTE+"].from.id");
				// if Measurement Task;
				boolean bSendMail=false;
				if(strFromType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY) || strFromType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY) || strFromType.equalsIgnoreCase(TYPE_WMS_SUPPLIMENTARY_AGREEMENT) || strFromType.equalsIgnoreCase(TYPE_WMSRIC) || strFromType.equalsIgnoreCase(TYPE_WMSAE) || strFromType.equalsIgnoreCase(TYPE_WMSDCSMASTER) || strFromType.equalsIgnoreCase(TYPE_WMSTECHNICALSANCTION) || strFromType.equals(TYPE_WMSWOO) || strFromType.equals(TYPE_WMSADMINAPPROVAL) || strFromType.equals(TYPE_WMSDELEGATION) || strFromType.equals(TYPE_WMS_FUND_REQUEST) || strFromType.equals(TYPE_WMS_FUND_RELEASE) || strFromType.equals(TYPE_WMS_DEFAULT_MASTERS) || strFromType.equalsIgnoreCase(TYPE_WMSRICMASTER) || strFromType.equalsIgnoreCase(TYPE_WMSAEMASTER)) {
					String strRouteId=(String) mInfo.get("from["+DomainConstants.RELATIONSHIP_ROUTE_TASK+"].to.id");
					Route route=new Route(strRouteId);
					//route
					StringList objectSelects = new StringList();
					objectSelects.add(DomainConstants.SELECT_ID);
					objectSelects.add(DomainConstants.SELECT_DESCRIPTION);
					objectSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
				   //bad there should be direct connection btwen Mtask and Work Order :( 
					objectSelects.add("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.id");  
					StringList relSelects = new StringList();
					int limit = 100;
					String strTaskTitle =  DomainConstants.EMPTY_STRING;
					String strDescription = DomainConstants.EMPTY_STRING;
					String strWorkOrderId = DomainConstants.EMPTY_STRING;
					List<String> lsTitle= new ArrayList<String>();
					MapList contentList = route.getRelatedObjects(context, 
																 DomainConstants.RELATIONSHIP_OBJECT_ROUTE, 
																TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY+","+TYPE_WMS_MEASUREMENT_BOOK_ENTRY+","+TYPE_WMS_SUPPLIMENTARY_AGREEMENT+","+TYPE_WMSRIC+","+TYPE_WMSAE+","+TYPE_WMSDCSMASTER+","+TYPE_WMSTECHNICALSANCTION+","+TYPE_WMSWOO+","+TYPE_WMSADMINAPPROVAL+","+TYPE_WMSDELEGATION+","+TYPE_WMS_FUND_RELEASE+","+TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_DEFAULT_MASTERS+","+TYPE_WMSAEMASTER+","+TYPE_WMSRICMASTER, 
																objectSelects, 
																relSelects, 
																true, 
																false, 
																(short)0, 
																DomainConstants.EMPTY_STRING, 
																null, 
																limit);
				   try {
					 ContextUtil.pushContext(context, "User Agent", null, null);
						for(int i=0;i<contentList.size();i++) {
							Map m=(Map)contentList.get(i);
							strRouteConnObjectId= (String)m.get(DomainConstants.SELECT_ID);
							domObject.setId(strRouteConnObjectId);
							strTaskTitle = (String)m.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
							strDescription = (String)m.get(DomainConstants.SELECT_DESCRIPTION);
							strWorkOrderId = (String)(String)m.get("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.id");
							lsTitle.add(strTaskTitle);
							domObject.demote(context);
					}
				   }finally{
						ContextUtil.popContext(context);
					
				   }
				}
				/*if(strWorkOrderId!=null) {
					sbSubject.append("BOQ Item(s) ").append(lsTitle.toString());
			 	 	sbSubject.append("  are rejected by ").append(strFromPerson);
					sbMessage.append("BOQ Items ").append(lsTitle.toString());
					sbMessage.append(" : ");
					DomainObject domWo=DomainObject.newInstance(context, strWorkOrderId);
			 		sbMessage.append(" under work order ").append(domWo.getAttributeValue(context, ATTRIBUTE_WMS_WORK_ORDER_TITLE));
					sbMessage.append("  has been rejected by  ").append(strFromPerson).append(", please find rejection comments  \n ");
					sbMessage.append(" '").append(strRejectedComment).append("'");
					sbMessage.append("\n  ");
					sbMessage.append("please take corrective actions and resend for approval.");
					bSendMail=true;
				}
		 		slObjectIdList.add(strWorkOrderId);
			   // ${CLASS:emxNotificationUtil}.sendJavaMail(context, slToPersonList, null, null, sbSubject.toString(), sbMessage.toString(), "", strFromPerson, null, slObjectIdList, notifyType);
	 		 }else if(strFromType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY)) {
				
				   domObject.setId(strRouteConnObjectId);
			 		StringList slInfo= new StringList(3);
					slInfo.add("to["+RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
				  	slInfo.add(DomainConstants.SELECT_NAME);
					Map mTaskInfo = domObject.getInfo(context, slInfo);
					String strTaskTitle = (String)mTaskInfo.get(DomainConstants.SELECT_NAME);
					String strDescription = (String)mTaskInfo.get(DomainConstants.SELECT_DESCRIPTION);
					String strWorkOrderTitle = (String)mTaskInfo.get("to["+RELATIONSHIP_WMS_WORK_ORDER_ABSTRACT_MBE+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
					slObjectIdList.add(strRouteConnObjectId);
					sbSubject.append("Bill  ").append(strTaskTitle);
			 	 	sbSubject.append("  is rejected by ").append(strFromPerson);
		  		    sbMessage.append("Bill ").append(strTaskTitle);
					sbMessage.append(" : ");
			 			sbMessage.append(" under work order ").append(strWorkOrderTitle);
						sbMessage.append("  has been rejected by  ").append(strFromPerson).append(", please find rejection comments  \n ");
						sbMessage.append(" '").append(strRejectedComment).append("'");
						sbMessage.append("\n  ");
						sbMessage.append("please take corrective actions and resend for approval.");
						ContextUtil.pushContext(context, "User Agent", null, null);
						domObject.demote(context);
						ContextUtil.popContext(context);
						bSendMail=true;
				 	   // ${CLASS:emxNotificationUtil}.sendJavaMail(context, slToPersonList, null, null, sbSubject.toString(), sbMessage.toString(), "", strFromPerson, null, slObjectIdList, notifyType);
				   }
			
			if(bSendMail) {
				String[] subjectKeys = {};
                String[] subjectValues = {};

                String[] messageKeys = {};
                String[] messageValues = {};
				MailUtil.sendNotification(context,
                  		slToPersonList,
                                            null,
                                            null,
                                            sbSubject.toString(),
                                            subjectKeys,
                                            subjectValues,
                                            sbMessage.toString(),
                                            messageKeys,
                                            messageValues,
                                            slObjectIdList,
                                            null);
				
			  }*/
			
	 		}
	 	}
	 }catch(Exception e) {
		System.out.println(" from trigger : triggerDemoteObjectOnRejection ");
		 e.printStackTrace();
		 
	 } 
		 
	 return 0;	 
		 }
	
	 
	 
 
	    public Map getAllBOQItemsForReview(Context context,DomainObject domWOObj,String sTypeOfContract) throws Exception
	    {
	        Map mReturn=new HashMap();
	        MapList mapListObjects = new MapList();
	        StringList strListBusSelects     = new StringList(3);
	        strListBusSelects.add(DomainConstants.SELECT_ID);
		 	strListBusSelects.add(DomainConstants.SELECT_TYPE);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			strListBusSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
			strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
			String errEPC="Quantity is missing on below items";
			String errOther="Rate/quantity is missing on below items";
	    	StringList strListRelSelects = new StringList(1);
	        strListRelSelects.add(DomainRelationship.SELECT_ID);
	        Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_BOOK);
	        patternType.addPattern(TYPE_WMS_SEGMENT);
	        patternType.addPattern(TYPE_WMS_MEASUREMENT_TASK);
	        Pattern patternRel = new Pattern(RELATIONSHIP_BILL_OF_QUANTITY);  
	        Map m=new HashMap();
	        m.put(DomainConstants.SELECT_TYPE, TYPE_WMS_MEASUREMENT_TASK);
	        m.put(DomainConstants.SELECT_CURRENT, "Create");
	        mapListObjects = domWOObj.getRelatedObjects(context,
	            	                     	                    RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
																patternType.getPattern(),                                    // object pattern
																false,                                                        // to direction
																true,                                                       // from direction
																(short)3,                                                      // recursion level
																strListBusSelects,                                                 // object selects
																null,                                                         // relationship selects
																DomainConstants.EMPTY_STRING,                                // object where clause
																DomainConstants.EMPTY_STRING,                                // relationship where clause
																(short)0,                                                      // No expand limit
																DomainConstants.EMPTY_STRING,                                // postRelPattern
																null, // postTypePattern
																m); 
	        
	        Iterator<Map> itr=mapListObjects.iterator();
	        String[] sArrIds=new String[mapListObjects.size()];
	        int i=0;
	        List<String> lstTitle=new ArrayList<String>();
	        List<String> lstErrTitle=new ArrayList<String>();
	        String strRate=DomainConstants.EMPTY_STRING;
	        String strQty=DomainConstants.EMPTY_STRING;
	        String strTitle=DomainConstants.EMPTY_STRING;
	        boolean bError=false;
	        while(itr.hasNext()) {
	        	Map mNext = itr.next();
	        	strQty=(String)mNext.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"]");
	        	strRate=(String)mNext.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"]");
	        	strTitle=(String)mNext.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
	        	if(!sTypeOfContract.equalsIgnoreCase("EPC")) {
	        		if(Double.parseDouble(strRate)==0) 
	        			bError=true;
	 }
	        	if(Double.parseDouble(strQty)==0) 
	        		bError=true;
		 
	        	if(bError)  
	        		lstErrTitle.add(strTitle);
	           		lstTitle.add(strTitle);
	         	 
	        	sArrIds[i]=(String)mNext.get(DomainConstants.SELECT_ID);
	        	i++;
	 }
	
	        if(lstTitle.isEmpty())
	        	bError=true;
	         
	        mReturn.put("IsError", bError);
	        mReturn.put("Error", sTypeOfContract.equalsIgnoreCase("EPC") ? errEPC : errOther);
	        mReturn.put("ErrorList", lstErrTitle);
	        mReturn.put("ApprovalList", lstTitle);
	        mReturn.put("ApplicableIds", sArrIds);
	         return mReturn;
	}

	    /** Gets the parents of MeasutmentTasks
	     * 
	     * @param context
	     * @param lstTasks -Task Ids
	     * @return
	     * @throws Exception
	     */
	 private String getParentOfTask(Context context,String[] stTasks) throws Exception {
		   StringList slSelect=new StringList(2);
	  	   slSelect.add("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.id");
		   MapList mSegments= DomainObject.getInfo(context, stTasks, slSelect);
	       Iterator<Map> itr=mSegments.iterator();
	       List<String> lstTasks = new ArrayList<String>();
	       String strSegmentId=DomainConstants.EMPTY_STRING;
		   while(itr.hasNext()) {
		   Map m = (Map)itr.next();
		   strSegmentId=(String)m.get("to["+RELATIONSHIP_BILL_OF_QUANTITY+"].from.id");
		   if(!lstTasks.contains(strSegmentId)) {
			   lstTasks.add(strSegmentId);
		   }
 		 }
	 
	 	 	 return String.join(",", lstTasks);	 
	 }
	
	 
	 
	  /**
	     * Method is used to populate the data for Review status for BOQ send for Review
	     *
	     * @param context the eMatrix <code>Context</code> object
	     * @param args The packed argument for JPO, containing the program map.
	     *             This program map will have request parameter information, objectId and information about the UI table object.
	     * @return MapList of data
	     * @throws Exception
	     */
	    @com.matrixone.apps.framework.ui.ProgramCallable
	    public  MapList getBOQReviewInfo(Context context, String[] args) throws Exception {
			MapList mlInboxTask = new MapList();
	        try {
				Pattern includeType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
		         Map programMap = (Map) JPO.unpackArgs(args);
	            String strObjectId = (String)programMap.get("objectId");
		 		StringList objectList = new StringList();
				objectList.addElement(DomainConstants.SELECT_ID);
				objectList.addElement(DomainConstants.SELECT_TYPE);
				objectList.addElement(DomainConstants.SELECT_CURRENT);
				objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_FIRST_NAME+"]");
				objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.id");
				objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_LAST_NAME+"]");
				objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ROUTE_TASK_USER+"]");
				objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_APPROVAL_STATUS+"]");
				objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]");
				objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
		 		StringList relList = new StringList();
				relList.addElement(DomainRelationship.SELECT_ID);
				DomainObject dObject = DomainObject.newInstance(context,strObjectId);
				mlInboxTask = dObject.getRelatedObjects(context,
						DomainConstants.RELATIONSHIP_OBJECT_ROUTE+","+DomainConstants.RELATIONSHIP_ROUTE_TASK,  //String relPattern
						DomainConstants.TYPE_ROUTE+","+DomainConstants.TYPE_INBOX_TASK, //String typePattern
						objectList,            //StringList objectSelects,
						relList,    		   //StringList relationshipSelects,
						true,                  //boolean getTo,
						true,                  //boolean getFrom,
						(short)0,              //short recurseToLevel,
						"",   				   //String objectWhere,
						"",                    //String relationshipWhere,
						includeType, 		   //Pattern includeType,
						null,                  //Pattern includeRelationship,
						null);        
	 	 		
			} catch (Exception e){
			
	}
			return mlInboxTask;
		}
		 
	 
	
	}
