/*---------------------------------------------------------------------------------------------------------------
NAME		: ${CLASSNAME}.java

DESCRIPTION	: Purpose of JPO is to Create WOO and perform the utility operations on it

CREATED		: August 13 2019

AUTHOR		: Chandrakant M Sangashetty

HISTORY		:

	Chandrakant M Sangashetty	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.util.Calendar;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainAccess;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;

import matrix.db.Context;
import matrix.db.Policy;
import matrix.db.JPO;
import matrix.util.StringList;
import matrix.db.BusinessObject;

import com.matrixone.jdom.Element;
import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;

public class WMSWOO_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSWOO_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	/**
	* Method to get Realated RICChapters information on ProjectSpace
	*
	* @param context - the eMatrix <code>Context</code> object
	* @param args - args contains a Map with the following entries
	*                      objectId - Object Id of the Context object
	* @return - Maplist
	* @throws Exception if the operation fails
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedWOO(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
			MapList mlWOOList = new MapList();
			DomainObject domProject=DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
    		selects.add(DomainConstants.SELECT_CURRENT);
			
			String sWhere = "revision == last";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId))
            {
				domProject = DomainObject.newInstance(context, sObjectId);
    			String sSOCObjId = domProject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
				DomainObject domSOC = DomainObject.newInstance(context, sSOCObjId);
				mlWOOList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOC_WOO, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);	
				for(int i=0; i<mlWOOList.size(); i++) {
					Map oMap = (Map) mlWOOList.get(i);
					if (!STATE_WMSWOO_CREATE.equals((String)oMap.get(DomainConstants.SELECT_CURRENT))) {
						oMap.put("disableSelection", "true");
					}
				}
			
			}
			return mlWOOList;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@com.matrixone.apps.framework.ui.IncludeOIDProgramCallable
	public StringList getProjectMembersIncludeIDs(Context context, String[] args) throws Exception {
      
            Map programMap = (Map) JPO.unpackArgs(args);
			
            String ProjectObjectId = (String) programMap.get("rootObjectId");
            DomainObject ProjectObjId = DomainObject.newInstance(context);
            ProjectObjId.setId(ProjectObjectId);
            MapList memberList = ProjectObjId.getRelatedObjects(context,
                                DomainConstants.RELATIONSHIP_MEMBER,  //String relPattern
                                DomainConstants.TYPE_PERSON, //String typePattern
                                new StringList(DomainConstants.SELECT_ID),          //StringList objectSelects,
                                null,                     //StringList relationshipSelects,
                                true,                     //boolean getTo,
                                true,                     //boolean getFrom,
                                (short)1,                 //short recurseToLevel,
                                null,    //String objectWhere,
                                "",                       //String relationshipWhere,
                                0,              //Query Limit
                                null,                     //Pattern includeType,
                                null,                     //Pattern includeRelationship,
                                null);

            StringList ids = new StringList(memberList.size());
            for (int i = 0; i < memberList.size(); i++) {
                Map member = (Map) memberList.get(i);
                ids.add((String)member.get(DomainConstants.SELECT_ID));
            }
          return ids;
         
       }
	    public void updateRemarksOnAuthorized(Context context,String[] args)throws Exception{
		    HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            HashMap paramMap = (HashMap) programMap.get("paramMap");
			String AEId = (String) paramMap.get("objectId");
			String strApprovedDuration = (String)paramMap.get("New Value");
			DomainObject domAE = DomainObject.newInstance(context);
			if(UIUtil.isNotNullAndNotEmpty(AEId))
			{
				domAE = DomainObject.newInstance(context, AEId);
				
				String strRelId = domAE.getInfo(context,"from["+RELATIONSHIP_WMSAUTHORIZED+"].id");
				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
					DomainRelationship drelObj = DomainRelationship.newInstance(context,strRelId);
					ContextUtil.pushContext(context);
					drelObj.setAttributeValue(context,ATTRIBUTE_REMARKS,strApprovedDuration);
					ContextUtil.popContext(context);
				}
			}
	   }
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList expandWOO(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");	
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			DomainObject domObject = new DomainObject(sObjectId);
			String sType = domObject.getInfo(context, DomainConstants.SELECT_TYPE);
			if(TYPE_WMSWOO.equals(sType)) {
				String sSOCId = domObject.getInfo(context,"to["+RELATIONSHIP_WMSSOC_WOO+"].from.id");			
				domObject = new DomainObject(sSOCId);
			}
			String sWhere = "attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value!=Equipments";
			MapList mlAE =domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_APPROVEDAEMASTER+","+RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
													TYPE_WMSAEMASTER+","+TYPE_WMSAE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause*/
			for(int i=0; i<mlAE.size(); i++) {
				Map oMap = (Map) mlAE.get(i);
				oMap.put("disableSelection", "true");
			}
			mlAE.sort("originated", "ascending", "date");
			return mlAE;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	* This Method Connects User to WOO
	**/
	@com.matrixone.apps.framework.ui.CellUpdateJPOCallable
	public void connectUser(Context context,String args[]) throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramMap =  (HashMap)programMap.get("paramMap");
			
			String strObjectId =(String) paramMap.get("objectId");
			String strRTId =(String) paramMap.get("New Value");
			
			DomainObject doObject = new DomainObject(strObjectId);
			String sType = doObject.getInfo(context, DomainConstants.SELECT_TYPE);
			if (TYPE_WMSAE.equals(sType)) {
				String sObjRTConnectionId = doObject.getInfo(context, "from["+RELATIONSHIP_WMSAUTHORIZED+"].id");
				if (UIUtil.isNotNullAndNotEmpty(sObjRTConnectionId)) {				
					DomainRelationship.disconnect(context, sObjRTConnectionId);
				}
				DomainRelationship.connect(context, strObjectId, RELATIONSHIP_WMSAUTHORIZED, strRTId, false);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * Finds SO1 Works
	 * @param context
	 * @return
	 * @throws Exception
	 */
	public static StringList getSO1Works(Context context) throws Exception {
		StringList SO1WorksPersons = new StringList();
		String sSO1Works = EnoviaResourceBundle.getProperty(context, "WMS.HostRole.SO1Works");
		String SO1WorksPerson = DomainConstants.EMPTY_STRING;
		String whereExpression = "current == Active && attribute[HostPersonRole].value == \""+sSO1Works+"\"";
		StringList objectSelects =  new StringList();
		objectSelects.add(DomainConstants.SELECT_NAME);
		objectSelects.add(DomainConstants.SELECT_ID);
		Map map = new HashMap();
		MapList personMList = DomainObject.findObjects(context,DomainConstants.TYPE_PERSON,"*",whereExpression,objectSelects);
		if(personMList != null) {
			for (int i=0; i<personMList.size(); i++) {
				map = (Map) personMList.get(i);
				SO1WorksPerson = (String)map.get(DomainConstants.SELECT_NAME);
				SO1WorksPersons.add(SO1WorksPerson);
			}
		}
		return SO1WorksPersons;
	}
	
	/**
	* Method to create work operational order 
	*
	* @param context - the eMatrix <code>Context</code> object
	* @param args - args contains a Map with the following entries
	* objectId - Object Id of the Context object
	* @return - Maplist
	* @throws Exception if the operation fails
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public int createWorkOperationOrder(Context context,String args[]) throws Exception {
		    String sObjectId = args[0];
		    DomainObject sSOCObj = new DomainObject(sObjectId);
			StringList slObjects = sSOCObj.getInfoList(context, "from["+RELATIONSHIP_WMSSOC_WOO+"]to.id");			
			if (slObjects.size()>0){
				return 0;
			}
			
			String revision = "";
			revision = new Policy(POLICY_WMSWOO).getFirstInMinorSequence(context);
			StringList defaultOwners = getSO1Works(context);
			String defaultOwner = DomainConstants.EMPTY_STRING;
			String defaultProj = DomainConstants.EMPTY_STRING;
			String defaultOrg = DomainConstants.EMPTY_STRING;
			if (defaultOwners != null && defaultOwners.size() > 0) {
				defaultOwner = defaultOwners.get(0);
				defaultProj = PersonUtil.getDefaultProject(context, defaultOwner);
				defaultOrg = PersonUtil.getDefaultOrganization(context, defaultOwner);
				defaultOwners.remove(defaultOwner);
			}
			
			DomainObject domWoo = DomainObject.newInstance(context);
			String strTSName = DomainObject.getAutoGeneratedName(context, "type_WMSWOO", "");			
			domWoo.createObject(context,TYPE_WMSWOO, strTSName,revision,POLICY_WMSWOO, "eService Production");
			domWoo.setAttributeValue(context, ATTRIBUTE_TITLE, "WOO");		
			DomainRelationship domRelforSoc = DomainRelationship.connect(context, sSOCObj, RELATIONSHIP_WMSSOC_WOO, domWoo);
			domWoo.TransferOwnership(context, defaultOwner, defaultProj, defaultOrg);
			String busId = domWoo.getId(context);
			
			for(int i=0; i< defaultOwners.size(); i++) {
				String personId = PersonUtil.getPersonObjectID(context, defaultOwners.get(i));
				StringList accessNames = DomainAccess.getLogicalNames(context, busId);
				String defaultAccess = (String)accessNames.get(accessNames.size()-1);
				DomainAccess.createObjectOwnership(context, busId, personId, defaultAccess, DomainAccess.COMMENT_MULTIPLE_OWNERSHIP);
			}
			
		return 0;
	}
	
 
 
    public static int createApprovalRoute(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doDelObj = null;
			DomainObject dSOCObj = null;
			String strTemplateId ="";
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				doDelObj = new DomainObject(sObjectId);
				MapList socList = doDelObj.getRelatedObjects(context, RELATIONSHIP_WMSSOC_WOO, "*", selects, null, true, false, (short)0, null, null,0,null,null,null);
			    Map mSoc = (Map)socList.get(0);
				String sSocId =(String)mSoc.get("id");
				dSOCObj = new DomainObject(sSocId);
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doDelObj, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);					
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
				} else {
					
					String strPolicy = (String)doDelObj.getInfo(context,DomainConstants.SELECT_POLICY);
					String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"Work Operational Order\"";
					MapList routeMapList= dSOCObj.getRelatedObjects(context, RELATIONSHIP_WMS_SOC_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
					if(routeMapList != null && !routeMapList.isEmpty()){
						Map mRouteTemplateMap = (Map)routeMapList.get(0);
						strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
						String sRouteDescription = (String)doDelObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
						String sState = (String)doDelObj.getInfo(context, DomainConstants.SELECT_CURRENT);
						String strContectUser =  context.getUser();
						Map mRouteAttrib= new HashMap();
						mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
					   
						Map objectRouteAttributeMap=new HashMap();
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy,false ));
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Review");
						objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,"Review");
						Map reviewerInfo= new HashMap();
					   
						Route.createAndStartRouteFromTemplateAndReviewers(context,
										strTemplateId,
										sRouteDescription,
										strContectUser ,
										sObjectId,
										strPolicy,
										sState,
										mRouteAttrib,
										objectRouteAttributeMap,
										reviewerInfo,
										true);
					}
					
					}
			}
			return 0;

		}  catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}
	
	/**
    ** This Method check Edit Access to Add Authorized in WOO
    */
	@com.matrixone.apps.framework.ui.ColJPOCallable
    public static StringList isAuthorizedCellEditable(Context context, String[] args)throws Exception {
		try {
			StringList isCellEditable = new StringList();
    		Map programMap 		= (Map) JPO.unpackArgs(args);
    		MapList objectList 	= (MapList) programMap.get("objectList");
			for (int i = 0 ; i < objectList.size(); i++) {
				Map objMap = (Map) objectList.get(i);
				String sType = (String) objMap.get("type");
				if (TYPE_WMSAE.equals(sType)) {
					isCellEditable.add("true");
				} else {
					isCellEditable.add("false");
				}
			}
			return isCellEditable;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method Check Tool bar Visible or Not
    */	
	public static Boolean isUserSO1Works (Context context, String[] args) throws Exception {
		Boolean bReturn = false;
		try  {
			String strPersonId = PersonUtil.getPersonObjectID(context);
			DomainObject doPerson = new DomainObject(strPersonId);
			String sHostRole = doPerson.getAttributeValue(context, ATTRIBUTE_HOST_ROLE);
			String sSO1Works = EnoviaResourceBundle.getProperty(context, "WMS.HostRole.SO1Works");
			if (UIUtil.isNotNullAndNotEmpty(sHostRole) && UIUtil.isNotNullAndNotEmpty(sSO1Works) && sHostRole.equals(sSO1Works)) {
				bReturn = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return bReturn;
	}
	
	public static Boolean isUserWorksDepartment(Context context, String[] args) throws Exception {
		Boolean bReturn = false;
		try  {
			String defaultOrg = PersonUtil.getDefaultOrganization(context, context.getUser());
			String sWorks = EnoviaResourceBundle.getProperty(context, "WMS.WOO.Create.Department");
			StringList slWorks = FrameworkUtil.split(sWorks, ",");
			if (slWorks.contains(defaultOrg)) {
				bReturn = true;
			}
		} catch(Exception e) {
			e.printStackTrace();
			bReturn = false;
		}
		return bReturn;
	}
	
	
	
	public static void generateXLForWOO(Context context,String args[]) throws Exception
	{
		try{
		String sSOCId = args[0];
		String sWOOID = args[1];
		DomainObject ObjWOO = null;
		if(UIUtil.isNotNullAndNotEmpty(sSOCId)) {		
			DomainObject dObj = new DomainObject(sSOCId);
			
			//get WOO
			if(UIUtil.isNotNullAndNotEmpty(sWOOID)){
			ObjWOO = new DomainObject(sWOOID);
			}			
			String fileName = DomainConstants.EMPTY_STRING;			
			FileOutputStream outputStream = null;
			String strTempFolder = context.createWorkspace();
			StringList busSelects = new StringList();
				busSelects.add(DomainConstants.SELECT_ID);
				busSelects.add(DomainConstants.SELECT_DESCRIPTION);
				busSelects.add(DomainConstants.SELECT_OWNER);
				busSelects.add(DomainConstants.SELECT_ORIGINATED);
				busSelects.add("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
				busSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
				busSelects.add("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"].value");
				busSelects.add("attribute["+ATTRIBUTE_RATE+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSGST+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSAUTHORIZED+"].value");
				busSelects.add("attribute["+ATTRIBUTE_REMARKS+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSCONTINGENCY+"].value");
				busSelects.add("attribute["+ATTRIBUTE_WMSCONSULTANCY+"].value");
				ContextUtil.pushContext(context);
				MapList mlAE =dObj.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_APPROVEDAEMASTER+","+RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
													TYPE_WMSAEMASTER+","+TYPE_WMSAE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause*/
				mlAE.addSortKey("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value","ascending","String");
				mlAE.addSortKey(DomainConstants.SELECT_ORIGINATED,"ascending","date");
				mlAE.sort();
				if(mlAE != null && !mlAE.isEmpty()) {
					XSSFWorkbook workbook = new XSSFWorkbook();
					XSSFSheet sheetData = workbook.createSheet("Data");
					//String[] headerData = {"Sl No", "Level", "Sequence Number", "Type", "Title","Description", "Unit of Measure", "Quantity", "Rate", "Amount", "GST(%)", "Contingency(%)", "Consultancy(%)", "Total Amount", "Item Type", "Remarks", "Owner"};
					String[] headerData = {"Sequence Number", "Level", "Type", "Title","Description", "Unit of Measure", "Quantity", "Rate", "Amount", "GST(%)", "Contingency(%)", "Consultancy(%)", "Total Amount", "Item Type", "Remarks", "Owner"};
					CellStyle styleHeading = workbook.createCellStyle();
					styleHeading.setBorderLeft(CellStyle.ALIGN_CENTER);
					
					XSSFFont font= workbook.createFont();
					font.setFontHeightInPoints((short)10);
					font.setFontName("Arial");
					font.setColor(IndexedColors.WHITE.getIndex());
					font.setBold(true);
					styleHeading.setFont(font);
					//styleHeading.setFillForegroundColor(IndexedColors.DARK_TEAL.getIndex());
					styleHeading.setFillForegroundColor((short)30);
					styleHeading.setFillPattern(CellStyle.SOLID_FOREGROUND); 
					styleHeading.setBorderLeft(CellStyle.BORDER_THIN);
					styleHeading.setBorderRight(CellStyle.BORDER_THIN);
					styleHeading.setBorderTop(CellStyle.BORDER_THIN);
					styleHeading.setBorderBottom(CellStyle.BORDER_THIN);
					
					Row row = sheetData.createRow(0);
					for (int columnCount=0; columnCount < headerData.length; columnCount++) {
						Cell cell = row.createCell(columnCount);
						cell.setCellValue((String) headerData[columnCount]);
						cell.setCellStyle(styleHeading);
					}
					
					String[] cellData = new String[headerData.length];			
					Row rowData = null;
					int iSize = mlAE.size();
					Map mapObjectInfo = null;
					int iCountRow = 1;
					String sObjectId = DomainConstants.EMPTY_STRING;
					String sOwner = DomainConstants.EMPTY_STRING;
					DecimalFormat df = new DecimalFormat("0.00");
					for(int i=0; i<iSize; i++) {
						mapObjectInfo = (Map)mlAE.get(i);
						cellData[0] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
						cellData[1] = (String)mapObjectInfo.get(DomainConstants.SELECT_LEVEL); 
						cellData[3] = (String)mapObjectInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
						cellData[4] = (String)mapObjectInfo.get(DomainConstants.SELECT_DESCRIPTION);
						cellData[5] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
						cellData[6] = (String)mapObjectInfo.get("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"].value");
						cellData[7] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_RATE+"].value");
						cellData[9] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSGST+"].value");
						cellData[10] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSCONTINGENCY+"].value");
						cellData[11] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSCONSULTANCY+"].value");
						cellData[13] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSAUTHORIZED+"].value");
						cellData[14] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_REMARKS+"].value");
						
						sObjectId = (String)mapObjectInfo.get(DomainConstants.SELECT_ID);
						DomainObject doAEObject = new DomainObject(sObjectId);
						switch((String) mapObjectInfo.get(DomainConstants.SELECT_TYPE)) {
							case "WMSAEMaster" :
										cellData[2] = "Head";
										cellData[8] = String.valueOf(df.format(WMSUtil_mxJPO.getMasterAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM})));
										cellData[12] = String.valueOf(df.format(WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM})));
										ContextUtil.pushContext(context);
										doAEObject.setState(context, STATE_WMSAEMASTER_CREATE, true);
										ContextUtil.popContext(context);
										break;
							case "WMSAE" :
										cellData[2] = "Head";
										cellData[8] = String.valueOf(df.format(WMSUtil_mxJPO.getHeadAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM})));
										cellData[12] = String.valueOf(df.format(WMSUtil_mxJPO.getPart1HeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM})));
										ContextUtil.pushContext(context);
										doAEObject.setState(context, STATE_WMSAE_CREATE, true);
										ContextUtil.popContext(context);
										break;
							case "WMSAEItem" :
										cellData[2] = "Item";
										cellData[8] = String.valueOf(df.format(WMSUtil_mxJPO.getItemAmount(context, new String[]{sObjectId})));
										cellData[12] = String.valueOf(df.format(WMSUtil_mxJPO.getItemTotalAmount(context, new String[]{sObjectId})));
										/*ContextUtil.pushContext(context);
										doAEObject.deleteObject(context, true);
										ContextUtil.popContext(context);*/
										break;
							default :
										cellData[2] = DomainConstants.EMPTY_STRING;
										cellData[8] = "0.00";
										cellData[12] = "0.00";
						}
						
						sOwner = (String)mapObjectInfo.get(DomainConstants.SELECT_OWNER);
						if (("User Agent").equalsIgnoreCase(sOwner)) {
							cellData[15] = sOwner;
						} else {
							BusinessObject boPerson = new BusinessObject(DomainConstants.TYPE_PERSON, sOwner, "-", VAULT_ESERVICEPRODUCTION);
							DomainObject doPerson = new DomainObject(boPerson);
							cellData[15] = (String) doPerson.getAttributeValue(context, DomainConstants.ATTRIBUTE_FIRST_NAME) + " " + doPerson.getAttributeValue(context, DomainConstants.ATTRIBUTE_LAST_NAME);
						}
						
						rowData = sheetData.createRow(iCountRow);
						for (int columnCount=0; columnCount < headerData.length; columnCount++) {
							Cell cell = rowData.createCell(columnCount);
							cell.setCellValue((String) cellData[columnCount]);
						}
						iCountRow++;
						
					}
					fileName = "WOO" +"_"+Calendar.getInstance().getTimeInMillis();
					outputStream = new FileOutputStream(new File(strTempFolder+"/"+fileName+ ".xlsx"));
					workbook.write(outputStream);
			
					DomainObject doNewDoc = DomainObject.newInstance(context, DomainConstants.TYPE_DOCUMENT);
					doNewDoc.createObject(context, DomainConstants.TYPE_DOCUMENT, fileName, new Policy(DomainConstants.POLICY_DOCUMENT).getFirstInMinorSequence(context), DomainConstants.POLICY_DOCUMENT, VAULT_ESERVICEPRODUCTION);
						
					String sName = doNewDoc.getInfo(context,"id");
					doNewDoc.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, fileName);
					doNewDoc.checkinFile(context, true, true, "", DomainConstants.FORMAT_GENERIC, fileName+".xlsx", strTempFolder);
					DomainRelationship.connect(context, ObjWOO,RELATIONSHIP_WMSWOO_REVISE_REFERENCEDOCUMENT, doNewDoc);
					ContextUtil.popContext(context);
			
		}
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	* Method to get Related AE Revision History information on WOO
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getWOORevisionHistory(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList(2);
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			StringList relSelects = new StringList(1);
            relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlRevisionHistory = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSWOO_REVISE_REFERENCEDOCUMENT, // relationship pattern
													DomainConstants.QUERY_WILDCARD, // type pattern
													busSelects, // object selects
													relSelects, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause													
			return mlRevisionHistory;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	* Method to get Related RICChapters information on ProjectSpace
	*
	* @param context - the eMatrix <code>Context</code> object
	* @param args - args contains a Map with the following entries
	*                      objectId - Object Id of the Context object
	* @return - Maplist
	* @throws Exception if the operation fails
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getWOO(Context context,String args[]) throws Exception {
		try {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sObjectId = (String) programMap.get("objectId");
			MapList mlWOOList = new MapList();
			DomainObject domObject = DomainObject.newInstance(context);
			StringList selects = new StringList(1);
    		selects.add(DomainConstants.SELECT_ID);
			
			domObject = DomainObject.newInstance(context, sObjectId);
			String sSOCObjId = domObject.getInfo(context, "to["+RELATIONSHIP_WMSSOC_WOO+"].from.id");
				
			if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)) {
				DomainObject domSOC = DomainObject.newInstance(context, sSOCObjId);
				mlWOOList = domSOC.getRelatedObjects(context, RELATIONSHIP_WMSSOC_WOO, "*", selects, null, false, true, (short)0, null, null,0,null,null,null);
			}
			return mlWOOList;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
