/*
 *  emxDiscussion.java
 *
 * Copyright (c) 1992-2018 Dassault Systemes.
 *
 * All Rights Reserved.
 * This program contains proprietary and trade secret information of
 * MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
import matrix.db.*;
import matrix.util.StringList;

import java.lang.*;
import java.util.HashMap;
import java.util.Vector;

import com.matrixone.apps.common.Message;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;

/**
 * @version Common 10-0-0-0 - Copyright (c) 2002, MatrixOne, Inc.
 */
public class emxDiscussion_mxJPO extends emxDiscussionBase_mxJPO
{

    /**
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments
     * @throws Exception if the operation fails
     * @since Common 10.0.0.0
     * @grade 0
     */
    public emxDiscussion_mxJPO (Context context, String[] args)
        throws Exception
    {
     super(context, args);
	}
    
    
    
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  Object getDiscussionList(Context context, String[] args) throws Exception
    {
    	MapList list = new MapList();
        if (args.length == 0 )
        {
            throw new IllegalArgumentException();
        }
        HashMap paramMap = (HashMap)JPO.unpackArgs(args);
        String objectId = (String)paramMap.get("objectId");
        String strPolicy = PropertyUtil.getSchemaProperty(context,"policy_PrivateMessage");
        String strOwner = context.getUser();
        String roleEmployee =   PropertyUtil.getSchemaProperty ( context, "role_Employee" );
        boolean hasEmpRole =false;
        Vector assignments = new Vector();
        assignments = PersonUtil.getAssignments(context);
         if(assignments.contains(roleEmployee))
        {
             hasEmpRole= true;
        }
        // Till Here
        if(objectId.indexOf("~") != -1)
        {
            objectId = objectId.substring(0,objectId.indexOf("~"));
        }
        if(FrameworkUtil.isObjectId(context,objectId))
        {
            DomainObject messageHolder = DomainObject.newInstance(context,objectId);
            String threadId = messageHolder.getInfo(context, "from[Thread].to.id");
            if(UIUtil.isNotNullAndNotEmpty(threadId)) {
            	 messageHolder.setId(threadId);
            	 StringList objectSelects = new StringList();
                 objectSelects.add(SELECT_ID);
                 objectSelects.add(SELECT_OWNER);
                 objectSelects.add(SELECT_POLICY);
                 //String objectWhere = "((policy =="+"\""+DomainConstants.POLICY_MESSAGE+"\")||((policy =="+"\""+strPolicy+"\") && ("+ Boolean.valueOf(hasEmpRole) +" || (owner =="+"\""+strOwner+"\"))))";
                 String relPattern = RELATIONSHIP_MESSAGE+ "," + RELATIONSHIP_REPLY;
                 list = messageHolder.getRelatedObjects(context, relPattern, "*", objectSelects, (StringList)null, false, true, (short)1, DomainConstants.EMPTY_STRING, (String)null);
            }
        }
        return list;
    }
}
