//
// $Id: emxProjectSpace.java.rca 1.6 Wed Oct 22 16:21:26 2008 przemek Experimental przemek $ 
//
// emxProjectSpace.java
//
// Copyright (c) 2002-2018 Dassault Systemes.
// All Rights Reserved
// This program contains proprietary and trade secret information of
// MatrixOne, Inc.  Copyright notice is precautionary only and does
// not evidence any actual or intended publication of such program.
//
import matrix.db.*;
import java.util.Map;
import java.util.HashMap;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import matrix.db.Context;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;

/**
 * The <code>emxProjectSpace</code> class represents the Project Space JPO
 * functionality for the AEF type.
 *
 * @version AEF 10.0.SP4 - Copyright (c) 2002, MatrixOne, Inc.
 */
public class emxProjectSpace_mxJPO extends emxProjectSpaceBase_mxJPO
{

	public static final String RELATIONSHIP_WMS_PROJECT_SOC = PropertyUtil.getSchemaProperty("relationship_WMSProjectSOC");
	public static final String RELATIONSHIP_WMS_PROJECT_CODE_HEAD = PropertyUtil.getSchemaProperty("relationship_WMSProjectCodeHead");
    /**
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds no arguments
     * @throws Exception if the operation fails
     * @since AEF 10.0.SP4
     * @grade 0
     */
    public emxProjectSpace_mxJPO (Context context, String[] args)
        throws Exception
    {
      super(context, args);
    }

    /**
     * Constructs a new emxProjectSpace JPO object.
     *
     * @param context the eMatrix <code>Context</code> object
     * @param String the business object id
     * @throws Exception if the operation fails
     * @since AEF 10.0.SP4
     */
    public emxProjectSpace_mxJPO (String id)
        throws Exception
    {
        // Call the super constructor
        super(id);
    }
	
	
	/**
  	 * Updated project information
  	 * @param context - The eMatrix <code>Context</code> object. 
  	 * @param args holds information about object.
  	 * @throws Exception if operation fails.
  	 */
  	@com.matrixone.apps.framework.ui.PostProcessCallable  
  	public void createAndConnectProject(Context context,String[]args)throws Exception
  	{
  		//TODO
		//Added for WMS
		connectSOCInProject(context,args);
  	}
	
	/** 
     * Method will connect the SOC to project
     * @param args Packed program and request maps for the table
     * @throws Exception if the operation fails
     * @author DMS
     * @since 418
     */
 
   public void connectSOCInProject(Context context, String[] args) throws Exception {
         
       try {
           HashMap programMap              = (HashMap) JPO.unpackArgs(args);
           HashMap paramMap             = (HashMap)programMap.get("paramMap");
           HashMap requestMap           = (HashMap)programMap.get("requestMap");
           String strProjectID             = (String) paramMap.get("objectId");
           String strSOCOID     =(String) requestMap.get("SeachAssociatedSOCOID");
           String strCodeHeadID     =(String) requestMap.get("SearchAssociatedCodeHeadOID");
		   if(UIUtil.isNotNullAndNotEmpty(strSOCOID) && UIUtil.isNotNullAndNotEmpty(strProjectID))
           {
               DomainRelationship.connect(context,strProjectID , RELATIONSHIP_WMS_PROJECT_SOC,strSOCOID , true);
           }
		   if(UIUtil.isNotNullAndNotEmpty(strCodeHeadID) && UIUtil.isNotNullAndNotEmpty(strProjectID))
           {
               DomainRelationship.connect(context,strProjectID , RELATIONSHIP_WMS_PROJECT_CODE_HEAD,strCodeHeadID , true);
           }
       } catch (Exception exception) {
			exception.printStackTrace();
       }
    
   }
}
