/*---------------------------------------------------------------------------------------------------------------
NAME		: ${CLASSNAME}.java

DESCRIPTION	: Purpose of JPO to generate XML for Budget Planning Report through 

CREATED		: 12 Mar 2020

AUTHOR		: 

HISTORY		:

------------------------------------------------------------------------------------------------------------------*/

import java.math.RoundingMode;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringBufferInputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.io.*;
import java.util.Vector;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;

import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.util.XMLResourceDescriptor;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.jdom.transform.JDOMResult;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import matrix.db.Context;
import matrix.db.FileList;
import matrix.db.MQLCommand;
import matrix.db.RelationshipType;
import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringList;
import matrix.db.JPO;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.common.Person;
import java.time.LocalDateTime;


public class WMSBudgetPlanningReportBatch_mxJPO extends WMSConstants_mxJPO {
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSBudgetPlanningReportBatch_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}	
	
	public void getDetails (Context context, String args[])throws Exception{
		// Get all Person
		String strWhere = "current == Active";
		
		if(args.length>0){
			String strArgsPersonName = (String)args[0];
			strWhere = strWhere + " && name == '"+strArgsPersonName+"'";
		}
		StringList selectStmts = new StringList(2);
		selectStmts.add(DomainConstants.SELECT_ID);
		selectStmts.add(DomainConstants.SELECT_NAME);
		
		MapList mlPersonList = (MapList)DomainObject.findObjects(context,
																 DomainConstants.TYPE_PERSON,
																 DomainConstants.QUERY_WILDCARD,
																 strWhere,
																 selectStmts);
		Iterator itrPerson = mlPersonList.iterator();
		Person person = new Person();
		MapList projectList = new MapList();
		com.matrixone.apps.program.ProjectSpace project =
		(com.matrixone.apps.program.ProjectSpace) DomainObject.newInstance(context,DomainConstants.TYPE_PROJECT_SPACE, DomainConstants.PROGRAM);
		StringList busSelects = new StringList(2);
		busSelects.add(DomainConstants.SELECT_ID);
		busSelects.add(DomainConstants.SELECT_NAME);
		busSelects.add("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
		busSelects.add("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.name");
		StringList slProjectPersonList = new StringList();
		HashMap mpPersonCodeHead = new HashMap();
		HashMap mpPersonMap = new HashMap();
		HashMap mpCodeHeadProject = new HashMap();
		HashMap mpCodeHeadAttribute = new HashMap();
		HashMap mpProjectIdName = new HashMap();
		// get if person is Member of work order and then get project List
		while (itrPerson.hasNext())
		{
			Map mpPerson = (Map) itrPerson.next();
			String strPersonId = (String)mpPerson.get(DomainConstants.SELECT_ID); 
			String strPersonName = (String)mpPerson.get(DomainConstants.SELECT_NAME);
			person.setId(strPersonId);
			if (!mpPersonMap.containsKey(strPersonId))
			{
				mpPersonMap.put(strPersonId,strPersonName);
			}
			projectList = project.getUserProjects(context,
												  person,
												  busSelects,
												  null,
												  DomainConstants.EMPTY_STRING,
												  DomainConstants.EMPTY_STRING);
			StringList slProjectList = new StringList();
			for (int iProj = 0 ;iProj<projectList.size();iProj++)
			{
				Map mpProj = (Map) projectList.get(iProj);
				String strProjectId = (String) mpProj.get(DomainConstants.SELECT_ID);
				if (!slProjectList.contains(strProjectId))
				{
					slProjectList.add(strProjectId);
				}
			}
			
			MapList mlWOPerson = getWorkOrdersForPerson(context,strPersonId);
			for (int iWoP =0;iWoP<mlWOPerson.size() ; iWoP++)
			{
				Map mpWO = (Map) mlWOPerson.get(iWoP);
				String strWOProjectId = (String) mpWO.get(DomainConstants.SELECT_ID);
				if (!slProjectList.contains(strWOProjectId))
				{
					slProjectList.add(strWOProjectId);
					projectList.add(mpWO);
				}
					
			}
			if (projectList.size()>0)
			{
				if (!slProjectPersonList.contains(strPersonId)) {
					slProjectPersonList.add(strPersonId);
				}
				// unique list of Code heads for each person.
				Iterator itProj = projectList.iterator();
				while (itProj.hasNext())
				{
					Map mpProj =(Map) itProj.next();
					String strProjectId = (String)mpProj.get(DomainConstants.SELECT_ID); 
					String strProjectName = (String)mpProj.get(DomainConstants.SELECT_NAME);
					if (!mpProjectIdName.containsKey(strProjectId))
					{
						mpProjectIdName.put(strProjectId,strProjectName);
					}					
					String strCodeHeadName = (String)mpProj.get("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.name"); 
					String strCodeHead = (String)mpProj.get("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]"); 
					if (mpPersonCodeHead.containsKey(strPersonId))
					{
						String strValue = (String) mpPersonCodeHead.get(strPersonId);
						if (strValue.contains(strCodeHeadName) == false)
						{
							String NewValue = strValue + ","+ strCodeHeadName;
							mpPersonCodeHead.put(strPersonId,NewValue);
						}
					}else
					{
						mpPersonCodeHead.put(strPersonId,strCodeHeadName);
					}
					
					if (mpCodeHeadProject.containsKey(strCodeHeadName))
					{
						String strValue = (String) mpCodeHeadProject.get(strCodeHeadName);
						StringList slValues = FrameworkUtil.split(strValue,",");
						if (!slValues.contains(strProjectId)){
							
							String NewValue = strValue + ","+ strProjectId;
							mpCodeHeadProject.put(strCodeHeadName,NewValue);
						}
					}else
					{
						mpCodeHeadProject.put(strCodeHeadName,strProjectId);
					}
					mpCodeHeadAttribute.put(strCodeHeadName,strCodeHeadName);
					
				}
			}							
		}
		
		//Iterate each person
		for (int iPerson =0 ; iPerson <slProjectPersonList.size();iPerson++){
			String strPersonId = (String)slProjectPersonList.get(iPerson);
			generateXMLFile(context,args,strPersonId,mpPersonMap,mpPersonCodeHead,mpCodeHeadProject,mpCodeHeadAttribute,mpProjectIdName);
		
		}
	}
	
	public MapList getWorkOrdersForPerson(Context context, String strPersonId) throws Exception{
		MapList mlReturnList = new MapList();
		try{
			StringList busSelects = new StringList(2);
			StringList relSelects = new StringList(2);
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
			busSelects.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.id");
			busSelects.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
			busSelects.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.name");
			DomainObject doPerson = new DomainObject (strPersonId);
			MapList mlWOList = doPerson.getRelatedObjects(context,
														RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE,
														TYPE_WMS_WORK_ORDER,
														busSelects,
														relSelects,       // relationshipSelects
														false,      // getTo
														true,       // getFrom
														(short) 1,  // recurseToLevel
														null,// objectWhere
														null);
			Iterator itrWOP = mlWOList.iterator();
			while (itrWOP.hasNext())
			{
				HashMap hmWP = new HashMap();
				Map mpWOP =(Map) itrWOP.next();
				String strId = (String) mpWOP.get(DomainConstants.SELECT_ID);
				String strProjId = (String) mpWOP.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.id");
				String strProjName = (String) mpWOP.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
				String strCodeHeadAttr = (String) mpWOP.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
				String strCodeHeadName = (String) mpWOP.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.name");
				hmWP.put(DomainConstants.SELECT_ID,strProjId);
				hmWP.put(DomainConstants.SELECT_NAME,strProjName);
				hmWP.put(DomainConstants.SELECT_NAME,strProjName);
				hmWP.put("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.name",strCodeHeadName);
				hmWP.put("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]",strCodeHeadAttr);
				mlReturnList.add(hmWP);
			}
			
		}catch (Exception ex)
		{
			ex.printStackTrace();
		}
		return mlReturnList;
	}
	public void preGenerateXML(Context context ,String[] args) throws Exception
	{
		if (args.length>0)
		{
			Person person = new Person();
			String strPersonId = args[0];
			MapList projectList = new MapList();
			com.matrixone.apps.program.ProjectSpace project =
			(com.matrixone.apps.program.ProjectSpace) DomainObject.newInstance(context,DomainConstants.TYPE_PROJECT_SPACE, DomainConstants.PROGRAM);
			StringList busSelects = new StringList(2);
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
			busSelects.add("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.name");
			StringList slProjectPersonList = new StringList();
			HashMap mpPersonCodeHead = new HashMap();
			HashMap mpPersonMap = new HashMap();
			HashMap mpCodeHeadProject = new HashMap();
			HashMap mpCodeHeadAttribute = new HashMap();
			HashMap mpProjectIdName = new HashMap(); 
			DomainObject doPerson = DomainObject.newInstance(context,strPersonId);
			String strPersonName = (String)doPerson.getInfo(context,DomainConstants.SELECT_NAME); 
			person.setId(strPersonId);
			if (!mpPersonMap.containsKey(strPersonId))
			{
				mpPersonMap.put(strPersonId,strPersonName);
			}
			projectList = project.getUserProjects(context,
												  person,
												  busSelects,
												  null,
												  DomainConstants.EMPTY_STRING,
												  DomainConstants.EMPTY_STRING);
			StringList slProjectList = new StringList();
			for (int iProj = 0 ;iProj<projectList.size();iProj++)
			{
				Map mpProj = (Map) projectList.get(iProj);
				String strProjectId = (String) mpProj.get(DomainConstants.SELECT_ID);
				if (!slProjectList.contains(strProjectId))
				{
					slProjectList.add(strProjectId);
				}
			}
			
			MapList mlWOPerson = getWorkOrdersForPerson(context,strPersonId);
			for (int iWoP =0;iWoP<mlWOPerson.size() ; iWoP++)
			{
				Map mpWO = (Map) mlWOPerson.get(iWoP);
				String strWOProjectId = (String) mpWO.get(DomainConstants.SELECT_ID);
				if (!slProjectList.contains(strWOProjectId))
				{
					slProjectList.add(strWOProjectId);
					projectList.add(mpWO);
				}
					
			}
				
			if (projectList.size()>0)
			{
				// append list of project from workOrder
				
				
				if (!slProjectPersonList.contains(strPersonId)) {
					slProjectPersonList.add(strPersonId);
				}
				// unique list of Code heads for each person.
				Iterator itProj = projectList.iterator();
				while (itProj.hasNext())
				{
					Map mpProj =(Map) itProj.next();
					String strProjectId = (String)mpProj.get(DomainConstants.SELECT_ID); 
					String strProjectName = (String)mpProj.get(DomainConstants.SELECT_NAME);
					if (!mpProjectIdName.containsKey(strProjectId))
					{
						mpProjectIdName.put(strProjectId,strProjectName);
					}					
					String strCodeHeadName = (String)mpProj.get("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.name"); 
					String strCodeHead = (String)mpProj.get("from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]"); 
					if (mpPersonCodeHead.containsKey(strPersonId))
					{
						String strValue = (String) mpPersonCodeHead.get(strPersonId);
						String NewValue = strValue + ","+ strCodeHeadName;
						mpPersonCodeHead.put(strPersonId,NewValue);
					}else
					{
						mpPersonCodeHead.put(strPersonId,strCodeHeadName);
					}
					
					if (mpCodeHeadProject.containsKey(strCodeHeadName))
					{
						String strValue = (String) mpCodeHeadProject.get(strCodeHeadName);
						StringList slValues = FrameworkUtil.split(strValue,",");
						if (!slValues.contains(strProjectId)){
							
							String NewValue = strValue + ","+ strProjectId;
							mpCodeHeadProject.put(strCodeHeadName,NewValue);
						}
					}else
					{
						mpCodeHeadProject.put(strCodeHeadName,strProjectId);
					}
					mpCodeHeadAttribute.put(strCodeHeadName,strCodeHead);
					
				}
				generateXMLFile(context,args,strPersonId,mpPersonMap,mpPersonCodeHead,mpCodeHeadProject,mpCodeHeadAttribute,mpProjectIdName);
			}else {
				// check if he is member of WO
				//MapList ml = getWorkOrdersForPerson(context,strPersonId);
				//System.out.println("...ml...."+ml);
			}
		}		
		
		
	}
	
	public void generateXMLFile (Context context,String[] args,String strPersonId,HashMap mpPersonMap,HashMap mpPersonCodeHead,
	HashMap mpCodeHeadProject,HashMap mpCodeHeadAttribute,HashMap mpProjectIdName)throws Exception
	{
		try
		{
			String strUserName = (String)mpPersonMap.get(strPersonId);
			String strCodeHeadValuesforPerson = (String)mpPersonCodeHead.get(strPersonId);
			StringList slCodeHeadValuesforPerson = FrameworkUtil.split(strCodeHeadValuesforPerson,",");
			String strTransPath = context.createWorkspace();
			String xmlSourceFileName = strUserName+".xml";
			DecimalFormat df = new DecimalFormat("0.00");

			String xmlFilePath = strTransPath + File.separator+xmlSourceFileName;
			//System.out.println("...xmlFilePath..."+xmlFilePath);
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();

			DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
			Document document = documentBuilder.newDocument();
			Element root = document.createElement("root");
			
			document.appendChild(root);
			Element user = document.createElement("user");
			Element date = document.createElement("Date");
			
			root.appendChild(user);
			user.setAttribute("value",strUserName);
			root.appendChild(date);
			
			String strCFY = DomainConstants.EMPTY_STRING;
			LocalDateTime now = LocalDateTime.now();
			
			date.setAttribute("value",now.toString());
			int year = now.getYear();
			int month = now.getMonthValue();
			int prevMonth = month-1;
			if(month>3){
				strCFY = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strCFY = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			
			String strNFY = DomainConstants.EMPTY_STRING;
			if(month>3){
					strNFY = String.valueOf(year+1)+"-"+String.valueOf(year+2);	
			}else{				
				strNFY = String.valueOf(year)+"-"+String.valueOf(year+1);
			}
			
			String strPFY = DomainConstants.EMPTY_STRING;
			if(month>3){
					strPFY = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}else{				
				strPFY = String.valueOf(year-2)+"-"+String.valueOf(year-1);
			}
			
			for (int iCode=0;iCode <slCodeHeadValuesforPerson.size();iCode++)
			{
				String strCodeHead = (String) slCodeHeadValuesforPerson.get(iCode);
				String strCodeHeadAttr = (String)mpCodeHeadAttribute.get(strCodeHead);
				Element codehead = document.createElement("codehead");
				root.appendChild(codehead);
				codehead.setAttribute("value",strCodeHeadAttr);
				
				String strProjectUnderCodeHead = (String)mpCodeHeadProject.get(strCodeHead);
				StringList slProjectUnderCodeHead = FrameworkUtil.split(strProjectUnderCodeHead,",");
				for (int iProj = 0 ;iProj <slProjectUnderCodeHead.size();iProj++)
				{
					String strProjId = (String) slProjectUnderCodeHead.get(iProj);
					String strProjectName = (String)mpProjectIdName.get(strProjId);
					// get All Budget planning  for Project
					MapList mlBudgetPlans = getBudgetPlanning(context,strProjId);
					MapList mlWorksWO = getProjectWorkorders(context,strProjId);
					//System.out.println("...mlBudgetPlans..."+mlBudgetPlans);
					Element project = document.createElement("project");
					codehead.appendChild(project);
					project.setAttribute("value",strProjectName);
					
					// childern tags under project
					
					Element ExpPFY = document.createElement("Exp-Upto-PFY");
					Element alltSOBT = document.createElement("Allotments-SOBT");
					Element expPMCFY = document.createElement("Exp-Upto-Prev-Mon-CFY");
					Element expCMCFY = document.createElement("Exp-during-Current-Mon-CFY");
					Element perExp = document.createElement("Per-Expdr");
					
					project.appendChild(ExpPFY);					
					String strExpPFY = getExpUptoPFY(context, args,mlWorksWO,strPFY);
					ExpPFY.setAttribute("value",strExpPFY);
					
					project.appendChild(alltSOBT);
					String strAllotment = getAllotment(context,args,mlWorksWO);
					alltSOBT.setAttribute("value",strAllotment);
					
					project.appendChild(expPMCFY);
					String strExpPMCFY = getExpCMCFY(context, args,mlWorksWO,strCFY,month,"Previous");
					expPMCFY.setAttribute("value",strExpPMCFY);
					
					project.appendChild(expCMCFY);
					String strExpCMCFY = getExpCMCFY(context, args,mlWorksWO,strCFY,month,"currentMonth");
					expCMCFY.setAttribute("value",strExpCMCFY);
					
					project.appendChild(perExp);
					String strPerExp = "0.0";
					if(UIUtil.isNotNullAndNotEmpty(strAllotment) && Double.valueOf(strAllotment)>0){
						strPerExp = String.valueOf(df.format((((Double.valueOf(strExpPFY) + Double.valueOf(strExpPMCFY) + Double.valueOf(strExpCMCFY))*100)/Double.valueOf(strAllotment))));
					}
					perExp.setAttribute("value",strPerExp);
					
					// Month details
					String strReportTypes = EnoviaResourceBundle.getProperty(context, "WMS.BudgetPlanningReport.Types");
					String strReportMonths = EnoviaResourceBundle.getProperty(context, "WMS.BudgetPlanningReport.Months");
					StringList slReportTypes = FrameworkUtil.split(strReportTypes,",");
					StringList slReportMonths = FrameworkUtil.split(strReportMonths,",");
					Double dTypeTotal = 0.0;
					String  strYear = DomainConstants.EMPTY_STRING;
					for (int iType =0 ;iType<slReportTypes.size();iType++)
					{	
						dTypeTotal = 0.0;
						
						String strTypeName = (String)slReportTypes.get(iType);
						String strPlanningType = DomainConstants.EMPTY_STRING;
						if (strTypeName.equals("RE"))
						{
							strPlanningType = "Revised Estimate";
							strYear = strCFY;
						}else if (strTypeName.equals("PRE")){
							strPlanningType = "Preliminary Revised Estimate";
							strYear = strCFY;
						}else if (strTypeName.equals("MA"))
						{
							strPlanningType = "Modified Appropriation Report";
							strYear = strCFY;
						}
						else if (strTypeName.equals("FE"))
						{
							strPlanningType = "Forecast Estimate";
							strYear = strNFY;
						}
						else if (strTypeName.equals("BE"))
						{
							strPlanningType = "Budget Estimate";
							strYear = strNFY;
						}
						
						Iterator itrBudgetPlan = mlBudgetPlans.iterator();
						while (itrBudgetPlan.hasNext())
						{
							Map mpBudgetPlan = (Map) itrBudgetPlan.next();
							String strBudgetPlanType = (String) mpBudgetPlan.get("attribute["+ATTRIBUTE_WMS_TYPE_OF_PLANNING+"]");
							String strPlanningYear = (String) mpBudgetPlan.get("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
							if (strBudgetPlanType.equals(strPlanningType))
							{
								for (int iMonth =0 ;iMonth<slReportMonths.size();iMonth++)
								{
									String strMonthName = (String)slReportMonths.get(iMonth);
									String strElementName = strTypeName + "-" + strMonthName;
									Element fieldName = document.createElement(strElementName);
									project.appendChild(fieldName);
									
									//value
									strMonthName = "WMS"+strMonthName;
									String strMonthValue = "0.0";									
									if (strPlanningYear.equals(strYear))
									{
										strMonthValue = (String) mpBudgetPlan.get("attribute["+strMonthName+"]");
									}
									fieldName.setAttribute("value",strMonthValue);
									dTypeTotal = dTypeTotal + Double.valueOf(strMonthValue);
								}
							}
						}						
						Element typeTotal = document.createElement(strTypeName+"-Total");
						project.appendChild(typeTotal);
						typeTotal.setAttribute("value" ,String.valueOf(dTypeTotal));
						
						String strDepts = EnoviaResourceBundle.getProperty(context, "WMS.Departments");
						StringList slDepts = FrameworkUtil.split(strDepts,",");
						for (int iDept=0;iDept<slDepts.size();iDept++)
						{
							String strDept = (String) slDepts.get(iDept);							
							String strDeptType = DomainConstants.EMPTY_STRING;
							if (strDept.equals("Works"))
							{
								strDeptType = "Wks";
							}else if (strDept.equals("Equipments"))
							{
								strDeptType = "Eqpt";
							}else if (strDept.equals("Planning"))
							{
								strDeptType = "Plg";
							}
							
							String strElementName = strTypeName + "-Total-" + strDeptType;
							Element fieldName = document.createElement(strElementName);
							
							project.appendChild(fieldName);
							Double dWOTotal = 0.0;
							Iterator itrWO = mlWorksWO.iterator();							
							while (itrWO.hasNext())
							{
								Map mpWO = (Map) itrWO.next();
								String strWOId = (String) mpWO.get(DomainConstants.SELECT_ID);
								String strWODept = (String) mpWO.get("attribute["+ATTRIBUTE_WMSDEPARTMENT+"]");
								//dWOTotal = 0.0;
								if (strWODept.equals(strDept))
								{
									MapList mlWOBudgetPlans = getBudgetPlanning(context,strWOId);
									Iterator itrWOBudgetPlan = mlWOBudgetPlans.iterator();								
									while (itrWOBudgetPlan.hasNext())
									{
										Map mpWOBudgetPlan = (Map) itrWOBudgetPlan.next();
										String strWOBudgetPlanType = (String) mpWOBudgetPlan.get("attribute["+ATTRIBUTE_WMS_TYPE_OF_PLANNING+"]");
										if (strWOBudgetPlanType.equals(strPlanningType))
										{
											for (int iMonth =0 ;iMonth<slReportMonths.size();iMonth++)
											{
												String strMonthName = (String)slReportMonths.get(iMonth);
												strMonthName = "WMS"+strMonthName;																				
												String strMonthValue = (String) mpWOBudgetPlan.get("attribute["+strMonthName+"]");
												dWOTotal = dWOTotal + Double.valueOf(strMonthValue);
											}																				
										}
									}
								}
																
							}
							fieldName.setAttribute("value",String.valueOf(dWOTotal));							
						}												
					}																
				}	
			}
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domSource = new DOMSource(document);
			StreamResult streamResult = new StreamResult(new File(xmlFilePath));
			transformer.transform(domSource, streamResult);
			DomainObject doPerson = new DomainObject (strPersonId);
			doPerson.checkinFile(context, true, true, "", DomainConstants.FORMAT_GENERIC, xmlSourceFileName, strTransPath);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			throw ex;
			
		}
	}
	
	
	/***
	 wo ->Abstrctbill -->Approved and Paid (Sum) (2018 -19 )
	*/
	
	public String getAllotment(Context context , String[] args, MapList mlWorkOrders) throws Exception{
		
		Iterator itrWO = mlWorkOrders.iterator();
		Double dFundRequested = 0.0;
		Double dFundReleased= 0.0;
		while (itrWO.hasNext())
		{
			Map mpWO = (Map) itrWO.next();
			String strWOId = (String) mpWO.get(DomainConstants.SELECT_ID);
			String strFunRequest = getWOFundDetails(context,strWOId,TYPE_WMS_FUND_REQUEST,RELATIONSHIP_WMS_WO_FUND_REQUEST, "");
			if (UIUtil.isNotNullAndNotEmpty(strFunRequest))
			{
				dFundRequested = dFundRequested + Double.valueOf(strFunRequest);
			}
			String strFunRelease = getWOFundDetails(context,strWOId,TYPE_WMS_FUND_RELEASE,RELATIONSHIP_WMS_WO_FUND_RELEASE, "current == Approved");								
			if (UIUtil.isNotNullAndNotEmpty(strFunRelease))
			{
				dFundReleased = dFundReleased + Double.valueOf(strFunRelease);
			}
		}
		String strAllotment = String.valueOf(dFundRequested - dFundReleased);
		return strAllotment;
	}
	
	public String getWOFundDetails(Context context, String strObjectId,String strType,String strRelType , String strWhere) throws Exception {
	
		String strReturnValue = "0.0";
        try
        {
			MapList mlWOFunddetails = new MapList();
			Double dFundAmt = 0.0;
            StringList slObjectSelects = new StringList(1);
			slObjectSelects.add(DomainConstants.SELECT_ID);
			slObjectSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
				
			StringList relSelect = new StringList();
			relSelect.add(DomainRelationship.SELECT_ID);
			
			DomainObject domObj = DomainObject.newInstance(context, strObjectId);
			mlWOFunddetails = domObj.getRelatedObjects(context,
														strRelType,
														strType,
														slObjectSelects,
														relSelect,       // relationshipSelects
														false,      // getTo
														true,       // getFrom
														(short) 1,  // recurseToLevel
														strWhere,// objectWhere
														null);
			Iterator itrWOFund = mlWOFunddetails.iterator();
			while (itrWOFund.hasNext())
			{
				Map mpMBE = (Map) itrWOFund.next();
				String strFundAmt= (String) mpMBE.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
				if (UIUtil.isNotNullAndNotEmpty(strFundAmt))
				{
					dFundAmt = dFundAmt + Double.valueOf(strFundAmt);
				}
			}
			strReturnValue = String.valueOf(dFundAmt);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return strReturnValue;
		
		
	}
	
	public String getExpCMCFY(Context context , String[] args, MapList mlWorkOrders,String strCFY,int month,String strMode) throws Exception{
		
		Iterator itrWO = mlWorkOrders.iterator();
		Double dExpPFY = 0.0;
		while (itrWO.hasNext())
		{
			Map mpWO = (Map) itrWO.next();
			String strWOId = (String) mpWO.get(DomainConstants.SELECT_ID);
			MapList mlMBE = getWOAbstractMBE(context,strWOId,strCFY);
			Iterator itrMBE = mlMBE.iterator();
			while (itrMBE.hasNext())
			{
				Map mpMBE = (Map) itrMBE.next();
				String strCertAmt= (String) mpMBE.get("attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"]");
				String strAttrMonth = (String) mpMBE.get("attribute["+ATTRIBUTE_WMS_MONTH+"]");
				if (strMode.equals("currentMonth") && month == Integer.valueOf(strAttrMonth))
				{
					dExpPFY = dExpPFY + Double.valueOf(strCertAmt);
				}else if (month != Integer.valueOf(strAttrMonth))
				{
					dExpPFY = dExpPFY + Double.valueOf(strCertAmt);
				}				
			}			
		}		
		return String.valueOf(dExpPFY);
	}
	/***
	 wo ->Abstrctbill -->Approved and Paid (Sum) (2018 -19 )
	*/
	
	public String getExpUptoPFY(Context context , String[] args, MapList mlWorkOrders,String strPFY) throws Exception{
		
		Iterator itrWO = mlWorkOrders.iterator();
		Double dExpPFY = 0.0;
		while (itrWO.hasNext())
		{
			Map mpWO = (Map) itrWO.next();
			String strWOId = (String) mpWO.get(DomainConstants.SELECT_ID);
			MapList mlMBE = getWOAbstractMBE(context,strWOId,strPFY);
			Iterator itrMBE = mlMBE.iterator();
			while (itrMBE.hasNext())
			{
				Map mpMBE = (Map) itrMBE.next();
				String strAttrInvAmt = (String) mpMBE.get("attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"]");
				if (UIUtil.isNotNullAndNotEmpty(strAttrInvAmt))
				{
					dExpPFY = dExpPFY + Double.valueOf(strAttrInvAmt);
				}				
			}			
		}		
		return String.valueOf(dExpPFY);
	}
	
	public MapList getWOAbstractMBE(Context context, String strObjectId,String strPFY) throws Exception {
	
		MapList mlWOAbstractMBE = new MapList();
        try
        {

            StringList slObjectSelects = new StringList(1);
			slObjectSelects.add(DomainConstants.SELECT_ID);
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_MONTH+"]");
				
			StringList relSelect = new StringList();
			relSelect.add(DomainRelationship.SELECT_ID);
			//String strWhere = "attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"] == '"+strPFY+"'";
			String strWhere = "((current == "+STATE_PLAN+" || current == "+STATE_APPROVED+") && (attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"] == '"+strPFY+"'))";
			
			DomainObject domObj = DomainObject.newInstance(context, strObjectId);
			mlWOAbstractMBE = domObj.getRelatedObjects(context,
														RELATIONSHIP_WORKORDER_ABSTRACT_MBE,
														TYPE_ABSTRACT_MBE,
														slObjectSelects,
														relSelect,       // relationshipSelects
														false,      // getTo
														true,       // getFrom
														(short) 1,  // recurseToLevel
														strWhere,// objectWhere
														null);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlWOAbstractMBE;
		
		
	}
	
	public MapList getProjectWorkorders(Context context, String strProjectId) throws Exception {
	
		MapList mlWorkOrders = new MapList();
        try
        {

            StringList slObjectSelects = new StringList(1);
			slObjectSelects.add(DomainConstants.SELECT_ID);
			slObjectSelects.add("attribute["+ATTRIBUTE_WMSDEPARTMENT+"]");
				
			StringList relSelect = new StringList();
			relSelect.add(DomainRelationship.SELECT_ID);
			String strWhere = "current != Create";
			
			DomainObject domObj = DomainObject.newInstance(context, strProjectId);
			mlWorkOrders = domObj.getRelatedObjects(context,
														RELATIONSHIP_WMS_PORJECT_WORK_ORDER,
														TYPE_WMS_WORK_ORDER,
														slObjectSelects,
														relSelect,       // relationshipSelects
														false,      // getTo
														true,       // getFrom
														(short) 1,  // recurseToLevel
														strWhere,// objectWhere
														null);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlWorkOrders;
		
		
	}
    public  MapList getBudgetPlanning(Context context, String strProjectId) throws Exception {
		MapList mlBudgetPlans = new MapList();
        try
        {
			// get current financial year
			
			
			
            StringList slObjectSelects = new StringList(17);
			slObjectSelects.add(DomainConstants.SELECT_ID);
			slObjectSelects.add(DomainObject.SELECT_OWNER);
			slObjectSelects.add(DomainObject.SELECT_CURRENT);
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_PLANNING_YEAR+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_JAN+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_FEB+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_MAR+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_APR+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_MAY+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_JUN+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_JUL+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_AUG+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_SEP+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_OCT+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_NOV+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_DEC+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_TYPE_OF_PLANNING+"]");
			slObjectSelects.add("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
				
			StringList relSelect = new StringList();
			relSelect.add(DomainRelationship.SELECT_ID);
			
			//String strWhere = "attribute["+ATTRIBUTE_WMS_PLANNING_YEAR+"] == \""+strYear+"\"";
			//System.out.println("...strWhere.."+strWhere);
			DomainObject domProj = DomainObject.newInstance(context, strProjectId);
			mlBudgetPlans = domProj.getRelatedObjects(context,
														RELATIONSHIP_WMS_BUDGET_PLANNING,
														TYPE_WMS_BUDGET_PLANNING,
														slObjectSelects,
														relSelect,       // relationshipSelects
														false,      // getTo
														true,       // getFrom
														(short) 1,  // recurseToLevel
														"current==Frozen",// objectWhere
														null);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlBudgetPlans;
	}
	
 }
 