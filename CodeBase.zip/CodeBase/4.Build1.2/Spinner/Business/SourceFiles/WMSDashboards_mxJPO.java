/** Name of the JPO    : WMSDashboards
 ** Developed by    :  
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to update/get data for dashboards.
 ** Revision Log:
 ** ---------------------------------------------------------------------------------------------------------------
 ** Author						Modified Date				History
 ** azr2						24th March, 19				add method to get cost details of work order
 ** ---------------------------------------------------------------------------------------------------------------
 ** ---------------------------------------------------------------------------------------------------------------
 **/

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.Date;
import java.util.Locale;
import java.text.SimpleDateFormat;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

/**
 * The purpose of this JPO is to update/get data for dashboards.
 * @author azr2
 */
public class WMSDashboards_mxJPO
{
	/**
	* Main entry point.
	*
	* @param context
	*		the eMatrix <code>Context</code> object
	* @param args
	*		holds no arguments
	* @return an integer status code (0 = success)
	* @throws Exception
	*		if the operation fails
	* @since 418
	*/
	public int mxMain(Context context, String[] args) throws Exception {
		if (!context.isConnected())
			throw new Exception("Not supported on desktop client");
		return 0;
	}

	/**
	*
	* @param context
	*		the eMatrix <code>Context</code> object
	* @param args
	*		holds 1 argument - obj id of work order
	* @return HashMap
	* @throws Exception
	*		if the operation fails
	*/
	public HashMap getWorkOrderCostDetails(Context context,String[] args) throws Exception
	{
		//get work order object id
		String strWorkOrderId = args[0];
		HashMap hmReturnMap = new HashMap();

		//prepare object selectables
		StringList slObj = new StringList();
		slObj.addElement("id");
		slObj.addElement("name");
		slObj.addElement("type");
		slObj.addElement("description");
		slObj.addElement("attribute[WMSPONumber]");
		slObj.addElement("attribute[WMSValueOfContract]");

		//get details of work order
		DomainObject doWorkOrder = DomainObject.newInstance(context, strWorkOrderId);
		Map mWorkOrderDetails = (Map)doWorkOrder.getInfo(context, slObj);

		//add work order details to return list
		hmReturnMap.put("objectid", (String)mWorkOrderDetails.get("id"));
		String strValueOfContract = (String)mWorkOrderDetails.get("attribute[WMSValueOfContract]");
		hmReturnMap.put("valueofcontract", strValueOfContract);

		//get details of related objects
		slObj = new StringList();
		slObj.addElement("current");
		//bill selects
		slObj.addElement("attribute[WMSCertifiedAmount]");
		//advance recovery selects
		slObj.addElement("attribute[WMSAdvanceAmount]");
		slObj.addElement("attribute[WMSRecoveryAmount]");
		//retention release selects
		slObj.addElement("attribute[WMSRetensionAmount]");
		slObj.addElement("attribute[WMSRetentionRecoveryAmount]");
		//withheld release selects 
		slObj.addElement("attribute[WMSBillReductionAmount]");
		slObj.addElement("attribute[WMSBillReductionReleaseAmountTillDate]");

		MapList mlRelatedItemsDetails = doWorkOrder.getRelatedObjects(context,
																		"WMSWOAbstractMBE,WMSWorkOrderAdvances,WMSWorkOrderRetentionRecovery,WMSWorkOrderReduction",  //String relPattern
																		"WMSAbstractMeasurementBookEntry,WMSAdvanceRecoveryItem,WMSRetentionRecoveryItem,WMSBillReductionItem", //String typePattern
																		slObj,
																		null,
																		false,
																		true,
																		(short)1,
																		DomainConstants.EMPTY_STRING,
																		DomainConstants.EMPTY_STRING,
																		null,
																		null,
																		null);

			//add details of related items
			int iSize = mlRelatedItemsDetails.size();

			double dTotalAdvances = 0.0;
			double dTotalRecoveries = 0.0;
			double dTotalRetentions = 0.0;
			double dTotalRetentionReleases = 0.0;
			double dTotalWithheld = 0.0;
			double dTotalWithheldReleases = 0.0;
			double dTotalAmountPaid = 0.0;
			double dTotalAmountInReview = 0.0;

			String strType = DomainConstants.EMPTY_STRING;
			for (int i = 0 ; i < iSize ; i++)
			{
				strType = (String)((Map)mlRelatedItemsDetails.get(i)).get("type");
				//get details from Bill
				if("WMSAbstractMeasurementBookEntry".equals(strType))
				{
					if ("Review".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
					{
						dTotalAmountInReview += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
					}
					else if ("Approved".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
					{
						dTotalAmountPaid += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
					}
				}
				//get details of advances and recoveries
				else if ("WMSAdvanceRecoveryItem".equals(strType))
				{
					dTotalAdvances += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdvanceAmount]"));
					dTotalRecoveries += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRecoveryAmount]"));
				}
				//get details of retentions and recoveries
				else if ("WMSRetentionRecoveryItem".equals(strType))
				{
					dTotalRetentions += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetensionAmount]"));
					dTotalRetentionReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetentionRecoveryAmount]"));
				}
				//get details of withheld releases
				else if ("WMSBillReductionItem".equals(strType))
				{
					dTotalWithheld += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionAmount]"));
					dTotalWithheldReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionReleaseAmountTillDate]"));
				}
			}

			//add details to return map & maplist
			hmReturnMap.put("dTotalAdvances", Math.round(dTotalAdvances));
			hmReturnMap.put("dTotalRecoveries", Math.round(dTotalRecoveries));
			hmReturnMap.put("dTotalRetentions", Math.round(dTotalRetentions));
			hmReturnMap.put("dTotalRetentionReleases", Math.round(dTotalRetentionReleases));
			hmReturnMap.put("dTotalWithheld", Math.round(dTotalWithheld));
			hmReturnMap.put("dTotalWithheldReleases", Math.round(dTotalWithheldReleases));
			hmReturnMap.put("dTotalAmountPaid", Math.round(dTotalAmountPaid));
			hmReturnMap.put("dTotalAmountInReview", Math.round(dTotalAmountInReview));
			hmReturnMap.put("financialprogress", Math.round((dTotalAmountPaid/Double.parseDouble(strValueOfContract))*100));

			return hmReturnMap;
	}
	
	/**
	*
	* @param context
	*		the eMatrix <code>Context</code> object
	* @param args
	*		holds 1 argument - obj id of work order
	* @return HashMap
	* @throws Exception
	*		if the operation fails
	*/
	public HashMap getProjectCostDetails(Context context,String[] args) throws Exception
	{
		//get project object id
		String strProjectId = args[0];
		HashMap hmReturnMap = new HashMap();

		//prepare object selectables
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("type");
		slObjSelects.addElement("description");
		slObjSelects.addElement("organization");
		slObjSelects.addElement("attribute[WMSAdminApprovalAmount]");
		slObjSelects.addElement("attribute[WMSApprovedAmountWork]");
		slObjSelects.addElement("attribute[WMSWorksContingency]");
		slObjSelects.addElement("attribute[WMSApprovedAmountEquipment]");
		slObjSelects.addElement("attribute[WMSEquipmentsContingency]");
		slObjSelects.addElement("attribute[WMSPlanningContingency]");
		slObjSelects.addElement("attribute[WMSCertifiedAmount]");
		
		//get details of related objects
		DomainObject doProject = DomainObject.newInstance(context, strProjectId);
		MapList mlRelatedItemsDetails = doProject.getRelatedObjects(context, 
																		"WMSProjectSOC,WMSSOCAdminApproval,WMSSOCDelegation,WMSProjectWorkOrder,WMSWOAbstractMBE",  //String relPattern
																		"WMSSOC,WMSAdminApproval,WMSDelegation,WMSWorkOrder,WMSAbstractMeasurementBookEntry", //String typePattern
																		slObjSelects,
																		null,
																		false,
																		true,
																		(short)0,
																		"revision==last",
																		DomainConstants.EMPTY_STRING,
																		null,
																		null,
																		null);
			//add details of related items
			int iSize = mlRelatedItemsDetails.size();

			String strAdminApproval = DomainConstants.EMPTY_STRING;
			String strTotalWorks = DomainConstants.EMPTY_STRING;
			String strTotalEquipment = DomainConstants.EMPTY_STRING;
			String strTotalPlanning = DomainConstants.EMPTY_STRING;
			double dTotalConsumedWorks=0.0;
			double dTotalConsumedEquipment=0.0;

			String strType = DomainConstants.EMPTY_STRING;
			String organzationType=DomainConstants.EMPTY_STRING;

			for (int i = 0 ; i < iSize ; i++)
			{
				strType = (String)((Map)mlRelatedItemsDetails.get(i)).get("type");
				organzationType =(String)((Map)mlRelatedItemsDetails.get(i)).get("organization");
				//get details of admin approval
				if("WMSAdminApproval".equals(strType))
				{
					strAdminApproval = WMSUtil_mxJPO.converToIndianCurrency(context, Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdminApprovalAmount]")));
				}
				//get details of delegation
				else if ("WMSDelegation".equals(strType))
				{
					strTotalWorks = WMSUtil_mxJPO.converToIndianCurrency(context, Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSApprovedAmountWork]")) + Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSWorksContingency]")));
					
					strTotalEquipment = WMSUtil_mxJPO.converToIndianCurrency(context, Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSApprovedAmountEquipment]")) + Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSEquipmentsContingency]")));
					
					strTotalPlanning = WMSUtil_mxJPO.converToIndianCurrency(context, Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSPlanningContingency]")));
				}
				//get details of the consumed amount Works
				else if("WMSAbstractMeasurementBookEntry".equals(strType) && "Works_V".equals(organzationType))
				{	
					dTotalConsumedWorks += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
			   	}
				//get  details of the consumed amount Equipments
				else if("WMSAbstractMeasurementBookEntry".equals(strType) && "Equipments_V".equals(organzationType))
				{
					dTotalConsumedEquipment += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));

			    	}
			}
			String strTotalConsumedWorks = WMSUtil_mxJPO.converToIndianCurrency(context, dTotalConsumedWorks);
			String strTotalConsumedEquipment = WMSUtil_mxJPO.converToIndianCurrency(context, dTotalConsumedEquipment);

			//add details to return map & maplist
			hmReturnMap.put("dAdminApproval", strAdminApproval);
			hmReturnMap.put("dTotalWorks", strTotalWorks);
			hmReturnMap.put("dTotalEquipment", strTotalEquipment);
			hmReturnMap.put("dTotalPlanning", strTotalPlanning);
			hmReturnMap.put("dTotalConsumedWork", strTotalConsumedWorks);
			hmReturnMap.put("dTotalConsumedEquipment", strTotalConsumedEquipment);

			return hmReturnMap;
	}
	public MapList getProjectDetails(Context context,String[] args) throws Exception
	{
		HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String strWhereCondition = (String) programMap.get("whereCondition");

		DomainObject doPerson = PersonUtil.getPersonObject(context);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("name");
		slObjSelects.addElement("current");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
		String strDateToday = simpleDateFormat.format(new Date());
		Date todayDate = new Date(strDateToday);
		String strCurrent = "";

		int iSize = mlRelatedProjectDetails.size();
		for (int i = 0 ; i < iSize ; i++)
		{
			Map mTemp = new HashMap();
			mTemp = (Map)mlRelatedProjectDetails.get(i);

			strCurrent = (String)mTemp.get("current");
			if("Complete".equals(strCurrent))
			{
				mTemp.put("status","completed");
			}
			else
			{
				Date dEstimatedFinishDate = new Date((String)mTemp.get("attribute[Task Estimated Finish Date]"));
				if(dEstimatedFinishDate.compareTo(todayDate) > 0)
				{
					mTemp.put("status","ontime");
				}
				else
				{
					mTemp.put("status","delayed");
				}
			}
		}
		return mlRelatedProjectDetails;
	}
}