/*---------------------------------------------------------------------------------------------------------------
NAME		: ${CLASSNAME}.java

DESCRIPTION	: Purpose of JPO is to generate PDF for RIC

CREATED		: OCT 29 2019

AUTHOR		: Divyashree B K

HISTORY		:

	Divyashree B K	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/

import java.math.RoundingMode;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringBufferInputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.io.*;
import java.util.Vector;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;

import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.util.XMLResourceDescriptor;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.jdom.transform.JDOMResult;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import matrix.db.Context;
import matrix.db.FileList;
import matrix.db.MQLCommand;
import matrix.db.RelationshipType;
import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringList;
import matrix.db.JPO;
import com.matrixone.apps.domain.util.MqlUtil;


public class WMSDownloadRICForm_mxJPO extends WMSConstants_mxJPO {
	public static final String FORMAT_GENERIC = PropertyUtil.getSchemaProperty("format_generic");
	public static final String SELECT_GENERIC_FORMAT_FILES = "format[" + FORMAT_GENERIC + "].file.name";
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSDownloadRICForm_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	public String generateRICForm(Context context,String[] args) throws Exception{
		
	     	String strFileName = DomainConstants.EMPTY_STRING;
		    String  strDocumentId = DomainConstants.EMPTY_STRING;
		try{
			HashMap programMap      = (HashMap)JPO.unpackArgs(args);
			String strObjID         = (String) programMap.get("objectId");
			String sAction 			= (String) programMap.get("action");
	        if(UIUtil.isNotNullAndNotEmpty(strObjID)){
			Map mRICDetails = getRICDetails(context,strObjID);	
		    String sSOCName = null;
			String sSOCFinyear = null;
			String sProjectType = null;
			String sOwner = null;
			String sPart1 = null;
			String sPart2 = null;
			if("DownloadRICPDF".equals(sAction)){
				sPart1 = "RIC Part-I";
				sPart2 = "RIC Part-II";
			}
			else if("DownloadAEPDF".equals(sAction)){
				sPart1 = "AE Part-I";
				sPart2 = "AE Part-II";
			}
			else if("DownloadApprovedAEPDF".equals(sAction))
		    {
				 sPart1 = "Approved AE Part-I";
				 sPart2 = "Approved AE Part-II";
		    }
			MapList mRICTableDetails = getRICTableDetails(context, new String[] {strObjID,sAction});
			MapList mRICPart1TableDetails = getRICPart1TableDetails(context, new String[] {strObjID,sAction});
			String strTransPath = context.createWorkspace();
			
			String xmlSourceFileName = sAction+"FormSource.xml";
			
			String xmlFilePath = strTransPath + File.separator+xmlSourceFileName;
			String sTSName = null;
			String sStation = null;
			String sProjectName = null;
			String sTSAmount = null;
			String sAdminApprovalAmount = null;
			String sWorkAmount = null;
			String sAmountInWords = null;
			String sPreviousTSAmount = null;
			String sIncludingALLTS = null;
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
			Document document = documentBuilder.newDocument();
			Element root = document.createElement("page");
			document.appendChild(root);
			String strpath = System.getProperty("user.dir");
		    File newFile = new File(strpath+"/..");
			
			String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
			String strLogo = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Logo");
			String strWatermark = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Watermark");
			strWatermark = strWatermark.replace("\\", "/");
			strLogo = strLogo.replace("\\", "/");
			Element embLogo = document.createElement("logo1");
			embLogo.appendChild(document.createTextNode("file:"+strLogo));
		
			Element embHeader = document.createElement("header-footer");
			Element embWatermark = document.createElement("watermark");
			embWatermark.appendChild(document.createTextNode("file:"+strWatermark));
			String strHeader = "";
			embHeader.appendChild(document.createTextNode(strHeader));
			root.appendChild(embHeader);
			root.appendChild(embWatermark);
			root.appendChild(embLogo);	
			
			Element sPart =  document.createElement("part_1");
			Element sSecPart =  document.createElement("part_2");
			sPart.appendChild(document.createTextNode(sPart1));
			
			sSecPart.appendChild(document.createTextNode(sPart2));
			
            		
			if(mRICDetails != null)
			{
			sSOCName  =(String)mRICDetails.get("sTitle");
			sSOCFinyear = (String)mRICDetails.get("sFinYear");
			sProjectType = (String)mRICDetails.get("sType");
			sOwner = (String)mRICDetails.get("sOwner");
			}	
            Element ricBasics = document.createElement("RICBasic");			
			
			Element sSOCTitle = document.createElement("SOCName");
			Element sSOCOwner = document.createElement("OwnerSOC");
			Element sSOCFYear = document.createElement("Financial_Year");
			Element sTypeofPrj = document.createElement("Type_Of_Project");
			
			
			sSOCTitle.appendChild(document.createTextNode(sSOCName));
		    ricBasics.appendChild(sSOCTitle);
			sSOCOwner.appendChild(document.createTextNode(sOwner));
		    ricBasics.appendChild(sSOCOwner);
			sSOCFYear.appendChild(document.createTextNode(sSOCFinyear));
		    ricBasics.appendChild(sSOCFYear);
			sTypeofPrj.appendChild(document.createTextNode(sProjectType));
		    ricBasics.appendChild(sTypeofPrj);
			
			root.appendChild(ricBasics);
			
			
			// to add the RIC Details in Part1
			Element ricMainDetailsforPart1 = document.createElement("ricdetailsforPart1");	
			String sTotalAmountOfAllHeads = "";
			for(int k=0;k<mRICPart1TableDetails.size();k++)
			{
				Map mRICData = (Map)mRICPart1TableDetails.get(k);
				String SlNo =  (String)mRICData.get("SlNo");
				String sTitle = (String)mRICData.get("sTitle");
				String sAmount = (String)mRICData.get("sAmount");
				String  sType = (String)mRICData.get("sType");
				String sContingency = (String)mRICData.get("sContingency");
				String sConsultancy = (String)mRICData.get("sConsultancy");
				String sTotalAmount = (String)mRICData.get("sTotalAmount");
				sTotalAmountOfAllHeads = (String)mRICData.get("sTotalAmountofAllHead");
				
				if(!"WMSRICItem".equals(sType)){
					if(!"WMSAEItem".equals(sType)){
				Element ricAttributesforPart1 = document.createElement("ricattributesforPart1");
				Element ricSlNo = document.createElement("Sl_No");
				Element ricTitle = document.createElement("title");
				Element ricAmount = document.createElement("amount");
				Element ricContingency = document.createElement("contingency");
				Element ricConsultancy = document.createElement("consultancy");
				Element ricTotalAmount = document.createElement("Total_Amount");
				
				
				ricSlNo.appendChild(document.createTextNode(SlNo));
				ricTitle.appendChild(document.createTextNode(sTitle));
				ricAmount.appendChild(document.createTextNode(sAmount));
				ricContingency.appendChild(document.createTextNode(sContingency));
				ricConsultancy.appendChild(document.createTextNode(sConsultancy));
				ricTotalAmount.appendChild(document.createTextNode(sTotalAmount));
				
				
				ricAttributesforPart1.appendChild(ricSlNo);	
				ricAttributesforPart1.appendChild(ricTitle);	
				ricAttributesforPart1.appendChild(ricAmount);	
				ricAttributesforPart1.appendChild(ricContingency);	
				ricAttributesforPart1.appendChild(ricConsultancy);	
				ricAttributesforPart1.appendChild(ricTotalAmount);
                ricMainDetailsforPart1.appendChild(ricAttributesforPart1);	
                ricMainDetailsforPart1.appendChild(sPart);	
				}				
				}
			}
			
			Element ricTotalAmountofAllHeads = document.createElement("Total_of_All_Heads_Amount");
			ricTotalAmountofAllHeads.appendChild(document.createTextNode(sTotalAmountOfAllHeads));
			
			ricMainDetailsforPart1.appendChild(ricTotalAmountofAllHeads);
			root.appendChild(ricMainDetailsforPart1);
			
			// to add the RIC Details in Part2
			Element ricMainDetails = document.createElement("ricdetails");	
			for(int i=0;i<mRICTableDetails.size();i++)
			{
			
				Map mRICData = (Map)mRICTableDetails.get(i);

				String SlNo =  (String)mRICData.get("SlNo");
				String  sLevel = (String)mRICData.get("sLevel");
				String  sType = (String)mRICData.get("sType");
				String  sTitle = (String)mRICData.get("sTitle");
				String  sDescription = (String)mRICData.get("sDescription");
				String sQuantity = (String)mRICData.get("sQuantity");
				String sRate = (String)mRICData.get("sRate");
				String sAmount = (String)mRICData.get("sAmount");
				String sGST= (String)mRICData.get("sGST");
				String sUnitofMeasure = (String)mRICData.get("sUnitofMeasure");
				String sContingency = (String)mRICData.get("sContingency");
				String  sConsultancy = (String)mRICData.get("sConsultancy");
				String  sTotalAmount = (String)mRICData.get("sTotalAmount");
				String sItemType = (String)mRICData.get("sItemType");
				String  sRemarks = (String)mRICData.get("sRemarks");
				String  sRICOwner = (String)mRICData.get("sOwner");
					
				
				Element ricSubDetails = document.createElement("RIC");
				Element ricDesc = document.createElement("RIC_DES");
				Element ricAttributes = document.createElement("ricattributes");
				Element ricSlNo = document.createElement("Sl_No");
				Element ricsLevel = document.createElement("level");
				Element ricType = document.createElement("type");
				Element ricTitle = document.createElement("title");
				Element ricUom = document.createElement("uom");
				Element ricQuant = document.createElement("qant");
				Element ricRate = document.createElement("Rate");
				Element ricAmount = document.createElement("amount");
				Element ricGST = document.createElement("GST");
				Element ricContingency = document.createElement("contingency");
				Element ricConsultancy = document.createElement("consultancy");
				Element ricTotalAmount = document.createElement("Total_Amount");
				Element ricItemType = document.createElement("Item_Type");
				Element ricRemarks = document.createElement("Remarks");
				Element ricOwner = document.createElement("Owner");
				
				ricDesc.appendChild(document.createTextNode(sDescription));
				ricSubDetails.appendChild(ricDesc);
				
				ricMainDetails.appendChild(ricSubDetails);
				ricSlNo.appendChild(document.createTextNode(SlNo));
				ricsLevel.appendChild(document.createTextNode(sLevel));
				ricType.appendChild(document.createTextNode(sType));
				ricTitle.appendChild(document.createTextNode(sTitle));
				ricUom.appendChild(document.createTextNode(sUnitofMeasure));
				ricQuant.appendChild(document.createTextNode(sQuantity));
				ricRate.appendChild(document.createTextNode(sRate));
				ricAmount.appendChild(document.createTextNode(sAmount));
				ricGST.appendChild(document.createTextNode(sGST));
				ricContingency.appendChild(document.createTextNode(sContingency));
				ricConsultancy.appendChild(document.createTextNode(sConsultancy));
				ricTotalAmount.appendChild(document.createTextNode(sTotalAmount));
				ricItemType.appendChild(document.createTextNode(sItemType));
				ricRemarks.appendChild(document.createTextNode(sRemarks));
				ricOwner.appendChild(document.createTextNode(sRICOwner));
				
				ricAttributes.appendChild(ricSlNo);				
			//	ricAttributes.appendChild(ricsLevel);				
			//	ricAttributes.appendChild(ricType);
				ricAttributes.appendChild(ricTitle);
				ricAttributes.appendChild(ricUom);
				ricAttributes.appendChild(ricQuant);
				ricAttributes.appendChild(ricRate);
				ricAttributes.appendChild(ricAmount);
				ricAttributes.appendChild(ricGST);
				//ricAttributes.appendChild(ricContingency);
				//ricAttributes.appendChild(ricConsultancy);
				ricAttributes.appendChild(ricTotalAmount);
				ricAttributes.appendChild(ricItemType);
				ricAttributes.appendChild(ricRemarks);
				ricAttributes.appendChild(ricDesc);
		//		ricAttributes.appendChild(ricOwner);
				
				ricSubDetails.appendChild(ricAttributes);		
				
				//ricMainDetails.appendChild(ricSubDetails);
				ricMainDetails.appendChild(ricAttributes);
				ricMainDetails.appendChild(sSecPart);
			
			}
			root.appendChild(ricMainDetails);
			//root.appendChild(ricMainDetails);

		    TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domSource = new DOMSource(document);
			StreamResult streamResult = new StreamResult(new File(xmlFilePath));
			transformer.transform(domSource, streamResult);
			File xmlFile = new File(xmlFilePath);

			//Write XML - End
		
			//Write XSL - Start
			String strXSLFile = sAction +"FormSource.xsl";
			File newTextFile = new File(strTransPath + File.separator+strXSLFile);

			MQLCommand mql = new MQLCommand();
			mql.open(context);
			mql.executeCommand(context, "print program WMSRICForm.xsl select code dump");
			mql.close(context);
			FileWriter fw = new FileWriter(newTextFile);
			fw.write(mql.getResult());
			fw.close();		
			
			File xsltFile = new File(strTransPath + File.separator+strXSLFile);
			StreamSource xmlSource = new StreamSource(new File(xmlFilePath));
			Calendar calendarDate = Calendar.getInstance();
			
			String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
			SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
			String strTime = formatter.format(calendarDate.getTime());
			String strName = null;
			if("DownloadAEPDF".equals(sAction)){
				
			 strName = "ExportAE"+strTime;
			}
			else if("DownloadRICPDF".equals(sAction))
			{
				strName = "ExportRIC"+strTime;
			}
			else if("DownloadApprovedAEPDF".equals(sAction))
		    {
				strName = "ExportApprovedAE"+strTime;
			}
			strFileName = strName+".pdf";
			OutputStream out;
			out = new java.io.FileOutputStream(strTransPath+File.separator+strFileName);
			try {
				FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());		
				FOUserAgent foUserAgent = fopFactory.newFOUserAgent();			
				Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);
				TransformerFactory factory = TransformerFactory.newInstance();
				Transformer transformer1 = factory.newTransformer(new StreamSource(xsltFile));
				Result res = new SAXResult(fop.getDefaultHandler());
				transformer1.transform(xmlSource, res);
				String strOwner = context.getUser();
				strDocumentId = FrameworkUtil.autoName(context, CommonDocument.SYMBOLIC_type_Document, CommonDocument.SYMBOLIC_policy_Document);
				DomainObject domObj = DomainObject.newInstance(context, strDocumentId);
				domObj.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, strFileName);

				DomainObject doSOC = new DomainObject(strObjID);
				doSOC.connect(context,new RelationshipType(RELATIONSHIP_WMSSOC_SYSTEMREFERENCEDOCUMENT),true, DomainObject.newInstance(context,strDocumentId));		
				domObj.setOwner(context, strOwner);
				WMSImport_mxJPO.checkInFile(context, strDocumentId, strFileName, DomainConstants.EMPTY_STRING, context.getSession().getVault(),strTransPath);
			  } 	
			  catch(Exception exception)
			  {
					exception.printStackTrace();
			  }			
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			DomainConstants.MULTI_VALUE_LIST.remove(SELECT_GENERIC_FORMAT_FILES);
			return strFileName;
		}
	
 }
	public static Map getRICDetails(Context context,String strObjID)throws Exception
	{
		Map mRICMap = new HashMap();
		try{
			if(UIUtil.isNotNullAndNotEmpty(strObjID))
			{
			DomainObject dObj = new DomainObject(strObjID);
			StringList sObjectSelect = new StringList();
			sObjectSelect.add("attribute["+ATTRIBUTE_TITLE+"].value");
			sObjectSelect.add("attribute["+ATTRIBUTE_WMSSOC_FINANCIAL_YEAR+"].value");
			sObjectSelect.add("attribute["+ATTRIBUTE_WMSSOC_PROJECT_TYPE+"].value");
			sObjectSelect.add(DomainConstants.SELECT_OWNER);
			Map mReturn = dObj.getInfo(context,sObjectSelect);
			if(mReturn.size()>0)
			{
			String sSOCTitle = (String)mReturn.get("attribute["+ATTRIBUTE_TITLE+"].value");
			String sSOCFyear = (String)mReturn.get("attribute["+ATTRIBUTE_WMSSOC_FINANCIAL_YEAR+"].value");
			String sSOCPType = (String)mReturn.get("attribute["+ATTRIBUTE_WMSSOC_PROJECT_TYPE+"].value");
			String sSOCOwner = (String)mReturn.get(DomainConstants.SELECT_OWNER);
			mRICMap.put("sTitle",sSOCTitle);
			mRICMap.put("sFinYear",sSOCFyear);
			mRICMap.put("sType",sSOCPType);
			String sO = " \"" + sSOCOwner + "\" ";
			String strOwner = MqlUtil.mqlCommand(context,"print person " +sO+ " select fullname dump");
			mRICMap.put("sOwner",strOwner);		
			}
			}
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		return mRICMap;
		
	}
	public static MapList getRICPart1TableDetails(Context context,String[] args)throws Exception
	{
		String strObjID = args[0];
		String sAction = args[1];
		//System.out.println("strObjID--"+strObjID);
		//System.out.println("sAction--"+sAction);
		MapList mlTableData = new MapList();
		String SlNo = "";
		String sLevel = "";
		String sType = "";
		String sTitle = "";
		String sDescription = "";
		String sUnitofMeasure = "";
		String sQuantity = "";
		String sRate = "";
		String sAmount = "";
		String sGST= "";
		String sContingency = "";
		String sConsultancy = "";
		String sTotalAmount = "";
		String sItemType = "";
		String sRemarks = "";
		String sOwner = "";
		String sId = "";
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		double dTotalAmount = 0;
		double dTotalofAllHeadAmount = 0;
		MapList mlRICMaster = new MapList();
		try{
		//	DecimalFormat df = new DecimalFormat("0.00");
			if(UIUtil.isNotNullAndNotEmpty(strObjID))
			{
			DomainObject dSOCObj = new DomainObject(strObjID);
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add("attribute["+ATTRIBUTE_TITLE+"].value");
			busSelects.add(DomainConstants.SELECT_DESCRIPTION);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add("attribute[Quantity].value");
			busSelects.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
			busSelects.add("attribute["+ATTRIBUTE_RATE+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSGST+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSAUTHORIZED+"].value");
			busSelects.add("attribute["+ATTRIBUTE_REMARKS+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSCONTINGENCY+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSCONSULTANCY+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value");
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			if("DownloadRICPDF".equals(sAction)){
			 mlRICMaster = dSOCObj.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_RICMASTER+","+RELATIONSHIP_WMSRICMASTER_RIC+","+RELATIONSHIP_WMSRIC_RIC+","+RELATIONSHIP_WMSRIC_RICITEM, // relationship pattern
													TYPE_WMSRIC+","+TYPE_WMSRICITEM+","+// relationship pattern
													TYPE_WMSRICMASTER+","+TYPE_WMS_DEFAULT_MASTERS, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short)0, // recursion level
													null, // object where clause
													null); // relationship where clause
			}
			else if("DownloadAEPDF".equals(sAction)){
				 mlRICMaster = dSOCObj.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_AEMASTER+","+RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE+","+RELATIONSHIP_WMSAE_AEITEM, // relationship pattern
													TYPE_WMSAE+","+TYPE_WMSAEITEM+","+// relationship pattern
													TYPE_WMSAEMASTER+","+TYPE_WMS_DEFAULT_MASTERS, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short)0, // recursion level
													null, // object where clause
													null); // relationship where clause
			}
			else if("DownloadApprovedAEPDF".equals(sAction))
		    {
				 mlRICMaster = dSOCObj.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_APPROVEDAEMASTER+","+RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE+","+RELATIONSHIP_WMSAE_AEITEM, // relationship pattern
													TYPE_WMSAE+","+TYPE_WMSAEITEM+","+// relationship pattern
													TYPE_WMSAEMASTER+","+TYPE_WMS_DEFAULT_MASTERS, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short)0, // recursion level
													null, // object where clause
													null); // relationship where clause
			}
			mlRICMaster.sort("originated", "ascending", "date");
			//System.out.println("mlRICMaster======="+mlRICMaster);
			
			for(int i=0; i<mlRICMaster.size(); i++)
			{
				Map mMap = (Map)mlRICMaster.get(i);
			    sId = (String)mMap.get(DomainConstants.SELECT_ID);
				SlNo =(String)mMap.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value"); 
				sLevel = (String)mMap.get("level"); 
				sType = (String)mMap.get("type"); 
				sTitle =(String)mMap.get("attribute["+ATTRIBUTE_TITLE+"].value");
				
				sContingency = (String)mMap.get("attribute["+ATTRIBUTE_WMSCONTINGENCY+"].value");
				if(UIUtil.isNotNullAndNotEmpty(sContingency)){
				Double doubleQuant = Double.parseDouble(sContingency);
				sContingency = WMSUtil_mxJPO.converToIndianCurrency(context,doubleQuant);
				} 
				
				sConsultancy = (String)mMap.get("attribute["+ATTRIBUTE_WMSCONSULTANCY+"].value");
				if(UIUtil.isNotNullAndNotEmpty(sConsultancy)){
				Double doubleQuant = Double.parseDouble(sConsultancy);
				sConsultancy = WMSUtil_mxJPO.converToIndianCurrency(context,doubleQuant);
				} 
				
				sItemType = (String)mMap.get("attribute["+ATTRIBUTE_WMSAUTHORIZED+"].value");
				sRemarks = (String)mMap.get("attribute["+ATTRIBUTE_REMARKS+"].value");
				sOwner = (String)mMap.get(DomainConstants.SELECT_OWNER);
				HashMap params      = new HashMap();
		        params.put("objectId", sId);
				params.put("type", sType);
				Map ricMap = new HashMap();
				
			
				
				ricMap.put("sLevel",sLevel);
				ricMap.put("SlNo",SlNo);

				ricMap.put("sType",sType);
				
				int iLevel = Integer.valueOf(sLevel);
				String strSpace =DomainConstants.EMPTY_STRING;
				for(int j = 1 ; j<iLevel; j++)
				{
					strSpace = strSpace + "      ";
				}
				ricMap.put("sTitle",strSpace+sTitle);
				
				//to get amount and total amount for each
				dAmount = WMSUtil_mxJPO.getTotalAmountforPDF(context,JPO.packArgs(params));
				if(sType.equals("WMSDefaultMaster")){
					dTotalAmount = Double.valueOf((String)mMap.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value"));
				}else{
					dTotalAmount = WMSUtil_mxJPO.getPart1TotalAmountforPDF(context,JPO.packArgs(params));
				}
				if(sType.equals("WMSRICMaster")) {
					dTotalofAllHeadAmount+= dTotalAmount;
					
				}
				if(sType.equals("WMSAEMaster")) {
					dTotalofAllHeadAmount+= dTotalAmount;
					
				}
				if(sType.equals("WMSDefaultMaster")) {
					dTotalofAllHeadAmount+= dTotalAmount;
					
				}
				ricMap.put("sAmount",WMSUtil_mxJPO.converToIndianCurrency(context,dAmount));
				ricMap.put("sContingency",sContingency);
				ricMap.put("sConsultancy",sConsultancy);
				ricMap.put("sTotalAmount",WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAmount));
				ricMap.put("sTotalAmountofAllHead",WMSUtil_mxJPO.converToIndianCurrency(context,dTotalofAllHeadAmount));
				//System.out.println("ricMap-------"+ricMap);
			    mlTableData.add(ricMap);
			}			
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//System.out.println("mlTableData-part1--"+mlTableData);
		return mlTableData;
	}
	
	
	public static MapList getRICTableDetails(Context context,String[] args)throws Exception
	{
		String strObjID = args[0];
		String sAction = args[1];
		MapList mlTableData = new MapList();
		String SlNo = "";
		String sLevel = "";
		String sType = "";
		String sTitle = "";
		String sDescription = "";
		String sUnitofMeasure = "";
		String sQuantity = "";
		String sRate = "";
		String sAmount = "";
		String sGST= "";
		String sContingency = "";
		String sConsultancy = "";
		String sTotalAmount = "";
		String sItemType = "";
		String sRemarks = "";
		String sOwner = "";
		String sId = "";
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		double dTotalAmount = 0;
		double dTotalofAllHeadAmount = 0;
		MapList mlRICMaster = new MapList();
		try{
		//	DecimalFormat df = new DecimalFormat("0.00");
			if(UIUtil.isNotNullAndNotEmpty(strObjID))
			{
			DomainObject dSOCObj = new DomainObject(strObjID);
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add("attribute["+ATTRIBUTE_TITLE+"].value");
			busSelects.add(DomainConstants.SELECT_DESCRIPTION);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add("attribute[Quantity].value");
			busSelects.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
			busSelects.add("attribute["+ATTRIBUTE_RATE+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSGST+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSAUTHORIZED+"].value");
			busSelects.add("attribute["+ATTRIBUTE_REMARKS+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSCONTINGENCY+"].value");
			busSelects.add("attribute["+ATTRIBUTE_WMSCONSULTANCY+"].value");
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			if("DownloadRICPDF".equals(sAction)){
			 mlRICMaster = dSOCObj.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_RICMASTER+","+RELATIONSHIP_WMSRICMASTER_RIC+","+RELATIONSHIP_WMSRIC_RIC+","+RELATIONSHIP_WMSRIC_RICITEM, // relationship pattern
													TYPE_WMSRIC+","+TYPE_WMSRICITEM+","+// relationship pattern
													TYPE_WMSRICMASTER, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short)0, // recursion level
													null, // object where clause
													null); // relationship where clause
			}
			else if("DownloadAEPDF".equals(sAction)){
				 mlRICMaster = dSOCObj.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_AEMASTER+","+RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE+","+RELATIONSHIP_WMSAE_AEITEM, // relationship pattern
													TYPE_WMSAE+","+TYPE_WMSAEITEM+","+// relationship pattern
													TYPE_WMSAEMASTER, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short)0, // recursion level
													null, // object where clause
													null); // relationship where clause
			}
			else if("DownloadApprovedAEPDF".equals(sAction))
		    {
				 mlRICMaster = dSOCObj.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_APPROVEDAEMASTER+","+RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE+","+RELATIONSHIP_WMSAE_AEITEM, // relationship pattern
													TYPE_WMSAE+","+TYPE_WMSAEITEM+","+// relationship pattern
													TYPE_WMSAEMASTER, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short)0, // recursion level
													null, // object where clause
													null); // relationship where clause
			}
			mlRICMaster.sort("originated", "ascending", "date");
			
			int iLevel = 1;
			int iLevelCtr = 1;
			for(int i=0; i<mlRICMaster.size(); i++)
			{
				Map mMap = (Map)mlRICMaster.get(i);
			    sId = (String)mMap.get(DomainConstants.SELECT_ID);
				SlNo =(String)mMap.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value"); 
				sLevel = (String)mMap.get("level"); 
				if(UIUtil.isNotNullAndNotEmpty(sLevel)){
					if(iLevel == Integer.valueOf(sLevel)){
						iLevelCtr++;	
					}else{
						iLevel = Integer.valueOf(sLevel);
						iLevelCtr = 1;
					}					
				}
				if(UIUtil.isNullOrEmpty(SlNo)){
					SlNo = String.valueOf(iLevel)+String.valueOf(iLevelCtr);					
				}
				sType = (String)mMap.get("type"); 
				sTitle =(String)mMap.get("attribute["+ATTRIBUTE_TITLE+"].value");
				sDescription =  (String)mMap.get(DomainConstants.SELECT_DESCRIPTION);
				if(UIUtil.isNullOrEmpty(sDescription))
				{
					sDescription = sTitle;
				}
				sUnitofMeasure =(String)mMap.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
				sQuantity = (String)mMap.get("attribute[Quantity].value");
				
				
				sRate =  (String)mMap.get("attribute["+ATTRIBUTE_RATE+"].value");
				
				if(UIUtil.isNotNullAndNotEmpty(sRate)){
				Double doubleQuant = Double.parseDouble(sRate);
				sRate = WMSUtil_mxJPO.converToIndianCurrency(context,doubleQuant);
				} 
				sGST = (String)mMap.get("attribute["+ATTRIBUTE_WMSGST+"].value");
				
				sContingency = (String)mMap.get("attribute["+ATTRIBUTE_WMSCONTINGENCY+"].value");
				if(UIUtil.isNotNullAndNotEmpty(sContingency)){
				Double doubleQuant = Double.parseDouble(sContingency);
				sContingency = WMSUtil_mxJPO.converToIndianCurrency(context,doubleQuant);
				} 
				
				sConsultancy = (String)mMap.get("attribute["+ATTRIBUTE_WMSCONSULTANCY+"].value");
				if(UIUtil.isNotNullAndNotEmpty(sConsultancy)){
				Double doubleQuant = Double.parseDouble(sConsultancy);
				sConsultancy = WMSUtil_mxJPO.converToIndianCurrency(context,doubleQuant);
				} 
				
				sItemType = (String)mMap.get("attribute["+ATTRIBUTE_WMSAUTHORIZED+"].value");
				sRemarks = (String)mMap.get("attribute["+ATTRIBUTE_REMARKS+"].value");
				sOwner = (String)mMap.get(DomainConstants.SELECT_OWNER);
				HashMap params      = new HashMap();
		        params.put("objectId", sId);
				params.put("type", sType);
				Map ricMap = new HashMap();
				
			//	ricMap.put("SlNo","1");
				
				ricMap.put("SlNo",SlNo);
				/*if(sType.equals("WMSRICMaster") || sType.equals("WMSRIC") )
				{
					sType = "Head";
				}
				if(sType.equals("WMSRICItem"))
				{
					sType = "Item";
				}*/

				ricMap.put("sType",sType);
				
				int iLevelSpace = Integer.valueOf(sLevel);
				String strSpace =DomainConstants.EMPTY_STRING;
				for(int j = 1 ; j<iLevelSpace; j++)
				{
					strSpace = strSpace + "      ";
				}
				ricMap.put("sTitle",strSpace+sTitle);
				ricMap.put("sDescription",sDescription);
				ricMap.put("sUnitofMeasure",sUnitofMeasure);
				ricMap.put("sQuantity",sQuantity);
				ricMap.put("sRate",sRate);
				
				//to get amount and total amount for each
				dAmount = WMSUtil_mxJPO.getAmountForPDF(context,JPO.packArgs(params));
				dTotalAmount = WMSUtil_mxJPO.getTotalAmountforPDF(context,JPO.packArgs(params));
				
				if(sType.equals("WMSRICMaster")) {
					dTotalofAllHeadAmount+= dTotalAmount;
					
				}
				if(sType.equals("WMSAEMaster")) {
					dTotalofAllHeadAmount+= dTotalAmount;
					
				}
				ricMap.put("sAmount",WMSUtil_mxJPO.converToIndianCurrency(context,dAmount));
				ricMap.put("sGST",sGST);
				ricMap.put("sContingency",sContingency);
				ricMap.put("sConsultancy",sConsultancy);
				ricMap.put("sTotalAmount",WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAmount));
				ricMap.put("sTotalAmountofAllHead",WMSUtil_mxJPO.converToIndianCurrency(context,dTotalofAllHeadAmount));
				ricMap.put("sItemType",sItemType);
				ricMap.put("sRemarks",sRemarks);
				String sO = " \"" + sOwner + "\" ";
			    String strOwner = MqlUtil.mqlCommand(context,"print person " +sO+ " select fullname dump");
				ricMap.put("sOwner",strOwner);
			    mlTableData.add(ricMap);
			}			
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return mlTableData;
	}
	
 }
 