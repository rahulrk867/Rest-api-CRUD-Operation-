/*---------------------------------------------------------------------------------------------------------------
NAME		: ${CLASSNAME}.java

DESCRIPTION	: Purpose of JPO is to Create RIC/AE and perform the utility operations on it

CREATED		: August 13 2019

AUTHOR		: Chandrakant M Sangashetty

HISTORY		:

	Chandrakant M Sangashetty	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.util.Hashtable;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.program.ProgramCentralConstants;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import matrix.db.Policy;
import matrix.util.Pattern;

import com.matrixone.jdom.Element;

public class WMSTS_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSTS_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	/**
	* Method to get Realated RICChapters information on ProjectSpace
	*
	* @param context - the eMatrix <code>Context</code> object
	* @param args - args contains a Map with the following entries
	*                      objectId - Object Id of the Context object
	* @return - Maplist
	* @throws Exception if the operation fails
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedTS(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
			DomainObject domObject = new DomainObject(sObjectId);
			String sSOCObjId = domObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			DomainObject domSOCObject = new DomainObject(sSOCObjId);
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			busSelects.add("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"].value");
			busSelects.add(ATTRIBUTE_TITLE);
			String sWhere = "revision==last";
			MapList sList = domSOCObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOCTS, // relationship pattern
													TYPE_WMSTECHNICALSANCTION, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
			String sContextUser = context.getUser();
			for (int i = 0, size = sList.size(); i < size; i++) {
				Map objMap = (Map) sList.get(i);
				String sState = (String) objMap.get(DomainConstants.SELECT_CURRENT);
				String sObjOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
				if(!"Create".equals(sState) || !sContextUser.equals(sObjOwner)) {
					objMap.put("RowEditable", "readonly");
					objMap.put("disableSelection", "true");
				}
			}
			sList.sort("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"].value", "ascending", "integer");
			return sList;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	check DCS Master Amonut 
	should not be more than 10% 
	of Admin Approval Amount
	**/
	public int checkTSAmount(Context context,String[] args)throws Exception{
		try{
			//attribute value of Admin Approval Amount
			String sObjectId = args[0];		
		    
			if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
				DomainObject dcsObj = new DomainObject(sObjectId);
				String sTSAmount = "";
				double sTotalTsAmount = 0;
				double sTSTotalAmount = 0;
				double dAmount=0;
				double iAdminAprrovalAmount = 0;
				String strAdminAprrovalAmount = "";
				String strAmount ="";
				String sSOCId = dcsObj.getInfo(context,"to["+RELATIONSHIP_WMSSOC_DCSMASTER+"].from.id");
				String sWhere = "revision == last";			
				StringList selects = new StringList(1);
				selects.add(DomainObject.SELECT_ID);
				selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
				DomainObject sSOCObj = new DomainObject(sSOCId);
				MapList AAList = sSOCObj.getRelatedObjects(context, RELATIONSHIP_WMSSOCADMINAPPROVAL, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
					if(AAList.size()>0)
					{
						Map mAA = (Map)AAList.get(0);
						//String sAA =(String)mAA.get(DomainObject.SELECT_ID);
						//DomainObject objAA = DomainObject.newInstance(context, sAA);
						//strAmount = objAA.getAttributeValue(context,"attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
						strAmount = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
					}
				if(UIUtil.isNullOrEmpty(strAmount))
				{
					strAmount = "0";
				}
				
				//double dcsAmount = getDCSMasterAmount(context, args);
				double dcsAmount = WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCSMASTER_DCS, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
				
				StringList sObjectSelects = new StringList();
				sObjectSelects.add(DomainConstants.SELECT_ID);
				sObjectSelects.add("attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
				MapList mList = sSOCObj.getRelatedObjects(context,RELATIONSHIP_WMSSOCTS,TYPE_WMSTECHNICALSANCTION,sObjectSelects,
								    null,false,true, (short)0,"revision==last",null,(short)0);
								
				//calculating 10% of Admin Approval Amount
                String strAmountPercent = EnoviaResourceBundle.getProperty(context,"WMS.Delegation.ApprovalAmountPercentage");
				double iAmountPercent = Double.parseDouble(strAmountPercent);
				double iApprovalAmount = Double.parseDouble(strAmount.replace(",","")); 
				iAdminAprrovalAmount = iApprovalAmount + ((iAmountPercent / 100) * iApprovalAmount);
				strAdminAprrovalAmount = Double.toString(iAdminAprrovalAmount);			
				dAmount = Double.valueOf(strAdminAprrovalAmount);
				//check for 1st TS
				if(mList.size() == 0)
				{
					if(dcsAmount > dAmount)
					{
						System.out.println("inside 1");
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.checkTS");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
					}
				}
				//checking for all the TS connected to SOC
				for(int i =0;i<mList.size(); i++)
				{
					Map mTSMap =(Map)mList.get(i);
					sTSAmount = (String)mTSMap.get("attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
					sTSTotalAmount = Double.parseDouble(sTSAmount);
					sTotalTsAmount = sTotalTsAmount + sTSTotalAmount;
				}
				
				//checking for greater than amount
				if(sTotalTsAmount > dAmount)
				{
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.checkTS");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
				}
				
			}
	
		return 0;	
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			return 1;
		}
		
	}
	
	/**
	* Method to get technical sanction 
	*
	* @param context - the eMatrix <code>Context</code> object
	* @param args - args contains a Map with the following entries
	* objectId - Object Id of the Context object
	* @return - Maplist
	* @throws Exception if the operation fails
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public int createTechnicalSanction(Context context,String args[]) throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		boolean bFlag = false;
		try {
			String sObjectId = args[0];
			DomainObject dcsObj = new DomainObject(sObjectId);
			
			StringList busSelects = new StringList();
			busSelects.add(DomainObject.SELECT_ID);
			String sWhere = "revision==last";
			StringList slInclude = new StringList();
			MapList sList = dcsObj.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSDCSTS, // relationship pattern
														TYPE_WMSTECHNICALSANCTION, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														sWhere, // object where clause
														null);
			if (sList.size() == 1) {
				String sTSId = (String) ((Map) sList.get(0)).get(DomainObject.SELECT_ID);
				StringList slObjectInfo = new StringList();
				slObjectInfo.add(DomainConstants.SELECT_CURRENT);
				slObjectInfo.add(DomainConstants.SELECT_OWNER);
				slObjectInfo.add("attribute["+ATTRIBUTE_WMSTSAMOUNT+"].value");
				
				DomainObject domTS = new DomainObject(sTSId);
				Map objMap = (Map) domTS.getInfo(context, slObjectInfo);
				String strState = (String) objMap.get(DomainConstants.SELECT_CURRENT);
				String strOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
				//double dPreviousAmount = Double.parseDouble((String) objMap.get("attribute["+ATTRIBUTE_WMSTSAMOUNT+"].value"));
				StringList slDCSMaster = domTS.getInfoList(context, "to["+RELATIONSHIP_WMSDCSTS+"].from.id");
				double dTempAmount = 0;
				for (Object ItemObject:slDCSMaster) {
					String sItemId = (String)ItemObject;
					dTempAmount += WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sItemId, RELATIONSHIP_WMSDCSMASTER_DCS, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
				}
				
				switch(strState) {
					case "Create" :
								domTS.setAttributeValue(context, ATTRIBUTE_WMSTSAMOUNT, df.format(dTempAmount));
								WMSDownloadTSForm_mxJPO.generateTSForm(context, new String[] {(String)domTS.getInfo(context, DomainConstants.SELECT_ID)});
								bFlag = true;
								break;
					case "Review" :
								bFlag = false;
								break;
					case "Approved" :
					case "Obsolete" :
								BusinessObject boTS = domTS.reviseObject(context, true);
								domTS = new DomainObject(boTS);
								domTS.setOwner(context, strOwner);
								domTS.setAttributeValue(context, ATTRIBUTE_WMSTSAMOUNT, df.format(dTempAmount));
								WMSDownloadTSForm_mxJPO.generateTSForm(context, new String[] {(String)domTS.getInfo(context, DomainConstants.SELECT_ID)});
								updateSubsequenceTSWhenRevised(context,domTS);
								domTS = new DomainObject(sTSId);
								domTS.setState(context, STATE_WMSTECHNICALSANCTION_OBSOLETE, true);
								bFlag = true;
								break;
					default :
								bFlag = false;
								emxContextUtil_mxJPO.mqlNotice(context, "Process Failed");
								return 1;
				}
			} else {
				String revision = "";
				revision = new Policy(POLICY_WMSTECHNICALSANCTION).getFirstInMinorSequence(context);
				if (UIUtil.isNotNullAndNotEmpty(sObjectId)) {
					double dTempAmount = WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCSMASTER_DCS, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
					
					DomainObject domTS = DomainObject.newInstance(context);
					String sTitle = dcsObj.getInfo(context, "attribute[Title]");
					String sSOCId = dcsObj.getInfo(context,"to["+RELATIONSHIP_WMSSOC_DCSMASTER+"].from.id");
					DomainObject sSOCObj = new DomainObject(sSOCId);
					MapList sTSList = sSOCObj.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSSOCTS, // relationship pattern
														TYPE_WMSTECHNICALSANCTION, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														sWhere, // object where clause
														null);
														
					int iSequence = 1;
					
					if(sTSList.size()>1){
						iSequence = sTSList.size();
					}
					
					String strTSName = DomainObject.getAutoGeneratedName(context, "type_WMSTechnicalSanction", "");			
					domTS.createObject(context, TYPE_WMSTECHNICALSANCTION, strTSName,revision,POLICY_WMSTECHNICALSANCTION, "eService Production");
					Map<String,String> mAttMap = new HashMap<String,String>();
					mAttMap.put(ATTRIBUTE_TITLE,sTitle);
					mAttMap.put(ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER,String.valueOf(iSequence+1));
					mAttMap.put(ATTRIBUTE_WMSTSAMOUNT,df.format(dTempAmount));
					domTS.setAttributeValues(context,mAttMap);
					DomainRelationship domRel = DomainRelationship.connect(context, dcsObj, RELATIONSHIP_WMSDCSTS, domTS);
					DomainRelationship domRelforSoc = DomainRelationship.connect(context, sSOCObj, RELATIONSHIP_WMSSOCTS, domTS);
					WMSDownloadTSForm_mxJPO.generateTSForm(context, new String[] {(String)domTS.getInfo(context, DomainConstants.SELECT_ID)});					
				}
				bFlag = true;
			}
			
			if (!bFlag) {
				emxContextUtil_mxJPO.mqlNotice(context, "Process Failed Demote TS and try again...");
			}
			
			return bFlag==true ? 0 : 1;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public double getTSAmount(Context context,Map map)throws Exception {
		try {						
			String sQuantity = (String) map.get("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"]");
			String sRate = (String) map.get("attribute["+ATTRIBUTE_RATE+"]");
			String sGST = (String) map.get("attribute["+ATTRIBUTE_WMSGST+"]");
			if(UIUtil.isNullOrEmpty(sQuantity))
				sQuantity = "0";
			if(UIUtil.isNullOrEmpty(sRate))
				sRate = "0";
			if(UIUtil.isNullOrEmpty(sGST))
				sGST = "0";
			double dQuantity = Double.parseDouble(sQuantity);
			double dRate = Double.parseDouble(sRate);
			double dGST = Double.parseDouble(sGST);
			double amount = dQuantity * dRate;
			amount = amount + (amount*dGST/100) ;
			return amount;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	 public int checkApprovalRouteTemplate(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];	
			DomainObject doObj = new DomainObject(sObjectId);	
			String sApprovalTemplateId = (String)doObj.getInfo(context, "from["+RELATIONSHIP_WMSTSAPPROVALTEMPLATE+"].to.id");
			
			if (!UIUtil.isNotNullAndNotEmpty(sApprovalTemplateId)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoApprovalTemplate");
				emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				return 1;
			}
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method create Route object.
    */
    public int createApprovalRoute(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			
			DomainObject doObj = new DomainObject(sObjectId);
					
			String strRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
			MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doObj, strRelWhere);
			if(mlExtRoutes.size()>0) {
				WMSUtil_mxJPO.restartExistingRoute(context,mlExtRoutes);
			} else {
			
				String sRouteDescription = (String)doObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
				String sState = (String)doObj.getInfo(context, DomainConstants.SELECT_CURRENT);
				String sApprovalTemplateId = (String)doObj.getInfo(context, "from["+RELATIONSHIP_WMSTSAPPROVALTEMPLATE+"].to.id");
				String strContectUser =  context.getUser();
				Map mRouteAttrib= new HashMap();
				mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
				
				Map objectRouteAttributeMap=new HashMap(); 
				objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", POLICY_WMSTECHNICALSANCTION,false ));
				objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Review");
				objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,"Review");
				Map reviewerInfo= new HashMap();
				
				Route.createAndStartRouteFromTemplateAndReviewers(context,
								sApprovalTemplateId,
								sRouteDescription,
								strContectUser , 
								sObjectId,
								POLICY_WMSTECHNICALSANCTION,
								sState, 
								mRouteAttrib,
								objectRouteAttributeMap, 
								reviewerInfo,
								true);
			}
			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			return 1;
		}
	}
	
	/**
	* This Method Connects RT to TS
	**/
	@com.matrixone.apps.framework.ui.CellUpdateJPOCallable
	public void connectApprovalTemplate(Context context,String args[]) throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramMap =  (HashMap)programMap.get("paramMap");
			
			String strObjectId =(String) paramMap.get("objectId");
			String strRTId =(String) paramMap.get("New Value");
			
			DomainObject doObject = new DomainObject(strObjectId);
			String sType = doObject.getInfo(context, DomainConstants.SELECT_TYPE);
			if (TYPE_WMSTECHNICALSANCTION.equals(sType)) {
				String sObjRTConnectionId = doObject.getInfo(context, "from["+RELATIONSHIP_WMSTSAPPROVALTEMPLATE+"].id");
				if (UIUtil.isNotNullAndNotEmpty(sObjRTConnectionId)) {				
					DomainRelationship.disconnect(context, sObjRTConnectionId);
				}
				DomainRelationship.connect(context, strObjectId, RELATIONSHIP_WMSTSAPPROVALTEMPLATE, strRTId, false);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
    public  MapList getAllApprovedTask(Context context, String strObjectId) throws Exception {
		MapList mlInboxTask = new MapList();
		MapList returnList = new MapList();
        try {
			Pattern includeType = new Pattern(DomainConstants.TYPE_INBOX_TASK);
				
			StringList objectList = new StringList();
			objectList.addElement(DomainConstants.SELECT_ID);
			objectList.addElement(DomainConstants.SELECT_TYPE);
			objectList.addElement(DomainConstants.SELECT_CURRENT);
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_FIRST_NAME+"]");
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.id");
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.name");
			objectList.addElement("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.attribute["+DomainConstants.ATTRIBUTE_LAST_NAME+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ROUTE_TASK_USER+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_APPROVAL_STATUS+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]");
			objectList.addElement("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
			//Added by ravi
			objectList.addElement("format.file.name");
			objectList.addElement("format.file.format");
			objectList.addElement("format.file.fileid");
			
			
			StringList relList = new StringList();
			relList.addElement(DomainRelationship.SELECT_ID);
			relList.addElement("attribute[Route Base State].value");

			DomainObject dObject = DomainObject.newInstance(context,strObjectId);

			MapList mlRoutes = dObject.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_OBJECT_ROUTE,  //String relPattern
					DomainConstants.TYPE_ROUTE, //String typePattern
					objectList,            //StringList objectSelects,
					relList,    		   //StringList relationshipSelects,
					false,                  //boolean getTo,
					true,                  //boolean getFrom,
					(short)1,              //short recurseToLevel,
					"",   				   //String objectWhere,
					//"attribute[Route Base State].value == state_Review",             //String relationshipWhere,
					"",             //String relationshipWhere,
					0);        
			Map mTemp = null;
			String strRouteId = DomainConstants.EMPTY_STRING;
			DomainObject doRoute = null;
			for(int i=0;i<mlRoutes.size();i++){
				mTemp = (Map)mlRoutes.get(i);
				strRouteId = (String)mTemp.get(DomainObject.SELECT_ID);
				doRoute = new DomainObject(strRouteId);
				MapList mlRouteTasks = doRoute.getRelatedObjects(context,
					DomainConstants.RELATIONSHIP_ROUTE_TASK,  //String relPattern
					DomainConstants.TYPE_INBOX_TASK, //String typePattern
					objectList,            //StringList objectSelects,
					relList,    		   //StringList relationshipSelects,
					true,                  //boolean getTo,
					false,                  //boolean getFrom,
					(short)1,              //short recurseToLevel,
					"",   				   //String objectWhere,
					"",             //String relationshipWhere,
					0); 
				mlInboxTask.addAll(mlRouteTasks);
			}
			
		Iterator itr = mlInboxTask.iterator();
		while(itr.hasNext()){
			Map returnMap = (Map)itr.next();
			String strState = (String)returnMap.get(DomainConstants.SELECT_CURRENT);
			if(strState != null && !"".equals(strState) && strState.equals("Complete")){
				returnList.add(returnMap);
			}
		}			
			
		} catch (Exception e){
		
		}
		returnList.sort("attribute["+DomainConstants.ATTRIBUTE_ACTUAL_COMPLETION_DATE+"]","descending","date");
		return returnList;
	}
	
	
	public void updateOwnershipOfTCS(Context context, String[] args)throws Exception{
		try{
			String strDCSId = (String)args[0];
			String strTSId = (String)args[1];
			if(UIUtil.isNotNullAndNotEmpty(strDCSId)){
				MapList mlApprovedTaskList = (MapList)getAllApprovedTask(context,strDCSId);
				String strOwner = DomainConstants.EMPTY_STRING;
				if(mlApprovedTaskList.size()>0){
					Hashtable hashTable = (Hashtable)mlApprovedTaskList.get(0);
					String strApprover = (String)hashTable.get("from["+DomainConstants.RELATIONSHIP_PROJECT_TASK+"].to.name");
					if(UIUtil.isNotNullAndNotEmpty(strApprover)){
						strOwner = strApprover;
					}
				}
				if(UIUtil.isNotNullAndNotEmpty(strTSId) && UIUtil.isNotNullAndNotEmpty(strOwner)){
					DomainObject doTS = new DomainObject(strTSId);
					doTS.setOwner(context,strOwner);
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}		
	}
	
	/** 
	* List of Approved TS
	**/
	@com.matrixone.apps.framework.ui.IncludeOIDProgramCallable
	public StringList getAllRelatedTS(Context context,String[] args) throws Exception {
		HashMap programMap=(HashMap)JPO.unpackArgs(args);
		String sObjectId  = (String) programMap.get("objectId");
		DomainObject domObject = new DomainObject(sObjectId);
		String sSOCObjId = domObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
		DomainObject domSOCObject = new DomainObject(sSOCObjId);
		StringList busSelects = new StringList();
		busSelects.add(DomainConstants.SELECT_ID);
		String sWhere = "revision==last";
		StringList slInclude = new StringList();
		MapList sList = domSOCObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOCTS, // relationship pattern
													TYPE_WMSTECHNICALSANCTION, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
		for (int i = 0, size = sList.size(); i < size; i++) {
			Map objMap = (Map) sList.get(i);
			String sTSId = (String) objMap.get(DomainConstants.SELECT_ID);
			slInclude.add(sTSId);
		}
		return slInclude;
	}
	
	/** 
	* List of Approved TS
	**/
	@com.matrixone.apps.framework.ui.IncludeOIDProgramCallable
	public StringList getAllRelatedTSFromDCS(Context context,String[] args) throws Exception {
		HashMap programMap=(HashMap)JPO.unpackArgs(args);
		String sObjectId  = (String) programMap.get("objectId");
		DomainObject domObject = new DomainObject(sObjectId);
		String sSOCObjId = domObject.getInfo(context, "to["+RELATIONSHIP_WMSSOC_DCSMASTER+"].from.id");
		DomainObject domSOCObject = new DomainObject(sSOCObjId);
		StringList busSelects = new StringList();
		busSelects.add(DomainConstants.SELECT_ID);
		String sWhere = "revision==last";
		StringList slInclude = new StringList();
		MapList sList = domSOCObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOCTS, // relationship pattern
													TYPE_WMSTECHNICALSANCTION, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
		for (int i = 0, size = sList.size(); i < size; i++) {
			Map objMap = (Map) sList.get(i);
			String sTSId = (String) objMap.get(DomainConstants.SELECT_ID);
			slInclude.add(sTSId);
		}
		return slInclude;
	}
	
	public String showDownloadIcon(Context context,String[] args) throws Exception{
		StringBuilder sb=new StringBuilder();
		 try { 
			Map mInputMap = (Map) JPO.unpackArgs(args);
		   Map requestMap = (Map) mInputMap.get("requestMap");
		   String strObjectId = (String) requestMap.get("objectId");
		   String downloadURL = "../components/emxCommonDocumentPreCheckout.jsp?objectAction=download&objectId="+strObjectId; 
		   String strDownLoadTip="Download Bill Form";
		 
			 sb.append("<a href=\"" + downloadURL + "\"  target=\"formViewHidden\"   >");
			 sb.append("<img border=\"0\" src=\"../common/images/iconActionDownload.gif\" alt=\""
			+ strDownLoadTip + "\" title=\"" + strDownLoadTip + "\"></img></a>&#160;");
		
		 }catch(Exception e) {
			 e.printStackTrace();
		 } 
		return  sb.toString();
	 }
	 
	@com.matrixone.apps.framework.ui.ExcludeOIDProgramCallable	 
	public StringList excludeConnectedTS(Context context,String[] args)throws Exception{
		StringList slReturnList = new StringList();
		try{
			String whereExpression = "current==Approved && to["+RELATIONSHIP_WMS_WORK_ORDER_TS+"]==TRUE";
			MapList mlTSlist = DomainObject.findObjects(context, TYPE_WMSTECHNICALSANCTION, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					whereExpression, // where clause
					new StringList(DomainObject.SELECT_ID)); 
			slReturnList = WMSUtil_mxJPO.convertToStringList(mlTSlist, DomainConstants.SELECT_ID);
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
		return slReturnList;
	}
	
	private static void updateSubsequenceTSWhenRevised(Context context, DomainObject doTS)throws Exception{
		try{
			StringList slTSSelect = new StringList();
			slTSSelect.add("to["+RELATIONSHIP_WMSSOCTS+"].from.id");
			slTSSelect.add("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"].value");
			int iSequence = 1;
			Map mTSInfo = (Map)doTS.getInfo(context,slTSSelect);
			if(mTSInfo != null){
				String strSequence = (String)mTSInfo.get("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"].value");
				if(UIUtil.isNotNullAndNotEmpty(strSequence)){
					iSequence = Integer.valueOf(strSequence);
				}
				String strSOCId = (String)mTSInfo.get("to["+RELATIONSHIP_WMSSOCTS+"].from.id");
				if(UIUtil.isNotNullAndNotEmpty(strSOCId)){
					DomainObject sSOCObj = DomainObject.newInstance(context,strSOCId);
					StringList busSelects = new StringList();
					busSelects.add(DomainObject.SELECT_ID);
					busSelects.add(DomainObject.SELECT_OWNER);
					busSelects.add("attribute["+ATTRIBUTE_WMSTSAMOUNT+"].value");
					busSelects.add("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"].value");
					String sWhere = "revision==last";
					MapList sTSList = sSOCObj.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSSOCTS, // relationship pattern
														TYPE_WMSTECHNICALSANCTION, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														sWhere, // object where clause
														null);
					
					Map mTemp = null;
					String strSeqTSId = DomainConstants.EMPTY_STRING;
					String strOwner = DomainConstants.EMPTY_STRING;
					String strAmount = DomainConstants.EMPTY_STRING;
					DomainObject domNextTS = DomainObject.newInstance(context);
					for(int i=0;i<sTSList.size();i++){
						mTemp = (Map)sTSList.get(i);
						strSeqTSId = (String)mTemp.get(DomainObject.SELECT_ID);
						strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
						strAmount = (String)mTemp.get("attribute["+ATTRIBUTE_WMSTSAMOUNT+"].value");
						strSequence = (String)mTemp.get("attribute["+ProgramCentralConstants.ATTRIBUTE_SEQUENCE_ORDER+"].value");
						domNextTS.setId(strSeqTSId);
						if(Integer.valueOf(strSequence)>iSequence){
							BusinessObject boTS = domNextTS.reviseObject(context, true);
							domNextTS = new DomainObject(boTS);
							domNextTS.setOwner(context, strOwner);
							domNextTS.setAttributeValue(context, ATTRIBUTE_WMSTSAMOUNT,strAmount);
							WMSDownloadTSForm_mxJPO.generateTSForm(context, new String[] {(String)domNextTS.getInfo(context,DomainObject.SELECT_ID)});
							domNextTS.setId(strSeqTSId);
							domNextTS.setState(context, STATE_WMSTECHNICALSANCTION_OBSOLETE, true);
						}
					}
				}
			}
			
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
 }