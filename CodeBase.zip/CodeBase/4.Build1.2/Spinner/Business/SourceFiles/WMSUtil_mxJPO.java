/** Name of the JPO    : WMSUtil
 ** Developed by    :  
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to use utilities created for code.
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/

 
 
import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import java.util.ListIterator;
import java.io.BufferedInputStream;
import java.util.Properties;
import java.io.ByteArrayInputStream;
import java.text.DecimalFormat;
import java.math.RoundingMode;
import java.util.Locale;
import java.text.NumberFormat;
import java.text.Format;

import com.matrixone.apps.common.Person;
import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.framework.ui.UICache;
import com.matrixone.apps.common.MemberRelationship;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.mxAttr;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.CacheUtil;
import com.matrixone.apps.domain.util.ContextUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.SelectList;
import matrix.util.StringList;
import matrix.db.BusinessObject;
import matrix.util.MatrixException;
import matrix.db.RelationshipType;
import matrix.db.Policy;
//Added for eSign
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.security.DigestInputStream;
import java.security.MessageDigest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;


/**
 * The purpose of this JPO is to use utilities created
 * @author 
 * @version R418 - Copyright (c) 1993-2016 Dassault Systems.
 */
public class WMSUtil_mxJPO extends WMSConstants_mxJPO 
{
	 


    /**
     * Constructor.
     * @param context the eMatrix Context object
     * @param strArguments holds the following input arguments[0]-id of the business object
     * @throws Exception if the operation fails    
     * @since 418
     */
    public WMSUtil_mxJPO (Context context, String[] args) throws Exception
    {
         super(context,args);
    }
    /**
     * Main entry point.
     *
     * @param context
     *            the eMatrix <code>Context</code> object
     * @param args
     *            holds no arguments
     * @return an integer status code (0 = success)
     * @throws Exception
     *             if the operation fails
     * @since 418
     */
    public int mxMain(Context context, String[] args) throws Exception {
        if (!context.isConnected())
            throw new Exception("Not supported on desktop client");
        return 0;
    }


    /**
     * Method to get Map  based on Key and Value
     * 
     * @param mapListObjects Maplist containing the Object data  
     * @param strKey String value containing the Key to identify the data
     * @param strValue String value to filter data
     * @return mapListSubSet MapList containing the Data based on Key and Value
     * @author WMS
     * @since R418 ///////////////USED
     */
    public static Map<String,String> getMap(MapList mapListObjects, String strKey,
            String strValue) {
        Iterator<Map<String,String>> iteratorMBEs = mapListObjects.iterator();
        Map<String,String> mapData;
        while(iteratorMBEs.hasNext())
        {
        	mapData = iteratorMBEs.next();
            String strKeyValue = mapData.get(strKey);
            if(strValue.equalsIgnoreCase(strKeyValue))
            {
            	return mapData;
            }
        }
        return new HashMap<String,String>();
    }

        /**
     * Method to get the context object OID from the args.
     *
     * @param args Packed program and request maps from the command or form or table
     * @return a string containing the object ID
     * @author WMS
     * @throws Exception if the operation fails 
     * @since 418
     */
    public static String getContextObjectOIDFromArgs(String[] args) throws Exception {
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String strObjectId = (String) programMap.get("objectId");
            if(UIUtil.isNullOrEmpty(strObjectId)) {
                strObjectId = (String) programMap.get("mbeOID");
            }
            return strObjectId;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

    /**
     * method get the basic bus info for the general class
     *
     * @return selListBusSelects SelectList containing the bus selects : type name revision policy vault
     * @author WMS
     * @since 418
     */
    public static SelectList getSubClassBusSelect() {
        SelectList selListBusSelects     = new SelectList(6);
        selListBusSelects.add(DomainConstants.SELECT_ID);
        selListBusSelects.add(DomainConstants.SELECT_POLICY);
        selListBusSelects.add(DomainConstants.SELECT_DESCRIPTION);
        selListBusSelects.add(DomainConstants.SELECT_VAULT);
        selListBusSelects.add(DomainConstants.SELECT_TYPE);
        selListBusSelects.add(DomainConstants.SELECT_NAME);
        return selListBusSelects;
    }

    /**
     * This method checks whether the given value is numeric or not
     *
     * @param String holds value to validate for numeric
     *
     * @return boolean holds true if value is numeric
     *                       false if value is not numeric
     * @throws Exception if the operation fails.
     */
    public static boolean isNumeric(String sValue)
    {
        try
        {
            Double.parseDouble(sValue);
        }
        catch(NumberFormatException nfe)
        {
            return false;
        }
        return true;
    }


/**
     * Access function for formType of Work Order to make it editable
     * @param context The Matrix Context object
     * @param args holds the arguments:     
     * @throws Exception if the operation fails
     */ 
    public boolean isCreateModeFormType(Context context, String[] args) throws Exception 
    {
        try
        {
            boolean bAccess	= false;
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strMode = (String) programMap.get("mode");
            if(UIUtil.isNotNullAndNotEmpty(strMode))
            {
                if("create".equals(strMode)){ 
                    bAccess= false;
                }
                else
                {
                    bAccess= true;
                }
            }
            return bAccess;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }


    public boolean isCreateModeHideField(Context context, String[] args) throws Exception 
    {
        try
        {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strMode = (String) programMap.get("mode");
            if(UIUtil.isNotNullAndNotEmpty(strMode))
            {
                if("create".equals(strMode)|| "edit".equals(strMode)){ 
                    return false;
                }
                else
                {
                    return true;
                }
                
            }
            return false;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

    /**
     * Access function for formType of Work Order to make it editable
     * @param context The Matrix Context object
     * @param args holds the arguments:     
     * @throws Exception if the operation fails
     */ 
    public boolean isCreateModeShowField(Context context, String[] args) throws Exception 
    {
        try
        {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strMode = (String) programMap.get("mode");
                       
            if(UIUtil.isNotNullAndNotEmpty(strMode))
            {
                if("create".equals(strMode)){ 
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

    /**
    * Access function for Project Description on Work Order Properties
    * @param context The Matrix Context object
    * @param args holds the arguments:     
    * @throws Exception if the operation fails
    */ 
   public boolean isCreateModeForProjectNameFields(Context context, String[] args) throws Exception 
   {
       try
       {
           HashMap programMap = (HashMap) JPO.unpackArgs(args);
           String strMode = (String) programMap.get("mode");
           if(UIUtil.isNotNullAndNotEmpty(strMode))
           {
               if("view".equals(strMode)){ 
                   return true;
               }
               else
               {
                   return false;
               }
               
           }
           return false;
       }
       catch(Exception exception)
       {
           exception.printStackTrace();
           throw exception;
       }
   }


    /**
     * Method will convert a string to Integer
     *
     * @param strValue String containing the real value
     * @return doubleValue double value of String
     * @author WMS
     * @since 418
     */
    public static int convertToInteger(String strValue) {
        int intValue = 0;
        try
        {

            if(UIUtil.isNullOrEmpty(strValue))
            {
                strValue = "-1";
            }
            intValue=  Integer.parseInt(strValue);
        }
        catch(Exception exception)
        {
            intValue = -1;
        }
        return intValue;
    }


    /**
     * Returns ematrix Date display format for Forms
     * @author WMS
     * @throws Exception 
     * @since 418
     **/
    public String getEmatrixDateFormat(Context context, String[] args) throws Exception
    {
        String strFormattedDate = "";
        try{                
                HashMap programMap          = (HashMap)JPO.unpackArgs(args);
                String strDateForFormat = (String)programMap.get("Date");
                
                Calendar calendarDate = Calendar.getInstance();
                long lDateForFormat=Long.parseLong(strDateForFormat);
                calendarDate.setTimeInMillis(lDateForFormat);
                SimpleDateFormat simpleDateFormatMatrix  = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(),context.getLocale());
                strFormattedDate = simpleDateFormatMatrix.format(calendarDate.getTime());
                
                Date dStartDate=simpleDateFormatMatrix.parse(strFormattedDate);				
                DateFormat dateFormat = DateFormat.getDateInstance(eMatrixDateFormat.getEMatrixDisplayDateFormat(),context.getLocale());
                strFormattedDate = dateFormat.format(dStartDate);
                
        }
        catch(Exception exception) 
        {
            exception.printStackTrace();
            throw exception;
        }
        return strFormattedDate;
    }

    public boolean isEditModeShowField(Context context, String[] args) throws Exception 
    {
        try
        {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strMode = (String) programMap.get("mode");
            if(UIUtil.isNotNullAndNotEmpty(strMode))
            {
                if("edit".equals(strMode)){ 
                    return true;
                }
                else
                {
                    return false;
                }
                
            }
            return false;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
    
    
    /**
     * Gets the Departments for the context user
     * @param context The Matrix Context.
     * @param args
     * @return maplist of Departments
     * @throws Exception If the operation fails.
     * @author WMS
     * @since 418
     */
     @com.matrixone.apps.framework.ui.ProgramCallable
     public static MapList getContextUserDepartment (Context context) throws Exception
     {
    	 MapList mapListDepartment = new MapList();
    	 StringList strListBusSelects = new StringList(2);
    	 strListBusSelects.addElement(DomainConstants.SELECT_ID);
    	 strListBusSelects.addElement(DomainConstants.SELECT_NAME);
    	 StringList strListRelSelects = new StringList(1);
    	 strListRelSelects.addElement(DomainConstants.SELECT_RELATIONSHIP_ID);
    	 try 
    	 {
    		 String strPersonId = PersonUtil.getPersonObjectID(context);
    		 Person person =(Person)DomainObject.newInstance(context,DomainConstants.TYPE_PERSON);
    		 person.setId(strPersonId);
    		 mapListDepartment = person.getRelatedObjects(context, // matrix context
    				 DomainConstants.RELATIONSHIP_MEMBER, // relationship pattern
    				 DomainConstants.TYPE_DEPARTMENT, // type pattern
    				 strListBusSelects, // object selects
    				 strListRelSelects, // relationship selects
    				 true, // to direction
    				 false, // from direction
    				 (short) 1, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
    	 }
    	 catch (Exception exception) 
    	 {
    		 exception.printStackTrace();
    		 throw exception;
    	 }
    	 return mapListDepartment;
     }

     /**
     * Connects an object with many others using the given relationship type. 
     * 
     * @param context the eMatrix <code>Context</code> object 
     * @param givenObject the object to connect to the list passed in
     * @param relationshipType The relationship type used for the connection
     * @param isFrom this is a from connection of the given object (true) or to the given object (false)
     * @param arrayListClonedTCIds is array list containing the businessobject ids to connect to given object
     * @return a map of related ids as keys and connection ids as values
     * @throws FrameworkException - if the operation fails
     * @author WMS
     * @since R418
     */
     public static Map connect(Context context, DomainObject givenObject,
	     String relationshipType, boolean isFrom,
	     ArrayList<String> arrayListClonedTCIds) throws FrameworkException {
	     try
		     {
		     if(arrayListClonedTCIds.size()>0)
		     {
		     int intSize = arrayListClonedTCIds.size();
		     String [] strTCIds = arrayListClonedTCIds.toArray(new String[intSize]);
		     return DomainRelationship.connect(context, givenObject,relationshipType, isFrom, strTCIds);
		     }
		     }
		     catch(FrameworkException frameworkException)
		     {
		     frameworkException.printStackTrace();
		     throw frameworkException;
		     }
	     return new HashMap();
     }
    
     /** 
      * Method will generates a StringList of value for a particular key from each map of MapList 
      * @param mapListObject holds the MapList of Objects
      * @param strKey holds the Key value
      * @return strListValues list of value from MapList for the given Key 
      * @author WMS
      * @since 418
      */
     public static StringList convertToStringList(MapList mapListObject, String strKey) {
         StringList strListValues = new StringList(mapListObject.size());
         Iterator iterator = mapListObject.iterator();
         while(iterator.hasNext())
         {
             Map<String,String> mapObject = (Map<String,String>)iterator.next();
             strListValues.add(mapObject.get(strKey));
         }
         return strListValues;
     }
	/** 
     * Method to check the User Company
     * @
     * @author WMS
     * @since 418
     */
	public boolean isEmployee(Context context, String[] args)throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Boolean isSupplierRepresentative = context.isAssigned(DomainConstants.ROLE_SUPPLIER_REPRESENTATIVE );
		boolean bAccess = false;
		try
		{       
				if(isSupplierRepresentative){
					bAccess=false;
				}
				else
				{
					bAccess=true ;
				}
		}catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return bAccess;
	}
	
	
	/** 
     * Method to check the if context user is supplier representative
     * @
     * @author WMS
     * @since 418
     */
	public boolean isSupplierRepresentative(Context context,String[] args) throws Exception{
		return !(isEmployee(context,args));
	
	}
	
	
	/**
	   * Display drop Icon.
	   * @param context - The eMatrix <code>Context</code> object.
	   * @param args - The args holds information about object.
	   * @return list of drop icon.
	   * @throws Exception if operation fails.
	   */
	  public StringList columnDropZone(Context context, String[] args) throws Exception 
	  {
	    StringList dropIconList = new StringList();
	    emxGenericColumns_mxJPO genericColumn = new emxGenericColumns_mxJPO(context,args);
	    Vector columnIconList = genericColumn.columnDropZone(context, args);
	    
	    Map programMap         = (HashMap) JPO.unpackArgs(args);
	    MapList objectList  = (MapList)programMap.get("objectList");
	    
	    if(objectList != null && objectList.size()>0){
	        
	    String[] objectIdArray = new String[objectList.size()];
	    for (int i=0; i<objectList.size(); i++) {
	            Map objectMap = (Map) objectList.get(i);
	            String objectId = (String)objectMap.get(DomainObject.SELECT_ID);
	            objectIdArray[i] = objectId;
	        }
	    
	        StringList dropAccesList = new StringList(3);
	        dropAccesList.addElement("modify");
	        dropAccesList.addElement("fromconnect");
	        dropAccesList.addElement("toconnect");
	        
	        StringList busSelect = new StringList(3);
	        busSelect.addElement("current.access");
	        busSelect.addElement(DomainObject.SELECT_TYPE);
	    
	    MapList objectInfoList = DomainObject.getInfo(context, objectIdArray, busSelect);
	    Iterator itrObj = objectInfoList.iterator();
	    Iterator itrIcon = columnIconList.iterator();
	    while(itrObj.hasNext()&&itrIcon.hasNext()){
	            Map objectMap = (Map)itrObj.next();
	            String dropIcon = (String)itrIcon.next();
	        
	            String access = (String)objectMap.get("current.access");
	            String strObjeType = (String)objectMap.get(DomainObject.SELECT_TYPE);
	            
	            boolean showDropIcon = false;
	            StringList currentAccessList = new StringList();
	            if(ProgramCentralUtil.isNotNullString(access)&& !access.equalsIgnoreCase("all") && TYPE_WMS_MEASUREMENTS.equals(strObjeType)){
	                currentAccessList = FrameworkUtil.split(access, ProgramCentralConstants.COMMA);
	                
	                if(currentAccessList.containsAll(dropAccesList)){
	                    showDropIcon = true;
	                }
	            }else if(access.equalsIgnoreCase("all") && TYPE_WMS_MEASUREMENTS.equals(strObjeType)){
	                showDropIcon = true;
	            }
	        
	            if(showDropIcon){
	                dropIconList.addElement(dropIcon);
	              }else{
	                  dropIconList.addElement(DomainObject.EMPTY_STRING);
	              }
	    }
	    }
	    return dropIconList;
	    
	  }
	 
	  /**
	     * disconnects an arraylist of relationship IDs
	     * 
	     * @param context the eMatrix <code>Context</code> object 
	     * @param arrayListClonedTCIds is array list containing Classified Item relationship IDs
	     * @throws FrameworkException - if the operation fails
	     * @author WMS
	     * @since R418
	     */
	    public static void disconnect(Context context,
	            ArrayList<String> arrayListRelationshipIDs)
	                    throws FrameworkException {
	        try
	        {
	            int intSize = arrayListRelationshipIDs.size();
	            if(intSize>0)
	            {
	                String [] strReqRelIds = arrayListRelationshipIDs.toArray(new String[intSize]);

	                DomainRelationship.disconnect(context,strReqRelIds);
	            }
	        }
	        catch(FrameworkException frameworkException)
	        {
	            frameworkException.printStackTrace();
	            throw frameworkException;
	        }
	    }
	    
	    
	    
	    /**
	     * Method will convert a string to double
	     *
	     * @param strValue String containing the real value
	     * @return doubleValue double value of String
	     * @author WMS
	     * @since 418
	     */
	    public static double convertToDouble(String strValue) {
	        double doubleValue = 0d;
	        try
	        {
	        	 if(UIUtil.isNullOrEmpty(strValue))
	             {
	                 strValue = "0.0";
	             }
	            
	             int iLangthAfterdecimal     =     0;
	             try
	             {
	                   iLangthAfterdecimal    =     strValue.substring(strValue.indexOf(".")+1, strValue.length()).length();
	             }
	             catch(Exception ex)
	             {
	                
	             }

	             doubleValue=  Double.parseDouble(strValue);
	             BigDecimal bigdecimal = new BigDecimal(doubleValue);
	             if(iLangthAfterdecimal == 2 || iLangthAfterdecimal == 3)
	             {
	                  bigdecimal = bigdecimal.setScale(iLangthAfterdecimal , BigDecimal.ROUND_HALF_EVEN);
	                  String strbigdecimal = bigdecimal.toPlainString();
	                  doubleValue=  Double.parseDouble(strbigdecimal);
	             }
	             else
	             {
	                 if(iLangthAfterdecimal > 3)
	                 {
	                     bigdecimal = bigdecimal.setScale(3 , BigDecimal.ROUND_HALF_EVEN);
	                     String strbigdecimal = bigdecimal.toPlainString();
	                     doubleValue=  Double.parseDouble(strbigdecimal);
	                 }                 
	             }            
	        	
	        }
	        catch(Exception exception)
	        {
	            doubleValue = 0d;
	        }
	        return doubleValue;
	    }
	    
	    
	    
	    /** 
	     * Method to check route exist on particular state
	     * @param context the eMatrix <code>Context</code> object
	     * @param domObj context object
	     * @param strRelWhere where condition to check on particular state
	     * @throws Exception if the operation fails
	     * @return MapList list of route objects exists
	     * @author WMS
	     * @since 418
	     */
	    public static MapList checkForExistingRouteObject(Context context,DomainObject domObj,
	            String strRelWhere) throws Exception {
	        MapList mlRoutes=new MapList();

	        try {
	            StringList busSelects = new StringList(4);
	            busSelects.add(DomainConstants.SELECT_ID);
	            busSelects.add(DomainConstants.SELECT_OWNER);
	            busSelects.add(DomainConstants.SELECT_CURRENT);
	            busSelects.add("attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]");
	            mlRoutes = domObj.getRelatedObjects(context,
	                    DomainConstants.RELATIONSHIP_OBJECT_ROUTE,
	                    DomainConstants.TYPE_ROUTE, busSelects, null, false, true,
	                    (short) 1,strRelWhere, DomainConstants.EMPTY_STRING, 0);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return mlRoutes;
	    }
	    
	    /** 
	     * Method to restart the existing route 
	     * @param context the eMatrix <code>Context</code> object
	     * @param routeMapList list of existing route objects
	     * @throws Exception if the operation fails
	     * @author WMS
	     * @since 418
	     */
	    public static void restartExistingRoute(Context context, MapList routeMapList) throws Exception {
	        boolean isContextPushed = false;
			try {
				ContextUtil.pushContext(context);
				isContextPushed = true;
	            Iterator iterator = routeMapList.iterator();
	            Route objRoute = (Route) DomainObject.newInstance(context,
	                    Route.TYPE_ROUTE);
	            while (iterator.hasNext()) {

	                Map<String, String> mRoute = (Map<String, String>) iterator
	                        .next();
	                String sOIDRoute = (String) mRoute
	                        .get(DomainConstants.SELECT_ID);
	                objRoute.setId(sOIDRoute);
	                objRoute.resume(context);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }finally{
				if(isContextPushed)
					ContextUtil.popContext(context);
				}
	    }
	    
	    
	    /** 
	     * Method will generates a StringList from object 
	     * @param mapListObject holds the MapList of Objects
	     * @param strKey holds the Key value
	     * @return strListValues list of value from MapList for the given Key 
	     * @author WMS
	     * @since 418
	     */
	    public static StringList convertToStringList(Object obj) {
	        StringList strListValues = new StringList();
	        if(obj instanceof StringList)
	        {
	      	  strListValues = (StringList)obj;
	        }
	        else
	        {
	      	  if(UIUtil.isNotNullAndNotEmpty((String)obj))
	      	  {
	      		  strListValues.add((String)obj);
	      	  }
	        }
	        
	        return strListValues;
	    }
	    /**
	     * Method to get Map List based on Key and Value
	     * 
	     * @param mapListObjects Maplist containing the Object data  
	     * @param strKey String value containing the Key to identify the data
	     * @param strValue String value to filter data
	     * @return mapListSubSet MapList containing the Data based on Key and Value
	     * @author WMS
	     * @since R418
	     */
	    public static MapList getSubMapList(MapList mapListObjects, String strKey,
	            String strValue) {
	        MapList mapListSubSet = new MapList(mapListObjects.size());
	        Iterator<Map<String,String>> iteratorMBEs = mapListObjects.iterator();
	        Map<String,String> mapData;
	        while(iteratorMBEs.hasNext())
	        {
	        	mapData = iteratorMBEs.next();
	            String strKeyValue = mapData.get(strKey);
	            if(strValue.equalsIgnoreCase(strKeyValue))
	            {
	                mapListSubSet.add(mapData);
	            }
	        }
	        return mapListSubSet;
	    }
	    
	    /**
	     * Method will set rate value to two decimal points 
	     *
	     * @param strRelId String containing relationship id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     */
	    public static int convertToDoubleRateForRel(Context context ,  String [] args) {
	        double doubleValue = 0.00d;
	        try
	        {
	        	String strRelId 	 = args[0];
	        	String strAttributeNewVlaue = args[1];
	        	String strAttributeName  = args[2];
	        	if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	            {
	        		strAttributeNewVlaue = "0.00";
	            }
	        	int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	        	if(iLangthAfterdecimal > 2){ 
	            doubleValue=  Double.parseDouble(strAttributeNewVlaue);
	            BigDecimal bigdecimal = new BigDecimal(doubleValue);
	            bigdecimal = bigdecimal.setScale(2  , BigDecimal.ROUND_HALF_EVEN);
	            String strbigdecimal = bigdecimal.toPlainString();
	            doubleValue=  Double.parseDouble(strbigdecimal);
	            strAttributeNewVlaue = String.valueOf(doubleValue);
	        	}
	        	if(UIUtil.isNotNullAndNotEmpty(strRelId)){
	            DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	        	}
	        }
	        catch(Exception exception)
	        {
	            exception.printStackTrace();
	        }
	         return 0;
	    }
	    
	    
	    /**
	     * Method will set Quantity value to three decimal points 
	     *
	     * @param strObjId String containing object id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     */
	    public static int convertToDoubleQuantity(Context context ,  String [] args) {
	        double doubleValue = 0.000d;
	        try
	        {
	        	String strObjectIds 	 = args[0];
	        	String strAttributeNewVlaue = args[1];
	        	String strAttributeName  = args[2];
	        	if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	            {
	        		strAttributeNewVlaue = "0.000";
	            }
	        	int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	        	if(iLangthAfterdecimal > 3){
	            doubleValue=  Double.parseDouble(strAttributeNewVlaue);
	            BigDecimal bigdecimal = new BigDecimal(doubleValue);
	            bigdecimal = bigdecimal.setScale(3  , BigDecimal.ROUND_HALF_EVEN);
	            String strbigdecimal = bigdecimal.toPlainString();
	            doubleValue=  Double.parseDouble(strbigdecimal);
	            strAttributeNewVlaue = String.valueOf(doubleValue);
	        	}
	        	if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	        		DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	        		domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	        	}
	        }
	        catch(Exception exception)
	        {
	        	exception.printStackTrace();
	        }
	         return 0;
	    }
	    
	    /**
	     * Method will set Rate value to two decimal points 
	     *
	     * @param strObjId String containing object id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     */
	    public static int convertToDoubleRate(Context context ,  String [] args) {
	        double doubleValue = 0.00d;
	        try
	        {
	        	String strObjectIds 	 	= args[0];
	        	String strAttributeNewVlaue = args[1];
	        	String strAttributeName  	= args[2];
	        	if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	            {
	        		strAttributeNewVlaue = "0.00";
	            }
	        	int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	        	if(iLangthAfterdecimal > 2){            
	            doubleValue			  = Double.parseDouble(strAttributeNewVlaue);
	            BigDecimal bigdecimal = new BigDecimal(doubleValue);
	            bigdecimal 			  = bigdecimal.setScale(2,BigDecimal.ROUND_HALF_EVEN);
	            String strbigdecimal  = bigdecimal.toPlainString();
	            doubleValue			  = Double.parseDouble(strbigdecimal);
	            strAttributeNewVlaue = String.valueOf(doubleValue);
	        	}
	        	if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	        		DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	        		domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	        	}
	        }
	        catch(Exception exception)
	        {
	            doubleValue = 0d;
	        }
	         return 0;
	    }
	    
	    
	    /**
	     * Method will set Quantity value to three decimal points 
	     *
	     * @param strObjId String containing object id/Rel id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     * */
	    public static int convertToDoubleObjRelQty(Context context ,  String [] args) {
	    	double doubleValue = 0.000d;
	    	try
	    	{/*
	    		String strObjectIds 	 = args[0];
	    		String strAttributeNewVlaue = args[1];
	    		String strAttributeName  = args[2];
	    		String strRelId  = args[3];
	    		if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	    		{
	    			strAttributeNewVlaue = "0.000";
	    		}
	    		int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	    		if(iLangthAfterdecimal > 3){
	    			doubleValue=  Double.parseDouble(strAttributeNewVlaue);
	    			BigDecimal bigdecimal = new BigDecimal(doubleValue);
	    			bigdecimal = bigdecimal.setScale(3  , BigDecimal.ROUND_HALF_EVEN);
	    			String strbigdecimal = bigdecimal.toPlainString();
	    			doubleValue=  Double.parseDouble(strbigdecimal);
	    			strAttributeNewVlaue = String.valueOf(doubleValue);
	    			if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	    				DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	    				//domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	    			}
	    			else
	    			{
	    				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
	    					DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	    				}

	    			}
	    		}
	    		else{
	    			if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	    				DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	    				domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	    			}
	    			else
	    			{
	    				if(UIUtil.isNotNullAndNotEmpty(args[3])){
	    					DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	    				}

	    			}
	    		}

	    	*/}
	    	catch(Exception exception)
	    	{
	    		exception.printStackTrace();
	    	}
	    	return 0;
	    }
	  
	    
	    /**
	     * Method will set Rate value to two decimal points 
	     *
	     * @param strObjId String containing object id/Rel id
	     * @param strValue String containing new value
	     * @param strAttributeName String containing attribute name
	     * @return int flag for trigger
	     * @author WMS
	     * @since 418
	     */
	    public static int convertToDoubleObjRelRate(Context context ,  String [] args) {
	        
	        double doubleValue = 0.00d;
	    	try
	    	{
	    		String strObjectIds 	 	= args[0];
	    		String strAttributeNewVlaue = args[1];
	    		String strAttributeName  	= args[2];
	    		String strRelId = args[3];
	    		if(UIUtil.isNullOrEmpty(strAttributeNewVlaue))
	    		{
	    			strAttributeNewVlaue = "0.00";
	    		}
	    		int iLangthAfterdecimal    =     strAttributeNewVlaue.substring(strAttributeNewVlaue.indexOf(".")+1, strAttributeNewVlaue.length()).length();
	    		if(iLangthAfterdecimal > 2){

	    			doubleValue			  = Double.parseDouble(strAttributeNewVlaue);
	    			BigDecimal bigdecimal = new BigDecimal(doubleValue);
	    			bigdecimal 			  = bigdecimal.setScale(2  , BigDecimal.ROUND_HALF_EVEN);
	    			String strbigdecimal  = bigdecimal.toPlainString();
	    			doubleValue			  = Double.parseDouble(strbigdecimal);
	    			strAttributeNewVlaue = String.valueOf(doubleValue);
	    			if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	    				DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	    				domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	    			}
	    			else
	    			{
	    				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
	    					DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	    				}

	    			}
	    		}
	    		else
	    		{
	    			if(UIUtil.isNotNullAndNotEmpty(strObjectIds)){
	    				DomainObject domObj = DomainObject.newInstance(context ,  strObjectIds);
	    				domObj.setAttributeValue(context, strAttributeName, strAttributeNewVlaue);
	    			}
	    			else
	    			{
	    				if(UIUtil.isNotNullAndNotEmpty(strRelId)){
	    					DomainRelationship.setAttributeValue(context, strRelId, strAttributeName, strAttributeNewVlaue);
	    				}

	    			}
	    		}
	    	}
	    	catch(Exception exception)
	    	{
	    		exception.printStackTrace();
	    	}
	    	return 0;
	    }
	    
/**

      * Gets the Departments for the context user
      * @param context The Matrix Context.
      * @param args
      * @return maplist of Departments
      * @throws Exception If the operation fails.
      * @author WMS
      * @since 418
      */
      @com.matrixone.apps.framework.ui.ProgramCallable
      public static MapList getContextUserDepartmentCGRDC (Context context, String[] args) throws Exception
      {
     	 MapList mapListDepartment = new MapList();
     	 StringList strListBusSelects = new StringList(2);
     	 strListBusSelects.addElement(DomainConstants.SELECT_ID);
     	 strListBusSelects.addElement(DomainConstants.SELECT_NAME);
     	 StringList strListRelSelects = new StringList(1);
     	 strListRelSelects.addElement(DomainConstants.SELECT_RELATIONSHIP_ID);
     	 try 
     	 {
     		 String strPersonId = PersonUtil.getPersonObjectID(context);
     		 Person person =(Person)DomainObject.newInstance(context,DomainConstants.TYPE_PERSON);
     		 person.setId(strPersonId);
     		 mapListDepartment = person.getRelatedObjects(context, // matrix context
     				 DomainConstants.RELATIONSHIP_MEMBER, // relationship pattern
     				 DomainConstants.TYPE_COMPANY, // type pattern
     				 strListBusSelects, // object selects
     				 strListRelSelects, // relationship selects
     				 true, // to direction
     				 false, // from direction
     				 (short) 1, // recursion level
     				 DomainConstants.EMPTY_STRING, // object where clause
     				 DomainConstants.EMPTY_STRING, // relationship where clause
     				 0);
     	 }
     	 catch (Exception exception) 
     	 {
     		 exception.printStackTrace();
     		 throw exception;
     	 }
     	 return mapListDepartment;
      }


/** 
     * Method will create new route object and connect route Object to User
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @throws FrameworkException if the operation fails
     * @return objRoute route object
     * @author WMS 
     * @since 418
     */

    public static Route createAndConnectRoute(Context context, String[] args, String strRouteBasePurpose)
            throws FrameworkException {
        try
        {
            Route objRoute = (Route) DomainObject.newInstance(context,
                    Route.TYPE_ROUTE);
            String strRouteId = createRoute(context);
            objRoute.setId(strRouteId);
            connectRouteToContextObject(context, args, objRoute, strRouteBasePurpose);
            setRouteAttributes(context, objRoute, strRouteBasePurpose);
            return objRoute;
        }
        catch(FrameworkException exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }	 

	
	 public static String createRoute(Context context) throws FrameworkException {
        String strRouteId = FrameworkUtil.autoName(context,
                "type_Route",
                "policy_Route");
        return strRouteId;
    }
 /** 
     * Method to connect route object to Context object
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps for the table
     * @param strRouteBasePurpose route object purpose
     * @throws FrameworkException if the operation fails
     * @author WMS 
     * @since 418
     */
    public static void connectRouteToContextObject(Context context, String[] args,
            Route objRoute, String strRouteBasePurpose) throws FrameworkException {
        String strGenralCalssID = args[0];

        String strSymbolicPolicyName = UICache.getSymbolicName(context, args[1], "policy");
        String strSymbolicStateName = args[2];
        HashMap<String, String> attrMap = new HashMap<String, String>();
        attrMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,
                strSymbolicStateName);
        attrMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,
                strSymbolicPolicyName);
        attrMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE, strRouteBasePurpose);
        RelationshipType relationshipType = new RelationshipType(
                DomainConstants.RELATIONSHIP_OBJECT_ROUTE);
        DomainRelationship domainRelationship = objRoute.addFromObject(context,
                relationshipType, strGenralCalssID);

        domainRelationship.setAttributeValues(context, attrMap);
    }	
	
	 public static void setRouteAttributes(Context context, Route objRoute, String strRouteBasePurpose)
            throws FrameworkException {
        try {
            Map<String, String> mpRouteAttributeMap = new HashMap<String, String>();
            mpRouteAttributeMap.put(
                    DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,
                    strRouteBasePurpose);
            mpRouteAttributeMap.put(
                    ATTRIBUTE_ROUTE_COMPLETION_ACTION, "Promote Connected Object");
            objRoute.setAttributeValues(
                    context, mpRouteAttributeMap);

        } catch (FrameworkException e) {
            e.printStackTrace();
        }
    }

	 public static void connectProjectRoute(Context context, Route objRoute,BusinessObject personObject)
            throws FrameworkException, MatrixException {
        try{
            objRoute.connect(context,new RelationshipType(DomainObject.RELATIONSHIP_PROJECT_ROUTE),true, personObject);
        }catch(FrameworkException e){
            e.printStackTrace();
        }
        catch(MatrixException e){
            e.printStackTrace();
        }
    }
	
	
	 /** 
     * Method to restart the existing route 
     * @param context the eMatrix <code>Context</code> object
     * @param domObjTestExecution context domain object
     * @param strPersonName person name to crate route and assign task
     * @param strRouteBasePurpose Route base purpose
     * @param strRouteAction defining route action to the person
     * @throws FrameworkException if the operation fails
     * @return taskMapList list of tasks assigned to the particular person
     * @author WMS
     * @since 418
     */
    public static MapList getRouteTaskMapListForObject(Context context, DomainObject domObjTestExecution, String strPersonName, String strRouteBasePurpose, String strRouteAction)
            throws FrameworkException {
        MapList taskMapList= new MapList();
        try{
            String strPersonId = PersonUtil.getPersonObjectID(context,strPersonName);

            String strTitle = domObjTestExecution.getInfo(context,"attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
            HashMap<String, String> taskMap=new HashMap<String, String>();
            taskMap.put("PersonId", strPersonId);
            taskMap.put("PersonName", strPersonName);
            taskMap.put(Route.ATTRIBUTE_TITLE, strTitle);
            taskMap.put(Route.ATTRIBUTE_ROUTE_ACTION, strRouteAction);
            taskMap.put(Route.ATTRIBUTE_ROUTE_INSTRUCTIONS, "Please Review and Approve");
            taskMap.put(Route.ATTRIBUTE_ROUTE_SEQUENCE, "1");
            taskMap.put(Route.ATTRIBUTE_ROUTE_BASE_PURPOSE, strRouteBasePurpose);
            if(strRouteBasePurpose.equals("Standard")){
                taskMap.put(Route.ATTRIBUTE_ALLOW_DELEGATION, "True");
            }else{
            taskMap.put(Route.ATTRIBUTE_ALLOW_DELEGATION, "false");
            }
            taskMap.put(Route.SELECT_NAME, strPersonName);

            taskMap.put(DomainObject.ATTRIBUTE_REVIEW_TASK, "No");
            taskMap.put(DomainObject.ATTRIBUTE_DUEDATE_OFFSET, "3");
            taskMap.put(DomainObject.ATTRIBUTE_DATE_OFFSET_FROM, "Task Create Date");
            taskMap.put(DomainObject.RELATIONSHIP_ROUTE_NODE, strPersonId);
            taskMap.put("access", "Add Remove");
            taskMap.put(DomainConstants.SELECT_ID, strPersonId);
            taskMapList.add(taskMap);
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return taskMapList;
    }

	 /**
     * Returns a filter Project Members list By the role mentioned in the argument
     * @param strRoleName StringList containing value roles (Schema Name)
     * @param membersList MapList containing list of Project Member
     * @return strListMembers String containing filter Project Members names assigned with the role
     * @author WMS
     * @since 418
     **/
    public static StringList filterMembersByRoles(StringList slRoleName,MapList membersList) {
        StringList strListMembers = new StringList();
        ListIterator<String> listIteratorRoles = slRoleName.listIterator();
        while(listIteratorRoles.hasNext())
        {
        	String strRole = listIteratorRoles.next();
        if(membersList!=null && membersList.size()>0)
        {
            ListIterator<Map<String,String>> membersItr = membersList.listIterator();
            Map<String,String> memberMap;
            while(membersItr.hasNext())
            {
            	memberMap = membersItr.next();
        			String strProjectRole = (String)memberMap.get(MemberRelationship.SELECT_PROJECT_ROLE);
                String strRoleUser = (String)memberMap.get(Person.SELECT_NAME);

        			if (strRole.equalsIgnoreCase(strProjectRole))
                {
                    strListMembers.add(strRoleUser);
        				break;
        			}
                }
            }
        }
        return strListMembers;
    }
	
	
	public static void createRouteFromTemplate(Context context, String strObjectId, String strTemplateId, String strPolicy, String strTargetStateName, String strSourceState)throws Exception{
		try {
		
			
			Route newRouteObj = null;
			String strMessage =  DomainObject.EMPTY_STRING;
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)) {
				DomainObject doObject = new DomainObject(strObjectId);
				StringList slObjectSelect = new StringList(DomainObject.SELECT_ID);
				slObjectSelect.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelect.add(DomainObject.SELECT_CURRENT);
				slObjectSelect.add(DomainObject.SELECT_POLICY);

				Map mObjInfo = doObject.getInfo(context,slObjectSelect);

				if(UIUtil.isNotNullAndNotEmpty(strTemplateId)){
					DomainObject doRouteTemplate = new DomainObject(strTemplateId);

					String strAttributeRouteCompletionAction = PropertyUtil.getSchemaProperty(context, "attribute_RouteCompletionAction");

					String strAttributeRouteBasePurpose = PropertyUtil.getSchemaProperty(context, "attribute_RouteBasePurpose");
					String SELECT_ATTR_ROUTE_BASE_PURPOSE = "attribute[" +  PropertyUtil.getSchemaProperty(context, "attribute_RouteBasePurpose")  + "]";

					String strAttributeRouteBasePolicy = PropertyUtil.getSchemaProperty(context, "attribute_RouteBasePolicy");
					String strAttributeRouteBaseState = PropertyUtil.getSchemaProperty(context, "attribute_RouteBaseState");
					String strAttributeAutoStopRejection = PropertyUtil.getSchemaProperty(context, "attribute_AutoStopOnRejection" );
					String SELECT_ATTR_AUTO_STOP_REJECTION = "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_AutoStopOnRejection" ) + "]";

					Map routeAttributeMap = new HashMap();		

					Map objectRouteAttributeMap = new HashMap();	

					slObjectSelect.add(SELECT_ATTR_AUTO_STOP_REJECTION);
					slObjectSelect.add(SELECT_ATTR_ROUTE_BASE_PURPOSE);
					Map mRouteTemplateInfo = doRouteTemplate.getInfo(context, slObjectSelect);


					routeAttributeMap.put(strAttributeRouteCompletionAction, "Promote Connected Object");
					routeAttributeMap.put(strAttributeAutoStopRejection, mRouteTemplateInfo.get(SELECT_ATTR_AUTO_STOP_REJECTION));
					routeAttributeMap.put(strAttributeRouteBasePurpose,mRouteTemplateInfo.get(SELECT_ATTR_ROUTE_BASE_PURPOSE));

					// attributes to be set on relationship Object Route
					objectRouteAttributeMap.put(strAttributeRouteBasePolicy,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy, false));
					objectRouteAttributeMap.put(strAttributeRouteBaseState, strSourceState);
					objectRouteAttributeMap.put(strAttributeRouteBasePurpose, "Review");
					String strRouteTemplateDescription = (String)mRouteTemplateInfo.get(DomainObject.SELECT_DESCRIPTION);
					String strStateName = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);

					newRouteObj = Route.createAndStartRouteFromTemplateAndReviewers(context, 
							strTemplateId, 
							strRouteTemplateDescription, 
							DomainConstants.EMPTY_STRING, 
							strObjectId,
							strPolicy, 
							strTargetStateName,
							routeAttributeMap, 
							objectRouteAttributeMap, 
							new HashMap(),
							true);
					String strStatus = newRouteObj.getAttributeValue(context, DomainConstants.ATTRIBUTE_ROUTE_STATUS);
					if(strStatus.equalsIgnoreCase("Not Started")) {
						newRouteObj.promote(context);
					}
				}
			}

		}catch(Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}


		public void createRoute(Context context, String[] args) throws Exception
		{
			try {
				String sObjectId = args[0];
				DomainObject doObj = null;
				if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
					
					doObj = new DomainObject(sObjectId);
					String strPolicy = (String)doObj.getInfo(context,DomainConstants.SELECT_POLICY);
					String strProjectId = getProjectIDFromFolder(context,sObjectId);
					
					if(UIUtil.isNotNullAndNotEmpty(strProjectId)){
						doObj = new DomainObject(strProjectId);
						String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == Documents";
						MapList routeMapList= doObj.getRelatedObjects(context, RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
						if(routeMapList != null && routeMapList.isEmpty() == false){
							Map mRouteTemplateMap = (Map)routeMapList.get(0);
							String strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
							createRouteFromTemplate(context, sObjectId, strTemplateId, strPolicy, "RELEASED", "state_FROZEN");

						}
					}				
				}			
			}
			catch (Exception e) {
				throw e;
			}
		}
	
	
	private String getProjectIDFromFolder(Context context,String sObjectId)throws Exception{
		String strReturn = DomainConstants.EMPTY_STRING;
		try{	
			DomainObject doObj = new DomainObject(sObjectId); 
			
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainObject.SELECT_ID);
			slObjSelect.add(DomainObject.SELECT_TYPE);
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			
			String strRelPattern = "Vaulted Documents Rev2,Sub Vaults,Data Vaults";
			String strTypePattern = "Workspace Vault,Project Space";
			
			MapList mlFolderList = doObj.getRelatedObjects(context, // matrix context
    				 strRelPattern, // relationship pattern
    				 strTypePattern, // type pattern
    				 slObjSelect, // object selects
    				 slRelSelect, // relationship selects
    				 true, // to direction
    				 false, // from direction
    				 (short) 0, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
			Map mTemp = null;
			String strType = DomainConstants.EMPTY_STRING;
			for(int i=0;i<mlFolderList.size();i++){
				mTemp = (Map)mlFolderList.get(i);
				strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
				if("Project Space".equals(strType)){
					strReturn = (String)mTemp.get(DomainObject.SELECT_ID);
					break;
				}				
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return strReturn;
	}

		public String getParentForDocument(Context context,String[] args)throws Exception{
		String strReturn = DomainConstants.EMPTY_STRING;
		try{	
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId); 
			
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainObject.SELECT_ID);
			slObjSelect.add(DomainObject.SELECT_TYPE);
			slObjSelect.add(DomainObject.SELECT_NAME);
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			
			String strRelPattern = "Vaulted Documents Rev2,Sub Vaults,Data Vaults";
			String strTypePattern = "Workspace Vault,Project Space";
			
			MapList mlFolderList = doObj.getRelatedObjects(context, // matrix context
    				 strRelPattern, // relationship pattern
    				 strTypePattern, // type pattern
    				 slObjSelect, // object selects
    				 slRelSelect, // relationship selects
    				 true, // to direction
    				 false, // from direction
    				 (short) 0, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
			Map mTemp = null;
			String strType = DomainConstants.EMPTY_STRING;
			for(int i=0;i<mlFolderList.size();i++){
				mTemp = (Map)mlFolderList.get(i);
				strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
				if("Project Space".equals(strType)){
					strReturn = (String)mTemp.get(DomainObject.SELECT_NAME);
					break;
				}				
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return strReturn;
	}

	public Map getRangeForWorkOrderRole(Context context, String[] args) throws Exception{
		Map mRange = new HashMap();
		StringList slRange = new StringList();
		slRange.add(DomainConstants.EMPTY_STRING);
		try{
			//StringList slRange = mxAttr.getChoices( context,ATTRIBUTE_WMS_WORK_ORDER_ROLE);	
			String strPMCRoles = EnoviaResourceBundle.getProperty(context, "WMS.Roles.PMC");
			StringList slPMCRoles = FrameworkUtil.split(strPMCRoles,",");
			
			String strContractorRoles = EnoviaResourceBundle.getProperty(context, "WMS.Roles.Contractor");
			StringList slContractorRoles = FrameworkUtil.split(strPMCRoles,",");
			
			String strRoleName = DomainConstants.EMPTY_STRING;
			for(int i=0;i<slPMCRoles.size();i++){
				strRoleName = (String)slPMCRoles.get(i);
				if(slRange.contains(strRoleName) == false){
					slRange.add(strRoleName);
				}
			}
			
			strRoleName = DomainConstants.EMPTY_STRING;
			for(int i=0;i<slContractorRoles.size();i++){
				strRoleName = (String)slContractorRoles.get(i);
				if(slRange.contains(strRoleName) == false){
					slRange.add(strRoleName);
				}
			}
			
            mRange.put("field_choices", slRange);
			mRange.put("field_display_choices", slRange);
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
		return mRange;

	}


	public boolean isSupplier(Context context, String[] args)throws Exception{
		boolean isSupplier = false;
		try{
			Map programMap         = (HashMap) JPO.unpackArgs(args);
			String strCompanyId = (String) programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strCompanyId)){
				String mqlQuery = "print bus "+strCompanyId+" select to["+DomainRelationship.RELATIONSHIP_SUPPLIER+"].id dump";
				String strResult = MqlUtil.mqlCommand(context,mqlQuery);
				if(UIUtil.isNotNullAndNotEmpty(strResult)){
					isSupplier = true;
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return isSupplier;
}
		
	
		/**
	 * Method generates hash value of file content and stores on IT attribute
	 * 
	 * @param context
	 * @param strFileName
	 * @return
	 */

	
	/*public void setSHA256HashOfFileContent(Context context,String  strFileName,DomainObject domInboTask) throws Exception{
		
			StringList slSelect=new StringList();
			slSelect.add(DomainConstants.SELECT_ID);
			slSelect.add("attribute["+DomainConstants.ATTRIBUTE_COMMENTS+"]");
			slSelect.add(DomainConstants.SELECT_OWNER);
		    Map mTaskInfo = domInboTask.getInfo(context,slSelect);
		    
			
			String strEdongal = EnoviaResourceBundle.getProperty(context,"WMS.Edongal.Enable");
			if(UIUtil.isNotNullAndNotEmpty(strEdongal) && "true".equals(strEdongal)){
				String strTokenInputHash = generatePDFStamplerEDongle(context,strFileName,mTaskInfo);
				domInboTask.setAttributeValue(context, ATTRIBUTE_WMS_TOKEN_FILE_HASH, strTokenInputHash);
				String strInputHash = generatePDFStampler(context,strFileName,mTaskInfo);
				domInboTask.setAttributeValue(context, ATTRIBUTE_WMS_FILE_HASH_CODE, strInputHash);
			}else{
				String strInputHash = generatePDFStampler(context,strFileName,mTaskInfo);
				domInboTask.setAttributeValue(context, ATTRIBUTE_WMS_FILE_HASH_CODE, strInputHash);
			}
         
 	    
 	    
 	}*/
	
	
//	public String generatePDFStampler(Context context, String strFileName, Map mTaskInfo) {
//		String strDocHashCode = null;
//		try {
//			String strId = (String) mTaskInfo.get(DomainConstants.SELECT_ID);
//			String userName = (String) mTaskInfo.get(DomainConstants.SELECT_OWNER);
//			String userComments = (String) mTaskInfo.get("attribute[" + DomainConstants.ATTRIBUTE_COMMENTS + "]");
//			String destinationfile = null;
//			FileOutputStream fout;
//			PdfSignatureAppearance appearance;
//			PdfReader reader;
//			File file = new File(strFileName);
//			String sourcefile = file.getAbsolutePath();
//			destinationfile = sourcefile.replace(file.getName(), "/Signed_" + file.getName());
//			reader = new PdfReader(sourcefile, null, true);
//		  	Rectangle cropBox = reader.getCropBox(1);
//			Rectangle rectangle = null;
// 		    rectangle = new Rectangle(cropBox.getLeft(20), cropBox.getBottom(20), cropBox.getLeft(200),
//					cropBox.getBottom(180));
//			fout = new FileOutputStream(destinationfile);
//			PdfStamper stamper = PdfStamper.createSignature(reader, fout, '\0', null, true);
//
//			appearance = stamper.getSignatureAppearance();
//			appearance.setRenderingMode(RenderingMode.DESCRIPTION);
//			appearance.setAcro6Layers(false);
//			Font font = new Font();
//			font.setSize(6);
//			font.setFamily("Helvetica");
//			font.setStyle("italic");
//			appearance.setLayer2Font(font);
//			Calendar currentDat = Calendar.getInstance();
//			currentDat.add(currentDat.MINUTE, 5);
//			// currentDat.setTimeInMillis(ASPGUI.deltaTime + currentDat.getTimeInMillis());
//			appearance.setSignDate(currentDat);
//			//appearance.setLayer2Text("Document Signed by " + userName + "  " + "\n" + " Location : India");
// 	        //appearance.setCertificationLevel(PdfSignatureAppearance.NOT_CERTIFIED);
// 	        appearance.setCertificationLevel(PdfSignatureAppearance.CERTIFIED_NO_CHANGES_ALLOWED);
//			appearance.setImage(null);
//			appearance.setVisibleSignature(rectangle, reader.getNumberOfPages(), null);
//			int contentEstimated = 10000;
//			HashMap<PdfName, Integer> exc = new HashMap();
//			exc.put(PdfName.CONTENTS, contentEstimated * 2 + 2);
//			PdfSignature dic = new PdfSignature(PdfName.ADOBE_PPKLITE, PdfName.ADBE_PKCS7_DETACHED);
//			dic.setReason(appearance.getReason());
//			dic.setLocation(appearance.getLocation());
//			dic.setDate(new PdfDate(appearance.getSignDate()));
//			appearance.setCryptoDictionary(dic);
//			appearance.preClose(exc);
//		 	System.gc();
//			// getting bytes of file
//			InputStream is = appearance.getRangeStream();
//			strDocHashCode = DigestUtils.sha256Hex(is);
//
//			CacheUtil.setCacheObject(context, "appearance" + strId, appearance);
//			CacheUtil.setCacheObject(context, "filepath" + strId, strFileName); // store the file path as this file
//																				// needs to check in
//		} catch (IOException e) {
//			e.printStackTrace();
//		} catch (DocumentException e) {
//			e.printStackTrace();
//		} catch (FrameworkException e) {
//			e.printStackTrace();
//		}
//
//		return strDocHashCode;
//	}
	
//	public String generatePDFStamplerEDongle(Context context, String strFileName, Map mTaskInfo) {
//		String strDocHashCode = null;
//		try {
//			
//			String strPersonId = PersonUtil.getPersonObjectID(context);
//			StringList slPersonSelect = new StringList();
//			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
//			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
//			
//			DomainObject doPerson = new DomainObject(strPersonId);
//			Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
//			String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
//			String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
//			
//			if(UIUtil.isNullOrEmpty(strFirstName)){
//				strFirstName = DomainConstants.EMPTY_STRING;
//			}
//			if(UIUtil.isNullOrEmpty(strLastName)){
//				strLastName = DomainConstants.EMPTY_STRING;
//			}
//			
//			String strUser = strFirstName + " " +strLastName;
//			
//			String strId = (String) mTaskInfo.get(DomainConstants.SELECT_ID);
//			String userName = (String) mTaskInfo.get(DomainConstants.SELECT_OWNER);
//			String userComments = (String) mTaskInfo.get("attribute[" + DomainConstants.ATTRIBUTE_COMMENTS + "]");
//			String destinationfile = null;
//			FileOutputStream fout;
//			//PdfSignatureAppearance appearance;
//			//PdfReader reader;
//			File file = new File(strFileName);
//			String sourcefile = file.getAbsolutePath();
//			String filePath = sourcefile.substring(0, sourcefile.lastIndexOf(File.separator));
//			//destinationfile = sourcefile.replace(file.getName(), "TokenSinged_" + file.getName());
//			//reader = new PdfReader(sourcefile, null, true);
//		  	//Rectangle cropBox = reader.getCropBox(1);
//			//Rectangle rectangle = null;
// 		    //rectangle = new Rectangle(cropBox.getLeft(), cropBox.getBottom(), cropBox.getLeft(100),
//			//		cropBox.getBottom(90));
//			//fout = new FileOutputStream(destinationfile);
//			
//			String strEnvironmentURL = EnoviaResourceBundle.getProperty(context,"WMS.Environment.URL");
//			PdfReader reader = new PdfReader(strFileName);
//			int iPageNumbers = reader.getNumberOfPages();
//			Rectangle cropBox = reader.getCropBox(1);
//			
//			String strpath = System.getProperty("user.dir");
//			File newFile = new File(strpath+"/..");
//		
//			String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
//			SimpleDateFormat dt = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
//			Date date  = new Date();
//			
//			String strDate = dt.format(date);
//			Image qrImg = Image.getInstance(newFile.getCanonicalPath()+strImageFolder+"TickMark.png");
//			qrImg.setAbsolutePosition(0,0);
//			PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(filePath+File.separator+"TokenSinged_"+file.getName()));
//			Font fontSize = new Font(FontFamily.HELVETICA, 13);
//			for(int i=0;i<iPageNumbers;i++){
//				PdfContentByte canvas = stamper.getOverContent(i+1);
//				canvas.addImage(qrImg);
//				Font bold = new Font(FontFamily.HELVETICA, 13, Font.BOLD);
//				Chunk chunk = new Chunk("here", bold);
//				chunk.setAnchor(strEnvironmentURL+"/common/emxForm.jsp?form=type_InboxTask&objectId="+strId+"&toolbar=WMSeSignVerification");
//				Phrase p = new Phrase("This document is generated by "+strUser+" and is digitally signed on "+strDate+". For verification please click ",fontSize);
//				p.add(chunk);
//				ColumnText ct = new ColumnText(canvas);
//				ct.setSimpleColumn(cropBox.getLeft(80), cropBox.getBottom(30), cropBox.getLeft(1000), cropBox.getBottom(10));
//				ct.addText(p);
//				ct.go();
//			}
//			stamper.close();
//			reader.close();
//			System.gc();
//			InputStream is = new FileInputStream(filePath+File.separator+"TokenSinged_"+file.getName());
//			strDocHashCode = DigestUtils.sha256Hex(is);
//			
//			//PdfStamper stamper = PdfStamper.createSignature(reader, fout, '\0', null, true);
//
//			//appearance = stamper.getSignatureAppearance();
//			//appearance.setRenderingMode(RenderingMode.DESCRIPTION);
//			//appearance.setAcro6Layers(false);
//			//Font font = new Font();
//			//font.setSize(6);
//			//font.setFamily("Helvetica");
//			//font.setStyle("italic");
//			//appearance.setLayer2Font(font);
//			//Calendar currentDat = Calendar.getInstance();
//			//currentDat.add(currentDat.MINUTE, 5);
//			// currentDat.setTimeInMillis(ASPGUI.deltaTime + currentDat.getTimeInMillis());
//			//appearance.setSignDate(currentDat);
//			//appearance.setLayer2Text("Document Signed by " + userName + "  " + "\n" + " Location : India");
// 	        //appearance.setCertificationLevel(PdfSignatureAppearance.NOT_CERTIFIED);
// 	       // appearance.setCertificationLevel(PdfSignatureAppearance.CERTIFIED_NO_CHANGES_ALLOWED);
//			//appearance.setImage(null);
//			//appearance.setVisibleSignature(rectangle, reader.getNumberOfPages(), null);
//			//int contentEstimated = 10000;
//			//HashMap<PdfName, Integer> exc = new HashMap();
//			//exc.put(PdfName.CONTENTS, contentEstimated * 2 + 2);
//			//PdfSignature dic = new PdfSignature(PdfName.ADOBE_PPKLITE, PdfName.ADBE_PKCS7_DETACHED);
//			//dic.setReason(appearance.getReason());
//			//dic.setLocation(appearance.getLocation());
//			//dic.setDate(new PdfDate(appearance.getSignDate()));
//			//appearance.setCryptoDictionary(dic);
//			//appearance.preClose(exc);
//		 	
//			// getting bytes of file
//			//InputStream is = appearance.getRangeStream();
//			
//			
//			/*MessageDigest md = MessageDigest.getInstance("SHA-256");
//		      System.out.println("strFileName00000---"+strFileName);
//			try (DigestInputStream dis = new DigestInputStream(new FileInputStream(strFileName), md)) {
//				while (dis.read() != -1) ; //empty loop to clear the data
//					md = dis.getMessageDigest();
//				}
//
//			byte[] hashInBytes =  md.digest();
//			
//			StringBuilder sb = new StringBuilder();
//			for (byte b : hashInBytes) {
//				sb.append(String.format("%02x", b));
//			}
//			
//			
//			strDocHashCode =  sb.toString();
//			System.out.println("strDocHashCode---"+strDocHashCode);*/
//
//			//CacheUtil.setCacheObject(context, "appearance" + strId, appearance);
//			CacheUtil.setCacheObject(context, "filepath_token" + strId, filePath+File.separator+"TokenSinged_"+file.getName()); // store the file path as this file
//																				// needs to check in
//		} catch (Exception e) {
//			e.printStackTrace();
//		} 
//		/*catch (DocumentException e) {
//			e.printStackTrace();
//		} catch (FrameworkException e) {
//			e.printStackTrace();
//		}*/
//
//		return strDocHashCode;
//	}
	
	/**
     * To get the quick task complete link
     * @param context
     * @param args
     * @return StringList
     * @throws Exception
     * @since V6R2015x
     */
	public StringList getQuickTaskCompleteLink(Context context, String [] args) throws Exception{
		HashMap programMap        = (HashMap) JPO.unpackArgs(args);
	    MapList relBusObjPageList = (MapList)programMap.get("objectList");
		StringList slLinks = new StringList(relBusObjPageList.size());
		String sTaskLink = "";
	    for (int i=0; i < relBusObjPageList.size(); i++) {
	         Map collMap = (Map)relBusObjPageList.get(i);
	         String sTaskType  = (String)collMap.get(DomainObject.SELECT_TYPE);
	         String sTaskId  = (String)collMap.get(DomainObject.SELECT_ID);
	         String routeTaskAction  = (String)collMap.get("attribute["+ DomainConstants.ATTRIBUTE_ROUTE_ACTION +"]");
	         if(sTypeInboxTask.equals(sTaskType) && routeTaskAction.equalsIgnoreCase("Approve")){
	        	 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxTaskCompletePreProcess.jsp?action=Approve&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
	         }else if(sTypeInboxTask.equals(sTaskType) && (routeTaskAction.equalsIgnoreCase("Comment") || routeTaskAction.equalsIgnoreCase("Notify Only"))){
	        	 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxTaskCompletePreProcess.jsp?action=Complete&amp;summaryPage=true&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;objectId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
	         }else{
	        	 sTaskLink = "javascript:emxTableColumnLinkClick('../components/emxUserTasksSummaryLinksProcess.jsp?fromPage=Complete&amp;emxSuiteDirectory=components&amp;suiteKey=Components&amp;emxTableRowId=" + sTaskId + "', null, null, 'false', 'listHidden', '', null, 'true')";
	         }
	         sTaskLink  = "<a href=\"" + sTaskLink + "\">" + "<img src=\"" + "../common/images/buttonDialogDone.gif" + "\" width=\"16px\" height=\"16px\"/>" + "</a>";
	         slLinks.add(sTaskLink);
	    }
		return slLinks;
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
   public MapList getAllRouteTasks(Context context, String[] args) throws Exception
   {
		MapList mlTaskList = JPO.invoke(context,"emxInboxTaskBase",args,"getAllRouteTasks",args,MapList.class);
		
		mlTaskList.sort("attribute[Route Sequence]", ProgramCentralConstants.ASCENDING_SORT, ProgramCentralConstants.SORTTYPE_INTEGER);
		
       return mlTaskList;

   }
   
   @com.matrixone.apps.framework.ui.ProgramCallable
   public MapList getDocuments(Context context, String[] args) throws Exception
   {
	   MapList mlFinalList = new MapList();
		HashMap programMap        = (HashMap) JPO.unpackArgs(args);
		String strObjectId = (String)programMap.get("objectId");
		if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
			DomainObject doObj = new DomainObject(strObjectId);
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainObject.SELECT_ID);
			slObjSelect.add(DomainObject.SELECT_NAME);
			slObjSelect.add(DomainObject.SELECT_ORIGINATED);
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			
			mlFinalList = doObj.getRelatedObjects(context, // matrix context
    				 DomainRelationship.RELATIONSHIP_REFERENCE_DOCUMENT, // relationship pattern
    				 "*", // type pattern
    				 slObjSelect, // object selects
    				 slRelSelect, // relationship selects
    				 false, // to direction
    				 true, // from direction
    				 (short) 1, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
			
			mlFinalList.sort(DomainObject.SELECT_ORIGINATED, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_DATE);
		}	
		
		return mlFinalList;
   }
	/**
	 * To show file drag/drop zone , object type must be eith MBE/AMB. this should not affect 
	 * other places
	 * 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	
	public static String isTypeAMBorMBE(Context context,String[] args) throws Exception{
		
		 HashMap programMap  = (HashMap) JPO.unpackArgs(args);
	     HashMap paramList   = (HashMap) programMap.get("paramList");
	     String strId=(String)paramList.get("objectId");
	     DomainObject dom=DomainObject.newInstance(context,strId);
	     String strType  = dom.getInfo(context, DomainConstants.SELECT_TYPE);
	     if(strType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY) || strType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY)){
	    	 return "true~"+strType+"~"+strId;
	     }
		 if(paramList.containsKey("parentOID")) {
			 strId= (String)paramList.get("parentOID");
			 dom.setId(strId);
			 strType = dom.getInfo(context, DomainConstants.SELECT_TYPE);
			 if(strType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY) || strType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY)){
		    	 return "true~"+strType+"~"+strId;
		     }
		 }
		
		 if(strType.equalsIgnoreCase(DomainConstants.TYPE_INBOX_TASK)) {
			 
			 strType=	 dom.getInfo(context, "from[" + DomainConstants.RELATIONSHIP_ROUTE_TASK + "].to.to["
						+ DomainConstants.RELATIONSHIP_OBJECT_ROUTE + "].from.type");
			 if(strType.equalsIgnoreCase(TYPE_WMS_MEASUREMENT_BOOK_ENTRY) || strType.equalsIgnoreCase(TYPE_WMS_ABSTRACT_MEASUREMENT_BOOK_ENTRY)){
		    	 return "true~"+strType+"~"+strId;
		     }
		 }
			return "false";
	}

	public static String getValueInWords(String strNumber)throws Exception{
		if(Double.valueOf(strNumber) == 0)
            return ZERO;
		DecimalFormat df1 = new DecimalFormat("#.##");   
		String strPrefix = DomainConstants.EMPTY_STRING;
		if(Double.valueOf(strNumber) <0){
			strPrefix = "-";
		}
		Double dValue = Math.abs(Double.valueOf(strNumber));
		dValue = Double.valueOf(df1.format(dValue));
		strNumber = new BigDecimal(dValue).setScale(2, RoundingMode.FLOOR).toPlainString();
		//strNumber = String.valueOf(dValue);
		
		StringList slNumbers = FrameworkUtil.split(strNumber,".");

		String strFirstValue = (String)slNumbers.get(0);
		String strSecondValue = (String)slNumbers.get(0);
		String strValue = DomainConstants.EMPTY_STRING;
		if(strFirstValue.length()>=10){
			strFirstValue = strFirstValue.substring(0,strFirstValue.length()-7);
			strSecondValue = strSecondValue.substring(strSecondValue.length()-7,strSecondValue.length());
			strValue = solution(Integer.valueOf(strFirstValue));	
		}
		String strValue2 = solution(Integer.valueOf(strSecondValue));		
		String strDecValue = solution(Integer.valueOf((String)slNumbers.get(1)));
		
		if(UIUtil.isNotNullAndNotEmpty(strValue))
			strValue = strValue + " Crore";
		
		String strFinalValue = strPrefix+ strValue +" "+strValue2 +" Rupees "+ strDecValue + " Paisa Only";
		
        return strFinalValue;
	}
	
	
	private static final String ZERO = "Zero";
    private static String[] oneToNine = {
            "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"
    };

    private static String[] tenToNinteen = {
            "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
    };

    private static String[] dozens = {
            "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
    };

    public static String solution(int number) {
        if(number == 0)
            return ZERO;

        return generate(number).trim();
    }

    public static String generate(int number) {
		if(number >= 10000000) {
            return generate(number / 10000000) + " Crore " + generate(number % 10000000);
        }
        else if(number >= 100000) {
            return generate(number / 100000) + " Lakh " + generate(number % 100000);
        }
        else if(number >= 1000) {
            return generate(number / 1000) + " Thousand " + generate(number % 1000);
        }
        else if(number >= 100) {
            return generate(number / 100) + " Hundred " + generate(number % 100);
        }

        return generate1To99(number);
    }

    private static String generate1To99(int number) {
        if (number == 0)
            return "";

        if (number <= 9)
            return oneToNine[number - 1];
        else if (number <= 19)
            return tenToNinteen[number % 10];
        else {
            return dozens[number / 10 - 1] + " " + generate1To99(number % 10);
        }
    }

 @com.matrixone.apps.framework.ui.ProgramCallable
   public MapList getReferenceDocuments(Context context, String[] args) throws Exception
   {
	   MapList mlFinalList = new MapList();
		HashMap programMap        = (HashMap) JPO.unpackArgs(args);
		String strObjectId = (String)programMap.get("objectId");
		if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
			DomainObject doObj = new DomainObject(strObjectId);
			String strObjOwner = doObj.getInfo(context,DomainObject.SELECT_OWNER);
			StringList slObjSelect = new StringList();
			slObjSelect.add(DomainObject.SELECT_ID);
			slObjSelect.add(DomainObject.SELECT_NAME);
			slObjSelect.add(DomainObject.SELECT_ORIGINATED);
			slObjSelect.add(DomainObject.SELECT_OWNER);
			
			StringList slRelSelect = new StringList();
			slRelSelect.add(DomainRelationship.SELECT_ID);
			
			mlFinalList = doObj.getRelatedObjects(context, // matrix context
    				 RELATIONSHIP_WMS_REFERENCE_DOCUMENTS, // relationship pattern
    				 "*", // type pattern
    				 slObjSelect, // object selects
    				 slRelSelect, // relationship selects
    				 false, // to direction
    				 true, // from direction
    				 (short) 1, // recursion level
    				 DomainConstants.EMPTY_STRING, // object where clause
    				 DomainConstants.EMPTY_STRING, // relationship where clause
    				 0);
			String strContextUser = context.getUser();
			for(int i=0;i<mlFinalList.size();i++){
				Map m = (Map) mlFinalList.get(i);
				String strOwner = (String)m.get(DomainObject.SELECT_OWNER);
				if(UIUtil.isNotNullAndNotEmpty(strOwner) && strContextUser.equals(strOwner) == false){
					m.put("disableSelection", "true");
				}
				if(strObjOwner.equals(strContextUser)){
					m.put("disableSelection", "false");
				}				
			}
			
			mlFinalList.sort(DomainObject.SELECT_ORIGINATED, ProgramCentralConstants.DESCENDING_SORT, ProgramCentralConstants.SORTTYPE_DATE);
		}	
		
		return mlFinalList;
   }
	
	
	public static String converToIndianCurrency(Context context, Double dValue)throws Exception{
		try{
			String str = String.valueOf(dValue);
			BigDecimal amount = new BigDecimal(str);
			 Format format = com.ibm.icu.text.NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
			 String moneyString = format.format(amount);
			 String strReturn = moneyString.replace("Rs.","");
			 return strReturn;
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String conertToRoman(int input)throws Exception{
		if (input < 1 || input > 3999)
			return "Invalid Roman Number Value";
		String s = "";
		while (input >= 1000) {
			s += "M";
			input -= 1000;        }
		while (input >= 900) {
			s += "CM";
			input -= 900;
		}
		while (input >= 500) {
			s += "D";
			input -= 500;
		}
		while (input >= 400) {
			s += "CD";
			input -= 400;
		}
		while (input >= 100) {
			s += "C";
			input -= 100;
		}
		while (input >= 90) {
			s += "XC";
			input -= 90;
		}
		while (input >= 50) {
			s += "L";
			input -= 50;
		}
		while (input >= 40) {
			s += "XL";
			input -= 40;
		}
		while (input >= 10) {
			s += "X";
			input -= 10;
		}
		while (input >= 9) {
			s += "IX";
			input -= 9;
		}
		while (input >= 5) {
			s += "V";
			input -= 5;
		}
		while (input >= 4) {
			s += "IV";
			input -= 4;
		}
		while (input >= 1) {
			s += "I";
			input -= 1;
		}    
		return s;
		
	}
	
	/**
	* Method to get Amount of Item
	**/
	public static double getItemAmount(Context context,String[] args)throws Exception {
		try {
            String sObjectId = args[0];
			DomainObject doObject = new DomainObject(sObjectId);
						
			String sQuantity = (String) doObject.getAttributeValue(context, DomainConstants.ATTRIBUTE_QUANTITY);
			String sRate = (String) doObject.getAttributeValue(context, ATTRIBUTE_RATE);
			double dQuantity = Double.parseDouble(sQuantity);
			double dRate = Double.parseDouble(sRate);
			
			return dQuantity * dRate;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	* Method to get Total Amount of Item (Including GST)
	**/
	public static double getItemTotalAmount(Context context,String[] args)throws Exception {
		try {
            String sObjectId = args[0];
			DomainObject doObject = new DomainObject(sObjectId);
			
			String sQuantity = (String) doObject.getAttributeValue(context, DomainConstants.ATTRIBUTE_QUANTITY);
			String sRate = (String) doObject.getAttributeValue(context, ATTRIBUTE_RATE);
			String sGST = (String) doObject.getAttributeValue(context, ATTRIBUTE_WMSGST);
			double dQuantity = Double.parseDouble(sQuantity);
			double dRate = Double.parseDouble(sRate);
			double dGST = (100 + Double.parseDouble(sGST)) / 100;
			
			return dQuantity * dRate * dGST;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	* Method to get Amount of Head
	**/
	public static double getHeadAmount(Context context,String[] args)throws Exception {
		double dAmount = 0;
		try {
            String sObjectId = args[0];
            String sRelationship = args[1];
            String sItemRelationship = args[2];
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
						
			StringList slObjects = doObject.getInfoList(context, "from["+sRelationship+"].to.id");
			for (Object ItemObject:slObjects) {
				sItemId = (String)ItemObject;
				double dTempAmount = getHeadAmount(context, new String[]{sItemId, sRelationship, sItemRelationship});
				dAmount = dAmount + dTempAmount;
			}
			StringList slItem = doObject.getInfoList(context, "from["+sItemRelationship+"].to.id");
			for (Object ItemObject:slItem) {
				sItemId = (String)ItemObject;
				double dTempAmount = getItemAmount(context, new String[]{sItemId});
				dAmount = dAmount + dTempAmount;
			}
			
			return dAmount;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	* Method to get Amount of Master
	**/
	public static double getMasterAmount(Context context,String[] args)throws Exception {
		double dAmount = 0;
		try {
            String sObjectId = args[0];
            String sMasterRelationship = args[1];
            String sRelationship = args[2];
            String sItemRelationship = args[3];
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
			
			StringList slObjects = doObject.getInfoList(context, "from["+sMasterRelationship+"].to.id");
			for (Object ItemObject:slObjects) {
				sItemId = (String)ItemObject;
				double dTempAmount = getHeadAmount(context, new String[]{sItemId, sRelationship, sItemRelationship});
				dAmount = dAmount + dTempAmount;
			}
			
			return dAmount;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
		
	/**
	* Method to get Total Amount of Head (Including GST)
	**/
	public static double getHeadTotalAmount(Context context,String[] args)throws Exception {
		double dAmount = 0;
		try {
            String sObjectId = args[0];
            String sRelationship = args[1];
            String sItemRelationship = args[2];
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
						
			StringList slObjects = doObject.getInfoList(context, "from["+sRelationship+"].to.id");
			for (Object ItemObject:slObjects) {
				sItemId = (String)ItemObject;
				double dTempAmount = getHeadTotalAmount(context, new String[]{sItemId, sRelationship, sItemRelationship});
				dAmount = dAmount + dTempAmount;
			}
			StringList slItem = doObject.getInfoList(context, "from["+sItemRelationship+"].to.id");
			for (Object ItemObject:slItem) {
				sItemId = (String)ItemObject;
				double dTempAmount = getItemTotalAmount(context, new String[]{sItemId});
				dAmount = dAmount + dTempAmount;
			}
			
			return dAmount;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	* Method to get Total Amount of Master (Including GST)
	**/
	public static double getMasterTotalAmount(Context context,String[] args)throws Exception {
		double dAmount = 0;
		try {
            String sObjectId = args[0];
            String sMasterRelationship = args[1];
            String sRelationship = args[2];
            String sItemRelationship = args[3];
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
						
			StringList slObjects = doObject.getInfoList(context, "from["+sMasterRelationship+"].to.id");
			for (Object ItemObject:slObjects) {
				sItemId = (String)ItemObject;
				double dTempAmount = getHeadTotalAmount(context, new String[]{sItemId, sRelationship, sItemRelationship});
				dAmount = dAmount + dTempAmount;
			}
			
			return dAmount;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	* Method to get Total Amount (Including Consultancy + Contingency)
	**/
	public static double getPart1HeadTotalAmount(Context context,String[] args)throws Exception {
		double dAmount = 0;
		double dExtra = 0;
		try {
            String sObjectId = args[0];
            String sRelationship = args[1];
            String sItemRelationship = args[2];
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
			
			String sContingency = (String) doObject.getAttributeValue(context, ATTRIBUTE_WMSCONTINGENCY);
			String sConsultancy = (String) doObject.getAttributeValue(context, ATTRIBUTE_WMSCONSULTANCY);
			if (UIUtil.isNotNullAndNotEmpty(sContingency) && UIUtil.isNotNullAndNotEmpty(sConsultancy)) {
				dExtra = (100 + Double.parseDouble(sContingency) + Double.parseDouble(sConsultancy)) / 100;
			}
						
			StringList slObject = doObject.getInfoList(context, "from["+sRelationship+"].to.id");
			for (Object ItemObject:slObject) {
				sItemId = (String)ItemObject;
				double dTempAmount = getPart1HeadTotalAmount(context, new String[]{sItemId, sRelationship, sItemRelationship});
				dAmount = dAmount + dTempAmount;
			}
			StringList slItem = doObject.getInfoList(context, "from["+sItemRelationship+"].to.id");
			for (Object ItemObject:slItem) {
				sItemId = (String)ItemObject;
				double dTempAmount = getItemTotalAmount(context, new String[]{sItemId});
				dAmount = dAmount + dTempAmount;
			}
			
			return dExtra > 0 ? dAmount * dExtra : dAmount;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	* Method to get Total Amount (Including Consultancy + Contingency)
	**/
	public static double getPart1MasterTotalAmount(Context context,String[] args)throws Exception {
		double dAmount = 0;
		try {
            String sObjectId = args[0];
            String sMasterRelationship = args[1];
            String sRelationship = args[2];
            String sItemRelationship = args[3];
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
									
			StringList slObject = doObject.getInfoList(context, "from["+sMasterRelationship+"].to.id");
			for (Object ItemObject:slObject) {
				sItemId = (String)ItemObject;
				double dTempAmount = getPart1HeadTotalAmount(context, new String[]{sItemId, sRelationship, sItemRelationship});
				dAmount = dAmount + dTempAmount;
			}
			
			return dAmount;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	 * PENDING header and annotation
	 * Method to Generate the Serial Numbers after the Object Creation
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public static Vector getSNOColumn(Context context, String[] args) throws Exception {
		try{
			Map programMap =   (Map)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			Iterator iterator  = objectList.iterator();
			for(int i=1; i < intSize+1; i++) {
				vecResponse.add(String.valueOf(i));
			}           

			return vecResponse;
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * Method to get Amount after the Object Creation
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public static Vector getAmount(Context context, String[] args) throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try{
			Map programMap =   (Map)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
					
			Map oMap = null;
			String sObjectId = DomainConstants.EMPTY_STRING;
			String sType = DomainConstants.EMPTY_STRING;
			DomainObject doObject = null;
			
			for(int i=0; i < intSize; i++) {
				dAmount = 0;
				oMap =  (Map) objectList.get(i);
				sObjectId = (String) oMap.get(DomainConstants.SELECT_ID);
				doObject = new DomainObject(sObjectId);
				sType = (String) doObject.getInfo(context, DomainConstants.SELECT_TYPE);
				
				switch(sType){
					case "WMSRICMaster" :
								dAmount = getMasterAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSRICMASTER_RIC, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								break;
					case "WMSAEMaster" :
								dAmount = getMasterAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								break;
					case "WMSRIC" :
								dAmount = getHeadAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								break;
					case "WMSAE" :
								dAmount = getHeadAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								break;
					case "WMSDCS" :
								dAmount = getHeadAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
								break;
					case "WMSRICItem" :
					case "WMSAEItem" :
					case "WMSDCSItem" :
								dAmount = getItemAmount(context, new String[]{sObjectId});
								break;
					default :
				}
				
				vecResponse.add(String.valueOf(df.format(dAmount)));
			}           

			return vecResponse;
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * Method to get Total Amount after the Object Creation
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public static Vector getTotalAmount(Context context, String[] args) throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try{
			Map programMap =   (Map)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
					
			Map oMap = null;
			String sObjectId = DomainConstants.EMPTY_STRING;
			String sType = DomainConstants.EMPTY_STRING;
			DomainObject doObject = null;
			
			for(int i=0; i < intSize; i++) {
				dAmount = 0;
				oMap =  (Map) objectList.get(i);
				sObjectId = (String) oMap.get(DomainConstants.SELECT_ID);
				doObject = new DomainObject(sObjectId);
				sType = (String) doObject.getInfo(context, DomainConstants.SELECT_TYPE);
				
				switch(sType){
					case "WMSDefaultMaster" :
								dAmount = Double.valueOf((String)oMap.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]"));
								break;
					case "WMSRICMaster" :
								dAmount = getMasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSRICMASTER_RIC, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								break;
					case "WMSAEMaster" :
								dAmount = getMasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								break;
					case "WMSRIC" :
								dAmount = getHeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								break;
					case "WMSAE" :
								dAmount = getHeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								break;
					case "WMSDCS" :
								dAmount = getHeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
								break;
					case "WMSRICItem" :
					case "WMSAEItem" :
					case "WMSDCSItem" :
								dAmount = getItemTotalAmount(context, new String[]{sObjectId});
								break;
					default :
				}
				
				vecResponse.add(String.valueOf(df.format(dAmount)));
			}           

			return vecResponse;
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * Method to get Total Amount after the Object Creation (Including Consultancy + Contingency)
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public static Vector getPart1TotalAmount(Context context, String[] args) throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try{
			Map programMap =   (Map)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
					
			Map oMap = null;
			String sObjectId = DomainConstants.EMPTY_STRING;
			String sType = DomainConstants.EMPTY_STRING;
			DomainObject doObject = null;
			
			for(int i=0; i < intSize; i++) {
				dAmount = 0;
				oMap =  (Map) objectList.get(i);
				sObjectId = (String) oMap.get(DomainConstants.SELECT_ID);
				doObject = new DomainObject(sObjectId);
				sType = (String) doObject.getInfo(context, DomainConstants.SELECT_TYPE);
				
				switch(sType){
					case "WMSRICMaster" :
								dAmount = getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSRICMASTER_RIC, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								vecResponse.add(String.valueOf(df.format(dAmount)));
								break;
					case "WMSAEMaster" :
								dAmount = getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								vecResponse.add(String.valueOf(df.format(dAmount)));
								break;
					case "WMSDCSMaster" :
								dAmount = getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCSMASTER_DCS, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
								vecResponse.add(String.valueOf(df.format(dAmount)));
								break;
					case "WMSRIC" :
								dAmount = getPart1HeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								vecResponse.add(String.valueOf(df.format(dAmount)));
								break;
					case "WMSAE" :
								dAmount = getPart1HeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								vecResponse.add(String.valueOf(df.format(dAmount)));
								break;
					case "WMSDCS" :
								dAmount = getPart1HeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
								vecResponse.add(String.valueOf(df.format(dAmount)));
								break;
					default :
								vecResponse.add(DomainConstants.EMPTY_STRING);
				}
								
				
			}           

			return vecResponse;
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
    ** This Method check Edit Access to Add Route Template.
    */
	@com.matrixone.apps.framework.ui.ColJPOCallable
    public static StringList isRTCellEditable(Context context, String[] args)throws Exception {
		try {
			StringList isCellEditable = new StringList();
    		Map programMap 		= (Map) JPO.unpackArgs(args);
    		MapList objectList 	= (MapList) programMap.get("objectList");
			for (int i = 0 ; i < objectList.size(); i++) {
				Map objMap = (Map) objectList.get(i);
				String sType = (String) objMap.get("type");
				String sRelationship = (String) objMap.get("relationship");
				String strRelName = DomainConstants.EMPTY_STRING;
				switch(sType){
					case "WMSRICMaster" :
								isCellEditable.add("true");
								break;
					case "WMSAEMaster" :
								isCellEditable.add("true");
								break;
					case "WMSDefaultMaster" :
								isCellEditable.add("true");
								break;
					default :
								isCellEditable.add("false");
				}
			}
			return isCellEditable;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method check Edit Access to Add Consultancy and Contingency.
    */
	@com.matrixone.apps.framework.ui.ColJPOCallable
    public static StringList isExtraCellEditable(Context context, String[] args)throws Exception {
		try {
			StringList isCellEditable = new StringList();
    		Map programMap 		= (Map) JPO.unpackArgs(args);
    		MapList objectList 	= (MapList) programMap.get("objectList");
			for (int i = 0 ; i < objectList.size(); i++) {
				Map objMap = (Map) objectList.get(i);
				String sType = (String) objMap.get("type");
				String sObjectId = (String) objMap.get("id");
				String sRelationship = DomainConstants.EMPTY_STRING;
				switch(sType){
					case "WMSRIC" :
								sRelationship = RELATIONSHIP_WMSRIC_RICITEM;
								break;
					case "WMSAE" :
								sRelationship = RELATIONSHIP_WMSAE_AEITEM;
								break;
					default :
								sRelationship = DomainConstants.EMPTY_STRING;
				}
				DomainObject doObject = new DomainObject(sObjectId);
				StringList slObjects = doObject.getInfoList(context, "from["+sRelationship+"].to.id");
				String sValue = slObjects.size() > 0 ? "true" : "false";
				isCellEditable.add(sValue);
			}
			return isCellEditable;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method Check Editable or Not
    */	
	public static Boolean isEditable (Context context, String[] args) throws Exception {
		Boolean bReturn = false ;
		try 
		{
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sObjectId = (String)programMap.get("objectId");
			String strContextUser = context.getUser();
			String strPersonId = PersonUtil.getPersonObjectID(context);
			
			if(UIUtil.isNotNullAndNotEmpty(sObjectId))
			{
				DomainObject doObject = new DomainObject(sObjectId);
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_OWNER);
				slSelect.add(DomainObject.SELECT_CURRENT);
				Map mObjInfo = doObject.getInfo(context,slSelect);
				
				String strOwner = (String)mObjInfo.get(DomainObject.SELECT_OWNER);
				String strState = (String)mObjInfo.get(DomainObject.SELECT_CURRENT);
				if(UIUtil.isNotNullAndNotEmpty(strOwner) && strContextUser.equals(strOwner) && "Create".equals(strState)) {
					bReturn = true;					
				} else {
					String mqlQuery = "print bus "+sObjectId+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
					String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
					if(UIUtil.isNotNullAndNotEmpty(strRouteId)) {
						mqlQuery = "print bus "+strRouteId+" select to["+DomainRelationship.RELATIONSHIP_ROUTE_TASK+"|from.current=='Assigned'].from.from["+DomainRelationship.RELATIONSHIP_PROJECT_TASK+"].to.name dump";
						String strUser = MqlUtil.mqlCommand(context, mqlQuery);
						if(UIUtil.isNotNullAndNotEmpty(strUser) && strUser.contains(strContextUser)) {
							bReturn = true;
						}
					}
				}				
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return bReturn;
	}
	
	/**
	* This Method Connects RT to Object
	**/
	@com.matrixone.apps.framework.ui.CellUpdateJPOCallable
	public static void connectRT(Context context,String args[]) throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramMap =  (HashMap)programMap.get("paramMap");
			
			String strObjectId =(String) paramMap.get("objectId");
			String strRTId =(String) paramMap.get("New Value");
			
			DomainObject doObject = new DomainObject(strObjectId);
			String sType = doObject.getInfo(context, DomainConstants.SELECT_TYPE);
			if (TYPE_WMSRICMASTER.equals(sType)) {
				String sObjRTConnectionId = doObject.getInfo(context, "from["+RELATIONSHIP_WMSRICMASTER_APPROVAL_TEMPLATE+"].id");
				if (UIUtil.isNotNullAndNotEmpty(sObjRTConnectionId)) {				
					DomainRelationship.disconnect(context, sObjRTConnectionId);
				}
				DomainRelationship.connect(context, strObjectId, RELATIONSHIP_WMSRICMASTER_APPROVAL_TEMPLATE, strRTId, false);
			} else if (TYPE_WMSAEMASTER.equals(sType)) {
				String sObjRTConnectionId = doObject.getInfo(context, "from["+RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE+"].id");
				if (UIUtil.isNotNullAndNotEmpty(sObjRTConnectionId)) {				
					DomainRelationship.disconnect(context, sObjRTConnectionId);
				}
				DomainRelationship.connect(context, strObjectId, RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE, strRTId, false);
			} else if (TYPE_WMSDCSMASTER.equals(sType)) {
				String sObjRTConnectionId = doObject.getInfo(context, "from["+RELATIONSHIP_WMSDCSMASTER_APPROVAL_TEMPLATE+"].id");
				if (UIUtil.isNotNullAndNotEmpty(sObjRTConnectionId)) {				
					DomainRelationship.disconnect(context, sObjRTConnectionId);
				}
				DomainRelationship.connect(context, strObjectId, RELATIONSHIP_WMSDCSMASTER_APPROVAL_TEMPLATE, strRTId, false);
			}else if (TYPE_WMS_DEFAULT_MASTERS.equals(sType)) {
				String strAECurrent =  doObject.getInfo(context, "to["+RELATIONSHIP_WMSSOC_AEMASTER+"].from.current");
				String strRICCurrent =  doObject.getInfo(context, "to["+RELATIONSHIP_WMSSOC_RICMASTER+"].from.current");
				String strRelName = DomainConstants.EMPTY_STRING;
				if("RIC".equals(strRICCurrent))
					strRelName = RELATIONSHIP_WMSRICMASTER_APPROVAL_TEMPLATE;
				if("AE".equals(strAECurrent))
					strRelName = RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE;
				
				String sObjRTConnectionId = doObject.getInfo(context, "from["+strRelName+"].id");
				if (UIUtil.isNotNullAndNotEmpty(sObjRTConnectionId)) {				
					DomainRelationship.disconnect(context, sObjRTConnectionId);
				}
				DomainRelationship.connect(context, strObjectId, strRelName, strRTId, false);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
    ** This Method Promote Childs
    */
    public static int promoteChilds(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			String sRelationship = args[1];
		
			String sItemId = DomainConstants.EMPTY_STRING;
			DomainObject doItemObject = null;
			
			DomainObject doObj = new DomainObject(sObjectId);
			StringList slObjects = doObj.getInfoList(context, "from["+sRelationship+"].to.id");
			for (Object ItemObject:slObjects) {
				sItemId = (String)ItemObject;
				doItemObject = new DomainObject(sItemId);
				doItemObject.promote(context);
			}
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}
	
	/**
    ** This Method Demote Childs
    */
    public static int demoteChilds(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			String sRelationship = args[1];
		
			String sItemId = DomainConstants.EMPTY_STRING;
			DomainObject doItemObject = null;
			
			DomainObject doObj = new DomainObject(sObjectId);
			StringList slObjects = doObj.getInfoList(context, "from["+sRelationship+"].to.id");
			for (Object ItemObject:slObjects) {
				sItemId = (String)ItemObject;
				doItemObject = new DomainObject(sItemId);
				doItemObject.demote(context);
			}
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}
		
	/**
    ** This Method create Route object.
    */
    public static int createApprovalRoute(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			String sRTRelationship = args[1];
			String sRelationship = args[2];
			
			DomainObject doObj = new DomainObject(sObjectId);			
			String strRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
			MapList mlExtRoutes = checkForExistingRouteObject(context, doObj, strRelWhere);
			if(mlExtRoutes.size()>0) {
				restartExistingRoute(context,mlExtRoutes);
			} else {
			
				String sRouteDescription = (String)doObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
				String sState = (String)doObj.getInfo(context, DomainConstants.SELECT_CURRENT);
				String sPolicy = (String)doObj.getInfo(context, DomainConstants.SELECT_POLICY);
				String sApprovalTemplateId = (String)doObj.getInfo(context, "from["+sRTRelationship+"].to.id");
				createRouteFromTemplate(context, sObjectId, sApprovalTemplateId, sPolicy, sState, "state_Review");
			}
			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}
	
	public static String getItemAmountField (Context context,String[] args)throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			dAmount = getItemAmount(context, new String[]{sObjectId});
			
			return df.format(dAmount);
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static String getItemTotalAmountField (Context context,String[] args)throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			DomainObject doObject = new DomainObject(sObjectId);
			
			dAmount = getItemTotalAmount(context, new String[]{sObjectId});
			
			return df.format(dAmount);
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method Check Tool bar Visible or Not
    */	
	public static Boolean isToolbarVisible (Context context, String[] args) throws Exception {
		Boolean bReturn = true ;
		try 
		{
			HashMap programMap 	= (HashMap)JPO.unpackArgs(args);
			String sSOCId 		= (String)programMap.get("objectId");
			
			if(UIUtil.isNotNullAndNotEmpty(sSOCId))
			{
				String mqlQuery = "print bus "+sSOCId+" select from["+DomainRelationship.RELATIONSHIP_OBJECT_ROUTE+"|to.current=='In Process'].to.id dump";
				String strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
				if(UIUtil.isNotNullAndNotEmpty(strRouteId)){
					mqlQuery = "print bus "+strRouteId+" select attribute[Route Status].value dump";
					strRouteId = MqlUtil.mqlCommand(context, mqlQuery);
					if(!"Stopped".equals(strRouteId)){
						bReturn = false;
					}
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return bReturn;
	}
	
	/**
    ** This Method create Default Header objects.
    */
    public static int createDefaultObjects(Context context, String[] args)throws Exception {
		int iCount = 1;
		try {
			String sObjectId = args[0];
			String sType = args[1];
			String sPolicy = args[1];
			String sRelationship = args[2];
			String symbolicTypeName = "type_"+sType;
			
			DomainObject doParentObject = new DomainObject(sObjectId);
			StringList slObjects = doParentObject.getInfoList(context, "from["+sRelationship+"].to.id");
			if (slObjects.size()>0) {
				return 0;
			}
			
			String sDefaultHeaders = EnoviaResourceBundle.getProperty(context, "WMS.RICnAE.DefaultHeaders");
			String sDefaultOtherHeaders = EnoviaResourceBundle.getProperty(context, "WMS.Other.Heads");
		    StringList slHeaders = FrameworkUtil.split(sDefaultHeaders, ",");
		    StringList slOtherHeaders = FrameworkUtil.split(sDefaultOtherHeaders, ",");
			String sValue = DomainConstants.EMPTY_STRING;
			String sIncludeObject = DomainConstants.EMPTY_STRING;
			String sTitle = DomainConstants.EMPTY_STRING;
			String sName = DomainConstants.EMPTY_STRING;
			String sRevision = new Policy(sPolicy).getFirstInMinorSequence(context);
			DomainObject doObject = new DomainObject();
			int iHeadSize =slHeaders.size();
			for (Object ItemObject:slHeaders) {
				sValue = (String)ItemObject;
				StringList slValues = FrameworkUtil.split(sValue, "|");
				sIncludeObject = doParentObject.getAttributeValue(context, slValues.get(0));
				if (slValues.size()==2 && UIUtil.isNotNullAndNotEmpty(sIncludeObject) && "TRUE".equalsIgnoreCase(sIncludeObject)) {
					sTitle = slValues.get(1);
					sName = DomainObject.getAutoGeneratedName(context, symbolicTypeName, DomainConstants.EMPTY_STRING);
					doObject.createAndConnect(context, sType, sName, sRevision, sPolicy, null, sRelationship, doParentObject, true);
					doObject.setDescription(context, sTitle);
					doObject.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, sTitle);
					//if (TYPE_WMSAEMASTER.equals(sType)) {
						doObject.setAttributeValue(context, ATTRIBUTE_WMSITEMSEQUENCE, ""+iCount);
						iCount++;
					//}
				}
			}
			int iSize = slHeaders.size();
			doObject = new DomainObject();
			sRevision = new Policy("WMSDefaultMaster").getFirstInMinorSequence(context);
			for(int i=0;i<slOtherHeaders.size();i++){
				sValue = (String)slOtherHeaders.get(i);
				sName = DomainObject.getAutoGeneratedName(context, "type_WMSDefaultMaster", DomainConstants.EMPTY_STRING);
				doObject.createAndConnect(context, "WMSDefaultMaster", sName, sRevision, "WMSDefaultMaster", null, sRelationship, doParentObject, true);
				doObject.setDescription(context, sValue);
				doObject.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, sValue);
				doObject.setAttributeValue(context, ATTRIBUTE_WMSITEMSEQUENCE, String.valueOf(iHeadSize+i+1));
			}
			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}
	
	public static int checkForLeafItem(Context context, String[] args)throws Exception {
		int iResult = 1;
		try {
			String sObjectId = args[0];
			String sRelationship = args[1];
			String sItemRelationship = args[2];
			
			DomainObject doObject = new DomainObject(sObjectId);
			StringList slTo = doObject.getInfoList(context, "from["+sRelationship+"].to.id");
			StringList slItem = doObject.getInfoList(context, "from["+sItemRelationship+"].to.id");
			if ( slTo.size() == 0) {
				if (slItem.size() > 0 ) {
					iResult = 0;
				}
			} else {
				iResult = 0;
				for (Object ItemObject:slTo) {
					iResult = checkForLeafItem(context, new String [] {(String) ItemObject, sRelationship, sItemRelationship});
				}
			}
			return iResult;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method check Route object.
    */
    public static int checkApprovalRouteTemplate(Context context, String[] args)throws Exception {
		int iResult = 1;
		try {
			String sObjectId = args[0];
			String sRTRelationship = args[1];
			String sMasterRelationship = args[2];
			String sRelationship = args[3];
			String sItemRelationship = args[4];
		
			DomainObject doObj = new DomainObject(sObjectId);
			String strType = (String)doObj.getInfo(context,DomainObject.SELECT_TYPE);
			String sApprovalTemplateId = (String)doObj.getInfo(context, "from["+sRTRelationship+"].to.id");
			
			if (!UIUtil.isNotNullAndNotEmpty(sApprovalTemplateId)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoApprovalTemplate");
				emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				return 1;
			}
			
			String sItemId = DomainConstants.EMPTY_STRING;
			DomainObject doItemObject = null;
			if(TYPE_WMS_DEFAULT_MASTERS.equals(strType)==false){
				StringList slObjects = doObj.getInfoList(context, "from["+sMasterRelationship+"].to.id");
				if (slObjects.size() == 0) {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoItem");
					emxContextUtil_mxJPO.mqlNotice(context, strMessage);
					return 1;
				} else {
					for (Object ItemObject:slObjects) {
						iResult = checkForLeafItem(context, new String [] {(String) ItemObject, sRelationship, sItemRelationship});
						if( iResult == 1) {
							String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoItem");
							emxContextUtil_mxJPO.mqlNotice(context, strMessage);
							return 1;
						}
					}
				}
			}
			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public boolean isAllApproved(Context context, String[] args) throws Exception {
		boolean isApproved = false;
        try {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strObjectId = (String)programMap.get("objectId");
			String strToolBar = (String)programMap.get("toolbar");
			String sRelationship = DomainConstants.EMPTY_STRING;
			switch(strToolBar) {
				case "WMSRICToolbar" :
							sRelationship = RELATIONSHIP_WMSSOC_RICMASTER;
							break;
				case "WMSAEToolbar" :
							sRelationship = RELATIONSHIP_WMSSOC_AEMASTER;
							break;
				case "WMSApprovedAEToolbar" :
							sRelationship = RELATIONSHIP_WMSSOC_APPROVEDAEMASTER;
							break;
				default :
							sRelationship = DomainConstants.EMPTY_STRING;
			}
			
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)) {
				DomainObject doObject = new DomainObject(strObjectId);
				StringList slObjectStates = doObject.getInfoList(context,"from["+sRelationship+"].to.current");
				if(!slObjectStates.isEmpty() && !slObjectStates.contains(STATE_WMSAEMASTER_CREATE) && !slObjectStates.contains(STATE_WMSAEMASTER_REVIEW) && WMSSOC_mxJPO.getSO1Planning(context).contains(context.getUser())){
					isApproved = true;
				}
			}
            
        } catch(Exception exception) {
            exception.printStackTrace();
            throw exception;
        }
		return isApproved;
    }
	
	public boolean isAllNotApproved(Context context, String[] args) throws Exception {
		boolean isApproved = true;
        try {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strObjectId = (String)programMap.get("objectId");
			String strToolBar = (String)programMap.get("toolbar");
			String sRelationship = DomainConstants.EMPTY_STRING;
			//boolean bValidUser = false;
			switch(strToolBar) {
				case "WMSRICToolbar" :
				case "WMSRICItemToolbar" :
							sRelationship = RELATIONSHIP_WMSSOC_RICMASTER;
							//bValidUser = WMSSOC_mxJPO.isNotSO1Planning(context);
							break;
				case "WMSAEToolbar" :
				case "WMSAEItemToolbar" :
							sRelationship = RELATIONSHIP_WMSSOC_AEMASTER;
							//bValidUser = WMSSOC_mxJPO.isNotSO1Planning(context);
							break;
				case "WMSApprovedAEToolbar" :
				case "WMSApprovedAEItemToolbar" :
							sRelationship = RELATIONSHIP_WMSSOC_APPROVEDAEMASTER;
							//bValidUser = context.getUser().equals(WMSSOC_mxJPO.getSO1Planning(context);
							break;
				default :
							sRelationship = DomainConstants.EMPTY_STRING;
							//bValidUser = false;
			}
			
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)) {
				DomainObject doObject = new DomainObject(strObjectId);
				StringList slObjectStates = doObject.getInfoList(context,"from["+sRelationship+"].to.current");
				if(!slObjectStates.isEmpty() && !slObjectStates.contains(STATE_WMSAEMASTER_CREATE) && !slObjectStates.contains(STATE_WMSAEMASTER_REVIEW)){
					isApproved = false;
				}
			}
            
        } catch(Exception exception) {
            exception.printStackTrace();
            throw exception;
        }
		return isApproved;
    }
	
	public static int updateMasterTotalAmount(Context context, String[] args)throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try {
				String sObjectId = args[0];
				dAmount = getPart1MasterTotalAmount(context, args);
				DomainObject doObject = new DomainObject(sObjectId);
				doObject.setAttributeValue(context, ATTRIBUTE_WMSTOTALAMOUNT, String.valueOf(df.format(dAmount)));
				return 0;
		} catch(Exception ex) {
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}
	
	public static int checkMasterTotalAmount(Context context, String[] args)throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try {
			String sObjectId = args[0];
			String sSOCRelationship = args[4];
			String sRelationship = args[5];
			String sType = args[6];
			StringList slInfoList  = new StringList();
			slInfoList.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
			slInfoList.add("to["+sSOCRelationship+"].from.id");
			String strAmountPercent = EnoviaResourceBundle.getProperty(context,"WMS.Delegation.ApprovalAmountPercentage");
			
			dAmount = getPart1MasterTotalAmount(context, args);
			DomainObject doObject = new DomainObject(sObjectId);
			Map objMap = doObject.getInfo(context, slInfoList);
			
			String sSOCId = (String) objMap.get("to["+sSOCRelationship+"].from.id");
			String sTitle = (String) objMap.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
			DomainObject doSOC = new DomainObject(sSOCId);
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value");
			String sWhere = "attribute["+DomainConstants.ATTRIBUTE_TITLE+"]=="+"'"+sTitle+"'";
		
			MapList mlMaster = doSOC.getRelatedObjects(context, // matrix context
												sRelationship, // relationship pattern
												sType, // type pattern
												busSelects, // object selects
												null, // relationship selects
												false, // to direction
												true, // from direction
												(short) 1, // recursion level
												sWhere, // object where clause
												null); // relationship where clause
												
			if (mlMaster.size() == 1) {
				Map masterMap = (Map) mlMaster.get(0);
				double dMasterAmount = Double.parseDouble((String) masterMap.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value"));
				double dMasterMaxAmount = dMasterAmount * ((100 + Double.parseDouble(strAmountPercent)) / 100 );
				if (dAmount <= dMasterMaxAmount && dAmount!= 0 && dMasterMaxAmount!=0) {
					doObject.setAttributeValue(context, ATTRIBUTE_WMSTOTALAMOUNT, String.valueOf(df.format(dAmount)));
					return 0;
				}
			}
			emxContextUtil_mxJPO.mqlNotice(context, "AE Total Amount of "+sTitle+" Exceeding more than "+strAmountPercent+"% of RIC "+sTitle);
			return 1;
		} catch(Exception ex) {
			ex.printStackTrace();
			return 1;
		}
	}
	
	public Vector getItemHistory(Context context,String[] args) throws Exception {
		Vector colVector = new Vector();
		try { 
			String strURL="../wms/wmsItemHistory.jsp";
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramList = (HashMap) programMap.get("paramList");
			MapList objectList  = (MapList) programMap.get("objectList");
			StringBuilder sb= null;
			Iterator<Map> itr = objectList.iterator();
			String strType = DomainConstants.EMPTY_STRING;
			String strId = DomainConstants.EMPTY_STRING;
			while(itr.hasNext()) {
				Map m = itr.next();
				strType = (String)m.get(DomainObject.SELECT_TYPE);
				strId = (String)m.get(DomainObject.SELECT_ID);
				sb=new StringBuilder();
				if(strType.equals(TYPE_WMSRICITEM) || strType.equals(TYPE_WMSAEITEM) || strType.equals(TYPE_WMSDCSITEM)){
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strId+"','600','400','false');\" >");            
					sb.append("<img border='0' title='History' src='../common/images/iconNewWindow.gif' height='15px' name='History' id='History' alt='History' onmouseover='openHistory()'/>");
					sb.append("</a>");
				}				
				colVector.add(sb.toString());
			}
			 
		} catch(Exception e) {
			e.printStackTrace();
		} 
		return colVector;
	}
	
	@com.matrixone.apps.framework.ui.PostProcessCallable
    public Map updateItemHistory(Context context, String[] args) throws Exception {
        HashMap mapReturnMap = new HashMap();
        try {
			DecimalFormat df = new DecimalFormat("0.00");
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap hmTableData = (HashMap) programMap.get("tableData");
           
			MapList mlItems = new MapList();
			Map mItemInfoMap = null;
			
            MapList mlObjectList = (MapList) hmTableData.get("ObjectList");

			
			String strPersonId = PersonUtil.getPersonObjectID(context);
			StringList slPersonSelect = new StringList();
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			slPersonSelect.add("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			
			DomainObject doPerson = new DomainObject(strPersonId);
			Map mPersonInfo = doPerson.getInfo(context,slPersonSelect);
			String strFirstName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_FIRST_NAME+"].value");
			String strLastName = (String)mPersonInfo.get("attribute["+DomainObject.ATTRIBUTE_LAST_NAME+"].value");
			
			if(UIUtil.isNullOrEmpty(strFirstName)){
				strFirstName = DomainConstants.EMPTY_STRING;
			}
			if(UIUtil.isNullOrEmpty(strLastName)){
				strLastName = DomainConstants.EMPTY_STRING;
			}
			
			String strUser = strFirstName + " " +strLastName;
			
			if(mlObjectList != null){				
				String strType = DomainConstants.EMPTY_STRING;
				String strItemId = DomainConstants.EMPTY_STRING;
				String strSequenceNumber = DomainConstants.EMPTY_STRING;
				String strUOM = DomainConstants.EMPTY_STRING;
				String strQuantity = DomainConstants.EMPTY_STRING;
				String strRate = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				String strGST = DomainConstants.EMPTY_STRING;
				String strTotalAmount = DomainConstants.EMPTY_STRING;
				String strHistoryOld = DomainConstants.EMPTY_STRING;
				String strHistoryNew = DomainConstants.EMPTY_STRING;
				String strTime  =  DomainConstants.EMPTY_STRING;
				String strLastEntry  =  DomainConstants.EMPTY_STRING;
				String strLastValue = DomainConstants.EMPTY_STRING;
				String strTitle = DomainConstants.EMPTY_STRING;
				
				Calendar calendarDate = Calendar.getInstance();
				String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
				SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
				strTime = formatter.format(calendarDate.getTime());
			
				Map mTemp = null;
				Map mObjInfo = null;
				
				int iOldHistoryEntrySize = 0;
				
				DomainObject doItem = null;
				StringList slHistoryEntryList = new StringList();
			
				StringList slSelect = new StringList();
				slSelect.add("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
				slSelect.add("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"].value");
				slSelect.add("attribute["+ATTRIBUTE_RATE+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMSGST+"].value");
				slSelect.add("attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMSITEMHISTORY+"].value");
				
				for(int i=0;i<mlObjectList.size();i++){
					iOldHistoryEntrySize = 0;
					
					strType = DomainConstants.EMPTY_STRING;
					strItemId = DomainConstants.EMPTY_STRING;
					strSequenceNumber = DomainConstants.EMPTY_STRING;
					strUOM = DomainConstants.EMPTY_STRING;
					strQuantity = DomainConstants.EMPTY_STRING;
					strRate = DomainConstants.EMPTY_STRING;
					strAmount = DomainConstants.EMPTY_STRING;
					strGST = DomainConstants.EMPTY_STRING;
					strTotalAmount = DomainConstants.EMPTY_STRING;
					strHistoryOld = DomainConstants.EMPTY_STRING;
					strHistoryNew = DomainConstants.EMPTY_STRING;
					strLastEntry  =  DomainConstants.EMPTY_STRING;
					strLastValue = DomainConstants.EMPTY_STRING;
					strTitle = DomainConstants.EMPTY_STRING;
					
					mTemp = (Map)mlObjectList.get(i);
					strType = (String)mTemp.get(DomainConstants.SELECT_TYPE);
					if(UIUtil.isNotNullAndNotEmpty(strType) && (TYPE_WMSAEITEM.equals(strType) || TYPE_WMSRICITEM.equals(strType) || TYPE_WMSDCSITEM.equals(strType))){
						strItemId = (String)mTemp.get(DomainConstants.SELECT_ID);
						if(UIUtil.isNotNullAndNotEmpty(strItemId)){
							doItem = new DomainObject(strItemId);
							mObjInfo = (Map)doItem.getInfo(context, slSelect);
							if(mObjInfo != null && !mObjInfo.isEmpty()){
								strSequenceNumber = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
								strUOM = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
								strQuantity = (String)mObjInfo.get("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"].value");
								strRate = (String)mObjInfo.get("attribute["+ATTRIBUTE_RATE+"].value");
								strGST = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMSGST+"].value");
								strTitle = (String)mObjInfo.get("attribute["+DomainObject.ATTRIBUTE_TITLE+"].value");
								strHistoryOld = (String)mObjInfo.get("attribute["+ATTRIBUTE_WMSITEMHISTORY+"].value");
																
								if(UIUtil.isNotNullAndNotEmpty(strQuantity) && UIUtil.isNotNullAndNotEmpty(strRate)) {
									strAmount = df.format(Double.parseDouble(strQuantity) * Double.parseDouble(strRate));
									if(UIUtil.isNotNullAndNotEmpty(strGST)) {
										strTotalAmount = df.format(Double.parseDouble(strQuantity) * Double.parseDouble(strRate) * ((100 + Double.parseDouble(strGST)) / 100));
									} else {
										strTotalAmount = strAmount;
									}
								}
							}

							if(TYPE_WMSAEITEM.equals(strType)) {
								strHistoryNew = strUser+"|"+strTime+"|"+strSequenceNumber+"|"+strUOM+"|"+strQuantity+"|"+strRate+"|"+strAmount+"|"+strGST+"|"+strTotalAmount;
								strLastValue = strSequenceNumber+"|"+strUOM+"|"+strQuantity+"|"+strRate+"|"+strAmount+"|"+strGST+"|"+strTotalAmount;
							} else {
								strHistoryNew = strUser+"|"+strTime+"|"+strUOM+"|"+strQuantity+"|"+strRate+"|"+strAmount+"|"+strGST+"|"+strTotalAmount;
								strLastValue = strUOM+"|"+strQuantity+"|"+strRate+"|"+strAmount+"|"+strGST+"|"+strTotalAmount;
							}
							
							if(UIUtil.isNotNullAndNotEmpty(strHistoryNew)){
								if(UIUtil.isNullOrEmpty(strHistoryOld)){
									strHistoryOld = strHistoryNew;
								} else {
									slHistoryEntryList = FrameworkUtil.split(strHistoryOld, "\n");
									iOldHistoryEntrySize = slHistoryEntryList.size();
									strLastEntry = (String)slHistoryEntryList.get(iOldHistoryEntrySize-1);
									if(strLastEntry.startsWith(strUser)){
										slHistoryEntryList.remove(strLastEntry);
										slHistoryEntryList.add(iOldHistoryEntrySize-1,strHistoryNew);
										for(int k=0;k<slHistoryEntryList.size();k++){
											if(k==0){
												strHistoryOld = (String)slHistoryEntryList.get(k);
											}else{
												strHistoryOld = strHistoryOld +"\n"+(String)slHistoryEntryList.get(k);
											}
										}
									} else {
										if(strHistoryOld.endsWith(strLastValue)==false){
											strHistoryOld = strHistoryOld + "\n"+ strHistoryNew;
										}
									}
									//strHistoryOld = strHistoryOld + "\n"+ strHistoryNew; // comment
								}
								doItem.setAttributeValue(context, ATTRIBUTE_WMSITEMHISTORY, strHistoryOld);
							}
						}
					}

				}
			}	
			
            mapReturnMap.put("Action","success");
        } catch (Exception exception) {
         exception.printStackTrace();
            mapReturnMap.put("Action","Stop");
            mapReturnMap.put("Message",exception.getMessage());
        }
        return mapReturnMap;
    }
	/**
	 * Method to get Amount after the Object Creation
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public static double getAmountForPDF(Context context, String[] args) throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try{
			HashMap programMap      = (HashMap)JPO.unpackArgs(args);
			String strObjID         = (String) programMap.get("objectId");
			
			String strType        = (String) programMap.get("type");
			
				switch(strType){
					case "WMSRICMaster" :
								dAmount = getMasterAmount(context, new String[]{strObjID, RELATIONSHIP_WMSRICMASTER_RIC, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								break;
					case "WMSAEMaster" :
								dAmount = getMasterAmount(context, new String[]{strObjID, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								break;
					case "WMSRIC" :
								dAmount = getHeadAmount(context, new String[]{strObjID, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								break;
					case "WMSAE" :
								dAmount = getHeadAmount(context, new String[]{strObjID, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								break;
					case "WMSDCS" :
								dAmount = getHeadAmount(context, new String[]{strObjID, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
								break;
					case "WMSRICItem" :
					case "WMSAEItem" :
					case "WMSDCSItem" :
								dAmount = getItemAmount(context, new String[]{strObjID});
								break;
					default :
				}
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		return dAmount;
	}

	/**
	 * Method to get Total Amount after the Object Creation
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public static double getTotalAmountforPDF(Context context, String[] args) throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try{
			HashMap programMap      = (HashMap)JPO.unpackArgs(args);
			String strObjID         = (String) programMap.get("objectId");
			
			String strType        = (String) programMap.get("type");
				switch(strType){
					case "WMSRICMaster" :
								dAmount = getMasterTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSRICMASTER_RIC, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								break;
					case "WMSAEMaster" :
								dAmount = getMasterTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								break;
					case "WMSRIC" :
								dAmount = getHeadTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								break;
					case "WMSAE" :
								dAmount = getHeadTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								break;
					case "WMSDCS" :
								dAmount = getHeadTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
								break;
					case "WMSRICItem" :
					case "WMSAEItem" :
					case "WMSDCSItem" :
								dAmount = getItemTotalAmount(context, new String[]{strObjID});
								break;
					default :
				}
				
				
			}           
	  catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		return dAmount;
	}
	/**
	 * Method to get Total Amount after the Object Creation (Including Consultancy + Contingency)
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public static double getPart1TotalAmountforPDF(Context context, String[] args) throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try{
			HashMap programMap      = (HashMap)JPO.unpackArgs(args);
			String strObjID         = (String) programMap.get("objectId");
			
			String strType        = (String) programMap.get("type");
				switch(strType){
					case "WMSRICMaster" :
								dAmount = getPart1MasterTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSRICMASTER_RIC, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								
								break;
					case "WMSAEMaster" :
								dAmount = getPart1MasterTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSAEMASTER_AE, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								
								break;
					case "WMSDCSMaster" :
								dAmount = getPart1MasterTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSDCSMASTER_DCS, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
								break;
					case "WMSRIC" :
								dAmount = getPart1HeadTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSRIC_RIC, RELATIONSHIP_WMSRIC_RICITEM});
								break;
					case "WMSAE" :
								dAmount = getPart1HeadTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
								break;
					case "WMSDCS" :
								dAmount = getPart1HeadTotalAmount(context, new String[]{strObjID, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
								break;
					default :
								
				}
								
				
			}           
		
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		return dAmount;
	}
	
		
	public static boolean createRouteWithPersons(Context context, String [] args) throws Exception {
		boolean bFlag = false;
        try
        {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strObjectId = (String) programMap.get("objectId");
			MapList mlRouteMembers = (MapList) programMap.get("RouteMembers");
			
			String strRouteCompletionAction = "Promote Connected Object";
			String strRouteBasePurpose = "Approval";
			String strBaseState = "Review";
			
			ContextUtil.startTransaction(context, true);
			
			Route routeBean = (Route) DomainObject.newInstance(context, DomainConstants.TYPE_ROUTE);
			
			Map mpRelAttributeMap = new Hashtable();
			mpRelAttributeMap.put("routeBasePurpose", strRouteBasePurpose);
			mpRelAttributeMap.put(strObjectId, strBaseState);
				
			Map routeMap = Route.createRouteWithScope(context, strObjectId, null, null, true,(Hashtable) mpRelAttributeMap);
			String strRouteId = (String) routeMap.get("routeId");
			routeBean.setId(strRouteId);
			
			//Set the attributes of the new Route Object
			Map mpRouteAttributeMap = new HashMap();
			mpRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE, strRouteBasePurpose);
			mpRouteAttributeMap.put(ATTRIBUTE_ROUTE_COMPLETION_ACTION, strRouteCompletionAction);
			routeBean.setAttributeValues(context, mpRouteAttributeMap);
			
			String[] sArrMembers = new String[mlRouteMembers.size()];
			for (int i=0; i < mlRouteMembers.size(); i++) {
				Map oMap = (Map) mlRouteMembers.get(i);
				String strPersonId = (String) oMap.get(DomainConstants.SELECT_ID);
				sArrMembers[i] = strPersonId; 
			}
			
			// Adding Members to Route
			routeBean.AddMembers(context, sArrMembers);
			
			StringList slMembersConnectionId = routeBean.getInfoList(context, "relationship["+DomainConstants.RELATIONSHIP_ROUTE_NODE+"].id");
			
			StringList sl = new StringList(1);
			sl.add(DomainRelationship.SELECT_TO_ID);
			
			String sConnectionId = DomainConstants.EMPTY_STRING;
			String strToId = DomainConstants.EMPTY_STRING;
			String strPersonId = DomainConstants.EMPTY_STRING;
			String strInstruction = DomainConstants.EMPTY_STRING;
			StringList slToIds = null;
			int iSequence = 1;
			DomainRelationship domRelObj = null;
			Map relationshipData = null;
			Map routeTaskAttributeMap = null;
			
			for (Object ItemObject:slMembersConnectionId) {
				sConnectionId = (String)ItemObject;
				domRelObj = new DomainRelationship(sConnectionId);
				relationshipData = domRelObj.getRelationshipData(context,sl);
				slToIds = (StringList) relationshipData.get(DomainRelationship.SELECT_TO_ID);
				strToId = (String) slToIds.get(0);
				for (int i=0; i < mlRouteMembers.size(); i++) {
					Map oMap = (Map) mlRouteMembers.get(i);
					strPersonId = (String) oMap.get(DomainConstants.SELECT_ID);
					if (strToId.equals(strPersonId)) {
						iSequence = (int) oMap.get("Order");
						strInstruction = (String) oMap.get("Instructions");
						routeTaskAttributeMap = new HashMap();
						routeTaskAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_ACTION, "Approve");
						routeTaskAttributeMap.put(DomainConstants.ATTRIBUTE_TITLE, "Approve Task");
						routeTaskAttributeMap.put(DomainConstants.ATTRIBUTE_ASSIGNEE_SET_DUEDATE, "Yes");
						routeTaskAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_SEQUENCE, ""+iSequence);
						routeTaskAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_INSTRUCTIONS, strInstruction);
						domRelObj.setAttributeValues(context, routeTaskAttributeMap);
					}
				}
			}
									
			bFlag = true;
			ContextUtil.commitTransaction(context);
			
        } catch(Exception exception) {
			ContextUtil.abortTransaction(context);
            exception.printStackTrace();
            throw exception;
        }
		return bFlag;
    }
	
	public Vector getRouteDetails(Context context,String[] args) throws Exception {
		Vector colVector = new Vector();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramList = (HashMap) programMap.get("paramList");
			MapList objectList  = (MapList) programMap.get("objectList");
			StringBuilder sb= null;
			Iterator<Map> itr = objectList.iterator();
			String strId = DomainConstants.EMPTY_STRING;
			String strType = DomainConstants.EMPTY_STRING;
			String strCurrent = DomainConstants.EMPTY_STRING;
			String strObjId = DomainConstants.EMPTY_STRING;
			String strObjName = DomainConstants.EMPTY_STRING;
			DomainObject doObject = null;
			MapList mlExtRoutes = null;
			String sWhere = DomainConstants.EMPTY_STRING;
			Map oMap = null;
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			while(itr.hasNext()) {
				Map m = itr.next();
				strId = (String)m.get(DomainObject.SELECT_ID);
				strCurrent = (String)m.get(DomainObject.SELECT_CURRENT);
				strType = (String)m.get(DomainObject.SELECT_TYPE);
				doObject = new DomainObject(strId);
				if ("Create".equals(strCurrent)) {
					sWhere = "current != Complete";
					mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
														DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
														DomainConstants.TYPE_ROUTE, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														sWhere, // object where clause
														null); // relationship where clause
					sb=new StringBuilder();
					if (mlExtRoutes.size() == 1) {
						String strURL="../common/emxTree.jsp";
						oMap = (Map) mlExtRoutes.get(0);
						strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
						strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
						sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
						sb.append(strObjName);
						sb.append("</a>");
					} else if (mlExtRoutes.size() == 0) {
						String strURL="../wms/wmsRouteCreationDialogFS.jsp?";
						if(TYPE_WMSTECHNICALSANCTION.equals(strType)) {
							strURL = strURL+"wmsSearch=all";
						} else {
							strURL = strURL+"wmsSearch=organization";
						}
						//String strURL="../wms/wmsRouteCreationDialogFS.jsp?WMSSearch=all";
						sb.append("<a href=\"javascript:showModalDialog('"+strURL+"%26objectId="+strId+"','600','400','false');\" >");            
						sb.append("<img border='0' title='Route' src='../common/images/iconSmallRoute.png' height='15px' name='Route' id='Route' alt='Route'/>");
						sb.append("</a>");
					}
				} else {
					mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
														DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
														DomainConstants.TYPE_ROUTE, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														null, // object where clause
														null); // relationship where clause
					mlExtRoutes.sort("originated", "descending", "date");
					sb=new StringBuilder();
					if (mlExtRoutes.size() > 0) {
						String strURL="../common/emxTree.jsp";
						oMap = (Map) mlExtRoutes.get(0);
						strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
						strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
						sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
						sb.append(strObjName);
						sb.append("</a>");
					}
				}
				colVector.add(sb.toString());
			}
			 
		} catch(Exception e) {
			e.printStackTrace();
		}
		return colVector;
	}
	
	/**
    ** This Method check Route object.
    */
    public static int checkApprovalRoute(Context context, String[] args)throws Exception {
		int iResult = 1;
		try {
			String sObjectId = args[0];
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			
			String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoApprovalRoute");
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sWhere = "current != Complete";
			MapList mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
													DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
													DomainConstants.TYPE_ROUTE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
			if (mlExtRoutes.size() != 1) {
				emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				return 1;
			}
			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}
	
	/**
    ** This Method create Route object.
    */
    public static int startApprovalRoute(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sWhere = "current != Complete";
			MapList mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
													DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
													DomainConstants.TYPE_ROUTE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
			if (mlExtRoutes.size() == 1) {
				Map oMap = (Map) mlExtRoutes.get(0);
				String strRouteId = (String) oMap.get(DomainConstants.SELECT_ID);
				Route newRouteObj = (Route) DomainObject.newInstance(context, DomainConstants.TYPE_ROUTE);
				newRouteObj.setId(strRouteId);
				String strStatus = newRouteObj.getAttributeValue(context, DomainConstants.ATTRIBUTE_ROUTE_STATUS);
				if(strStatus.equalsIgnoreCase("Not Started")) {
					newRouteObj.promote(context);
				}
			}
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}

	public boolean hasAccessForDashboards(Context context, String[] args)throws Exception{
		boolean bHasAccess = true;
		try{
			String strPersonId = PersonUtil.getPersonObjectID(context);
			if(UIUtil.isNotNullAndNotEmpty(strPersonId)){
				DomainObject doPerson = new DomainObject(strPersonId);
				String strHostPersonRole = doPerson.getAttributeValue(context, ATTRIBUTE_HOST_ROLE);
				if(UIUtil.isNullOrEmpty(strHostPersonRole) || "User".equals(strHostPersonRole))
					bHasAccess = false;
			}			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}	
		return bHasAccess;
	}

	@com.matrixone.apps.framework.ui.CreateProcessCallable
	public Map createItem(Context context, String [] args) {
		Map retMap = new HashMap();
		try {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sTypeActual = (String) programMap.get("TypeActual");
			String sType = (String) programMap.get("type");
			String sPolicy = (String) programMap.get("policy");
			String sParentOID = (String) programMap.get("parentOID");
			String sSequenceNumber = (String) programMap.get("SequenceNumber");
			String sTitle = (String) programMap.get("Title");
			String sDescription = (String) programMap.get("Description");
			String sUOM = (String) programMap.get("UoM");
			String sQuantity = (String) programMap.get("Quantity");
			String sRate = (String) programMap.get("Rate");
			String sGST = (String) programMap.get("GST");
			String sItemType = (String) programMap.get("Authorized");
			String sRemarks = (String) programMap.get("Remarks");
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			
			String sRelationship = DomainConstants.EMPTY_STRING;
			String sWhere = DomainConstants.EMPTY_STRING;
			String strMessage = DomainConstants.EMPTY_STRING;
			
			if (TYPE_WMSDCSITEM.equals(sTypeActual)) {
				sRelationship = RELATIONSHIP_WMSDCS_DCSITEM;
				sWhere = DomainConstants.SELECT_DESCRIPTION+" == \""+sDescription+"\"";
				strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.DCSItemCreate");
			} else {
				sRelationship = TYPE_WMSAEITEM.equals(sTypeActual) ? RELATIONSHIP_WMSAE_AEITEM : RELATIONSHIP_WMSRIC_RICITEM;
				sWhere = "attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value == \""+sTitle+"\"";
				strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.ItemCreate");
			}
			
			DomainObject doParent = new DomainObject(sParentOID);
			MapList mlItemObjects = doParent.getRelatedObjects(context, // matrix context
														sRelationship, // relationship pattern
														sTypeActual, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														sWhere, // object where clause
														null); // relationship where clause
			if (mlItemObjects.size() > 0) {
				//emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				retMap.put("Action", "Stop");
				retMap.put("ErrorMessage", strMessage);
			} else {
				Map mAttrMap = new HashMap();
				mAttrMap.put(ATTRIBUTE_WMSITEMSEQUENCE, sSequenceNumber);
				mAttrMap.put(DomainConstants.ATTRIBUTE_TITLE, sTitle);
				mAttrMap.put(ATTRIBUTE_WMS_UNIT_OF_MEASURE, sUOM);
				mAttrMap.put(DomainConstants.ATTRIBUTE_QUANTITY, sQuantity);
				mAttrMap.put(ATTRIBUTE_RATE, sRate);
				mAttrMap.put(ATTRIBUTE_WMSGST, sGST);
				mAttrMap.put(ATTRIBUTE_WMSAUTHORIZED, sItemType);
				mAttrMap.put(ATTRIBUTE_REMARKS, sRemarks);
				
				String strObjectId = FrameworkUtil.autoName(context, sType, sPolicy);
				DomainObject domObject = DomainObject.newInstance(context, strObjectId);
				domObject.setDescription(context, sDescription);
				retMap.put(DomainConstants.SELECT_ID, strObjectId);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			retMap.put("Action", "Stop");
			retMap.put("Message", e.getMessage());
		}
		return retMap;
	}
		
	/**
    ** This Method get Object and its Child object.
    */
    public StringList getObjectAndChilds(Context context, String[] args)throws Exception {
		StringList slAllObjects = new StringList();
		try {
			String sObjectId = args[0];
			String sMasterRelationship = args[1];
			String sRelationship = args[2];
			String sItemRelationship = args[3];
			DomainObject doObj = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
			String sItemId1 = DomainConstants.EMPTY_STRING;
			String sItemId2 = DomainConstants.EMPTY_STRING;
			
			StringList slItem = doObj.getInfoList(context, "from["+sItemRelationship+"].to.id");
			slAllObjects.addAll(slItem);
			
			StringList slObjects = doObj.getInfoList(context, "from["+sRelationship+"].to.id");
			for (Object ItemObject:slObjects) {
				sItemId = (String)ItemObject;
				StringList slAllHeads = getObjectAndChilds(context, new String[]{sItemId, sMasterRelationship, sRelationship, sItemRelationship});
				slAllObjects.addAll(slAllHeads);
			}
			StringList slObjects1 = doObj.getInfoList(context, "from["+sMasterRelationship+"].to.id");
			for (Object ItemObject:slObjects1) {
				sItemId = (String)ItemObject;
				StringList slAllMasters = getObjectAndChilds(context, new String[]{sItemId, sMasterRelationship, sRelationship, sItemRelationship});
				slAllObjects.addAll(slAllMasters);
			}
			String sType = doObj.getInfo(context, DomainConstants.SELECT_TYPE);
			if (!TYPE_WMSRICMASTER.equals(sType) && !TYPE_WMSAEMASTER.equals(sType)) {
				slAllObjects.add(sObjectId);
			}
		} catch(Exception ex){
			slAllObjects = new StringList();
			ex.printStackTrace();
		}
		return slAllObjects;
    }
	
	/**
    ** This Method Delete RIC/AE/DCS Objects and its Child object.
    */
    public String deleteWMSObjects(Context context, String[] args)throws Exception {
		String strErrorMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.DeleteFailed");
		try {
			StringList slAllObjects = new StringList();
			StringList slObjects = new StringList();
			String sContextUser = context.getUser();
			for(int i=0;i<args.length;i++) {
				String sObjectId = args[i];
				StringList slObjList = FrameworkUtil.split(sObjectId,"|");
				sObjectId = (String)slObjList.get(slObjList.size()-3);
				DomainObject doObj = new DomainObject(sObjectId);
				String sType = doObj.getInfo(context, DomainConstants.SELECT_TYPE);
				String sState = doObj.getInfo(context, DomainConstants.SELECT_CURRENT);
				String strOwner = doObj.getInfo(context, DomainConstants.SELECT_OWNER);
				
				String sMasterRelationship = DomainConstants.EMPTY_STRING;
				String sRelationship = DomainConstants.EMPTY_STRING;
				String sItemRelationship = DomainConstants.EMPTY_STRING;
				
				switch(sType){
					case "WMSRICMaster" :
					case "WMSRIC" :
					case "WMSRICItem" :
								sMasterRelationship = RELATIONSHIP_WMSRICMASTER_RIC;
								sRelationship = RELATIONSHIP_WMSRIC_RIC;
								sItemRelationship = RELATIONSHIP_WMSRIC_RICITEM;
								break;
					case "WMSAEMaster" :
					case "WMSAE" :
					case "WMSAEItem" :
								sMasterRelationship = RELATIONSHIP_WMSAEMASTER_AE;
								sRelationship = RELATIONSHIP_WMSAE_AE;
								sItemRelationship = RELATIONSHIP_WMSAE_AEITEM;
								break;
					case "WMSDCSMaster" :
					case "WMSDCS" :
					case "WMSDCSItem" :
								sMasterRelationship = RELATIONSHIP_WMSDCSMASTER_DCS;
								sRelationship = RELATIONSHIP_WMSDCS_DCS;
								sItemRelationship = RELATIONSHIP_WMSDCS_DCSITEM;
								break;
					default :
								sMasterRelationship = DomainConstants.EMPTY_STRING;
								sRelationship = DomainConstants.EMPTY_STRING;
								sItemRelationship = DomainConstants.EMPTY_STRING;
				}
				
				if ("Create".equals(sState)) {
					slObjects = getObjectAndChilds(context, new String[]{sObjectId, sMasterRelationship, sRelationship, sItemRelationship});
				} else if("Exists".equals(sState)) {
					if (TYPE_WMSDCS.equals(sType) || TYPE_WMSDCSITEM.equals(sType)) {
						slObjects = getObjectAndChilds(context, new String[]{sObjectId, sMasterRelationship, sRelationship, sItemRelationship});
					} else {
						String sParentState = doObj.getInfo(context, "to["+sItemRelationship+"].from.current");
						if ("Create".equals(sParentState)) {
							slObjects = getObjectAndChilds(context, new String[]{sObjectId, sMasterRelationship, sRelationship, sItemRelationship});
						} else {
							String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.DeleteParentImproperState");
							return strMessage;
						}
					}
				} else {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.DeleteImproperState");
					return strMessage;
				}
				
				for (Object ItemObject:slObjects) {
					String sItemId = (String)ItemObject;
					if(!slAllObjects.contains(sItemId)) {
						slAllObjects.add(sItemId);
					}
				}
			}
			String[] objIds = new String[slAllObjects.size()];
			objIds = slAllObjects.toArray(objIds);
			DomainObject.deleteObjects(context, objIds);
			strErrorMessage = "success";	
		} catch(Exception ex){
			strErrorMessage = ex.getMessage();
			ex.printStackTrace();
		}
		return strErrorMessage;
    }
		
	/**
	* This Method Updates Unique Title
	**/
	@com.matrixone.apps.framework.ui.CellUpdateJPOCallable
	public boolean checkUniqueTitle(Context context,String args[]) throws Exception {
		boolean flag = true;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);			
			String sObjectId =(String) programMap.get("objectId");
			String sNewValue =(String) programMap.get("enteredValue");
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)) {
			DomainObject doObject = new DomainObject(sObjectId);
			String sType = doObject.getInfo(context, DomainConstants.SELECT_TYPE);
						
			String sParentOID = DomainConstants.EMPTY_STRING;
			String sRelationships = DomainConstants.EMPTY_STRING;
			String sWhere = DomainConstants.EMPTY_STRING;
			
			switch(sType){
				case "WMSRIC" :
							sParentOID = doObject.getInfo(context, "to["+RELATIONSHIP_WMSRICMASTER_RIC+"].from.id");
							if (UIUtil.isNullOrEmpty(sParentOID)) {
								sParentOID = doObject.getInfo(context, "to["+RELATIONSHIP_WMSRIC_RIC+"].from.id");
							}
							sRelationships = RELATIONSHIP_WMSRICMASTER_RIC+","+RELATIONSHIP_WMSRIC_RIC;
							sWhere = "attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value == \""+sNewValue+"\"";
							break;
				case "WMSRICItem" :
							sParentOID = doObject.getInfo(context, "to["+RELATIONSHIP_WMSRIC_RICITEM+"].from.id");
							sRelationships = RELATIONSHIP_WMSRIC_RICITEM;
							sWhere = "attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value == \""+sNewValue+"\"";
							break;
				case "WMSAE" :
							sParentOID = doObject.getInfo(context, "to["+RELATIONSHIP_WMSAEMASTER_AE+"].from.id");
							if (UIUtil.isNullOrEmpty(sParentOID)) {
								sParentOID = doObject.getInfo(context, "to["+RELATIONSHIP_WMSAE_AE+"].from.id");
							}
							sRelationships = RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE;
							sWhere = "attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value == \""+sNewValue+"\"";
							break;
				case "WMSAEItem" :
							sParentOID = doObject.getInfo(context, "to["+RELATIONSHIP_WMSAE_AEITEM+"].from.id");
							sRelationships = RELATIONSHIP_WMSAE_AEITEM;
							sWhere = "attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value == \""+sNewValue+"\"";
							break;
				case "WMSDCS" :
							sParentOID = doObject.getInfo(context, "to["+RELATIONSHIP_WMSDCSMASTER_DCS+"].from.id");
							if (UIUtil.isNullOrEmpty(sParentOID)) {
								sParentOID = doObject.getInfo(context, "to["+RELATIONSHIP_WMSDCS_DCS+"].from.id");
							}
							sRelationships = RELATIONSHIP_WMSDCSMASTER_DCS+","+RELATIONSHIP_WMSDCS_DCS;
							sWhere = DomainConstants.SELECT_DESCRIPTION+" == \""+sNewValue+"\"";
							break;
				case "WMSDCSItem" :
							sParentOID = doObject.getInfo(context, "to["+RELATIONSHIP_WMSDCS_DCSITEM+"].from.id");
							sRelationships = RELATIONSHIP_WMSDCS_DCSITEM;
							sWhere = DomainConstants.SELECT_DESCRIPTION+" == \""+sNewValue+"\"";
							break;
				default :
							sParentOID = DomainConstants.EMPTY_STRING;
							sRelationships = DomainConstants.EMPTY_STRING;
							sWhere = DomainConstants.EMPTY_STRING;
			}
			
			if (UIUtil.isNotNullAndNotEmpty(sParentOID)) {
				DomainObject doParent = new DomainObject(sParentOID);
				MapList mlObjects = doParent.getRelatedObjects(context, // matrix context
															sRelationships, // relationship pattern
															sType, // type pattern
															busSelects, // object selects
															null, // relationship selects
															false, // to direction
															true, // from direction
															(short) 1, // recursion level
															sWhere, // object where clause
															null); // relationship where clause*/
				if (mlObjects.size() == 0) {
					flag = true;
				}else {
					flag = false;
				}
			}
		   }
		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static double getPart1MasterTotalWithoutConsultancyAmount(Context context,String[] args)throws Exception {
		double dAmount = 0;
		try {
            String sObjectId = args[0];
            String sMasterRelationship = args[1];
            String sRelationship = args[2];
            String sItemRelationship = args[3];
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
									
			StringList slObject = doObject.getInfoList(context, "from["+sMasterRelationship+"].to.id");
			for (Object ItemObject:slObject) {
				sItemId = (String)ItemObject;
				double dTempAmount = getPart1HeadTotalWithoutConsulancyAmount(context, new String[]{sItemId, sRelationship, sItemRelationship});
				dAmount = dAmount + dTempAmount;
			}
			
			return dAmount;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public static double getPart1HeadTotalWithoutConsulancyAmount(Context context,String[] args)throws Exception {
		double dAmount = 0;
		double dExtra = 0;
		try {
            String sObjectId = args[0];
            String sRelationship = args[1];
            String sItemRelationship = args[2];
			
			DomainObject doObject = new DomainObject(sObjectId);
			String sItemId = DomainConstants.EMPTY_STRING;
			
			String sContingency = (String) doObject.getAttributeValue(context, ATTRIBUTE_WMSCONTINGENCY);
			if (UIUtil.isNotNullAndNotEmpty(sContingency)) {
				dExtra = (100 + Double.parseDouble(sContingency)) / 100;
			}
						
			StringList slObject = doObject.getInfoList(context, "from["+sRelationship+"].to.id");
			for (Object ItemObject:slObject) {
				sItemId = (String)ItemObject;
				double dTempAmount = getPart1HeadTotalAmount(context, new String[]{sItemId, sRelationship, sItemRelationship});
				dAmount = dAmount + dTempAmount;
			}
			StringList slItem = doObject.getInfoList(context, "from["+sItemRelationship+"].to.id");
			for (Object ItemObject:slItem) {
				sItemId = (String)ItemObject;
				double dTempAmount = getItemTotalAmount(context, new String[]{sItemId});
				dAmount = dAmount + dTempAmount;
			}
			
			return dExtra > 0 ? dAmount * dExtra : dAmount;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
		
		
	/**
    ** This Method check Edit Access to Add Route Template.
    */
	@com.matrixone.apps.framework.ui.ColJPOCallable
    public static StringList isTotalAmountEditable(Context context, String[] args)throws Exception {
		try {
			StringList isCellEditable = new StringList();
    		Map programMap 		= (Map) JPO.unpackArgs(args);
    		MapList objectList 	= (MapList) programMap.get("objectList");
			for (int i = 0 ; i < objectList.size(); i++) {
				Map objMap = (Map) objectList.get(i);
				String sType = (String) objMap.get("type");
				String sRelationship = (String) objMap.get("relationship");
				String strRelName = DomainConstants.EMPTY_STRING;
				switch(sType){
					case "WMSDefaultMaster" :
								isCellEditable.add("true");
								break;
					default :
								isCellEditable.add("false");
				}
			}
			return isCellEditable;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	
	/**
    ** This Method create Route object.
    */
    public static int createDefaultHeadsApprovalRoute(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			String sRTRelationship = args[1];
			String sRelationship = args[2];
			
			DomainObject doObj = new DomainObject(sObjectId);		
			String strRICCurrent = doObj.getInfo(context,"to["+RELATIONSHIP_WMSSOC_RICMASTER+"].from.current");
			String strAECurrent = doObj.getInfo(context,"to["+RELATIONSHIP_WMSSOC_AEMASTER+"].from.current");
			
			if(UIUtil.isNotNullAndNotEmpty(strRICCurrent) && "RIC".equals(strRICCurrent)){
				sRTRelationship = RELATIONSHIP_WMSRICMASTER_APPROVAL_TEMPLATE;
			}
			if(UIUtil.isNotNullAndNotEmpty(strAECurrent) && "AE".equals(strAECurrent)){
				sRTRelationship = RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE;
			}
			
			String strRelWhere ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
			MapList mlExtRoutes = checkForExistingRouteObject(context, doObj, strRelWhere);
			if(mlExtRoutes.size()>0) {
				restartExistingRoute(context,mlExtRoutes);
			} else {
			
				String sRouteDescription = (String)doObj.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
				String sState = (String)doObj.getInfo(context, DomainConstants.SELECT_CURRENT);
				String sPolicy = (String)doObj.getInfo(context, DomainConstants.SELECT_POLICY);
				String sApprovalTemplateId = (String)doObj.getInfo(context, "from["+sRTRelationship+"].to.id");
				createRouteFromTemplate(context, sObjectId, sApprovalTemplateId, sPolicy, sState, "state_Review");
			}
			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}
	
	
	public static int checkDefaultHeadsApprovalRouteTemplate(Context context, String[] args)throws Exception {
		int iResult = 1;
		try {
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId);		
			String strRICCurrent = doObj.getInfo(context,"to["+RELATIONSHIP_WMSSOC_RICMASTER+"].from.current");
			String strAECurrent = doObj.getInfo(context,"to["+RELATIONSHIP_WMSSOC_AEMASTER+"].from.current");
			String sRTRelationship = DomainConstants.EMPTY_STRING;

			if(UIUtil.isNotNullAndNotEmpty(strRICCurrent) && "RIC".equals(strRICCurrent)){
				sRTRelationship = RELATIONSHIP_WMSRICMASTER_APPROVAL_TEMPLATE;
			}
			if(UIUtil.isNotNullAndNotEmpty(strAECurrent) && "AE".equals(strAECurrent)){
				sRTRelationship = RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE;
			}
		
			String sApprovalTemplateId = (String)doObj.getInfo(context, "from["+sRTRelationship+"].to.id");
			if (!UIUtil.isNotNullAndNotEmpty(sApprovalTemplateId)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoApprovalTemplate");
				emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				return 1;
			}
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public boolean hasAccessToSOCDashboardCommands(Context context, String[] args) throws Exception 
    {
        try
        {
            String strPersonId = PersonUtil.getPersonObjectID(context);
            
            if(UIUtil.isNotNullAndNotEmpty(strPersonId))
            {
               DomainObject doPerson = new DomainObject(strPersonId);
			   String strHostPersonRole = doPerson.getAttributeValue(context,ATTRIBUTE_HOST_ROLE);
			   String strUserRole = EnoviaResourceBundle.getProperty(context, "WMS.DGNP.User.Role");
			   if(UIUtil.isNotNullAndNotEmpty(strHostPersonRole) && strHostPersonRole.contains(strUserRole))
					return true;
            }
            return false;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
	
	public boolean hasAccessToBudgetPlanningReports(Context context, String[] args) throws Exception 
    {
        try
        {
            String strPersonId = PersonUtil.getPersonObjectID(context);
            
            if(UIUtil.isNotNullAndNotEmpty(strPersonId))
            {
               DomainObject doPerson = new DomainObject(strPersonId);
			   String strHostPersonRole = doPerson.getAttributeValue(context,ATTRIBUTE_HOST_ROLE);
			   String strUserRole = EnoviaResourceBundle.getProperty(context, "WMS.DGNP.User.Role");
			   if(UIUtil.isNotNullAndNotEmpty(strHostPersonRole) && strHostPersonRole.contains(strUserRole))
					return false;
            }
            return true;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
}

