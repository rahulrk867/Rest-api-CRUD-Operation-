/*---------------------------------------------------------------------------------------------------------------
NAME		: WMSBudgetDashboard_mxJPO.java

------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.math.BigDecimal;
import java.util.Locale;
import java.math.RoundingMode;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PersonUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;


public class WMSBudgetDashboard_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSBudgetDashboard_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	public Map getBudgetDashboardData(Context context, String[] args)throws Exception{
		Map mBudgetInfo = null;
		try{
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strCodeHead = (String)programMap.get("CodeHead");
			String strCodeHeadYearFromJSP = (String)programMap.get("CodeHeadYear");
			MapList mlCodeHeads = new MapList();
		
			String strYear = strCodeHeadYearFromJSP;
			String strTotalAllocationCFY = "0.00";
			String strTotalConsumedCFY = "0.00";
			
			Map mAllocationCFY = null;
			Map mConsumptionCFY = null;
			Map mFundRequestAllocationCFY = null;
			Map mFundAllocationExpenditureCFY = null;

			if("CFY".equals(strYear))
			{
				LocalDateTime now = LocalDateTime.now();
				int year = now.getYear();
				int month = now.getMonthValue();
				
				if(month>3){
					strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
				}else{
					strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
				}
			}
			System.out.println("strYear ::: " + strYear);
			
			String strWhere = DomainConstants.EMPTY_STRING;
			if(UIUtil.isNotNullAndNotEmpty(strCodeHead) && "All".equals(strCodeHead)==false){
				strWhere = "name=='"+strCodeHead+"'";
			}
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainObject.SELECT_ID);
			strListBusSelects.add(DomainObject.SELECT_NAME);
			mlCodeHeads = DomainObject.findObjects(
					context,
					TYPE_WMS_CODE_HEAD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					strWhere,               // where expression
					DomainConstants.EMPTY_STRING,
					true,
					strListBusSelects, // object selects
					(short) 0);
					
			Map mTemp = null;
			double dTotalAllocatedAmountCFY = 0.0;
			double dTotalConsumedAmountCFY = 0.0;
			String strCodeHeadId = DomainConstants.EMPTY_STRING;
			for(int i=0;i<mlCodeHeads.size();i++){
				mTemp = (Map)mlCodeHeads.get(i);
				strCodeHeadId = (String)mTemp.get(DomainObject.SELECT_ID);
				
				if(UIUtil.isNotNullAndNotEmpty(strCodeHeadId)){
					String strCodeHeadYear = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"'].to.id dump");
					
					if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
						String strResutl = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"|to.current==Frozen].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						StringList slAmounts = FrameworkUtil.split(strResutl,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAllocatedAmountCFY = dTotalAllocatedAmountCFY + Double.valueOf((String)slAmounts.get(j));
						}
					}
					if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
						String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"'&& to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						if(UIUtil.isNotNullAndNotEmpty(strResult)){
							StringList slAmounts = FrameworkUtil.split(strResult,"|");
							for(int j=0;j<slAmounts.size();j++){
								dTotalConsumedAmountCFY = dTotalConsumedAmountCFY + Double.valueOf((String)slAmounts.get(j));
							}
						}
					}
					if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
						String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.current==Approved)].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						if(UIUtil.isNotNullAndNotEmpty(strResult)){
							StringList slAmounts = FrameworkUtil.split(strResult,"|");
							for(int j=0;j<slAmounts.size();j++){
								dTotalConsumedAmountCFY = dTotalConsumedAmountCFY - Double.valueOf((String)slAmounts.get(j));
							}
						}
					}
					if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
						mAllocationCFY = (Map)getAllocationInCFY(context,strCodeHeadYear,mAllocationCFY);
						mConsumptionCFY = (Map)getConsumptionInCFY(context,strCodeHeadYear,strYear,mConsumptionCFY);
						mFundRequestAllocationCFY = (Map)getFundRequestAllocationCFY(context,strCodeHeadYear,strYear,mFundRequestAllocationCFY);
						mFundAllocationExpenditureCFY = (Map)getFundAllocationExpenditureCFY(context,strCodeHeadYear,strYear,mFundAllocationExpenditureCFY);
					}
				}
				
			}
			mBudgetInfo = new HashMap();
			
			if(mAllocationCFY == null){
				mAllocationCFY = (Map)updateEmptyMap(mAllocationCFY);
			}
			if(mConsumptionCFY == null){
				mConsumptionCFY = (Map)updateEmptyMap(mConsumptionCFY);
			}
			if(mFundRequestAllocationCFY == null){
				mFundRequestAllocationCFY = (Map)updateEmptyComparisionMap(mFundRequestAllocationCFY);
			}
			if(mFundAllocationExpenditureCFY == null){
				mFundAllocationExpenditureCFY = (Map)updateEmptyComparisionMap(mFundAllocationExpenditureCFY);
			}
			
			
			strTotalAllocationCFY = WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAllocatedAmountCFY);
			strTotalConsumedCFY = WMSUtil_mxJPO.converToIndianCurrency(context,dTotalConsumedAmountCFY);
			
			double dPercentageConsumption = 0.0;
			if(dTotalConsumedAmountCFY>0 && dTotalAllocatedAmountCFY>0){
				dPercentageConsumption = dTotalConsumedAmountCFY/dTotalAllocatedAmountCFY*100;
			}
			String strPercentage = new BigDecimal(dPercentageConsumption).setScale(2, RoundingMode.FLOOR).toPlainString();
			
			mBudgetInfo.put("TotalAllocationCFY",strTotalAllocationCFY);
			mBudgetInfo.put("TotalConsumedCFY",strTotalConsumedCFY);
			mBudgetInfo.put("PercentageConsumption",strPercentage);
			mBudgetInfo.put("AllocationsCFY",mAllocationCFY);
			mBudgetInfo.put("ConsumptionsCFY",mConsumptionCFY);
			mBudgetInfo.put("FundRequestAllocationCFY",mFundRequestAllocationCFY);
			mBudgetInfo.put("FundAllocationExpenditureCFY",mFundAllocationExpenditureCFY);
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mBudgetInfo;
	}
	
	
	private Map getAllocationInCFY(Context context, String strCodeHeadYear, Map mAllocationCFY)throws Exception{
		try{
			if(mAllocationCFY == null){
				mAllocationCFY = new HashMap();
			}
			if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
				String[] sMonths = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				for(int i=0;i<sMonths.length;i++){
					strMonth = (String)sMonths[i];					
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"|(to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current=='Frozen')].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					double dTotal = 0.0;
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					strAmount = (String)mAllocationCFY.get(strMonth);
					if(UIUtil.isNotNullAndNotEmpty(strAmount)){
						dTotal = Double.valueOf(strAmount) + dTotal;
					}
					mAllocationCFY.put(strMonth,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mAllocationCFY;
		
	}
	
	private Map getConsumptionInCFY(Context context, String strCodeHeadYear,String strYear, Map mConsumptionCFY)throws Exception{
		if(mConsumptionCFY == null){
				mConsumptionCFY = new HashMap();
		}
		try{
			if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
				String[] sMonths = new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"};
				String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				for(int i=0;i<sMonths.length;i++){
					strMonth = (String)sMonths[i];
					double dTotal = 0.0;
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current==Approved)].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal - Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strAmount = (String)mConsumptionCFY.get((String)sMonthNames[i]);
					if(UIUtil.isNotNullAndNotEmpty(strAmount)){
						dTotal = Double.valueOf(strAmount) + dTotal;
					}
					mConsumptionCFY.put((String)sMonthNames[i],new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());					
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mConsumptionCFY;
		
	}
	
	private Map getFundRequestAllocationCFY(Context context, String strCodeHeadYear,String strYear, Map mFundRequestAllocationCFY)throws Exception{
		if(mFundRequestAllocationCFY == null){
				mFundRequestAllocationCFY = new HashMap();
		}
		try{
			if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
				String[] sMonths = new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"};
				String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				for(int i=0;i<sMonths.length;i++){
					strMonth = (String)sMonths[i];
					double dFundRequestTotal = 0.0;
					double dFundReleaseTotal = 0.0;
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current!='Create'].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dFundRequestTotal = dFundRequestTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current=='Approved')].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dFundReleaseTotal = dFundReleaseTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strAmount = (String)mFundRequestAllocationCFY.get((String)sMonthNames[i]);
					if(UIUtil.isNotNullAndNotEmpty(strAmount)){
						StringList slAmounts = FrameworkUtil.split(strAmount,"|");
						dFundRequestTotal = dFundRequestTotal + Double.valueOf((String)slAmounts.get(0));
						dFundReleaseTotal = dFundReleaseTotal + Double.valueOf((String)slAmounts.get(1));
					}
					mFundRequestAllocationCFY.put((String)sMonthNames[i],new BigDecimal(dFundRequestTotal).setScale(2, RoundingMode.FLOOR).toPlainString()+"|"+new BigDecimal(dFundRequestTotal-dFundReleaseTotal).setScale(2, RoundingMode.FLOOR).toPlainString());					
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mFundRequestAllocationCFY;
		
	}
	
	private Map getFundAllocationExpenditureCFY(Context context, String strCodeHeadYear,String strYear, Map mFundAllocationExpenditureCFY)throws Exception{
		if(mFundAllocationExpenditureCFY == null){
				mFundAllocationExpenditureCFY = new HashMap();
		}
		try{
			if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
				String[] sMonths = new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"};
				String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				for(int i=0;i<sMonths.length;i++){
					strMonth = (String)sMonths[i];
					double dTotal = 0.0;
					double dBillTotal = 0.0;
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current=='Approved')].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current=='Approved')].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal - Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && (to.current=='Approved' || to.current=='Paid'))].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dBillTotal = dBillTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strAmount = (String)mFundAllocationExpenditureCFY.get((String)sMonthNames[i]);
					if(UIUtil.isNotNullAndNotEmpty(strAmount)){
						StringList slAmounts = FrameworkUtil.split(strAmount,"|");
						dTotal = dTotal + Double.valueOf((String)slAmounts.get(0));
						dBillTotal = dBillTotal + Double.valueOf((String)slAmounts.get(1));
					}
					mFundAllocationExpenditureCFY.put((String)sMonthNames[i],new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString()+"|"+new BigDecimal(dBillTotal).setScale(2, RoundingMode.FLOOR).toPlainString());					
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mFundAllocationExpenditureCFY;
		
	}
	
	
	private Map updateEmptyMap(Map map){
		map = new HashMap();
		String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
		String strMonth = DomainConstants.EMPTY_STRING;
		for(int i=0;i<sMonthNames.length;i++){
			strMonth = (String)sMonthNames[i];
			map.put(strMonth,"0.00");
		}
		return map;
	}
	
	private Map updateEmptyComparisionMap(Map map){
		map = new HashMap();
		String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
		String strMonth = DomainConstants.EMPTY_STRING;
		for(int i=0;i<sMonthNames.length;i++){
			strMonth = (String)sMonthNames[i];
			map.put(strMonth,"0.00|0.00");
		}
		return map;
		
	}
}
			
	
 