/*---------------------------------------------------------------------------------------------------------------
NAME		: WMSBudgetManagement_mxJPO.java

DESCRIPTION	: Purpose of JPO is to Create Admin Approvals  and perform the utility operations on it

CREATED		: August 13 2019

AUTHOR		: Divyashree B K

HISTORY		:

	Divyashree B K	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;
import java.math.BigDecimal;
import java.util.Locale;
import java.math.RoundingMode;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectConcept;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PersonUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import matrix.db.Policy;
import com.matrixone.jdom.Element;
import matrix.util.Pattern;

public class WMSBudgetManagement_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSBudgetManagement_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getCodeHeads(Context context, String[] args) throws Exception{
		try{
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainObject.SELECT_ID);
			strListBusSelects.add(DomainObject.SELECT_NAME);
			strListBusSelects.add("attribute[Title].value");
			strListBusSelects.add("attribute[WMSCodeHeadName].value");
			strListBusSelects.add(DomainObject.SELECT_DESCRIPTION);
			MapList mlRevisionList = DomainObject.findObjects(
					context,
					TYPE_WMS_CODE_HEAD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.EMPTY_STRING,               // where expression
					DomainConstants.EMPTY_STRING,
					true,
					strListBusSelects, // object selects
					(short) 0);
			return mlRevisionList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getCodeHeadYearConsumedAmount(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for(int i =0;i<objectList.size();i++){
				slReturnList.add("0");
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}

	@com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getFundRequests(Context context, String[] args) throws Exception {
		MapList mlBillItems = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");

            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
				slObjectSelects.add("attribute[Remarks]");
				slObjectSelects.add(DomainObject.SELECT_OWNER);
				slObjectSelects.add(DomainObject.SELECT_CURRENT);
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
                mlBillItems = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_WO_FUND_REQUEST,
															TYPE_WMS_FUND_REQUEST,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
															
				String strCtxUser = (String)context.getUser();
				Map mTemp = null;					
				String strCurrent = DomainConstants.EMPTY_STRING;
				String strOwner = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlBillItems.size();i++){
					mTemp = (Map)mlBillItems.get(i);
					strCurrent = (String)mTemp.get(DomainObject.SELECT_CURRENT);
					strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
					if(strCtxUser.equals(strOwner) == false || "Create".equals(strCurrent) == false){
						mTemp.put("RowEditable", "readonly");
						mTemp.put("disableSelection", "true");
					}
				}
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlBillItems;
	}
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getFundRelease(Context context, String[] args) throws Exception {
		MapList mlBillItems = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");

            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
				slObjectSelects.add("attribute[Remarks]");
				slObjectSelects.add(DomainObject.SELECT_OWNER);
				slObjectSelects.add(DomainObject.SELECT_CURRENT);
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
                mlBillItems = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_WO_FUND_RELEASE,
															TYPE_WMS_FUND_RELEASE,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
															String strCtxUser = (String)context.getUser();
				Map mTemp = null;					
				String strCurrent = DomainConstants.EMPTY_STRING;
				String strOwner = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlBillItems.size();i++){
					mTemp = (Map)mlBillItems.get(i);
					strCurrent = (String)mTemp.get(DomainObject.SELECT_CURRENT);
					strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
					if(strCtxUser.equals(strOwner) == false && "Create".equals(strCurrent) == false){
						mTemp.put("RowEditable", "readonly");
						mTemp.put("disableSelection", "true");
					}
				}
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlBillItems;
	}
		
		
		@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public HashMap createFundRequest(Context context, String [] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Map paramMap = (Map) programMap.get("paramMap");
		String sObjectId=(String)paramMap.get("objectId");

		String sRowId = "" ;
		String strNewObject = "";

		HashMap columnsMap;
		HashMap changedRowMap;
		HashMap doc = new HashMap();
		HashMap retMap;
		DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
		DomainObject doBillItemObject = DomainObject.newInstance(context);

		Element elm = (Element) programMap.get("contextData");        
		MapList mlItems = new MapList();
		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		Map mapAttr = new HashMap();     

		for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
		{
			try
			{   
				retMap = new HashMap();
				changedRowMap = (HashMap) chgRowsMapList.get(i);
				columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");

				String strDesc = (String) columnsMap.get("Description");
				String strAmount = (String) columnsMap.get("Amount");
				String strRemarks = (String) columnsMap.get("Remarks");

				strNewObject = DomainObject.getAutoGeneratedName(context, "type_WMSFundRequest", DomainConstants.EMPTY_STRING);
				/*strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
						"type_WMSFundRequest",
						"",
						"policy_WMSFundRequest",
						context.getVault().getName(),
						"-"
						);*/
				
				DomainRelationship domRel   = doBillItemObject.createAndConnect(context,
						TYPE_WMS_FUND_REQUEST,
						strNewObject,
						"-",
					    POLICY_WMS_FUND_REQUEST,
						null,
						RELATIONSHIP_WMS_WO_FUND_REQUEST,
						domAmbObject,
						true);
						
				String strYear = DomainConstants.EMPTY_STRING;
				String strMonth = DomainConstants.EMPTY_STRING;		
				LocalDateTime now = LocalDateTime.now();
				int year = now.getYear();
				int month = now.getMonthValue();
				
				if(month>3){
					strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
				}else{
					strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
				}
				strMonth = String.valueOf(month);
				
				mapAttr = new HashMap();
				if (strAmount != null && !"".equals(strAmount)) {
					mapAttr.put(ATTRIBUTE_WMSTOTALAMOUNT, strAmount);
				}
				if (strRemarks != null && !"".equals(strRemarks)) {
					mapAttr.put("Remarks", strRemarks);
				}
				if (strDesc != null && !"".equals(strDesc)) {
					doBillItemObject.setDescription(context,strDesc);
				}
				if (strYear != null && !"".equals(strYear)) {
					mapAttr.put(ATTRIBUTE_WMS_FINANCIAL_YEAR, strYear);
				}
				if (strMonth != null && !"".equals(strMonth)) {
					mapAttr.put(ATTRIBUTE_WMS_MONTH, strMonth);
				}

				doBillItemObject.setAttributeValues(context,mapAttr);
				retMap = new HashMap();
				retMap.put("oid", doBillItemObject.getObjectId(context));
				retMap.put("relid", domRel.toString());
				retMap.put("pid", "");
				retMap.put("rid", "");
				retMap.put("markup", "new");
				retMap.put("rowId", sRowId);
				columnsMap.putAll(retMap);
				retMap.put("columns", columnsMap);
				mlItems.add(retMap);
				doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
				doc.put("Action", "success"); // Here the action can be "Success" or "refresh"
			}
			catch(Exception Ex)
			{
				Ex.printStackTrace();
				throw Ex;
			}
		}
		return doc;
	}
	
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public HashMap createFundRelease(Context context, String [] args) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Map paramMap = (Map) programMap.get("paramMap");
		String sObjectId=(String)paramMap.get("objectId");

		String sRowId = "" ;
		String strNewObject = "";

		HashMap columnsMap;
		HashMap changedRowMap;
		HashMap doc = new HashMap();
		HashMap retMap;
		DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
		DomainObject doBillItemObject = DomainObject.newInstance(context);

		Element elm = (Element) programMap.get("contextData");        
		MapList mlItems = new MapList();
		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		Map mapAttr = new HashMap();     

		for (int i = 0, size = chgRowsMapList.size(); i < size; i++) 
		{
			try
			{   
				retMap = new HashMap();
				changedRowMap = (HashMap) chgRowsMapList.get(i);
				columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");

				String strDesc = (String) columnsMap.get("Description");
				String strAmount = (String) columnsMap.get("Amount");
				String strRemarks = (String) columnsMap.get("Remarks");

				strNewObject = DomainObject.getAutoGeneratedName(context, "type_WMSFundRelease", DomainConstants.EMPTY_STRING);
				/*strNewObject = com.matrixone.apps.domain.util.FrameworkUtil.autoName(context,
						"type_WMSFundRelease",
						"",
						"policy_WMSFundRelease",
						context.getVault().getName(),
						"-"
						);*/
				
				DomainRelationship domRel   = doBillItemObject.createAndConnect(context,
						TYPE_WMS_FUND_RELEASE,
						strNewObject,
						"-",
					    POLICY_WMS_FUND_RELEASE,
						null,
						RELATIONSHIP_WMS_WO_FUND_RELEASE,
						domAmbObject,
						true);

				String strYear = DomainConstants.EMPTY_STRING;
				String strMonth = DomainConstants.EMPTY_STRING;		
				LocalDateTime now = LocalDateTime.now();
				int year = now.getYear();
				int month = now.getMonthValue();
				
				if(month>3){
					strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
				}else{
					strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
				}
				strMonth = String.valueOf(month);
				
				mapAttr = new HashMap();
				if (strAmount != null && !"".equals(strAmount)) {
					mapAttr.put(ATTRIBUTE_WMSTOTALAMOUNT, strAmount);
				}
				if (strRemarks != null && !"".equals(strRemarks)) {
					mapAttr.put("Remarks", strRemarks);
				}
				if (strDesc != null && !"".equals(strDesc)) {
					doBillItemObject.setDescription(context,strDesc);
				}
				if (strYear != null && !"".equals(strYear)) {
					mapAttr.put(ATTRIBUTE_WMS_FINANCIAL_YEAR, strYear);
				}
				if (strMonth != null && !"".equals(strMonth)) {
					mapAttr.put(ATTRIBUTE_WMS_MONTH, strMonth);
				}

				doBillItemObject.setAttributeValues(context,mapAttr);
				retMap = new HashMap();
				retMap.put("oid", doBillItemObject.getObjectId(context));
				retMap.put("relid", domRel.toString());
				retMap.put("pid", "");
				retMap.put("rid", "");
				retMap.put("markup", "new");
				retMap.put("rowId", sRowId);
				columnsMap.putAll(retMap);
				retMap.put("columns", columnsMap);
				mlItems.add(retMap);
				doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
				doc.put("Action", "success"); // Here the action can be "Success" or "refresh"
			}
			catch(Exception Ex)
			{
				Ex.printStackTrace();
				throw Ex;
			}
		}
		return doc;
	}
	
	
		public int createRouteOnPromote(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doBus = null;
			String strTemplateId ="";
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				doBus = new DomainObject(sObjectId);
				StringList slSelect = new StringList();
				slSelect.add(DomainObject.SELECT_TYPE);
				slSelect.add(DomainObject.SELECT_POLICY);
				slSelect.add(DomainObject.SELECT_OWNER);
				slSelect.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
				slSelect.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
				
				Map mBusInfo = (Map)doBus.getInfo(context,slSelect);
				String strWOID = DomainConstants.EMPTY_STRING;
				if(!mBusInfo.isEmpty() && mBusInfo != null){
					String strType = (String)mBusInfo.get(DomainObject.SELECT_TYPE);
					if(TYPE_WMS_FUND_REQUEST.equals(strType)){
						strWOID = (String)mBusInfo.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
					}else if(TYPE_WMS_FUND_RELEASE.equals(strType)){
						strWOID = (String)mBusInfo.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
					}
				}
				
				String strRelWhereExist ="attribute["+Route.ATTRIBUTE_ROUTE_STATUS+"]==\"Stopped\"";
				MapList mlExtRoutes = WMSUtil_mxJPO.checkForExistingRouteObject(context, doBus, strRelWhereExist);
				if(mlExtRoutes.size()>0) {
					Iterator iterator = mlExtRoutes.iterator();
					Route objRoute = (Route) DomainObject.newInstance(context, Route.TYPE_ROUTE);
					ContextUtil.pushContext(context);
					while (iterator.hasNext()) {
						Map<String, String> mRoute = (Map<String, String>) iterator.next();
						String sOIDRoute = (String) mRoute.get(DomainConstants.SELECT_ID);
						objRoute.setId(sOIDRoute);
						objRoute.resume(context);
					}
					ContextUtil.popContext(context);
				} else {
					
					String strPolicy = (String)mBusInfo.get(DomainConstants.SELECT_POLICY);
					String strProjectOwner = (String)mBusInfo.get(DomainObject.SELECT_OWNER);
					if(UIUtil.isNotNullAndNotEmpty(strWOID)){
						DomainObject doWO = new DomainObject(strWOID);
						String strRelWhere = "attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"] == \"Fund Approval\"";
						MapList routeMapList= doWO.getRelatedObjects(context, RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE, "Route Template", false, true, 0 , new StringList(DomainObject.SELECT_ID),null ,"", strRelWhere, 1, "", "", null);
						if(routeMapList != null && routeMapList.isEmpty() == false){
							Map mRouteTemplateMap = (Map)routeMapList.get(0);
							strTemplateId = (String)mRouteTemplateMap.get(DomainConstants.SELECT_ID);
							String sRouteDescription = (String)doBus.getInfo(context, DomainConstants.SELECT_TYPE) + " Review";
							String sState = (String)doBus.getInfo(context, DomainConstants.SELECT_CURRENT);
							String sApprovalTemplateId = strTemplateId;
							String strContectUser =  context.getUser();
							Map mRouteAttrib= new HashMap();
							mRouteAttrib.put("Route Completion Action", "Promote Connected Object");
							
							Map objectRouteAttributeMap=new HashMap(); 
							objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_POLICY,FrameworkUtil.getAliasForAdmin(context, "Policy", strPolicy,false ));
							objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_STATE,"state_Review");
							objectRouteAttributeMap.put(DomainConstants.ATTRIBUTE_ROUTE_BASE_PURPOSE,"Review");
							Map reviewerInfo= new HashMap();
							ContextUtil.pushContext(context);
							Route route = Route.createAndStartRouteFromTemplateAndReviewers(context,
											sApprovalTemplateId,
											sRouteDescription,
											strProjectOwner , 
											sObjectId,
											POLICY_WMSSOC,
											"AE", 
											mRouteAttrib,
											objectRouteAttributeMap, 
											reviewerInfo,
											true);
							route.promote(context);
							ContextUtil.popContext(context);
						}else{
							  String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Aleter.NoApprovalTemplateForFund");
							  emxContextUtil_mxJPO.mqlNotice(context,strMessage);
							  return 1;
						}
					}
				}
			}
			return 0;
		
		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}
	
	
	public StringList getCodeHeadProjects(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Map mTemp = null;
			String strId = DomainConstants.EMPTY_STRING;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Map)objectList.get(i);
				strId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strId)){
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.name dump");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						slReturnList.add(strResult);
					}else{
						slReturnList.add(DomainConstants.EMPTY_STRING);
					}
				}else{
					slReturnList.add(DomainConstants.EMPTY_STRING);
				}
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getWorkNames(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Map mTemp = null;
			String strId = DomainConstants.EMPTY_STRING;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Map)objectList.get(i);
				strId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strId)){
					ContextUtil.pushContext(context);
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMSPROJECTSOC+"].to.attribute[Title].value dump");
					ContextUtil.popContext(context);
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						slReturnList.add(strResult);
					}else{
						slReturnList.add(DomainConstants.EMPTY_STRING);
					}
				}else{
					slReturnList.add(DomainConstants.EMPTY_STRING);
				}
			}
			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getAdminApprovalAmount(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Map mTemp = null;
			String strId = DomainConstants.EMPTY_STRING;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Map)objectList.get(i);
				strId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strId)){
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strId+" select to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMSPROJECTSOC+"].to.from["+RELATIONSHIP_WMSSOCADMINAPPROVAL+"].to.attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAAList = FrameworkUtil.split(strResult,"|");
						double dSum = 0.0;
						for(int j=0;j<slAAList.size();j++){
							String strAmt = (String)slAAList.get(j);
							if(UIUtil.isNullOrEmpty(strAmt))
								strAmt = "0";
							dSum = dSum+Double.valueOf(strAmt);
						}
						slReturnList.add(String.valueOf(new BigDecimal(dSum).setScale(2, RoundingMode.FLOOR).toPlainString()));
					}else{
						slReturnList.add("0.0");
					}
				}else{
					slReturnList.add("0.0");
				}
			}
			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getExpenditureUptoPrevFY(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for(int i =0;i<objectList.size();i++){
				slReturnList.add("0");
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getAllotmentCFY(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for(int i =0;i<objectList.size();i++){
				slReturnList.add("0");
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getExpenditurePrevMonthCFY(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for(int i =0;i<objectList.size();i++){
				slReturnList.add("0");
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getTotalExpCurrentMonthCFY(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for(int i =0;i<objectList.size();i++){
				slReturnList.add("0");
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getTotalExpCFY(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for(int i =0;i<objectList.size();i++){
				slReturnList.add("0");
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getTotalExpIncPrevYearCurrentMonth(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for(int i =0;i<objectList.size();i++){
				slReturnList.add("0");
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getUnitName(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			for(int i =0;i<objectList.size();i++){
				slReturnList.add("0");
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getCodeHeadYear(Context context, String[] args) throws Exception {
		MapList mlBillItems = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");
            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList();
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_OWNER);
				slObjectSelects.add(DomainObject.SELECT_CURRENT);
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
                mlBillItems = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_CODE_HEAD_YEAR,
															TYPE_WMS_CODE_HEAD_YEAR,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
								
				String strCtxUser = (String)context.getUser();
				Map mTemp = null;					
				String strCurrent = DomainConstants.EMPTY_STRING;
				String strOwner = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlBillItems.size();i++){
					mTemp = (Map)mlBillItems.get(i);
					strCurrent = (String)mTemp.get(DomainObject.SELECT_CURRENT);
					strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
					if(strCtxUser.equals(strOwner) == false || strCurrent.equals("Inactive")){
						mTemp.put("RowEditable", "readonly");
						mTemp.put("disableSelection", "true");
					}
				}
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlBillItems;
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getCodeHeadYearAllocation(Context context, String[] args) throws Exception {
		MapList mlBillItems = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");

            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_DESCRIPTION);
				slObjectSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
				slObjectSelects.add("attribute[Remarks]");
				slObjectSelects.add(DomainObject.SELECT_OWNER);
				slObjectSelects.add(DomainObject.SELECT_CURRENT);
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
                mlBillItems = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION,
															TYPE_WMS_CODE_HEAD_YEAR_ALLOCATION,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
															
				String strCtxUser = (String)context.getUser();
				Map mTemp = null;					
				String strCurrent = DomainConstants.EMPTY_STRING;
				String strOwner = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlBillItems.size();i++){
					mTemp = (Map)mlBillItems.get(i);
					strCurrent = (String)mTemp.get(DomainObject.SELECT_CURRENT);
					strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
					if(strCtxUser.equals(strOwner) == false || strCurrent.equals("Frozen")){
						mTemp.put("RowEditable", "readonly");
						mTemp.put("disableSelection", "true");
					}
				}
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlBillItems;
	}
	
	
	public StringList getTotalAllocatedAmount(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Object mTemp = null;
			String strId = DomainConstants.EMPTY_STRING;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Object)objectList.get(i);
				if(mTemp instanceof HashMap){
					HashMap mMap = (HashMap)mTemp;
					strId = (String)mMap.get(DomainObject.SELECT_ID);
				}
				if(mTemp instanceof Hashtable){
					Hashtable mMap = (Hashtable)mTemp;
					strId = (String)mMap.get(DomainObject.SELECT_ID);
				}
				
				if(UIUtil.isNotNullAndNotEmpty(strId)){
					DomainObject doBus = new DomainObject(strId);
					String strType = (String)doBus.getInfo(context,DomainObject.SELECT_TYPE);
					StringList slAmounts = new StringList();
					if(TYPE_WMS_CODE_HEAD.equals(strType)){
						//String strResutl = MqlUtil.mqlCommand(context,"print bus "+strId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].to.from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"|to.current==Frozen].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						//slAmounts = FrameworkUtil.split(strResutl,"|");
						slReturnList.add(DomainConstants.EMPTY_STRING);
					}else if(TYPE_WMS_CODE_HEAD_YEAR.equals(strType)){
						String strResutl = MqlUtil.mqlCommand(context,"print bus "+strId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"|to.current==Frozen].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						slAmounts = FrameworkUtil.split(strResutl,"|");
						double dTotalAmount = 0.0;
						for(int j=0;j<slAmounts.size();j++){
							dTotalAmount = dTotalAmount + Double.valueOf((String)slAmounts.get(j));
						}
						slReturnList.add(WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAmount));
					}
					
					
				}else{
					slReturnList.add(DomainConstants.EMPTY_STRING);
				}
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getTotalConsumedAmount(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Object mTemp = null;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Object)objectList.get(i);
				String strId = DomainConstants.EMPTY_STRING;
				if(mTemp instanceof HashMap){
					HashMap mMap = (HashMap)mTemp;
					strId = (String)mMap.get(DomainObject.SELECT_ID);
				}
				if(mTemp instanceof Hashtable){
					Hashtable mMap = (Hashtable)mTemp;
					strId = (String)mMap.get(DomainObject.SELECT_ID);
				}
				
				
				if(UIUtil.isNotNullAndNotEmpty(strId)){
					DomainObject doBus = new DomainObject(strId);
					String strFinancialYear = (String)doBus.getAttributeValue(context,ATTRIBUTE_WMS_FINANCIAL_YEAR);
					String strType = (String)doBus.getInfo(context,DomainObject.SELECT_TYPE);
					if(UIUtil.isNotNullAndNotEmpty(strFinancialYear) && TYPE_WMS_CODE_HEAD_YEAR.equals(strType)){
						double dTotal = 0.0;
						String strResult = MqlUtil.mqlCommand(context,"print bus "+strId+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strFinancialYear+"'&& to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						if(UIUtil.isNotNullAndNotEmpty(strResult)){
							StringList slAmounts = FrameworkUtil.split(strResult,"|");
							for(int j=0;j<slAmounts.size();j++){
								dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
							}
						}
						
						strResult = MqlUtil.mqlCommand(context,"print bus "+strId+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strFinancialYear+"' && to.current==Approved)].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						if(UIUtil.isNotNullAndNotEmpty(strResult)){
							StringList slAmounts = FrameworkUtil.split(strResult,"|");
							for(int j=0;j<slAmounts.size();j++){
								dTotal = dTotal - Double.valueOf((String)slAmounts.get(j));
							}
						}
						slReturnList.add(WMSUtil_mxJPO.converToIndianCurrency(context,dTotal));
					}else{
						slReturnList.add(DomainConstants.EMPTY_STRING);
					}
					
				}else{
					slReturnList.add("0.00");
				}
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public String createCodeHeadYear(Context context, String [] args) throws Exception
	{
		String strReturn = "Success";
		try{
			
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId=(String)programMap.get("objectId");
			String strMode=(String)programMap.get("mode");
			String strYear = DomainConstants.EMPTY_STRING;
					
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			if(month>3){
                if (strMode.equals("CodeHeadYear")) {
                    strYear = String.valueOf(year)+"-"+String.valueOf(year+1);
                } else {
                    strYear = String.valueOf(year+1)+"-"+String.valueOf(year+2);
                }
			}else{
                if (strMode.equals("CodeHeadYear")) {
                    strYear = String.valueOf(year-1)+"-"+String.valueOf(year);
                } else {
                    strYear = String.valueOf(year)+"-"+String.valueOf(year+1);
                }
			}
			
			String strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value dump");
			
			if(UIUtil.isNullOrEmpty(strResult) || strResult.contains(strYear)==false){
				String sRowId = "" ;
				String strNewObject = "";

				HashMap columnsMap;
				HashMap changedRowMap;
				HashMap doc = new HashMap();
				DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
				StringList slPrevYearObjects = (StringList)domAmbObject.getInfoList(context,"from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].to.id");
				
				String strTitle = (String)domAmbObject.getInfo(context,"attribute[Title].value");
				DomainObject doBillItemObject = DomainObject.newInstance(context);

				Map mapAttr = new HashMap();     

				HashMap retMap = new HashMap();
				strNewObject = DomainObject.getAutoGeneratedName(context, "type_WMSCodeHeadYear", DomainConstants.EMPTY_STRING);
				
				DomainRelationship domRel   = doBillItemObject.createAndConnect(context,
						TYPE_WMS_CODE_HEAD_YEAR,
						strNewObject,
						"-",
						POLICY_WMS_CODE_HEAD_YEAR,
						null,
						RELATIONSHIP_WMS_CODE_HEAD_YEAR,
						domAmbObject,
						true);

				mapAttr = new HashMap();
				if (strTitle != null && !"".equals(strTitle)) {
					mapAttr.put("Title", strTitle);
				}
				if (strYear != null && !"".equals(strYear)) {
					mapAttr.put(ATTRIBUTE_WMS_FINANCIAL_YEAR, strYear);
				}
				doBillItemObject.setAttributeValues(context,mapAttr);
				
				ContextUtil.pushContext(context);
                if (strMode.equals("CodeHeadYear")) {
                    DomainObject doPrev = null;
                    for(int k=0;k<slPrevYearObjects.size();k++){
                        String strOID = (String)slPrevYearObjects.get(k);
                        doPrev = new DomainObject(strOID);
                        doPrev.setState(context, "Inactive");
                    }
                } else {
                    doBillItemObject.setState(context, "Inactive");
                }
				ContextUtil.popContext(context);
			}else{
				strReturn = "failed";
			}
			}
				catch(Exception Ex)
				{
					strReturn = "failed";
					Ex.printStackTrace();
					throw Ex;
				}
		return strReturn;
	}
	
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public String createCodeHeadYearAllocation(Context context, String [] args) throws Exception
	{
		String strReturn = "Success";
		try{
			
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId=(String)programMap.get("parentOID");
			String strMonth = DomainConstants.EMPTY_STRING;
			
			Calendar cal = Calendar.getInstance();
			strMonth = cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH);
						
			String strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"].to.attribute["+ATTRIBUTE_WMS_MONTH+"].value dump");
			
			String sRowId = "" ;
			String strNewObject = "";

			HashMap columnsMap;
			HashMap changedRowMap;
			HashMap doc = new HashMap();
			DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
			String strTitle = (String)domAmbObject.getInfo(context,"attribute[Title].value");
			DomainObject doBillItemObject = DomainObject.newInstance(context);

			Map mapAttr = new HashMap();     

			HashMap retMap = new HashMap();
			strNewObject = DomainObject.getAutoGeneratedName(context, "type_WMSCodeHeadYearAllocation", DomainConstants.EMPTY_STRING);
			
			DomainRelationship domRel   = doBillItemObject.createAndConnect(context,
					TYPE_WMS_CODE_HEAD_YEAR_ALLOCATION,
					strNewObject,
					"-",
					POLICY_WMS_CODE_HEAD_YEAR_ALLOCATION,
					null,
					RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION,
					domAmbObject,
					true);

			mapAttr = new HashMap();
			if (strTitle != null && !"".equals(strTitle)) {
				mapAttr.put("Title", strTitle);
			}
			if (strMonth != null && !"".equals(strMonth)) {
				mapAttr.put(ATTRIBUTE_WMS_MONTH, strMonth);
			}
			doBillItemObject.setAttributeValues(context,mapAttr);
			
		}
		catch(Exception Ex)
		{
			strReturn = "failed";
			Ex.printStackTrace();
			throw Ex;
		}
		return strReturn;
	}

@com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getBudgetPlanning(Context context, String[] args) throws Exception {
		MapList mlBillItems = new MapList();
        try
        {
            HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String sParentOID  = (String)programMap.get("objectId");

            if(null!=sParentOID && !"".equals(sParentOID) && !"null".equalsIgnoreCase(sParentOID))
            {
                StringList slObjectSelects = new StringList(1);
                slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_OWNER);
				slObjectSelects.add(DomainObject.SELECT_CURRENT);
				
                StringList relSelect = new StringList();
                relSelect.add(DomainRelationship.SELECT_ID);

                DomainObject domParentObj = DomainObject.newInstance(context, sParentOID);
                mlBillItems = domParentObj.getRelatedObjects(context,
															RELATIONSHIP_WMS_BUDGET_PLANNING,
															TYPE_WMS_BUDGET_PLANNING,
															slObjectSelects,
															relSelect,       // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
															
				String strCtxUser = (String)context.getUser();
				Map mTemp = null;					
				String strCurrent = DomainConstants.EMPTY_STRING;
				String strOwner = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mlBillItems.size();i++){
					mTemp = (Map)mlBillItems.get(i);
					strCurrent = (String)mTemp.get(DomainObject.SELECT_CURRENT);
					strOwner = (String)mTemp.get(DomainObject.SELECT_OWNER);
					if(strCtxUser.equals(strOwner) == false || "Frozen".equals(strCurrent)){
						mTemp.put("RowEditable", "readonly");
						mTemp.put("disableSelection", "true");
					}
				}
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
		return mlBillItems;
	}

	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public String createCurrentBudgetPlanning(Context context, String [] args) throws Exception
	{
		String strReturn = "Success";
		try{
			
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId=(String)programMap.get("objectId");
			String strYear = DomainConstants.EMPTY_STRING;			
					
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			
			String strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WMS_BUDGET_PLANNING+"].to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value dump");
			
			if(UIUtil.isNullOrEmpty(strResult) || strResult.contains(strYear)==false){
				String sRowId = "" ;
				String strNewObject = "";

				HashMap columnsMap;
				HashMap changedRowMap;
				HashMap doc = new HashMap();
				DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
				String strType = (String)domAmbObject.getInfo(context,DomainObject.SELECT_TYPE);
				DomainObject doBillItemObject = DomainObject.newInstance(context);

				Map mapAttr = new HashMap();     

				HashMap retMap = new HashMap();
				strNewObject = DomainObject.getAutoGeneratedName(context, "type_WMSBudgetPlanning", DomainConstants.EMPTY_STRING);
				
				DomainRelationship domRel   = doBillItemObject.createAndConnect(context,
						TYPE_WMS_BUDGET_PLANNING,
						strNewObject,
						"-",
						POLICY_WMS_BUDGET_PLANNING,
						null,
						RELATIONSHIP_WMS_BUDGET_PLANNING,
						domAmbObject,
						true);

				mapAttr = new HashMap();
				if (strYear != null && !"".equals(strYear)) {
					mapAttr.put(ATTRIBUTE_WMS_FINANCIAL_YEAR, strYear);
				}
				
				if(TYPE_WMS_WORK_ORDER.equals(strType)){
					mapAttr = updateMonthAmounts(context,sObjectId,strYear,mapAttr);
				}
				
				doBillItemObject.setAttributeValues(context,mapAttr);
			}else{
				strReturn = "failed";
			}
			}
			catch(Exception Ex)
			{
				strReturn = "failed";
				Ex.printStackTrace();
				throw Ex;
			}
			return strReturn;
	}
	
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
	public String createNewBudgetPlanning(Context context, String [] args) throws Exception
	{
		String strReturn = "Success";
		try{
			
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sObjectId=(String)programMap.get("objectId");
			String strYear = DomainConstants.EMPTY_STRING;			
					
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			if(month>3){
				strYear = String.valueOf(year+1)+"-"+String.valueOf(year+2);	
			}else{
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}
			
			String strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WMS_BUDGET_PLANNING+"].to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value dump");
			
			if(UIUtil.isNullOrEmpty(strResult) || strResult.contains(strYear)==false){
				String sRowId = "" ;
				String strNewObject = "";

				HashMap columnsMap;
				HashMap changedRowMap;
				HashMap doc = new HashMap();
				DomainObject domAmbObject =  DomainObject.newInstance(context,sObjectId);
				DomainObject doBillItemObject = DomainObject.newInstance(context);

				Map mapAttr = new HashMap();     

				HashMap retMap = new HashMap();
				strNewObject = DomainObject.getAutoGeneratedName(context, "type_WMSBudgetPlanning", DomainConstants.EMPTY_STRING);
				
				DomainRelationship domRel   = doBillItemObject.createAndConnect(context,
						TYPE_WMS_BUDGET_PLANNING,
						strNewObject,
						"-",
						POLICY_WMS_BUDGET_PLANNING,
						null,
						RELATIONSHIP_WMS_BUDGET_PLANNING,
						domAmbObject,
						true);

				mapAttr = new HashMap();
				if (strYear != null && !"".equals(strYear)) {
					mapAttr.put(ATTRIBUTE_WMS_FINANCIAL_YEAR, strYear);
				}
				doBillItemObject.setAttributeValues(context,mapAttr);
			}else{
				strReturn = "failed";
			}
			}
			catch(Exception Ex)
			{
				strReturn = "failed";
				Ex.printStackTrace();
				throw Ex;
			}
		return strReturn;
	}
	
	
	
	public StringList getCodeHeadAllocatatedAmount(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Object mTemp = null;
			String strId = DomainConstants.EMPTY_STRING;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Object)objectList.get(i);
				if(mTemp instanceof HashMap){
					HashMap mMap = (HashMap)mTemp;
					strId = (String)mMap.get(DomainObject.SELECT_ID);
				}
				if(mTemp instanceof Hashtable){
					Hashtable mMap = (Hashtable)mTemp;
					strId = (String)mMap.get(DomainObject.SELECT_ID);
				}
				if(UIUtil.isNotNullAndNotEmpty(strId)){
					DomainObject doBus = new DomainObject(strId);
					StringList slAmounts = (StringList)doBus.getInfoList(context,"from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].to.from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value");
					double dTotalAmount = 0.0;
					for(int j=0;j<slAmounts.size();j++){
						dTotalAmount = dTotalAmount + Double.valueOf((String)slAmounts.get(j));
					}
					slReturnList.add(new BigDecimal(dTotalAmount).setScale(2, RoundingMode.FLOOR).toPlainString());
				}else{
					slReturnList.add("0.0");
				}
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public void updateMonth(Context context, String[] args) throws Exception 
     {
         try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String sMeasurementOid = (String)paramMap.get("objectId");
             String sTitle = (String)paramMap.get("New Value");
             DomainObject doMeasurement = DomainObject.newInstance(context, sMeasurementOid);
			 ContextUtil.pushContext(context);
             doMeasurement.setAttributeValue(context, ATTRIBUTE_WMS_MONTH, sTitle);
			 ContextUtil.popContext(context);
         }
         catch (Exception e) {
             throw e;
         }
     }

	 
	 public void updateTitle(Context context, String[] args) throws Exception 
     {
         try {
			String strObjectId = (String)args[0];
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				DomainObject doBus = new DomainObject(strObjectId);
				String strName = (String)doBus.getInfo(context,DomainObject.SELECT_NAME);
				doBus.setAttributeValue(context, "Title", strName);
			}
         }
         catch (Exception e) {
             throw e;
         }
     }
	 
	 
	 public boolean hasAccessForCodeHeads(Context context, String[] args) throws Exception 
     {
		 boolean hasAccess = false;
         try {
			String strPersonId = PersonUtil.getPersonObjectID(context);
			if(UIUtil.isNotNullAndNotEmpty(strPersonId)){
				DomainObject doPerson = new DomainObject(strPersonId);
				String strHostPersonRole = doPerson.getAttributeValue(context,ATTRIBUTE_HOST_ROLE);
				String strCodeHeadRoles = EnoviaResourceBundle.getProperty(context, "WMS.CodeHeads.HostRole");
				StringList slCodeHeadRoles = FrameworkUtil.split(strCodeHeadRoles,",");
				if(UIUtil.isNotNullAndNotEmpty(strCodeHeadRoles) && UIUtil.isNotNullAndNotEmpty(strHostPersonRole) && slCodeHeadRoles.contains(strHostPersonRole))
					hasAccess = true;
			}
         }
         catch (Exception e) {
             throw e;
         }
		 return hasAccess;
     }
	 
	 
	 
	 public StringList getCodeHeadFinancialYear(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			Map mTemp = null;
			String strId = DomainConstants.EMPTY_STRING;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Map)objectList.get(i);
				strId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strId)){
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"|to.current==Active].to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value dump");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						slReturnList.add(strResult);
					}else{
						slReturnList.add(DomainConstants.EMPTY_STRING);
					}
				}else{
					slReturnList.add(DomainConstants.EMPTY_STRING);
				}
			}
			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	private Map updateMonthAmounts(Context context, String sObjectId,String strYear, Map mapAttr)throws Exception{
		try{
			String strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==1)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_JAN,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==2)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_FEB,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==3)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_MAR,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==4)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_APR,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==5)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_MAY,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==6)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_JUN,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==7)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_JUL,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==8)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_AUG,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==9)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_SEP,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==10)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_OCT,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==11)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_NOV,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			
			strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value==12)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
			if(UIUtil.isNotNullAndNotEmpty(strResult)){
				StringList slAmounts = FrameworkUtil.split(strResult,"|");
				double dTotal = 0.0;
				for(int j=0;j<slAmounts.size();j++){
					dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
				}
				mapAttr.put(ATTRIBUTE_WMS_DEC,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
			}
			return mapAttr;
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	@com.matrixone.apps.framework.ui.ColJPOCallable
    public static StringList isMonthEditable(Context context, String[] args)throws Exception {
		try {
			StringList isCellEditable = new StringList();
    		Map programMap 		= (Map) JPO.unpackArgs(args);
			Map mRequestMap = (Map)programMap.get("requestMap");
			String strObjectId = (String)mRequestMap.get("objectId");
			Map mColumnMap = (Map)programMap.get("columnMap");
			Map mSettingMap = (Map)mColumnMap.get("settings");
			String strMonthSequence = (String)mSettingMap.get("MonthSequence");
			String strYear = DomainConstants.EMPTY_STRING;
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			
			int iMonthSeq = Integer.valueOf(strMonthSequence);
			
			DomainObject doPlanning = DomainObject.newInstance(context);
			String strFinancialYear = DomainConstants.EMPTY_STRING;
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				DomainObject doBus = new DomainObject(strObjectId);
				String strType = (String)doBus.getInfo(context,DomainObject.SELECT_TYPE);
				MapList objectList 	= (MapList) programMap.get("objectList");
				for (int i = 0 ; i < objectList.size(); i++) {
					if(TYPE_WMS_WORK_ORDER.equals(strType)){
						Map mTemp  = (Map)objectList.get(i);
						String strId = (String)mTemp.get(DomainObject.SELECT_ID);
						doPlanning.setId(strId);
						strFinancialYear = (String)doPlanning.getAttributeValue(context,ATTRIBUTE_WMS_FINANCIAL_YEAR);
						if(UIUtil.isNotNullAndNotEmpty(strFinancialYear) && strYear.equals(strFinancialYear)){
							if (iMonthSeq >=4 && iMonthSeq <=12 && month >=4 && month <=12)
							{
								if (iMonthSeq < month)
									isCellEditable.add("false");
								else
									isCellEditable.add("true");
							}
							else if (iMonthSeq >=1 && iMonthSeq <=3 && month >=1 && month <=3)
							{
								if (iMonthSeq < month)
									isCellEditable.add("false");
								else
									isCellEditable.add("true");
							}
							else if (iMonthSeq >=4 && iMonthSeq <=12 && month >=1 && month <=3)
							{
								isCellEditable.add("false");
							}
							else if (iMonthSeq >=1 && iMonthSeq <=3 && month >=4 && month <=12)
							{
								isCellEditable.add("true");
							}
						}else{
							isCellEditable.add("true");
						}
					}else{
						isCellEditable.add("true");
					}
				}
				
			}
    		
			return isCellEditable;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}

	public int checkForFundAvailability(Context context,String[] args) throws Exception
		{
		try {	  
			String strBillId = (String)args[0];
			
			if(UIUtil.isNotNullAndNotEmpty(strBillId)){
				double dTotalAmount = 0.0;
				double dBillInvoicedAmount = 0.0;
				DomainObject doBill = new DomainObject(strBillId);
				String strBillFormGenerated = (String)doBill.getAttributeValue(context,ATTRIBUTE_WMS_BILL_FORM_GENERATED);
				if(UIUtil.isNotNullAndNotEmpty(strBillFormGenerated) && "No".equals(strBillFormGenerated)){
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Bill.BillFormNotGenerated");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;					
				}
				String strBillAmount = (String)doBill.getAttributeValue(context,ATTRIBUTE_WMS_INVOICED_AMOUNT);
				if(UIUtil.isNullOrEmpty(strBillAmount)){
					strBillAmount = "0";
				}
				dBillInvoicedAmount = Double.valueOf(strBillAmount);
				String strWOId = (String)doBill.getInfo(context,"to["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"].from.id");
				if(UIUtil.isNotNullAndNotEmpty(strWOId)){
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strWOId+" select from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAmount = dTotalAmount + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strWOId+" select from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAmount = dTotalAmount - Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strWOId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.current==Approved || to.current==Paid)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAmount = dTotalAmount - Double.valueOf((String)slAmounts.get(j));
						}
					}
				}
				
				if(dBillInvoicedAmount>dTotalAmount){
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Bill.NoFundAvailable");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
					
				}
			}		
						
		}catch(Exception e){
			e.printStackTrace();
		} 
		return 0;
	}	


@com.matrixone.apps.framework.ui.CellRangeJPOCallable
public Map getPlanningYear(Context context, String[] args) throws Exception{
try {
		Map newIssueRange = new HashMap();
		StringList slRange = new StringList();
		slRange.add("");
		
		String strDepartments = EnoviaResourceBundle.getProperty(context, "WMS.BudgetPlanning.Year");
		if(UIUtil.isNotNullAndNotEmpty(strDepartments)){
			StringList slList = FrameworkUtil.split(strDepartments,",");
			for(int i=0;i<slList.size();i++){
				slRange.add((String)slList.get(i));
			}
		}
		newIssueRange.put("field_choices", slRange);
		newIssueRange.put("field_display_choices", slRange);
		return newIssueRange;
	} catch (Exception ex) {
		ex.printStackTrace();
		throw ex;
	}
}


@com.matrixone.apps.framework.ui.CellRangeJPOCallable
public Map getTypeOfPlanning(Context context, String[] args) throws Exception{
try {
		Map programMap 		= (Map) JPO.unpackArgs(args);
		Map newIssueRange = new HashMap();
		StringList slRange = new StringList();
		slRange.add("");
		
		String strDepartments = EnoviaResourceBundle.getProperty(context, "WMS.BudgetPlanning.Types");
		if(UIUtil.isNotNullAndNotEmpty(strDepartments)){
			StringList slList = FrameworkUtil.split(strDepartments,",");
			for(int i=0;i<slList.size();i++){
				slRange.add((String)slList.get(i));
			}
		}
		
		
		newIssueRange.put("field_choices", slRange);
		newIssueRange.put("field_display_choices", slRange);
		return newIssueRange;
	} catch (Exception ex) {
		ex.printStackTrace();
		throw ex;
	}
}

	@com.matrixone.apps.framework.ui.CreateProcessCallable
	public Map<String,String> performCreateBudgetAddProcess(Context context, String[] args) throws Exception {
		Map<String,String> mapReturnMap = new HashMap();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strParentId = (String)programMap.get("objectId");
			if(UIUtil.isNotNullAndNotEmpty(strParentId)){
				DomainObject doParent = new DomainObject(strParentId);
				String strType = (String)doParent.getInfo(context,DomainObject.SELECT_TYPE);
				
				String strYear = DomainConstants.EMPTY_STRING;
				String strMonth = DomainConstants.EMPTY_STRING;		
				LocalDateTime now = LocalDateTime.now();
				int year = now.getYear();
				int month = now.getMonthValue();
				
				if(month>3){
					strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
				}else{
					strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
				}
			
				String strFinancialYear = (String) programMap.get("FinancialYear");
				String strTypeOfPlanning = (String) programMap.get("TypeOfPlanning");
				
				if(UIUtil.isNotNullAndNotEmpty(strFinancialYear) && "CFY".equals(strFinancialYear)){
					if(UIUtil.isNotNullAndNotEmpty(strTypeOfPlanning) && "Preliminary Revised Estimate,Revised Estimate,Modified Appropriation Report".contains(strTypeOfPlanning)==false){
						mapReturnMap.put("Action", "Stop");
						mapReturnMap.put("ErrorMessage", "Type of Report can be only Preliminary Revised Estimate/Revised Estimate/Modified Appropriation Report for CFY");
						return mapReturnMap;
					}
				}
				
				if(UIUtil.isNotNullAndNotEmpty(strFinancialYear) && "NFY".equals(strFinancialYear)){
					if(UIUtil.isNotNullAndNotEmpty(strTypeOfPlanning) && "Forecast Estimate,Budget Estimate".contains(strTypeOfPlanning)==false){
						mapReturnMap.put("Action", "Stop");
						mapReturnMap.put("ErrorMessage", "Type of Report can be only Forecast Estimate/Budget Estimate for CFY");
						return mapReturnMap;
					}					
				}
				
				Map<String,String> mAttrMap = new HashMap<String,String>();
				if (strFinancialYear != null && !"".equals(strFinancialYear)) {
					if("CFY".equals(strFinancialYear) == false){
						if(month>3){
							strYear = String.valueOf(year+1)+"-"+String.valueOf(year+2);	
						}else{
							strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
						}
					}
					
					mAttrMap.put(ATTRIBUTE_WMS_PLANNING_YEAR, strFinancialYear);
				}
				
				// check if there is already Budget object for same year and same type.
				StringList slObjectSelects = new StringList(1);
				slObjectSelects.add(DomainConstants.SELECT_ID);			
				slObjectSelects.add("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");			
				StringList relSelect = new StringList();
				relSelect.add(DomainRelationship.SELECT_ID);
				StringBuffer sbWhere = new StringBuffer();
				sbWhere.append("(attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"] == '"+strYear+"'");
				sbWhere.append("&&");
				sbWhere.append("attribute["+ATTRIBUTE_WMS_TYPE_OF_PLANNING+"] == '"+strTypeOfPlanning+"')");
				String strWhere = "attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"] == '"+strTypeOfPlanning+"'";					
				MapList mlBudgetPlans = doParent.getRelatedObjects(context,
																RELATIONSHIP_WMS_BUDGET_PLANNING,
																TYPE_WMS_BUDGET_PLANNING,
																slObjectSelects,
																relSelect,       // relationshipSelects
																false,      // getTo
																true,       // getFrom
																(short) 1,  // recurseToLevel
																sbWhere.toString(),// objectWhere
																null);
				if (mlBudgetPlans.size()>0)
				{
					mapReturnMap.put("Action", "Stop");
					mapReturnMap.put("ErrorMessage", "Type of Report for same Financial Year already Exists.");
					return mapReturnMap;
				}
				if (strTypeOfPlanning != null && !"".equals(strTypeOfPlanning)) {
					mAttrMap.put(ATTRIBUTE_WMS_TYPE_OF_PLANNING, strTypeOfPlanning);
				}
				if (strYear != null && !"".equals(strYear)) {
					mAttrMap.put(ATTRIBUTE_WMS_FINANCIAL_YEAR, strYear);
				}
				if(TYPE_WMS_WORK_ORDER.equals(strType)){
					mAttrMap = updateMonthAmounts(context,strParentId,strYear,mAttrMap);
				}
				DomainObject domBudget = DomainObject.newInstance(context);
				String strName = DomainObject.getAutoGeneratedName(context, "type_WMSBudgetPlanning", DomainConstants.EMPTY_STRING);
				domBudget.createObject(context, TYPE_WMS_BUDGET_PLANNING, strName, "", POLICY_WMS_BUDGET_PLANNING, "eService Production");
				domBudget.setAttributeValues(context, mAttrMap);
				DomainRelationship.connect(context, doParent, RELATIONSHIP_WMS_BUDGET_PLANNING, domBudget);
				mapReturnMap.put("id", domBudget.getObjectId(context));
			}
			
		} catch (Exception exception) {
			exception.printStackTrace();
			mapReturnMap.put("Action", "Stop");
			mapReturnMap.put("ErrorMessage", exception.getMessage());
		}
		return mapReturnMap;

	}
	
	public int checkForAllocationAmount(Context context, String[] args)throws Exception{
		try{
			String strRequestId = (String)args[0];
			if(UIUtil.isNotNullAndNotEmpty(strRequestId)){
				String strCodeHeadYear = MqlUtil.mqlCommand(context,"print bus "+strRequestId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"|to.current==Active].to.id dump");
				DomainObject doRequest = new DomainObject(strRequestId);
				String strRequestAmount = doRequest.getAttributeValue(context,ATTRIBUTE_WMSTOTALAMOUNT);
				String strFinancialYear = doRequest.getAttributeValue(context,ATTRIBUTE_WMS_FINANCIAL_YEAR);
				double dRequestAmount = Double.valueOf(strRequestAmount);
				double dTotalAllocatedAmount = 0.0;
				if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"|to.current==Frozen].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAllocatedAmount = dTotalAllocatedAmount + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strFinancialYear+"' && to.current==Approved)].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAllocatedAmount = dTotalAllocatedAmount - Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strFinancialYear+"' && to.current==Approved)].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAllocatedAmount = dTotalAllocatedAmount - Double.valueOf((String)slAmounts.get(j));
						}
					}					
				}
				if(dRequestAmount>dTotalAllocatedAmount){
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoEnoughFundAllocated");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage);
					return 1;
					
				}
			}			
		}catch(Exception ex){
			
			
		}
		return 0;
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getFundRequestDashboard(Context context, String[] args) throws Exception {
		MapList mlBillItems = new MapList();
        try
        {
            StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainObject.SELECT_ID);
			strListBusSelects.add(DomainObject.SELECT_NAME);
			strListBusSelects.add("attribute[Title].value");
			strListBusSelects.add(DomainObject.SELECT_DESCRIPTION);
			mlBillItems = DomainObject.findObjects(
					context,
					TYPE_WMS_FUND_REQUEST,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					"current==Review",               // where expression
					DomainConstants.EMPTY_STRING,
					true,
					strListBusSelects, // object selects
					(short) 0);
			return mlBillItems;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }	
	}
	
	public Vector getExistingAllotment(Context context, String[] args) throws Exception{
		Vector colVector = new Vector();
		try{
			String strYear = DomainConstants.EMPTY_STRING;
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			String strObjId = DomainConstants.EMPTY_STRING;
			String strResult = DomainConstants.EMPTY_STRING;
			
			Map mTemp = null;
			for(int i =0;i<objectList.size();i++){
				double dTotalAllocatedAmount = 0.0;
				double dTotalAllocatedAmountCFY = 0.0;
				mTemp = (Map)objectList.get(i);
				strObjId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strObjId)){
					strResult = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAllocatedAmount = dTotalAllocatedAmount + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|(to.current==Approved && to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"')].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAllocatedAmountCFY = dTotalAllocatedAmountCFY + Double.valueOf((String)slAmounts.get(j));
						}
					}
				}
				StringBuilder sb= new StringBuilder();
				sb.append(new BigDecimal(dTotalAllocatedAmount).setScale(2, RoundingMode.FLOOR).toPlainString());
				sb.append("<br/>");
				sb.append("CFY: "+new BigDecimal(dTotalAllocatedAmountCFY).setScale(2, RoundingMode.FLOOR).toPlainString());
				
				colVector.add(sb.toString());
			}

			return colVector;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public Vector getFundExpended(Context context, String[] args) throws Exception{
		Vector colVector = new Vector();
		try{
			String strYear = DomainConstants.EMPTY_STRING;
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			String strObjId = DomainConstants.EMPTY_STRING;
			String strResult = DomainConstants.EMPTY_STRING;
			Map mTemp = null;
			for(int i =0;i<objectList.size();i++){
				double dTotalExpendedAmount = 0.0;
				double dTotalExpendedAmountCFY = 0.0;
				mTemp = (Map)objectList.get(i);
				strObjId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strObjId)){
					strResult = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.current==Approved || to.current==Paid)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalExpendedAmount = dTotalExpendedAmount + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|((to.current==Approved || to.current==Paid) && to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"')].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalExpendedAmountCFY = dTotalExpendedAmountCFY + Double.valueOf((String)slAmounts.get(j));
						}
					}
				}
				StringBuilder sb= new StringBuilder();
				sb.append(new BigDecimal(dTotalExpendedAmount).setScale(2, RoundingMode.FLOOR).toPlainString());
				sb.append("<br/>");
				sb.append("CFY: "+new BigDecimal(dTotalExpendedAmountCFY).setScale(2, RoundingMode.FLOOR).toPlainString());
				
				colVector.add(sb.toString());
			}

			return colVector;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getFundBalance(Context context, String[] args) throws Exception{
		try{
			StringList slReturnList = new StringList();
			
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			String strObjId = DomainConstants.EMPTY_STRING;
			String strResult = DomainConstants.EMPTY_STRING;
			Map mTemp = null;
			for(int i =0;i<objectList.size();i++){
				double dTotalAllocatedAmount = 0.0;
				double dTotalPaid = 0.0;
				mTemp = (Map)objectList.get(i);
				strObjId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strObjId)){
					strResult = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAllocatedAmount = dTotalAllocatedAmount + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.current==Approved || to.current==Paid)].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalPaid = dTotalPaid + Double.valueOf((String)slAmounts.get(j));
						}
					}
				}
				slReturnList.add(new BigDecimal(dTotalAllocatedAmount-dTotalPaid).setScale(2, RoundingMode.FLOOR).toPlainString());
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		
	}
	
	public StringList getCodeHeadFromProject(Context context, String[] args) throws Exception{
		boolean isContextPushed = false;
		try{
			StringList slReturnList = new StringList();
			ContextUtil.pushContext(context);
			isContextPushed = true;
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			String strObjId = DomainConstants.EMPTY_STRING;
			String strResult = DomainConstants.EMPTY_STRING;
			Map mTemp = null;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Map)objectList.get(i);
				strObjId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strObjId)){
					strResult = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.name dump |");
					if(UIUtil.isNullOrEmpty(strResult))
						strResult = DomainConstants.EMPTY_STRING;
					slReturnList.add(strResult);
				}
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(isContextPushed)
				ContextUtil.popContext(context);
		}
		
	}
	
	public StringList getProjectName(Context context, String[] args) throws Exception{
		boolean isContextPushed = false;
		try{
			StringList slReturnList = new StringList();
			ContextUtil.pushContext(context);
			isContextPushed = true;
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			String strObjId = DomainConstants.EMPTY_STRING;
			String strResult = DomainConstants.EMPTY_STRING;
			Map mTemp = null;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Map)objectList.get(i);
				strObjId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strObjId)){
					strResult = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name dump |");
					if(UIUtil.isNullOrEmpty(strResult))
						strResult = DomainConstants.EMPTY_STRING;
					slReturnList.add(strResult);
				}
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(isContextPushed)
				ContextUtil.popContext(context);
		}
		
	}
	
	public StringList getWorkName(Context context, String[] args) throws Exception{
		boolean isContextPushed = false;
		try{
			StringList slReturnList = new StringList();
			ContextUtil.pushContext(context);
			isContextPushed = true;
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			String strObjId = DomainConstants.EMPTY_STRING;
			String strResult = DomainConstants.EMPTY_STRING;
			Map mTemp = null;
			for(int i =0;i<objectList.size();i++){
				mTemp = (Map)objectList.get(i);
				strObjId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strObjId)){
					strResult = MqlUtil.mqlCommand(context,"print bus "+strObjId+" select to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value dump |");
					if(UIUtil.isNullOrEmpty(strResult))
						strResult = DomainConstants.EMPTY_STRING;
					slReturnList.add(strResult);
				}
			}

			return slReturnList;
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}finally{
			if(isContextPushed)
				ContextUtil.popContext(context);
		}
		
	}
	
	public String checkPrepolulatedValue(Context context, String[] args)throws Exception{
		String strReturn = "0";
		try{			
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strObjectId = (String)programMap.get("objectId");
			String strMonth = (String)programMap.get("month");
			if(UIUtil.isNotNullAndNotEmpty(strObjectId)){
				StringList slSelect = new StringList();
				slSelect.add("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value");
				slSelect.add("attribute["+ATTRIBUTE_WMS_PLANNING_YEAR+"].value");
				slSelect.add("to["+RELATIONSHIP_WMS_BUDGET_PLANNING+"].from.id");
				DomainObject doPlanning = new DomainObject(strObjectId);
				Map mInfo = (Map)doPlanning.getInfo(context,slSelect);
				
				String strYear = DomainConstants.EMPTY_STRING;
				LocalDateTime now = LocalDateTime.now();
				int year = now.getYear();
				int month = now.getMonthValue();
				
				if(month>3){
					strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
				}else{
					strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
				}
				
				strMonth = getMonthSequence(strMonth);
				
				if(mInfo != null && mInfo.isEmpty()==false){
					String strPlanningYear = (String)mInfo.get("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value");
					String strPlanningType = (String)mInfo.get("attribute["+ATTRIBUTE_WMS_PLANNING_YEAR+"].value");
					
					if(strPlanningYear.equals(strYear) && "CFY".equals(strPlanningType)){
						String sObjectId = (String)mInfo.get("to["+RELATIONSHIP_WMS_BUDGET_PLANNING+"].from.id");
						String strResult = MqlUtil.mqlCommand(context,"print bus "+sObjectId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strPlanningYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=="+strMonth+")].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
						if(UIUtil.isNotNullAndNotEmpty(strResult)){
							StringList slAmounts = FrameworkUtil.split(strResult,"|");
							double dTotal = 0.0;
							for(int j=0;j<slAmounts.size();j++){
								dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
							}
							strReturn = new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString();
						}
					}
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return strReturn;
	}
	
	private String getMonthSequence(String month){
		if(UIUtil.isNotNullAndNotEmpty(month)){
			if("January".equals(month)){
				month = "1";
			}
			if("February".equals(month)){
				month = "2";
			}
			if("March".equals(month)){
				month = "3";
			}
			if("April".equals(month)){
				month = "4";
			}
			if("May".equals(month)){
				month = "5";
			}
			if("June".equals(month)){
				month = "6";
			}
			if("July".equals(month)){
				month = "7";
			}
			if("August".equals(month)){
				month = "8";
			}
			if("September".equals(month)){
				month = "9";
			}
			if("October".equals(month)){
				month = "10";
			}
			if("November".equals(month)){
				month = "11";
			}
			if("December".equals(month)){
				month = "12";
			}
		}
		return month;
		
	}
	
	public int checkReleaseAmount(Context context,String[] args) throws Exception
		{
		try {	  
			String strFundRelease = (String)args[0];
			
			if(UIUtil.isNotNullAndNotEmpty(strFundRelease)){
				DomainObject doRelease = new DomainObject(strFundRelease);
				String strFundReleaseAmount = (String)doRelease.getAttributeValue(context,ATTRIBUTE_WMSTOTALAMOUNT);
				if(UIUtil.isNullOrEmpty(strFundReleaseAmount)){
					strFundReleaseAmount = "0";
				}
				double dReleaseAmount = Double.valueOf(strFundReleaseAmount);
				
				String strWOId = (String)doRelease.getInfo(context,"to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
				
				double dFundRequest = 0.0;
				double dFundRelease = 0.0;
				double dBilledAmount = 0.0;
				if(UIUtil.isNotNullAndNotEmpty(strWOId)){
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strWOId+" select from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+" | to.current!='Create'].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dFundRequest = dFundRequest + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strWOId+" select from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+" | to.current=='Approved'].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dFundRelease = dFundRelease + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strWOId+" select from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+" | to.current!='Create'].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
					
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dBilledAmount = dBilledAmount + Double.valueOf((String)slAmounts.get(j));
						}
					}
				}
				double dFinalAmount = dFundRequest - dFundRelease - dBilledAmount;
				if(dReleaseAmount>dFinalAmount){
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Fund.Release.Limited");
					emxContextUtil_mxJPO.mqlNotice(context,strMessage+":"+WMSUtil_mxJPO.converToIndianCurrency(context,dFinalAmount));
					return 1;
					
				}
			}		
						
		}catch(Exception e){
			e.printStackTrace();
		} 
		return 0;
	}	
	

	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedApprovedAEMaster(Context context,String args[]) throws Exception {
		MapList mlReturnList = new MapList();
		try {
			
			String defaultOrg = PersonUtil.getDefaultOrganization(context, context.getUser());
			
			String strWorksOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Works");
			String strEqupmentsOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Equipments");
			
			String strWhere = DomainConstants.EMPTY_STRING;
			if(strWorksOrgName.equals(defaultOrg)){
				strWhere = "attribute[Title]==Works";
			}
			if(strEqupmentsOrgName.equals(defaultOrg)){
				strWhere = "attribute[Title]==Equipments";
			}
			
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
									
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add(DomainConstants.SELECT_TYPE);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			busSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
			busSelects.add("from["+RELATIONSHIP_WMSAEMASTER_APPROVAL_TEMPLATE+"].to.id");
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			String sObjState = DomainConstants.EMPTY_STRING;
			String sObjRTId = DomainConstants.EMPTY_STRING;
			String sObjType = DomainConstants.EMPTY_STRING;
			
			DomainObject domObject = new DomainObject(sObjectId);
			String strSOCId = (String)domObject.getInfo(context,"to["+RELATIONSHIP_WMS_BUDGET_PLANNING+"].from.from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			
			if(UIUtil.isNotNullAndNotEmpty(strSOCId)){
				DomainObject doSOC = DomainObject.newInstance(context,strSOCId);
				MapList mlAEMaster = doSOC.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_APPROVEDAEMASTER, // relationship pattern
													TYPE_WMSAEMASTER+","+TYPE_WMS_DEFAULT_MASTERS, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													strWhere, // object where clause
													null); // relationship where clause
				for (int i = 0, size = mlAEMaster.size(); i < size; i++) {
					Map objMap = (Map) mlAEMaster.get(i);
					objMap.put("disableSelection", "true");
					mlReturnList.add(objMap);
				}
			}else{
				StringList slAEPart1List = (StringList)domObject.getInfoList(context,"to["+RELATIONSHIP_WMS_BUDGET_PLANNING+"].from.from["+RELATIONSHIP_WMS_WORK_ORDER_TS+"].to.to["+RELATIONSHIP_WMSDCSTS+"].from.from["+RELATIONSHIP_WMSDCSMASTER_DCS+"].to.from["+RELATIONSHIP_WMSDCS_AE+"].to.id");
				DomainObject doAE = DomainObject.newInstance(context);
				String strAEId = DomainConstants.EMPTY_STRING;
				Map mTemp = null;
				for(int i=0;i<slAEPart1List.size();i++){
					strAEId = (String)slAEPart1List.get(i);
					doAE.setId(strAEId);
					mTemp = (Map)doAE.getInfo(context,busSelects);
					mlReturnList.add(mTemp);
				}
			}
			mlReturnList.sort("originated", "ascending", "date");
			return mlReturnList;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	* Method to get Related AE information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedAE(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
			String sCommandName=(String) programMap.get("portalCmdName");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			String sObjState = DomainConstants.EMPTY_STRING;
			String sObjRTId = DomainConstants.EMPTY_STRING;
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlAE =domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
													TYPE_WMSAE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			for (int i = 0, size = mlAE.size(); i < size; i++) {
				Map objMap = (Map) mlAE.get(i);
				sObjOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
				sObjState = (String) objMap.get(DomainConstants.SELECT_CURRENT);
				if(!sContextUser.equals(sObjOwner) || !STATE_WMSAE_CREATE.equals(sObjState)) {
					objMap.put("RowEditable", "readonly");
				}
			}
			mlAE.sort("originated", "ascending", "date");
			return mlAE;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getBudgetPlanningForAE(Context context,String args[]) throws Exception {
		MapList mlReturnList = new MapList();
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add(DomainConstants.SELECT_TYPE);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			StringList relSelect = new StringList();
			relSelect.add(DomainRelationship.SELECT_ID);
			relSelect.add("attribute["+ATTRIBUTE_WMS_JAN+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_FEB+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_MAR+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_APR+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_MAY+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_JUN+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_JUL+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_AUG+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_SEP+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_OCT+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_NOV+"].value");
			relSelect.add("attribute["+ATTRIBUTE_WMS_DEC+"].value");
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			String sObjState = DomainConstants.EMPTY_STRING;
			String sObjRTId = DomainConstants.EMPTY_STRING;
			String sObjType = DomainConstants.EMPTY_STRING;
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlAEMaster = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMS_BP_AE, // relationship pattern
													TYPE_WMSAE, // type pattern
													busSelects, // object selects
													relSelect, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			return mlAEMaster;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@com.matrixone.apps.framework.ui.PostProcessCallable
    public Map updateBPAmounts(Context context, String[] args) throws Exception {
        HashMap mapReturnMap = new HashMap();
        try {
			DecimalFormat df = new DecimalFormat("0.00");
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sObjectId=(String) paramMap.get("objectId");			
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				DomainObject doBP = DomainObject.newInstance(context,sObjectId);
				Map mItemInfoMap = null;
							
				Map mArgs = new HashMap();
				mArgs.put("objectId",sObjectId);
				MapList mlObjectList = (MapList) getBudgetPlanningForAE(context,JPO.packArgs(mArgs));
				
				StringList slMonths = new StringList();
				slMonths.add("WMSJan");
				slMonths.add("WMSFeb");
				slMonths.add("WMSMar");
				slMonths.add("WMSApr");
				slMonths.add("WMSMay");
				slMonths.add("WMSJun");
				slMonths.add("WMSJul");
				slMonths.add("WMSAug");
				slMonths.add("WMSSep");
				slMonths.add("WMSOct");
				slMonths.add("WMSNov");
				slMonths.add("WMSDec");
				Map mAttrMap = new HashMap();
				
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				double dAmount = 0.0;
				Map mTemp = null;
				for(int i=0;i<slMonths.size();i++){
					dAmount = 0.0;
					strMonth = (String)slMonths.get(i);
					
					for(int j=0;j<mlObjectList.size();j++){
						mTemp = (Map)mlObjectList.get(j);
						strAmount = (String)mTemp.get("attribute["+strMonth+"].value");
						if(UIUtil.isNullOrEmpty(strAmount))
							strAmount = "0";
						dAmount = dAmount + Double.valueOf(strAmount);
					}
					mAttrMap.put(strMonth,df.format(dAmount));
				}
				
				ContextUtil.pushContext(context);
				doBP.setAttributeValues(context,mAttrMap);
				ContextUtil.popContext(context);
			}
			
            mapReturnMap.put("Action","success");
        } catch (Exception exception) {
         exception.printStackTrace();
            mapReturnMap.put("Action","Stop");
            mapReturnMap.put("Message",exception.getMessage());
        }
        return mapReturnMap;
    }
		
	public int updateBPAmountsOnRemove(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				DecimalFormat df = new DecimalFormat("0.00");
				DomainObject doBP = DomainObject.newInstance(context,sObjectId);
				Map mItemInfoMap = null;
							
				Map mArgs = new HashMap();
				mArgs.put("objectId",sObjectId);
				MapList mlObjectList = (MapList) getBudgetPlanningForAE(context,JPO.packArgs(mArgs));
				
				StringList slMonths = new StringList();
				slMonths.add("WMSJan");
				slMonths.add("WMSFeb");
				slMonths.add("WMSMar");
				slMonths.add("WMSApr");
				slMonths.add("WMSMay");
				slMonths.add("WMSJun");
				slMonths.add("WMSJul");
				slMonths.add("WMSAug");
				slMonths.add("WMSSep");
				slMonths.add("WMSOct");
				slMonths.add("WMSNov");
				slMonths.add("WMSDec");
				Map mAttrMap = new HashMap();
				
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				double dAmount = 0.0;
				Map mTemp = null;
				for(int i=0;i<slMonths.size();i++){
					dAmount = 0.0;
					strMonth = (String)slMonths.get(i);
					
					for(int j=0;j<mlObjectList.size();j++){
						mTemp = (Map)mlObjectList.get(j);
						strAmount = (String)mTemp.get("attribute["+strMonth+"].value");
						if(UIUtil.isNullOrEmpty(strAmount))
							strAmount = "0";
						dAmount = dAmount + Double.valueOf(strAmount);
					}
					mAttrMap.put(strMonth,df.format(dAmount));
				}
				
				ContextUtil.pushContext(context);
				doBP.setAttributeValues(context,mAttrMap);
				ContextUtil.popContext(context);				
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
		return 0;
	}
	
	
	public void updateFundRequestValue(Context context, String[] args)throws Exception{
		 try {
             HashMap programMap = (HashMap)JPO.unpackArgs(args);
             HashMap paramMap = (HashMap)programMap.get("paramMap");
             String strFundRequestId = (String)paramMap.get("objectId");
             String strNewAmount = (String)paramMap.get("New Value");
             DomainObject doFR = DomainObject.newInstance(context, strFundRequestId);
			 String strHistoryValue = (String)doFR.getAttributeValue(context,ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY);
			 String strUser = context.getUser();
			 
			 StringList slHistoryEntries = FrameworkUtil.split(strHistoryValue,"\n");
			 int iHistorySize = slHistoryEntries.size();
			 String strLastHistoryEntry = (String)slHistoryEntries.get(iHistorySize-1);
			 String strHistoryOld = DomainConstants.EMPTY_STRING;
			 
			 String strFullName = MqlUtil.mqlCommand(context,"print person '"+strUser+"' select fullname dump");
			 
			 Calendar calendarDate = Calendar.getInstance();
			 String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
			 SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
			 String strTime = formatter.format(calendarDate.getTime());
			 
			 String strHistoryNew = strFullName+"|"+strTime+"|"+strNewAmount;
			 
			 if(strLastHistoryEntry.startsWith(strFullName)){
				slHistoryEntries.remove(strLastHistoryEntry);
				slHistoryEntries.add(iHistorySize-1,strHistoryNew);
				for(int k=0;k<slHistoryEntries.size();k++){
					if(k==0){
						strHistoryOld = (String)slHistoryEntries.get(k);
					}else{
						strHistoryOld = strHistoryOld +"\n"+(String)slHistoryEntries.get(k);
					}
				}
			}else{
				if(strHistoryValue.endsWith(strHistoryNew)==false){
					strHistoryOld = strHistoryValue + "\n"+ strHistoryNew;
				}else{
					strHistoryOld = strHistoryValue;
				}
			}
			 HashMap mAttrMap = new HashMap();
			 mAttrMap.put(ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY,strHistoryOld);
			 mAttrMap.put(ATTRIBUTE_WMSTOTALAMOUNT,strNewAmount);
			 ContextUtil.pushContext(context);
             doFR.setAttributeValues(context, mAttrMap);
			 ContextUtil.popContext(context);
         }
			catch (Exception e) {
             throw e;
         }
	}
	
	public String getFundRequestHistory(Context context,String[] args) throws Exception{
		StringBuilder sb=new StringBuilder();
		 try { 
			Map mInputMap = (Map) JPO.unpackArgs(args);
		   Map requestMap = (Map) mInputMap.get("requestMap");
		   String strObjectId = (String) requestMap.get("objectId");
		   String downloadURL = "../wms/wmsFundRequestAmountHistory.jsp?objectId="+strObjectId; 
		   String strDownLoadTip="History";
		 
			 sb.append("<a href=\"" + downloadURL + "\"  target=\"popup\"   >");
			 sb.append("<img border=\"0\" src=\"../common/images/iconNewWindow.gif\" alt=\""
			+ strDownLoadTip + "\" title=\"" + strDownLoadTip + "\"></img></a>&#160;");
		
		 }catch(Exception e) {
			 e.printStackTrace();
		 } 
		return  sb.toString();
	 }
	 
	 public int updateHistoryOnPromote(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			if(UIUtil.isNotNullAndNotEmpty(sObjectId)){
				DomainObject doBus = DomainObject.newInstance(context,sObjectId);
				String strUser = context.getUser();
				String strFullName = MqlUtil.mqlCommand(context,"print person '"+strUser+"' select fullname dump");
				Calendar calendarDate = Calendar.getInstance();
				String strHistoryDateFormat = EnoviaResourceBundle.getProperty(context,"WMS.History.DateFormat");
				SimpleDateFormat formatter = new SimpleDateFormat(strHistoryDateFormat);  
				String strTime = formatter.format(calendarDate.getTime());
				String strAmount = (String)doBus.getAttributeValue(context,ATTRIBUTE_WMSTOTALAMOUNT);
				String strHistory = strFullName +"|"+strTime+"|"+strAmount;
				doBus.setAttributeValue(context, ATTRIBUTE_WMS_MEASUREMENT_APPROVAL_HISTORY,strHistory);
			}
			return 0;
		
		}
		catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}
}
			

		