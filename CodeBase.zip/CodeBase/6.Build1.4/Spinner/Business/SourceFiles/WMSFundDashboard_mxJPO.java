/*---------------------------------------------------------------------------------------------------------------
NAME        : WMSFundDashboard_mxJPO.java

DESCRIPTION    : Purpose of JPO is to Create Admin Approvals  and perform the utility operations on it

CREATED        : August 13 2019

AUTHOR        : Divyashree B K

HISTORY        :

    Divyashree B K    13-08-2019        Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;
import java.math.BigDecimal;
import java.util.Locale;
import java.math.RoundingMode;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.ProjectConcept;
import com.matrixone.apps.program.ProjectSpace;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import matrix.db.Policy;
import com.matrixone.jdom.Element;
import matrix.util.Pattern;

public class WMSFundDashboard_mxJPO extends WMSConstants_mxJPO {
    
    public static final String ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTotalAllotmentAmount");
    public static final String ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSCYAllotmentAmount");
    public static final String ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSTotalExpendedAmount");
    public static final String ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSCYExpendedAmount");
    public static final String ATTRIBUTE_WMS_FUND_BALANCE_AMOUNT = PropertyUtil.getSchemaProperty("attribute_WMSFundBalanceAmount");
    public static final String ATTRIBUTE_WMS_CODE_HEAD_NAME = PropertyUtil.getSchemaProperty("attribute_WMSCodeHeadName");

    
    /**
    * Constructor.
    *
    * @param context the eMatrix <code>Context</code> object.
    * @param args holds no arguments.
    * @throws Exception if the operation fails.
    * @since EC 9.5.JCI.0.
    **/
    public WMSFundDashboard_mxJPO (Context context, String[] args) throws Exception {
      super(context, args);
    }
        
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getFundRequestDashboard(Context context, String[] args) throws Exception {
        MapList mlFinalList = new MapList();
        try
        {
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainObject.SELECT_ID);
            strListBusSelects.add(DomainObject.SELECT_NAME);
            strListBusSelects.add(DomainObject.SELECT_TYPE);
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            MapList mlFundItems = DomainObject.findObjects(context,
                                                            TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            "current==Review",               // where expression
                                                            DomainConstants.EMPTY_STRING,
                                                            true,
                                                            strListBusSelects, // object selects
                                                            (short) 0);
                    
            Map mTemp = null;
            Map mFinalMap = null;
            String strType = "";
            StringList slWorkOrderList = new StringList();
            String strWOID = "";
            for(int i = 0; i < mlFundItems.size(); i++){
                mTemp = (Map)mlFundItems.get(i);
                strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                if (!slWorkOrderList.contains(strWOID)) {
                    slWorkOrderList.add(strWOID);
                }
            }
            int iWOListSize = slWorkOrderList.size();
            String[] saWOArray = new String[iWOListSize];
            StringList slWOSelectable = new StringList();
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slWOSelectable.add(DomainConstants.SELECT_ID);
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            //make the array for WO objects
            for(int j = 0; j < iWOListSize; j++){
                saWOArray[j] = (String)slWorkOrderList.get(j);
            }
            MapList mlWOInfo = DomainObject.getInfo(context, saWOArray, slWOSelectable);
            //Get other fields for the WO
            Map mWOTemp = null;
            Map mCurrentWorkOrderDetails = new HashMap();
            Map mWorkOrderDetails = new HashMap();
            for(int k = 0; k < mlWOInfo.size(); k++){
                mCurrentWorkOrderDetails = new HashMap();
                mWOTemp = (Map)mlWOInfo.get(k);
                strWOID = (String)mWOTemp.get(DomainConstants.SELECT_ID);
                Map mFinancialDetails = getWOFinancials(context, strWOID);
                mCurrentWorkOrderDetails.putAll(mFinancialDetails);
                mCurrentWorkOrderDetails.put("CodeHead", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]"));
                mCurrentWorkOrderDetails.put("ProjectName", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name"));
                mCurrentWorkOrderDetails.put("WorkName", (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]"));
                mWorkOrderDetails.put(strWOID, mCurrentWorkOrderDetails);
            }
            //Prepare Final Map to be returned to the Table
            Map mFundMap = null;
            Map mTableRowMap = new HashMap();
            for(int l = 0; l < mlFundItems.size(); l++){
                mFundMap = (Map)mlFundItems.get(l);
                strType = (String)mFundMap.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                Map mWOTableDeatils = (Map)mWorkOrderDetails.get(strWOID);
                mFundMap.putAll(mWOTableDeatils);
                mlFinalList.add(mFundMap);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        return mlFinalList;
    }
    
    public Map getWOFinancials(Context context, String strWOID) throws Exception 
    {
        Map mFinalMap = new HashMap();
        try{
            String strYear = DomainConstants.EMPTY_STRING;
            LocalDateTime now = LocalDateTime.now();
            int year = now.getYear();
            int month = now.getMonthValue();
            
            if(month>3){
                strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
            }else{
                strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
            }
            
            MapList mlWOData = getWorkOrderData(context, strWOID);
            
            BigDecimal bgZero = new BigDecimal(0);
            Map mTemp = null;
            Map mAMBDetails = new HashMap();
            mAMBDetails.put("CYExpendedAmount", bgZero);
            mAMBDetails.put("TotalExpendedAmount", bgZero);
            Map mFundReqDetails = new HashMap();
            mFundReqDetails.put("CYAllotmentAmount", bgZero);
            mFundReqDetails.put("TotalAllotmentAmount", bgZero);
            Map mFundRelDetails = new HashMap();
            mFundRelDetails.put("CYAllotmentAmount", bgZero);
            mFundRelDetails.put("TotalAllotmentAmount", bgZero);
            String strType = "";
            String strFY = "";

            
            for(int i = 0; i < mlWOData.size(); i++){
                mTemp = (Map)mlWOData.get(i);
                strType = (String)mTemp.get(DomainConstants.SELECT_TYPE);
                //if type is AMB then do the calculation for Fund Expended overall and CY
                if (strType.equals(TYPE_ABSTRACT_MBE)) {
                    mAMBDetails = getAMBFundDetails(mTemp, strYear, mAMBDetails);
                } else if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    //get the Allottment details for Current Year and total
                    mFundReqDetails = getFundRequestDetails(mTemp, strYear, mFundReqDetails);
                } else {
                    //get Release Details for Current Year and total
                    mFundRelDetails = getFundRequestDetails(mTemp, strYear, mFundRelDetails);
                }
            }
            mFinalMap.putAll(mAMBDetails);
            BigDecimal bgCYRequestAmount = (BigDecimal)mFundReqDetails.get("CYAllotmentAmount");
            BigDecimal bgTotalRequestAmount = (BigDecimal)mFundReqDetails.get("TotalAllotmentAmount");
            BigDecimal bgCYReleaseAmount = (BigDecimal)mFundRelDetails.get("CYAllotmentAmount");
            BigDecimal bgTotalReleaseAmount = (BigDecimal)mFundRelDetails.get("TotalAllotmentAmount");
            BigDecimal bgTotalAllotmentAmount = bgTotalRequestAmount.subtract(bgTotalReleaseAmount);
            BigDecimal bgCYAllotmentAmount = bgCYRequestAmount.subtract(bgCYReleaseAmount);
            mFinalMap.put("TotalAllotment", bgTotalAllotmentAmount);
            mFinalMap.put("CYAllotment", bgCYAllotmentAmount);
        }catch(Exception ex){
            System.out.println("error in getSubAllocationForCHY method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return mFinalMap;
    }
    
    public Map getFundRequestDetails(Map mAMBMap, String strYear, Map mFundReqDetails) throws Exception{
        Map mFinalMap = new HashMap();
        try{
            BigDecimal bgZero = new BigDecimal(0);
            //Get the Certified Amount from the Map
            String strAmount = (String)mAMBMap.get("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
            BigDecimal bgFundAmount = new BigDecimal(strAmount);
            //If FY matches the passed FY then get the same
            String strFundFY = (String)mAMBMap.get("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
            
            //Check if the Details map already has the keys, if yes, add else add keys and values.
            if (mFundReqDetails.containsKey("CYAllotmentAmount")) {
                BigDecimal bgCYTemp = (BigDecimal)mFundReqDetails.get("CYAllotmentAmount");
                if (strFundFY.equals(strYear)) {
                    bgCYTemp = bgCYTemp.add(bgFundAmount);
                }
                mFinalMap.put("CYAllotmentAmount", bgCYTemp);
                BigDecimal bgTotalTemp = (BigDecimal)mFundReqDetails.get("TotalAllotmentAmount");
                bgTotalTemp = bgTotalTemp.add(bgFundAmount);
                mFinalMap.put("TotalAllotmentAmount", bgTotalTemp);
            }
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        return mFinalMap;
    }
    
    public Map getAMBFundDetails(Map mAMBMap, String strYear, Map mAMBDetails) throws Exception{
        Map mFinalMap = new HashMap();
        try{
            BigDecimal bgZero = new BigDecimal(0);
            //Get the Certified Amount from the Map
            String strCertifiedAmount = (String)mAMBMap.get("attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"]");
            BigDecimal bgAMBCertAmount = new BigDecimal(strCertifiedAmount);
            //If FY matches the passed FY then get the same
            String strAMBFY = (String)mAMBMap.get("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
            
            //Check if the Details map already has the keys, if yes, add else add keys and values.
            if (mAMBDetails.containsKey("CYExpendedAmount")) {
                BigDecimal bgCYTemp = (BigDecimal)mAMBDetails.get("CYExpendedAmount");
                if (strAMBFY.equals(strYear)) {
                    bgCYTemp = bgCYTemp.add(bgAMBCertAmount);
                }
                mFinalMap.put("CYExpendedAmount", bgCYTemp);
                BigDecimal bgTotalTemp = (BigDecimal)mAMBDetails.get("TotalExpendedAmount");
                bgTotalTemp = bgTotalTemp.add(bgAMBCertAmount);
                mFinalMap.put("TotalExpendedAmount", bgTotalTemp);
            }
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        return mFinalMap;
    }
    
    public MapList getWorkOrderData(Context context, String strWOID) throws Exception 
    {
        MapList mlWOData = new MapList();
        try{
            DomainObject doWOObj = DomainObject.newInstance(context, strWOID);
            StringList slObjectSelects = new StringList();
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
            slObjectSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
            slObjectSelects.add("attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"]");
            slObjectSelects.add(DomainConstants.SELECT_CURRENT);
            slObjectSelects.add(DomainConstants.SELECT_TYPE);
            
            
            mlWOData = doWOObj.getRelatedObjects(context,
                                                RELATIONSHIP_WMS_WO_FUND_REQUEST+","+RELATIONSHIP_WMS_WO_FUND_RELEASE+","+RELATIONSHIP_WORKORDER_ABSTRACT_MBE,
                                                TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE+","+TYPE_ABSTRACT_MBE,
                                                slObjectSelects,
                                                null,       // relationshipSelects
                                                false,      // getTo
                                                true,       // getFrom
                                                (short) 1,  // recurseToLevel
                                                "(current==Approved || current==Paid)",// objectWhere
                                                null);
            mlWOData.sortStructure(DomainConstants.SELECT_TYPE, "descending", "string");
        } catch(Exception ex){
            System.out.println("error in getWorkOrderData method of JPO WMSFundStatusReport.");
            ex.printStackTrace();
            throw ex;
        }
        return mlWOData;
    }
    
    
    
    
    public Vector getExistingAllotment(Context context, String[] args) throws Exception{
        Vector colVector = new Vector();
        try{
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            
            Map mTemp = null;
            BigDecimal bgTotalAllotment = new BigDecimal(0);
            BigDecimal bgCYAllotment = new BigDecimal(0);
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
                bgTotalAllotment = (BigDecimal)mTemp.get("TotalAllotment");
                bgCYAllotment = (BigDecimal)mTemp.get("CYAllotment");
                Double dblTotalValue = Double.parseDouble(bgTotalAllotment.toString());
                String strTotalAmount = String.format("%.2f", dblTotalValue);
                Double dblCYValue = Double.parseDouble(bgCYAllotment.toString());
                String strCYAmount = String.format("%.2f", dblCYValue);
                StringBuilder sb= new StringBuilder();
                sb.append(strTotalAmount);
                sb.append("<br/>");
                sb.append("CFY: "+strCYAmount);
                colVector.add(sb.toString());
            }
            return colVector;
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
    }
    
    
    
    public Vector getFundExpended(Context context, String[] args) throws Exception{
        Vector colVector = new Vector();
        try{
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            
            Map mTemp = null;
            BigDecimal bgTotalExpended = new BigDecimal(0);
            BigDecimal bgCYExpended = new BigDecimal(0);
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
                bgTotalExpended = (BigDecimal)mTemp.get("TotalExpendedAmount");
                bgCYExpended = (BigDecimal)mTemp.get("CYExpendedAmount");
                Double dblTotalValue = Double.parseDouble(bgTotalExpended.toString());
                String strTotalAmount = String.format("%.2f", dblTotalValue);
                Double dblCYValue = Double.parseDouble(bgCYExpended.toString());
                String strCYAmount = String.format("%.2f", dblCYValue);
                StringBuilder sb= new StringBuilder();
                sb.append(strTotalAmount);
                sb.append("<br/>");
                sb.append("CFY: "+strCYAmount);
                colVector.add(sb.toString());
            }

            return colVector;
            
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        
    }
    
    
    public StringList getFundBalance(Context context, String[] args) throws Exception{
        try{
            StringList slReturnList = new StringList();
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            BigDecimal bgTotalExpended = new BigDecimal(0);
            BigDecimal bgTotalAllotment = new BigDecimal(0);
            BigDecimal bgFundBalance = new BigDecimal(0);
            Map mTemp = null;
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
                bgTotalExpended = (BigDecimal)mTemp.get("TotalExpendedAmount");
                bgTotalAllotment = (BigDecimal)mTemp.get("TotalAllotment");
                bgFundBalance = bgTotalAllotment.subtract(bgTotalExpended);
                Double dblTotalValue = Double.parseDouble(bgFundBalance.toString());
                String strTotalAmount = String.format("%.2f", dblTotalValue);
                slReturnList.add(strTotalAmount);
            }

            return slReturnList;
            
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        
    }
    
    public StringList getColumnValue(Context context, String[] args) throws Exception{
        try{
            StringList slReturnList = new StringList();
            
            Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Map mColumnMap = (Map)programMap.get("columnMap");
            Map mSettingMap = (Map)mColumnMap.get("settings");
            String strKey = (String)mSettingMap.get("mapKey");
            Map mTemp = null;
            String strKeyValue = "";
            for(int i =0;i<objectList.size();i++){
                mTemp = (Map)objectList.get(i);
				if (mTemp.containsKey(strKey))
				{
					strKeyValue = (String)mTemp.get(strKey);
					slReturnList.add(strKeyValue);
				}
				else
				{
					if("numeric".equals((String)mSettingMap.get("format")))
					{
						slReturnList.add("0.0");
					}
					else
					{
						slReturnList.add("");
					}
				}
            }
            return slReturnList;
            
        }catch(Exception ex){
            ex.printStackTrace();
            throw ex;
        }
        
    }
    
   
    public StringList getFundRequiredStyle(Context context, String[] args) throws Exception {
        StringList slResults    = new StringList();
        Map programMap          = (Map) JPO.unpackArgs(args);
        MapList objectList             = (MapList) programMap.get("objectList");
        int iobjectListSize            = objectList.size();
        String strType = "";
        Map objectMap = null;
        for (int i=0; i < iobjectListSize; i++)
        {
            objectMap=(Map)objectList.get(i);
            strType = (String)objectMap.get(DomainObject.SELECT_TYPE);
            if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                slResults.addElement("ResourcePlanningYellowBackGroundColor");
            } else {
                slResults.addElement("ResourcePlanningGreenBackGroundColor");
            }
        }
        return slResults;
     }
     
    public int copyFinancialAttrs(Context context, String[] args) throws Exception {
        try {
            String sObjectId = args[0];
            String strType = args[1];
            DomainObject doBus = DomainObject.newInstance(context, sObjectId);
            String strCurObjAmount = doBus.getAttributeValue(context, ATTRIBUTE_WMSTOTALAMOUNT);
            BigDecimal bgCurrObjAmount = new BigDecimal(strCurObjAmount);
            String strWOID = "";
            if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                strWOID = doBus.getInfo(context, "to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            } else {
                strWOID = doBus.getInfo(context, "to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            }
            Map mFinancialDetails = getWOFinancials(context, strWOID);
            BigDecimal bgTotalExpended = (BigDecimal)mFinancialDetails.get("TotalExpendedAmount");
            BigDecimal bgCYExpended = (BigDecimal)mFinancialDetails.get("CYExpendedAmount");
            BigDecimal bgTotalAllotment = (BigDecimal)mFinancialDetails.get("TotalAllotment");
            //Reduce/Add the value of the current object from the total/CY
            BigDecimal bgCYAllotment = (BigDecimal)mFinancialDetails.get("CYAllotment");
            if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                bgTotalAllotment = bgTotalAllotment.subtract(bgCurrObjAmount);
                bgCYAllotment = bgCYAllotment.subtract(bgCurrObjAmount);
            } else {
                bgTotalAllotment = bgTotalAllotment.add(bgCurrObjAmount);
                bgCYAllotment = bgCYAllotment.add(bgCurrObjAmount);
            }
            BigDecimal bgFundBalance = bgTotalAllotment.subtract(bgTotalExpended);
            //Prepare AttrMap
            Map mapAttributes = new HashMap();
            mapAttributes.put(ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT, convertBGToString(bgTotalAllotment));
            mapAttributes.put(ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT, convertBGToString(bgCYAllotment));
            mapAttributes.put(ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT, convertBGToString(bgTotalExpended));
            mapAttributes.put(ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT, convertBGToString(bgCYExpended));
            mapAttributes.put(ATTRIBUTE_WMS_FUND_BALANCE_AMOUNT, convertBGToString(bgFundBalance));
            ContextUtil.pushContext(context);
            doBus.setAttributeValues(context, mapAttributes);
            ContextUtil.popContext(context);
            return 0;
        }
        catch (Exception e) {
            e.printStackTrace();
            return 1;
        }
    }
    
    public String convertBGToString(BigDecimal bgNumber)throws Exception {
        String strReturn = "";
        try {
            Double dblValue = Double.parseDouble(bgNumber.toString());
            strReturn = String.format("%.2f", dblValue);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return strReturn;
    }
    
    
    @com.matrixone.apps.framework.ui.ProgramCallable
    public  MapList getFundRequestApprovedDashboard(Context context, String[] args) throws Exception {
        MapList mlFinalList = new MapList();
        try
        {
            HashMap hashmap = (HashMap) JPO.unpackArgs(args);
            String strWMSFYFilter = (String)hashmap.get("WMSFYFilter");
            if (UIUtil.isNullOrEmpty(strWMSFYFilter)) {
                String strYear = DomainConstants.EMPTY_STRING;
                LocalDateTime now = LocalDateTime.now();
                int year = now.getYear();
                int month = now.getMonthValue();
                
                if(month>3){
                    strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
                }else{
                    strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
                }
                strWMSFYFilter = strYear;
            }
            String strWhere = "current==Approved && attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]=='"+strWMSFYFilter+"'";
            StringList strListBusSelects = new StringList();
            strListBusSelects.add(DomainObject.SELECT_ID);
            strListBusSelects.add(DomainObject.SELECT_NAME);
            strListBusSelects.add(DomainObject.SELECT_TYPE);
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
            strListBusSelects.add("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT+"]");
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT+"]");
            
            
            MapList mlFundItems = DomainObject.findObjects(context,
                                                            TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            DomainConstants.QUERY_WILDCARD,
                                                            strWhere,               // where expression
                                                            DomainConstants.EMPTY_STRING,
                                                            true,
                                                            strListBusSelects, // object selects
                                                            (short) 0);
                    
            Map mTemp = null;
            Map mFinalMap = null;
            String strType = "";
            StringList slWorkOrderList = new StringList();
            String strWOID = "";
            for(int i = 0; i < mlFundItems.size(); i++){
                mTemp = (Map)mlFundItems.get(i);
                strType = (String)mTemp.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mTemp.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                if (!slWorkOrderList.contains(strWOID)) {
                    slWorkOrderList.add(strWOID);
                }
            }
            int iWOListSize = slWorkOrderList.size();
            String[] saWOArray = new String[iWOListSize];
            StringList slWOSelectable = new StringList();
            slWOSelectable.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]");
            slWOSelectable.add(DomainConstants.SELECT_ID);
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]");
            slWOSelectable.add("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]");
            //make the array for WO objects
            for(int j = 0; j < iWOListSize; j++){
                saWOArray[j] = (String)slWorkOrderList.get(j);
            }
            MapList mlWOInfo = DomainObject.getInfo(context, saWOArray, slWOSelectable);
            //Get other fields for the WO
            Map mWOTemp = null;
            Map mCurrentWorkOrderDetails = new HashMap();
            Map mWorkOrderDetails = new HashMap();
            for(int k = 0; k < mlWOInfo.size(); k++){
                mCurrentWorkOrderDetails = new HashMap();
                mWOTemp = (Map)mlWOInfo.get(k);
                strWOID = (String)mWOTemp.get(DomainConstants.SELECT_ID);
                mCurrentWorkOrderDetails.put("CodeHead", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"]"));
                mCurrentWorkOrderDetails.put("ProjectName", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.name"));
                mCurrentWorkOrderDetails.put("WorkName", (String)mWOTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"]"));
                mCurrentWorkOrderDetails.put("CodeHeadName", (String)mWOTemp.get("to["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].from.from["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].to.attribute["+ATTRIBUTE_WMS_CODE_HEAD_NAME+"]"));
                mWorkOrderDetails.put(strWOID, mCurrentWorkOrderDetails);
            }
            //Prepare Final Map to be returned to the Table
            Map mFundMap = null;
            for(int l = 0; l < mlFundItems.size(); l++){
                mFundMap = (Map)mlFundItems.get(l);
                strType = (String)mFundMap.get(DomainObject.SELECT_TYPE);
                if (strType.equals(TYPE_WMS_FUND_REQUEST)) {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"].from.id");
                } else {
                    strWOID = (String)mFundMap.get("to["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"].from.id");
                }
                Map mWOTableDeatils = (Map)mWorkOrderDetails.get(strWOID);
                mFundMap.putAll(mWOTableDeatils);
                //Add values in specific keys of Map
                mFundMap.put("TotalExpendedAmount",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_TOTAL_EXPENDED_AMOUNT+"]")));
                mFundMap.put("CYExpendedAmount",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_CY_EXPENDED_AMOUNT+"]")));
                mFundMap.put("TotalAllotment",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_TOTAL_ALLOCATION_AMOUNT+"]")));
                mFundMap.put("CYAllotment",new BigDecimal((String)mFundMap.get("attribute["+ATTRIBUTE_WMS_CY_ALLOCATION_AMOUNT+"]")));
                mlFinalList.add(mFundMap);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        return mlFinalList;
    }
    
    @com.matrixone.apps.framework.ui.ProgramCallable
    public HashMap getFYDropdown(Context context, String[] args) throws Exception
    {
        HashMap mapFYs = new HashMap();
        Map programMap = (HashMap) JPO.unpackArgs(args);
        Map requestMap = (Map) programMap.get("requestMap");
        String strWMSFYFilter = (String) requestMap.get("WMSFYFilter");
        StringList slFYIds = new StringList();
        if (UIUtil.isNullOrEmpty(strWMSFYFilter)) {
            String strYear = DomainConstants.EMPTY_STRING;
            LocalDateTime now = LocalDateTime.now();
            int year = now.getYear();
            int month = now.getMonthValue();
            
            if(month>3){
                strYear = String.valueOf(year)+"-"+String.valueOf(year+1);    
            }else{
                strYear = String.valueOf(year-1)+"-"+String.valueOf(year);    
            }
            strWMSFYFilter = strYear;
        }
        slFYIds.add(strWMSFYFilter);
        
        StringList strListBusSelects = new StringList(2);
        strListBusSelects.add("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
        
        MapList mlFundItems = DomainObject.findObjects(context,
                                                        TYPE_WMS_FUND_REQUEST+","+TYPE_WMS_FUND_RELEASE, 
                                                        DomainConstants.QUERY_WILDCARD,
                                                        DomainConstants.QUERY_WILDCARD,
                                                        DomainConstants.QUERY_WILDCARD,
                                                        DomainConstants.QUERY_WILDCARD,
                                                        "current==Approved",               // where expression
                                                        DomainConstants.EMPTY_STRING,
                                                        true,
                                                        strListBusSelects, // object selects
                                                        (short) 0);
        
        
        
        mlFundItems.sortStructure("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]","ascending","string");
        //get the FYs
        Map mpObjInfo;
        String strFY = "";
        for (Object obj : mlFundItems) {
            mpObjInfo = (Map) obj;
            strFY = (String) mpObjInfo.get("attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"]");
            if (strWMSFYFilter.equals(strFY)) {
                continue;
            }
            if (!slFYIds.contains(strFY)) {
                slFYIds.add(strFY);
            }
        }
        
        mapFYs.put("field_choices", slFYIds);
        mapFYs.put("field_display_choices", slFYIds);
        return mapFYs;
    }
	@com.matrixone.apps.framework.ui.ProgramCallable
    public HashMap getTypeOfReportsDropdown(Context context, String[] args) throws Exception
    {
        HashMap mapTypes = new HashMap();
        Map programMap = (HashMap) JPO.unpackArgs(args);
        Map requestMap = (Map) programMap.get("requestMap");

		String strFYFilter = (String) requestMap.get("WMSFinancialProgressFYFilter");
		String strFinancialProgressTypeOfReportFilter = (String) requestMap.get("WMSFinancialProgressTypeOfReportFilter");
		String strFinancialProgressCodeHeadFilter = (String) requestMap.get("WMSFinancialProgressCodeHeadFilter");
		
		StringList slTypeOfReports = new StringList(4);
		slTypeOfReports.addElement("Preliminary Revised Estimate");
		slTypeOfReports.addElement("Monthly Appropriation Report");
		slTypeOfReports.addElement("Budget Estimate");
		slTypeOfReports.addElement("Revised Estimate");
		
		if (!UIUtil.isNullOrEmpty(strFinancialProgressTypeOfReportFilter))
		{
			slTypeOfReports.removeElement(strFinancialProgressTypeOfReportFilter);
			slTypeOfReports.add(0, strFinancialProgressTypeOfReportFilter);
		}
        
        mapTypes.put("field_choices", slTypeOfReports);
        mapTypes.put("field_display_choices", slTypeOfReports);
        return mapTypes;
    }
	@com.matrixone.apps.framework.ui.ProgramCallable
    public HashMap getCodeHeadDropdown(Context context, String[] args) throws Exception
    {
		HashMap mapCodeHeads = new HashMap();
		Map programMap = (HashMap) JPO.unpackArgs(args);
		Map requestMap = (Map) programMap.get("requestMap");

		String strFYFilter = (String) requestMap.get("WMSFinancialProgressFYFilter");
		String strFinancialProgressTypeOfReportFilter = (String) requestMap.get("WMSFinancialProgressTypeOfReportFilter");
		String strFinancialProgressCodeHeadFilter = (String) requestMap.get("WMSFinancialProgressCodeHeadFilter");

		StringList strListBusSelects = new StringList();
		strListBusSelects.add(DomainObject.SELECT_ID);
		strListBusSelects.add(DomainObject.SELECT_NAME);
		strListBusSelects.add("attribute[WMSCodeHeadName].value");
		MapList mlCodeHeads = DomainObject.findObjects(
													context,
													TYPE_WMS_CODE_HEAD,
													DomainConstants.QUERY_WILDCARD,
													DomainConstants.QUERY_WILDCARD,
													DomainConstants.QUERY_WILDCARD,
													DomainConstants.QUERY_WILDCARD,
													null,// where expression
													DomainConstants.EMPTY_STRING,
													true,
													strListBusSelects, // object selects
													(short) 0);
		
		StringList slCodeHeads = new StringList(mlCodeHeads.size());
		for(int i = 0 ; i < mlCodeHeads.size() ; i++)
		{
			slCodeHeads.addElement((String)((Map)mlCodeHeads.get(i)).get("name"));
		}
		if (!UIUtil.isNullOrEmpty(strFinancialProgressCodeHeadFilter))
		{
			slCodeHeads.removeElement(strFinancialProgressCodeHeadFilter);
			slCodeHeads.add(0, strFinancialProgressCodeHeadFilter);
		}
		else
		{
			slCodeHeads.add(0, "all");
		}
        
        mapCodeHeads.put("field_choices", slCodeHeads);
        mapCodeHeads.put("field_display_choices", slCodeHeads);
        return mapCodeHeads;
    }
}
