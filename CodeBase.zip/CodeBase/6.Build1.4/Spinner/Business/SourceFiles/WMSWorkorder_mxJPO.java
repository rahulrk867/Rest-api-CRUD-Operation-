/** Name of the JPO    : WMSWorkorder
 ** Developed by    : DSIS 
 ** Client            : WMS
 ** Description        : The purpose of this JPO is to manage all code for Workorder
 ** Revision Log:
 ** -----------------------------------------------------------------
 ** Author                    Modified Date                History
 ** -----------------------------------------------------------------

 ** -----------------------------------------------------------------
 **/
import com.matrixone.apps.domain.util.MailUtil;
import org.joda.time.LocalDate;
import org.joda.time.Days;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Calendar;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import java.text.DateFormat;

import matrix.util.Pattern;
import matrix.util.StringList;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.Page;
import java.util.Vector;
import java.text.DecimalFormat;
import java.lang.Math;
 
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
 
import com.matrixone.apps.common.Company;

/**
 * The purpose of this JPO is to handle functionality of SOR
 * @author DSIS
 */
public class WMSWorkorder_mxJPO extends WMSConstants_mxJPO
{
    /**
     * Constructor.
     * @param context - the eMatrix <code>Context</code> object
     * @param args - holds no arguments
     * @throws Exception if the operation fails
     * @author DSIS
     */

    public WMSWorkorder_mxJPO(Context context, String[] args) throws Exception
    {
       super(context,args);
    }
/**
     * Method to get the connected Work Orders from the Project
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command or form or table
     * @return mapListWorkOrders MapList containing the Work Order MBEs
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getWorkOrders (Context context, String[] args) throws Exception 
    {
        try
        {     
		 
            MapList mapListWorkOrders = new MapList();
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
		    if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
                DomainObject domObjWO = DomainObject.newInstance(context, strObjectId);
                mapListWorkOrders = getWorkOrders(context, domObjWO);
			 
            }
            return mapListWorkOrders;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

    /**
     * Function to get the Work Orders connected to the Project Space
     *
     * @param context the eMatrix <code>Context</code> object
     * @param domObjProjectSpace DomainObject instance of selected Work Order 
     * @return mapListMBEs MapList containing the MBEs connected to Work Order with ID
     * @throws FrameworkException if the operation fails
     * @author WMS
     * @since 418
     */
    private MapList getWorkOrders(Context context, DomainObject domObjProjectSpace)
            throws Exception {
        try
        {
            StringList strListBusSelects     = new StringList(2);
            strListBusSelects.add(DomainConstants.SELECT_ID);
            strListBusSelects.add(DomainConstants.SELECT_NAME);
            strListBusSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value");
            StringList strListRelSelects     = new StringList(1);
            strListRelSelects.add(DomainRelationship.SELECT_ID);

            MapList mapListWorkOrders = domObjProjectSpace.getRelatedObjects(context, // matrix context
                    "WMSProjectWorkOrder",//RELATIONSHIP_PROJECT_WO, // relationship pattern
                    "WMSWorkOrder", //TYPE_WMSWorkorder, // type pattern
                    strListBusSelects, // object selects
                    strListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 0, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
            return mapListWorkOrders;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }


    /**
     * Access function for formType of Work Order set Non editableto make it editable
     * @param context The Matrix Context object
     * @param args holds the arguments:     
     * @throws Exception if the operation fails
     */ 
    public String setCompletionDuedateField(Context context, String[] args)throws Exception 
    {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
        HashMap requestMap = (HashMap) programMap.get("requestMap");
        String strMode = (String) requestMap.get("mode");

        StringBuffer strPAC = new StringBuffer();
        try
        {
            if("create".equals(strMode))
            {
                strPAC.append("<input type=\"text\" readonly=\"true\" size=\"20\" name=\"CompletionDueDate1\" id=\"CompletionDueDate1\" />");
            }
            else if("edit".equals(strMode))
            {
                HashMap paramMap = (HashMap) programMap.get("paramMap");
                String sWorkOrderOid = (String) paramMap.get("objectId");
                DomainObject domObj = DomainObject.newInstance(context, sWorkOrderOid);
                String strAttrCompletionDueDate = domObj.getInfo(context, "attribute["+ATTRIBUTE_WMS_COMPLETION_DUE_DATE+"]");
                if(UIUtil.isNotNullAndNotEmpty(strAttrCompletionDueDate)){
                    Date date = new Date(strAttrCompletionDueDate);  
                    SimpleDateFormat formatter = new SimpleDateFormat("MMM dd, yyyy");  
                    String strDate = formatter.format(date);  
                    strPAC.append("<input type=\'text\' readonly=\'true\' size=\'20\' name=\'CompletionDueDate1\' id=\'CompletionDueDate1\' value =\'"+strDate+"\'/>");
                }
            }
        }
        catch(Exception exception) 
        {
            exception.printStackTrace();
            throw exception;
        } 	
        return strPAC.toString();
    }



    /** 
      * Method will connect the Work Order In Projects
      * @param args Packed program and request maps for the table
      * @throws Exception if the operation fails
      * @author WMS
      * @since 418
      */
    @com.matrixone.apps.framework.ui.PostProcessCallable
    public Map connectWorkOrderInProjects(Context context, String[] args) throws Exception {
        HashMap mapReturnMap = new HashMap();
     
        try {
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
            HashMap paramMap             = (HashMap)programMap.get("paramMap");
            HashMap requestMap           = (HashMap)programMap.get("requestMap");
            String strWOOID             = (String) paramMap.get("objectId");
            String strProjectOID     = (String) requestMap.get("parentOID");
            String ContractorOID     =(String) requestMap.get("NameOfContractorOID");
			String PMCConsultantOID     =(String) requestMap.get("PMCConsultantCompanyOID");
            String strCompletionDate     =(String) requestMap.get("CompletionDueDate1");
            String strValueOfContract     =(String) requestMap.get("ValueOfContract1");
            String strDepartment     =(String) requestMap.get("Department");
			System.out.println("strDepartment:"+strDepartment);
            String strTSId     =(String) requestMap.get("TSOID");
			
            Date dCompletionDate = new Date(strCompletionDate);
            long lCompletionTime = dCompletionDate.getTime();
       
        
            //use MatrixDateFormat's pattern
            SimpleDateFormat mxDateFrmt = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
            String strFormattedCompletionDate = mxDateFrmt.format(dCompletionDate);
         
            if( UIUtil.isNotNullAndNotEmpty(strWOOID))
            {
                                  
                HashMap<String,String> hashMapAttributes = new HashMap<>(2);
                hashMapAttributes.put(ATTRIBUTE_WMS_VALUE_OF_CONTRACT, strValueOfContract);
                hashMapAttributes.put("WMSDepartmentUI", strDepartment);
				if("Revenue".equals(strDepartment))
				{
					hashMapAttributes.put("WMSDepartment", "Equipments");
				}
				else
				{
					hashMapAttributes.put("WMSDepartment", strDepartment);
				}
                hashMapAttributes.put(ATTRIBUTE_WMS_COMPLETION_DUE_DATE, strFormattedCompletionDate);
                DomainObject domObjWO = DomainObject.newInstance(context, strWOOID);
                domObjWO.setAttributeValues(context, hashMapAttributes);
                 
            }
            if(UIUtil.isNotNullAndNotEmpty(ContractorOID) && UIUtil.isNotNullAndNotEmpty(strWOOID))
            {
                DomainRelationship.connect(context, ContractorOID, RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR, strWOOID, true);
            }
			
			if(UIUtil.isNotNullAndNotEmpty(PMCConsultantOID) && UIUtil.isNotNullAndNotEmpty(strWOOID))
            {
                DomainRelationship.connect(context, PMCConsultantOID, RELATIONSHIP_WMS_WORKORDER_PMC_CONSULTANT, strWOOID, true);
            }
			if(UIUtil.isNotNullAndNotEmpty(strTSId) && UIUtil.isNotNullAndNotEmpty(strWOOID))
            {
                DomainRelationship.connect(context, strWOOID, RELATIONSHIP_WMS_WORK_ORDER_TS, strTSId, true);
            }
            if(UIUtil.isNotNullAndNotEmpty(strProjectOID) && UIUtil.isNotNullAndNotEmpty(strWOOID))
            {
                ContextUtil.pushContext(context);
                DomainRelationship.connect(context, strProjectOID, RELATIONSHIP_WMS_PROJECT_WORK_ORDER, strWOOID, true);
                ContextUtil.popContext(context);
				StringBuffer strBuffer = new StringBuffer();
                strBuffer.append("<mxRoot>");
                strBuffer.append("<action><![CDATA[add]]></action>");
                strBuffer.append("<data status=\"committed\">");
                strBuffer.append("<item oid=\""+strWOOID+"\" relId=\""+""+"\" pid=\""+strWOOID+"\"  direction=\"from\" />");
                strBuffer.append("</data>");
                strBuffer.append("</mxRoot>");
                mapReturnMap.put("selectedOID", strProjectOID);
                mapReturnMap.put("rows",strBuffer.toString());
                //mapReturnMap.put ("Action", "execScript");
                //mapReturnMap.put("Message", "{ main:function() {alert(11);refreshRows();refreshStructureWithOutSort();}}");
                mapReturnMap.put("Insertdata",strBuffer.toString());
              //  mapReturnMap.put("Message","Successfully created workorder ");
                mapReturnMap.put("Action","success");
            }
        } catch (Exception exception) {
         exception.printStackTrace();
            mapReturnMap.put("Action","Stop");
            mapReturnMap.put("Message",exception.getMessage());
        }
        return mapReturnMap;
    }


   @com.matrixone.apps.framework.ui.ProgramCallable
    public String SetWOCompleteDateRainySeason(Context context, String[] args) throws Exception
    {
        String strNewEnddate = "";
        try
        {
            HashMap programMap          = (HashMap)JPO.unpackArgs(args);
            String strWOStartDate = (String)programMap.get("strWOStartDate");
            String strWOEndDate = (String)programMap.get("strWOEndDate");
            String strDuration = (String)programMap.get("Duration");
            String strPreparationTime = (String)programMap.get("PreparationTime");
            int intDuration = Integer.parseInt(strDuration);
                    
            //String strLanguage = context.getSession().getLanguage();
            String strDefaultRainyStartDate =  EnoviaResourceBundle.getProperty(context,"wmsCustom", context.getLocale(), "WMS.RainySeason.StartDate");
            String strDefaultRainyEndDate = EnoviaResourceBundle.getProperty(context,"wmsCustom", context.getLocale(), "WMS.RainySeason.EndDate");
            String strWOPreparationTime = EnoviaResourceBundle.getProperty(context,"wmsCustom", context.getLocale(), "WMS.WorkOrder.PreparationTime");
            int intPreparationTime = Integer.parseInt(strWOPreparationTime.trim());
            if("Yes".equals(strPreparationTime))
            {
                intDuration = intDuration+intPreparationTime;
            }
            //Get rainy Start Date and Month
            StringList strListRainyDaysMonthStart = FrameworkUtil.split(strDefaultRainyStartDate, "-");
            StringList strListRainyDaysMonthEnd = FrameworkUtil.split(strDefaultRainyEndDate, "-");
            
            int intRainySeasonStartDate = -1;
            int intRainySeasonStartMonth = -1;
            int intRainySeasonEndDate = -1;
            int intRainySeasonEndMonth = -1;
            
            if(strListRainyDaysMonthStart!=null && strListRainyDaysMonthEnd!=null)
            {
                if(strListRainyDaysMonthStart.size()>=0)
                {
                    String strRainySeasonStartDate = (String)strListRainyDaysMonthStart.get(0);
                    String strRainySeasonStartMonth = (String)strListRainyDaysMonthStart.get(1);
                    intRainySeasonStartDate = WMSUtil_mxJPO.convertToInteger(strRainySeasonStartDate);
                    intRainySeasonStartMonth = WMSUtil_mxJPO.convertToInteger(strRainySeasonStartMonth);
                }
                if(strListRainyDaysMonthEnd.size()>=0)
                {
                    String strRainySeasonStartDate = (String)strListRainyDaysMonthEnd.get(0);
                    String strRainySeasonStartMonth = (String)strListRainyDaysMonthEnd.get(1);
                    intRainySeasonEndDate = WMSUtil_mxJPO.convertToInteger(strRainySeasonStartDate);
                    intRainySeasonEndMonth = WMSUtil_mxJPO.convertToInteger(strRainySeasonStartMonth);
                }
            }
                    
                            
            Calendar calendarStartDate = Calendar.getInstance();
            Calendar calendarEndDate = Calendar.getInstance();
            
            int intCurrentYear = calendarStartDate.get(Calendar.YEAR);
            
            long lWOStartDate=Long.parseLong(strWOStartDate);  
            long lWOEndDate=Long.parseLong(strWOEndDate);
            calendarStartDate.setTimeInMillis(lWOStartDate);
            calendarEndDate.setTimeInMillis(lWOEndDate);
                                
            Calendar calendarRainyStartDate = Calendar.getInstance();
            calendarRainyStartDate.set(intCurrentYear,intRainySeasonStartMonth-1 ,intRainySeasonStartDate,0,0);
            Date dRainyStartDate = calendarRainyStartDate.getTime();
            
            Calendar calendarRainyEndDate = Calendar.getInstance();
            calendarRainyEndDate.set(intCurrentYear,intRainySeasonEndMonth-1 ,intRainySeasonEndDate,0,0);
            Date dRainyEndDate = calendarRainyEndDate.getTime();
                                
            //Duration of Rainy days
            long lRainyDuration = (dRainyStartDate.getTime() - dRainyEndDate.getTime())/(1000*60*60*24);
            lRainyDuration =Math.abs(lRainyDuration);
            int intRainyDuration= (int) lRainyDuration;

            //Check end date falling into Rainy Season days
            int intEndMonth = calendarEndDate.get(Calendar.MONTH);
            int intEndDay = calendarEndDate.get(Calendar.DAY_OF_MONTH);					
                                    
            boolean bEndDateflag = false;          
            intEndMonth++;
            if(intEndMonth == intRainySeasonStartMonth)
            {
              if(intEndDay >=intRainySeasonStartDate)
                {
                    bEndDateflag =	true;				
                }
            }
            else if(intEndMonth>intRainySeasonStartMonth)
            {
                if(intEndMonth < intRainySeasonEndMonth)
                {
                  bEndDateflag =	true;
                }
                else if((intEndMonth == intRainySeasonEndMonth&& intEndDay <= intRainySeasonEndDate))
                {
                    bEndDateflag =	true;
                }
            }
            int intEnddateYear = calendarEndDate.get(Calendar.YEAR);
            //end Date falls into Rainy and Same Year
            int intCounter=0;
            if(bEndDateflag && (intCurrentYear == intEnddateYear))
            {
                //Check Start date falls In between Rainy Days to calculate only rainy days fall between start and rainy End date
                boolean bStartDateflag = false;
                int intStartMonth = calendarStartDate.get(Calendar.MONTH);
                int intStartDay = calendarStartDate.get(Calendar.DAY_OF_MONTH);
                intStartMonth++;   
                if( intStartMonth == intRainySeasonStartMonth )
                {
                  if(intStartDay >= intRainySeasonStartDate )
                    {
                        bStartDateflag =	true;				
                    }
                }
                else if(intStartMonth>intRainySeasonStartMonth)
                {
                    if( intStartMonth < intRainySeasonEndMonth)
                    {
                      bStartDateflag =	true;
                    }
                    else if( (intEndMonth == intRainySeasonEndMonth&& intEndDay <= intRainySeasonEndDate))
                    {
                        bStartDateflag =	true;
                    }
                }
                if(bStartDateflag)
                {						
                    //start date and end date falling into Rainy days same year..Start date will be one day after rainy end date
                    calendarStartDate.set(intCurrentYear,intRainySeasonEndMonth-1 ,intRainySeasonEndDate+1,0,0);
                    calendarStartDate.add(Calendar.DATE, intDuration);
                    long lDateInMillis = calendarStartDate.getTimeInMillis();
                    strNewEnddate = Long.toString(lDateInMillis);
                }
                else
                {
                intDuration = intDuration+intRainyDuration;
                calendarStartDate.add(Calendar.DATE, intDuration);
                long lDateInMillis = calendarStartDate.getTimeInMillis();
                strNewEnddate = Long.toString(lDateInMillis);
                }
            }
            //end Date falls into Rainy and Future Year
            else if(bEndDateflag && (intCurrentYear < intEnddateYear))
            {
                //Check Start date falls In between Rainy Days to calculate only rainy days fall between start and rainy End date
                boolean bStartDateflag = false;
                int intStartMonth = calendarStartDate.get(Calendar.MONTH);
                int intStartDay = calendarStartDate.get(Calendar.DAY_OF_MONTH);
                intStartMonth++;   
                if( intStartMonth == intRainySeasonStartMonth )
                {
                  if(intStartDay >= intRainySeasonStartDate )
                    {
                        bStartDateflag =	true;				
                    }
                }
                else if(intStartMonth>intRainySeasonStartMonth)
                {
                    if( intStartMonth < intRainySeasonEndMonth)
                    {
                      bStartDateflag =	true;
                    }
                    else if( (intEndMonth == intRainySeasonEndMonth&& intEndDay <= intRainySeasonEndDate))
                    {
                        bStartDateflag =	true;
                    }
                }
                if(bStartDateflag)
                {
                    intCounter=0;
                    //Calculating the Number of days falling into rainy days
                    while(calendarStartDate.before(calendarRainyEndDate))
                    {
                        int intMonth = calendarStartDate.get(Calendar.MONTH);
                        int intDay = calendarStartDate.get(Calendar.DAY_OF_MONTH);
                        intMonth++;                       
                        if(intMonth == intRainySeasonStartMonth)
                        {
                            if(intDay >= intRainySeasonStartDate)
                            {
                                intCounter++;								
                            }
                        }
                        //Check if it in equal to rainy Start date and Month
                        else if(intMonth>intRainySeasonStartMonth)
                        {
                            if(intMonth < intRainySeasonEndMonth)
                            {
                                intCounter++;
                            }
                            else if(intMonth == intRainySeasonEndMonth&&intDay <= intRainySeasonEndDate)
                            {
                                intCounter++;
                            }
                        }
                        calendarStartDate.add(Calendar.DATE, 1);
                    }//End of Calculation
                }
                else
                {
                    intCounter=0;
                    //Calculating the Number of days falling into rainy days
                    while(calendarStartDate.before(calendarRainyEndDate))
                    {
                        int intMonth = calendarStartDate.get(Calendar.MONTH);
                        int intDay = calendarStartDate.get(Calendar.DAY_OF_MONTH);
            
                        intMonth++;                       
                        if(intMonth == intRainySeasonStartMonth)
                        {
                            if(intDay >= intRainySeasonStartDate)
                            {
                                intCounter++;								
                            }
                        }
                        //Check if it in equal to rainy Start date and Month
                        else if(intMonth>intRainySeasonStartMonth)
                        {
                            if(intMonth < intRainySeasonEndMonth)
                            {
                                intCounter++;
                            }
                            else if(intMonth == intRainySeasonEndMonth&&intDay <= intRainySeasonEndDate)
                            {
                                intCounter++;
                            }
                        }
                        calendarStartDate.add(Calendar.DATE, 1);
                    }//End of Calculation
                }//
                calendarStartDate.set(intCurrentYear,intRainySeasonEndMonth-1 ,intRainySeasonEndDate+1,0,0);
                int intSecondDuration =0;
                while(calendarStartDate.before(calendarEndDate))
                {
                    int intMonth = calendarStartDate.get(Calendar.MONTH);
                    int intDay = calendarStartDate.get(Calendar.DAY_OF_MONTH);
                    
                    intMonth++;                       
                    if(intMonth == intRainySeasonStartMonth)
                    {
                        if(intDay >= intRainySeasonStartDate)
                        {
                            intSecondDuration++;								
                        }
                    }
                    //Check if it in equal to rainy Start date and Month
                    else if(intMonth>intRainySeasonStartMonth)
                    {
                        if(intMonth < intRainySeasonEndMonth)
                        {
                            intSecondDuration++;
                        }
                        else if(intMonth == intRainySeasonEndMonth&&intDay <= intRainySeasonEndDate)
                        {
                            intSecondDuration++;
                        }
                    }
                    calendarStartDate.add(Calendar.DATE, 1);
                }//End of Calculation
                calendarStartDate.setTimeInMillis(lWOStartDate);
                //set Second Duration 92 days if it less than rainy season days since it will fall into rainy day again it should be considered as 92 days
                if(intSecondDuration>0 && intSecondDuration< intRainyDuration )
                {
                    intSecondDuration = intRainyDuration;
                }
                //intcounter is from current year and add rainy days since End date falls into rainy days
                intDuration = intDuration+intCounter+intSecondDuration;
                calendarStartDate.add(Calendar.DATE, intDuration);
                long lDateInMillis = calendarStartDate.getTimeInMillis();
                Calendar calendarNewEndDate = Calendar.getInstance();
                calendarNewEndDate.setTimeInMillis(lDateInMillis);
                
                //Check the New End date falls again between Rainy Days
                intEndMonth = calendarNewEndDate.get(Calendar.MONTH);
                intEndDay = calendarNewEndDate.get(Calendar.DAY_OF_MONTH);					
                                        
                boolean bNewEndDateflag = false;          
                intEndMonth++;
                if(intEndMonth == intRainySeasonStartMonth)
                {
                  if(intEndDay >=intRainySeasonStartDate)
                    {
                        bNewEndDateflag =	true;				
                    }
                }
                else if(intEndMonth>intRainySeasonStartMonth)
                {
                    if(intEndMonth < intRainySeasonEndMonth)
                    {
                      bNewEndDateflag =	true;
                    }
                    else if((intEndMonth == intRainySeasonEndMonth&& intEndDay <= intRainySeasonEndDate))
                    {
                        bNewEndDateflag =	true;
                    }
                }
                if(bNewEndDateflag)
                {
                 //Add Rainy days Again to Final Duration
                 intDuration =intDuration+intRainyDuration;
                 calendarStartDate.setTimeInMillis(lWOStartDate);
                 calendarStartDate.add(Calendar.DATE, intDuration);
                 lDateInMillis = calendarStartDate.getTimeInMillis();
                 strNewEnddate = Long.toString(lDateInMillis);
                }
                else
                {
                    strNewEnddate = Long.toString(lDateInMillis);
                }
                
            }
            //if End date falls after Rainy Days
            else
            {
                 intCounter=0;
                    //Calculating the Number of days falling into rainy days
                    while(calendarStartDate.before(calendarEndDate))
                    {
                        int intMonth = calendarStartDate.get(Calendar.MONTH);
                        int intDay = calendarStartDate.get(Calendar.DAY_OF_MONTH);
                        
                intMonth++;                       
                if(intMonth==intRainySeasonStartMonth)
                {
                    if(intDay>=intRainySeasonStartDate)
                    {
                        intCounter++;								
                    }
                }
                //Check if it in equal to rainy Start date and Month
                else if(intMonth>intRainySeasonStartMonth)
                {
                    if(intMonth<intRainySeasonEndMonth)
                    {
                        intCounter++;
                    }
                    else if(intMonth==intRainySeasonEndMonth&&intDay<=intRainySeasonEndDate)
                    {
                        intCounter++;
                    }
                }
                calendarStartDate.add(Calendar.DATE, 1);
                    }//End of Calculation
                calendarStartDate.setTimeInMillis(lWOStartDate);
                intDuration = intDuration+intCounter;
                calendarStartDate.add(Calendar.DATE, intDuration);
                long lDateInMillis = calendarStartDate.getTimeInMillis();
                Calendar calendarNewEndDate = Calendar.getInstance();
                calendarNewEndDate.setTimeInMillis(lDateInMillis);
                
                //Calculate Rainy days between End Date and New End date
                   int intNewCounter = 0;
                   while(calendarEndDate.before(calendarNewEndDate))
                    {
                         int intMonth = calendarEndDate.get(Calendar.MONTH);
                         int intDay = calendarEndDate.get(Calendar.DAY_OF_MONTH);
                        
                        intMonth++;                       
                        if(intMonth == intRainySeasonStartMonth)
                        {
                            if(intDay >= intRainySeasonStartDate)
                            {
                                intNewCounter++;								
                            }
                        }
                        //Check if it in equal to rainy Start date and Month
                        else if(intMonth>intRainySeasonStartMonth)
                        {
                            if(intMonth < intRainySeasonEndMonth)
                            {
                                intNewCounter++;
                            }
                            else if(intMonth == intRainySeasonEndMonth&&intDay <= intRainySeasonEndDate)
                            {
                                intNewCounter++;
                            }
                        }
                        calendarEndDate.add(Calendar.DATE, 1);
                    }//End of Calculation
                if(intNewCounter>0 && intNewCounter< intRainyDuration )
                {
                    intNewCounter = intRainyDuration;
                }
                //set new End date since New count 
                calendarStartDate.setTimeInMillis(lWOStartDate);
                intDuration = intDuration+intNewCounter;
                calendarStartDate.add(Calendar.DATE, intDuration);
                lDateInMillis = calendarStartDate.getTimeInMillis();
                calendarNewEndDate.setTimeInMillis(lDateInMillis);
                
                //Check the New End date falls again between Rainy Days
                intEndMonth = calendarNewEndDate.get(Calendar.MONTH);
                intEndDay = calendarNewEndDate.get(Calendar.DAY_OF_MONTH);					
                                        
                boolean bNewEndDateflag = false;          
                intEndMonth++;
                if(intEndMonth == intRainySeasonStartMonth)
                {
                  if(intEndDay >=intRainySeasonStartDate)
                    {
                        bNewEndDateflag =	true;				
                    }
                }
                else if(intEndMonth>intRainySeasonStartMonth)
                {
                    if(intEndMonth < intRainySeasonEndMonth)
                    {
                      bNewEndDateflag =	true;
                    }
                    else if((intEndMonth == intRainySeasonEndMonth&& intEndDay <= intRainySeasonEndDate))
                    {
                        bNewEndDateflag =	true;
                    }
                }
                if(bNewEndDateflag)
                {
                 //Add Rainy days Again to Final Duration
                 intDuration =intDuration+intRainyDuration;
                 calendarStartDate.setTimeInMillis(lWOStartDate);
                 calendarStartDate.add(Calendar.DATE, intDuration);
                 lDateInMillis = calendarStartDate.getTimeInMillis();
                 strNewEnddate = Long.toString(lDateInMillis);
                }
                else
                {
                    strNewEnddate = Long.toString(lDateInMillis);
                }
                
            }
                
                                        
        }
        catch (Exception e) {
            throw new Exception("Error in Method SetWOCompleteDateRainySeason:"+e.getMessage());
        }  
                         
        return strNewEnddate;
    }

	@com.matrixone.apps.framework.ui.ExcludeOIDProgramCallable
    public StringList excludeHostCompany(Context context, String[] args) throws Exception {
        StringList slReturnValue = new StringList();
        try {
            String strHostId = Company.getHostCompany(context);
            slReturnValue.add(strHostId);
        } catch (Exception e) {
            throw new FrameworkException(e.getMessage());
        }
        return slReturnValue;
    }

        /** 
     * Method will update the Work Order deatils in Edit mode
     * @param args Packed program and request maps for the table
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.PostProcessCallable
    public Map updateWorkOrderDetails(Context context, String[] args) throws Exception {
        HashMap mapReturnMap = new HashMap();
        try {
            HashMap programMap 		= (HashMap) JPO.unpackArgs(args);
            HashMap paramMap		= (HashMap) programMap.get("paramMap");
            HashMap requestMap 		= (HashMap) programMap.get("requestMap");
            String strWOOID 		= (String) paramMap.get("objectId");
            //String strCompletionDate	 	= (String) requestMap.get("CompletionDueDate1");
            String strValueOfContract 		= (String) requestMap.get("ValueOfContract1");
            //Date dCompletionDate = new Date(strCompletionDate);
            //long lCompletionTime = dCompletionDate.getTime();

            SimpleDateFormat mxDateFrmt = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
            //String strFormattedCompletionDate = mxDateFrmt.format(dCompletionDate);
         
            if (UIUtil.isNotNullAndNotEmpty(strWOOID))
            {

                HashMap<String, String> hashMapAttributes = new HashMap<>(2);
                hashMapAttributes.put(ATTRIBUTE_WMS_VALUE_OF_CONTRACT, strValueOfContract);
                //hashMapAttributes.put(ATTRIBUTE_COMPLETION_DUE_DATE, strFormattedCompletionDate);
                DomainObject domObjWO = DomainObject.newInstance(context, strWOOID);
                domObjWO.setAttributeValues(context, hashMapAttributes);
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return mapReturnMap;
    }

    /**
     * Method to connect the Work Order and MBE
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args Packed program and request maps from the command
     * @throws Exception if the operation fails
     * @author WMS
     * @since 418
     */
    @com.matrixone.apps.framework.ui.CreateProcessCallable
    public void connectWorkOrderAndContractor(Context context,String[]args)throws Exception
    {
        try{
        Map programMap                 = JPO.unpackArgs(args);
        HashMap paramMap             = (HashMap) programMap.get("paramMap");
        HashMap requestMap      = (HashMap)programMap.get("requestMap");
        String strWorkOrderOID             = (String) paramMap.get("objectId");
        String strNewSuppOID             = (String) paramMap.get("New OID");

        
        if(UIUtil.isNotNullAndNotEmpty(strWorkOrderOID) )
            {
                 DomainObject domObjWO = DomainObject.newInstance(context, strWorkOrderOID);
                StringList strListBusSelects     = new StringList(1);
                StringList strListRelSelects     = new StringList(1);
                strListRelSelects.add(DomainRelationship.SELECT_ID);
                 String strOldRelID = "";
                MapList mapListOrg = domObjWO.getRelatedObjects(context, // matrix context
                		RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR, // relationship pattern
                        DomainConstants.TYPE_COMPANY, // type pattern
                        strListBusSelects, // object selects
                        strListRelSelects, // relationship selects
                        true, // to direction
                        true, // from direction
                        (short) 1, // recursion level
                        DomainConstants.EMPTY_STRING, // object where clause
                        DomainConstants.EMPTY_STRING, // relationship where clause
                        0);
                
                if(mapListOrg.size() > 0)
                {
                            Iterator<Map<String,String>> itemsIterator = mapListOrg.iterator();
                            Map<String,String> itemsmapData;
                            DomainObject domObjItem  = DomainObject.newInstance(context);
                                
                            while(itemsIterator.hasNext()){
                                itemsmapData = itemsIterator.next();
                                strOldRelID = itemsmapData.get(DomainRelationship.SELECT_ID);
                            }
                            if(UIUtil.isNotNullAndNotEmpty(strOldRelID) && UIUtil.isNotNullAndNotEmpty(strNewSuppOID))
                            {
                                 //Disconnect Old Supplier and Connect New Supplier
                                 DomainRelationship.disconnect(context,strOldRelID); 	 
                                 DomainRelationship.connect(context, strNewSuppOID,RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR, strWorkOrderOID, true);
                            }
                            if(UIUtil.isNotNullAndNotEmpty(strOldRelID) && UIUtil.isNullOrEmpty(strNewSuppOID))
                            {
                                //Disconnect current Supplier
                                DomainRelationship.disconnect(context,strOldRelID); 	 
                            }
                }
                //Connect New Supplier 
                else{
                    if(UIUtil.isNotNullAndNotEmpty(strNewSuppOID))
                    {
                        DomainRelationship.connect(context, strNewSuppOID,RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR, strWorkOrderOID, true);
                    }
                 }
            }
                
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }

/**
* Returns ematrix Date display format for Forms
* @author WMS
* @throws Exception 
* @since 418
		**/
public String getEmatrixDateFormat(Context context, String[] args)
		throws Exception {
	String strFormattedDate = "";
		try{ 
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String strDateForFormat = (String)programMap.get("Date");

			Calendar calendarDate = Calendar.getInstance();
			long lDateForFormat=Long.parseLong(strDateForFormat);
			calendarDate.setTimeInMillis(lDateForFormat);
			SimpleDateFormat simpleDateFormatMatrix = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(),context.getLocale());
			strFormattedDate = simpleDateFormatMatrix.format(calendarDate.getTime());

			Date dStartDate=simpleDateFormatMatrix.parse(strFormattedDate);	
			DateFormat dateFormat = DateFormat.getDateInstance(eMatrixDateFormat.getEMatrixDisplayDateFormat(),context.getLocale());
			strFormattedDate = dateFormat.format(dStartDate);

		}
		catch(Exception exception) 
		{
			exception.printStackTrace();
			throw exception;
		} 
		return strFormattedDate;
	}


	
	public int triggerEnsureApprovalTemplate(Context context, String[] args) throws Exception {
    	String STR_ERROR_MSG_EMPTY="Purpose is empty for Approval Template ";
    	String STR_ERROR_MSG="Please add Approval Template for value";
    	try{
    	
		StringList strListBusSelects = new StringList(DomainConstants.SELECT_ID);
    	strListBusSelects.add(DomainConstants.SELECT_NAME);
    	StringList strListRelSelects = new StringList(DomainRelationship.SELECT_ID);
    	strListRelSelects.add("attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"]");
    	DomainObject domWorkOrder = DomainObject.newInstance(context,args[0]);
		
		String strTypeOfContract = (String)domWorkOrder.getAttributeValue(context,ATTRIBUTE_WMS_TYPE_OF_CONTRACT);
		
		StringList slApprovalReasons = new StringList();
		if(UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && "EPC".equalsIgnoreCase(strTypeOfContract)){
			String strApprovapPurposeListEPC = EnoviaResourceBundle.getProperty(context,"WMS.WorkOrder.ApprovalTemplatePurpose.EPC");
			slApprovalReasons = FrameworkUtil.split(strApprovapPurposeListEPC, ",");
		}else{
			String strApprovapPurposeListLumpSum = EnoviaResourceBundle.getProperty(context,"WMS.WorkOrder.ApprovalTemplatePurpose.Lumpsum");
			slApprovalReasons = FrameworkUtil.split(strApprovapPurposeListLumpSum, ",");
		}
		
    	Map<String,Integer> mCounter=new HashMap<String,Integer>();
    	Iterator itr = slApprovalReasons.iterator();
    	String strRange=DomainConstants.EMPTY_STRING;
			while(itr.hasNext()){
			strRange=(String)itr.next();
				if(!strRange.isEmpty()){
					mCounter.put(strRange, 0);
				}
			}
    		//now get all approval template with
		
    	MapList mlApprovalTemplates= domWorkOrder.getRelatedObjects(context, // matrix context
			    	RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE, // relationship pattern
			    	DomainConstants.TYPE_ROUTE_TEMPLATE, // type pattern // Approval Template type
			    	strListBusSelects, // object selects
			    	strListRelSelects, // relationship selects
			    	false, // to direction
			    	true, // from direction
			    	(short) 1, // recursion level
			    	DomainConstants.EMPTY_STRING, // object where clause
			    	DomainConstants.EMPTY_STRING, // relationship where clause
			    	0);
			if(mlApprovalTemplates.size()==0) {
				String strMessage = DomainConstants.EMPTY_STRING;
				for(int i=0;i<slApprovalReasons.size();i++){
					strMessage = strMessage + "\n" +String.valueOf(i+1)+" "+(String)slApprovalReasons.get(i);
					
				}
        	   emxContextUtil_mxJPO.mqlNotice(context, "No Approval Templates are added,Please add approval Templates for below purpose"+strMessage );
        	   return 1;
			}else {	
		    	Iterator<Map> itrApprovalTemplate = mlApprovalTemplates.iterator();
		    	String strPurpose=DomainConstants.EMPTY_STRING;
		    	String strName=DomainConstants.EMPTY_STRING;
		    	while(itrApprovalTemplate.hasNext()){
			    	Map m=itrApprovalTemplate.next();
			    	strPurpose = (String)m.get("attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"]");
			    	strName = (String)m.get(DomainConstants.SELECT_NAME);
			    	if(strPurpose.isEmpty()){
						emxContextUtil_mxJPO.mqlNotice(context, STR_ERROR_MSG_EMPTY+" "+strName);
						return 1; 
			    	}
			    	// Start counting...
			    	int iCount = mCounter.get(strPurpose);
			    	mCounter.put(strPurpose, iCount+1);
			    	
		    	}
		    	java.util.Set keys = mCounter.keySet();
		    	Iterator itrKeys = keys.iterator();
		    	while(itrKeys.hasNext()){
				    	strName=(String)itrKeys.next();
				    	int i =mCounter.get(strName);
				    	if(i==0){
				    	     emxContextUtil_mxJPO.mqlNotice(context, "Approval Template with Purpose "+strName+" is not added");
				    	return 1; 
				    	}
		       	}
		    	
		    	/*  Please check the SDP is connected  added for WorkOrder Vendor Document Management */
		    	
		    	//String strIsSDPConnected = domWorkOrder.getInfo(context, "from["+RELATIONSHIP_WMS_WORK_ORDER_SDP+"]");
		    	//if(strIsSDPConnected.equalsIgnoreCase("False")) {
		    	//	 ${CLASS:emxContextUtil}.mqlNotice(context, "Contractor document list is not defined,Please add Contractor document list" );
		    	//	 return 1; 
		     	//}
     }
    	}catch(Exception e){
    		throw e;
    	}
    	return 0;
    }
    /**
	 * This program is to exclude already connected Line Item Templates.
	 * @param context
	 * @param args
	 * @return 
	 * @throws Exception
	 */
	@com.matrixone.apps.framework.ui.ExcludeOIDProgramCallable
	public StringList excludeConnectedApprovalTemplates(Context context, String[] args) throws Exception{
	
		StringList excludeOids = new StringList();
		try {
			String whereExpression = "to[" +RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE + "].from.id!=''";
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			MapList rATList = DomainObject.findObjects(context, DomainConstants.TYPE_ROUTE_TEMPLATE, DomainConstants.QUERY_WILDCARD, DomainConstants.QUERY_WILDCARD, null,
					null, whereExpression, true, new StringList(DomainConstants.SELECT_ID));
			if(rATList!=null) {
				for(Object info: rATList) {
					excludeOids.add((String)((Map)info).get(DomainConstants.SELECT_ID));
				}
			}
		}catch (Exception ex) {
			throw ex;// TODO: handle exception
		}
		return excludeOids;
	}
	/**
	 * This Load Apprval Template table content.
	 * @param context
	 * @param args
	 * @return 
	 * @throws Exception
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getApprovalTemplate(Context context, String[] args) throws Exception {
		MapList mlApprovalTemplate=new MapList();
		try {
			StringList strListBusSelects     = new StringList(1);
            strListBusSelects.add(DomainConstants.SELECT_ID);
            strListBusSelects.add(DomainConstants.SELECT_NAME);
           
            StringList strListRelSelects     = new StringList(1);
            strListRelSelects.add(DomainRelationship.SELECT_ID);
            strListRelSelects.add("attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"]");
			Map mInputMap = (Map) JPO.unpackArgs(args);
			String strObjId = (String)mInputMap.get("objectId");
			DomainObject domObjWO = DomainObject.newInstance(context, strObjId);
			ContextUtil.pushContext(context);
			mlApprovalTemplate=domObjWO.getRelatedObjects(context, // matrix context
					 RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE, // relationship pattern
                     DomainConstants.TYPE_ROUTE_TEMPLATE, // type pattern
                    strListBusSelects, // object selects
                    strListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 1, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
			ContextUtil.popContext(context);
		}catch (Exception ex) {
			throw ex;// TODO: handle exception
		}
		return mlApprovalTemplate;
	}

/** Trigger method on Workorder create promote action, stamps ownership of Person's organization connected to WorkOrder
 * so only WorkOrder only those Work Order can be visible to it 
 * mod bus 20220.13561.10676.36117 add ownership "RG Constructions" "Common Space";
 * @param context
 * @param args
 * @throws Exception
 */
	

public int triggerUpdateObjectOwnership(Context context,String[] args) throws Exception{
	
	try {
	
	
	    String strWOId = args[0];
	    DomainObject domWO=DomainObject.newInstance(context, strWOId);
	    MQLCommand mql=new MQLCommand();
	
	    String strSupplierOrg = domWO.getInfo(context, "to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.name");
		if(UIUtil.isNotNullAndNotEmpty(strSupplierOrg)){
			 ContextUtil.pushContext(context, "User Agent",DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
			 mql.executeCommand(context, "mod bus $1 add ownership $2 $3", strWOId, strSupplierOrg,"GLOBAL");
			ContextUtil.popContext(context);
		}
	 
	  }catch(Exception e) {
		  ContextUtil.popContext(context);
		 e.printStackTrace();
	 }
	   return 0;
 }

    /**
     * Access function for formType of Work Order set Non editableto make it editable
     * @param context The Matrix Context object
     * @param args holds the arguments:     
     * @throws Exception if the operation fails
     */ 
	@com.matrixone.apps.framework.ui.ProgramCallable 
    public String setPercentageField(Context context, String[] args)throws Exception 
    {
        StringBuffer strPAC = new StringBuffer();
        try
        {  
			StringList detailsList = new StringList();
			detailsList.addElement("attribute["+ATTRIBUTE_WMSECVIBM_VALUE+"]");
			detailsList.addElement("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sWorkOrderOid = (String) paramMap.get("objectId");
			if(sWorkOrderOid != null && !"".equals(sWorkOrderOid)){
				DomainObject domObj = DomainObject.newInstance(context, sWorkOrderOid);			
				Map objectMap = (Map)domObj.getInfo(context,detailsList);
				String sValueOfContract = (String)objectMap.get("attribute["+ATTRIBUTE_WMS_VALUE_OF_CONTRACT+"]");
				String sWMSECVIBM = (String)objectMap.get("attribute["+ATTRIBUTE_WMSECVIBM_VALUE+"]");
				if(UIUtil.isNotNullAndNotEmpty(sWMSECVIBM) && "0.0".equals(sWMSECVIBM)==false){
					
					double dValueOfContract = Double.parseDouble(sValueOfContract);
					double dWMSECVIBM = Double.parseDouble(sWMSECVIBM);

					double dFinalDiscount = (dWMSECVIBM - dValueOfContract) / (dWMSECVIBM) * 100;
					
					DecimalFormat df = new DecimalFormat("#.##");      
					dFinalDiscount = Double.valueOf(df.format(dFinalDiscount));
					//String sFinalValue = Double.toString(Math.abs(dFinalDiscount));
					String sFinalValue = Double.toString(dFinalDiscount * -1);
					strPAC.append(sFinalValue); 
				}else{
					strPAC.append(DomainConstants.EMPTY_STRING); 
				}
           }
        }
        catch(Exception exception) 
        {
            exception.printStackTrace();
            throw exception;
        } 	
        return strPAC.toString();
    }
	
	
  public Vector getWorkOrdersForProjects(Context context, String[] args) throws Exception 
    {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            int intSize = objectList.size();
            Vector vColumnValues = new Vector(intSize);
			Map mTemp = null;
			Map mTempWO = null;
			String strProjectId = DomainConstants.EMPTY_STRING;
			String strWOId = DomainConstants.EMPTY_STRING;
			String strWOName = DomainConstants.EMPTY_STRING;
			String strColumnValue = DomainConstants.EMPTY_STRING;
			DomainObject doProject = null;
			for(int i=0; i<intSize;i++){
				strColumnValue = DomainConstants.EMPTY_STRING;
				mTemp = (Map)objectList.get(i);
				strProjectId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strProjectId)){
					doProject = new DomainObject(strProjectId);
					MapList mlWOList = getWorkOrders(context,doProject);					
					int intWOSize = mlWOList.size();
					if(intWOSize>0){
						StringBuilder strUrl = new StringBuilder();
						for(int j=0;j<intWOSize;j++){
							mTempWO = (Map)mlWOList.get(j);
							strWOId = (String)mTempWO.get(DomainObject.SELECT_ID);
							strWOName = (String)mTempWO.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_TITLE+"].value");
							String strLink = "../common/emxTree.jsp?objectId="+strWOId;
							strUrl.append("<a href=\"javascript:showModalDialog('"+strLink+"','600','400','false');\" >");            
							strUrl.append(strWOName);
							strUrl.append("</a>");
							strUrl.append("<br/>");
						}						
						vColumnValues.add(strUrl.toString());
					}else{
						vColumnValues.add(DomainConstants.EMPTY_STRING);
					}
					
				}else{
					vColumnValues.add(DomainConstants.EMPTY_STRING);
				}
			}
            return vColumnValues;
        }
        catch (Exception e) {
            throw e;
        }
    }
 
  public StringList getWorkOrderContractors(Context context, String[] args) throws Exception 
    {
        try {
            Map programMap = (Map) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            int intSize = objectList.size();
            StringList slReturnList = new StringList();
			Map mTemp = null;
			Map mTempWO = null;
			String strProjectId = DomainConstants.EMPTY_STRING;
			String strWOId = DomainConstants.EMPTY_STRING;
			String strWOName = DomainConstants.EMPTY_STRING;
			String strColumnValue = DomainConstants.EMPTY_STRING;
			DomainObject doProject = null;
			DomainObject doWO= null;
			for(int i=0; i<intSize;i++){
				strColumnValue = DomainConstants.EMPTY_STRING;
				mTemp = (Map)objectList.get(i);
				strProjectId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strProjectId)){
					doProject = new DomainObject(strProjectId);
					MapList mlWOList = getWorkOrders(context,doProject);					
					int intWOSize = mlWOList.size();
					if(intWOSize>0){
						String strContractors = DomainConstants.EMPTY_STRING;
						StringBuilder strUrl = new StringBuilder();
						for(int j=0;j<intWOSize;j++){
							mTempWO = (Map)mlWOList.get(j);
							strWOId = (String)mTempWO.get(DomainObject.SELECT_ID);
							doWO = new DomainObject(strWOId);
							String strContractorName = (String)doWO.getInfo(context,"to["+RELATIONSHIP_WMS_WORK_ORDER_CONTRACTOR+"].from.name");
							if(UIUtil.isNullOrEmpty(strContractors)){
								strContractors = strContractorName;
							}else{
								strContractors = strContractors +"<br/>"+strContractorName;
							}
						}	
						slReturnList.add(strContractors);						
					}else{
						slReturnList.add(DomainConstants.EMPTY_STRING);
					}
					
				}else{
					slReturnList.add(DomainConstants.EMPTY_STRING);
				}
			}
            return slReturnList;
        }
        catch (Exception e) {
            throw e;
        }
    }
	

	 public StringList getWorkOrderContractPerson(Context context, String[] args) throws Exception 
    {
         try {
            Map programMap = (Map) JPO.unpackArgs(args);
            
            HashMap columnMap = (HashMap) programMap.get("columnMap");
	    	Map settings = (Map) columnMap.get("settings");
	    	String sColumnKey = (String) settings.get("ROLE");
            MapList objectList = (MapList) programMap.get("objectList");
            int intSize = objectList.size();
            StringList slReturnList = new StringList();
			Map mTemp = null;
			Map mTempWO = null;
			String strProjectId = DomainConstants.EMPTY_STRING;
			String strWOId = DomainConstants.EMPTY_STRING;
			String strWOName = DomainConstants.EMPTY_STRING;
			String strColumnValue = DomainConstants.EMPTY_STRING;
			DomainObject doProject = null;
			for(int i=0; i<intSize;i++){
				strColumnValue = DomainConstants.EMPTY_STRING;
				mTemp = (Map)objectList.get(i);
				strProjectId = (String)mTemp.get(DomainObject.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strProjectId)){
					doProject = new DomainObject(strProjectId);
					MapList mlWOList = getWorkOrders(context,doProject);					
					int intWOSize = mlWOList.size();
					if(intWOSize>0){
						StringBuilder strUrl = new StringBuilder();
						String strContractors = DomainConstants.EMPTY_STRING;
						for(int j=0;j<intWOSize;j++){

							mTempWO = (Map)mlWOList.get(j);
							strWOId = (String)mTempWO.get(DomainObject.SELECT_ID);
							String strContractorPersonName = MqlUtil.mqlCommand(context, "print bus $1 select $2 $3",strWOId,"to["+RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE+"|attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value == '"+sColumnKey+"'].from.name", "dump");
							if(UIUtil.isNullOrEmpty(strContractorPersonName)){
								strContractorPersonName = "Not Assigned";
							}							
							if(UIUtil.isNullOrEmpty(strContractors)){
								strContractors = strContractorPersonName;
							}else{
								strContractors = strContractors +"<br/>"+strContractorPersonName;
							}
						}
						slReturnList.add(strContractors);								
					}else{
						slReturnList.add(DomainConstants.EMPTY_STRING);
					}
					
				}else{
					slReturnList.add(DomainConstants.EMPTY_STRING);
				}
			}
            return slReturnList;
        }
        catch (Exception e) {
            throw e;
        }
    }
 
  public void updatePercentageField(Context context, String[] args)throws Exception 
    {
		//Do nothing
	}

	
public int updateWorkOrderMemeberAttribute(Context context,String[] args) throws Exception{
	boolean isContextPushed = false;
	try {
			String strPersonId = args[0];
			String strRelId = args[1];
			ContextUtil.pushContext(context);
			isContextPushed = true;
			DomainObject doPerson = new DomainObject(strPersonId);
			String strPersonRole = (String)doPerson.getAttributeValue(context,ATTRIBUTE_HOST_ROLE);
			if(UIUtil.isNotNullAndNotEmpty(strPersonRole)){
				DomainRelationship doRel = new DomainRelationship(strRelId);
				doRel.setAttributeValue(context, ATTRIBUTE_WMS_WORK_ORDER_ROLE, strPersonRole);
			}		
		 
		}catch(Exception e) {
			  
			 e.printStackTrace();
		}
		finally{
			if(isContextPushed){
				ContextUtil.popContext(context);
			}
		}
		   return 0;
	}	

	public int checkForSupplier(Context context, String[] args) throws Exception 
    {
        try {
			boolean isRoleMissing = false;
            int iResult = 0;
            String sObjectId = args[0];
            if (UIUtil.isNotNullAndNotEmpty(sObjectId)) // check for work order object only
            {
				String strOrgRoles  = EnoviaResourceBundle.getProperty(context,"WMS.MandatoryAccess.WorkOrder.Host");
				String strPMCRoles  = EnoviaResourceBundle.getProperty(context,"WMS.MandatoryAccess.WorkOrder.PMC");
				String strContractorRoles  = EnoviaResourceBundle.getProperty(context,"WMS.MandatoryAccess.WorkOrder.Contractor");
			
				StringList slOrgMissingRoleList = FrameworkUtil.split(strOrgRoles,",");
				StringList slPMCMissingRoleList = FrameworkUtil.split(strPMCRoles,",");
				StringList slContractorMissingRoleList = FrameworkUtil.split(strContractorRoles,",");
				
				DomainObject doWO = new DomainObject(sObjectId);
				
				StringList strListBusSelects = new StringList();
				strListBusSelects.add(DomainObject.SELECT_ID);
				strListBusSelects.add("to["+DomainRelationship.RELATIONSHIP_MEMBER+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_COMPANY+"].value");
							
				StringList strListRelSelects = new StringList();
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				strListRelSelects.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"].value");
				
				
				MapList mlMember = doWO.getRelatedObjects(context, // matrix context
                    RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE, // relationship pattern
                    DomainObject.TYPE_PERSON, //TYPE_WMSWorkorder, // type pattern
                    strListBusSelects, // object selects
                    strListRelSelects, // relationship selects
                    true, // to direction
                    false, // from direction
                    (short) 1, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
				
				Map mPersonMap = null;
				String strWorkOrderRole = DomainConstants.EMPTY_STRING;
				Object oTypeOfCompany;
				StringList slWorkOrderRoleList = null;
				StringList slTypeOfCompanyList = null;
				
				for(int i=0;i<mlMember.size();i++){
					slTypeOfCompanyList = new StringList();
					slWorkOrderRoleList = new StringList();
					mPersonMap = (Map)mlMember.get(i);
					strWorkOrderRole = (String)mPersonMap.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ACCESS+"].value");
					oTypeOfCompany = (Object)mPersonMap.get("to["+DomainRelationship.RELATIONSHIP_MEMBER+"].from.attribute["+ATTRIBUTE_WMS_TYPE_OF_COMPANY+"].value");
					
					if(oTypeOfCompany != null){
						if(oTypeOfCompany instanceof String){
							StringList slCompanyTypes = FrameworkUtil.split((String)oTypeOfCompany,",");
							slTypeOfCompanyList.addAll(slCompanyTypes);
						}else if(oTypeOfCompany instanceof StringList){
							slTypeOfCompanyList = (StringList)oTypeOfCompany;
						}
					}
					
					if(UIUtil.isNotNullAndNotEmpty(strWorkOrderRole)){
						slWorkOrderRoleList = FrameworkUtil.split(strWorkOrderRole,",");
					}
					strWorkOrderRole = DomainConstants.EMPTY_STRING;
					for(int j=0;j<slWorkOrderRoleList.size();j++){
						strWorkOrderRole = (String)slWorkOrderRoleList.get(j);
						if(slTypeOfCompanyList.size()>0 && slTypeOfCompanyList.contains("PMC")){
							if(slPMCMissingRoleList.contains(strWorkOrderRole) == true){
								slPMCMissingRoleList.remove(strWorkOrderRole);
							}
						}else if(slTypeOfCompanyList.size()>0 && slTypeOfCompanyList.contains("Contractor")){
							if(slContractorMissingRoleList.contains(strWorkOrderRole) == true){
								slContractorMissingRoleList.remove(strWorkOrderRole);
							}
						}else{							
							if(slOrgMissingRoleList.contains(strWorkOrderRole) == true){
								slOrgMissingRoleList.remove(strWorkOrderRole);
							}
						}
					}
				}
				
				StringBuilder sbOrg = new StringBuilder();
				
				for(int i = 0;i<slOrgMissingRoleList.size();i++){
					if(i==0){
						sbOrg.append("\n");
						sbOrg.append(EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.OrgRolesMissing"));
						sbOrg.append("\n");
					}					
					sbOrg.append(i+1);
					sbOrg.append(".");
					sbOrg.append((String)slOrgMissingRoleList.get(i));
					sbOrg.append("\n");
					isRoleMissing = true;
				}
				
				for(int i = 0;i<slPMCMissingRoleList.size();i++){
					if(i==0){
						sbOrg.append("\n");
						sbOrg.append(EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.PMCRolesMissing"));
						sbOrg.append("\n");
					}					
					sbOrg.append(i+1);
					sbOrg.append(".");
					sbOrg.append((String)slPMCMissingRoleList.get(i));
					sbOrg.append("\n");
					isRoleMissing = true;
				}
				
				for(int i = 0;i<slContractorMissingRoleList.size();i++){
					if(i==0){
						sbOrg.append("\n");
						sbOrg.append(EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Message.ContractorRolesMissing"));
						sbOrg.append("\n");
					}					
					sbOrg.append(i+1);
					sbOrg.append(".");
					sbOrg.append((String)slContractorMissingRoleList.get(i));
					sbOrg.append("\n");
					isRoleMissing = true;
				}
				if(isRoleMissing){
					String strMessage =  EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.WorkOrder.NoSupplierConnected");
					emxContextUtil_mxJPO.mqlNotice(context, strMessage+"\n"+sbOrg.toString());
					iResult = 1;
				}
            }
            return iResult;
        }
        catch (Exception e) {
			e.printStackTrace();
            throw e;
        }
    }

public void updateWorkOrderRole(Context context,String[] args) throws Exception{
	
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		HashMap hmRequestMap = (HashMap)programMap.get("paramMap");
		String strRelId = (String)hmRequestMap.get("relId");
		String strNewValue = (String)hmRequestMap.get("New Value");
		
		if(UIUtil.isNotNullAndNotEmpty(strRelId)){
			DomainRelationship doRel = new DomainRelationship(strRelId);
			doRel.setAttributeValue(context, ATTRIBUTE_WMS_WORK_ORDER_ROLE, strNewValue);
		}
		 
		}catch(Exception e) {
			 e.printStackTrace();
		}
	}	
	
public Vector getContractorDetails(Context context,String[] args) throws Exception
     {
    	Vector colVector = new Vector();
	     try { 
	     	 
	    	 String strURL="../wms/wmsWorkOrderContractorPMCDetails.jsp?mode=Contractor";
	    	 HashMap programMap         = (HashMap) JPO.unpackArgs(args);
			 HashMap paramList = (HashMap) programMap.get("paramList");
	    	 MapList objectList  = (MapList) programMap.get("objectList");
	    	 StringBuilder sb= null;
	    	 Iterator<Map> itr = objectList.iterator();
			 String strType = DomainConstants.EMPTY_STRING;
			 String strId = DomainConstants.EMPTY_STRING;
	    	 while(itr.hasNext()) {
				Map m = itr.next();
				strType = (String)m.get(DomainObject.SELECT_TYPE);
				strId = (String)m.get(DomainObject.SELECT_ID);
				sb=new StringBuilder();
				sb.append("<a href=\"javascript:showModalDialog('"+strURL+"&amp;objectId="+strId+"','600','400','false');\" >");
				sb.append("<img border='0' title='Contractor Details' src='../common/images/iconNewWindow.gif' height='15px' name='Contractor Details' id='Contractor Details' alt='Contractor Details' onmouseover='openResponsiblePersons()'/>");
				sb.append("</a>");
				sb.append("<script>");
				sb.append("function openResponsiblePersons(){");
				sb.append("javascript:showModalDialog('"+strURL+"&amp;objectId="+strId+"','600','400','false');");
				sb.append("}");
				sb.append("</script>");
				colVector.add(sb.toString());
	    	 }
	    	 
	    }catch(Exception e) {
	    	e.printStackTrace();
	    } 
	  return colVector;
     }
	 
public Vector getPMCDetails(Context context,String[] args) throws Exception
     {
    	Vector colVector = new Vector();
	     try { 
	     	 
	    	 String strURL="../wms/wmsWorkOrderContractorPMCDetails.jsp?mode=PMC";
	    	 HashMap programMap         = (HashMap) JPO.unpackArgs(args);
			 HashMap paramList = (HashMap) programMap.get("paramList");
	    	 MapList objectList  = (MapList) programMap.get("objectList");
	    	 StringBuilder sb= null;
	    	 Iterator<Map> itr = objectList.iterator();
			 String strType = DomainConstants.EMPTY_STRING;
			 String strId = DomainConstants.EMPTY_STRING;
	    	 while(itr.hasNext()) {
				Map m = itr.next();
				strId = (String)m.get(DomainObject.SELECT_ID);
				sb=new StringBuilder();
				sb.append("<a href=\"javascript:showModalDialog('"+strURL+"&amp;objectId="+strId+"','600','400','false');\" >");            
				sb.append("<img border='0' title='PMC Details' src='../common/images/iconNewWindow.gif' height='15px' name='PMC Details' id='PMC Details' alt='PMC Details' onmouseover='openResponsiblePersons()'/>");
				sb.append("</a>");
				sb.append("<script>");
				sb.append("function openResponsiblePersons(){");
				sb.append("javascript:showModalDialog('"+strURL+"&amp;objectId="+strId+"','600','400','false');");
				sb.append("}");
				sb.append("</script>");
				colVector.add(sb.toString());
	    	 }
	    	 
	    }catch(Exception e) {
	    	e.printStackTrace();
	    } 
	  return colVector;
     }

	
//Added by Ravi 10 sept 2018 BOQ toolbar changes : 	


@com.matrixone.apps.framework.ui.IncludeOIDProgramCallable

public StringList getRelatedTenderBOQs(Context context,String[] args) throws Exception{
	StringList slIncludeIds = new StringList();
	try {
	    Map mInput = (Map) JPO.unpackArgs(args);
	    String strWorkOrderId=(String) mInput.get("objectId");
	    DomainObject domWo=DomainObject.newInstance(context,strWorkOrderId);
	    
	    StringList strListBusSelects     = new StringList(3);
        strListBusSelects.add(DomainConstants.SELECT_ID);
        strListBusSelects.add(DomainConstants.SELECT_NAME);
		strListBusSelects.add("attribute["+ATTRIBUTE_WMS_MBE_ITEM_TYPE+"].value");

		StringList strListRelSelects = new StringList(1);
        strListRelSelects.add(DomainRelationship.SELECT_ID);
        Pattern patternType = new Pattern(TYPE_WMS_MEASUREMENT_TASK);
        patternType.addPattern(TYPE_WMS_SEGMENT);
        patternType.addPattern(TYPE_WMS_MEASUREMENT_BOOK);
        Pattern patternRel = new Pattern(RELATIONSHIP_BILL_OF_QUANTITY);     
            MapList mapListObjects = domWo.getRelatedObjects(context,
            	                     	                    RELATIONSHIP_BILL_OF_QUANTITY,                         // relationship pattern
															patternType.getPattern(),                                    // object pattern
															false,                                                        // to direction
															true,                                                       // from direction
															(short)3,                                                      // recursion level
															strListBusSelects,                                                 // object selects
															null,                                                         // relationship selects
															DomainConstants.EMPTY_STRING,                                // object where clause
															DomainConstants.EMPTY_STRING,                                // relationship where clause
															(short)0,                                                      // No expand limit
															DomainConstants.EMPTY_STRING,                                // postRelPattern
															TYPE_WMS_MEASUREMENT_TASK, // postTypePattern
															null); 
	          slIncludeIds= WMSUtil_mxJPO.convertToStringList(mapListObjects, DomainConstants.SELECT_ID);
        	 
	    return slIncludeIds;	
		
	  }catch(Exception e) {
		e.printStackTrace();
		throw e;
	}
	}
	
	
	public void updateApprovalTemplatePurpose(Context context,String[] args) throws Exception{
	
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		HashMap hmRequestMap = (HashMap)programMap.get("paramMap");
		String strRelId = (String)hmRequestMap.get("relId");
		String strNewValue = (String)hmRequestMap.get("New Value");
		
		if(UIUtil.isNotNullAndNotEmpty(strRelId)){
			DomainRelationship doRel = new DomainRelationship(strRelId);
			ContextUtil.pushContext(context);
			doRel.setAttributeValue(context, ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE, strNewValue);
			ContextUtil.popContext(context);
		}
		 
		}catch(Exception e) {
			 e.printStackTrace();
		}
	}
	
	
public String getContractorDetailsForWO(Context context,String[] args) throws Exception
{
	String strReturn = DomainConstants.EMPTY_STRING;
	try { 
		String strURL="../wms/wmsWorkOrderContractorPMCDetails.jsp?mode=Contractor";
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String sWorkOrderOid = (String) paramMap.get("objectId");
		
		DomainObject doBus = new DomainObject(sWorkOrderOid);
		String strRelName = PropertyUtil.getSchemaProperty("relationship_PRBWorkorderContractor");
		StringList slCompanySelect = new StringList();
		slCompanySelect.add("to["+strRelName+"].from.id");
		Map mCompanyDetails = (Map)doBus.getInfo(context,slCompanySelect);
		
		String strCompanyId = (String)mCompanyDetails.get("to["+strRelName+"].from.id");
		
		StringList slObjSelect = new StringList();
		slObjSelect.add(DomainObject.SELECT_ID);
		slObjSelect.add(DomainObject.SELECT_NAME);
		slObjSelect.add("attribute[First Name].value");
		slObjSelect.add("attribute[Last Name].value");
		slObjSelect.add("attribute[Email Address].value");
		slObjSelect.add("attribute[Cell Phone Number].value");
		
		StringList slRelSelect = new StringList();
		slRelSelect.add(DomainRelationship.SELECT_ID);
		slRelSelect.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value");
		
		String strObjWhere = "to["+DomainRelationship.RELATIONSHIP_MEMBER+"].from.id=="+strCompanyId;
		
		
		MapList mlMemberList = 	doBus.getRelatedObjects(context, // matrix context
										RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE,                                     // relationship pattern
										DomainConstants.TYPE_PERSON,    
										slObjSelect, // object selects
										slRelSelect, // relationship selects
										true, // to direction
										false, // from direction
										(short) 1, // recursion level
										strObjWhere, // object where clause
										DomainConstants.EMPTY_STRING);
										
		if(mlMemberList.size()==1){
			Map mTemp = (Map)mlMemberList.get(0);
			String strUser = (String)mTemp.get("attribute[First Name].value") + " " +(String)mTemp.get("attribute[Last Name].value");
			strReturn = strUser;
		}
		else{
			StringBuilder sb= new StringBuilder();
			sb.append("<a href=\"javascript:showModalDialog('"+strURL+"&amp;objectId="+sWorkOrderOid+"','600','400','false');\" >");            
			sb.append("<img border='0' title='Contractor Details' src='../common/images/iconNewWindow.gif' height='15px' name='Contractor Details' id='Contractor Details' alt='Contractor Details' onmouseover='openResponsibleContractorPersons()'/>");
			sb.append("</a>");
			sb.append("<script>");
			sb.append("function openResponsibleContractorPersons(){");
			sb.append("javascript:showModalDialog('"+strURL+"&objectId="+sWorkOrderOid+"','600','400','false');");
			sb.append("}");
			sb.append("</script>");
			strReturn = sb.toString();
		
		}

	}catch(Exception e) {
		e.printStackTrace();
	} 
	return strReturn;
}
	 
public String getPMCDetailsForWO(Context context,String[] args) throws Exception
{
	String strReturn = DomainConstants.EMPTY_STRING;
	try { 
		String strURL="../wms/wmsWorkOrderContractorPMCDetails.jsp?mode=PMC";
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);

		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String sWorkOrderOid = (String) paramMap.get("objectId");
		DomainObject doBus = new DomainObject(sWorkOrderOid);
		String strRelName = PropertyUtil.getSchemaProperty("relationship_PRBWorkOrderPMCConsultant");
		StringList slCompanySelect = new StringList();
		slCompanySelect.add("to["+strRelName+"].from.id");
		Map mCompanyDetails = (Map)doBus.getInfo(context,slCompanySelect);
		
		String strCompanyId = (String)mCompanyDetails.get("to["+strRelName+"].from.id");
		
		StringList slObjSelect = new StringList();
		slObjSelect.add(DomainObject.SELECT_ID);
		slObjSelect.add(DomainObject.SELECT_NAME);
		slObjSelect.add("attribute[First Name].value");
		slObjSelect.add("attribute[Last Name].value");
		slObjSelect.add("attribute[Email Address].value");
		slObjSelect.add("attribute[Cell Phone Number].value");
		
		StringList slRelSelect = new StringList();
		slRelSelect.add(DomainRelationship.SELECT_ID);
		slRelSelect.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_ROLE+"].value");
		
		String strObjWhere = "to["+DomainRelationship.RELATIONSHIP_MEMBER+"].from.id=="+strCompanyId;
		
		
		MapList mlMemberList = 	doBus.getRelatedObjects(context, // matrix context
										RELATIONSHIP_WMS_WORK_ORDER_ASSIGNEE,                                     // relationship pattern
										DomainConstants.TYPE_PERSON,    
										slObjSelect, // object selects
										slRelSelect, // relationship selects
										true, // to direction
										false, // from direction
										(short) 1, // recursion level
										strObjWhere, // object where clause
										DomainConstants.EMPTY_STRING);
		if(mlMemberList.size()==1){
			Map mTemp = (Map)mlMemberList.get(0);
			String strUser = (String)mTemp.get("attribute[First Name].value") + " " +(String)mTemp.get("attribute[Last Name].value");
			strReturn = strUser;
		}
		else{
		
			StringBuilder sb= new StringBuilder();
			sb.append("<a href=\"javascript:showModalDialog('"+strURL+"&amp;objectId="+sWorkOrderOid+"','600','400','false');\" >");            
			sb.append("<img border='0' title='PMC Details' src='../common/images/iconNewWindow.gif' height='15px' name='PMC Details' id='PMC Details' alt='PMC Details' onmouseover='openResponsiblePersons()'/>");
			sb.append("</a>");
			sb.append("<script>");
			sb.append("function openResponsiblePersons(){");
			sb.append("javascript:showModalDialog('"+strURL+"&objectId="+sWorkOrderOid+"','600','400','false');");
			sb.append("}");
			sb.append("</script>");
			
			strReturn = sb.toString();
		}

	}catch(Exception e) {
		e.printStackTrace();
	} 
	return strReturn;
}

public void updateWorkOrderAccess(Context context,String[] args) throws Exception{
	
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		HashMap hmRequestMap = (HashMap)programMap.get("paramMap");
		String strRelId = (String)hmRequestMap.get("relId");
		String strNewValue = (String)hmRequestMap.get("New Value");
		ContextUtil.pushContext(context);
		if(UIUtil.isNotNullAndNotEmpty(strRelId)){
			DomainRelationship doRel = new DomainRelationship(strRelId);
			doRel.setAttributeValue(context, ATTRIBUTE_WMS_WORK_ORDER_ACCESS, strNewValue);
		}
		 
		}catch(Exception e) {
			  
			 e.printStackTrace();
		}finally{
			ContextUtil.popContext(context);
		}
	}		

public StringList checkEditForHostUser(Context context,String args[]) throws Exception
    {
        StringList strListAccess = new StringList();;
        try
        {
            Map programMap = (HashMap) JPO.unpackArgs(args);
            MapList objectList = (MapList) programMap.get("objectList");
            Iterator<Map<String,String>> objectListIterator = objectList.iterator();
            while (objectListIterator.hasNext()) {

                Map<String,String> mapData = objectListIterator.next();
                String strHostRole = mapData.get("attribute["+ATTRIBUTE_HOST_ROLE+"]");
                if(UIUtil.isNotNullAndNotEmpty(strHostRole))
                    strListAccess.add(String.valueOf(false));
                else
                    strListAccess.add(String.valueOf(true));
            }
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
        return strListAccess;

    }

	
	
	public Boolean isECVFiledEditable (Context context, String[] args) throws Exception 
	{
		try 
		{
			HashMap programMap 			= (HashMap)JPO.unpackArgs(args);
			String strWOId 		= (String)programMap.get("objectId");
			HashMap hmSettings = (HashMap)programMap.get("SETTINGS");
			if(UIUtil.isNotNullAndNotEmpty(strWOId)){
				DomainObject doObj = new DomainObject(strWOId);
				String strTypeOfContract = (String)doObj.getAttributeValue(context,ATTRIBUTE_WMS_TYPE_OF_CONTRACT);
				if(UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && "EPC".equals(strTypeOfContract) == false){
					hmSettings.put("Editable","false");
				}else{
					hmSettings.put("Editable","true");
				}
				programMap.put("SETTINGS",hmSettings);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return true;
	}
	
	
	public void updateECVValueForWorkOrder(Context context, String[] args)throws Exception{
		try{
			String strWOId= (String)args[0];
			if(UIUtil.isNotNullAndNotEmpty(strWOId)){
				DomainObject doWO = new DomainObject(strWOId);
				
				String strTypeOfContract = (String)doWO.getAttributeValue(context,ATTRIBUTE_WMS_TYPE_OF_CONTRACT);
				
				if(UIUtil.isNotNullAndNotEmpty(strTypeOfContract) && "EPC".equals(strTypeOfContract) == false){
					StringList slObjectSelect = new StringList();
					slObjectSelect.add(DomainObject.SELECT_ID);
					slObjectSelect.add(DomainObject.SELECT_TYPE);
					slObjectSelect.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
					slObjectSelect.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
					slObjectSelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"].value");
					
					StringList slRelSelect  = new StringList();
					slRelSelect.add(DomainRelationship.SELECT_ID);
					
					String strType = TYPE_WMS_MEASUREMENT_BOOK+","+TYPE_WMS_SEGMENT+","+TYPE_WMS_MEASUREMENT_TASK;
					MapList mlMeasurementItems = doWO.getRelatedObjects(context, // matrix context
						RELATIONSHIP_BILL_OF_QUANTITY,//RELATIONSHIP_PROJECT_WO, // relationship pattern
						strType, //TYPE_WMSWorkorder, // type pattern
						slObjectSelect, // object selects
						slRelSelect, // relationship selects
						false, // to direction
						true, // from direction
						(short) 0, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
					
					Map mTempMap = null;
					String strObjType = DomainConstants.EMPTY_STRING;
					String strBOQTotalQty = DomainConstants.EMPTY_STRING;
					String strBOQRate = DomainConstants.EMPTY_STRING;
					String strBOQType = DomainConstants.EMPTY_STRING;
					double dTotalECVValue = 0;				
					
					for(int i=0;i<mlMeasurementItems.size();i++){
						mTempMap = (Map)mlMeasurementItems.get(i);
						strObjType = (String)mTempMap.get(DomainObject.SELECT_TYPE);
						strBOQType = (String)mTempMap.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"].value");
						if(TYPE_WMS_MEASUREMENT_TASK.equals(strObjType) && "Tender Items".equals(strBOQType)){
							strBOQTotalQty = (String)mTempMap.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
							strBOQRate = (String)mTempMap.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
							if(UIUtil.isNullOrEmpty(strBOQRate) || Double.valueOf(strBOQRate)==0){
								strBOQRate = "1";
							}
							dTotalECVValue = dTotalECVValue + (Double.valueOf(strBOQTotalQty) * Double.valueOf(strBOQRate));
						}					
					}
					ContextUtil.pushContext(context);
					doWO.setAttributeValue(context,ATTRIBUTE_WMSECVIBM_VALUE,String.valueOf(dTotalECVValue));
					ContextUtil.popContext(context); ///ravisetPercentageField
					//set premium and discount here for item rate contracts 
					HashMap hmProgramMap = new HashMap();
					HashMap paramMap = new HashMap();
					paramMap.put("objectId", strWOId);
					hmProgramMap.put("paramMap", paramMap);
					setPercentageField(context,JPO.packArgs(hmProgramMap));//
				}
			}		
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	
	public void updateChangeOrderValue(Context context, String[] args)throws Exception{
		try{
			String strBOQId= (String)args[0];
			if(UIUtil.isNotNullAndNotEmpty(strBOQId)){
				DomainObject doBOQ = new DomainObject(strBOQId);
				
				StringList slObjectSelect = new StringList();
				slObjectSelect.add(DomainObject.SELECT_ID);
				slObjectSelect.add(DomainObject.SELECT_TYPE);
				slObjectSelect.add("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
				slObjectSelect.add("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
				slObjectSelect.add("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"].value");
				
				Map mBOQInfo = (Map)doBOQ.getInfo(context,slObjectSelect);
				String strTypeOfBOQ = (String)mBOQInfo.get("attribute["+ATTRIBUTE_WMS_MEASUREMENT_TASK_TYPE+"].value");
				String strTotalQty = (String)mBOQInfo.get("attribute["+ATTRIBUTE_WMS_TOTAL_QUANTITY+"].value");
				String strRate = (String)mBOQInfo.get("attribute["+ATTRIBUTE_WMS_REDUCED_SOR_RATE+"].value");
				
				if(UIUtil.isNotNullAndNotEmpty(strTypeOfBOQ) && "Tender Items".equals(strTypeOfBOQ) == false){
					StringList slObjSelect = new StringList();
					slObjSelect.add(DomainObject.SELECT_ID);
					slObjSelect.add(DomainObject.SELECT_TYPE);
					slObjSelect.add("attribute["+ATTRIBUTE_WMS_CHANGE_ORDER_VALUE+"].value");
					StringList slRelSelect  = new StringList();
					slRelSelect.add(DomainRelationship.SELECT_ID);
					
					String strType = TYPE_WMS_MEASUREMENT_BOOK+","+TYPE_WMS_SEGMENT+","+TYPE_WMS_MEASUREMENT_TASK+","+TYPE_WMS_WORK_ORDER;
					MapList mlMeasurementItems = doBOQ.getRelatedObjects(context, // matrix context
						RELATIONSHIP_BILL_OF_QUANTITY,//RELATIONSHIP_PROJECT_WO, // relationship pattern
						strType, //TYPE_WMSWorkorder, // type pattern
						slObjSelect, // object selects
						slRelSelect, // relationship selects
						true, // to direction
						false, // from direction
						(short) 0, // recursion level
						DomainConstants.EMPTY_STRING, // object where clause
						DomainConstants.EMPTY_STRING, // relationship where clause
						0);
					Map mTempMap = null;
					String strObjType = DomainConstants.EMPTY_STRING;
					String strObjId = DomainConstants.EMPTY_STRING;
					String strChangeOrderValue = DomainConstants.EMPTY_STRING;
					double dChangeOrderValue = 0;				
					
					for(int i=0;i<mlMeasurementItems.size();i++){
						mTempMap = (Map)mlMeasurementItems.get(i);
						strObjType = (String)mTempMap.get(DomainObject.SELECT_TYPE);
						if(TYPE_WMS_WORK_ORDER.equals(strObjType)){
							strChangeOrderValue = (String)mTempMap.get("attribute["+ATTRIBUTE_WMS_CHANGE_ORDER_VALUE+"].value");
							if(UIUtil.isNullOrEmpty(strChangeOrderValue)){
								strChangeOrderValue = "0";
							}
							strObjId = (String)mTempMap.get(DomainObject.SELECT_ID);
							DomainObject doWO = new DomainObject(strObjId);							
							dChangeOrderValue = Double.valueOf(strChangeOrderValue) + (Double.valueOf(strTotalQty) * Double.valueOf(strRate));
							ContextUtil.pushContext(context);
							doWO.setAttributeValue(context,ATTRIBUTE_WMS_CHANGE_ORDER_VALUE,String.valueOf(dChangeOrderValue));
							ContextUtil.popContext(context);
						}					
					}
					
				}
			}		
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}

public void updateRouteTemplateOnWorkOrder(Context context, String[] arguments)throws Exception{
	boolean isContextPushed = false;
	try{
		String strRouteTemplateId = arguments[0];
		if(UIUtil.isNotNullAndNotEmpty(strRouteTemplateId)){
			ContextUtil.pushContext(context);
			isContextPushed = true;
			DomainObject doRouteTemplate = new DomainObject(strRouteTemplateId);
			String strPrevRev = (String)doRouteTemplate.getInfo(context,"previous.id");
			
			if(UIUtil.isNotNullAndNotEmpty(strPrevRev)){
				DomainObject doPrevRouteTemplate = new DomainObject(strPrevRev);
				
				StringList strListBusSelects = new StringList();
				strListBusSelects.add(DomainObject.SELECT_ID);
				
				StringList strListRelSelects = new StringList();
				strListRelSelects.add(DomainRelationship.SELECT_ID);
				strListRelSelects.add("attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"].value");
				
				
				MapList mapListWorkOrders = doPrevRouteTemplate.getRelatedObjects(context, // matrix context
                    RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE,//RELATIONSHIP_PROJECT_WO, // relationship pattern
                    TYPE_WMS_WORK_ORDER, //TYPE_WMSWorkorder, // type pattern
                    strListBusSelects, // object selects
                    strListRelSelects, // relationship selects
                    true, // to direction
                    false, // from direction
                    (short) 0, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
					
				Map mTemp = null;
				String strWOId = DomainConstants.EMPTY_STRING;
				String strOldRelId = DomainConstants.EMPTY_STRING;
				String strPurpose = DomainConstants.EMPTY_STRING;
				for(int i=0;i<mapListWorkOrders.size();i++){
					mTemp = (Map)mapListWorkOrders.get(i);
					strWOId = (String)mTemp.get(DomainObject.SELECT_ID);
					strOldRelId = (String)mTemp.get(DomainRelationship.SELECT_ID);
					strPurpose = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE+"].value");
					DomainRelationship domRel = DomainRelationship.connect(context, new DomainObject(strWOId), RELATIONSHIP_WMS_WORK_ORDER_APPROVAL_TEMPLATE, doRouteTemplate);
					domRel.setAttributeValue(context,ATTRIBUTE_WMS_APPROVAL_TEMPLATE_PURPOSE,strPurpose);
					DomainRelationship.disconnect(context, strOldRelId);
				}				
			}
			
		}		
	}catch(Exception ex){
		ex.printStackTrace();
		throw ex;
	}finally{
		if(isContextPushed){
			ContextUtil.popContext(context);
		}
	}
	
}

public String getPendingDays(Context context, String[] args)throws Exception{
	String strReturn = DomainConstants.EMPTY_STRING;
	try { 
	boolean isNegative = false;
		HashMap programMap         = (HashMap) JPO.unpackArgs(args);

		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String sWorkOrderOid = (String) paramMap.get("objectId");
		DomainObject doBus = new DomainObject(sWorkOrderOid);
			
		StringList slObjSelect = new StringList();
		slObjSelect.add(DomainObject.SELECT_ID);
		slObjSelect.add(DomainObject.SELECT_TYPE);
		slObjSelect.add("attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"].value");
		slObjSelect.add("attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"].value");
	
		Map mTemp = (Map)doBus.getInfo(context,slObjSelect);


		String strNoOfDays = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_TIME_ALLOWED+"].value");
		String strWODate = (String)mTemp.get("attribute["+ATTRIBUTE_WMS_WORK_ORDER_DATE+"].value");

		SimpleDateFormat simpleDateFormatMatrix  = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(),context.getLocale());
		Date dWODate=simpleDateFormatMatrix.parse(strWODate);	

		Date dToday = new Date();

		long lDifference = dToday.getTime() - dWODate.getTime();
		
		long lDiffDays = lDifference/(60*60*1000*24);
		
		long lDuration = Long.valueOf(strNoOfDays);
		
		long lDiff = lDuration - lDiffDays;
		
		if(lDiff < 0){
			isNegative = true;
			lDiff  = lDiff * -1;
		}
		strReturn = String.valueOf(lDiff);
		
		if(isNegative)
			strReturn = "-"+strReturn;
    
	}catch(Exception e) {
		e.printStackTrace();
	} 
	return strReturn;
	
	
}


public void updateMemberRemarks(Context context,String[] args) throws Exception{
	
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		HashMap hmRequestMap = (HashMap)programMap.get("paramMap");
		String strRelId = (String)hmRequestMap.get("relId");
		String strNewValue = (String)hmRequestMap.get("New Value");
		
		if(UIUtil.isNotNullAndNotEmpty(strRelId)){
			DomainRelationship doRel = new DomainRelationship(strRelId);
			ContextUtil.pushContext(context);
			doRel.setAttributeValue(context, "Remarks", strNewValue);
			ContextUtil.popContext(context);
		}
		 
		}catch(Exception e) {
			 e.printStackTrace();
		}
	}	

	
	public void updateRoyaltyChargeApplicable(Context context,String[] args) throws Exception{
	
	try {
		Map programMap = (Map) JPO.unpackArgs(args);
		HashMap hmRequestMap = (HashMap)programMap.get("paramMap");
		String strBOQId = (String)hmRequestMap.get("objectId");
		String strNewValue = (String)hmRequestMap.get("New Value");
		
		if(UIUtil.isNotNullAndNotEmpty(strBOQId)){
			DomainObject doBOQ = new DomainObject(strBOQId);
			ContextUtil.pushContext(context);
			doBOQ.setAttributeValue(context, ATTRIBUTE_WMS_RC_APPLICABLE, strNewValue);
			ContextUtil.popContext(context);
		}
		 
		}catch(Exception e) {
			 e.printStackTrace();
		}
	}

public StringList isBOQEditable(Context context, String[] args) throws Exception
    {
       StringList slReturnList   =    new StringList();
        try 
        {
            Map programMap              = (Map) JPO.unpackArgs(args);
            MapList objectList          = (MapList) programMap.get("objectList");
            int iObjectListSize         = objectList.size();
            Map dataMap                 = null;
            String strState = DomainConstants.EMPTY_STRING;
            for (int i = 0; i < iObjectListSize; i++) 
            {
               dataMap                = (Map) objectList.get(i);
			   strState = (String)dataMap.get(DomainObject.SELECT_CURRENT);
			   if("Active".equals(strState)){
				   slReturnList.add("false");
			   }else{
				   slReturnList.add("true");
			   }
            }
        }
        catch (Exception e) {
           
            e.printStackTrace();
            throw e;
        }
        return slReturnList;
    }
}



