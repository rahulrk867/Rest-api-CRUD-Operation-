import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import java.text.SimpleDateFormat;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.framework.ui.UIUtil;
import java.util.Iterator;
import java.util.Vector;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import java.text.SimpleDateFormat;


public class WMSObservation_mxJPO extends WMSConstants_mxJPO
{
	  private static final String TYPE_Observation = "WMSObservation";
	  
	   public WMSObservation_mxJPO (Context context, String[] args)
        throws Exception
    {
        super(context, args);
    }
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getAllObservation (Context context, String[] args) throws Exception 
    {
        try
        {     
		 
            MapList mapListObservation = new MapList();
            String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
		    if(UIUtil.isNotNullAndNotEmpty(strObjectId))
            {
                DomainObject domObjOB = DomainObject.newInstance(context, strObjectId);
                mapListObservation = getAllObservation(context, domObjOB);
			 
            }
            return mapListObservation;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }
    private MapList getAllObservation(Context context, DomainObject domObjProjectSpace)
            throws Exception {
        try
        {
            StringList strListBusSelects     = new StringList(3);
            strListBusSelects.add(DomainConstants.SELECT_ID);
            strListBusSelects.add(DomainConstants.SELECT_NAME);
			strListBusSelects.addElement("state[Response].actual");
			strListBusSelects.addElement("state[Forward].actual");
            StringList strListRelSelects     = new StringList(1);
            strListRelSelects.add(DomainRelationship.SELECT_ID);

            MapList mapListObservation = domObjProjectSpace.getRelatedObjects(context, // matrix context
                    "WMSProjectObservations",//RELATIONSHIP_PROJECT_WO, // relationship pattern
                    "WMSObservation", //TYPE_WMSWorkorder, // type pattern
                    strListBusSelects, // object selects
                    strListRelSelects, // relationship selects
                    false, // to direction
                    true, // from direction
                    (short) 0, // recursion level
                    DomainConstants.EMPTY_STRING, // object where clause
                    DomainConstants.EMPTY_STRING, // relationship where clause
                    0);
					System.out.println("-----------mapListObservation ---------"+mapListObservation);
            return mapListObservation;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            throw exception;
        }
    }


	  @com.matrixone.apps.framework.ui.ProgramCallable
	  public MapList getAllObservationDetails(Context context, String[] args)throws Exception
				{  
		  			MapList programList = null;
		  			try
		  				{
		  					StringList busSelects = new StringList();
		  					busSelects.add("id");
							busSelects.add("name");
							busSelects.add("attribute[WMSObservationheads]");
							busSelects.add("attribute[WMSObservationDate]");
		  					programList = DomainObject.findObjects(context,
							TYPE_Observation,
							"eService Production",
							null,			
							busSelects);		
		  				} 
		  			catch (Exception ex)
		  			{
		  				throw ex;
		  			}
					System.out.println("The details"+programList);
		return programList;

}
	  @com.matrixone.apps.framework.ui.CellRangeJPOCallable
		public Map getRangeObservationHead(Context context, String[] args)throws Exception
		{
			try
			{
				Map newObservationRange = new HashMap(); //map object 
				String strobservationRange = EnoviaResourceBundle.getProperty(context, "WMS.Head.Observation");
				StringList slRange = new StringList(); 
				if((UIUtil.isNotNullAndNotEmpty(strobservationRange)))//conditional statement to check is empty or not
				{
					slRange = FrameworkUtil.split(strobservationRange,",");//splitting method separated by comma 
					newObservationRange.put("field_choices", slRange);
					newObservationRange.put("field_display_choices",slRange);
				}
				return newObservationRange;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				throw e;
			}
		}
		
			public Vector getSNOColumn(Context context, String[] args) throws Exception 
			{
		try {
			Map<String,MapList> programMap = (Map) JPO.unpackArgs(args);
			MapList objectList = (MapList) programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			Iterator iterator = objectList.iterator();
			for (int i = 1; i < intSize + 1; i++) {
				vecResponse.add(String.valueOf(i));
			}

			return vecResponse;
		} catch (Exception exception) {
			exception.printStackTrace();
			throw exception;
		}
	}
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getObservationAssignees (Context context, String[] args) throws Exception 
	{
		try
		{
			
			MapList mapListAssignees = new MapList();
			String strObjectId = WMSUtil_mxJPO.getContextObjectOIDFromArgs(args);
			if(UIUtil.isNotNullAndNotEmpty(strObjectId))
			{
				DomainObject domObjOBS = DomainObject.newInstance(context, strObjectId);
                String strObservationOwner = domObjOBS.getInfo(context, DomainConstants.SELECT_OWNER);
				System.out.println("strObservationOwner"+strObservationOwner);
                mapListAssignees = getObservationAssignees(context, domObjOBS);
                Iterator iterator   = mapListAssignees.iterator();
                while (iterator.hasNext()) {
                    Map mapAssigneInfo = (Map) iterator.next();
                    String strAssignee = (String) mapAssigneInfo.get(DomainConstants.SELECT_NAME);
                    if (strObservationOwner.equalsIgnoreCase(strAssignee)) {
                        mapAssigneInfo.put("disableSelection", "true");
                    }
                }
			}
			
			return mapListAssignees;
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
			throw exception;
		}
	}
	public static MapList getObservationAssignees(Context context, DomainObject domObjOBS) throws FrameworkException
	{
		try
		{
			StringList strListBusSelects     = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			strListBusSelects.add(DomainConstants.SELECT_NAME);
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			
             MapList mapListAssignees = domObjOBS.getRelatedObjects(context, // matrix context
            		                                                 RELATIONSHIP_WMS_OBSERVATION_ASSIGNEE, // relationship pattern
																	DomainConstants.TYPE_PERSON, // type pattern
																	strListBusSelects, // object selects
																	strListRelSelects, // relationship selects
																	true, // to direction
																	false, // from direction
																	(short) 1, // recursion level
																	DomainConstants.EMPTY_STRING, // object where clause
																	DomainConstants.EMPTY_STRING, // relationship where clause
																	0);
																

			return mapListAssignees;
		}
		catch(FrameworkException frameworkException)
		{
			frameworkException.printStackTrace();
			throw frameworkException;
		}
	}
 @com.matrixone.apps.framework.ui.PostProcessCallable
    public Map connectObservationInProjects(Context context, String[] args) throws Exception {
        HashMap mapReturnMap = new HashMap();
     
        try {
            HashMap programMap              = (HashMap) JPO.unpackArgs(args);
            HashMap paramMap             = (HashMap)programMap.get("paramMap");
            HashMap requestMap           = (HashMap)programMap.get("requestMap");
            String strWOOID             = (String) paramMap.get("objectId");
            String strProjectOID     = (String) requestMap.get("parentOID");
         
            if(UIUtil.isNotNullAndNotEmpty(strProjectOID) && UIUtil.isNotNullAndNotEmpty(strWOOID))
            {
                ContextUtil.pushContext(context);
                DomainRelationship.connect(context, strProjectOID, RELATIONSHIP_WMS_PROJECT_OBSERVATIONS, strWOOID, true);
                ContextUtil.popContext(context);
				StringBuffer strBuffer = new StringBuffer();
                strBuffer.append("<mxRoot>");
                strBuffer.append("<action><![CDATA[add]]></action>");
                strBuffer.append("<data status=\"committed\">");
                strBuffer.append("<item oid=\""+strWOOID+"\" relId=\""+""+"\" pid=\""+strWOOID+"\"  direction=\"from\" />");
                strBuffer.append("</data>");
                strBuffer.append("</mxRoot>");
                mapReturnMap.put("selectedOID", strProjectOID);
                mapReturnMap.put("rows",strBuffer.toString());
                mapReturnMap.put("Insertdata",strBuffer.toString());
                mapReturnMap.put("Action","success");
            }
        } catch (Exception exception) {
         exception.printStackTrace();
            mapReturnMap.put("Action","Stop");
            mapReturnMap.put("Message",exception.getMessage());
        }
        return mapReturnMap;
    } 

public MapList getObservationFilterWise(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String strWhere = (String)programMap.get("ObservationheadWhere");
		MapList mlobservation = new MapList();
		try
		{
			DomainObject doPerson = PersonUtil.getPersonObject(context);
		StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			//strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			//slObjSelects.addElement("id");
			strListBusSelects.addElement("id");
			strListBusSelects.addElement("physicalid");
			strListBusSelects.addElement("type");
			strListBusSelects.addElement("current");
			strListBusSelects.addElement("policy");
			strListBusSelects.addElement("name");
			strListBusSelects.addElement("description");
			strListBusSelects.addElement("attribute[WMSObservationheads]");
			strListBusSelects.addElement("attribute[WMSObservationDate]");
			strListBusSelects.addElement("attribute[WMSObservationComments]");
			strListBusSelects.addElement("attribute[WMSObservationDeadlineDate]");
			strListBusSelects.addElement("state[Response].actual");
			strListBusSelects.addElement("state[Forward].actual");
			strListBusSelects.addElement("to[WMSProjectObservations].from.name");
			strListBusSelects.addElement("to[WMSProjectObservations].from.id");
			strListBusSelects.addElement("to[WMSObservationAssignee].from.name");
			strListBusSelects.addElement("originated");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlobservation = doPerson.findObjects(context, TYPE_WMSOBSERVATION, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					strWhere, // where clause
					strListBusSelects); // object selects
					System.out.println("mlobservation---"+mlobservation);
			
				/*String StrDateFormat1= " ";
				String StrDateFormat2= " ";
				String StrDateFormat3= " ";
			for (int i = 0; i < mlobservation.size(); i++) {
				Map mMap = (Map) mlobservation.get(i);
				StrDateFormat1=(String) mMap.get("attribute[WMSObservationDate]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat1);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("observationDate", (dt1.format(date))+"");
				StrDateFormat2=(String) mMap.get("attribute[WMSObservationResponseDate]");
				SimpleDateFormat dt2 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date1 = dt2.parse(StrDateFormat2);
				SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("ResponseDate", (dt21.format(date))+"");
				StrDateFormat3=(String) mMap.get("originated");
				SimpleDateFormat dt3 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date2 = dt3.parse(StrDateFormat3);
				SimpleDateFormat dt31 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("CurrentDate", (dt31.format(date))+"");
		}*/
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("mlobservation"+mlobservation);
		return mlobservation;
}
	public int checkObservationDocuments(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId);
			StringList slRefDocs = doObj.getInfoList(context, "from["+DomainConstants.RELATIONSHIP_REFERENCE_DOCUMENT+"].to.id");
			if ((slRefDocs.size() == 0)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Observation.NoRefDoc");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}	
			StringList slmember = doObj.getInfoList(context, "to["+RELATIONSHIP_WMS_OBSERVATION_ASSIGNEE+"].from.id");
			if ((slmember.size() == 0)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Observation.Member");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	public boolean getObservationMembers(Context context, String[] args) throws FrameworkException {
		String strContextId = args[0];
		String strType      = args[1];
		MapList mlobservation = new MapList();
		
		try
		{
		if(strType.equalsIgnoreCase(TYPE_WMSOBSERVATION)){
		
		DomainObject observationDomainObject = DomainObject.newInstance(context,strContextId);
		mlobservation = getObservationAssignees (context, observationDomainObject);
			String sOwner = (String) observationDomainObject.getInfo(context, "to[WMSObservationAssignee].from.name" );
				if(sOwner.equalsIgnoreCase(context.getUser())) {
					return true;
				}
				}
				}catch(Exception e) {
			e.printStackTrace();
		}
		return false;

	}

public int checkObservationResponseDocuments(Context context, String[] args)throws Exception {
		try {
			String sObjectId = args[0];
			DomainObject doObj = new DomainObject(sObjectId);
			StringList slRefDocs = doObj.getInfoList(context, "from["+RELATIONSHIP_WMS_OBSERVATION_RESPONSE_DOCUMENTS+"].to.id");
			if ((slRefDocs.size() == 0)) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.Observation.NoResDoc");
				emxContextUtil_mxJPO.mqlNotice(context,strMessage);
				return 1;
			}
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public String getAssociatedProject (Context context,String[] args)throws Exception {
		StringBuilder sb = null;
		try { 
			String strURL="../common/emxTree.jsp";
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			String sprojectName = DomainConstants.EMPTY_STRING;
			String sprojectId = DomainConstants.EMPTY_STRING;
			
			DomainObject doObject = new DomainObject(sObjectId);
			MapList sList = doObject.getRelatedObjects(context, // matrix context
												RELATIONSHIP_WMSPROJECTSOC, // relationship pattern
												TYPE_PROJECTSPACE, // type pattern
												busSelects, // object selects
												null, // relationship selects
												true, // to direction
												false, // from direction
												(short) 1, // recursion level
												null, // object where clause
												null); // relationship where clause
			System.out.println("----------" + sList);
			if (sList.size() == 1) {
				Map objMap = (Map) sList.get(0);
				sprojectId = (String) objMap.get(DomainConstants.SELECT_ID);
				sprojectName = (String) objMap.get(DomainConstants.SELECT_NAME);
			}
			
			sb = new StringBuilder();
			sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+sprojectId+"','600','400','false')\" >");            
			sb.append(sprojectName);
			sb.append("</a>");
		} catch(Exception e) {
			e.printStackTrace();
		} 
		return sb.toString();
	}
}
