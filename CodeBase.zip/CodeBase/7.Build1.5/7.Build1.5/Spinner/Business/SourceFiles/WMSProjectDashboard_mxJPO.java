import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.Date;
import java.util.Locale;
import java.text.SimpleDateFormat;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.framework.ui.ProgramCallable;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class WMSProjectDashboard_mxJPO extends WMSConstants_mxJPO {

public WMSProjectDashboard_mxJPO(Context context, String[] args) throws Exception {
		super(context, args);
	}
	@ProgramCallable
	public MapList getPreAAproject(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strprojectTypeFromURL = (String)programMap.get("ProjectType");
		String strprojectStateFromURL = (String)programMap.get("projectState");
		String strprojectYearFromURL = (String)programMap.get("ProjectYear");
		MapList mlSOC = new MapList();
		try {
			DomainObject doPerson = PersonUtil.getPersonObject(context);
			String strWhere = null;
			if(UIUtil.isNotNullAndNotEmpty(strprojectTypeFromURL) && "All".equals(strprojectTypeFromURL)==false)
			{
				if(strWhere!=null)
				{
					strWhere += " && attribute[WMSSOCProjectType].value=='"+strprojectTypeFromURL+"'";
					System.out.println("strprojectTypeFromURL"+strWhere);
				}
				else
				{
					strWhere = "attribute[WMSSOCProjectType].value=='"+strprojectTypeFromURL+"'";
					System.out.println("strprojectTypeFromURL1"+strWhere);
				}
			}
			if(UIUtil.isNotNullAndNotEmpty(strprojectStateFromURL) && "All".equals(strprojectStateFromURL)==false)
			{
				if(strWhere!=null)
				{
					strWhere += " && current=='"+strprojectStateFromURL+"'";
					System.out.println("strprojectStateFromURL"+strWhere);
				}
				else
				{
					strWhere = "current=='"+strprojectStateFromURL+"'";
					System.out.println("strprojectStateFromURL"+strWhere);
				}
			}
			if(UIUtil.isNotNullAndNotEmpty(strprojectYearFromURL) && "All".equals(strprojectYearFromURL)==false)
			{
				if(strWhere!=null)
				{
					strWhere += " && attribute[WMSSOCFinancialYear].value=='"+strprojectYearFromURL+"'";
					System.out.println("strprojectStateFromURL"+strWhere);
				}
				else
				{
					strWhere = "attribute[WMSSOCFinancialYear].value=='"+strprojectYearFromURL+"'";
					System.out.println("strprojectStateFromURL"+strWhere);
				}
			}
			String objectWhere = "revision==last && current!=Create && current!=Submit && current!=Rejected && current!=UnderExecution && current!=Delegation";
			System.out.println("The objectWhere"+objectWhere);
			String whereCondition = objectWhere + "&&" + strWhere;
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			//strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			//slObjSelects.addElement("id");
			strListBusSelects.addElement("id");
			strListBusSelects.addElement("physicalid");
			strListBusSelects.addElement("type");
			strListBusSelects.addElement("current");
			strListBusSelects.addElement("policy");
			strListBusSelects.addElement("name");
			strListBusSelects.addElement("description");
			strListBusSelects.addElement("attribute[WMSSOCProjectType]");
			strListBusSelects.addElement("attribute[WMSSOCFinancialYear]");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlSOC = doPerson.findObjects(context, TYPE_WMSSOC, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					whereCondition, // where clause
					strListBusSelects); // object selects
			
			String strCurrent = DomainConstants.EMPTY_STRING;
			for (int i = 0; i < mlSOC.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlSOC.get(i);
				mMap.put("DgnpCount", count+"");
				strCurrent = (String) mMap.get(DomainConstants.SELECT_CURRENT);
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mlSOC;
	}
	@ProgramCallable
public MapList getProjectUnderExecution(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	String strprojectTypeFromURL = (String)programMap.get("ProjectType");
		String strprojectStateFromURL = (String)programMap.get("projectState");
		String strprojectYearFromURL = (String)programMap.get("ProjectYear");
		MapList mlRelatedProjectDetails = new MapList();
		try
		{
			
		DomainObject doPerson = PersonUtil.getPersonObject(context);
		String strWhere = null;
			if(UIUtil.isNotNullAndNotEmpty(strprojectTypeFromURL) && "All".equals(strprojectTypeFromURL)==false)
			{
				if(strWhere!=null)
				{
					strWhere += " && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value=='"+strprojectTypeFromURL+"'";
					System.out.println("strprojectTypeFromURL"+strWhere);
				}
				else
				{
					strWhere = "from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value=='"+strprojectTypeFromURL+"'";
					System.out.println("strprojectTypeFromURL1"+strWhere);
				}
			}
			if(UIUtil.isNotNullAndNotEmpty(strprojectStateFromURL) && "All".equals(strprojectStateFromURL)==false)
			{
				if(strWhere!=null)
				{
					strWhere += " && from[WMSProjectSOC].to.current=='"+strprojectStateFromURL+"'";
					System.out.println("strprojectStateFromURL"+strWhere);
				}
				else
				{
					strWhere = "from[WMSProjectSOC].to.current=='"+strprojectStateFromURL+"'";
					System.out.println("strprojectStateFromURL"+strWhere);
				}
			}
			if(UIUtil.isNotNullAndNotEmpty(strprojectYearFromURL) && "All".equals(strprojectYearFromURL)==false)
			{
				if(strWhere!=null)
				{
					strWhere += " && from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value=='"+strprojectYearFromURL+"'";
					System.out.println("strprojectStateFromURL"+strWhere);
				}
				else
				{
					strWhere = "from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value=='"+strprojectYearFromURL+"'";
					System.out.println("strprojectStateFromURL"+strWhere);
				}
			}
		String strWhereCondition ="from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation";
		String whereCondition = strWhereCondition;
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
	    mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	whereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
		String strCurrent = " ";
		String StrDateFormat= " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
				{
					mMap.put("status", "UnderExecution");
				}
				else if (strCurrent.equalsIgnoreCase("Delegation"))
				{
					mMap.put("status", "Delegation");
				}
			}
			} catch (Exception e) {
			e.printStackTrace();
			}
		return mlRelatedProjectDetails;
		
	}
}