import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;
import java.util.Date;
import java.util.Locale;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.DateUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.mxType;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.framework.ui.ProgramCallable;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.program.ProgramCentralUtil;
import com.matrixone.apps.program.Task;
import com.matrixone.apps.program.fiscal.Helper;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.Pattern;
import matrix.util.StringList;

/**
 * The following class is responsible for Project Status Dashboard
 * 
 * @author PSN12
 *
 */
public class WMSProjectDashboard_mxJPO extends WMSConstants_mxJPO {

	SimpleDateFormat sdf;
	StringList slObjSelects = new StringList();

	private final static String SELECT_ATTRIBUTE_TASK_ESTIMATED_END_DATE = "attribute["
			+ DomainConstants.ATTRIBUTE_TASK_ESTIMATED_FINISH_DATE + "]";
	private final static String SELECT_FROM_SUBTASK = "from[" + DomainConstants.RELATIONSHIP_SUBTASK + "]";

	public WMSProjectDashboard_mxJPO(Context context, String[] args) throws Exception {
		super(context, args);
		String dateTimeFormat = EnoviaResourceBundle.getProperty(context, "eServiceSuites.eMatrixDateFormat");
		if (ProgramCentralUtil.isNullString(dateTimeFormat)) {
			dateTimeFormat = "MM/dd/yyyy hh:mm:ss aaa";
		}
		sdf = new SimpleDateFormat(dateTimeFormat, Locale.US);

		slObjSelects.addElement(ProgramCentralConstants.SELECT_POLICY);
		slObjSelects.addElement(DomainObject.SELECT_OWNER);
		slObjSelects.addElement(Task.SELECT_TASK_ESTIMATED_FINISH_DATE);
		slObjSelects.addElement(SELECT_FROM_SUBTASK);
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Start Date]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("attribute[Task Actual Finish Date]");
		slObjSelects.addElement("attribute[Task Actual Start Date]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("to[Project Access Key].from.from[Project Access List].to.id");
		slObjSelects.addElement("to[Project Access Key].from.from[Project Access List].to.name");
		slObjSelects.addElement("to[Issue].from.name");
		slObjSelects.addElement("to[Issue].from.id");
	}

	@ProgramCallable
	public MapList getPreAAproject(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strprojectTypeFromURL = (String) programMap.get("ProjectType");
		String strprojectStateFromURL = (String) programMap.get("projectState");
		String strprojectYearFromURL = (String) programMap.get("ProjectYear");
		MapList mlSOC = new MapList();
		try {
			DomainObject doPerson = PersonUtil.getPersonObject(context);
			String strWhere = null;
			if (UIUtil.isNotNullAndNotEmpty(strprojectTypeFromURL) && "All".equals(strprojectTypeFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSSOCProjectType].value=='" + strprojectTypeFromURL + "'";
				} else {
					strWhere = "attribute[WMSSOCProjectType].value=='" + strprojectTypeFromURL + "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strprojectStateFromURL) && "All".equals(strprojectStateFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && current=='" + strprojectStateFromURL + "'";
				} else {
					strWhere = "current=='" + strprojectStateFromURL + "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strprojectYearFromURL) && "All".equals(strprojectYearFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && attribute[WMSSOCFinancialYear].value=='" + strprojectYearFromURL + "'";
				} else {
					strWhere = "attribute[WMSSOCFinancialYear].value=='" + strprojectYearFromURL + "'";
				}
			}
			String objectWhere = "revision==last && current!=Create && current!=Submit && current!=Rejected && current!=UnderExecution && current!=Delegation";
			String whereCondition = objectWhere + "&&" + strWhere;
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			// strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			// slObjSelects.addElement("id");
			strListBusSelects.addElement("id");
			strListBusSelects.addElement("physicalid");
			strListBusSelects.addElement("type");
			strListBusSelects.addElement("current");
			strListBusSelects.addElement("policy");
			strListBusSelects.addElement("name");
			strListBusSelects.addElement("description");
			strListBusSelects.addElement("attribute[WMSSOCProjectType]");
			strListBusSelects.addElement("attribute[WMSSOCFinancialYear]");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlSOC = doPerson.findObjects(context, TYPE_WMSSOC, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					whereCondition, // where clause
					strListBusSelects); // object selects

			String strCurrent = DomainConstants.EMPTY_STRING;
			for (int i = 0; i < mlSOC.size(); i++) {
				int count = i + 1;
				Map mMap = (Map) mlSOC.get(i);
				mMap.put("DgnpCount", count + "");
				strCurrent = (String) mMap.get(DomainConstants.SELECT_CURRENT);
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				} else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				} else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				} else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				} else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mlSOC;
	}

	@ProgramCallable
	public MapList getProjectUnderExecution(Context context, String[] args) throws Exception {

		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strprojectTypeFromURL = (String) programMap.get("ProjectType");
		String strprojectStateFromURL = (String) programMap.get("projectState");
		String strprojectYearFromURL = (String) programMap.get("ProjectYear");
		MapList mlRelatedProjectDetails = new MapList();
		MapList mlReturnList = new MapList();
		try {

			DomainObject doPerson = PersonUtil.getPersonObject(context);
			String strWhere = "";
			if (UIUtil.isNotNullAndNotEmpty(strprojectTypeFromURL) && "All".equals(strprojectTypeFromURL) == false) {
				if (UIUtil.isNotNullAndNotEmpty(strWhere)) {
					strWhere += " && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value=='"
							+ strprojectTypeFromURL + "'";
				} else {
					strWhere = "from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value=='" + strprojectTypeFromURL
							+ "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strprojectStateFromURL) && "All".equals(strprojectStateFromURL) == false) {
				if (UIUtil.isNotNullAndNotEmpty(strWhere)) {
					strWhere += " && from[WMSProjectSOC].to.current=='" + strprojectStateFromURL + "'";
					//System.out.println("strWhere State"+strWhere);
				} else {
					strWhere = "from[WMSProjectSOC].to.current=='" + strprojectStateFromURL + "'";
					//System.out.println("strWhere else State"+strWhere);
				}
			}else if("All".equals(strprojectStateFromURL)){
				if(UIUtil.isNotNullAndNotEmpty(strWhere)){
					strWhere += " && (from[WMSProjectSOC].to.current=='Delegation' || from[WMSProjectSOC].to.current=='UnderExecution')";
				}else{
					strWhere = "(from[WMSProjectSOC].to.current=='Delegation' || from[WMSProjectSOC].to.current=='UnderExecution')";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strprojectYearFromURL) && "All".equals(strprojectYearFromURL) == false) {
				if (UIUtil.isNotNullAndNotEmpty(strWhere)) {
					strWhere += " && from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value=='"
							+ strprojectYearFromURL + "'";
				} else {
					strWhere = "from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value=='" + strprojectYearFromURL
							+ "'";
				}
			}
			//String strWhereCondition = "from[WMSProjectSOC].to.current!=RIC && from[WMSProjectSOC].to.current!=ListingOfProjects && from[WMSProjectSOC].to.current!=BoardProceedings && from[WMSProjectSOC].to.current!=AE && from[WMSProjectSOC].to.current!=AdminApproval";
			//String strWhereCondition = "from[WMSProjectSOC].to.current=='Delegation' || from[WMSProjectSOC].to.current=='UnderExecution'";
			//System.out.println("strWhereCondition"+strWhereCondition);
			String whereCondition = strWhere;
			StringList slObjSelects = new StringList();
			slObjSelects.addElement("id");
			slObjSelects.addElement("physicalid");
			slObjSelects.addElement("type");
			slObjSelects.addElement("current");
			slObjSelects.addElement("policy");
			slObjSelects.addElement("name");
			slObjSelects.addElement("description");
			slObjSelects.addElement("attribute[Task Estimated Duration]");
			slObjSelects.addElement("attribute[Percent Complete]");
			slObjSelects.addElement("attribute[Task Estimated Finish Date]");
			slObjSelects.addElement("from[WMSProjectSOC].to.current");
			slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
			slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
			mlRelatedProjectDetails = doPerson.getRelatedObjects(context, "Member", // String relPattern
					"Project Space", // String typePattern
					slObjSelects, null, true, false, (short) 1, whereCondition, DomainConstants.EMPTY_STRING, null,
					null, null);
			String strCurrent = " ";
			String StrDateFormat = " ";
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count = i + 1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count + "");
				StrDateFormat = (String) mMap.get("attribute[Task Estimated Finish Date]");
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date)) + "");

				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("Delegation")) {
					mMap.put("status", "Delegation");
				} else if (strCurrent.equalsIgnoreCase("UnderExecution")) {
					mMap.put("status", "UnderExecution");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	mlRelatedProjectDetails.sortStructure("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value","descending","string");
		return mlRelatedProjectDetails;

	}

	/**
	 * The following method loads all task for selected dashboard projects...
	 * 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 * @author PSN12
	 */
	@SuppressWarnings({ "unused", "unchecked" })
	public MapList getAllProjectTasks(Context context, String[] args) throws Exception {

		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strprojectTypeFromURL = (String) programMap.get("ProjectType");
		String strprojectStateFromURL = (String) programMap.get("projectState");
		String strprojectYearFromURL = (String) programMap.get("ProjectYear");
		String strMode = (String) programMap.get("ShowTask");
		MapList masterTaskList = new MapList();
		try {

			DomainObject doPerson = PersonUtil.getPersonObject(context);

			String strWhere = "from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation";

			if (UIUtil.isNotNullAndNotEmpty(strprojectTypeFromURL) && "All".equals(strprojectTypeFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value=='"
							+ strprojectTypeFromURL + "'";
				} else {
					// Potential Dead Code
					strWhere = "from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value=='" + strprojectTypeFromURL
							+ "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strprojectStateFromURL) && "All".equals(strprojectStateFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && from[WMSProjectSOC].to.current=='" + strprojectStateFromURL + "'";
				} else {
					// Potential Dead Code
					strWhere = "from[WMSProjectSOC].to.current=='" + strprojectStateFromURL + "'";
				}
			}
			if (UIUtil.isNotNullAndNotEmpty(strprojectYearFromURL) && "All".equals(strprojectYearFromURL) == false) {
				if (strWhere != null) {
					strWhere += " && from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value=='"
							+ strprojectYearFromURL + "'";
				} else {
					// Potential Dead Code
					strWhere = "from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value=='" + strprojectYearFromURL
							+ "'";
				}
			}

			String whereCondition = strWhere;

			// TODO Comment below line in Production
			whereCondition = "";

			Pattern relPattern = new Pattern("Subtask");
			Pattern typePattern = new Pattern("Task");
			typePattern.addPattern("Milestone");
			typePattern.addPattern("Phase");
			typePattern.addPattern("Gate");

			String objectWhere = "current!=Complete";
			String strEstimatedFinishDate;
			String strActualFinishDate;
			String strActualStartDate;
			String strPercentComplete;
			String strIssueId;
			long slipDays;
			Map taskMap;

			if (strMode.equalsIgnoreCase("Missing Logs")) {
				getMissingLogTasks(context, masterTaskList, doPerson, whereCondition, relPattern, typePattern,
						objectWhere);

				// TODO Comment below line in Production
				masterTaskList = new MapList();

			} else if (!strMode.equalsIgnoreCase("All")) {
				if (strMode.equalsIgnoreCase("Next 30 Days")) {
					strMode = "Soon";
				}
				MapList returnList = getPendingTasks(context, strMode);
				Iterator taskListitr = returnList.iterator();
				while (taskListitr.hasNext()) {
					taskMap = (Map) taskListitr.next();
					strEstimatedFinishDate = (String) taskMap.get("attribute[Task Estimated Finish Date]");
					strPercentComplete = (String) taskMap.get("attribute[Percent Complete]");
					strActualFinishDate = (String) taskMap.get("attribute[Task Actual Finish Date]");
					strActualStartDate = (String) taskMap.get("attribute[Task Actual Start Date]");

					clearBlankIssues(taskMap);

					slipDays = getSlipdays(context, strEstimatedFinishDate);
					taskMap.put("slipDays", String.valueOf(slipDays));
					taskMap.put("taskIcon", getTaskIcon(context, strPercentComplete, strEstimatedFinishDate,
							strActualFinishDate, strActualStartDate));
				}

				return returnList;
			} else {
				getAllPendingTasks(context, masterTaskList, doPerson, whereCondition, relPattern, typePattern,
						objectWhere);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return masterTaskList;

	}

	/**
	 * The following method loads ALL pending tasks for context owner or PM
	 * 
	 * @param context
	 * @param masterTaskList
	 * @param doPerson
	 * @param whereCondition
	 * @param relPattern
	 * @param typePattern
	 * @param objectWhere
	 * @throws FrameworkException
	 * @throws Exception
	 * @author PSN12
	 */
	@SuppressWarnings({ "deprecation", "unchecked" })
	private void getAllPendingTasks(Context context, MapList masterTaskList, DomainObject doPerson,
			String whereCondition, Pattern relPattern, Pattern typePattern, String objectWhere)
			throws FrameworkException, Exception {

		MapList mlRelatedTasksDetails;
		String strProjectID;
		String strEstimatedFinishDate;
		String strActualFinishDate;
		String strActualStartDate;
		String strPercentComplete;
		String strIssueId;
		long slipDays;
		DomainObject projectObj;
		Map taskMap;
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context, "Member", "Project Space", slObjSelects,
				null, true, false, (short) 1, whereCondition, DomainConstants.EMPTY_STRING, null, null, null);

		Iterator relatedProjectIterator = (Iterator) mlRelatedProjectDetails.iterator();
		while (relatedProjectIterator.hasNext()) {

			Map projectMap = (Map) relatedProjectIterator.next();
			strProjectID = (String) projectMap.get(DomainConstants.SELECT_ID);
			projectObj = DomainObject.newInstance(context, strProjectID);

			mlRelatedTasksDetails = projectObj.getRelatedObjects(context, relPattern.getPattern(),
					typePattern.getPattern(), slObjSelects, null, false, true, (short) 0, objectWhere,
					DomainConstants.EMPTY_STRING, null, null, null);
			Iterator taskListitr = mlRelatedTasksDetails.iterator();
			while (taskListitr.hasNext()) {
				taskMap = (Map) taskListitr.next();
				strEstimatedFinishDate = (String) taskMap.get("attribute[Task Estimated Finish Date]");
				strPercentComplete = (String) taskMap.get("attribute[Percent Complete]");
				strActualFinishDate = (String) taskMap.get("attribute[Task Actual Finish Date]");
				strActualStartDate = (String) taskMap.get("attribute[Task Actual Start Date]");

				clearBlankIssues(taskMap);

				slipDays = getSlipdays(context, strEstimatedFinishDate);
				taskMap.put("slipDays", String.valueOf(slipDays));
				taskMap.put("taskIcon", getTaskIcon(context, strPercentComplete, strEstimatedFinishDate,
						strActualFinishDate, strActualStartDate));
			}

			masterTaskList.addAll(mlRelatedTasksDetails);
		}
	}

	/**
	 * TODO The following method loads all Task with Missing Logs
	 * 
	 * @param context
	 * @param masterTaskList
	 * @param doPerson
	 * @param whereCondition
	 * @param relPattern
	 * @param typePattern
	 * @param objectWhere
	 * @throws FrameworkException
	 * @throws Exception
	 * @author PSN12
	 */
	@SuppressWarnings({ "deprecation", "unchecked" })
	private void getMissingLogTasks(Context context, MapList masterTaskList, DomainObject doPerson,
			String whereCondition, Pattern relPattern, Pattern typePattern, String objectWhere)
			throws FrameworkException, Exception {
		MapList mlRelatedTasksDetails;
		String strProjectID;
		String strEstimatedFinishDate;
		String strActualFinishDate;
		String strActualStartDate;
		String strPercentComplete;
		String strIssueId;
		long slipDays;
		DomainObject projectObj;
		Map taskMap;
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context, "Member", "Project Space", slObjSelects,
				null, true, false, (short) 1, whereCondition, DomainConstants.EMPTY_STRING, null, null, null);

		Iterator relatedProjectIterator = (Iterator) mlRelatedProjectDetails.iterator();
		while (relatedProjectIterator.hasNext()) {

			Map projectMap = (Map) relatedProjectIterator.next();
			strProjectID = (String) projectMap.get(DomainConstants.SELECT_ID);
			projectObj = DomainObject.newInstance(context, strProjectID);

			mlRelatedTasksDetails = projectObj.getRelatedObjects(context, relPattern.getPattern(),
					typePattern.getPattern(), slObjSelects, null, false, true, (short) 0, objectWhere,
					DomainConstants.EMPTY_STRING, null, null, null);
			Iterator taskListitr = mlRelatedTasksDetails.iterator();
			while (taskListitr.hasNext()) {
				taskMap = (Map) taskListitr.next();
				strEstimatedFinishDate = (String) taskMap.get("attribute[Task Estimated Finish Date]");
				strPercentComplete = (String) taskMap.get("attribute[Percent Complete]");
				strActualFinishDate = (String) taskMap.get("attribute[Task Actual Finish Date]");
				strActualStartDate = (String) taskMap.get("attribute[Task Actual Start Date]");

				clearBlankIssues(taskMap);

				slipDays = getSlipdays(context, strEstimatedFinishDate);
				taskMap.put("slipDays", String.valueOf(slipDays));
				taskMap.put("taskIcon", getTaskIcon(context, strPercentComplete, strEstimatedFinishDate,
						strActualFinishDate, strActualStartDate));
			}

			masterTaskList.addAll(mlRelatedTasksDetails);
		}
	}

	/**
	 * The following method clear null issues from collection
	 * 
	 * @param taskMap
	 * @author PSN12
	 */
	private void clearBlankIssues(Map taskMap) {
		String strIssueId;
		// Clear Blank Issues
		strIssueId = null;
		if (null != taskMap.get("to[Issue].from.id")) {
			strIssueId = (String) taskMap.get("to[Issue].from.id").toString();
		}

		if (strIssueId == null) {
			taskMap.put("to[Issue].from.id", "");
			taskMap.put("to[Issue].from.name", "");
		} else {
			taskMap.put("to[Issue].from.id", "Exists");
			taskMap.put("to[Issue].from.name", "Exists");
		}
	}

	/**
	 * This method is used to show the slipdays.
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args    holds the following input arguments: 0 - objectList MapList
	 * @returns Vector containing the slipdays value as Long.
	 * @throws Exception if the operation fails
	 * @since PMC 11.0.0.0
	 * @author PSN12
	 */
	@SuppressWarnings({ "finally", "deprecation" })
	public long getSlipdays(Context context, String taskEstFinishDate) throws Exception {

		long slipDays = (long) 0;
		try {
			Locale locale = context.getLocale();
			SimpleDateFormat sdf = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), locale);
			int iDateFormat = eMatrixDateFormat.getEMatrixDisplayDateFormat();
			DateFormat format = DateFormat.getDateTimeInstance(iDateFormat, iDateFormat, locale);
			Date sysDate = new Date();
			String ClientDate = sdf.format(sysDate);

			TimeZone tz = TimeZone.getTimeZone(context.getSession().getTimezone());
			double dbMilisecondsOffset = (double) (-1) * tz.getRawOffset();
			double clientTZOffset = (new Double(dbMilisecondsOffset / (1000 * 60 * 60))).doubleValue();

			ClientDate = eMatrixDateFormat.getFormattedDisplayDateTime(ClientDate, clientTZOffset, locale);
			sysDate = format.parse(ClientDate);
			Date estFinishDate = sdf.parse(taskEstFinishDate);
			estFinishDate.setHours(0);
			estFinishDate.setMinutes(0);
			estFinishDate.setSeconds(0);
			sysDate.setHours(0);
			sysDate.setMinutes(0);
			sysDate.setSeconds(0);

			slipDays = DateUtil.computeDuration(estFinishDate, sysDate) - 1;
		} catch (Exception ex) {
			throw ex;
		} finally {
			return slipDays;
		}
	}

	/**
	 * This method is used to show the status image.
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args    holds the following input arguments: 0 - objectList MapList
	 * @returns Vector containing all the status image value as String.
	 * @throws Exception if the operation fails
	 * @since PMC 11.0.0.0
	 * @author PSN12
	 */
	public String getTaskIcon(Context context, String percentComplete, String estimatedFinishDate,
			String actualFinishDate, String actualStartDate) throws Exception {
		String ctxLang = context.getLocale().getLanguage();
		SimpleDateFormat sdf = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);

		Calendar calendar = Calendar.getInstance();
		Date systemDate = calendar.getTime();
		systemDate = Helper.cleanTime(systemDate);

		String onTime = EnoviaResourceBundle.getProperty(context, "ProgramCentral", "emxProgramCentral.Common.OnTime",
				ctxLang);
		String late = EnoviaResourceBundle.getProperty(context, "ProgramCentral", "emxProgramCentral.Common.Late",
				ctxLang);
		String behindSchedule = EnoviaResourceBundle.getProperty(context, "ProgramCentral",
				"emxProgramCentral.Common.Legend.BehindSchedule", ctxLang);
		int yellowRedThreshold = Integer.parseInt(
				EnoviaResourceBundle.getProperty(context, "eServiceApplicationProgramCentral.SlipThresholdYellowRed"));

		String value = DomainObject.EMPTY_STRING;
		String display = DomainObject.EMPTY_STRING;
		try {
			Date estimatedFinish = sdf.parse(estimatedFinishDate);
			if ("100.0".equals(percentComplete)) {
				if (UIUtil.isNotNullAndNotEmpty(actualFinishDate)) {
					Date actualFinish = sdf.parse(actualFinishDate);

					if (actualFinish.before(estimatedFinish)) {
						display = onTime;
						value = ProgramCentralConstants.TASK_STATUS_ON_TIME;
					} else {
						display = late;
						value = ProgramCentralConstants.TASK_STATUS_COMPLETED_LATE;
					}
				} else if (UIUtil.isNotNullAndNotEmpty(actualStartDate)) {
					Date actStartDate = sdf.parse(actualStartDate);
					if (actStartDate.before(estimatedFinish)) {
						display = onTime;
						value = ProgramCentralConstants.TASK_STATUS_ON_TIME;
					} else {
						display = late;
						value = ProgramCentralConstants.TASK_STATUS_COMPLETED_LATE;
					}
				}
			} else {
				if (systemDate.after(estimatedFinish)) {
					display = late;
					value = ProgramCentralConstants.TASK_STATUS_LATE;
				} else if (DateUtil.computeDuration(systemDate, estimatedFinish) <= yellowRedThreshold) {
					display = behindSchedule;
					value = ProgramCentralConstants.TASK_STATUS_BEHIND_SCHEDULE;
				}
			}

		} catch (ParseException e) {
			e.printStackTrace();
		}

		if (ProgramCentralConstants.TASK_STATUS_ON_TIME.equals(value)) {
			return "<div style=\"background:#009E73;width:20px;height:20px;border-radius:50px;margin:auto;\" title=\""
					+ display + "\"> </div>";
		} else if (ProgramCentralConstants.TASK_STATUS_COMPLETED_LATE.equals(value)) {
			return "<div style=\"background:#009E73;width:20px;height:20px;border-radius:50px;margin:auto;\" title=\""
					+ display + "\"> </div>";
		} else if (ProgramCentralConstants.TASK_STATUS_BEHIND_SCHEDULE.equals(value)) {
			return "<div style=\"background: #FFCC00;width:20px;height:20px;border: none;-webkit-box-sizing: content-box;-moz-box-sizing: content-box;box-sizing: content-box;font: normal 100%/normal Arial, Helvetica, sans-serif;color: rgba(0, 0, 0, 1);-o-text-overflow: clip;text-overflow: clip;-webkit-transform: rotateZ(-45deg);transform: rotateZ(-45deg);-webkit-transform-origin: 0 100% 0deg;transform-origin: 0 100% 0deg;;margin:auto;\" title=\""
					+ display + "\"> </div>";
		} else if (ProgramCentralConstants.TASK_STATUS_LATE.equals(value)) {
			return "<div style=\"background:#da4242;width:20px;height:20px;margin:auto;\" title=\"" + display
					+ "\"> </div>";
		} else {
			return "<div style=\"background:#009E73;width:20px;height:20px;border-radius:50px;margin:auto;\" title=\""
					+ display + "\"> </div>";
		}

	}

	/**
	 * The following method gets list of all pending task with Mode settings
	 * 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 * @author PSN12
	 */
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getPendingTasks(Context context, String strMode) throws Exception {

		MapList mlResult = new MapList();
		String[] init = new String[] {};
		HashMap argsMap = new HashMap();
		String[] methodargs;
		MapList mlProjects;

		argsMap.put("objectId", "");
		methodargs = JPO.packArgs(argsMap);
		mlProjects = (com.matrixone.apps.domain.util.MapList) JPO.invoke(context, "emxProjectSpace", init,
				"getActiveProjects", methodargs, com.matrixone.apps.domain.util.MapList.class);

		// sort the projects by the ones that are due sooner
		mlProjects.sort(SELECT_ATTRIBUTE_TASK_ESTIMATED_END_DATE, "ascending", "date");

		// get the number of charts we want to display and only display data for that
		// number of charts
		String strNumberOfProjects = EnoviaResourceBundle.getProperty(context,
				"emxProgramCentral.ProjectSummary.ChartsToDisplay");
		int numberOfProjects = Integer.parseInt(strNumberOfProjects);
		if (mlProjects.size() < numberOfProjects) {
			numberOfProjects = mlProjects.size();
		}

		MapList tempMapList = new MapList();
		;
		for (int i = 0; i < numberOfProjects; i++) {
			Map projectMap = (Map) mlProjects.get(i);
			tempMapList.add(projectMap);
		}

		// set the project list to number of projects set by ChartsToDisplay
		mlProjects = tempMapList;

		// Check for sub-project IDs starts : To avoid repetitive tasks.
		String[] arrProjectId = new String[numberOfProjects];
		for (int i = 0; i < numberOfProjects; i++) {
			Map mProject = (Map) mlProjects.get(i);
			String sOIDProject = (String) mProject.get(DomainObject.SELECT_ID);
			arrProjectId[i] = sOIDProject;
		}

		String SELECT_SUB_PROJECT_ID = "from[" + DomainConstants.RELATIONSHIP_SUBTASK + "].to["
				+ DomainConstants.TYPE_PROJECT_SPACE + "].id";
		MapList mlSubProjectsId = DomainObject.getInfo(context, arrProjectId, new StringList(SELECT_SUB_PROJECT_ID));
		StringList subProjectIdList = new StringList();
		for (int i = 0; i < mlSubProjectsId.size(); i++) {
			Map projectMap = (Map) mlSubProjectsId.get(i);
			String subProjectId = (String) projectMap.get(SELECT_SUB_PROJECT_ID);
			subProjectIdList.addAll(ProgramCentralUtil.getAsStringList(subProjectId));
		}
		// Check for sub-project IDs ends

		if (numberOfProjects > 0) {
			for (int i = 0; i < numberOfProjects; i++) {
				Map mProject = (Map) mlProjects.get(i);
				String sOIDProject = (String) mProject.get(DomainObject.SELECT_ID);
				if (subProjectIdList.contains(sOIDProject)) {
					continue;
				}
				MapList mlTemp = retrieveOpenTasksOfProject(context, strMode, sOIDProject);
				mlResult.addAll(mlTemp);
			}
		}

		return mlResult;

	}

	/**
	 * The following method get all Open task for Projects
	 * 
	 * @param context
	 * @param sMode
	 * @param sOIDProject
	 * @return
	 * @throws Exception
	 * @author PSN12
	 */
	public MapList retrieveOpenTasksOfProject(Context context, String sMode, String sOIDProject) throws Exception {

		MapList mlResult = new MapList();
		DomainObject doProject = new DomainObject(sOIDProject);
		Calendar cal = Calendar.getInstance(TimeZone.getDefault());
		Calendar cCurrent = Calendar.getInstance();
		int iYearCurrent = cCurrent.get(Calendar.YEAR);
		int iMonthCurrent = cCurrent.get(Calendar.MONTH);
		int iWeekCurrent = cCurrent.get(Calendar.WEEK_OF_YEAR);
		long lCurrent = cCurrent.getTimeInMillis();
		long lDiff = 2592000000L;

		if (null == sMode) {
			sMode = "All";
		}

		StringList relSelects = new StringList();

		try {
			MapList mlTasks = doProject.getRelatedObjects(context, "Program Project,Subtask",
					"Project Space,Task Management", slObjSelects, relSelects, false, true, (short) 0, "", "", 0);

			if (mlTasks.size() > 0) {

				for (int j = 0; j < mlTasks.size(); j++) {

					Map mTask = (Map) mlTasks.get(j);
					String sCurrent = (String) mTask.get(DomainObject.SELECT_CURRENT);
					String sType = (String) mTask.get(DomainObject.SELECT_TYPE);
					String sIsLeaf = (String) mTask.get(SELECT_FROM_SUBTASK);
					if (mxType.isOfParentType(context, sType, DomainConstants.TYPE_TASK)) {
						if (!sCurrent.equals("Complete")) {
							if (sIsLeaf.equalsIgnoreCase("FALSE")) {

								/*
								 * Map mResult = new HashMap(); mResult.put(DomainObject.SELECT_ID, sOIDResult);
								 * mResult.put(DomainObject.SELECT_OWNER, sOwner);
								 * mResult.put(DomainObject.SELECT_CURRENT, sCurrent);
								 */

								if (sMode.equals("All")) {
									mlResult.add(mTask);
								} else if (sMode.equals("Overdue")) {
									String sTargetDate = (String) mTask.get(Task.SELECT_TASK_ESTIMATED_FINISH_DATE);
									if (sTargetDate != null && !"".equals(sTargetDate)) {

										Calendar cTarget = Calendar.getInstance();
										cTarget.setTime(sdf.parse(sTargetDate));

										if (cTarget.before(cal)) {
											mlResult.add(mTask);
										}
									}
								} else if (sMode.equals("This Week")) {
									String sTargetDate = (String) mTask.get(Task.SELECT_TASK_ESTIMATED_FINISH_DATE);
									if (sTargetDate != null && !"".equals(sTargetDate)) {

										Calendar cTarget = Calendar.getInstance();
										cTarget.setTime(sdf.parse(sTargetDate));

										int iYearTarget = cTarget.get(Calendar.YEAR);
										int iWeekTarget = cTarget.get(Calendar.WEEK_OF_YEAR);

										if (iYearCurrent == iYearTarget) {
											if (iWeekCurrent == iWeekTarget) {
												mlResult.add(mTask);
											}
										}
									}
								} else if (sMode.equals("This Month")) {
									String sTargetDate = (String) mTask.get(Task.SELECT_TASK_ESTIMATED_FINISH_DATE);
									if (sTargetDate != null && !"".equals(sTargetDate)) {

										Calendar cTarget = Calendar.getInstance();
										cTarget.setTime(sdf.parse(sTargetDate));

										int iYearTarget = cTarget.get(Calendar.YEAR);
										int iMonthTarget = cTarget.get(Calendar.MONTH);

										if (iYearCurrent == iYearTarget) {
											if (iMonthCurrent == iMonthTarget) {
												mlResult.add(mTask);
											}
										}
									}
								} else if (sMode.equals("Soon")) {
									String sTargetDate = (String) mTask.get(Task.SELECT_TASK_ESTIMATED_FINISH_DATE);
									if (sTargetDate != null && !"".equals(sTargetDate)) {

										Calendar cTarget = Calendar.getInstance();
										cTarget.setTime(sdf.parse(sTargetDate));
										long lTarget = cTarget.getTimeInMillis();

										if ((lTarget - lCurrent) < lDiff) {
											if ((lTarget - lCurrent) > 0) {
												mlResult.add(mTask);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		} catch (FrameworkException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return mlResult;

	}

}