/*---------------------------------------------------------------------------------------------------------------
NAME		: ${CLASSNAME}.java

------------------------------------------------------------------------------------------------------------------*/
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.math.BigDecimal;
import java.util.Locale;
import java.math.RoundingMode;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PersonUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;


public class WMSBudgetDashboard_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSBudgetDashboard_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	public Map getBudgetDashboardData(Context context, String[] args)throws Exception{
		Map mBudgetInfo = null;
		try{
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strCodeHead=(String)programMap.get("CodeHead");
			MapList mlCodeHeads = new MapList();
		
			String strYear = DomainConstants.EMPTY_STRING;
			String strTotalAllocationCFY = "0.00";
			String strTotalConsumedCFY = "0.00";
			
			Map mAllocationCFY = null;
			Map mConsumptionCFY = null;
			Map mFundRequestAllocationCFY = null;
			Map mFundAllocationExpenditureCFY = null;
					
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			
			if(month>3){
				strYear = String.valueOf(year)+"-"+String.valueOf(year+1);	
			}else{
				strYear = String.valueOf(year-1)+"-"+String.valueOf(year);	
			}			
			
			String strWhere = DomainConstants.EMPTY_STRING;
			if(UIUtil.isNotNullAndNotEmpty(strCodeHead) && "All".equals(strCodeHead)==false){
				strWhere = "name=='"+strCodeHead+"'";
			}
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainObject.SELECT_ID);
			strListBusSelects.add(DomainObject.SELECT_NAME);
			mlCodeHeads = DomainObject.findObjects(
					context,
					TYPE_WMS_CODE_HEAD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD,
					strWhere,               // where expression
					DomainConstants.EMPTY_STRING,
					true,
					strListBusSelects, // object selects
					(short) 0);
					
			Map mTemp = null;
			double dTotalAllocatedAmountCFY = 0.0;
			double dTotalConsumedAmountCFY = 0.0;
			String strCodeHeadId = DomainConstants.EMPTY_STRING;
			for(int i=0;i<mlCodeHeads.size();i++){
				mTemp = (Map)mlCodeHeads.get(i);
				strCodeHeadId = (String)mTemp.get(DomainObject.SELECT_ID);
				
				if(UIUtil.isNotNullAndNotEmpty(strCodeHeadId)){
					String strCodeHeadYear = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadId+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"'].to.id dump");
					
					if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
						String strResutl = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"|to.current==Frozen].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						StringList slAmounts = FrameworkUtil.split(strResutl,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotalAllocatedAmountCFY = dTotalAllocatedAmountCFY + Double.valueOf((String)slAmounts.get(j));
						}
					}
					if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
						String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"'&& to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						if(UIUtil.isNotNullAndNotEmpty(strResult)){
							StringList slAmounts = FrameworkUtil.split(strResult,"|");
							for(int j=0;j<slAmounts.size();j++){
								dTotalConsumedAmountCFY = dTotalConsumedAmountCFY + Double.valueOf((String)slAmounts.get(j));
							}
						}
					}
					if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
						String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.current==Approved)].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
						if(UIUtil.isNotNullAndNotEmpty(strResult)){
							StringList slAmounts = FrameworkUtil.split(strResult,"|");
							for(int j=0;j<slAmounts.size();j++){
								dTotalConsumedAmountCFY = dTotalConsumedAmountCFY - Double.valueOf((String)slAmounts.get(j));
							}
						}
					}
					if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
						mAllocationCFY = (Map)getAllocationInCFY(context,strCodeHeadYear,mAllocationCFY);
						mConsumptionCFY = (Map)getConsumptionInCFY(context,strCodeHeadYear,strYear,mConsumptionCFY);
						mFundRequestAllocationCFY = (Map)getFundRequestAllocationCFY(context,strCodeHeadYear,strYear,mFundRequestAllocationCFY);
						mFundAllocationExpenditureCFY = (Map)getFundAllocationExpenditureCFY(context,strCodeHeadYear,strYear,mFundAllocationExpenditureCFY);
					}
				}
				
			}
			mBudgetInfo = new HashMap();
			
			if(mAllocationCFY == null){
				mAllocationCFY = (Map)updateEmptyMap(mAllocationCFY);
			}
			if(mConsumptionCFY == null){
				mConsumptionCFY = (Map)updateEmptyMap(mConsumptionCFY);
			}
			if(mFundRequestAllocationCFY == null){
				mFundRequestAllocationCFY = (Map)updateEmptyComparisionMap(mFundRequestAllocationCFY);
			}
			if(mFundAllocationExpenditureCFY == null){
				mFundAllocationExpenditureCFY = (Map)updateEmptyComparisionMap(mFundAllocationExpenditureCFY);
			}
			
			
			strTotalAllocationCFY = WMSUtil_mxJPO.converToIndianCurrency(context,dTotalAllocatedAmountCFY);
			strTotalConsumedCFY = WMSUtil_mxJPO.converToIndianCurrency(context,dTotalConsumedAmountCFY);
			
			double dPercentageConsumption = 0.0;
			if(dTotalConsumedAmountCFY>0 && dTotalAllocatedAmountCFY>0){
				dPercentageConsumption = dTotalConsumedAmountCFY/dTotalAllocatedAmountCFY*100;
			}
			String strPercentage = new BigDecimal(dPercentageConsumption).setScale(2, RoundingMode.FLOOR).toPlainString();
			
			mBudgetInfo.put("TotalAllocationCFY",strTotalAllocationCFY);
			mBudgetInfo.put("TotalConsumedCFY",strTotalConsumedCFY);
			mBudgetInfo.put("PercentageConsumption",strPercentage);
			mBudgetInfo.put("AllocationsCFY",mAllocationCFY);
			mBudgetInfo.put("ConsumptionsCFY",mConsumptionCFY);
			mBudgetInfo.put("FundRequestAllocationCFY",mFundRequestAllocationCFY);
			mBudgetInfo.put("FundAllocationExpenditureCFY",mFundAllocationExpenditureCFY);
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mBudgetInfo;
	}
	
	
	private Map getAllocationInCFY(Context context, String strCodeHeadYear, Map mAllocationCFY)throws Exception{
		try{
			if(mAllocationCFY == null){
				mAllocationCFY = new HashMap();
			}
			if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
				String[] sMonths = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				for(int i=0;i<sMonths.length;i++){
					strMonth = (String)sMonths[i];					
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select from["+RELATIONSHIP_WMS_CODE_HEAD_YEAR_ALLOCATION+"|(to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current=='Frozen')].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					double dTotal = 0.0;
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					strAmount = (String)mAllocationCFY.get(strMonth);
					if(UIUtil.isNotNullAndNotEmpty(strAmount)){
						dTotal = Double.valueOf(strAmount) + dTotal;
					}
					mAllocationCFY.put(strMonth,new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mAllocationCFY;
		
	}
	
	private Map getConsumptionInCFY(Context context, String strCodeHeadYear,String strYear, Map mConsumptionCFY)throws Exception{
		if(mConsumptionCFY == null){
				mConsumptionCFY = new HashMap();
		}
		try{
			if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
				String[] sMonths = new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"};
				String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				for(int i=0;i<sMonths.length;i++){
					strMonth = (String)sMonths[i];
					double dTotal = 0.0;
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current==Approved].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current==Approved)].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal - Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strAmount = (String)mConsumptionCFY.get((String)sMonthNames[i]);
					if(UIUtil.isNotNullAndNotEmpty(strAmount)){
						dTotal = Double.valueOf(strAmount) + dTotal;
					}
					mConsumptionCFY.put((String)sMonthNames[i],new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString());					
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mConsumptionCFY;
		
	}
	
	private Map getFundRequestAllocationCFY(Context context, String strCodeHeadYear,String strYear, Map mFundRequestAllocationCFY)throws Exception{
		if(mFundRequestAllocationCFY == null){
				mFundRequestAllocationCFY = new HashMap();
		}
		try{
			if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
				String[] sMonths = new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"};
				String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				for(int i=0;i<sMonths.length;i++){
					strMonth = (String)sMonths[i];
					double dFundRequestTotal = 0.0;
					double dFundReleaseTotal = 0.0;
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current!='Create'].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dFundRequestTotal = dFundRequestTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current=='Approved')].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dFundReleaseTotal = dFundReleaseTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strAmount = (String)mFundRequestAllocationCFY.get((String)sMonthNames[i]);
					if(UIUtil.isNotNullAndNotEmpty(strAmount)){
						StringList slAmounts = FrameworkUtil.split(strAmount,"|");
						dFundRequestTotal = dFundRequestTotal + Double.valueOf((String)slAmounts.get(0));
						dFundReleaseTotal = dFundReleaseTotal + Double.valueOf((String)slAmounts.get(1));
					}
					mFundRequestAllocationCFY.put((String)sMonthNames[i],new BigDecimal(dFundRequestTotal).setScale(2, RoundingMode.FLOOR).toPlainString()+"|"+new BigDecimal(dFundRequestTotal-dFundReleaseTotal).setScale(2, RoundingMode.FLOOR).toPlainString());					
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mFundRequestAllocationCFY;
		
	}
	
	private Map getFundAllocationExpenditureCFY(Context context, String strCodeHeadYear,String strYear, Map mFundAllocationExpenditureCFY)throws Exception{
		if(mFundAllocationExpenditureCFY == null){
				mFundAllocationExpenditureCFY = new HashMap();
		}
		try{
			if(UIUtil.isNotNullAndNotEmpty(strCodeHeadYear)){
				String[] sMonths = new String[] {"1","2","3","4","5","6","7","8","9","10","11","12"};
				String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
				String strMonth = DomainConstants.EMPTY_STRING;
				String strAmount = DomainConstants.EMPTY_STRING;
				for(int i=0;i<sMonths.length;i++){
					strMonth = (String)sMonths[i];
					double dTotal = 0.0;
					double dBillTotal = 0.0;
					String strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_REQUEST+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current=='Approved')].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WMS_WO_FUND_RELEASE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && to.current=='Approved')].to.attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dTotal = dTotal - Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					
					strResult = MqlUtil.mqlCommand(context,"print bus "+strCodeHeadYear+" select to["+RELATIONSHIP_WMS_CODE_HEAD_YEAR+"].from.to["+RELATIONSHIP_WMS_PROJECT_CODE_HEAD+"].from.from["+RELATIONSHIP_WMS_PORJECT_WORK_ORDER+"].to.from["+RELATIONSHIP_WORKORDER_ABSTRACT_MBE+"|(to.attribute["+ATTRIBUTE_WMS_FINANCIAL_YEAR+"].value=='"+strYear+"' && to.attribute["+ATTRIBUTE_WMS_MONTH+"].value=='"+strMonth+"' && (to.current=='Approved' || to.current=='Paid'))].to.attribute["+ATTRIBUTE_WMS_CERTIFIED_AMOUNT+"].value dump |");
					if(UIUtil.isNotNullAndNotEmpty(strResult)){
						StringList slAmounts = FrameworkUtil.split(strResult,"|");
						for(int j=0;j<slAmounts.size();j++){
							dBillTotal = dBillTotal + Double.valueOf((String)slAmounts.get(j));
						}
					}
					
					strAmount = (String)mFundAllocationExpenditureCFY.get((String)sMonthNames[i]);
					if(UIUtil.isNotNullAndNotEmpty(strAmount)){
						StringList slAmounts = FrameworkUtil.split(strAmount,"|");
						dTotal = dTotal + Double.valueOf((String)slAmounts.get(0));
						dBillTotal = dBillTotal + Double.valueOf((String)slAmounts.get(1));
					}
					mFundAllocationExpenditureCFY.put((String)sMonthNames[i],new BigDecimal(dTotal).setScale(2, RoundingMode.FLOOR).toPlainString()+"|"+new BigDecimal(dBillTotal).setScale(2, RoundingMode.FLOOR).toPlainString());					
				}
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
		return mFundAllocationExpenditureCFY;
		
	}
	
	
	private Map updateEmptyMap(Map map){
		map = new HashMap();
		String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
		String strMonth = DomainConstants.EMPTY_STRING;
		for(int i=0;i<sMonthNames.length;i++){
			strMonth = (String)sMonthNames[i];
			map.put(strMonth,"0.00");
		}
		return map;
	}
	
	private Map updateEmptyComparisionMap(Map map){
		map = new HashMap();
		String[] sMonthNames = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
		String strMonth = DomainConstants.EMPTY_STRING;
		for(int i=0;i<sMonthNames.length;i++){
			strMonth = (String)sMonthNames[i];
			map.put(strMonth,"0.00|0.00");
		}
		return map;
		
	}

	public HashMap getBudgetData(Context context, String[] args)throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		String strCodeHead = (String)programMap.get("CodeHead"); //code head id 1/94/35
		String strCodeHeadYear = (String)programMap.get("CodeHeadYear"); //FY
		String strCodeHeadType = (String)programMap.get("CodeHeadType"); //capital or revenue
		String strCodeHeadName = (String)programMap.get("CodeHeadName"); //DODY
		
		/*String strCodeHead = "All";
		String strCodeHeadYear = "CFY";
		String strCodeHeadType = "All";
		String strCodeHeadName = "All";*/

		String strFinancialYear = strCodeHeadYear;
		if ("CFY".equals(strFinancialYear))
		{
			LocalDateTime now = LocalDateTime.now();
			int year = now.getYear();
			int month = now.getMonthValue();
			if(month > 3)
			{
				strFinancialYear = String.valueOf(year)+"-"+String.valueOf(year+1);
			}
			else
			{
				strFinancialYear = String.valueOf(year-1)+"-"+String.valueOf(year);
			}
		}
		
		//get allocation details
		String strAllocationsWhere = "to[WMSCodeHeadYearAllocation].from.attribute[WMSFinancialYear].value=='"+strFinancialYear+"' && current==Frozen";
		if(!"All".equals(strCodeHeadType))
		{
			strAllocationsWhere += " && to[WMSCodeHeadYearAllocation].from.to[WMSCodeHeadYear].from.attribute[WMSCodeHeadType].value=='"+strCodeHeadType+"'";
		}
		if(!"All".equals(strCodeHeadName))
		{
			strAllocationsWhere += " && to[WMSCodeHeadYearAllocation].from.to[WMSCodeHeadYear].from.attribute[WMSCodeHeadName].value=='"+strCodeHeadName+"'";
		}
		if(!"All".equals(strCodeHead))
		{
			strAllocationsWhere += " && to[WMSCodeHeadYearAllocation].from.to[WMSCodeHeadYear].from.name=='"+strCodeHead+"'";
		}
		StringList slAllocationSels = new StringList(2);
		slAllocationSels.addElement("attribute[WMSTotalAmount].value");
		slAllocationSels.addElement("attribute[WMSMonth].value");

		MapList mlAllocations = DomainObject.findObjects(
														context,
														"WMSCodeHeadYearAllocation",
														DomainConstants.QUERY_WILDCARD,
														DomainConstants.QUERY_WILDCARD,
														DomainConstants.QUERY_WILDCARD,
														DomainConstants.QUERY_WILDCARD,
														strAllocationsWhere,
														DomainConstants.EMPTY_STRING,
														true,
														slAllocationSels,
														(short) 0);

		HashMap hmMonthlyAllocations = new HashMap();
		hmMonthlyAllocations.put("April", "0.0");
		hmMonthlyAllocations.put("May", "0.0");
		hmMonthlyAllocations.put("June", "0.0");
		hmMonthlyAllocations.put("July", "0.0");
		hmMonthlyAllocations.put("August", "0.0");
		hmMonthlyAllocations.put("September", "0.0");
		hmMonthlyAllocations.put("October", "0.0");
		hmMonthlyAllocations.put("November", "0.0");
		hmMonthlyAllocations.put("December", "0.0");
		hmMonthlyAllocations.put("January", "0.0");
		hmMonthlyAllocations.put("February", "0.0");
		hmMonthlyAllocations.put("March", "0.0");

		int iAllocationsSize = mlAllocations.size();
		for(int i=0 ; i<iAllocationsSize ; i++)
		{
			Map mTemp = (Map)mlAllocations.get(i);
			String strMonth = (String)mTemp.get("attribute[WMSMonth].value");
			hmMonthlyAllocations.put(strMonth, (Double.parseDouble((String)hmMonthlyAllocations.get(strMonth)) + Double.parseDouble((String)mTemp.get("attribute[WMSTotalAmount].value")))+"");
		}
		//get expenditure details
		String strExpenditureWhere = "attribute[WMSFinancialYear].value=='"+strFinancialYear+"' && current==Approved";
		if(!"All".equals(strCodeHeadType))
		{
			strExpenditureWhere += " && to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.from[WMSProjectCodeHead].to.attribute[WMSCodeHeadType].value=='"+strCodeHeadType+"'";
		}
		if(!"All".equals(strCodeHeadName))
		{
			strExpenditureWhere += " && to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.from[WMSProjectCodeHead].to.attribute[WMSCodeHeadName].value=='"+strCodeHeadName+"'";
		}
		if(!"All".equals(strCodeHead))
		{
			strExpenditureWhere += " && to[WMSWOAbstractMBE].from.to[WMSProjectWorkOrder].from.from[WMSProjectCodeHead].to.name=='"+strCodeHead+"'";
		}

		StringList slExpenditureSels = new StringList(2);
		slExpenditureSels.addElement("attribute[WMSCertifiedAmount].value");
		slExpenditureSels.addElement("attribute[WMSMonth].value");
		MapList mlExpenditures = DomainObject.findObjects(
														context,
														"WMSAbstractMeasurementBookEntry",
														DomainConstants.QUERY_WILDCARD,
														DomainConstants.QUERY_WILDCARD,
														DomainConstants.QUERY_WILDCARD,
														DomainConstants.QUERY_WILDCARD,
														strExpenditureWhere,
														DomainConstants.EMPTY_STRING,
														true,
														slExpenditureSels,
														(short) 0);

		int iExpendituresSize = mlExpenditures.size();
		HashMap hmMonthMapping = new HashMap();
		hmMonthMapping.put("1", "January");
		hmMonthMapping.put("2", "February");
		hmMonthMapping.put("3", "March");
		hmMonthMapping.put("4", "April");
		hmMonthMapping.put("5", "May");
		hmMonthMapping.put("6", "June");
		hmMonthMapping.put("7", "July");
		hmMonthMapping.put("8", "August");
		hmMonthMapping.put("9", "September");
		hmMonthMapping.put("10", "October");
		hmMonthMapping.put("11", "November");
		hmMonthMapping.put("12", "December");
		
		HashMap hmMonthlyExpenditures = new HashMap();
		hmMonthlyExpenditures.put("April", "0.0");
		hmMonthlyExpenditures.put("May", "0.0");
		hmMonthlyExpenditures.put("June", "0.0");
		hmMonthlyExpenditures.put("July", "0.0");
		hmMonthlyExpenditures.put("August", "0.0");
		hmMonthlyExpenditures.put("September", "0.0");
		hmMonthlyExpenditures.put("October", "0.0");
		hmMonthlyExpenditures.put("November", "0.0");
		hmMonthlyExpenditures.put("December", "0.0");
		hmMonthlyExpenditures.put("January", "0.0");
		hmMonthlyExpenditures.put("February", "0.0");
		hmMonthlyExpenditures.put("March", "0.0");
		for(int i=0 ; i<iExpendituresSize ; i++)
		{
			Map mTemp = (Map)mlExpenditures.get(i);
			String strMonth = (String)mTemp.get("attribute[WMSMonth].value");
			hmMonthlyExpenditures.put((String)hmMonthMapping.get(strMonth), (Double.parseDouble((String)hmMonthlyExpenditures.get((String)hmMonthMapping.get(strMonth))) + Double.parseDouble((String)mTemp.get("attribute[WMSCertifiedAmount].value")))+"");
		}
		//prepare strings for highcharts
		//allocations and cumulative allocations
		StringList slAllocations = new StringList(12);
		StringList slCumulativeAllocations = new StringList(12);
		double dCumulativeAllocations = 0.0;

		StringList slExpenditures = new StringList(12);
		StringList slCumulativeExpenditures = new StringList(12);
		double dCumulativeExpenditures = 0.0;

		StringList slMonths = new StringList(12);
		slMonths.addElement("April");
		slMonths.addElement("May");
		slMonths.addElement("June");
		slMonths.addElement("July");
		slMonths.addElement("August");
		slMonths.addElement("September");
		slMonths.addElement("October");
		slMonths.addElement("November");
		slMonths.addElement("December");
		slMonths.addElement("January");
		slMonths.addElement("February");
		slMonths.addElement("March");

		String key;
		for (int i = 0 ; i < slMonths.size() ; i++)
		{
			key = (String)slMonths.get(i);
			slAllocations.addElement("['"+key+"]', "+(String)hmMonthlyAllocations.get(key)+"]");
			dCumulativeAllocations += Double.valueOf((String)hmMonthlyAllocations.get(key));
			slCumulativeAllocations.addElement("['"+key+"]', "+String.valueOf(dCumulativeAllocations)+"]");

			slExpenditures.addElement((String)hmMonthlyExpenditures.get(key));
			dCumulativeExpenditures += Double.valueOf((String)hmMonthlyExpenditures.get(key));
			slCumulativeExpenditures.addElement(String.valueOf(dCumulativeExpenditures));
		}

		HashMap hmReturnMap = new HashMap();
		hmReturnMap.put("slAllocations",slAllocations.toString());
		hmReturnMap.put("slCumulativeAllocations",slCumulativeAllocations.toString());
		hmReturnMap.put("slExpenditures",slExpenditures.toString());
		hmReturnMap.put("slCumulativeExpenditures",slCumulativeExpenditures.toString());
		hmReturnMap.put("strCummulativeAllocation",(WMSUtil_mxJPO.converToIndianCurrency(context,dCumulativeAllocations))+"");
		hmReturnMap.put("strCummulativeExpenditure",(WMSUtil_mxJPO.converToIndianCurrency(context,dCumulativeExpenditures))+"");
		return hmReturnMap;
	}
} 