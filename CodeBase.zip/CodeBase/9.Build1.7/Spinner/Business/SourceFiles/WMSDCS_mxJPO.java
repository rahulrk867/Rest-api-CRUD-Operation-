/*---------------------------------------------------------------------------------------------------------------
NAME		: ${CLASSNAME}.java

DESCRIPTION	: Purpose of JPO is to Create DCS and perform the utility operations on it

CREATED		: August 13 2019

AUTHOR		: Chandrakant M Sangashetty

HISTORY		:

	Chandrakant M Sangashetty	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import com.matrixone.apps.common.Route;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.framework.ui.UICache;
import com.matrixone.apps.framework.ui.UITableIndented;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.Policy;
import matrix.util.StringList;

import com.matrixone.jdom.Element;

import java.io.File;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;

public class WMSDCS_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSDCS_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
	
	/**
	* Method to get Related DCS information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedDCSMaster(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			String sObjState = DomainConstants.EMPTY_STRING;
			String sObjRTId = DomainConstants.EMPTY_STRING;
			MapList mlDCSMaster = new MapList();
			
			DomainObject domObject = new DomainObject(sObjectId);
			String sSOCObjId = domObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)){
				domObject = new DomainObject(sSOCObjId);
				mlDCSMaster = domObject.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSSOC_DCSMASTER, // relationship pattern
														TYPE_WMSDCSMASTER, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														null, // object where clause
														null); // relationship where clause
				for (int i = 0, size = mlDCSMaster.size(); i < size; i++) {
					Map objMap = (Map) mlDCSMaster.get(i);
					sObjOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
					sObjState = (String) objMap.get(DomainConstants.SELECT_CURRENT);
					sObjRTId = (String) objMap.get("from["+RELATIONSHIP_WMSDCSMASTER_APPROVAL_TEMPLATE+"].to.id");
					if(!sContextUser.equals(sObjOwner) || !STATE_WMSDCSMASTER_CREATE.equals(sObjState)) {
						objMap.put("RowEditable", "readonly");
					}
					if(STATE_WMSDCSMASTER_REVIEW.equals(sObjState)){
						objMap.put("disableSelection", "true");
					}
				}
				mlDCSMaster.sort("originated", "ascending", "date");
			}
			return mlDCSMaster;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
    ** This Method connect DCS Item object.
    */
	@com.matrixone.apps.framework.ui.PostProcessCallable
    public void connectDCSMaster(Context context, String[] args)throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
			HashMap paramMap = (HashMap) programMap.get("paramMap");
			
			String sParentObjectId = (String) requestMap.get("parentOID");
			String sAssociatedTSId = (String) requestMap.get("AssociatedTechnicalSanctionOID");
			DomainObject domObject = new DomainObject(sParentObjectId);
			String sfromObjectId = domObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			String stoObjectId = (String) paramMap.get("objectId");
			
			DomainRelationship.connect(context, sfromObjectId, RELATIONSHIP_WMSSOC_DCSMASTER, stoObjectId, false);
			
			if (UIUtil.isNotNullAndNotEmpty(sAssociatedTSId)) {
				DomainRelationship.connect(context, stoObjectId, RELATIONSHIP_WMSDCSTS, sAssociatedTSId, false);
			}
			
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	 * PENDING header and annotation
	 * Method to Generate the Serial Numbers after the Object Creation
	 */
	@com.matrixone.apps.framework.ui.ColJPOCallable
	public Vector getDCSMasterState(Context context, String[] args) throws Exception {
		try{
			Map programMap =   (Map)JPO.unpackArgs(args);
			MapList objectList = (MapList)programMap.get("objectList");
			int intSize = objectList.size();
			Vector vecResponse = new Vector(intSize);
			Iterator iterator  = objectList.iterator();
			for(int i=0; i < intSize; i++) {
				Map objMap = (Map) objectList.get(i);
				String sState = (String) objMap.get("current");
				if (STATE_WMSDCSMASTER_APPROVED.equals(sState)) {
					vecResponse.add(STATE_WMSDCSMASTER_APPROVED);
				} else {
					vecResponse.add("Draft");
				}
			}           

			return vecResponse;
		} catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
			
	/**
    ** This Method get Approved AE object on SOC.
    */
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getApprovedAE(Context context, String[] args)throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("rootObjectId");
			DomainObject domObject = new DomainObject(sObjectId);
			String sSOCObjId = domObject.getInfo(context, "to["+RELATIONSHIP_WMSSOC_DCSMASTER+"].from.id");

			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainObject.SELECT_TYPE);
			busSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
			String sWhere = DomainConstants.SELECT_CURRENT+" == "+STATE_WMSAEMASTER_APPROVED;
			MapList mlAEMaster = new MapList();
			if(UIUtil.isNotNullAndNotEmpty(sSOCObjId)){
				domObject = new DomainObject(sSOCObjId);
				mlAEMaster =domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_APPROVEDAEMASTER, // relationship pattern
													TYPE_WMSAEMASTER+","+TYPE_WMS_DEFAULT_MASTERS, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 0, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
				String strType = DomainConstants.EMPTY_STRING;
				for (int i = 0, size = mlAEMaster.size(); i < size; i++) {
					Map objMap = (Map) mlAEMaster.get(i);
					strType = (String)objMap.get(DomainObject.SELECT_TYPE);
					if(TYPE_WMS_DEFAULT_MASTERS.equals(strType)==false)
						objMap.put("disableSelection", "true");
				}
				mlAEMaster.sort("originated", "ascending", "date");
			}
			return mlAEMaster;
		} catch(Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method get Approved AE object on AE.
    */
	@com.matrixone.apps.framework.ui.ProgramCallable
    public MapList expandApprovedAE(Context context, String[] args)throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add("from["+RELATIONSHIP_WMSAE_AEITEM+"]");
			busSelects.add("attribute["+ATTRIBUTE_WMSTOTALAMOUNT+"]");
			
			String sWhere = DomainConstants.SELECT_CURRENT+" == "+STATE_WMSAE_APPROVED;
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlAE =domObject.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSAEMASTER_AE+","+RELATIONSHIP_WMSAE_AE, // relationship pattern
														TYPE_WMSAE, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														sWhere, // object where clause
														null); // relationship where clause
														
			String strIsLeaf = DomainConstants.EMPTY_STRING;
			for (int i = 0, size = mlAE.size(); i < size; i++) {
				Map objMap = (Map) mlAE.get(i);
				strIsLeaf = (String)objMap.get("from["+RELATIONSHIP_WMSAE_AEITEM+"]");
				if("false".equalsIgnoreCase(strIsLeaf))
					objMap.put("disableSelection", "true");
			}
														
			mlAE.sort("originated", "ascending", "date");
			return mlAE;
		} catch(Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}
		
	/**
    * This Method create DCS objects.
    **/
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
    public Map createDCS(Context context, String[] args)throws Exception {
		Map returnMap = new HashMap();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String sParentOID = (String) programMap.get("parentOID");
			HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sObjectId = (String) paramMap.get("objectId");
			String symbolicTypeName = (String) UICache.getSymbolicName(context, TYPE_WMSDCS, "type");
						
			Element elm = (Element) programMap.get("contextData");        
			MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
			HashMap objMap;
			String sRowId = DomainConstants.EMPTY_STRING ;
			MapList returnList = new MapList();
			
			for (int i = 0, size = chgRowsMapList.size(); i < size; i++) {
				objMap = new HashMap();
				Map changedRowMap = (HashMap) chgRowsMapList.get(i);
				Map columnsMap = (HashMap) changedRowMap.get("columns");
				sRowId = (String) changedRowMap.get("rowId");
				String strAuthorityId = (String) columnsMap.get("Authority");
				String strDescription = (String) columnsMap.get("Description");
				
				DomainObject doParentObject = null;
				String sRelationship = DomainConstants.EMPTY_STRING;
				if (UIUtil.isNotNullAndNotEmpty(sParentOID)) {
					doParentObject = new DomainObject(sParentOID);
					sRelationship = RELATIONSHIP_WMSDCS_DCS;
				} else {
					doParentObject = new DomainObject(sObjectId);
					sRelationship = RELATIONSHIP_WMSDCSMASTER_DCS;
				}
				
				StringList busSelects = new StringList();
				busSelects.add(DomainConstants.SELECT_ID);
				
				String sWhere = DomainConstants.SELECT_DESCRIPTION+" == \""+strDescription+"\"";
				MapList mlObjects = doParentObject.getRelatedObjects(context, // matrix context
															sRelationship, // relationship pattern
															TYPE_WMSDCS, // type pattern
															busSelects, // object selects
															null, // relationship selects
															false, // to direction
															true, // from direction
															(short) 1, // recursion level
															sWhere, // object where clause
															null); // relationship where clause
				if (mlObjects.size() > 0) {
					String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.DCSHeadCreate");
					returnMap.put("Action", "ERROR");
					returnMap.put("Message", strMessage);
				} else {
					String sName = DomainObject.getAutoGeneratedName(context, symbolicTypeName, DomainConstants.EMPTY_STRING);
					DomainObject doObject = new DomainObject();
					DomainRelationship doRel = doObject.createAndConnect(context, TYPE_WMSDCS, sName, DomainConstants.EMPTY_STRING, POLICY_WMSDCS, null, sRelationship, doParentObject, true);
					
					if (UIUtil.isNullOrEmpty(sParentOID) && UIUtil.isNotNullAndNotEmpty(strAuthorityId)) {
						DomainObject doAuthorityObject = new DomainObject(strAuthorityId);
						DomainRelationship doAuthorityRel = DomainRelationship.connect(context, doObject, RELATIONSHIP_WMSDCS_AE, doAuthorityObject);
						doAuthorityRel.setAttributeValue(context, ATTRIBUTE_WMSDCSMASTERID, sObjectId);
					}
					
					doObject.setDescription(context, strDescription);
					
					objMap.put("oid", doObject.getObjectId(context));
					objMap.put("relid", doRel.toString());
					objMap.put("pid", sObjectId);
					objMap.put("rid", "");
					objMap.put("markup", "new");
					objMap.put("rowId", sRowId);                
					returnList.add(objMap);
					returnMap.put("changedRows", returnList);
					returnMap.put("Action", "refresh");
				}
			}
			
		} catch(Exception ex){
			ex.printStackTrace();
			returnMap.put("Action", "ERROR");
			returnMap.put("Message", ex.getMessage());
		}
		return returnMap;	
    }
	
	/**
	* This Method Connects AE to DCS
	**/
	@com.matrixone.apps.framework.ui.CellUpdateJPOCallable
	public void connectAE(Context context,String args[]) throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramMap =  (HashMap)programMap.get("paramMap");
			
			HashMap requestMap  =(HashMap)programMap.get("requestMap");
			String PId = (String)requestMap.get("objectId");
			String strObjectId =(String) paramMap.get("objectId");
			String strAuthorityId =(String) paramMap.get("New Value");
			
			DomainObject doObject = new DomainObject(strObjectId);
			String sType = doObject.getInfo(context, DomainConstants.SELECT_TYPE);
			if (TYPE_WMSDCS.equals(sType)) {
				String sObjAEConnectionId = doObject.getInfo(context, "from["+RELATIONSHIP_WMSDCS_AE+"].id");
				if (UIUtil.isNotNullAndNotEmpty(sObjAEConnectionId)) {				
					DomainRelationship.disconnect(context, sObjAEConnectionId);
				}			
				DomainObject doAuthorityObject = new DomainObject(strAuthorityId);
				DomainRelationship doAuthorityRel = DomainRelationship.connect(context, doObject, RELATIONSHIP_WMSDCS_AE, doAuthorityObject);
				doAuthorityRel.setAttributeValue(context, ATTRIBUTE_WMSDCSMASTERID, PId);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
    ** This Method check Edit Access to Add Route Template.
    */
	@com.matrixone.apps.framework.ui.ColJPOCallable
    public StringList isAuthorityEditable(Context context, String[] args)throws Exception {
		try {
			StringList isCellEditable = new StringList();
    		Map programMap 		= (Map) JPO.unpackArgs(args);
    		MapList objectList 	= (MapList) programMap.get("objectList");
			
			for (int i = 0 ; i < objectList.size(); i++) {
				Map objMap = (Map) objectList.get(i);
				String sRelationship = (String) objMap.get("relationship");
				String sObjectId = (String) objMap.get("id");
				if(RELATIONSHIP_WMSDCS_DCSITEM.equals(sRelationship)) {
					isCellEditable.add("false");
				} else {
					DomainObject doObject = new DomainObject(sObjectId);
					StringList slObjects = doObject.getInfoList(context, "to["+RELATIONSHIP_WMSDCS_DCS+"].from.id");
					String sValue = slObjects.size() == 0 ? "true" : "false";
					isCellEditable.add(sValue);
				}
			}
			return isCellEditable;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
	* Method to get Related DCS information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedDCS(Context context,String args[]) throws Exception {
		try {
			HashMap programMap = (HashMap)JPO.unpackArgs(args);
			String sObjectId = (String) programMap.get("objectId");
			String sCommandName = (String) programMap.get("portalCmdName");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			MapList mlDCS = new MapList();
			
			DomainObject domObject = new DomainObject(sObjectId);
			mlDCS = domObject.getRelatedObjects(context, // matrix context
												RELATIONSHIP_WMSDCSMASTER_DCS, // relationship pattern
												TYPE_WMSDCS, // type pattern
												busSelects, // object selects
												null, // relationship selects
												false, // to direction
												true, // from direction
												(short) 1, // recursion level
												null, // object where clause
												null); // relationship where clause
			for (int i = 0, size = mlDCS.size(); i < size; i++) {
				Map objMap = (Map) mlDCS.get(i);
				sObjOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
				if(!sContextUser.equals(sObjOwner)) {
					objMap.put("RowEditable", "readonly");
				}
			}
			mlDCS.sort("originated", "ascending", "date");
			return mlDCS;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	* Method to get Related DCS information on DCS
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList expandDCS(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			
			String sContextUser = context.getUser();
			String sObjOwner = DomainConstants.EMPTY_STRING;
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlDCS = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSDCS_DCS, // relationship pattern
													TYPE_WMSDCS, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			for (int i = 0, size = mlDCS.size(); i < size; i++) {
				Map objMap = (Map) mlDCS.get(i);
				sObjOwner = (String) objMap.get(DomainConstants.SELECT_OWNER);
				if(!sContextUser.equals(sObjOwner)) {
					objMap.put("RowEditable", "readonly");
				}
			}
			mlDCS.sort("originated", "ascending", "date");
			return mlDCS;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	* Method to get Realated DCS Item information on DCS
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getRelatedDCSItem(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			
			DomainObject domObject = new DomainObject(sObjectId);
			
			MapList mlDCSItem = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSDCS_DCS+","+RELATIONSHIP_WMSDCS_DCSITEM, // relationship pattern
													TYPE_WMSDCS+","+TYPE_WMSDCSITEM, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			mlDCSItem.sort("originated", "ascending", "date");
			return mlDCSItem;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public String getDCSAmountField (Context context,String[] args)throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			dAmount = WMSUtil_mxJPO.getHeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
			
			return df.format(dAmount);
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method connect DCS Item object.
    */
	@com.matrixone.apps.framework.ui.PostProcessCallable
    public void connectItem(Context context, String[] args)throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
			HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sParentObjectId = (String) paramMap.get("objectId");
			
			String sfromObjectId = (String) requestMap.get("parentOID");
			String sType = (String) requestMap.get("TypeActual");
			String stoObjectId = (String) paramMap.get("objectId");
			
			DomainRelationship.connect(context, sfromObjectId, RELATIONSHIP_WMSDCS_DCSITEM, stoObjectId, false);
			
			MapList mlObjects = new MapList();
			Map oMap = new HashMap();
			oMap.put(DomainConstants.SELECT_TYPE, TYPE_WMSDCSITEM);
			oMap.put(DomainConstants.SELECT_ID, stoObjectId);
			mlObjects.add(oMap);
			
			oMap = new HashMap();
			oMap.put("ObjectList", mlObjects);
			
			HashMap hmTableData = new HashMap();
			hmTableData.put("tableData", oMap);
			
			JPO.invoke(context, "WMSUtil", null, "updateItemHistory", JPO.packArgs (hmTableData), Map.class);
			
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public void reviseDCSMaster(Context context, String[] args) throws Exception {
		try {
			
			ContextUtil.startTransaction(context, true);
			
			String fileName = DomainConstants.EMPTY_STRING;
			FileOutputStream outputStream = null;
			String strTempFolder = context.createWorkspace();
			//String strTempFolder = EnoviaResourceBundle.getProperty(context,"WMS.PaymentSchedule.Revision.tempfolder");
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
			MapList mlRows = (MapList) programMap.get("RowIds");
			
			for (int i = 0, size = mlRows.size(); i < size; i++) {
				Map objMap = (Map) mlRows.get(i);
				String strObjId = (String) objMap.get(DomainConstants.SELECT_ID);
				if(UIUtil.isNotNullAndNotEmpty(strObjId)) {
					
					DomainObject doObject = new DomainObject(strObjId);
					String strDCSMasterTitle = doObject.getAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE);
					
					StringList busSelects = new StringList();
					busSelects.add(DomainConstants.SELECT_ID);
					busSelects.add(DomainConstants.SELECT_DESCRIPTION);
					busSelects.add(DomainConstants.SELECT_OWNER);
					busSelects.add(DomainConstants.SELECT_ORIGINATED);
					busSelects.add("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
					busSelects.add("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
					busSelects.add("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"].value");
					busSelects.add("attribute["+ATTRIBUTE_RATE+"].value");
					busSelects.add("attribute["+ATTRIBUTE_WMSGST+"].value");
					busSelects.add("attribute["+ATTRIBUTE_REMARKS+"].value");
					busSelects.add("attribute["+ATTRIBUTE_WMSSTATION+"].value");
					busSelects.add("from["+RELATIONSHIP_WMSDCS_AE+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
					busSelects.add("state["+STATE_WMSDCSMASTER_APPROVED+"].actual");
					
					MapList mlDCSAll = new MapList();
					Map DCSMMap = doObject.getInfo(context, busSelects);
					mlDCSAll.add(DCSMMap);
					
					MapList mlDCS =doObject.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSDCSMASTER_DCS+","+RELATIONSHIP_WMSDCS_DCS+","+RELATIONSHIP_WMSDCS_DCSITEM, // relationship pattern
														TYPE_WMSDCS+","+TYPE_WMSDCSITEM, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 0, // recursion level
														DomainConstants.EMPTY_STRING, // object where clause
														DomainConstants.EMPTY_STRING); // relationship where clause
					mlDCSAll.addAll(mlDCS);
					//mlDCS.add(DCSMMap);
					//mlDCS.sort("originated", "ascending", "date");
					if(mlDCSAll != null && !mlDCSAll.isEmpty()) {
						XSSFWorkbook workbook = new XSSFWorkbook();
						XSSFSheet sheetData = workbook.createSheet("Data");
						String[] headerData = {"Sl No", "Level", "Type", "Name of Work", "Station", "Authority", "Description of Work", "Unit of Measure", "Quantity", "Rate", "Amount", "GST(%)", "Total Amount", "Remarks", "Created On", "Approved On", "Owner"};
						CellStyle styleHeading = workbook.createCellStyle();
						styleHeading.setBorderLeft(CellStyle.ALIGN_CENTER);
						
						XSSFFont font= workbook.createFont();
						font.setFontHeightInPoints((short)10);
						font.setFontName("Arial");
						font.setColor(IndexedColors.WHITE.getIndex());
						font.setBold(true);
						styleHeading.setFont(font);
						styleHeading.setFillForegroundColor((short)30);
						styleHeading.setFillPattern(CellStyle.SOLID_FOREGROUND); 
						styleHeading.setBorderLeft(CellStyle.BORDER_THIN);
						styleHeading.setBorderRight(CellStyle.BORDER_THIN);
						styleHeading.setBorderTop(CellStyle.BORDER_THIN);
						styleHeading.setBorderBottom(CellStyle.BORDER_THIN);
						
						Row row = sheetData.createRow(0);
						for (int columnCount=0; columnCount < headerData.length; columnCount++) {
							Cell cell = row.createCell(columnCount);
							cell.setCellValue((String) headerData[columnCount]);
							cell.setCellStyle(styleHeading);
						}
						
						String[] cellData = new String[headerData.length];			
						Row rowData = null;
						int iSize = mlDCSAll.size();
						Map mapObjectInfo = null;
						int iCountRow = 1;
						String sObjectId = DomainConstants.EMPTY_STRING;
						String sOwner = DomainConstants.EMPTY_STRING;
						String sApproved = DomainConstants.EMPTY_STRING;
						Date dtOriginated = new Date();
						Date dtApproved = new Date();
						DecimalFormat df = new DecimalFormat("0.00");
						SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
						for(int j=0; j<iSize; j++) {
							mapObjectInfo = (Map)mlDCSAll.get(j);
							cellData[0] = iCountRow+"";
							cellData[1] = UIUtil.isNotNullAndNotEmpty((String) mapObjectInfo.get(DomainConstants.SELECT_LEVEL)) ? ""+(1 + Integer.parseInt((String) mapObjectInfo.get(DomainConstants.SELECT_LEVEL))) : "1";
							cellData[3] = (String)mapObjectInfo.get("attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
							cellData[4] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSSTATION+"].value");
							cellData[5] = (String)mapObjectInfo.get("from["+RELATIONSHIP_WMSDCS_AE+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
							cellData[6] = (String)mapObjectInfo.get(DomainConstants.SELECT_DESCRIPTION);
							cellData[7] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMS_UNIT_OF_MEASURE+"].value");
							cellData[8] = (String)mapObjectInfo.get("attribute["+DomainConstants.ATTRIBUTE_QUANTITY+"].value");
							cellData[9] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_RATE+"].value");
							cellData[11] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_WMSGST+"].value");
							cellData[13] = (String)mapObjectInfo.get("attribute["+ATTRIBUTE_REMARKS+"].value");
							dtOriginated = eMatrixDateFormat.getJavaDate((String)mapObjectInfo.get(DomainConstants.SELECT_ORIGINATED));
							cellData[14] = sdf.format(dtOriginated);
							sApproved = (String) mapObjectInfo.get("state["+STATE_WMSDCSMASTER_APPROVED+"].actual");
							if (UIUtil.isNotNullAndNotEmpty(sApproved)) {
								dtApproved = eMatrixDateFormat.getJavaDate(sApproved);
								cellData[15] = sdf.format(dtApproved);
							} else {	
								cellData[15] = DomainConstants.EMPTY_STRING;
							}
							
							sObjectId = (String)mapObjectInfo.get(DomainConstants.SELECT_ID);
							DomainObject doDCSObject = new DomainObject(sObjectId);
							switch((String)mapObjectInfo.get(DomainConstants.SELECT_TYPE)) {
								case "WMSDCSMaster" :
											cellData[2] = "Sheet";
											cellData[10] = DomainConstants.EMPTY_STRING;
											cellData[12] = String.valueOf(df.format(WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCSMASTER_DCS, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM})));
											ContextUtil.pushContext(context);
											doDCSObject.setState(context, STATE_WMSAEMASTER_CREATE, true);
											ContextUtil.popContext(context);
											break;
								case "WMSDCS" :
											cellData[2] = "Head";
											cellData[10] = DomainConstants.EMPTY_STRING;
											cellData[12] = String.valueOf(df.format(WMSUtil_mxJPO.getHeadTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM})));
											break;
								case "WMSDCSItem" :
											cellData[2] = "Item";
											cellData[10] = String.valueOf(df.format(WMSUtil_mxJPO.getItemAmount(context, new String[]{sObjectId})));
											cellData[12] = String.valueOf(df.format(WMSUtil_mxJPO.getItemTotalAmount(context, new String[]{sObjectId})));
											ContextUtil.pushContext(context);
											doDCSObject.deleteObject(context, true);
											ContextUtil.popContext(context);
											break;
								default :
											cellData[2] = DomainConstants.EMPTY_STRING;
											cellData[10] = "0.00";
											cellData[12] = "0.00";
							}
							
							sOwner = (String)mapObjectInfo.get(DomainConstants.SELECT_OWNER);
							if (("User Agent").equalsIgnoreCase(sOwner)) {
								cellData[16] = sOwner;
							} else {
								BusinessObject boPerson = new BusinessObject(DomainConstants.TYPE_PERSON, sOwner, "-", VAULT_ESERVICEPRODUCTION);
								DomainObject doPerson = new DomainObject(boPerson);
								cellData[16] = (String) doPerson.getAttributeValue(context, DomainConstants.ATTRIBUTE_FIRST_NAME) + " " + doPerson.getAttributeValue(context, DomainConstants.ATTRIBUTE_LAST_NAME);
							}
							
							rowData = sheetData.createRow(iCountRow);
							for (int columnCount=0; columnCount < headerData.length; columnCount++) {
								Cell cell = rowData.createCell(columnCount);
								cell.setCellValue((String) cellData[columnCount]);
							}
							iCountRow++;
							
						}
						
						
						fileName = strDCSMasterTitle +"_"+Calendar.getInstance().getTimeInMillis();
						outputStream = new FileOutputStream(new File(strTempFolder+"/"+fileName+ ".xlsx"));
						workbook.write(outputStream);
						
						DomainObject doNewDoc = DomainObject.newInstance(context, DomainConstants.TYPE_DOCUMENT);
						doNewDoc.createObject(context, DomainConstants.TYPE_DOCUMENT, fileName, new Policy(DomainConstants.POLICY_DOCUMENT).getFirstInMinorSequence(context), DomainConstants.POLICY_DOCUMENT, VAULT_ESERVICEPRODUCTION);	
						doNewDoc.setAttributeValue(context, DomainConstants.ATTRIBUTE_TITLE, fileName);
						doNewDoc.checkinFile(context, true, true, "", DomainConstants.FORMAT_GENERIC, fileName+".xlsx", strTempFolder);
						DomainRelationship.connect(context, doObject, RELATIONSHIP_WMSDCSMASTERREVISE_REFERENCEDOCUMENT, doNewDoc);
						
					}
				}
			}
			
			ContextUtil.commitTransaction(context);
			
		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			emxContextUtil_mxJPO.mqlNotice(context, "Revise Process Failed");
			e.printStackTrace();
			throw e;
		}
	}
		
	/**
	* Method to get Related AE Revision History information on SOC
	**/
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getDCSRevisionHistory(Context context,String args[]) throws Exception {
		try {
			HashMap programMap=(HashMap)JPO.unpackArgs(args);
			String sObjectId=(String) programMap.get("objectId");
						
			StringList busSelects = new StringList(2);
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			StringList relSelects = new StringList(1);
            relSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			
			DomainObject domObject = new DomainObject(sObjectId);
			MapList mlRevisionHistory = domObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSDCSMASTERREVISE_REFERENCEDOCUMENT, // relationship pattern
													DomainConstants.QUERY_WILDCARD, // type pattern
													busSelects, // object selects
													relSelects, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
			return mlRevisionHistory;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public Vector getAssociatedTS(Context context,String[] args) throws Exception {
		Vector colVector = new Vector();
		try { 
			String strURL="../common/emxTree.jsp";
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramList = (HashMap) programMap.get("paramList");
			MapList objectList  = (MapList) programMap.get("objectList");
			StringBuilder sb= null;
			Iterator<Map> itr = objectList.iterator();
			String strType = DomainConstants.EMPTY_STRING;
			String strId = DomainConstants.EMPTY_STRING;
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add("attribute[WMSTSNumber]");
			String sWhere = "revision==last";
			String sTSName = DomainConstants.EMPTY_STRING;
			String sTSId = DomainConstants.EMPTY_STRING;
			while(itr.hasNext()) {
				Map m = itr.next();
				strType = (String)m.get(DomainObject.SELECT_TYPE);
				strId = (String)m.get(DomainObject.SELECT_ID);
				DomainObject doObject = new DomainObject(strId);
				MapList sList = doObject.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSDCSTS, // relationship pattern
													TYPE_WMSTECHNICALSANCTION, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
				if (sList.size() == 1) {
					Map objMap = (Map) sList.get(0);
					sTSId = (String) objMap.get(DomainConstants.SELECT_ID);
					sTSName = (String) objMap.get("attribute[WMSTSNumber]");
				}
				sb=new StringBuilder();
				sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+sTSId+"','600','400','false')\" >");            
				sb.append(sTSName);
				sb.append("</a>");		
				colVector.add(sb.toString());
				sTSName = DomainConstants.EMPTY_STRING;
				sTSId = DomainConstants.EMPTY_STRING;	
			}
			 
		} catch(Exception e) {
			e.printStackTrace();
		} 
		return colVector;
	}
	
	public boolean isValidtoCreateDCSMaster(Context context,String[] args) throws Exception {
		boolean bFlag = true;
		try {
			String sObjectId = args[0];
			
			String sWOO = EnoviaResourceBundle.getProperty(context, "WMS.WOO.Create.Department");
			StringList slWOO = FrameworkUtil.split(sWOO, ",");
			
			String sContextUser = context.getUser();
			String sCompany = (String) PersonUtil.getDefaultOrganization(context, sContextUser);
			
			if (!slWOO.isEmpty() && !slWOO.contains(sCompany)) {
				return true;
			}
			
			DomainObject doObject = new DomainObject(sObjectId);
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_CURRENT);
			String sWhere = "revision==last";
			
			String sSOCId =  (String) doObject.getInfo(context, "from["+RELATIONSHIP_WMSPROJECTSOC+"].to.id");
			doObject = new DomainObject(sSOCId);
			MapList sList = doObject.getRelatedObjects(context, // matrix context
														RELATIONSHIP_WMSSOC_WOO, // relationship pattern
														TYPE_WMSWOO, // type pattern
														busSelects, // object selects
														null, // relationship selects
														false, // to direction
														true, // from direction
														(short) 1, // recursion level
														sWhere, // object where clause
														null); // relationship where clause
			if (sList.size() == 1) {
				Map objMap = (Map) sList.get(0);
				String sState = (String) objMap.get(DomainConstants.SELECT_CURRENT);
				if (STATE_WMSWOO_APPROVED.equals(sState)) {
					bFlag = true;
				}
			}
						
		} catch(Exception e) {
			e.printStackTrace();
			bFlag = false;
		} 
		return bFlag;
	}
		
	/**
    ** This Method check Route object.
    */
    public static int checkApprovalRoute(Context context, String[] args)throws Exception {
		int iResult = 1;
		try {
			String sObjectId = args[0];
			String sRTRelationship = args[1];
			String sMasterRelationship = args[2];
			String sRelationship = args[3];
			String sItemRelationship = args[4];
		
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
		
			DomainObject doObj = new DomainObject(sObjectId);
			String sWhere = "current != Complete";
			MapList mlExtRoutes = doObj.getRelatedObjects(context, // matrix context
													sRTRelationship, // relationship pattern
													DomainConstants.TYPE_ROUTE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
			
			if (mlExtRoutes.size() != 1) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoApprovalTemplate");
				emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				return 1;
			}
			
			String sItemId = DomainConstants.EMPTY_STRING;
			DomainObject doItemObject = null;
			StringList slObjects = doObj.getInfoList(context, "from["+sMasterRelationship+"].to.id");
			if (slObjects.size() == 0) {
				String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoItem");
				emxContextUtil_mxJPO.mqlNotice(context, strMessage);
				return 1;
			} else {
				for (Object ItemObject:slObjects) {
					iResult = WMSUtil_mxJPO.checkForLeafItem(context, new String [] {(String) ItemObject, sRelationship, sItemRelationship});
					if( iResult == 1) {
						String strMessage = EnoviaResourceBundle.getProperty(context,"wmsStringResource", context.getLocale(), "WMS.Alert.NoItem");
						emxContextUtil_mxJPO.mqlNotice(context, strMessage);
						return 1;
					}
				}
			}
			
			return 0;
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	/**
    ** This Method check DCS Authority Amount.
    */
    public static int checkDCSAuthorityAmount(Context context, String[] args)throws Exception {
		int iResult = 1;
		
		try {
			String sObjectId = args[0];
			DomainObject doObject = new DomainObject(sObjectId);
			
			StringList slAllDCS = doObject.getInfoList(context, "from["+RELATIONSHIP_WMSDCSMASTER_DCS+"].to.id");
			for (Object ItemObject:slAllDCS) {
				double dAEAmount = 0;
				double dDCSAmount = 0;
				String sDCSId = (String)ItemObject;
				DomainObject doDCS = new DomainObject(sDCSId);
				String sDCSDesc = doDCS.getInfo(context, DomainConstants.SELECT_DESCRIPTION);
				String sAEId = doDCS.getInfo(context, "from["+RELATIONSHIP_WMSDCS_AE+"].to.id");
				if (UIUtil.isNullOrEmpty(sAEId)) {
					emxContextUtil_mxJPO.mqlNotice(context, "Authority is missing for DCS "+sDCSDesc);
					return 1;
				}
				/*String sTitle = doDCS.getInfo(context, "from["+RELATIONSHIP_WMSDCS_AE+"].to.attribute["+DomainConstants.ATTRIBUTE_TITLE+"].value");
				dAEAmount = ${CLASS:WMSUtil}.getPart1HeadTotalAmount(context, new String[]{sAEId, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
				DomainObject doAE = new DomainObject(sAEId);
				StringList slDCS = doAE.getInfoList(context, "to["+RELATIONSHIP_WMSDCS_AE+"].from.id");
				for (Object DCSObject:slDCS) {
					String sAEDCSId = (String)DCSObject;
					dDCSAmount = dDCSAmount + ${CLASS:WMSUtil}.getHeadTotalAmount(context, new String[]{sAEDCSId, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
				}
				if (dAEAmount<dDCSAmount) {
					${CLASS:emxContextUtil}.mqlNotice(context, "Amount of DCS is Exceeding than its Authority "+sTitle);
					return 1;
				}*/
			}
						
			return 0;
			
		} catch(Exception ex){
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}
	
	/**
    ** This Method check DCSMaster Total Amount.
    */
    public static int checkDCSMasterTotalAmount(Context context, String[] args)throws Exception {
		int iResult = 1;
		double dDelegationAmount = 0;
		double dDelegationContingencyAmount = 0;
		double dDCSMasterTotalAmount = 0;
		try {
			String sObjectId = args[0];
			
			dDCSMasterTotalAmount = dDCSMasterTotalAmount + WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCSMASTER_DCS, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
			
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ORGANIZATION);
			slObjSelects.add("to["+RELATIONSHIP_WMSSOC_DCSMASTER+"].from.id");
			
			DomainObject doObject = new DomainObject(sObjectId);
			Map oMap = doObject.getInfo(context, slObjSelects);
			String sOrganization = (String) oMap.get(DomainConstants.SELECT_ORGANIZATION);
			String sSOCId = (String) oMap.get("to["+RELATIONSHIP_WMSSOC_DCSMASTER+"].from.id");
			
			String sAttributeMapping = EnoviaResourceBundle.getProperty(context, "WMS.DelegationOrg.AttributeMapping");
		    StringList slAttributeMapping = FrameworkUtil.split(sAttributeMapping, ",");
			String sAttrOrgAmount = DomainConstants.EMPTY_STRING;
			String sAttrOrgContingency = DomainConstants.EMPTY_STRING;
			String sAttrOrgContengency = DomainConstants.EMPTY_STRING;
			for (Object ItemObject:slAttributeMapping) {
				String sValue = (String)ItemObject;
				StringList slValues = FrameworkUtil.split(sValue, "|");
				if(slValues.size() == 3 && sOrganization.equalsIgnoreCase(slValues.get(0))){
					sAttrOrgAmount = slValues.get(1);
					sAttrOrgContingency = slValues.get(2);
				}
			}
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add("attribute["+sAttrOrgAmount+"].value");			
			busSelects.add("attribute["+sAttrOrgContingency+"].value");			
			String sWhere = "revision == last && current == Delegate";
			
			DomainObject doSOC = new DomainObject(sSOCId);
			MapList mlDelegation = doSOC.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOCDELEGATION, // relationship pattern
													TYPE_WMSDELEGATION, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
			if(mlDelegation.size() == 1) {
				oMap  = (Map) mlDelegation.get(0);
				dDelegationAmount = Double.parseDouble((String) oMap.get("attribute["+sAttrOrgAmount+"].value"));
				dDelegationContingencyAmount = Double.parseDouble((String) oMap.get("attribute["+sAttrOrgContingency+"].value"));
			}
			dDelegationAmount = dDelegationAmount+dDelegationContingencyAmount;
			sWhere = "current == Approved && organization == "+sOrganization;
			MapList mlDCSMaster = doSOC.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOC_DCSMASTER, // relationship pattern
													TYPE_WMSDCSMASTER, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
			
			for (int i=0; i<mlDCSMaster.size(); i++) {
				oMap  = (Map) mlDCSMaster.get(i);
				String sDCSId = (String) oMap.get(DomainConstants.SELECT_ID);
				dDCSMasterTotalAmount = dDCSMasterTotalAmount + WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sDCSId, RELATIONSHIP_WMSDCSMASTER_DCS, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
			}
			dDelegationAmount = dDelegationAmount*1.1;
			if (dDelegationAmount < dDCSMasterTotalAmount) {
				emxContextUtil_mxJPO.mqlNotice(context, "Amount of DCS Sheets is Exceeding the "+sOrganization+" Delegated Amount");
				return 1;
			}
			
			return 0;
			
		} catch(Exception ex){
			ex.printStackTrace();
			emxContextUtil_mxJPO.mqlNotice(context, ex.getMessage());
			return 1;
		}
	}
	
	public String getAssociatedTSField (Context context,String[] args)throws Exception {
		StringBuilder sb = null;
		try { 
			String strURL="../common/emxTree.jsp";
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			String sWhere = "revision==last";
			String sTSName = DomainConstants.EMPTY_STRING;
			String sTSId = DomainConstants.EMPTY_STRING;
			
			DomainObject doObject = new DomainObject(sObjectId);
			MapList sList = doObject.getRelatedObjects(context, // matrix context
												RELATIONSHIP_WMSDCSTS, // relationship pattern
												TYPE_WMSTECHNICALSANCTION, // type pattern
												busSelects, // object selects
												null, // relationship selects
												false, // to direction
												true, // from direction
												(short) 1, // recursion level
												sWhere, // object where clause
												null); // relationship where clause
			if (sList.size() == 1) {
				Map objMap = (Map) sList.get(0);
				sTSId = (String) objMap.get(DomainConstants.SELECT_ID);
				sTSName = (String) objMap.get(DomainConstants.SELECT_NAME);
			}
			
			sb = new StringBuilder();
			sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+sTSId+"','600','400','false')\" >");            
			sb.append(sTSName);
			sb.append("</a>");
		} catch(Exception e) {
			e.printStackTrace();
		} 
		return sb.toString();
	}
	
	public String getDCSRouteField(Context context,String[] args) throws Exception {
		StringBuilder sb= null;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			String strCurrent = DomainConstants.EMPTY_STRING;
			String strObjId = DomainConstants.EMPTY_STRING;
			String strObjName = DomainConstants.EMPTY_STRING;
			MapList mlExtRoutes = null;
			String sWhere = DomainConstants.EMPTY_STRING;
			Map oMap = null;
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add(DomainConstants.SELECT_ORIGINATED);
			
			DomainObject doObject = new DomainObject(sObjectId);
			strCurrent = doObject.getInfo(context, DomainConstants.SELECT_CURRENT);
			
			if ("Create".equals(strCurrent)) {
				sWhere = "current != Complete";
				mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
													DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
													DomainConstants.TYPE_ROUTE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
				sb = new StringBuilder();
				if (mlExtRoutes.size() == 1) {
					String strURL="../common/emxTree.jsp";
					oMap = (Map) mlExtRoutes.get(0);
					strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
					strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
					sb.append(strObjName);
					sb.append("</a>");
				} else if (mlExtRoutes.size() == 0) {
					String strURL="../wms/wmsRouteCreationDialogFS.jsp?wmsSearch=organization";
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"%26objectId="+sObjectId+"','600','400','false');\" >");            
					sb.append("<img border='0' title='Route' src='../common/images/iconSmallRoute.png' height='15px' name='Route' id='Route' alt='Route'/>");
					sb.append("</a>");
				}
			} else {
				mlExtRoutes = doObject.getRelatedObjects(context, // matrix context
													DomainConstants.RELATIONSHIP_OBJECT_ROUTE, // relationship pattern
													DomainConstants.TYPE_ROUTE, // type pattern
													busSelects, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													null, // object where clause
													null); // relationship where clause
				mlExtRoutes.sort("originated", "descending", "date");
				sb = new StringBuilder();
				if (mlExtRoutes.size() > 0) {
					String strURL="../common/emxTree.jsp";
					oMap = (Map) mlExtRoutes.get(0);
					strObjId = (String) oMap.get(DomainConstants.SELECT_ID);
					strObjName = (String) oMap.get(DomainConstants.SELECT_NAME);
					sb.append("<a href=\"javascript:showModalDialog('"+strURL+"?objectId="+strObjId+"','600','400','false');\" >");            
					sb.append(strObjName);
					sb.append("</a>");
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
	
	public String getDCSMasterTotalAmountField (Context context,String[] args)throws Exception {
		DecimalFormat df = new DecimalFormat("0.00");
		double dAmount = 0;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			dAmount = WMSUtil_mxJPO.getPart1MasterTotalAmount(context, new String[]{sObjectId, RELATIONSHIP_WMSDCSMASTER_DCS, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
			
			return df.format(dAmount);
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
	
	public String getAssociatedTSEditField (Context context,String[] args)throws Exception {
		String sTSName = DomainConstants.EMPTY_STRING;
		String sTSId = DomainConstants.EMPTY_STRING;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap requestMap = (HashMap) programMap.get("requestMap");
            String sObjectId = (String) requestMap.get("objectId");
			
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);
			String sWhere = "revision==last";
			
			DomainObject doObject = new DomainObject(sObjectId);
			MapList sList = doObject.getRelatedObjects(context, // matrix context
												RELATIONSHIP_WMSDCSTS, // relationship pattern
												TYPE_WMSTECHNICALSANCTION, // type pattern
												busSelects, // object selects
												null, // relationship selects
												false, // to direction
												true, // from direction
												(short) 1, // recursion level
												sWhere, // object where clause
												null); // relationship where clause
			if (sList.size() == 1) {
				Map objMap = (Map) sList.get(0);
				sTSId = (String) objMap.get(DomainConstants.SELECT_ID);
				sTSName = (String) objMap.get(DomainConstants.SELECT_NAME);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		} 
		return sTSName;
	}
	
	/**
    ** This Method connect DCS Master object to New TS.
    */
	@com.matrixone.apps.framework.ui.CellUpdateJPOCallable
    public void connectNewTS(Context context, String[] args)throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			HashMap paramMap = (HashMap) programMap.get("paramMap");
						
			String sObjectId = (String) paramMap.get("objectId");
			String sAssociatedTSId = (String) paramMap.get("New OID");
						
			DomainObject domObject = new DomainObject(sObjectId);
			String sTSRelId = domObject.getInfo(context, "from["+RELATIONSHIP_WMSDCSTS+"].id");
			if (UIUtil.isNotNullAndNotEmpty(sTSRelId)) {				
				DomainRelationship.disconnect(context, sTSRelId);
			}
			
			if (UIUtil.isNotNullAndNotEmpty(sAssociatedTSId)) {
				DomainRelationship.connect(context, sObjectId, RELATIONSHIP_WMSDCSTS, sAssociatedTSId, false);
			}
			
		} catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
		
 }