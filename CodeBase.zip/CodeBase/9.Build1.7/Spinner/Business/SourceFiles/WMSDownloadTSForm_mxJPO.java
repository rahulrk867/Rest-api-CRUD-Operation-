/*---------------------------------------------------------------------------------------------------------------
NAME		: ${CLASSNAME}.java

DESCRIPTION	: Purpose of JPO is to generate PDF for Technical Sanction

CREATED		: August 13 2019

AUTHOR		: Divyashree B K

HISTORY		:

	Divyashree B K	13-08-2019		Initial version
------------------------------------------------------------------------------------------------------------------*/
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.LicenseUtil;
import matrix.util.StringList;
import matrix.db.MQLCommand;
import java.math.RoundingMode;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.util.Map;
import java.util.Iterator;
import java.util.Date;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.io.*;
import java.text.SimpleDateFormat;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.program.ProgramCentralConstants;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXResult;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.OutputKeys;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.util.XMLResourceDescriptor;
import org.apache.fop.apps.FOUserAgent;
import org.apache.fop.apps.Fop;
import org.apache.fop.apps.FopFactory;
import org.apache.fop.apps.MimeConstants;
import org.apache.poi.util.Units;
import java.math.BigDecimal;
import org.joda.time.LocalDate;



public class WMSDownloadTSForm_mxJPO extends WMSConstants_mxJPO {
	
	/**
	* Constructor.
	*
	* @param context the eMatrix <code>Context</code> object.
	* @param args holds no arguments.
	* @throws Exception if the operation fails.
	* @since EC 9.5.JCI.0.
	**/
	public WMSDownloadTSForm_mxJPO (Context context, String[] args) throws Exception {
	  super(context, args);
	}
		
	public static void generateTSForm(Context context,String[] args) throws Exception{
		try{
			String strHeader = DomainConstants.EMPTY_STRING;
			String strObjID = args[0];		
			Map mTSDetails = getTSDetails(context,strObjID);
			MapList mTSTableDetails = getTSTableDetails(context, args);
			String strTransPath = context.createWorkspace();
			String xmlSourceFileName = "TSFormSource.xml";
			String xmlFilePath = strTransPath + File.separator+xmlSourceFileName;
			String sTSName = null;
			String sStation = null;
			String sProjectName = null;
			String sSubProjectName = null;
			String sAuthority = null;
			String sDated = null;
			String sDept = null;
			String sTSAmount = null;
			String sAdminApprovalAmount = null;
			String sWorkAmount = null;
			String sAmountInWords = null;
			String sPreviousTSAmount = null;
			String sIncludingALLTS = null;
			String sCheif = null;
			String sOrganization = null;
			String sAALetterNo = null;
			String sAADate = null;
		
			
			
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
			Document document = documentBuilder.newDocument();
			Element root = document.createElement("page");
			document.appendChild(root);
			String strpath = System.getProperty("user.dir");
		    File newFile = new File(strpath+"/..");
			
			String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
			String strLogo = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Logo");
			String strWatermark = newFile.getCanonicalPath()+strImageFolder+EnoviaResourceBundle.getProperty(context,"WMS.Host.Watermark");
			strWatermark = strWatermark.replace("\\", "/");
			strLogo = strLogo.replace("\\", "/");
			Element embLogo = document.createElement("logo1");
			embLogo.appendChild(document.createTextNode("file:"+strLogo));
		
			Element embHeader = document.createElement("header-footer");
			Element embWatermark = document.createElement("watermark");
			embWatermark.appendChild(document.createTextNode("file:"+strWatermark));
			strHeader = "Technical Sanction";
			embHeader.appendChild(document.createTextNode(strHeader));
			root.appendChild(embHeader);
			root.appendChild(embWatermark);
			root.appendChild(embLogo);
			
			
			
			if(mTSDetails != null)
			{
				 sTSName = (String)mTSDetails.get("TSname");
				 sTSName = "Technical Sanction:"+sTSName;
				 sStation = (String)mTSDetails.get("station");
				 sProjectName = (String)mTSDetails.get("projectName");
				 sSubProjectName = (String)mTSDetails.get("subProjectName");				 
				 sAuthority = (String)mTSDetails.get("authority");
				 sDept = (String)mTSDetails.get("dept");
				 sDated = (String)mTSDetails.get("dated");
				 sTSAmount = (String)mTSDetails.get("AmountFromTS");
				 sAdminApprovalAmount = (String)mTSDetails.get("AdminApprovedAmount");
				 sWorkAmount = (String)mTSDetails.get("AdminApprovedWorkAmount");		
                 sAmountInWords = WMSUtil_mxJPO.getValueInWords(sTSAmount);
				 sPreviousTSAmount = (String)mTSDetails.get("TotalPerviousTSAmount");
				 sIncludingALLTS = (String)mTSDetails.get("TotalTSAmountIncluding");
				 sCheif = (String)mTSDetails.get("CheifEngg");
				 sOrganization = (String)mTSDetails.get("Organization");
				 sAALetterNo = (String)mTSDetails.get("AALetterNo");
				 sAADate = (String)mTSDetails.get("AADate");
				 
			}		
			

			Element heading2 = document.createElement("heading2");
			Element station = document.createElement("basic-Station");
			Element nameOfProject = document.createElement("basic-name-of-project");
			Element nameOfSubProject = document.createElement("basic-name-of-sub-project");
			Element authority = document.createElement("basic-authority");
			Element dept = document.createElement("basic-Depts");
			Element dated = document.createElement("basic-Dated");
			Element amountTSAmount = document.createElement("basic-amount-cost-schedule-work");
			Element amountTSAmountInWords = document.createElement("basic-amount-cost-schedule-work-InWords");
			Element amountDelegatedToWork = document.createElement("amount-delgated-to-work");
			Element adminApprovalAmount = document.createElement("admin-approval-amount");
			Element amounofPreviousTS = document.createElement("total-amount-previous-ts");
			Element amountofAllTS = document.createElement("total-amount-All-ts");
			Element cheifengg = document.createElement("Cheif-Engg");
			Element sAAletterNo = document.createElement("AA-Letter-No");
			Element sAAdate = document.createElement("AA-Date");
			
			Element distribution = document.createElement("basic-Distribution");
			Element internal = document.createElement("basic-Internal");
			Element TSFile = document.createElement("basic-TSFile");
			Element folder = document.createElement("basic-Folder");
			
			folder.appendChild(document.createTextNode(""));
		    root.appendChild(folder);
			
			internal.appendChild(document.createTextNode(""));
		    root.appendChild(internal);
			
			distribution.appendChild(document.createTextNode(""));
		    root.appendChild(distribution);
			
			TSFile.appendChild(document.createTextNode(""));
		    root.appendChild(TSFile);
			
			
			heading2.appendChild(document.createTextNode(sTSName));
		    root.appendChild(heading2);
			
			nameOfProject.appendChild(document.createTextNode(sProjectName));
			root.appendChild(nameOfProject);
			
			nameOfSubProject.appendChild(document.createTextNode(sSubProjectName));
			root.appendChild(nameOfSubProject);
			
			cheifengg.appendChild(document.createTextNode(sCheif));
			root.appendChild(cheifengg);
			
			sAAletterNo.appendChild(document.createTextNode(sAALetterNo));
			root.appendChild(sAAletterNo);
			
			sAAdate.appendChild(document.createTextNode(sAADate));
			root.appendChild(sAAdate);
			
			authority.appendChild(document.createTextNode(sAuthority));
			root.appendChild(authority);
			
			dept.appendChild(document.createTextNode(sDept));
			root.appendChild(dept);
			
			dated.appendChild(document.createTextNode(sDated));
			root.appendChild(dated);
			
			station.appendChild(document.createTextNode(sStation));
			root.appendChild(station);
			
			double dTSAmount = Double.valueOf(sTSAmount);
			sTSAmount = WMSUtil_mxJPO.converToIndianCurrency(context,dTSAmount);
			
			amountTSAmount.appendChild(document.createTextNode(sTSAmount));
			root.appendChild(amountTSAmount);
			
			amountTSAmountInWords.appendChild(document.createTextNode(sAmountInWords));
			root.appendChild(amountTSAmountInWords);
			
			
			String sAETotal =null;
			double dAETotal =0;
			String sAEThisTSTotal = null;
			double dAEThisTSTotal = 0;
			String sAmountUptoThisTSToatl = null;
			double dAmountUptoThisTSToatl = 0;
			for(int i =0;i<mTSTableDetails.size(); i++)
			{
				Map mTSData = (Map)mTSTableDetails.get(i);
				Element tsItems = document.createElement("ts-details");
				Element tsSequence = document.createElement("sequence");
				Element tsItem = document.createElement("item");
				Element tsAmountOfAE = document.createElement("amount-of-ae");
				Element tsAmountOfThisTs = document.createElement("amount-of-this-ts");
				Element tsAmountuptoThisTS = document.createElement("amount-upto-including-ts");
				Element tsRemarks = document.createElement("remarks");
				
				String strSequence = (String)mTSData.get("Sequence");
				String strItem = (String)mTSData.get("item");
				String strAEAmount = (String)mTSData.get("AEAmount");
				String strTSAmount = (String)mTSData.get("TSAmount");
				String strTotalTSAmount = (String)mTSData.get("TotalTSAmount");
				String strRemarks = (String)mTSData.get("TotalTSAmount");
				
				
				dAETotal+= Double.parseDouble(strAEAmount);
			    dAEThisTSTotal+= Double.parseDouble(strTSAmount);
				dAmountUptoThisTSToatl+= Double.parseDouble(strTotalTSAmount);
				
				tsSequence.appendChild(document.createTextNode(strSequence));
				tsItem.appendChild(document.createTextNode(strItem));
				tsAmountOfAE.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strAEAmount))));				
				tsAmountOfThisTs.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strTSAmount))));
				tsAmountuptoThisTS.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,Double.valueOf(strTotalTSAmount))));
				
				tsRemarks.appendChild(document.createTextNode(""));
				
				tsItems.appendChild(tsSequence);
				tsItems.appendChild(tsItem);
				tsItems.appendChild(tsAmountOfAE);
				tsItems.appendChild(tsAmountOfThisTs);
				tsItems.appendChild(tsAmountuptoThisTS);
				tsItems.appendChild(tsRemarks);
				root.appendChild(tsItems);
				
			}
				Element tsTotalAmountOfAE = document.createElement("total-amount-of-ae");
				Element tsTotalAmountOfThisTs = document.createElement("total-amount-of-this-ts");
				Element tsTotalAmountuptoThisTS = document.createElement("total-amount-upto-including-ts");
				
				tsTotalAmountOfAE.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dAETotal)));
			    root.appendChild(tsTotalAmountOfAE);
				
				tsTotalAmountOfThisTs.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dAEThisTSTotal)));
			    root.appendChild(tsTotalAmountOfThisTs);
				
				tsTotalAmountuptoThisTS.appendChild(document.createTextNode(WMSUtil_mxJPO.converToIndianCurrency(context,dAmountUptoThisTSToatl)));
			    root.appendChild(tsTotalAmountuptoThisTS);
			
			    
			if(mTSTableDetails.size()==0){
			Element tsItems = document.createElement("ts-details");
			Element tsSequence = document.createElement("sequence");
			Element tsItem = document.createElement("item");
			Element tsAmountOfAE = document.createElement("amount-of-ae");
			Element tsAmountOfThisTs = document.createElement("amount-of-this-ts");
			Element tsAmountuptoThisTS = document.createElement("amount-upto-including-ts");
			Element tsRemarks = document.createElement("remarks");
			
			tsSequence.appendChild(document.createTextNode(""));
			tsItem.appendChild(document.createTextNode(""));
			tsAmountOfAE.appendChild(document.createTextNode(""));
			tsAmountOfThisTs.appendChild(document.createTextNode(""));
			tsAmountuptoThisTS.appendChild(document.createTextNode(""));
			tsRemarks.appendChild(document.createTextNode(""));
			
			tsItems.appendChild(tsSequence);
			tsItems.appendChild(tsItem);
			tsItems.appendChild(tsAmountOfAE);
			tsItems.appendChild(tsAmountOfThisTs);
			tsItems.appendChild(tsAmountuptoThisTS);
			tsItems.appendChild(tsRemarks);
			root.appendChild(tsItems);
			
		    }
			
			
			adminApprovalAmount.appendChild(document.createTextNode(sAdminApprovalAmount));
			root.appendChild(adminApprovalAmount);
			
			amountDelegatedToWork.appendChild(document.createTextNode(sWorkAmount));
			root.appendChild(amountDelegatedToWork);
			
			amounofPreviousTS.appendChild(document.createTextNode(sPreviousTSAmount));
			root.appendChild(amounofPreviousTS);
			
			amountofAllTS.appendChild(document.createTextNode(sIncludingALLTS));
			root.appendChild(amountofAllTS);
			
			
			
           
		    TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domSource = new DOMSource(document);	
			StreamResult streamResult = new StreamResult(new File(xmlFilePath));
			transformer.transform(domSource, streamResult);
			
			File xmlFile = new File(xmlFilePath);

			//Write XML - End
		
			//Write XSL - Start
			String strXSLFile = "FormTSSource.xsl";
			File newTextFile = new File(strTransPath + File.separator+strXSLFile);


			String strPlanningOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Planning");
			String strWorksOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Works");
			String strEqupmentsOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Equipments");
			
			
			String strXSLName = "";
			if(sOrganization.equals(strPlanningOrgName) || sOrganization.equals(strWorksOrgName))
			{			
				strXSLName = "WMSTechnicalSanctionFormWorks.xsl";			
			}
			if(sOrganization.equals(strEqupmentsOrgName)){
				strXSLName = "WMSTechnicalSanctionFormEquipment.xsl";		
			}

			MQLCommand mql = new MQLCommand();
			mql.open(context);
			mql.executeCommand(context, "print program "+strXSLName+" select code dump");
			mql.close(context);
			FileWriter fw = new FileWriter(newTextFile);
			fw.write(mql.getResult());
			fw.close();
			//Write XSL - End				
			
			File xsltFile = new File(strTransPath + File.separator+strXSLFile);
			// the XML file which provides the input
			StreamSource xmlSource = new StreamSource(new File(xmlFilePath));
			// create an instance of fop factory
			// Setup output
			
			//LocalDate ldToday=new LocalDate();
            //String strTime = ldToday.toString();
			String strName = "TechnicalSanction";
			String strFileName = strName+".pdf";
			OutputStream out;
			out = new java.io.FileOutputStream(strTransPath+File.separator+strFileName);
			try {
				FopFactory fopFactory = FopFactory.newInstance(new File(".").toURI());
				// a user agent is needed for transformation
				FOUserAgent foUserAgent = fopFactory.newFOUserAgent();
				// Construct fop with desired output format
				Fop fop = fopFactory.newFop(MimeConstants.MIME_PDF, foUserAgent, out);

				// Setup XSLT
				TransformerFactory factory = TransformerFactory.newInstance();
				Transformer transformer1 = factory.newTransformer(new StreamSource(xsltFile));
				//xsltFile.delete();
				// Resulting SAX events (the generated FO) must be piped through to FOP
				Result res = new SAXResult(fop.getDefaultHandler());
				// Start XSLT transformation and FOP processing
				// That's where the XML is first transformed to XSL-FO and then 
				// PDF is created
				transformer1.transform(xmlSource, res);
			} finally {
				    File file1 = new File(strTransPath+File.separator+strFileName);			
					DomainObject dObject = DomainObject.newInstance(context,strObjID);
					ContextUtil.pushContext(context);
					dObject.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strTransPath);
					ContextUtil.popContext(context);
				if(file1.delete())
				{
					System.out.println("File deleted successfully");
				}
				else
				{
					System.out.println("Failed to delete the file");
				}
				if(newTextFile.delete())
				{
					System.out.println("File deleted successfully");
				}
				else
				{
					System.out.println("Failed to delete the file");
				}
				if(xmlFile.delete())
				{
					System.out.println("File deleted successfully");
				}
				else
				{
					System.out.println("Failed to delete the file");
				}
				out.close();
			}
				
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static Map getTSDetails(Context context,String strObjID)throws Exception
	{
		Map mTSMap = new HashMap();
		try{
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
			DecimalFormat df = new DecimalFormat("0.00");
			DomainObject dObj = new DomainObject(strObjID);
			
			String strPlanningOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Planning");
			String strWorksOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Works");
			String strEqupmentsOrgName =  EnoviaResourceBundle.getProperty(context,"WMS.OrganizationName.Equipments");
			
			//to get DSC Owner and his organization
			StringList busSelects = new StringList();
			String sDept = null;
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_OWNER);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add("attribute[Title].value");
			MapList slDCSMaster = dObj.getRelatedObjects(context, RELATIONSHIP_WMSDCSTS, "*", busSelects, null, true, false, (short)0, null, null,0,null,null,null);
			slDCSMaster.sort("originated", "descending", "date");
			Map mDCSMap = (Map)slDCSMaster.get(0);
			String sDCSOwner  = (String)mDCSMap.get(DomainConstants.SELECT_OWNER);	
			String sDCSName  = (String)mDCSMap.get(DomainConstants.SELECT_NAME);	
			String sDCSTitle  = (String)mDCSMap.get("attribute[Title].value");	
			String defaultOrg = PersonUtil.getDefaultOrganization(context, sDCSOwner);
			if(defaultOrg.equals(strPlanningOrgName) || defaultOrg.equals(strWorksOrgName))
			{
				sDept = "DG/        /        /Wks";
			}
			if(defaultOrg.equals(strEqupmentsOrgName)){
				sDept = "DG/       /         /Eqpt";
			}
			//String sTSName = dObj.getInfo(context,"name");
			String sTSName = (String)dObj.getAttributeValue(context,"WMSTSNumber");
			String sOwner = (String)dObj.getInfo(context,DomainConstants.SELECT_OWNER);
			String sDated = (String)dObj.getInfo(context,DomainConstants.SELECT_ORIGINATED);
			
			if(UIUtil.isNotNullAndNotEmpty(sOwner)){
				sOwner = MqlUtil.mqlCommand(context,"print person '"+sOwner+"' select fullname dump");
			}
			
			Date date1 = eMatrixDateFormat.getJavaDate(sDated);
			sDated = dateFormat.format(date1);
			//5. Amount as per the Costed Schedule of Work
			String sAmount =dObj.getInfo(context,"attribute["+ATTRIBUTE_WMSTSAMOUNT+"]");
			String sSOCId = dObj.getInfo(context,"to["+RELATIONSHIP_WMSSOCTS+"].from.id");
			DomainObject dsocObj = new DomainObject(sSOCId);
			StringList objectSelectable = new StringList();
			objectSelectable.add("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.name");
			objectSelectable.add("from["+RELATIONSHIP_WMSSOCDELEGATION+"].to.attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
			
			String sWhere = "revision == last";			
			StringList selects = new StringList(1);
			String strAmount = "";
			String strAADate = "";
			String AAdate = "";
			String strAALetterNo = "";
			selects.add(DomainObject.SELECT_ID);
			selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
			selects.add("attribute["+ATTRIBUTE_WMSADMINAPPROVALDATE+"]");
			selects.add("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
			MapList AAList = dsocObj.getRelatedObjects(context, RELATIONSHIP_WMSSOCADMINAPPROVAL, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
			//System.out.println("--------AAList---------"+AAList);
				if(AAList.size()>0)
				{
					Map mAA = (Map)AAList.get(0);
					//String sAA =(String)mAA.get("id");
					//DomainObject objAA = DomainObject.newInstance(context, sAA);
					//strAmount = objAA.getAttributeValue(context,"attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
					strAmount = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALAMOUNT+"]");
					strAADate = (String)mAA.get("attribute["+ATTRIBUTE_WMSADMINAPPROVALDATE+"]");
					SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(strAADate);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				AAdate = (dt1.format(date));
				//mMap.put("DateFormat", (dt1.format(date))+"");
					strAALetterNo = (String)mAA.get("attribute["+ATTRIBUTE_WMS_LETTER_NUMBER+"]");
				}
				String sAADate = AAdate + ", ";
				String sAALetterNo = strAALetterNo + ", ";
				
			Map sSOCList = dsocObj.getInfo(context,objectSelectable);
			
			//2. Name of the Project: 
			String sProjectName = (String)sSOCList.get("to["+RELATIONSHIP_WMSPROJECTSOC+"].from.name");
			//1. Amount of A/A for the whole project 
			if(UIUtil.isNullOrEmpty(strAmount))
			{
				strAmount = "0";
			}
			String sAdminApprovalAmount = strAmount;
			//2. Amount Delegated for DDG & CE 
			String sWorkAmount = "0.00";
			String sCheif = "";
			double dEquipmentAmount = 0.0;
			double dWorksAmount = 0.0;
			double dPlanningAmount = 0.0;
				
			double dEquipmentContAmount = 0.0;
			double dWorksContAmount = 0.0;
			double dPlanningContAmount = 0.0;
			//(String)sSOCList.get("from["+RELATIONSHIP_WMSSOCDELEGATION+"].to.attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
			selects.add("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
			selects.add("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
			selects.add("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
			selects.add("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
			selects.add("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
			selects.add("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
			selects.add("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
			
			MapList mlDelList = dsocObj.getRelatedObjects(context, RELATIONSHIP_WMSSOCDELEGATION, "*", selects, null, false, true, (short)0, sWhere, null,0,null,null,null);
			if(mlDelList.size()==1){
				Map mDelInfo = (Map)mlDelList.get(0);
				//sWorkAmount = (String)mDelInfo.get("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
				String strWorksAmount = (String)mDelInfo.get("attribute["+ATTRIBUTE_WMSAPPROVEDWORK+"]");
				String strEquipAmount = (String)mDelInfo.get("attribute["+ATTRIBUTE_WMSAPPROVEDEQUIPMENT+"]");
				String strPlanAmount = (String)mDelInfo.get("attribute["+ATTRIBUTE_WMSAPPROVEDPLANNING+"]");
				String strWorksCont = (String)mDelInfo.get("attribute["+ATTRIBUTE_WMS_WORKS_CONTINGENCY+"]");
				String strEquipCont = (String)mDelInfo.get("attribute["+ATTRIBUTE_WMS_EQUIPMENTS_CONTINGENCY+"]");
				String strPlanCont = (String)mDelInfo.get("attribute["+ATTRIBUTE_WMS_PLANNING_CONTINGENCY+"]");
						dEquipmentAmount = Double.valueOf(strEquipAmount);
						dWorksAmount = Double.valueOf(strWorksAmount);
						dPlanningAmount = Double.valueOf(strPlanAmount);
						dEquipmentContAmount = Double.valueOf(strEquipCont);
						dWorksContAmount = Double.valueOf(strWorksCont);
						dPlanningContAmount = Double.valueOf(strPlanCont);
			}
			double dWorksTotal = 0.0;
				double dEquipmentTotal = 0.0;
				
				dWorksTotal = dWorksAmount+dWorksContAmount;
				dEquipmentTotal = dEquipmentAmount+dEquipmentContAmount;
				String strWorksTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dWorksTotal);
				String strEquipmentTotal = WMSUtil_mxJPO.converToIndianCurrency(context,dEquipmentTotal);
			
			if(defaultOrg.equals(strPlanningOrgName) || defaultOrg.equals(strWorksOrgName))
			{			
			strWorksTotal = strWorksTotal;
			sWorkAmount=strWorksTotal;
			sCheif=" DDG and CE";
			
			}
			if(defaultOrg.equals(strEqupmentsOrgName)){
			strEquipmentTotal = strEquipmentTotal;
			sWorkAmount=strEquipmentTotal;
				sCheif="DDGE";
			}
			
			//get details from DCS
			String sDCSId = dObj.getInfo(context,"to["+RELATIONSHIP_WMSDCSTS+"].from.id");		
			DomainObject dDCSMObj = new DomainObject(sDCSId);
			//1. Station: 
			String sStation = dDCSMObj.getInfo(context,"attribute[WMSStation]");
			double sdoubelAmount =0;
			sdoubelAmount= Double.parseDouble(sAmount);
			double sAdminApprovaldoubelAmount =0;
			sAdminApprovaldoubelAmount= Double.parseDouble(sAdminApprovalAmount);
			mTSMap.put("TSname",sTSName);
			mTSMap.put("station",sStation);
			mTSMap.put("projectName",sProjectName);
			mTSMap.put("subProjectName",sDCSTitle);
			mTSMap.put("authority",sOwner);
			mTSMap.put("dept",sDept);
			mTSMap.put("dated",sDated);
			mTSMap.put("AmountFromTS",sAmount);
			mTSMap.put("AdminApprovedAmount",WMSUtil_mxJPO.converToIndianCurrency(context,sAdminApprovaldoubelAmount));
			mTSMap.put("AdminApprovedWorkAmount",WMSDCSPart2Export_mxJPO.getDelegationDetails(context, (String)((Map)mlDelList.get(0)).get("id"),dDCSMObj.getInfo(context,"owner")));
			//mTSMap.put("AdminApprovedWorkAmount",sWorkAmount);
			mTSMap.put("CheifEngg",sCheif);
			mTSMap.put("Organization",defaultOrg);
			mTSMap.put("AALetterNo",sAALetterNo);
			mTSMap.put("AADate",sAADate);
			
			
			sWhere = "revision==last && current== Approved && attribute[WMSTSDepartment]=='"+defaultOrg+"'";
			StringList busSelects1 = new StringList();
			busSelects1.add(DomainConstants.SELECT_ID);
			busSelects1.add("attribute["+ATTRIBUTE_WMSTSAMOUNT+"].value");
			
			double sTotalPerviousTSAmount = 0;
			
			MapList sListTS = dsocObj.getRelatedObjects(context, // matrix context
													RELATIONSHIP_WMSSOCTS, // relationship pattern
													TYPE_WMSTECHNICALSANCTION, // type pattern
													busSelects1, // object selects
													null, // relationship selects
													false, // to direction
													true, // from direction
													(short) 1, // recursion level
													sWhere, // object where clause
													null); // relationship where clause
													System.out.println("sListTS--"+sListTS);
			for (int i=0; i<sListTS.size(); i++) {
				Map mMap = (Map) sListTS.get(i);
				sTotalPerviousTSAmount = Double.parseDouble((String) mMap.get("attribute["+ATTRIBUTE_WMSTSAMOUNT+"].value"));				
			}
			mTSMap.put("TotalPerviousTSAmount",WMSUtil_mxJPO.converToIndianCurrency(context,sTotalPerviousTSAmount));
			mTSMap.put("TotalTSAmountIncluding",WMSUtil_mxJPO.converToIndianCurrency(context,sTotalPerviousTSAmount+sdoubelAmount));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("------mTSMap"+mTSMap);
		return mTSMap;
		
	}
	public static MapList getTSTableDetails(Context context,String[] args)throws Exception
	{
		MapList mlTableData = new MapList();
		try{
			String sID = args[0];
			//get details of connected AE
			DecimalFormat df = new DecimalFormat("0.00");
			DomainObject dTSObj = new DomainObject(sID);

			//String sDCSMaster = dTSObj.getInfo(context, "to["+RELATIONSHIP_WMSDCSTS+"].from.id");
		    StringList slDCSMaster = dTSObj.getInfoList(context, "to["+RELATIONSHIP_WMSDCSTS+"].from.id");
			for(int k=0; k<slDCSMaster.size(); k++) {
				String sDCSMaster = (String)slDCSMaster.get(k);
				DomainObject dDCSMasterObj = new DomainObject(sDCSMaster);
				StringList sList = dDCSMasterObj.getInfoList(context, "from["+RELATIONSHIP_WMSDCSMASTER_DCS+"].to.id");
				String sSOCId = dTSObj.getInfo(context,"to["+RELATIONSHIP_WMSSOCTS+"].from.id");

				String sAEName = null;
				String sSequence = null;
				String sAEID = null;
				double sAEAmount = 0;
				double sTSAmount = 0;
				double dTempAmount = 0;
				double sTotalTSAmount = 0;
				Map oMap = null;
				
				for(int i=0; i<sList.size(); i++) {
					dTempAmount = 0;
					String sDcsId = (String)sList.get(i);
					DomainObject dDCSObj = new DomainObject(sDcsId);
					StringList busSelects = new StringList();
					busSelects.add("from["+RELATIONSHIP_WMSDCS_AE+"].to.attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
					busSelects.add("from["+RELATIONSHIP_WMSDCS_AE+"].to."+DomainConstants.SELECT_ID);
					busSelects.add("from["+RELATIONSHIP_WMSDCS_AE+"].to.attribute["+ATTRIBUTE_TITLE+"].value");
					Map mMap = dDCSObj.getInfo(context, busSelects);
					sAEID = (String)mMap.get("from["+RELATIONSHIP_WMSDCS_AE+"].to."+DomainConstants.SELECT_ID);
					sAEName = (String)mMap.get("from["+RELATIONSHIP_WMSDCS_AE+"].to.attribute["+ATTRIBUTE_TITLE+"].value");
					sSequence = (String)mMap.get("from["+RELATIONSHIP_WMSDCS_AE+"].to.attribute["+ATTRIBUTE_WMSITEMSEQUENCE+"].value");
					sAEAmount = WMSUtil_mxJPO.getPart1HeadTotalAmount(context, new String[]{sAEID, RELATIONSHIP_WMSAE_AE, RELATIONSHIP_WMSAE_AEITEM});
					sTSAmount = WMSUtil_mxJPO.getHeadTotalAmount(context, new String[]{sDcsId, RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
					DomainObject domAE = new DomainObject(sAEID);
					StringList slConnectedDCS = domAE.getInfoList(context, "to["+RELATIONSHIP_WMSDCS_AE+"].from.id");
					
					for (int l=0; l<mlTableData.size(); l++) {
						Map objMap = (Map)mlTableData.get(l);
						String objName = (String) objMap.get("item");
						if (objName.equals(sAEName)) {
							String objTSAmount = (String) objMap.get("TSAmount");
							sTSAmount = sTSAmount + Double.parseDouble(objTSAmount);
							mlTableData.remove(objMap);
						}
					}
					
					for (int j=0; j<slConnectedDCS.size(); j++) {
						 
						dTempAmount = dTempAmount + WMSUtil_mxJPO.getHeadTotalAmount(context, new String[]{(String)slConnectedDCS.get(j), RELATIONSHIP_WMSDCS_DCS, RELATIONSHIP_WMSDCS_DCSITEM});
					}
					sTotalTSAmount = dTempAmount;
										
					oMap = new HashMap();
					oMap.put("Sequence", sSequence);
					oMap.put("item", sAEName);
					oMap.put("AEAmount",df.format(sAEAmount));
					oMap.put("TSAmount", df.format(sTSAmount));
					oMap.put("TotalTSAmount",df.format(sTotalTSAmount));
					mlTableData.add(oMap);
				}	
			}		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return mlTableData;
	}
}
 