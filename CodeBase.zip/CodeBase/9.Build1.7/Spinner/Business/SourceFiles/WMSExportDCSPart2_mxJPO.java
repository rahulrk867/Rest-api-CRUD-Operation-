import java.io.File;
import java.util.HashMap;
import java.util.Map;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.FrameworkUtil;

import com.itextpdf.io.image.ImageData; 
import com.itextpdf.io.image.ImageDataFactory; 
import com.itextpdf.kernel.pdf.PdfDocument; 
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Image; 
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.layout.Document; 
import com.itextpdf.layout.element.Cell; 
import com.itextpdf.layout.element.Table;  
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.Property;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.VerticalAlignment;
import com.itextpdf.layout.property.HorizontalAlignment;

import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.WebColors;
import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;

public class WMSExportDCSPart2_mxJPO extends WMSConstants_mxJPO {

	public WMSExportDCSPart2_mxJPO(Context context,String[] args) {
		super(context,args);
	}
	public HashMap generateCostSchedulePDF(Context context, String[] args) throws Exception 
	{
		//String strTSId = args[1];
		Map mInputMap = (Map) JPO.unpackArgs(args);
		String strTSId = (String)mInputMap.get("TSId");
		
		DomainObject doTS = DomainObject.newInstance(context, strTSId);
		String strTransPath = context.createWorkspace();
		String strFileName = "CostSchedule-"+(String)doTS.getInfo(context,"name")+".pdf";
		String dest = strTransPath+File.separator+strFileName;
		
		String strTSNumber = doTS.getInfo(context,"attribute[WMSTSNumber].value");
		StringList slTSNumber = FrameworkUtil.split(strTSNumber,"-");

		//get data
		HashMap hmObjDetails = new HashMap();
		hmObjDetails.put("objectId", strTSId);
		HashMap hmDetails = (HashMap)JPO.invoke(context, "WMSDCSPart2Export", null, "getDCSPart2Details", JPO.packArgs(hmObjDetails), HashMap.class);

		// Creating a PdfDocument
		PdfDocument pdf = new PdfDocument(new PdfWriter(dest));
		// Creating a Document
		Document document = new Document(pdf, PageSize.A4.rotate(), false);

		//adding DGNP logo
		String imgFile = getImgFile(context);
		ImageData imgdata = ImageDataFactory.create(imgFile);
		Image image = new Image(imgdata);
		image.setTextAlignment(TextAlignment.CENTER);
		document.add(image);
		
		//add space
		document.add(new Paragraph(""));
		
		//add headers
		Paragraph p = new Paragraph("COSTED SCHEDULE OF WORK")
									.setTextAlignment(TextAlignment.CENTER)
									.setFontSize(14)
									.setUnderline(0.1f, -2f);
		document.add(p);
		Paragraph p2 = new Paragraph("Technical Sanction - " + (String)slTSNumber.get(1))
									.setTextAlignment(TextAlignment.CENTER)
									.setFontSize(12);
		document.add(p2);
		
		//add space
		document.add(new Paragraph(""));
		
		//adding project details table
		Table details = new Table(UnitValue.createPercentArray(new float[] {3, 6}));
		details.addCell(createCell("1. Name of Project", 0, 1, TextAlignment.LEFT));
		details.addCell(createCell(": "+(String)hmDetails.get("projectname"),0, 1, TextAlignment.LEFT));
		details.addCell(createCell("2. Name of Sub Project", 0, 1, TextAlignment.LEFT));
		details.addCell(createCell(": "+(String)hmDetails.get("subprojectname"), 0, 1, TextAlignment.LEFT));
		details.addCell(createCell("3. AA No., Date & Amount", 0, 1, TextAlignment.LEFT));
		details.addCell(createCell(": "+(String)hmDetails.get("aadetails"), 0, 1, TextAlignment.LEFT));
		details.addCell(createCell("4. Delegation No., Date & Amount", 0, 1, TextAlignment.LEFT));
		details.addCell(createCell(": "+(String)hmDetails.get("deldetails"),0, 1, TextAlignment.LEFT));
		document.add(details);
		document.add(new Paragraph(""));
		//adding items table
		Table table = new Table(UnitValue.createPercentArray(new float[] {1, 2, 5, 1, 1, 2, 1, 2}));
		table.addCell(createCell("#", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("AE Part II No", 1, 1, TextAlignment.CENTER).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Description", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Unit", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Qty", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Rate", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("GST", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell("Amount", 1, 1, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		
		MapList mlItemDetails = (MapList)hmDetails.get("itemdetails");
		double dTotal = 0.0;
		int iCounter = 1;
		for (int i = 0 ; i < mlItemDetails.size() ; i++)
		{
			String strType = (String)((Map)mlItemDetails.get(i)).get("type");
			if("WMSDCS".equals(strType))
				continue;
			double dQty = Double.valueOf((String)((Map)mlItemDetails.get(i)).get("attribute[Quantity].value"));
			double dRate = Double.valueOf((String)((Map)mlItemDetails.get(i)).get("attribute[Rate].value"));
			double dGST = Double.valueOf((String)((Map)mlItemDetails.get(i)).get("attribute[WMSGST].value"));
			
			double dAmount = dQty * dRate * (1+(dGST/100));
			dTotal += dAmount;
			
			table.addCell(createCell(iCounter+"", 1, 1, TextAlignment.LEFT));
			table.addCell(createCell((String)((Map)mlItemDetails.get(i)).get("attribute[WMSItemSequence].value"), 1, 1, TextAlignment.CENTER));
			table.addCell(createCell((String)((Map)mlItemDetails.get(i)).get("description"), 1, 1, TextAlignment.LEFT));
			table.addCell(createCell((String)((Map)mlItemDetails.get(i)).get("attribute[WMSUnitOfMeasure].value"), 1, 1, TextAlignment.LEFT));
			table.addCell(createCell((String)((Map)mlItemDetails.get(i)).get("attribute[Quantity].value"), 1, 1, TextAlignment.LEFT));
			table.addCell(createCell(WMSUtil_mxJPO.converToIndianCurrency(context, dRate), 1, 1, TextAlignment.LEFT));
			table.addCell(createCell((String)((Map)mlItemDetails.get(i)).get("attribute[WMSGST].value"), 1, 1, TextAlignment.LEFT));
			table.addCell(createCell(WMSUtil_mxJPO.converToIndianCurrency(context, dAmount), 1, 1, TextAlignment.LEFT));
			iCounter++;
		}
		table.addCell(createCell("Totals", 1, 7, TextAlignment.LEFT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		table.addCell(createCell(WMSUtil_mxJPO.converToIndianCurrency(context, dTotal), 1, 1, TextAlignment.RIGHT).setBackgroundColor(WebColors.getRGBColor("#D8D8D8")));
		document.add(table);
		
		//add space
		document.add(new Paragraph(""));
		
		//final value
		String strFinalInWords = WMSUtil_mxJPO.getValueInWords(dTotal+"");
		Paragraph pFinalValue = new Paragraph(strFinalInWords)
											.setTextAlignment(TextAlignment.CENTER)
											.setFontSize(12)
											.setUnderline(0.1f, -2f);
		document.add(pFinalValue);
	
		//add footer
		float width = pdf.getDefaultPageSize().getWidth();
		float height = pdf.getDefaultPageSize().getHeight();
		int n = pdf.getNumberOfPages();
		PdfCanvas canvas;
		Rectangle pageSize;
		for(int i=1;i<=n;i++)
		{
			PdfPage page = pdf.getPage(i);
			pageSize = page.getPageSize();
			canvas = new PdfCanvas(page);
			canvas.setStrokeColor(ColorConstants.BLACK).setLineWidth(.2f).moveTo(pageSize.getWidth()/2-30,20).lineTo(pageSize.getWidth()/2+30,20).stroke();

			//Draw page number
			canvas.beginText().setFontAndSize(PdfFontFactory.createFont(FontConstants.HELVETICA),7).moveText(pageSize.getWidth()/2-7,10).showText(String.valueOf(i)).showText(" of ").showText(String.valueOf(n)).endText();

			//add border
			canvas.rectangle(20, 20, width - 40, height - 40);
			canvas.stroke();
		}
		document.close();
		pdf.close();
		
		//checkin file
		checkinFile(context, strTSId, strTransPath, strFileName);
		
		HashMap hmReturnMap = new HashMap();
		hmReturnMap.put("Action","Success");
		return hmReturnMap;
	}
	private static Cell createCell(String content, float borderWidth, int colspan, TextAlignment alignment) {
		Cell cell = new Cell(1, colspan).add(new Paragraph(content));
		cell.setTextAlignment(alignment);
		if(borderWidth==0)
			cell.setBorder(Border.NO_BORDER);
		else
			cell.setBorder(new SolidBorder(borderWidth));
		return cell;
	}
	private static void checkinFile(Context context, String strObjId, String strFilePath, String strFileName) throws Exception
	{
		DomainObject dObject = DomainObject.newInstance(context,strObjId);
		ContextUtil.pushContext(context);
		dObject.checkinFile(context, true, true, "",  DomainConstants.FORMAT_GENERIC , strFileName, strFilePath);
		ContextUtil.popContext(context);
	}
	private static String getImgFile(Context context) throws Exception
	{
		String strpath = System.getProperty("user.dir");
		File newFile = new File(strpath+"/..");
		String strImageFolder =  EnoviaResourceBundle.getProperty(context,"WMS.Folder.Common.ImagesPath");
		String strLogo = newFile.getCanonicalPath()+strImageFolder+"banner.png";
		strLogo = strLogo.replace("\\", "/");
		return strLogo;
	}
}
