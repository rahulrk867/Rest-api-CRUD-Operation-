import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.Date;
import java.util.Locale;
import java.text.SimpleDateFormat;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.framework.ui.ProgramCallable;
import java.text.DateFormat;
import java.util.Calendar;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class WMSProjectDashboards_mxJPO extends WMSConstants_mxJPO {

public WMSProjectDashboards_mxJPO(Context context, String[] args) throws Exception {
		super(context, args);
	}

@ProgramCallable
public MapList getProjectUnderExecution(Context context, String[] args) throws Exception {

	HashMap programMap = (HashMap)JPO.unpackArgs(args);
		String strWhereCondition ="from[WMSProjectSOC].to.current==UnderExecution || from[WMSProjectSOC].to.current==Delegation ";

		DomainObject doPerson = PersonUtil.getPersonObject(context);
		StringList slObjSelects = new StringList();
		slObjSelects.addElement("id");
		slObjSelects.addElement("physicalid");
		slObjSelects.addElement("type");
		slObjSelects.addElement("current");
		slObjSelects.addElement("policy");
		slObjSelects.addElement("name");
		slObjSelects.addElement("description");
		slObjSelects.addElement("attribute[Task Estimated Duration]");
		slObjSelects.addElement("attribute[Percent Complete]");
		slObjSelects.addElement("attribute[Task Estimated Finish Date]");
		slObjSelects.addElement("from[WMSProjectSOC].to.current");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCProjectType].value");
		slObjSelects.addElement("from[WMSProjectSOC].to.attribute[WMSSOCFinancialYear].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSApprovedDuration].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalDate].value");
		slObjSelects.addElement("from[WMSProjectSOC|to.revision==to.last].to.from[WMSSOCAdminApproval|to.revision==to.last].to.attribute[WMSAdminApprovalAmount].value");
		MapList mlRelatedProjectDetails = doPerson.getRelatedObjects(context,
																	"Member",  //String relPattern
																	"Project Space", //String typePattern
																	slObjSelects,
																	null,
																	true,
																	false,
																	(short)1,
																	strWhereCondition,
																	DomainConstants.EMPTY_STRING,
																	null,
																	null,
																	null);
		String strCurrent = " ";
		String StrDateFormat= " ";
		String SAdminCost= " ";
		String Sname= " ";
		String StrDateFormat1 =" ";
			System.out.println("--------------------------------------------");
			for (int i = 0; i < mlRelatedProjectDetails.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlRelatedProjectDetails.get(i);
				mMap.put("DgnpCount", count+"");
			
				StrDateFormat=(String) mMap.get("attribute[Task Estimated Finish Date]");
				System.out.println("Estimated end Date"+StrDateFormat);
				SimpleDateFormat dt = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
				Date date = dt.parse(StrDateFormat);
				SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
				mMap.put("DateFormat", (dt1.format(date))+"");
				 SAdminCost=(String) mMap.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalAmount].value");
				System.out.println("Cost"+SAdminCost);
				 Sname=(String) mMap.get("description");
				System.out.println("description"+Sname);
				
				
			StrDateFormat1 = (String) mMap.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSAdminApprovalDate].value");
			SimpleDateFormat dt12 = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date date1 = dt12.parse(StrDateFormat1);
			SimpleDateFormat dt21 = new SimpleDateFormat("dd-MM-yyyy");
			String ProjectStartDate= (dt21.format(date1));
			mMap.put("ProjectStartDate", (dt21.format(date1))+"");
				
			Double TotalWeek= Double.parseDouble((String)mMap.get("from[WMSProjectSOC].to.from[WMSSOCAdminApproval].to.attribute[WMSApprovedDuration].value"));
			
			int TotalIntWeek = (int) Math.round(TotalWeek);
			
			int TotalDays = TotalIntWeek*7;
			
			
			//DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
			Calendar c = Calendar.getInstance();
			c.setTime(date1);
			c.add(Calendar.DATE, TotalDays);
			Date projectCompleteDate = c.getTime();
			System.out.println("Project Complete Date as per admin Approval week" +dt.format(projectCompleteDate));
		
			
			
			String ProjectCompletesDate= (dt.format(projectCompleteDate));
			SimpleDateFormat completedDate = new SimpleDateFormat("MM/dd/yyyy hh:mm:s ");
			Date Cdate = completedDate.parse(ProjectCompletesDate);
			SimpleDateFormat completedDate1 = new SimpleDateFormat("dd-MM-yyyy");
			mMap.put("ProjectCompletedDate", (completedDate1.format(Cdate))+"");
				
				strCurrent = (String) mMap.get("from[WMSProjectSOC].to.current");
				if (strCurrent.equalsIgnoreCase("UnderExecution"))
					mMap.put("status", "UnderExecution");
				else if (strCurrent.equalsIgnoreCase("Delegation"))
					mMap.put("status", "Delegation");
			}
				System.out.println("--------------------------------------------");
		return mlRelatedProjectDetails;
		
	}
	@ProgramCallable
	public MapList getPreAAprojects(Context context, String[] args) throws Exception {
		MapList mlSOC = new MapList();
		try {
			DomainObject doPerson = PersonUtil.getPersonObject(context);
			String objectWhere = "revision==last && current!=Rejected && current!=UnderExecution && current!=Delegation";
			StringList strListBusSelects = new StringList();
			strListBusSelects.add(DomainConstants.SELECT_ID);
			//strListBusSelects.add(DomainConstants.SELECT_ORIGINATED);
			strListBusSelects.add(DomainConstants.SELECT_CURRENT);
			//slObjSelects.addElement("id");
			strListBusSelects.addElement("id");
			strListBusSelects.addElement("physicalid");
			strListBusSelects.addElement("type");
			strListBusSelects.addElement("current");
			strListBusSelects.addElement("policy");
			strListBusSelects.addElement("name");
			strListBusSelects.addElement("description");
			strListBusSelects.addElement("attribute[WMSSOCProjectType]");
			strListBusSelects.addElement("attribute[WMSSOCFinancialYear]");
			StringList strListRelSelects = new StringList();
			strListRelSelects.add(DomainRelationship.SELECT_ID);
			mlSOC = doPerson.findObjects(context, TYPE_WMSSOC, // type filter
					DomainConstants.QUERY_WILDCARD, // vault filter
					objectWhere, // where clause
					strListBusSelects); // object selects
			
			String strCurrent = DomainConstants.EMPTY_STRING;
			for (int i = 0; i < mlSOC.size(); i++) {
				int count=i+1;
				Map mMap = (Map) mlSOC.get(i);
				mMap.put("DgnpCount", count+"");
				strCurrent = (String) mMap.get(DomainConstants.SELECT_CURRENT);
				if (strCurrent.equalsIgnoreCase("RIC")) {
					mMap.put("status", "RIC");
				}
				else if (strCurrent.equalsIgnoreCase("ListingOfProjects")) {
					mMap.put("status", "ListingOfProjects");
				}
				else if (strCurrent.equalsIgnoreCase("BoardProceedings")) {
					mMap.put("status", "BoardProceedings");
				}
				else if (strCurrent.equalsIgnoreCase("AE")) {
					mMap.put("status", "AE");
				}
				else if (strCurrent.equalsIgnoreCase("AdminApproval")) {
					mMap.put("status", "AdminApproval");
			}
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mlSOC;
	}
public String getSOCAttributeValue(Context context,String args[]) throws Exception
	{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		HashMap fieldMap = (HashMap) programMap.get("fieldMap");
		HashMap settings = (HashMap) fieldMap.get("settings");

		String strSOCId = (String) paramMap.get("objectId");
		String strAttributeName = (String) settings.get("attribute");

		DomainObject doSOC = DomainObject.newInstance(context, strSOCId);
		String strAttributeValue = doSOC.getInfo(context, "attribute["+strAttributeName+"].value");

		if("TRUE".equals(strAttributeValue))
		{
			strAttributeValue = "Yes";
		}
		if("FALSE".equals(strAttributeValue))
		{
			strAttributeValue = "No";
		}

		return strAttributeValue;
	}
}

