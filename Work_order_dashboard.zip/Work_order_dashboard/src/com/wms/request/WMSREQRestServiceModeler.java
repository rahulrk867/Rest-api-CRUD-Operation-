package com.wms.request;

import com.dassault_systemes.platform.restServices.ModelerBase;
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/resources/WMSREQRestServiceModeler")
public class WMSREQRestServiceModeler extends ModelerBase
{
	@Override
    public Class<?>[] getServices()
    {
        return new Class<?>[] {WorkOrder.class};
    }
}