package com.wms.request;

import com.dassault_systemes.platform.restServices.RestService;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PersonUtil;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.math.BigDecimal;
import java.text.Format;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;


import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObjectBuilder;

@SuppressWarnings("deprecation")
public class WorkOrder extends RestService
{
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GET
	@POST
    @Path("/getWorkOrderDetails")
	public Response getWorkOrderDetails(@javax.ws.rs.core.Context HttpServletRequest request, @QueryParam("state") String state)
    {
    	JsonObjectBuilder output = Json.createObjectBuilder();
    	JsonArrayBuilder outArr = Json.createArrayBuilder();
        Context context = null;
        try
        {
        	context = getAuthenticatedContext(request, false);
            StringList slObj = new StringList();
            slObj.addElement("id");
            slObj.addElement("type");
            slObj.addElement("attribute[WMSWorkorderTitle]");
            slObj.addElement("attribute[WMSCompletionDueDate]");
            slObj.addElement("attribute[WMSValueOfContract]");
            
            DomainObject doPerson = DomainObject.newInstance(context, PersonUtil.getPersonObjectID(context, context.getUser()));
            MapList mlWorkOrders = doPerson.getRelatedObjects(context,
																"WMSWorkOrderAssignee,WMSWOAbstractMBE,WMSWOMBE",  //String relPattern
																"WMSWorkOrder,WMSAbstractMeasurementBookEntry,WMSMeasurementBookEntry", //String typePattern
																slObj,
																null,
																false,
																true,
																(short)2,
																DomainConstants.EMPTY_STRING,
																DomainConstants.EMPTY_STRING,
																null,
																null,
																null);
            //MapList mlReturnList = new MapList();
            
            int iSize = mlWorkOrders.size();
            String strType = DomainConstants.EMPTY_STRING;
            int iMeasurementEntries = 0;
            int iBills = 0;
            Map hmTemp = new HashMap();
            JsonObjectBuilder jsonObj = Json.createObjectBuilder();
            for (int i = 0 ; i < iSize ; i++)
            {
            	
            	strType = (String)((Map)mlWorkOrders.get(i)).get("type");
            	if ("WMSWorkOrder".equals(strType))
            	{
            		hmTemp = new HashMap();
            		iMeasurementEntries = 0;
                    iBills = 0;
                    
                
                    
                	hmTemp.put("woobjid", (String)((Map)mlWorkOrders.get(i)).get("id"));
                	hmTemp.put("wotitle", (String)((Map)mlWorkOrders.get(i)).get("attribute[WMSWorkorderTitle]"));
                	hmTemp.put("wocompletionduedate", changeDateFormat((String)((Map)mlWorkOrders.get(i)).get("attribute[WMSCompletionDueDate]")));
                	hmTemp.put("wovalueofcontract", formatAmount(Double.parseDouble((String)((Map)mlWorkOrders.get(i)).get("attribute[WMSValueOfContract]"))));
                	hmTemp.put("iMeasurementEntries", iMeasurementEntries);
                	hmTemp.put("iBills", iBills);
                	hmTemp.put("financialprogress", getWorkOrderDetails(context, (String)((Map)mlWorkOrders.get(i)).get("id")).get("financialprogress"));
            	}
            	else if ("WMSMeasurementBookEntry".equals(strType))
            	{
            		iMeasurementEntries++;
            		hmTemp.put("iMeasurementEntries", iMeasurementEntries);
            	}
            	else if ("WMSAbstractMeasurementBookEntry".equals(strType))
            	{
            		iBills++;
            		hmTemp.put("iBills", iBills);
            	}
            	map2JsonBuilder(jsonObj, hmTemp);
                outArr.add(jsonObj);
            }

        
            
            output.add("msg", "OK");
            output.add("data", outArr);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return Response.status(200).entity(output.build().toString()).build();
    }
	
	private String changeDateFormat(String strDate) throws Exception
    {    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat ("MM/dd/yyyy");
    	Date date = dateFormat.parse(strDate);	
    	return new SimpleDateFormat("dd-MMM-yyyy").format(date);
    }
	
	@SuppressWarnings({ "unchecked" })
	@GET
	@POST
    @Path("/getWorkOrderMBandAMBDetails")
    public Response getWorkOrderMBandAMBDetails(@javax.ws.rs.core.Context HttpServletRequest request, @QueryParam("id") String id)
    {
		JsonObjectBuilder output = Json.createObjectBuilder();
    	JsonArrayBuilder outArr = Json.createArrayBuilder();
        Context context = null;
        try
        {
        	
        	context = getAuthenticatedContext(request, false);
        	JsonObjectBuilder jsonObj = Json.createObjectBuilder();
        	map2JsonBuilder(jsonObj, getWorkOrderDetails(context, id));
            outArr.add(jsonObj);
            output.add("msg", "OK");
            output.add("data", outArr);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return Response.status(200).entity(output.build().toString()).build();
    }
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private HashMap getWorkOrderDetails (Context context, String strWorkOrderId) throws Exception
	{
		HashMap hmReturnMap = new HashMap();
		
		//prepare object selectables
		StringList slObj = new StringList();
		slObj.addElement("id");
		slObj.addElement("name");
		slObj.addElement("type");
		slObj.addElement("description");
		slObj.addElement("attribute[WMSWorkorderTitle]");
		slObj.addElement("attribute[WMSPONumber]");
		slObj.addElement("attribute[WMSValueOfContract]");

		//get details of work order
		DomainObject doWorkOrder = DomainObject.newInstance(context, strWorkOrderId);
		Map mWorkOrderDetails = (Map)doWorkOrder.getInfo(context, slObj);

		//add work order details to return list
		hmReturnMap.put("objectid", (String)mWorkOrderDetails.get("id"));
		hmReturnMap.put("wotitle", (String)mWorkOrderDetails.get("attribute[WMSWorkorderTitle]"));
		String strValueOfContract = (String)mWorkOrderDetails.get("attribute[WMSValueOfContract]");
		hmReturnMap.put("valueofcontract", formatAmount(Double.parseDouble(strValueOfContract)));

		//get details of related objects
		slObj = new StringList();
		slObj.addElement("current");
		//bill selects
		slObj.addElement("attribute[WMSCertifiedAmount]");
		//advance recovery selects
		slObj.addElement("attribute[WMSAdvanceAmount]");
		slObj.addElement("attribute[WMSRecoveryAmount]");
		//retention release selects
		slObj.addElement("attribute[WMSRetensionAmount]");
		slObj.addElement("attribute[WMSRetentionRecoveryAmount]");
		//withheld release selects 
		slObj.addElement("attribute[WMSBillReductionAmount]");
		slObj.addElement("attribute[WMSBillReductionReleaseAmountTillDate]");

		MapList mlRelatedItemsDetails = doWorkOrder.getRelatedObjects(context,
																		"WMSWOMBE,WMSWOAbstractMBE,WMSWorkOrderAdvances,WMSWorkOrderRetentionRecovery,WMSWorkOrderReduction",  //String relPattern
																		"WMSMeasurementBookEntry,WMSAbstractMeasurementBookEntry,WMSAdvanceRecoveryItem,WMSRetentionRecoveryItem,WMSBillReductionItem ", //String typePattern
																		slObj,
																		null,
																		false,
																		true,
																		(short)1,
																		DomainConstants.EMPTY_STRING,
																		DomainConstants.EMPTY_STRING,
																		null,
																		null,
																		null);

		//add details of related items
		int iSize = mlRelatedItemsDetails.size();

		double dTotalAdvances = 0.0;
		double dTotalRecoveries = 0.0;
		double dTotalRetentions = 0.0;
		double dTotalRetentionReleases = 0.0;
		double dTotalWithheld = 0.0;
		double dTotalWithheldReleases = 0.0;
		double dTotalAmountPaid = 0.0;
		double dTotalAmountInReview = 0.0;
		int iPendingMB = 0;
        int iReviewMB = 0;
        int iSubmittedMB = 0;

		String strType = DomainConstants.EMPTY_STRING;
		for (int i = 0 ; i < iSize ; i++)
		{
			strType = (String)((Map)mlRelatedItemsDetails.get(i)).get("type");
			//get details from Bill
			if("WMSAbstractMeasurementBookEntry".equals(strType))
			{
				if ("Review".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
				{
					dTotalAmountInReview += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
				}
				else if ("Approved".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
				{
					dTotalAmountPaid += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSCertifiedAmount]"));
				}
			}
			//get details of advances and recoveries
			else if ("WMSAdvanceRecoveryItem".equals(strType))
			{
				dTotalAdvances += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSAdvanceAmount]"));
				dTotalRecoveries += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRecoveryAmount]"));
			}
			//get details of retentions and recoveries
			else if ("WMSRetentionRecoveryItem".equals(strType))
			{
				dTotalRetentions += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetensionAmount]"));
				dTotalRetentionReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSRetentionRecoveryAmount]"));
			}
			//get details of withheld releases
			else if ("WMSBillReductionItem".equals(strType))
			{
				dTotalWithheld += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionAmount]"));
				dTotalWithheldReleases += Double.parseDouble((String)((Map)mlRelatedItemsDetails.get(i)).get("attribute[WMSBillReductionReleaseAmountTillDate]"));
			}
			//get details of advances and recoveries
			else if ("WMSMeasurementBookEntry".equals(strType))
			{
				if ("Create".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
        			iPendingMB++;
        		else if ("Review".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")) || "Formalized".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
        			iReviewMB++;
        		else if ("Submitted".equals((String)((Map)mlRelatedItemsDetails.get(i)).get("current")))
        			iSubmittedMB++;
			}
		}

		//add details to return map & maplist
		hmReturnMap.put("dTotalAdvances", formatAmount(dTotalAdvances));
		hmReturnMap.put("dTotalRecoveries", formatAmount(dTotalRecoveries));
		hmReturnMap.put("dTotalRetentions", formatAmount(dTotalRetentions));
		hmReturnMap.put("dTotalRetentionReleases", formatAmount(dTotalRetentionReleases));
		hmReturnMap.put("dTotalWithheld", formatAmount(dTotalWithheld));
		hmReturnMap.put("dTotalWithheldReleases", formatAmount(dTotalWithheldReleases));
		hmReturnMap.put("dTotalAmountPaid", formatAmount(dTotalAmountPaid));
		hmReturnMap.put("dTotalAmountInReview", formatAmount(dTotalAmountInReview));
		hmReturnMap.put("financialprogress", Math.round((dTotalAmountPaid/Double.parseDouble(strValueOfContract))*100));
		hmReturnMap.put("iPendingMB", iPendingMB);
		hmReturnMap.put("iReviewMB", iReviewMB);
		hmReturnMap.put("iSubmittedMB", iSubmittedMB);
		return hmReturnMap;
		
	}
	
	private String formatAmount(double dValue) throws Exception
	{		
		try{
			String str = String.valueOf(dValue);
			BigDecimal amount = new BigDecimal(str);
			 Format format = com.ibm.icu.text.NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
			 String moneyString = format.format(amount);
			 String strReturn = moneyString.replace("Rs.","");
			 return strReturn;
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}
	}
   
    @SuppressWarnings({ "rawtypes", "unchecked" })
	@GET
	@POST
    @Path("/getWorkOrderMBs")
    public Response getWorkOrderMBs(@javax.ws.rs.core.Context HttpServletRequest request, @QueryParam("state") String state, @QueryParam("id") String id)
    {
    	JsonObjectBuilder output = Json.createObjectBuilder();
    	JsonArrayBuilder outArr = Json.createArrayBuilder();
        Context context = null;
        
        try
        {
        	context = getAuthenticatedContext(request, false);
            StringList slObj = new StringList();
            slObj.add("id");
            slObj.add("name");
            slObj.add("current");
            slObj.add("owner");
            //slObj.add("attribute[WMSMBEDateOfMeasurementDate]");
            slObj.add("attribute[WMSWorkorderTitle]");
            slObj.add("from[WMSMBEActivities].to.attribute[Title]");

            DomainObject doWorkOrder = DomainObject.newInstance(context, id);
            MapList mlMBs = doWorkOrder.getRelatedObjects(context,
											           		"WMSWOMBE",
															"WMSMeasurementBookEntry",
															slObj,  // busSelects
															null, // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
           // MapList mlReturnList = new MapList();
            
            int iSize = mlMBs.size();
            Map hmTemp;
            String strCurrent = DomainConstants.EMPTY_STRING;
            DomainObject doPerson = DomainObject.newInstance(context);
            for (int i = 0 ; i < iSize ; i++)
            {
            	JsonObjectBuilder jsonObj = Json.createObjectBuilder();
            	strCurrent = (String)((Map)mlMBs.get(i)).get("current");
            	if (state.equals(strCurrent))
            	{
	            	hmTemp = new HashMap();
	            	hmTemp.put("objid", (String)((Map)mlMBs.get(i)).get("id"));
	            	hmTemp.put("name", (String)((Map)mlMBs.get(i)).get("name"));
	            	hmTemp.put("title", (String)((Map)mlMBs.get(i)).get("attribute[WMSWorkorderTitle]"));
	            	//hmTemp.put("measurementdate", changeDateFormat((String)((Map)mlMBs.get(i)).get("attribute[WMSMBEDateOfMeasurementDate]")));
	            	hmTemp.put("sorids", (String)((Map)mlMBs.get(i)).get("from[WMSMBEActivities].to.attribute[Title]").toString());
	            	
	            	doPerson.setId(PersonUtil.getPersonObjectID(context, (String)((Map)mlMBs.get(i)).get("owner")));
	            	hmTemp.put("owner", doPerson.getInfo(context,"attribute[First Name]") + " " + doPerson.getInfo(context,"attribute[Last Name]"));
	
	            	map2JsonBuilder(jsonObj, hmTemp);
	            	outArr.add(jsonObj);
            	}
            }
           // mlReturnList.sort("name", "descending", ProgramCentralConstants.SORTTYPE_STRING);

           output.add("msg", "OK");
           output.add("data", outArr);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return Response.status(200).entity(output.build().toString()).build();
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
	@GET
	@POST
    @Path("/getWorkOrderAMBs")
    public Response getWorkOrderAMBs(@javax.ws.rs.core.Context HttpServletRequest request, @QueryParam("state") String state, @QueryParam("id") String id)
    {
    	JsonObjectBuilder output = Json.createObjectBuilder();
    	JsonArrayBuilder outArr = Json.createArrayBuilder();
        Context context = null;
        
        try
        {
        	context = getAuthenticatedContext(request, false);
            StringList slObj = new StringList();
            slObj.add("id");
            slObj.add("name");
            slObj.add("current");
            slObj.add("description");
            slObj.add("state[Review].actual");
            slObj.add("owner");
            slObj.add("attribute[WMSCertifiedAmount]");

            DomainObject doWorkOrder = DomainObject.newInstance(context, id);
            MapList mlAMBs = doWorkOrder.getRelatedObjects(context,
											           		"WMSWOAbstractMBE",
															"WMSAbstractMeasurementBookEntry",
															slObj,  // busSelects
															null, // relationshipSelects
															false,      // getTo
															true,       // getFrom
															(short) 1,  // recurseToLevel
															null,// objectWhere
															null);
           // MapList mlReturnList = new MapList();
            
            int iSize = mlAMBs.size();
            Map hmTemp;
            String strCurrent = DomainConstants.EMPTY_STRING;
            DomainObject doPerson = DomainObject.newInstance(context);
            		
            for (int i = 0 ; i < iSize ; i++)
            {
            	JsonObjectBuilder jsonObj = Json.createObjectBuilder();
            	strCurrent = (String)((Map)mlAMBs.get(i)).get("current");
            	if (state.indexOf(strCurrent) > -1)
            	{
	            	hmTemp = new HashMap();
	            	hmTemp.put("objid", (String)((Map)mlAMBs.get(i)).get("id"));
	            	hmTemp.put("name", (String)((Map)mlAMBs.get(i)).get("name"));
	            	hmTemp.put("description", (String)((Map)mlAMBs.get(i)).get("description"));
	            	hmTemp.put("submittedon", changeDateFormat((String)((Map)mlAMBs.get(i)).get("state[Review].actual")));
	            	hmTemp.put("certifiedamount", formatAmount(Double.parseDouble((String)((Map)mlAMBs.get(i)).get("attribute[WMSCertifiedAmount]"))));
	            	
	            	doPerson.setId(PersonUtil.getPersonObjectID(context, (String)((Map)mlAMBs.get(i)).get("owner")));
	            	hmTemp.put("owner", doPerson.getInfo(context,"attribute[First Name]") + " " + doPerson.getInfo(context,"attribute[Last Name]"));
	
	            	map2JsonBuilder(jsonObj, hmTemp);
	            	outArr.add(jsonObj);
            	}
            }
           // mlReturnList.sort("name", "descending", ProgramCentralConstants.SORTTYPE_STRING);
            
            output.add("msg", "OK");
            output.add("data", outArr);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return Response.status(200).entity(output.build().toString()).build();
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	@GET
	@POST
    @Path("/getApprovalHistory")
    public Response getApprovalHistory(@javax.ws.rs.core.Context HttpServletRequest request, @QueryParam("objectId") String objectId)
    {
    	JsonObjectBuilder output = Json.createObjectBuilder();
    	JsonArrayBuilder outArr = Json.createArrayBuilder();
        Context context = null;
       // MapList mlReturnList = new MapList();
        try
        {
        	context = getAuthenticatedContext(request, false);
        	
        	Map programMap = new HashMap(2);
        	programMap.put("objectId", objectId);
        	programMap.put("languageStr", "en-US");
        	
        	MapList mlData = (MapList)JPO.invoke(context, "emxLifecycle", null, "getAllTaskSignaturesOnObject",JPO.packArgs(programMap), MapList.class);
        	
        	int iSize = mlData.size();
        	Map mTemp;
        	
        	DomainObject doPerson = DomainObject.newInstance(context);
        	StringList slPersonDetails = new StringList(4);
        	slPersonDetails.addElement("attribute[First Name]");
        	slPersonDetails.addElement("attribute[Last Name]");
        	slPersonDetails.addElement("attribute[HostPersonRole]");
        	slPersonDetails.addElement("to[Employee].from.name");
        	
        	for (int i = 0 ; i < iSize ; i++)
        	{
        		JsonObjectBuilder jsonObj = Json.createObjectBuilder();
        		mTemp = (Map)mlData.get(i);
        		
        		if ("emptyRow".equals((String)mTemp.get("infoType")))
        			continue;
        		
        		//completion date
        		if (!"".equals((String)mTemp.get("completionDate")) && (String)mTemp.get("completionDate") != null)
        			mTemp.put("completionDateFormatted", changeDateFormat((String)mTemp.get("completionDate")));
        		else
        			mTemp.put("completionDateFormatted", "");
        		
        		//approval status
        		if ("Approve".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Approved By");
        		else if ("None".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Pending With");
        		else if ("Reject".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Rejected By");
        		else if ("Abstain".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Abstained By");
        		else if ("Ignore".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Ignored By");
        		else if ("".equals((String)mTemp.get("approvalStatus")))
        			mTemp.put("approvalStatusFormatted", "Upcoming Approver");
        		
        		//person details
        		doPerson.setId((String)mTemp.get("assigneeId"));
        		Map hmPersonDetails = (Map) doPerson.getInfo(context, slPersonDetails);
        		mTemp.put("assigneeName", (String)hmPersonDetails.get("attribute[First Name]") + " " + (String)hmPersonDetails.get("attribute[Last Name]"));
        		mTemp.put("assigneeRole", (String)hmPersonDetails.get("attribute[HostPersonRole]"));
        		mTemp.put("assigneeOrg", (String)hmPersonDetails.get("to[Employee].from.name"));
        		
        		map2JsonBuilder(jsonObj, mTemp);
            	outArr.add(jsonObj);
        	}
    		
        	output.add("msg", "OK");
            output.add("data", outArr);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return Response.status(200).entity(output.build().toString()).build();
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	@GET
	@POST
    @Path("/getMyActivities")
    public Response getMyActivities(@javax.ws.rs.core.Context HttpServletRequest request, @QueryParam("types") String types)
    {
    	JsonObjectBuilder output = Json.createObjectBuilder();
    	JsonArrayBuilder outArr = Json.createArrayBuilder();
    	
        Context context = null;
        try
        {
        	context = getAuthenticatedContext(request, false);
        	String strNavigation = "from[Route Task].to.to[Object Route].from.";
        	
            StringList slObj = new StringList();
            slObj.addElement("id");
            slObj.addElement("name");
            slObj.addElement("state[Assigned].actual");
            
            //object selects
            slObj.addElement(strNavigation+"id");
            slObj.addElement(strNavigation+"type");
            slObj.add(strNavigation+"name");
            slObj.add(strNavigation+"current");
            slObj.add(strNavigation+"owner");
            slObj.add(strNavigation+"description");
            
            //bill selects 
            slObj.add(strNavigation+"state[Review].actual");
            slObj.add(strNavigation+"attribute[WMSCertifiedAmount]");
            slObj.add(strNavigation+"state[Review].actual");
            slObj.add(strNavigation+"to[WMSWOAbstractMBE].from.id");
            slObj.add(strNavigation+"to[WMSWOAbstractMBE].from.attribute[WMSWorkorderTitle]");
            
            //measurement selects
            //slObj.add(strNavigation+"attribute[WMSMBEDateOfMeasurementDate]");
            slObj.add(strNavigation+"attribute[WMSWorkorderTitle]");
            slObj.add(strNavigation+"from[WMSMBEActivities].to.attribute[Title]");
            slObj.add(strNavigation+"to[WMSWOMBE].from.id");
            slObj.add(strNavigation+"to[WMSWOMBE].from.attribute[WMSWorkorderTitle]");
            
            DomainObject doPerson = DomainObject.newInstance(context, PersonUtil.getPersonObjectID(context, context.getUser()));
            MapList mlObjects = doPerson.getRelatedObjects(context,
										            		"Project Task",  //String relPattern
															"Inbox Task", //String typePattern
															slObj,  // busSelects
															null, // relationshipSelects
															true,      // getTo
															false,       // getFrom
															(short) 1,  // recurseToLevel
															"current==Assigned",
															null);
            
            int iSize = mlObjects.size();
            String strType = DomainConstants.EMPTY_STRING;
            Map mTemp = new HashMap();
            Map mDetails;
            
            for (int i = 0 ; i < iSize ; i++)
            {
            	JsonObjectBuilder jsonObj = Json.createObjectBuilder();
            	
            	mTemp = (Map)mlObjects.get(i);
            	strType = (String)mTemp.get(strNavigation+"type");
            	
            	mDetails = new HashMap();
            	
            	mDetails.put("taskName", (String)mTemp.get("name"));
            	mDetails.put("taskId", (String)mTemp.get("id"));
            	mDetails.put("taskAssignmentDate", (String)mTemp.get("state[Assigned].actual"));
            	
            	if("WMSAbstractMeasurementBookEntry".equals(strType))
            	{
            		mDetails.put("objectType", "Bill");
            		mDetails.put("objid", (String)mTemp.get(strNavigation+"id"));
            		mDetails.put("name", (String)mTemp.get(strNavigation+"name"));
            		mDetails.put("description", mTemp.get(strNavigation+"description"));
            		mDetails.put("submittedon", changeDateFormat((String)mTemp.get(strNavigation+"state[Review].actual")));
            		mDetails.put("certifiedamount", formatAmount(Double.parseDouble((String)mTemp.get(strNavigation+"attribute[WMSCertifiedAmount]"))));
            		mDetails.put("woTitle", mTemp.get(strNavigation+"to[WMSWOAbstractMBE].from.attribute[WMSWorkorderTitle]"));
            		mDetails.put("woId", mTemp.get(strNavigation+"to[WMSWOAbstractMBE].from.id"));
            		
            		doPerson.setId(PersonUtil.getPersonObjectID(context, (String)mTemp.get(strNavigation+"owner")));
	            	mDetails.put("owner", doPerson.getInfo(context,"attribute[First Name]") + " " + doPerson.getInfo(context,"attribute[Last Name]"));
            	}
            	else if ("WMSMeasurementBookEntry".equals(strType))
            	{
            		mDetails.put("objectType", "Measurements");
            		mDetails.put("objid", (String)mTemp.get(strNavigation+"id"));
            		mDetails.put("name", (String)mTemp.get(strNavigation+"name"));
            		mDetails.put("title", (String)mTemp.get(strNavigation+"attribute[WMSWorkorderTitle]"));
            		//mDetails.put("measurementdate", changeDateFormat((String)mTemp.get(strNavigation+"attribute[WMSMBEDateOfMeasurementDate]")));
            		mDetails.put("sorids", (String)mTemp.get(strNavigation+"from[WMSMBEActivities].to.attribute[Title]").toString());
            		mDetails.put("woTitle", mTemp.get(strNavigation+"to[WMSWOMBE].from.attribute[WMSWorkorderTitle]"));
            		mDetails.put("woId", mTemp.get(strNavigation+"to[WMSWOMBE].from.id"));
	            	
	            	doPerson.setId(PersonUtil.getPersonObjectID(context, (String)mTemp.get(strNavigation+"owner")));
	            	mDetails.put("owner", doPerson.getInfo(context,"attribute[First Name]") + " " + doPerson.getInfo(context,"attribute[Last Name]"));
            	}
            	else
            	{
            		continue;
            	}
            	map2JsonBuilder(jsonObj, mDetails);
            	outArr.add(jsonObj);
            }
            
            output.add("msg", "OK");
            output.add("data", outArr);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return Response.status(200).entity(output.build().toString()).build();
    }
    @SuppressWarnings({ "unchecked", "rawtypes" })
	@GET
	@POST
    @Path("/getAllActivities")
    public Response getAllActivities(@javax.ws.rs.core.Context HttpServletRequest request, @QueryParam("types") String types)
    {
    	JsonObjectBuilder output = Json.createObjectBuilder();
    	JsonArrayBuilder outArr = Json.createArrayBuilder();
        Context context = null;
        try
        {
        	context = getAuthenticatedContext(request, false);
        	String strNavigation = "from[Route Task].to.to[Object Route].from.";
        	
            StringList slObj = new StringList();
            slObj.addElement("id");
            slObj.addElement("name");
            slObj.addElement("state[Assigned].actual");
            
            //object selects
            slObj.addElement(strNavigation+"id");
            slObj.addElement(strNavigation+"type");
            slObj.add(strNavigation+"name");
            slObj.add(strNavigation+"current");
            slObj.add(strNavigation+"owner");
            slObj.add(strNavigation+"description");
            
            //bill selects 
            slObj.add(strNavigation+"state[Review].actual");
            slObj.add(strNavigation+"attribute[WMSCertifiedAmount]");
            slObj.add(strNavigation+"state[Review].actual");
            slObj.add(strNavigation+"to[WMSWOAbstractMBE].from.id");
            slObj.add(strNavigation+"to[WMSWOAbstractMBE].from.attribute[WMSWorkorderTitle]");
            
            //measurement selects
            //slObj.add(strNavigation+"attribute[WMSMBEDateOfMeasurementDate]");
            slObj.add(strNavigation+"attribute[WMSWorkorderTitle]");
            slObj.add(strNavigation+"from[WMSMBEActivities].to.attribute[Title]");
            slObj.add(strNavigation+"to[WMSWOMBE].from.id");
            slObj.add(strNavigation+"to[WMSWOMBE].from.attribute[WMSWorkorderTitle]");
            
            DomainObject doPerson = DomainObject.newInstance(context);
            
            ContextUtil.pushContext(context);
            MapList mlObjects = DomainObject.findObjects(context,DomainConstants.TYPE_INBOX_TASK,context.getVault().getName(),"current==Assigned",slObj);
            ContextUtil.popContext(context);
          
           // MapList mlReturnList = new MapList();
            
            int iSize = mlObjects.size();
            String strType = DomainConstants.EMPTY_STRING;
            Map mTemp = new HashMap();
            Map mDetails;
            
            for (int i = 0 ; i < iSize ; i++)
            {
            	JsonObjectBuilder jsonObj = Json.createObjectBuilder();
            	mTemp = (Map)mlObjects.get(i);
            	strType = (String)mTemp.get(strNavigation+"type");
            	
            	mDetails = new HashMap();
            	
            	mDetails.put("taskName", (String)mTemp.get("name"));
            	mDetails.put("taskId", (String)mTemp.get("id"));
            	mDetails.put("taskAssignmentDate", (String)mTemp.get("state[Assigned].actual"));
            	
            	if("WMSAbstractMeasurementBookEntry".equals(strType))
            	{
            		mDetails.put("objectType", "Bill");
            		mDetails.put("objid", (String)mTemp.get(strNavigation+"id"));
            		mDetails.put("name", (String)mTemp.get(strNavigation+"name"));
            		mDetails.put("description", mTemp.get(strNavigation+"description"));
            		mDetails.put("submittedon", changeDateFormat((String)mTemp.get(strNavigation+"state[Review].actual")));
            		mDetails.put("certifiedamount", formatAmount(Double.parseDouble((String)mTemp.get(strNavigation+"attribute[WMSCertifiedAmount]"))));
            		mDetails.put("woTitle", mTemp.get(strNavigation+"to[WMSWOAbstractMBE].from.attribute[WMSWorkorderTitle]"));
            		mDetails.put("woId", mTemp.get(strNavigation+"to[WMSWOAbstractMBE].from.id"));
            		
            		doPerson.setId(PersonUtil.getPersonObjectID(context, (String)mTemp.get(strNavigation+"owner")));
	            	mDetails.put("owner", doPerson.getInfo(context,"attribute[First Name]") + " " + doPerson.getInfo(context,"attribute[Last Name]"));
            	}
            	else if ("WMSMeasurementBookEntry".equals(strType))
            	{
            		mDetails.put("objectType", "Measurements");
            		mDetails.put("objid", (String)mTemp.get(strNavigation+"id"));
            		mDetails.put("name", (String)mTemp.get(strNavigation+"name"));
            		mDetails.put("title", (String)mTemp.get(strNavigation+"attribute[WMSWorkorderTitle]"));
            		//mDetails.put("measurementdate", changeDateFormat((String)mTemp.get(strNavigation+"attribute[WMSMBEDateOfMeasurementDate]")));
            		mDetails.put("sorids", (String)mTemp.get(strNavigation+"from[WMSMBEActivities].to.attribute[Title]").toString());
            		mDetails.put("woTitle", mTemp.get(strNavigation+"to[WMSWOMBE].from.attribute[WMSWorkorderTitle]"));
            		mDetails.put("woId", mTemp.get(strNavigation+"to[WMSWOMBE].from.id"));
	            	
	            	doPerson.setId(PersonUtil.getPersonObjectID(context, (String)mTemp.get(strNavigation+"owner")));
	            	mDetails.put("owner", doPerson.getInfo(context,"attribute[First Name]") + " " + doPerson.getInfo(context,"attribute[Last Name]"));
            	}
            	else
            	{
            		continue;
            	}
            	
            	map2JsonBuilder(jsonObj, mDetails);
            	outArr.add(jsonObj);
            }
            output.add("msg", "OK");
            output.add("data", outArr);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return Response.status(200).entity(output.build().toString()).build();
    }
    
    private static void map2JsonBuilder(JsonObjectBuilder jsonObj, Map<String, Object> mapObj) {
        for (String key : mapObj.keySet()) {
          Object objValue = mapObj.get(key);
          if (objValue instanceof String) {
            jsonObj.add(key, (String)objValue);
            continue;
          } 
          if (objValue instanceof StringList) {
            StringList objValueList = (StringList)objValue;
            JsonArrayBuilder jsonArr = Json.createArrayBuilder();
            for (String stringVal : objValueList)
              jsonArr.add(stringVal); 
            jsonObj.add(key, jsonArr);
            continue;
          } 
          jsonObj.add(key, objValue.toString());
        } 
      }
}
